# Slice Process Recipe

This recipe installs Process slice config.

Not Composed / Not added to the satis.json.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-process-recipe
