<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check process slice displays on a page.
 *
 * @group slices
 */
class ProcessSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a process slice to a node.
   */
  public function testProcessSliceDisplay() {
    $items[] = $this->createParagraph('process_item', [
      'field_title' => 'Process 01',
      'field_content' => 'Process content 1'
    ]);
    $items[] = $this->createParagraph('process_item', [
      'field_title' => 'Process 02',
      'field_content' => 'Process content 2'
    ]);

    $paragraphs[] = $this->createParagraph('slice_process', [
      'field_title' => 'Process Slice',
      'field_items' => $items,
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $assertSession->pageTextContains('Process Slice');
    $assertSession->pageTextContains('Process 01');
    $assertSession->pageTextContains('Process content 1');
    $assertSession->pageTextContains('Process 02');
    $assertSession->pageTextContains('Process content 2');
  }

  /**
   * Test adding a process displays content items field requires a minimum of 2 items.
   */
  public function testProcessSliceMinimumProcessItems(): void {
    $items[] = $this->createParagraph('process_item', [
      'field_title' => 'Process 01',
      'field_content' => 'Process content 1'
    ]);

    $paragraphs[] = $this->createParagraph('slice_process', [
      'field_title' => 'Process slice title',
      'field_items' => $items,
    ]);

    $node = $this->createPublishedNode([
      'title' => 'Page title',
      'field_teaser_summary' => 'Page summary',
      'field_slices' => $paragraphs,
    ]);
    $assertSession = $this->assertSession();

    // Login as editor.
    $this->createUserWithPersonaAndLogin(['editor']);

    $this->visitCheckCode('node/' . $node->id() . '/edit', Response::HTTP_OK);

    $this->submitForm([], 'Save');
    $assertSession->statusCodeEquals(Response::HTTP_OK);
    $assertSession->responseContains('Process items field requires a minimum of 2 items.');
  }

  /**
   * Test adding a process displays content items field requires a maximum of 4 items.
   */
  public function testProcessSliceMaximumProcessItems(): void {
    $items[] = $this->createParagraph('process_item', [
      'field_title' => 'Process 01',
      'field_content' => 'Process content 1'
    ]);

    $items[] = $this->createParagraph('process_item', [
      'field_title' => 'Process 02',
      'field_content' => 'Process content 2'
    ]);

    $items[] = $this->createParagraph('process_item', [
      'field_title' => 'Process 03',
      'field_content' => 'Process content 3'
    ]);

    $items[] = $this->createParagraph('process_item', [
      'field_title' => 'Process 04',
      'field_content' => 'Process content 4'
    ]);

    $items[] = $this->createParagraph('process_item', [
      'field_title' => 'Process 05',
      'field_content' => 'Process content 5'
    ]);

    $paragraphs[] = $this->createParagraph('slice_process', [
      'field_title' => 'Process slice title',
      'field_items' => $items,
    ]);

    $node = $this->createPublishedNode([
      'title' => 'Page title',
      'field_teaser_summary' => 'Page summary',
      'field_slices' => $paragraphs,
    ]);
    $assertSession = $this->assertSession();

    // Login as editor.
    $this->createUserWithPersonaAndLogin(['editor']);

    $this->visitCheckCode('node/' . $node->id() . '/edit', Response::HTTP_OK);

    $this->submitForm([], 'Save');
    $assertSession->statusCodeEquals(Response::HTTP_OK);
    $assertSession->responseContains('Process items field requires a maximum of 4 items.');
  }
}
