<?php

declare(strict_types=1);

namespace Drupal\media_video_preview\Hook;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\Core\Theme\ThemeManagerInterface;

/**
 * Hook implementations for media_video_preview.
 */
class MediaVideoPreviewHooks {

  use StringTranslationTrait;

  public function __construct(
    private readonly ThemeManagerInterface $themeManager,
    private readonly ConfigFactoryInterface $configFactory,
    TranslationInterface $string_translation,
  ) {
    $this->stringTranslation = $string_translation;
  }

  /**
   * Implements hook_help().
   */
  #[Hook('help')]
  public function help(string $route_name, RouteMatchInterface $route_match): ?string {
    switch ($route_name) {
      case 'help.page.media_video_preview':
        $output = '';
        $output .= '<h3>' . $this->t('About') . '</h3>';
        $output .= '<p>' . $this->t('Add media preview data') . '</p>';
        return $output;

      default:
        return NULL;
    }
  }

  /**
   * Implements hook_preprocess_media().
   */
  #[Hook('preprocess_media')]
  public function preprocessMedia(array &$variables): void {
    $media = $variables['elements']['#media'];
    if ($media->bundle() === 'video') {
      $admin_theme = $this->configFactory->get('system.theme')->get('admin');
      if ($this->themeManager->getActiveTheme()->getName() !== $admin_theme) {
        $video_source = $media->getSource()->getMetadata($media, 'source');
        $classes = $video_source . '-embedded-video embedded-video';
        $variables['content']['field_media_video_embed_field'][0]['children']['#attributes']['class'][] = $classes;
        $variables['content']['preview_overlay'] = [
          '#theme' => 'media_video_preview_overlay',
          '#content' => [
            'video_source' => $video_source,
            'thumbnail' => $variables['content']['thumbnail'] ?? NULL,
          ],
        ];
      }
    }
  }

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'media_video_preview_overlay' => [
        'variables' => [
          'content' => [],
        ],
      ],
    ];
  }

  /**
   * Implements hook_entity_base_field_info_alter().
   */
  #[Hook('entity_base_field_info_alter')]
  public function entityBaseFieldInfoAlter(array &$fields, EntityTypeInterface $entity_type): void {
    if ($entity_type->id() === 'media') {
      // Allow uploading or removing the thumbnail image.
      $fields['thumbnail']->setDisplayConfigurable('form', TRUE);
    }
  }

}
