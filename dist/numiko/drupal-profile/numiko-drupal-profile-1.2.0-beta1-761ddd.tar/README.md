# Numiko Drupal 9 Install Profile

This is the standard Numiko Drupal 9 profile.

In most cases the install profile will be used as part of the [Drupal 9 Composer Template](https://bitbucket.org/numiko/drupal-9-composer-template) - see the instructions there if you want to create a new site from the profile.

# Features

## Hero

There is an embedded video field, and a field to be used to link directly to a video. It is likely that only one of these will be needed in a project, so remove the one that isn't.

# Development

Amending the install profile is not simply a case of making changes on a site and exporting config. You need a site that has been built from the install profile, with no extra config changes, so you will be creating sites from scratch a lot. Make the changes there and export the config.

Copy the config to an install profile working copy, removing unnecessary lines (see below). Commit to the install profile.

It's now necessary to test this on a new site. Tag the changes and update our [package repository](http://non-dev-perm.numiko.local:4567/Numiko-Package-Repository) - the changes must be known to the package repository before a full test can be performed. Create a new site with the [composer template](https://bitbucket.org/numiko/drupal-9-composer-template).

As you build and destroy sites, you'll need to use `docker-compose down` rather than `stop` to remove all containers and the network, otherwise you'll end up with a lot of unused Docker resources.

## Removing unnecessary lines from all config files in a directory:

```
find . -name '*.yml' | xargs sed -i '/^\_core/d'
find . -name '*.yml' | xargs sed -i '/^uuid/d'
find . -name '*.yml' | xargs sed -i '/default\_config\_hash/d'
```

