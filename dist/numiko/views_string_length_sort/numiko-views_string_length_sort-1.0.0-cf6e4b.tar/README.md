# Views String Length Sort

Adds a new sort type to all fields output as a string, so you can sort by the output string length.