<?php

declare(strict_types=1);

namespace Drupal\username_sanitize\Drush\Listeners;

use Drupal\Core\Database\Connection;
use Drush\Commands\AutowireTrait;
use Drush\Event\SanitizeConfirmsEvent;
use Psr\Log\LoggerInterface;
use Symfony\Component\Console\Event\ConsoleTerminateEvent;
use Symfony\Component\EventDispatcher\Attribute\AsEventListener;

/**
 * Sanitizes usernames during drush sql:sanitize.
 */
#[AsEventListener(method: 'onSanitizeConfirm')]
#[AsEventListener(method: 'onConsoleTerminate')]
final class UsernameSanitizeListener {

  use AutowireTrait;

  public function __construct(
    protected Connection $database,
    protected LoggerInterface $logger,
  ) {}

  /**
   * Adds this operation to the pre-sanitize confirmation summary.
   */
  public function onSanitizeConfirm(SanitizeConfirmsEvent $event): void {
    $event->addMessage(dt('Sanitize usernames.'));
  }

  /**
   * Performs the sanitization after the command has run.
   */
  public function onConsoleTerminate(ConsoleTerminateEvent $event): void {
    if ($event->getCommand()->getName() !== 'sql:sanitize' || $event->getExitCode()) {
      return;
    }

    $this->database->update('users_field_data')
      ->condition('uid', 0, '>')
      ->expression('name', "CONCAT('user_', uid)")
      ->execute();
    $this->logger->notice('Usernames sanitized.');
  }

}
