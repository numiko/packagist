## Username Sanitize

Extends `drush sql-sanitize` to sanitize usernames.

Sets the username as `user_{$uid}`.
