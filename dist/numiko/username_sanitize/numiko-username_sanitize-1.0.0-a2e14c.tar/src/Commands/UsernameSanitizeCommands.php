<?php

namespace Drupal\username_sanitize\Commands;

use Consolidation\AnnotatedCommand\CommandData;
use Drupal\Core\Database\Connection;
use Drush\Commands\DrushCommands;
use Drush\Drupal\Commands\sql\SanitizePluginInterface;
use Symfony\Component\Console\Input\InputInterface;

/**
 * Drush sql-sanitize plugin for sanitising username.
 */
class UsernameSanitizeCommands extends DrushCommands implements SanitizePluginInterface {

  /**
   * @var \Drupal\Core\Database\Connection
   */
  protected $database;

  /**
   * Constructor.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(Connection $database) {
    $this->database = $database;
  }

  /**
   * Sanitize usernames.
   *
   * @hook post-command sql-sanitize
   *
   * {@inheritdoc}
   */
  public function sanitize($result, CommandData $command_data) {
    $this->database->update('users_field_data')
      ->condition('uid', 0, '>')
      ->expression('name', "CONCAT('user_', uid)")
      ->execute();
    $this->logger()->success(dt("Usernames sanitized."));
  }

  /**
   * Sanitization messages.
   *
   * @hook on-event sql-sanitize-confirms
   *
   * {@inheritdoc}
   */
  public function messages(&$messages, InputInterface $input) {
    $messages[] = dt('Sanitize usernames.');
  }

}
