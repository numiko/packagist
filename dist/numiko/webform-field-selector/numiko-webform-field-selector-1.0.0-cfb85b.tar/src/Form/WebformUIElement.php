<?php

namespace Drupal\webform_field_selector\Form;

use Drupal\Core\Form\FormStateInterface;

class WebformUIElement {

  public function elementFormAlter(array &$form, FormStateInterface $form_state) {
    if ($webform = $form_state->getBuildInfo()['callback_object']->getWebform()) {
      $form['properties']['element']['optional_field'] = [
        '#type' => 'checkbox',
        '#title' => 'This field can be optionally included',
        '#description' => 'This will only affect webforms which have webform optional fields enabled',
        '#default_value' => ($form_state->get('element_properties') && isset($form_state->get('element_properties')['optional_field'])) ? $form_state->get('element_properties')['optional_field'] : '',
        '#parents' => ['properties', 'optional_field'],
        '#weight' => 50,
      ];
    }
  }

}