<?php

namespace Drupal\webform_field_selector\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Serialization\Yaml;
use Drupal\webform\WebformMessageManagerInterface;
use Drupal\webform\Plugin\Field\FieldFormatter\WebformEntityReferenceEntityFormatter;

/**
 * Plugin implementation of the 'Webform rendered entity' formatter.
 *
 * @FieldFormatter(
 *   id = "webform_entity_reference_entity_view",
 *   label = @Translation("Webform"),
 *   description = @Translation("Display the referenced webform with default submission data."),
 *   field_types = {
 *     "webform_optional_fields"
 *   }
 * )
 */
class WebformFieldSelectorEntityReferenceEntityFormatter extends WebformEntityReferenceEntityFormatter {

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    /**
      * Loop through each of the webform entities and check to see if there are any hidden webform elements.
      */
    foreach ($this->getEntitiesToView($items, $langcode) as $delta => $entity) {
      $hiddenElements = $this->elementsToHide($items[$delta]);
      if ($hiddenElements) {
        $this->deleteElementsFromSubmissionForm($entity, array_keys($hiddenElements));
      }
    }
    $elements = parent::viewElements($items, $langcode);
    return $elements;
  }

  /**
   * Asking which fields to keep but need the reverse, i.e. those with 0 as the array value.
   */
  protected function elementsToHide($item) {
    return array_filter($item->optional_field_switch, function($value) {
      return $value === 0;
    });
  }

  /**
   * Loop through the elements array and remove any that are marked as hidden.
   */
  protected function deleteElementsFromSubmissionForm($webform, $hiddenElements) {
    foreach ($hiddenElements as $hiddenElement) {
      if ($webformElement = $webform->getElement($hiddenElement)) {
        $webform->deleteElement($hiddenElement);
      }
    }
  }

}
