# Recipe Config Action

This module is designed to provide extra config actions to be used with recipes.
