# Workbench Moderation Bulk Actions

Content view bulk action plugins for Workbench Moderation.

## Description

Currently Views Bulk Operations (VBO) do not play nicely with Workbench Moderation.
See:

[Unable to publish/unpublish content from admin/content page when Workbench Moderation is enabled](https://www.drupal.org/node/2804105)

and

[Add an action plugin to transition between states](https://www.drupal.org/node/2627780)

### Moderation states
I have extended the work from the gist in the second link above to include the default Workbench Moderation states.

* Archived
* Draft
* Needs Review
* Published

If you configure additional states, you will also need to create a corresponding Plugin Action and system.action.*.yml file for each.

Uninstall and re-install the module to have new actions recognised.

### Moderation state transitions
This module uses the WM services to control access, so some of the default transitions will be invalid (although you should be able to define the missing transitions if you wish).

e.g.

* Published -> Needs review (must go to Draft first)
* Archived -> Draft (Archived items can only be published - and an item must be published before it can be archived)

### Permissions
Users must have the relevant "Use the _Moderation state transition_ transition" permission to perform an action. Where _Moderation state transition_ is one of those listed on the /admin/structure/workbench-moderation/transitions page.

### Non-moderatable content
Not all content types will necessarily have moderation enabled. For these types actions will be handled based on the _status_ property.

For access control the _from_ part of the transition will be treated as if status = true = _'published'_, and status = false = _'draft'_.

If a transition is allowed, non-moderatable item status will be set to _NODE_PUBLISHED_ for the "Workbench Moderation Publish" action and to _NODE_NOT_PUBLISHED_ for other actions.

## Dependencies

* workbench_moderation
