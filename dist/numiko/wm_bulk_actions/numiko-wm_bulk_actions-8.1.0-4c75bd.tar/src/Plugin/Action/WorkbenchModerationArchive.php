<?php

namespace Drupal\wm_bulk_actions\Plugin\Action;

/**
 * Move a node to Archived.
 *
 * @Action(
 *   id = "workbench_moderation_node_archive_action",
 *   label = @Translation("Workbench Moderation Archive"),
 *   type = "node"
 * )
 */
class WorkbenchModerationArchive extends AbstractWorkbenchModerationAction
{
  const STATE_TARGET = 'archived';
}
