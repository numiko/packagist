<?php

namespace Drupal\secureme\Form;

use Drupal\Core\Flood\FloodInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\user\UserAuthInterface;
use Drupal\user\UserStorageInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\user\Form\UserLoginForm as DefaultUserLoginForm;

use Drupal\Component\Utility\Html;
use Drupal\Component\Utility\Crypt;

/**
 * Provides a user login form.
 */
class UserLoginForm extends DefaultUserLoginForm {
  
  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    
    // Manually make sure that even an Anonymous user has a Session started
    \Drupal::service('session_manager')->start();
    if ($_SESSION['login_token']) {
      $login_token = $_SESSION['login_token'];
    } else {    
      $login_token = \Drupal::service('csrf_token')->get('login_token');
      
      $_SESSION['login_token'] = $login_token;      
    }
  
    $form = parent::buildForm($form, $form_state);
    
    // CSRF validation must come before Final!
    array_unshift($form['#validate'], '::validateCsrf');
    
    //$form['#token'] = TRUE;
    $form['form_token'] = [
      '#id' => Html::getUniqueId('edit-form-token'),
      '#type' => 'token',
      '#value' => $login_token,
      //'#value' => 'csrf_value',
      // Form processing and validation requires this value, so ensure the
      // submitted form value appears literally, regardless of custom #tree
      // and #parents being set elsewhere.
      '#parents' => ['form_token'],
      '#cache' => [
        'max-age' => 0,
      ],
    ];
    \Drupal::service('session_manager')->save();
    
    return $form;
  }
  
  public function validateCsrf(array &$form, FormStateInterface $form_state) {    
    // Validate that the _token field is what we stored somewhere...
    
    // Use `\Drupal::request()->get('form_token')` as form_token is CLEANED by Drupal
    
    \Drupal::service('session_manager')->start();
    if ($_SESSION['login_token']) {
      $login_token = $_SESSION['login_token'];
      
      if (! $login_token === \Drupal::request()->get('form_token')) {
        $form_state->setErrorByName('name', 'This submission is invalid: Token failed!');
        return;
      }
    } else {    
      $form_state->setErrorByName('name', 'This submission is invalid: Session failed!');
      return;
    }
      
    if (! \Drupal::service('csrf_token')->validate(\Drupal::request()->get('form_token'), 'login_token')) {       
      $form_state->set('invalid_csrf', TRUE);
      $form_state->setErrorByName('name', 'This submission is invalid: You tried to steal an identity!');
      return;
    }
  }
  
  //public function validateFinal(array &$form, FormStateInterface $form_state) {
  //  \Drupal::service('session_manager')->start();
  //  
  //  //die(\Drupal::service('csrf_token')->validate($form_state->getValue('form_token')));
  //  die(var_dump([$_SESSION, $form_state->getValue('form_token')]));
  //  
  //  if ($csrf_identifier = $form_state->get('invalid_csrf')) {
  //    // 
  //    $this->flood->register('user.failed_login_ip', $flood_config->get('ip_window'));
  //    $this->flood->register('user.failed_login_user', $flood_config->get('user_window'), 'Csrf invalid');
  //    $form_state->setErrorByName('name', 'This submission is invalid');
  //  }
  //  
  //  parent::validateFinal($form, $form_state);
  //}

}
