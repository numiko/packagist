<?php

namespace Drupal\enforceuserlogincsrf\Form;

use Drupal\user\Form\UserLoginForm as DefaultUserLoginForm;
/**
 * Provides a user login form.
 */
class UserLoginForm extends DefaultUserLoginForm {

    use UserTraitForm;

}
