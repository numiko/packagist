<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the rich text list slice displays on a page.
 *
 * @group slices
 */
class RichTextListSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a rich text list slice to a node.
   */
  public function testContentSliceDisplay(): void {
    $items = [
      $this->createParagraph('content_list_item', [
        'field_title' => 'Content Slice List Title 1',
        'field_content' => 'Content Slice List Content 1',
      ]),
      $this->createParagraph('content_list_item', [
        'field_title' => 'Content Slice List Title 2',
        'field_content' => 'Content Slice List Content 2',
      ]),
      $this->createParagraph('content_list_item', [
        'field_title' => 'Content Slice List Title 3',
        'field_content' => 'Content Slice List Content 3',
      ]),
    ];

    $paragraph = $this->createParagraph('slice_content_list', [
      'field_title' => 'Content Slice Title',
      'field_items' => $items,
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraph]);

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $this->assertSession()->pageTextContains('Content Slice Title');
    $this->assertSession()->pageTextContains('Content Slice List Title 1');
    $this->assertSession()->pageTextContains('Content Slice List Content 1');
    $this->assertSession()->pageTextContains('Content Slice List Title 2');
    $this->assertSession()->pageTextContains('Content Slice List Content 2');
    $this->assertSession()->pageTextContains('Content Slice List Title 3');
    $this->assertSession()->pageTextContains('Content Slice List Content 3');
    $this->assertSession()->pageTextContains('01');
    $this->assertSession()->pageTextContains('02');
    $this->assertSession()->pageTextContains('03');

  }

}
