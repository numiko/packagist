<?php

namespace Drupal\icon_menu\Plugin\Block;

use Drupal\Core\Form\FormStateInterface;
use Drupal\system\Plugin\Block\SystemMenuBlock;

/**
 * Provides an extended Menu block with icon functionality.
 *
 * @Block(
 *   id = "icon_menu_block",
 *   admin_label = @Translation("Icon menu block"),
 *   category = @Translation("Icon Menus"),
 *   deriver = "Drupal\system\Plugin\Derivative\SystemMenuBlock"
 * )
 */
class IconMenuBlock extends SystemMenuBlock {

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->configuration;

    $form = parent::blockForm($form, $form_state);

    $form['suggestion'] = [
      '#type' => 'machine_name',
      '#title' => $this->t('Theme hook suggestion'),
      '#default_value' => $config['suggestion'],
      '#field_prefix' => '<code>menu__</code>',
      '#description' => $this->t('A theme hook suggestion can be used to override the default HTML and CSS classes for menus found in <code>menu.html.twig</code>.'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['suggestion'] = $form_state->getValue('suggestion');
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return parent::defaultConfiguration() + [
      'suggestion' => strtr($this->getDerivativeId(), '-', '_'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = parent::build();
    if (!isset($build['#items'])) {
      return $build;
    }
    $build['#theme'] = 'icon_menu';
    // Add the configuration for use in
    // icon_menu_theme_suggestions_icon_menu_alter().
    $build['#icon_menu_configuration'] = $this->configuration;
    foreach ($build['#items'] as &$item) {
      if ($attributes = $item['url']->getOption('attributes')) {
        $item['icon'] = $attributes['title'];
        unset($attributes['title']);
        $item['url']->setOption('attributes', $attributes);
      }
    }
    return $build;
  }

}
