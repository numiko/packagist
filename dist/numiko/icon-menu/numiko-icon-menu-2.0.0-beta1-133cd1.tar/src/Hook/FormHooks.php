<?php

namespace Drupal\icon_menu\Hook;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Hook implementations for icon_menu.
 */
final class FormHooks {
  use StringTranslationTrait;

  public function __construct(
    TranslationInterface $stringTranslation,
    protected readonly ConfigFactoryInterface $configFactory,
  ) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Implements hook_form_FORM_ID_alter().
   */
  #[Hook('form_menu_link_content_menu_link_content_form_alter')]
  public function menuLinkFormAlter(array &$form, FormStateInterface $form_state, string $form_id): void {
    $icon_choices = '';
    /** @var ?string $directory */
    $directory = $this->configFactory->get('icon_menu.settings')->get('icon_directory');
    if ($directory) {
      $icon_files = scandir($directory);
      if ($icon_files) {
        $icons = array_filter(array_map(static fn($file) => $file != "." && $file != ".." && strtolower(substr($file, strrpos($file, '.') + 1)) == 'svg' ? str_replace('.svg', '', $file) : NULL, $icon_files));
      }
      if (!empty($icons)) {
        $icon_choices = "(these can include: <em>" . implode(', ', $icons) . "</em>)";
      }
    }
    $form['description']['widget']['#title'] = $this->t('Description / Icon');
    $form['description']['widget'][0]['value']['#title'] = $this->t('Description / Icon');
    $form['description']['widget'][0]['value']['#description'] = $this->t('Shown when hovering over the menu link <b>or</b> the icon class if used in an icon menu @icon_choices.', [
      '@icon_choices' => $icon_choices,
    ]);
  }

}
