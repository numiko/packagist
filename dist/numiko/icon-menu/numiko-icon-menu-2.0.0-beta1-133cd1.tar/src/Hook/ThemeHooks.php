<?php

namespace Drupal\icon_menu\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Theme hook implementations for icon_menu.
 */
final class ThemeHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'icon_menu' => [
        'template' => 'icon-menu',
        'render element' => 'children',
        'variables' => [
          'items' => [],
          'menu_name' => '',
        ],
      ],
    ];
  }

  /**
   * Implements hook_theme_registry_alter().
   *
   * Add $icon_menu_configuration as a variable to the 'icon_menu' theme hook
   * and set its default value to be an empty array.
   */
  #[Hook('theme_registry_alter')]
  public function themeRegistryAlter(array &$theme_registry): void {
    $theme_registry['icon_menu']['variables']['icon_menu_configuration'] = [];
  }

  /**
 * Implements hook_theme_suggestions_alter().
 */
  #[Hook('theme_suggestions_icon_menu_alter')]
  public function themeSuggestionsIconMenuAlter(array &$suggestions, array $variables): void {
    $suggestions[] = $variables['theme_hook_original'] . '__' . str_replace('-', '_', $variables['menu_name']);

    if (!empty($variables['icon_menu_configuration'])) {
      $config = $variables['icon_menu_configuration'];
      $menu_name = strtr($variables['menu_name'], '-', '_');

      // Add our custom theme suggestion.
      if (!empty($config['suggestion']) && $config['suggestion'] !== $menu_name) {
        $suggestions[] = $variables['theme_hook_original'] . '__' . $config['suggestion'];
      }
    }
  }

  /**
   * Implements hook_theme_suggestions_HOOK_alter().
   *
   * Adds block__icon_menu__{suggestion} to icon menu block.
   */
  #[Hook('theme_suggestions_block_alter')]
  public function themeSuggestionsBlockAlter(array &$suggestions, array $variables): void {
    if (isset($variables['elements']['#base_plugin_id']) && $variables['elements']['#base_plugin_id'] === 'icon_menu_block') {
      $menu_name = strtr($variables['elements']['#derivative_plugin_id'], '-', '_');
      $config = $variables['elements']['#configuration'] ?? [];
      $suggestions[] = 'block__icon_menu__' . $menu_name;
      // Add our custom theme suggestion.
      if (!empty($config['suggestion']) && $config['suggestion'] !== $menu_name) {
        $suggestions[] = 'block__icon_menu__' . $config['suggestion'];
      }
    }
  }

}
