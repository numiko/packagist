# Icon Menu #

This extension to the system menu modifies the usage of the description field to use it as the svn icon id.

## Usage ##

The main use case for this extension is in social media menu's which are commonly accompanied by iconography.