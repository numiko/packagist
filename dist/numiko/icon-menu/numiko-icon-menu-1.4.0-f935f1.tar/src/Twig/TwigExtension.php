<?php

namespace Drupal\icon_menu\Twig;

use Twig\TwigFilter;
use Twig\Extension\AbstractExtension;
use Drupal\menu_link_content\Plugin\Menu\MenuLinkContent;

/**
 * Twig extension for handling media.
 *
 * Dependency injection is not used for performance reason.
 */
class TwigExtension extends AbstractExtension {

  /**
   * {@inheritdoc}
   */
  public function getFilters() {
    $filters = [
      new TwigFilter('menu_item_icon', [$this, 'menuItemIcon']),
    ];
    return $filters;
  }

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return 'icon_menu';
  }

  /**
   * Get the menu icon name from the menu item.
   *
   * Menu items are not fieldable and therefore we need to store additional
   * information as it was not intended. TO this end we make use of the almost
   * entirely unused menu item description field.
   *
   * We alter the form to re-label the field and then use this twig extension
   * to output the content of that field.
   *
   * This does have the downside that if a description were added for a menu
   * item that would be used as the menu icon (and almost certainly no relevant
   * icon would be found).
   */
  public function menuItemIcon(array $menuItem) : ?string {
    if (!empty($menuItem['original_link']) && $menuItem['original_link'] instanceof MenuLinkContent) {
      return $menuItem['original_link']->getDescription();
    }
  }

}
