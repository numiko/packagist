# Quote Slice Recipe

This recipe installs quote config.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-quote-recipe
