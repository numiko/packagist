<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the quote slice displays on a page.
 *
 * @group slices
 */
class QuoteSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a quote slice to a node.
   */
  public function testQuoteSliceDisplay() {
    $paragraphs[] = $this->createParagraph('slice_quote', [
      'field_title' => 'Quote slice title',
      'field_content' => 'Test Quote',
      'field_name' => 'Ao Tanaka',
      'field_job_title' => 'Netrunner',
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $assertSession->pageTextContains('Quote slice title');
    $assertSession->pageTextContains('Test Quote');
    $assertSession->pageTextContains('Ao Tanaka');
    $assertSession->pageTextContains('Netrunner');
  }

}
