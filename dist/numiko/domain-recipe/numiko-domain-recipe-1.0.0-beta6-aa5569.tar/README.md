# Domain Recipe

This recipe installs the necessary modules for adding Domain functionality to a site.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/domain-recipe`
