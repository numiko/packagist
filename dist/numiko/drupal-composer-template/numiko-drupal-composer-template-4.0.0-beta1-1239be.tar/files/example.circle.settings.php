<?php

$config['config_split.config_split.dev']['status'] = FALSE;
$config['config_split.config_split.prod']['status'] = TRUE;
$config['config_split.config_split.stage']['status'] = TRUE;

$config['search_api.server.solr_server']['backend_config']['connector_config']['core'] = 'drupal';
$config['search_api.server.solr_server']['backend_config']['connector_config']['port'] = '8983';
$config['search_api.server.solr_server']['backend_config']['connector_config']['host'] = 'solr';
$config['search_api.server.solr_server']['backend_config']['connector_config']['path'] = '/';

$databaseName = getenv('DATABASE_NAME');
$databaseUser = getenv('DATABASE_USER');
$databasePassword = getenv('DATABASE_PASSWORD');
$databaseHost = getenv('DATABASE_HOST');

$databases['default']['default'] = [
  'database' => ($databaseName !== FALSE) ? $databaseName : '',
  'username' => ($databaseUser !== FALSE) ? $databaseUser : '',
  'password' => ($databasePassword !== FALSE) ? $databasePassword : '',
  'host' => ($databaseHost !== FALSE) ? $databaseHost : '',
  'port' => '3306',
  'namespace' => 'Drupal\\Core\\Database\\Driver\\mysql',
  'driver' => 'mysql',
  'prefix' => '',
];
