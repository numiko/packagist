# Numiko Composer template for Drupal Project

## Quickstart

Make sure you have no other sites running with Docker. The `install-site-kit` script will ask you if you want to create the Drupal database - if you answer this question too quickly it will fail - just run the script again (see Troubleshooting below).

```sh
composer create-project numiko/drupal-composer-template:3.0.0 {PROJECT_NAME} --stability dev --no-interaction --repository-url=https://numiko.github.io/packagist --ignore-platform-reqs
cd {PROJECT_NAME}
cp ~/.ssh/{KEY_FOR_BITBUCKET_REPOS} docker/web/.env.key
# Only needed on Linux
chown $USER:docker -R db-backups
./scripts/dev/install-site-kit
```
You will now have a site running at [https://localhost:8081/](https://localhost:8081/).

The `sysadmin` password will be output after Drupal installation (part of the `install-site-kit` script).

## History

* [Numiko Drupal 9 Composer template](https://bitbucket.org/numiko/drupal-9-composer-template/src)
* [Numiko Drupal 8 Composer template](https://bitbucket.org/numiko/drupal-8-composer-template/src) was a fork of [Composer template for Drupal Projects](https://github.com/drupal-composer/drupal-project)

## Detailed usage

Below is a detailed explanation of the install steps above.

### Create the project

Create the project with Composer. Brings in the Docker files, Drupal and the install profile.

Replace {PROJECT_NAME} with the directory name where you want the project.

* `composer create-project numiko/drupal-composer-template:3.* {PROJECT_NAME} --stability dev --no-interaction --repository-url=https://numiko.github.io/packagist --ignore-platform-reqs
`

### Install site kit

Copy your key into the container context so that it can be accessed during the build, then run the setup script:

* `cp ~/.ssh/my_selected_key docker/web/.env.key`

Build and bring up the Docker containers, install Drupal using Drush with the Drupal Install Profile (will ask a series of questions about the site), and then set correct permissions:

* `./scripts/dev/install-site-kit`

### CircleCI Config

Replace the `.circleci/config.yml` `$SLACK_CHANNEL` variables with the slack channel.

### Remove this line and everything above once you create the site

----------------------------

# Drupal Project by Numiko

## Initial project setup

Instructions for building the existing project locally for the first time.

### 1. Clone the repository
### 2. Add your SSH key to the docker container

```sh
cp ~/.ssh/my_selected_key docker/web/.env.key
```

### 3. Run the install-environment script.

```sh
./scripts/dev/install-environment
```

### 4. Obtain a DB and add it into the db-backups directory

### 5. Import DB (Change sql file name to yours)

```sh
docker compose exec -T db mariadb -u drupal -pdrupal drupal < <path-to-db-dump>
```

### 6. Run the install-local script

```sh
docker compose exec web ./scripts/dev/install-local
```

### 7. Create user account

For local development it is best to create your own user and assign the administrator persona.

```sh
drush user:create yourusername --mail="email@numiko.com" --password="insert password"
```

This will output the user ID for the newly created user. Replace X in the next command with the User ID.

```sh
drush eval "Drupal\user\Entity\User::load(X)->set('personas', ['administrator'])->save();"
```

### 8. Index search

You need to update the search index to see search results.

```sh
drush search-api-reindex

drush search-api-index

```

## Moving branches

When ever you need to switch branches, once switched and have pulled the latest changes, run the install-local script This will run the FE build script also at [scripts/dev/build-fe](scripts/dev/build-fe)

`docker compose exec web ./scripts/dev/install-local`

## Hosting

### Platform.sh

If the project is being hosted on platform.sh everything required should already be in place, other than adding the platform.sh deploy key (`https://console.platform.sh/numiko-ltd/{project-id}/-/settings/deploykey`) to [front-end packages project](https://bitbucket.org/numiko/workspace/projects/FEP/settings/access-keys)

## XDebug

XDebug 3 is installed and running by default.

## Tests

### Functional existing site tests

This site uses existing site tests (requires site to be running in docker - as it uses ExisitngSiteBase see https://gitlab.com/weitzman/drupal-test-traits) and unit tests and can be run using:

```sh
docker compose exec web ./vendor/phpunit/phpunit/phpunit --configuration . --testsuite functional
```

### Functional javascript tests

FunctionalJavascript tests must also have setup a headless Chrome container paired with a Selenium hub as seen in this project's docker-compose.test.yml file. To run these, bring up your docker containers with the testing override configuration using the command below.

```sh
docker compose -f docker-compose.yml -f docker-compose.test.yml up -d
docker compose exec web ./vendor/phpunit/phpunit/phpunit --configuration . --testsuite functional-javascript
```

Sometimes, the FunctionalJavascript tests can fail with a StreamException error. Please try re-running the test if this occurs.
