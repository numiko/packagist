# Numiko Composer template for Drupal Project

## Quickstart

```
composer create-project numiko/drupal-9-composer-template:1.* PROJECT_NAME --stability dev --no-interaction --repository-url=https://numiko.github.io/packagist --ignore-platform-reqs  
cd <project directory>
cp ~/.ssh/key_for_bitbucket_repos docker/web/.env.key  
./scripts/dev/install-first-time  
```

You will now have a site running at [https://localhost:8081/](https://localhost:8081/).

## Background

This template is a fork of [Composer template for Drupal Projects](https://github.com/drupal-composer/drupal-project) with additional functionality specific to Numiko.

## Detailed usage

### Create the project

* `composer create-project numiko/drupal-9-composer-template:1.* PROJECT_NAME --stability dev --no-interaction --repository-url=https://numiko.github.io/packagist --ignore-platform-reqs
`

Where PROJECT_NAME is the folder to create the project in.

### Quick Environment & Docker Setup

Copy your key into the container context so that it can be accessed during the build, then run the setup script:

* `cp ~/.ssh/my_selected_key docker/web/.env.key`
  
Build and bring up the Docker containers, install Drupal using Drush (will ask a series of questions about the site), and then set correct permissions.

* `./scripts/dev/install-first-time`

## What does this template do

This template will:

* Drupal will be installed in the `docroot`-directory.
* Autoloader is implemented to use the generated composer autoloader in `vendor/autoload.php`,
  instead of the one provided by Drupal (`web/vendor/autoload.php`).
* Modules (packages of type `drupal-module`) will be placed in `docroot/modules/contrib/`
* Theme (packages of type `drupal-theme`) will be placed in `docroot/themes/contrib/`
* Profiles (packages of type `drupal-profile`) will be placed in `docroot/profiles/contrib/`
* Creates default writable versions of `settings.php` and `services.yml`.
* Creates `sites/default/files`-directory.
* Latest version of drush is installed locally for use at `vendor/bin/drush`.
* Latest version of DrupalConsole is installed locally for use at `vendor/bin/drupal`.
* Numiko install profiles added:
	* [Numiko D9 Profile](https://bitbucket.org/numiko/d9-profile)
* All dependencies of install profiles placed in appropriate directories

These files will then be ready for you to point the web server at and run the install process (selecting the profile best suited to the projects requirements).

For more information see [the original docs](https://github.com/drupal-composer/drupal-project).
