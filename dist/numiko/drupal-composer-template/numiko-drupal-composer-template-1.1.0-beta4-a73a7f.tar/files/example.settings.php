/**
 * Allow the toolbar tab to show in the admin theme.
 */
$config['toolbar.tab']['admin']['include'] = TRUE;

/**
 * Need to change the data attributes to parsley specific ones on webforms
 * for validation.
 *
 * @see https://www.drupal.org/project/clientside_validation/issues/2855356
 */
$config['clientside.validation']['rule_key'] = 'data-parsley-:rule';
$config['clientside.validation']['message_key'] = 'data-parsley-:rule-message';

/**
 * Load local development override configuration, if available.
 *
 * Use settings.local.php to override variables on secondary (staging,
 * development, etc) installations of this site. Typically used to disable
 * caching, JavaScript/CSS compression, re-routing of outgoing emails, and
 * other things that should not happen on development and testing sites.
 *
 * Keep this code block at the end of this file to take full effect.
 */

if (file_exists($app_root . '/' . $site_path . '/settings.local.php')) {
  include $app_root . '/' . $site_path . '/settings.local.php';
}

