<?php

namespace DrupalProject\composer;

use Composer\Script\Event;
use Drupal\Core\Site\Settings;
use Drupal\Core\Site\SettingsEditor;
use DrupalFinder\DrupalFinder;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Filesystem\Path;

class ScriptHandler {
  const DRUPAL_CORE_FOLDER = 'core';
  const DRUPAL_MODULES_FOLDER = 'modules';

  const DOCUMENTATION_FILE_PERMISSIONS = 0600;
  const SCRIPTS_FILE_PERMISSIONS = 0755;

  public static function createRequiredFiles(Event $event): void {
    $fs = new Filesystem();
    $drupalFinder = new DrupalFinder();
    $drupalFinder->locateRoot(getcwd());
    $drupalRoot = $drupalFinder->getDrupalRoot();

    $dirs = [
      'modules',
      'profiles',
      'themes',
    ];

    // Required for unit testing.
    foreach ($dirs as $dir) {
      if (!$fs->exists($drupalRoot . '/' . $dir)) {
        $fs->mkdir($drupalRoot . '/' . $dir);
        $fs->touch($drupalRoot . '/' . $dir . '/.gitkeep');
      }
    }

    // Prepare the settings file for installation.
    if (!$fs->exists($drupalRoot . '/sites/default/settings.php') && $fs->exists($drupalRoot . '/sites/default/default.settings.php')) {
      $fs->copy($drupalRoot . '/sites/default/default.settings.php', $drupalRoot . '/sites/default/settings.php');
      require_once $drupalRoot . '/core/includes/bootstrap.inc';
      require_once $drupalRoot . '/core/includes/install.inc';
      new Settings([]);
      $settings['settings']['config_sync_directory'] = (object) [
        'value' => Path::makeRelative($drupalFinder->getComposerRoot() . '/config/sync', $drupalRoot),
        'required' => TRUE,
      ];
      SettingsEditor::rewrite($drupalRoot . '/sites/default/settings.php', $settings);
      $fs->chmod($drupalRoot . '/sites/default/settings.php', 0666);
      $event->getIO()->write("Created a sites/default/settings.php file with chmod 0666");
    }

    // Create the files directory with chmod 0777.
    if (!$fs->exists($drupalRoot . '/sites/default/files')) {
      $oldmask = umask(0);
      $fs->mkdir($drupalRoot . '/sites/default/files', 0777);
      umask($oldmask);
      $event->getIO()->write("Created a sites/default/files directory with chmod 0777");
    }
  }

  public static function denyAccessToDocumentationFiles(Event $event): void {
    $fs = new Filesystem();
    $drupalFinder = new DrupalFinder();
    $drupalFinder->locateRoot(getcwd());
    $drupalRoot = $drupalFinder->getDrupalRoot();

    $folders = [static::DRUPAL_CORE_FOLDER, static::DRUPAL_MODULES_FOLDER];
    $extensions = ['txt', 'md', 'markdown'];

    foreach ($folders as $folder) {
      foreach ($extensions as $extension) {
        foreach (static::findFiles($drupalRoot . '/' . $folder . '/*.' . $extension) as $filename) {
          try {
            $fs->chmod($filename, static::DOCUMENTATION_FILE_PERMISSIONS);
          }
          catch (IOExceptionInterface $e) {
            if (substr(sprintf('%o', fileperms($e->getPath())), -1) > 0) {
              $errors[] = $e->getPath();
            }
          }
        }
      }
    }

    if (!empty($errors)) {
      $event->getIO()->write("Unable to deny access to the following documentation file(s):");
      foreach ($errors as $errorPath) {
        $event->getIO()->write($errorPath);
      }
    }
  }

  protected static function findFiles(string $pattern, int $flags = 0): array {
    $files = glob($pattern, $flags);
    foreach (glob(dirname($pattern) . '/*', GLOB_ONLYDIR | GLOB_NOSORT) as $dir) {
      $files = array_merge($files, static::findFiles($dir . '/' . basename($pattern), $flags));
    }
    return $files;
  }

  /**
   * Allow the site kit start-up scripts to be executed.
   */
  public static function setScriptPermissionsOnProjectCreate(Event $event): void {
    $fs = new Filesystem();

    // Prepare the create project scripts permissions.
    if ($fs->exists('scripts/dev/install-site-kit') && $fs->exists('scripts/dev/build-fe')) {
      $fs->chmod('scripts/dev/install-site-kit', self::SCRIPTS_FILE_PERMISSIONS);
      $fs->chmod('scripts/dev/build-fe', self::SCRIPTS_FILE_PERMISSIONS);
      $event->getIO()->write("Update site kit script permissions");
    }
  }

}
