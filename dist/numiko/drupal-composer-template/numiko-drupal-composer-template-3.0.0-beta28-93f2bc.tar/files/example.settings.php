
/**
 * Allow the toolbar tab to show in the admin theme.
 */
$config['toolbar.tab']['admin']['include'] = TRUE;

/**
 * Load local development override configuration, if available.
 */
if (file_exists($app_root . '/' . $site_path . '/settings.local.php')) {
  include $app_root . '/' . $site_path . '/settings.local.php';
}

/**
 * Load platform override configuration, if available.
 */
if (file_exists($app_root . '/' . $site_path . '/settings.platformsh.php')) {
  include $app_root . '/' . $site_path . '/settings.platformsh.php';
}
