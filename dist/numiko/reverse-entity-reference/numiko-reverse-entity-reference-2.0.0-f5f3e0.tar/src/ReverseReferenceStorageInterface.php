<?php

namespace Drupal\reverse_entity_reference;

/**
 * Defines the Reverse Reference storage.
 */
interface ReverseReferenceStorageInterface {

  /**
   * Find reverse references for the given field.
   *
   * @return \Drupal\reverse_entity_reference\ReverseReferenceInterface[]
   */
  public function loadByParentField(string $field): array;

  /**
   * Load an individual reverse reference based on field and bundle.
   */
  public function loadByFieldBundle(string $field, string $bundle, string $entityType): ?ReverseReferenceInterface;

  /**
   * Load all reverse references based on a bundle.
   *
   * @return \Drupal\reverse_entity_reference\ReverseReferenceInterface[]
   */
  public function loadByBundle(string $bundle, string $entityType): array;

}
