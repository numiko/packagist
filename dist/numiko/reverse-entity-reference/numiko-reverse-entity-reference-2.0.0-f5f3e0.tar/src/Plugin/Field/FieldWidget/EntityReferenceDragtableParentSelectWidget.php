<?php

namespace Drupal\reverse_entity_reference\Plugin\Field\FieldWidget;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\Attribute\FieldWidget;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\Plugin\Field\FieldWidget\OptionsSelectWidget;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\StringTranslation\TranslationInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Plugin implementation of 'entity_reference_dragtable_parent_select'.
 */
#[FieldWidget(
  id: 'entity_reference_dragtable_parent_select',
  label: new TranslatableMarkup('Entity Reference Dragtable Parent Select'),
  field_types: ['entity_reference']
)]
class EntityReferenceDragtableParentSelectWidget extends OptionsSelectWidget implements ContainerFactoryPluginInterface {
  use StringTranslationTrait;

  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $static = new static($plugin_id, $plugin_definition, $configuration['field_definition'], $configuration['settings'], $configuration['third_party_settings']);
    $static->entityTypeManager = $container->get(EntityTypeManagerInterface::class);
    $static->stringTranslation = $container->get(TranslationInterface::class);
    return $static;
  }

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $formState) {
    $entity = $formState->getformObject()->getEntity();
    /** @var \Drupal\reverse_entity_reference\ReverseReferenceStorageInterface $reverseReferenceStorage */
    $reverseReferenceStorage = $this->entityTypeManager->getStorage('reverse_reference');
    $reverseReference = $reverseReferenceStorage->loadByFieldBundle($items->getName(), $entity->bundle(), $entity->getEntityTypeId());
    if (!$reverseReference) {
      return $element;
    }

    $element['value'] = parent::formElement($items, $delta, $element, $form, $formState);

    $element['#attached']['library'][] = 'core/drupal.ajax';
    $element['#attached']['library'][] = 'core/drupal.tabledrag';

    $element['value']['#ajax'] = [
      'callback' => [$this, 'weightsTableUpdate'],
      'wrapper' => 'edit-weights-wrapper',
      'event' => 'change',
    ];

    $element['parent_child_weights']['table'] = [
      '#type' => 'table',
      '#header' => [
        'name' => $this->t('Name'),
        'weight' => $this->t('Weight'),
      ],
      '#prefix' => '<div id="edit-weights-wrapper">',
      '#suffix' => '</div>',
      '#id' => 'weights-order',
      '#empty' => $this->t('No pages found'),
      '#tabledrag' => [
        [
          'action' => 'order',
          'relationship' => 'sibling',
          'group' => 'item-weight',
        ],
      ],
    ];

    // Get the options list in alphabetically order.
    if (!empty($element['value']['#options'])) {
      asort($element['value']['#options'], SORT_STRING | SORT_FLAG_CASE);
    }

    $userInput = $formState->getUserInput();
    $value = (!empty($userInput[$items->getName()][0]['value'])) ? $userInput[$items->getName()][0]['value'] : $element['value']['#default_value'][0] ?? NULL;
    if (!empty($value) && $value != "_none") {
      $currentId = ($entity->isNew()) ? 0 : $entity->id();
      $parent = $this->entityTypeManager->getStorage('node')->load($value);
      $children = ($parent) ? $reverseReference->getChildren($parent) : [];

      $currentExists = FALSE;
      $delta = 0;
      $maxDelta = count($children) + 2;
      foreach ($children as $delta => $child) {
        $id = $child->id();
        $label = $child->label();
        if ($id === $currentId) {
          $currentExists = TRUE;
          $label = "<strong>{$label}</strong>";
        }
        $element['parent_child_weights']['table'][$id] = [
          '#attributes' => ['class' => ['draggable']],
          '#weight' => $delta,
          'name' => ['#markup' => $label],
          'weight' => [
            '#type' => 'weight',
            '#title' => $this->t('Weight'),
            '#default_value' => $delta,
            '#delta' => $maxDelta,
            '#title_display' => 'invisible',
            '#attributes' => ['class' => ['item-weight']],
          ],
        ];
        $element['parent_child_previous_weights'][$id] = [
          '#type' => 'hidden',
          '#value' => $delta,
        ];
      }
      if (!$currentExists) {
        $label = $userInput['title'][0]['value'] ?? $entity->label() ?? 'Current page';
        $element['parent_child_weights']['table'][$currentId] = [
          '#attributes' => ['class' => ['draggable']],
          '#weight' => $delta + 1,
          'name' => ['#markup' => "<strong>{$label}</strong>"],
          'weight' => [
            '#type' => 'weight',
            '#title' => $this->t('Weight'),
            '#default_value' => $delta,
            '#delta' => $maxDelta,
            '#title_display' => 'invisible',
            '#attributes' => ['class' => ['item-weight']],
          ],
        ];
      }
    }

    return $element;
  }

  /**
   * Ajax function to update the weights table.
   */
  public static function weightsTableUpdate(array $form, FormStateInterface $formState) {
    $parents = $formState->getTriggeringElement()['#parents'];
    return $form[$parents[0]]['widget'][0]['parent_child_weights']['table'];
  }

}
