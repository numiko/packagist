<?php

namespace Drupal\reverse_entity_reference;

use Drupal\Core\Config\Entity\ConfigEntityStorage;

/**
 * Defines the Reverse Reference storage.
 */
class ReverseReferenceStorage extends ConfigEntityStorage implements ReverseReferenceStorageInterface {

  /**
   * {@inheritDoc}
   */
  public function loadByParentField(string $field): array {
    return $this->loadByProperties(['status' => 1, 'parent_field' => $field]);
  }

  /**
   * {@inheritDoc}
   */
  public function loadByFieldBundle(string $field, string $bundle): ?ReverseReferenceInterface {
    $results = array_filter($this->loadByParentField($field), fn ($reverseReference) => $reverseReference->isValidForBundle($bundle));
    if ($results) {
      return current($results);
    }
    return NULL;
  }

  /**
   * {@inheritDoc}
   */
  public function loadByBundle(string $bundle): array {
    /** @var \Drupal\reverse_entity_reference\ReverseReferenceInterface[] */
    $multiple = $this->loadMultiple();
    return array_filter($multiple, fn ($reverseReference) => $reverseReference->isValidForBundle($bundle));
  }

}
