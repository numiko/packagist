<?php

namespace Drupal\reverse_entity_reference\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;
use Drupal\Core\Entity\Attribute\ConfigEntityType;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityDeleteForm;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\reverse_entity_reference\Form\ReverseReferenceForm;
use Drupal\reverse_entity_reference\ReverseReferenceInterface;
use Drupal\reverse_entity_reference\ReverseReferenceListBuilder;
use Drupal\reverse_entity_reference\ReverseReferenceStorage;

/**
 * Defines the reverse reference entity type.
 */
#[ConfigEntityType(
  id: 'reverse_reference',
  label: new TranslatableMarkup('Reverse Reference'),
  label_collection: new TranslatableMarkup('Reverse References'),
  label_singular: new TranslatableMarkup('reverse reference'),
  label_plural: new TranslatableMarkup('reverse references'),
  label_count: [
    'singular' => '@count reverse reference',
    'plural' => '@count reverse references',
  ],
  handlers: [
    'list_builder' => ReverseReferenceListBuilder::class,
    'storage' => ReverseReferenceStorage::class,
    'form' => [
      'add' => ReverseReferenceForm::class,
      'edit' => ReverseReferenceForm::class,
      'delete' => EntityDeleteForm::class,
    ],
  ],
  config_prefix: 'reverse_reference',
  admin_permission: 'administer reverse_reference',
  links: [
    'collection' => '/admin/structure/reverse-reference',
    'add-form' => '/admin/structure/reverse-reference/add',
    'edit-form' => '/admin/structure/reverse-reference/{reverse_reference}',
    'delete-form' => '/admin/structure/reverse-reference/{reverse_reference}/delete',
  ],
  entity_keys: [
    'id' => 'id',
    'label' => 'label',
    'uuid' => 'uuid',
  ],
  config_export: [
    'id',
    'label',
    'status',
    'child_field',
    'parent_field',
    'delta_field',
    'bundles',
  ]
)]
class ReverseReference extends ConfigEntityBase implements ReverseReferenceInterface {

  /**
   * The reverse reference ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The reverse reference label.
   *
   * @var string
   */
  protected $label;

  /**
   * The reverse reference status.
   *
   * @var bool
   */
  protected $status;

  /**
   * The child field on the parent node.
   *
   * @var string
   */
  public $child_field;

  /**
   * The parent field on the child node.
   *
   * @var string
   */
  public $parent_field;

  /**
   * The temporary delta field on the child node.
   *
   * @var string
   */
  public $delta_field;

  /**
   * The corresponding bundles keyed by entity type.
   *
   * Example:
   *   [
   *     'node' => ['article', 'page'],
   *     'commerce_product' => ['default']
   *   ]
   *
   * @var array
   */
  public $bundles;

  /**
   * {@inheritdoc}
   */
  public function getLabel(): ?string {
    return $this->label;
  }

  /**
   * {@inheritdoc}
   */
  public function setLabel(string $label): self {
    $this->label = $label;

    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getChildField(): ?string {
    return $this->child_field;
  }

  /**
   * {@inheritdoc}
   */
  public function setChildField(string $childField): self {
    $this->child_field = $childField;
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getParentField(): ?string {
    return $this->parent_field;
  }

  /**
   * {@inheritdoc}
   */
  public function setParentField(string $parentField): self {
    $this->parent_field = $parentField;
    return $this;
  }

  /**
   * {@inheritDoc}
   */
  public function getChildren(ContentEntityInterface $parent): array {
    if ($parent->hasField($this->getChildField()) && !$parent->get($this->getChildField())->isEmpty()) {
      return $parent->get($this->getChildField())->referencedEntities();
    }
    return [];
  }

  /**
   * {@inheritDoc}
   */
  public function getParent(ContentEntityInterface $child): ?EntityInterface {
    if ($child->hasField($this->getParentField()) && !$child->get($this->getParentField())->isEmpty()) {
      $parentEntities = $child->get($this->getParentField())->referencedEntities();
      if ($parentEntities) {
        return current($parentEntities);
      }
    }
    return NULL;
  }

  /**
   * {@inheritDoc}
   */
  public function hasParentFieldChange(ContentEntityInterface $previousVersionChild, ContentEntityInterface $child): bool {
    $previousVersionParent = $previousVersionChild->get($this->getParentField());
    $currentVersionParent = $child->get($this->getParentField());
    return (!$currentVersionParent->equals($previousVersionParent));
  }

  /**
   * {@inheritDoc}
   */
  public function removeChildFromParent(ContentEntityInterface $parent, ContentEntityInterface $child): void {
    $values = array_filter(
      $parent->get($this->getChildField())->getValue(),
      fn ($value) => $value['target_id'] !== $child->id()
    );
    $parent->set($this->getChildField(), $values);
  }

  /**
   * {@inheritdoc}
   */
  public function getDeltaField(): ?string {
    return $this->delta_field;
  }

  /**
   * {@inheritdoc}
   */
  public function setDeltaField(string $deltaField): self {
    $this->delta_field = $deltaField;
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getDelta(ContentEntityInterface $child): string|false {
    if ($child->hasField($this->getDeltaField()) && !$child->get($this->getDeltaField())->isEmpty()) {
      return $child->get($this->getDeltaField())->getString();
    }
    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function updateParentDelta(ContentEntityInterface $parent, ContentEntityInterface $child, int $delta): void {
    $values = $parent->get($this->getChildField())->getValue();
    array_splice($values, $delta, 0, [['target_id' => $child->id()]]);
    $parent->set($this->getChildField(), $values);
  }

  /**
   * {@inheritdoc}
   */
  public function getBundles(): array {
    return $this->bundles ?? [];
  }

  /**
   * {@inheritdoc}
   */
  public function isValidForBundle(string $bundle): bool {
    foreach ($this->bundles as $bundles) {
      if (in_array($bundle, $bundles)) {
        return TRUE;
      }
    }
    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function setBundles(array $bundles): self {
    $this->bundles = $bundles;
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function isEnabled(): bool {
    return $this->status;
  }

  /**
   * {@inheritdoc}
   */
  public function setEnabled(bool $enabled): self {
    $this->status = $enabled;
    return $this;
  }

}
