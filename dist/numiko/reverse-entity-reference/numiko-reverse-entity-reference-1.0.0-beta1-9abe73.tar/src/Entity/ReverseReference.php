<?php

namespace Drupal\reverse_entity_reference\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\reverse_entity_reference\ReverseReferenceInterface;

/**
 * Defines the reverse reference entity type.
 *
 * @ConfigEntityType(
 *   id = "reverse_reference",
 *   label = @Translation("Reverse Reference"),
 *   label_collection = @Translation("Reverse References"),
 *   label_singular = @Translation("reverse reference"),
 *   label_plural = @Translation("reverse references"),
 *   label_count = @PluralTranslation(
 *     singular = "@count reverse reference",
 *     plural = "@count reverse references",
 *   ),
 *   handlers = {
 *     "list_builder" = "Drupal\reverse_entity_reference\ReverseReferenceListBuilder",
 *     "storage" = "Drupal\reverse_entity_reference\ReverseReferenceStorage",
 *     "form" = {
 *       "add" = "Drupal\reverse_entity_reference\Form\ReverseReferenceForm",
 *       "edit" = "Drupal\reverse_entity_reference\Form\ReverseReferenceForm",
 *       "delete" = "Drupal\Core\Entity\EntityDeleteForm"
 *     }
 *   },
 *   config_prefix = "reverse_reference",
 *   admin_permission = "administer reverse_reference",
 *   links = {
 *     "collection" = "/admin/structure/reverse-reference",
 *     "add-form" = "/admin/structure/reverse-reference/add",
 *     "edit-form" = "/admin/structure/reverse-reference/{reverse_reference}",
 *     "delete-form" = "/admin/structure/reverse-reference/{reverse_reference}/delete"
 *   },
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid"
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "status",
 *     "child_field",
 *     "parent_field",
 *     "delta_field",
 *     "bundles"
 *   }
 * )
 */
class ReverseReference extends ConfigEntityBase implements ReverseReferenceInterface {

  /**
   * The reverse reference ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The reverse reference label.
   *
   * @var string
   */
  protected $label;

  /**
   * The reverse reference status.
   *
   * @var bool
   */
  protected $status;

  /**
   * The child field on the parent node.
   *
   * @var string
   */
  public $child_field;

  /**
   * The parent field on the child node.
   *
   * @var string
   */
  public $parent_field;

  /**
   * The temporary delta field on the child node.
   *
   * @var string
   */
  public $delta_field;

  /**
   * The corresponding bundles keyed by entity type.
   *
   * Example:
   *   [
   *     'node' => ['article', 'page'],
   *     'commerce_product' => ['default']
   *   ]
   *
   * @var array
   */
  public $bundles;

  /**
   * {@inheritdoc}
   */
  public function getLabel() {
    return $this->label;
  }

  /**
   * {@inheritdoc}
   */
  public function setLabel($label) {
    $this->label = $label;

    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getChildField() {
    return $this->child_field;
  }

  /**
   * {@inheritdoc}
   */
  public function setChildField($childField) {
    $this->child_field = $childField;

    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getParentField() {
    return $this->parent_field;
  }

  /**
   * {@inheritdoc}
   */
  public function setParentField($parentField) {
    $this->parent_field = $parentField;

    return $this;
  }

  /**
   * Use the child field on the entity to get the child entities.
   *
   * Provided the parent entity the function will return an array of child
   * entities using the reverse reference child field.
   */
  public function getChildren(ContentEntityInterface $parent) : array {
    if ($parent->hasField($this->getChildField()) && !$parent->get($this->getChildField())->isEmpty()) {
      return $parent->get($this->getChildField())->referencedEntities();
    }
    return [];
  }

  /**
   * Use the parent field on the entity to get the child entities.
   *
   * Provided the parent entity the function will return an array of child
   * entities using the reverse reference child field.
   */
  public function getParent(ContentEntityInterface $child) : ?EntityInterface {
    if ($child->hasField($this->getParentField()) && !$child->get($this->getParentField())->isEmpty()) {
      $parentEntities = $child->get($this->getParentField())->referencedEntities();
      if ($parentEntities) {
        return current($parentEntities);
      }
    }
    return NULL;
  }

  /**
   * Check for parent field changes on the child.
   *
   * Check if the current version of the parent field on the child is the
   * same as the previous version.
   */
  public function hasParentFieldChange(ContentEntityInterface $previousVersionChild, ContentEntityInterface $child) {
    $previousVersionParent = $previousVersionChild->get($this->getParentField());
    $currentVersionParent = $child->get($this->getParentField());
    return (!$currentVersionParent->equals($previousVersionParent));
  }

  /**
   * Remove the child page from the parent.
   */
  public function removeChildFromParent(ContentEntityInterface $parent, ContentEntityInterface $child) {
    $values = array_filter($parent->get($this->getChildField())->getValue(), function ($value) use ($child) {
      return $value['target_id'] !== $child->id();
    });
    $parent->set($this->getChildField(), $values);
  }

  /**
   * {@inheritdoc}
   */
  public function getDeltaField() {
    return $this->delta_field;
  }

  /**
   * {@inheritdoc}
   */
  public function setDeltaField($deltaField) {
    $this->delta_field = $deltaField;

    return $this;
  }

  /**
   * Get the temporary delta for the child page.
   *
   * This is a weight, so must be compared with FALSE.
   */
  public function getDelta(ContentEntityInterface $child) {
    if ($child->hasField($this->getDeltaField()) && !$child->get($this->getDeltaField())->isEmpty()) {
      return $child->get($this->getDeltaField())->getString();
    }
    return FALSE;
  }

  /**
   * Update the parent delta for the child page.
   */
  public function updateParentDelta(ContentEntityInterface $parent, ContentEntityInterface $child, int $delta) {
    $values = $parent->get($this->getChildField())->getValue();
    array_splice($values, $delta, 0, [['target_id' => $child->id()]]);
    $parent->set($this->getChildField(), $values);
  }

  /**
   * {@inheritdoc}
   */
  public function getBundles() {
    return $this->bundles;
  }

  /**
   * {@inheritdoc}
   */
  public function isValidForBundle(string $bundle) {
    foreach ($this->bundles as $bundles) {
      if (in_array($bundle, $bundles)) {
        return TRUE;
      }
    }
    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function setBundles(array $bundles) {
    $this->bundles = $bundles;

    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function isEnabled() {
    return $this->status;
  }

  /**
   * {@inheritdoc}
   */
  public function setEnabled($enabled) {
    $this->status = $enabled;

    return $this;
  }

}
