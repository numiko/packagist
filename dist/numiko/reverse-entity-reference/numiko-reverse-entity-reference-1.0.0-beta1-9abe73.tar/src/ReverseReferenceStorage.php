<?php

namespace Drupal\reverse_entity_reference;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Config\Entity\ConfigEntityStorage;

/**
 * Defines the Reverse Reference storage.
 */
class ReverseReferenceStorage extends ConfigEntityStorage implements ReverseReferenceStorageInterface {

  /**
   * {@inheritDoc}
   */
  public function loadByParentField(string $field) : array {
    $query = $this->getQuery()
      ->condition('status', 1)
      ->condition('parent_field', $field);

    $result = $query->execute();

    if (empty($result)) {
      return [];
    }

    return $this->loadMultiple($result);
  }

  /**
   * {@inheritDoc}
   */
  public function loadByFieldBundle(string $field, string $bundle) : ?EntityInterface {
    $results = array_filter($this->loadByParentField($field), function ($reverseReference) use ($bundle) {
      return $reverseReference->isValidForBundle($bundle);
    });
    if ($results) {
      return current($results);
    }
    return NULL;
  }

  /**
   * {@inheritDoc}
   */
  public function loadByBundle(string $bundle) : array {
    return array_filter($this->loadMultiple(), function ($reverseReference) use ($bundle) {
      return $reverseReference->isValidForBundle($bundle);
    });
  }

}
