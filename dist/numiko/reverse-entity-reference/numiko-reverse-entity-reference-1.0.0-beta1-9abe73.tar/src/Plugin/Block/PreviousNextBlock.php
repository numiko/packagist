<?php

namespace Drupal\reverse_entity_reference\Plugin\Block;

use Drupal\Core\Cache\Cache;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\reverse_entity_reference\Entity\ReverseReference;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\reverse_entity_reference\ReverseReferenceStorageInterface;

/**
 * Provides a block that displays the previous and next items in the list.
 *
 * @Block(
 *   id = "previous_next_block",
 *   admin_label = @Translation("Previous Next Block"),
 *   category = @Translation("Reverse Entity Reference"),
 *   context_definitions = {
 *     "node" = @ContextDefinition("entity:node", label = @Translation("Node")),
 *   }
 * )
 */
class PreviousNextBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * The reverse reference manager service.
   *
   * @var \Drupal\reverse_entity_reference\ReverseReferenceStorageInterface
   */
  protected $reverseReferenceStorage;

  /**
   * Constructs a new PreviousNextBlock instance.
   *
   * @param array $configuration
   *   The block configuration.
   * @param string $pluginId
   *   The plugin ID for the block.
   * @param mixed $pluginDefinition
   *   The plugin definition for the block.
   * @param \Drupal\Core\Routing\RouteMatchInterface $routeMatch
   *   The route match service.
   * @param \Drupal\reverse_entity_reference\ReverseReferenceStorageInterface $reverseReferenceStorage
   *   The reverse reference manager service.
   */
  public function __construct(array $configuration, $pluginId, $pluginDefinition, ReverseReferenceStorageInterface $reverseReferenceStorage) {
    parent::__construct($configuration, $pluginId, $pluginDefinition);
    $this->reverseReferenceStorage = $reverseReferenceStorage;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $pluginId, $pluginDefinition) {
    return new static(
      $configuration,
      $pluginId,
      $pluginDefinition,
      $container->get('entity_type.manager')->getStorage('reverse_reference')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $block = [];
    $node = $this->getContextValue('node');
    if (!($node instanceof ContentEntityInterface)) {
      return $block;
    }
    $reverseReference = $this->getReverseReference($node);
    if (!$reverseReference) {
      return $block;
    }

    // Get the parent entity using the getParent method.
    $parentEntity = $reverseReference->getParent($node);
    if ($parentEntity) {
      $children = [];
      foreach ($reverseReference->getChildren($parentEntity) as $entity) {
        // Ensure the children are limited to those accessible.
        if ($entity->access('view')) {
          $children[] = $entity;
        }
      }

      // Find the next and previous items in the entity reference list.
      $currentItemKey = array_search($node, $children, TRUE);

      $previousItem = NULL;
      if (($currentItemKey !== FALSE) && $currentItemKey > 0) {
        $previousItem = [
          'id' => $children[$currentItemKey - 1]->id(),
          'label' => $children[$currentItemKey - 1]->label(),
          'field_teaser_summary' => $children[$currentItemKey - 1]->field_teaser_summary->view('teaser'),
        ];
      }

      $nextItem = NULL;
      if (($currentItemKey !== FALSE) && $currentItemKey < count($children) - 1) {
        $nextItem = [
          'id' => $children[$currentItemKey + 1]->id(),
          'label' => $children[$currentItemKey + 1]->label(),
          'field_teaser_summary' => $children[$currentItemKey + 1]->field_teaser_summary->view('teaser'),
        ];
      }

      if ($previousItem || $nextItem) {
        $block['content'] = [
          '#theme' => 'previous_next_block',
          '#parent' => $parentEntity,
          '#previousItem' => $previousItem,
          '#nextItem' => $nextItem,
        ];
      }
    }

    return $block;
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheTags() {
    $cacheTags = ['block:previous_next_block'];
    $node = $this->getContextValue('node');
    if ($node) {
      $reverseReferences = $this->reverseReferenceStorage->loadByBundle($node->bundle());
      if ($reverseReferences) {
        $reverseReference = current($reverseReferences);
        // Get the parent entity using the getParent method.
        $parentEntity = $reverseReference->getParent($node);
        if ($parentEntity) {
          // Set a specific cache tag which will be invalidated when the
          // parent is updated.
          $cacheTags[] = 'reverse_parent:' . $parentEntity->id();
        }
      }
    }
    return Cache::mergeTags(parent::getCacheTags(), $cacheTags);
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts() {
    return Cache::mergeContexts(parent::getCacheContexts(), ['url']);
  }

  protected function getReverseReference(EntityInterface $node) : ?ReverseReference {
    $reverseReferences = $this->reverseReferenceStorage->loadByBundle($node->bundle());
    if ($reverseReferences) {
      return current($reverseReferences);
    }
  }
}
