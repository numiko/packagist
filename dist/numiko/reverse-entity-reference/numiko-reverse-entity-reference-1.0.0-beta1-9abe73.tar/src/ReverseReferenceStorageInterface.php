<?php

namespace Drupal\reverse_entity_reference;

use Drupal\Core\Entity\EntityInterface;

/**
 * Defines the Reverse Reference storage.
 */
interface ReverseReferenceStorageInterface {

  /**
   * Find reverse references for the given field.
   */
  public function loadByParentField(string $field);

  /**
   * Load an individual reverse reference based on field and bundle.
   */
  public function loadByFieldBundle(string $field, string $bundle) : ?EntityInterface;

  /**
   * Load all reverse references based on a bundle.
   */
  public function loadByBundle(string $bundle) : array;

}
