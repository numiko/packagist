<?php

namespace Drupal\reverse_entity_reference;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface defining a reverse reference entity type.
 */
interface ReverseReferenceInterface extends ConfigEntityInterface {

}
