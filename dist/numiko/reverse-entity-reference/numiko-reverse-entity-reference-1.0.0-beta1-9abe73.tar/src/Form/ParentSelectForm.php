<?php

namespace Drupal\reverse_entity_reference\Form;

use Drupal\Core\Cache\Cache;
use Drupal\Core\Form\FormStateInterface;

/**
 * Custom form functionality for handling child parent widgets.
 */
class ParentSelectForm {

  /**
   * Validate that the parents child order has not changed while editing.
   */
  public static function validateParentChildOrder(array &$form, FormStateInterface $formState) {
    /** @var Drupal\Core\Entity\EntityTypeManagerInterface */
    $entityTypeManager = \Drupal::entityTypeManager();
    $formState->setTemporaryValue('entity_validated', TRUE);
    $entity = $formState->getFormObject()->getEntity();
    $reverseReferences = $entityTypeManager->getStorage('reverse_reference')->loadByBundle($entity->bundle());
    if (!$reverseReferences) {
      return;
    }
    foreach ($reverseReferences as $reverseReference) {
      $values = $formState->getValue($reverseReference->getParentField());
      if (empty($values[0]['value'][0]['target_id'])) {
        continue;
      }
      /** @var \Drupal\Core\Entity\ContentEntityInterface */
      $parent = $entityTypeManager->getStorage('node')->load($values[0]['value'][0]['target_id']);
      if (!$parent) {
        continue;
      }

      $formPreviousWeights = $values[0]['parent_child_previous_weights'] ?? [];
      $storedWeights = $parent->get($reverseReference->getChildField());
      foreach ($storedWeights as $delta => $currentNode) {
        if ($delta !== $formPreviousWeights[$currentNode->getValue()['target_id']]) {
          $formState->setErrorByName($reverseReference->getParentField(), "The page order has either been modified by another user, or you have already submitted modifications. As a result, your changes cannot be saved.");
        }
      }
    }
  }

  /**
   * Use the composite form field to update the child order on the parent.
   *
   * Extract the weight values from the table part of the form element
   * and update the child values oon the parent node, then update the value
   * of the field with the selected parent node.
   */
  public static function updateParentChildOrder(array &$form, FormStateInterface $formState) {
    /** @var Drupal\Core\Entity\EntityTypeManagerInterface */
    $entityTypeManager = \Drupal::entityTypeManager();
    /** @var \Drupal\Core\Entity\ContentEntityInterface */
    $entity = $formState->getFormObject()->getEntity();
    $reverseReferences = $entityTypeManager->getStorage('reverse_reference')->loadByBundle($entity->bundle());
    if (!$reverseReferences) {
      return;
    }
    foreach ($reverseReferences as $reverseReference) {
      $values = $formState->getValue($reverseReference->getParentField());
      if (empty($values[0]['value'][0]['target_id'])) {
        continue;
      }
      /** @var \Drupal\Core\Entity\ContentEntityInterface */
      $parent = $entityTypeManager->getStorage('node')->load($values[0]['value'][0]['target_id']);
      if (!$parent) {
        continue;
      }

      $formState->unsetValue($reverseReference->getDeltaField());

      $parentChildValues = [];
      $delta = 0;
      $weights = $values[0]['parent_child_weights']['table'];
      uasort($weights, function ($a, $b) {
        return $a['weight'] <=> $b['weight'];
      });
      foreach ($weights as $key => $weight) {
        if ($key) {
          $parentChildValues[$delta] = ['target_id' => $key];
        }
        else {
          $formState->setValue($reverseReference->getDeltaField(), $delta);
        }
        $delta++;
      }

      $currentValues = $parent->get($reverseReference->getChildField())->getValue();
      if ($parentChildValues !== $currentValues) {
        $parent->set($reverseReference->getChildField(), $parentChildValues);
        $parent->save();
        Cache::invalidateTags(['reverse_parent:' . $parent->id()]);
      }

      $formState->setValue($reverseReference->getParentField(), [['target_id' => $parent->id()]]);
    }
  }

}
