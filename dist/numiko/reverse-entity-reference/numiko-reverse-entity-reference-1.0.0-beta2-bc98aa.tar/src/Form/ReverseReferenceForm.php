<?php

namespace Drupal\reverse_entity_reference\Form;

use Drupal\Core\DependencyInjection\AutowireTrait;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\EntityWithPluginCollectionInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Reverse Reference form.
 *
 * @property \Drupal\reverse_entity_reference\ReverseReferenceInterface $entity
 */
class ReverseReferenceForm extends EntityForm {
  use AutowireTrait;

  /**
   * Constructs a CorrespondingReferenceForm object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $fieldManager
   *   The entity field manager.
   */
  public function __construct(
    EntityTypeManagerInterface $entityTypeManager,
    protected EntityFieldManagerInterface $fieldManager,
  ) {
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state): array {
    $form = parent::form($form, $form_state);

    /** @var \Drupal\reverse_entity_reference\ReverseReferenceInterface $reverseReference */
    $reverseReference = $this->entity;

    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Label'),
      '#maxlength' => 255,
      '#default_value' => $reverseReference->label(),
      '#description' => $this->t('Label for the reverse reference.'),
      '#required' => TRUE,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $reverseReference->id(),
      '#machine_name' => [
        'exists' => '\Drupal\reverse_entity_reference\Entity\ReverseReference::load',
      ],
      '#disabled' => !$reverseReference->isNew(),
    ];

    $form['status'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enabled'),
      '#default_value' => $reverseReference->status(),
    ];

    $form['parent_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Parent field'),
      '#description' => $this->t('Select the parent field on the child entity.'),
      '#options' => $this->getFieldOptions(),
      '#default_value' => $reverseReference->getParentField(),
      '#required' => TRUE,
    ];

    $form['child_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Child field'),
      '#description' => $this->t('Select the child field on the parent entity.'),
      '#options' => $this->getFieldOptions(),
      '#default_value' => $reverseReference->getChildField(),
      '#required' => TRUE,
    ];

    $form['delta_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Delta field'),
      '#description' => $this->t('Select the temporary delta field on the child entity.'),
      '#options' => $this->getIntegerFieldOptions(),
      '#default_value' => $reverseReference->getDeltaField(),
      '#required' => TRUE,
    ];

    $form['bundles'] = [
      '#type' => 'select',
      '#title' => $this->t('Bundles'),
      '#description' => $this->t('Select the bundles which should correspond to one another when they have one of the corresponding fields.'),
      '#options' => $this->getBundleOptions(),
      '#multiple' => TRUE,
      '#default_value' => $this->getBundleValuesForForm($reverseReference->getBundles()),
    ];

    return $form;
  }

  /**
   * Gets a map of possible number fields.
   *
   * @return array
   *   The reference field map.
   */
  protected function getIntegerFieldMap(): array {
    return $this->fieldManager->getFieldMapByFieldType('integer');
  }

  /**
   * Gets an array of field options to populate in the form.
   *
   * @return array
   *   An array of field options.
   */
  protected function getIntegerFieldOptions(): array {
    $options = [];

    foreach ($this->getIntegerFieldMap() as $entityTypeFields) {
      foreach ($entityTypeFields as $fieldName => $field) {
        if (!preg_match('/^field_.*$/', $fieldName)) {
          continue;
        }

        $options[$fieldName] = $fieldName;
      }
    }

    return $options;
  }

  /**
   * Gets a map of possible reference fields.
   *
   * @return array
   *   The reference field map.
   */
  protected function getReferenceFieldMap(): array {
    return $this->fieldManager->getFieldMapByFieldType('entity_reference');
  }

  /**
   * Gets an array of field options to populate in the form.
   *
   * @return array
   *   An array of field options.
   */
  protected function getFieldOptions(): array {
    $options = [];

    foreach ($this->getReferenceFieldMap() as $entityTypeFields) {
      foreach ($entityTypeFields as $fieldName => $field) {
        if (!preg_match('/^field_.*$/', $fieldName)) {
          continue;
        }

        $options[$fieldName] = $fieldName;
      }
    }

    return $options;
  }

  /**
   * Gets an array of bundle options to populate in the form.
   *
   * @return array
   *   An array of bundle options.
   */
  protected function getBundleOptions(): array {
    $correspondingFields = [];

    $options = [];

    foreach ($this->getReferenceFieldMap() as $entityType => $entityTypeFields) {
      $includeType = FALSE;

      foreach ($entityTypeFields as $fieldName => $field) {
        if (!empty($correspondingFields) && !in_array($fieldName, $correspondingFields)) {
          continue;
        }

        if (!preg_match('/^field_.*$/', $fieldName)) {
          continue;
        }

        $includeType = TRUE;

        foreach ($field['bundles'] as $bundle) {
          $options["$entityType:$bundle"] = "$entityType: $bundle";
        }
      }

      if ($includeType) {
        $options["$entityType:*"] = "$entityType: *";
      }
    }

    ksort($options);

    return $options;
  }

  /**
   * Gets bundle options value in a format for use in the form.
   */
  protected function getBundleValuesForForm(?array $values = NULL): array {
    $formValues = [];

    if (!is_null($values)) {
      foreach ($values as $entityType => $bundles) {
        foreach ($bundles as $bundle) {
          $formValues[] = "$entityType:$bundle";
        }
      }
    }

    return $formValues;
  }

  /**
   * Gets bundle options value in a format for use in the config entity.
   */
  protected function getBundleValuesForEntity(?array $values = NULL): array {
    $entityValues = [];

    if (!is_null($values)) {
      foreach ($values as $value) {
        [$entityType, $bundle] = explode(':', $value);

        $entityValues[$entityType][] = $bundle;
      }
    }

    return $entityValues;
  }

  /**
   * Copies form values into the config entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The config entity.
   * @param array $form
   *   The form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state object.
   */
  protected function copyFormValuesToEntity(EntityInterface $entity, array $form, FormStateInterface $form_state): void {
    $values = $form_state->getValues();

    if ($this->entity instanceof EntityWithPluginCollectionInterface) {
      // Do not manually update values represented by plugin collections.
      $values = array_diff_key($values, $this->entity->getPluginCollections());
    }

    /** @var \Drupal\reverse_entity_reference\ReverseReferenceInterface $entity */
    $entity->set('id', $values['id']);
    $entity->set('label', $values['label']);
    $entity->set('child_field', $values['child_field']);
    $entity->set('parent_field', $values['parent_field']);
    $entity->set('delta_field', $values['delta_field']);
    $entity->set('bundles', $this->getBundleValuesForEntity($values['bundles']));
    $entity->set('status', $values['status']);
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $result = parent::save($form, $form_state);
    $message_args = ['%label' => $this->entity->label()];
    $message = $result == SAVED_NEW
      ? $this->t('Created new reverse reference %label.', $message_args)
      : $this->t('Updated reverse reference %label.', $message_args);
    $this->messenger()->addStatus($message);
    $form_state->setRedirectUrl($this->entity->toUrl('collection'));
    return $result;
  }

}
