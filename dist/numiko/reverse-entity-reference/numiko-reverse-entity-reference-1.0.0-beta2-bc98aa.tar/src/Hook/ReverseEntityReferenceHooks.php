<?php

namespace Drupal\reverse_entity_reference\Hook;

use Drupal\Core\Cache\Cache;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\reverse_entity_reference\Form\ParentSelectForm;

/**
 * Hook implementations for reverse_entity_reference.
 */
class ReverseEntityReferenceHooks {

  public function __construct(protected EntityTypeManagerInterface $entityTypeManager) {}

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'previous_next_block' => [
        'variables' => [
          'parent' => NULL,
          'previousItem' => NULL,
          'nextItem' => NULL,
        ],
      ],
    ];
  }

  /**
   * Implements hook_form_node_form_alter().
   */
  #[Hook('form_node_form_alter')]
  public function formNodeFormAlter(array &$form, FormStateInterface $form_state, mixed $form_id): void {
    /** @var \Drupal\Core\Entity\EntityForm $entityForm */
    $entityForm = $form_state->getFormObject();
    /** @var \Drupal\reverse_entity_reference\ReverseReferenceStorageInterface $reverseReferenceStorage */
    $reverseReferenceStorage = $this->entityTypeManager->getStorage('reverse_reference');
    $reverseReferences = $reverseReferenceStorage->loadByBundle($entityForm->getEntity()->bundle());

    if ($reverseReferences) {
      array_unshift($form['#validate'], [
        ParentSelectForm::class,
        'validateParentChildOrder',
      ]);
      array_unshift($form['actions']['submit']['#submit'], [
        ParentSelectForm::class,
        'updateParentChildOrder',
      ]);
    }
  }

  /**
   * Implements hook_entity_insert().
   */
  #[Hook('entity_insert')]
  public function entityInsert(EntityInterface $entity): void {
    /** @var \Drupal\reverse_entity_reference\ReverseReferenceStorageInterface $reverseReferenceStorage */
    $reverseReferenceStorage = $this->entityTypeManager->getStorage('reverse_reference');
    $reverseReferences = $reverseReferenceStorage->loadByBundle($entity->bundle());

    foreach ($reverseReferences as $reverseReference) {
      $delta = $reverseReference->getDelta($entity);
      if ($delta !== FALSE) {
        $parent = $reverseReference->getParent($entity);
        $reverseReference->updateParentDelta($parent, $entity, $delta);
        $parent->save();
        Cache::invalidateTags([
          'reverse_parent:' . $parent->id(),
        ]);
      }
    }
  }

  /**
   * Implements hook_entity_update().
   *
   * If the parent value of the entity has changed then remove the child
   * from the previous parent entity.
   */
  #[Hook('entity_update')]
  public function entityUpdate(EntityInterface $entity): void {
    if (!$entity instanceof ContentEntityInterface) {
      return;
    }

    /** @var \Drupal\reverse_entity_reference\ReverseReferenceStorageInterface $reverseReferenceStorage */
    $reverseReferenceStorage = $this->entityTypeManager->getStorage('reverse_reference');
    $reverseReferences = $reverseReferenceStorage->loadByBundle($entity->bundle());
    if (!$reverseReferences) {
      return;
    }

    foreach ($reverseReferences as $reverseReference) {
      $original = $entity->getOriginal();
      if ($reverseReference->hasParentFieldChange($original, $entity)) {
        $previousParent = $reverseReference->getParent($original);
        if ($previousParent) {
          $reverseReference->removeChildFromParent($previousParent, $original);
          $previousParent->save();
          Cache::invalidateTags([
            'reverse_parent:' . $previousParent->id(),
          ]);
        }
      }
    }
  }

  /**
   * Implements hook_entity_delete().
   *
   * If the entity is removed then remove it from the parent entity.
   */
  #[Hook('entity_delete')]
  public function entityDelete(EntityInterface $entity): void {
    if (!$entity instanceof ContentEntityInterface) {
      return;
    }
    /** @var \Drupal\reverse_entity_reference\ReverseReferenceStorageInterface $reverseReferenceStorage */
    $reverseReferenceStorage = $this->entityTypeManager->getStorage('reverse_reference');
    $reverseReferences = $reverseReferenceStorage->loadByBundle($entity->bundle());
    if (!$reverseReferences) {
      return;
    }

    foreach ($reverseReferences as $reverseReference) {
      $parent = $reverseReference->getParent($entity);
      if ($parent) {
        $reverseReference->removeChildFromParent($parent, $entity);
        $parent->save();
        Cache::invalidateTags([
          'reverse_parent:' . $parent->id(),
        ]);
      }
    }
  }

}
