<?php

namespace Drupal\reverse_entity_reference;

use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityInterface;

/**
 * Provides an interface defining a reverse reference entity type.
 */
interface ReverseReferenceInterface extends ConfigEntityInterface {

  /**
   * Get label.
   */
  public function getLabel(): ?string;

  /**
   * Set label.
   */
  public function setLabel(string $label): self;

  /**
   * Get child field.
   */
  public function getChildField(): ?string;

  /**
   * Set child field.
   */
  public function setChildField(string $childField): self;

  /**
   * Get parent field.
   */
  public function getParentField(): ?string;

  /**
   * Set parent field.
   */
  public function setParentField(string $parentField): self;

  /**
   * Get delta field.
   */
  public function getDeltaField(): ?string;

  /**
   * Set delta field.
   */
  public function setDeltaField(string $deltaField): self;

  /**
   * Get bundles.
   */
  public function getBundles(): array;

  /**
   * Set bundles.
   */
  public function setBundles(array $bundles): self;

  /**
   * Is this enabled?
   */
  public function isEnabled(): bool;

  /**
   * Set is enabled.
   */
  public function setEnabled(bool $enabled): self;

  /**
   * Use the child field on the entity to get the child entities.
   *
   * Provided the parent entity the function will return an array of child
   * entities using the reverse reference child field.
   */
  public function getChildren(ContentEntityInterface $parent): array;

  /**
   * Use the parent field on the entity to get the child entities.
   *
   * Provided the parent entity the function will return an array of child
   * entities using the reverse reference child field.
   */
  public function getParent(ContentEntityInterface $child): ?EntityInterface;

  /**
   * Check for parent field changes on the child.
   *
   * Check if the current version of the parent field on the child is the
   * same as the previous version.
   */
  public function hasParentFieldChange(ContentEntityInterface $previousVersionChild, ContentEntityInterface $child): bool;

  /**
   * Remove the child page from the parent.
   */
  public function removeChildFromParent(ContentEntityInterface $parent, ContentEntityInterface $child): void;

  /**
   * Get the temporary delta for the child page.
   *
   * This is a weight, so must be compared with FALSE.
   */
  public function getDelta(ContentEntityInterface $child): string|false;

  /**
   * Update the parent delta for the child page.
   */
  public function updateParentDelta(ContentEntityInterface $parent, ContentEntityInterface $child, int $delta): void;

  /**
   * Is valid for this bundle?
   */
  public function isValidForBundle(string $bundle): bool;

}
