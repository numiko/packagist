# Reverse Entity Reference

Inspired by the Corresponding Entity References (https://www.drupal.org/project/cer) module, this module allows for a one-to-many relationship.

This module provides tools to make managing the parent child relationship in a way similar to managing menus.

## Usage

* Create two entity types to act as parent / child
* Add an entity reference field on each referencing the opposing type (set the form widgets as defined below - these are intended for use in the details sidebar)
* Add an additional field to the child entity to store a number (this will be a temporary field and should be disabled from the entity form)
* Now create a reverse reference config entity setting all of the fields created above (/admin/structure/reverse_reference/add)
* Optionally you can now add the previous / next block to the child content type

## Widgets

The module provides two widgets one for the parent item - **Autocomplete (draggable table)** - which allows adding / removing items to be removed and instead provides a simple draggable interface for managing the child items order. This widget is lifted from the CER module and extended to allow adding / removing to be disabled.

The second is a bespoke widget - **Entity Reference Dragtable Parent Select** - this widget provides an interface similar to the Menu link weight module () and allows users to move content to its correct position in the entity reference field on the parent page.

## Blocks

The module provides a **Previous / next block** which shows the previous / next item based on the reverse reference entity associated with the current page.

The template for the block should be overridden by your theme.
