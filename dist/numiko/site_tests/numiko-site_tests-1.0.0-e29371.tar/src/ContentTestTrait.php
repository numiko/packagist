<?php

namespace Drupal\site_tests;

/**
 * Pre-populate expected content as part of the setup.
 */
trait ContentTestTrait {

  /**
   * Pre-populate the system site settings with home and error pages.
   *
   * The drupal site expects home and error pages to be populated with
   * existing nodes, so as part of the setup these are created.
   */
  protected function setUp(): void {
    parent::setUp();

    // The homepage is node 1 so a dummy homepage is
    // created to avoid nodes created in tests having their
    // URL alias generated as if they were the homepage
    // and therefore, incorrectly.
    $homePage = $this->createPublishedNode([
      'type' => 'page',
      'title' => 'Dummy home page',
    ]);
    $errorPage = $this->createPublishedNode([
      'type' => 'page',
      'title' => 'Dummy error page',
    ]);
    $siteConfig = \Drupal::configFactory()->getEditable('system.site');
    $siteConfig->set('page.front', '/node/' . $homePage->id());
    $siteConfig->set('page.403', '/node/' . $errorPage->id());
    $siteConfig->set('page.404', '/node/' . $errorPage->id());
    $siteConfig->save();
  }

}
