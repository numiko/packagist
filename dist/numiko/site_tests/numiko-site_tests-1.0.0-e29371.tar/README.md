# Site Tests

This module exists as the starting point for testing a site kit site.

The module is intended to be extended as the site is built; adding content types
personas, slices, and then tests for other functionality offered by the site.
