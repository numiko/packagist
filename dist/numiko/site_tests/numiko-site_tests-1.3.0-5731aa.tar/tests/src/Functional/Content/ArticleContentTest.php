<?php

namespace Drupal\Tests\site_tests\Functional\Content;

use Drupal\site_tests\ContentTestTrait;
use Drupal\taxonomy\Entity\Vocabulary;
use Symfony\Component\HttpFoundation\Response;
use Drupal\integration_tests\IntegrationTestBase;

/**
 * Test that content page content functions as expected.
 *
 * @group content
 * @group page-content
 */
class ArticleContentTest extends IntegrationTestBase {

  use ContentTestTrait;

  /**
   * Test creation of article page and view.
   */
  public function testArticleContentCreateEditView() {
    // Create category taxonomy.
    $category = $this->createTerm(Vocabulary::load('category'), ['name' => 'Test category']);

    // Login as editor.
    $this->createUserWithPersonaAndLogin(['editor']);

    // Check access to create form.
    $this->visitCheckCode('/node/add/article', Response::HTTP_OK);

    $node = $this->createNode([
      'type' => 'article',
      'title' => 'Test content title',
      'body' => 'Test body content',
      'field_publish_date' => '2023-12-19',
      'field_hero_media' => $this->getSampleImageMedia([], 'sample_image_hero.jpg')->id(),
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser summary',
      'field_category' => [
        'target_id' => $category->id(),
      ],
      'moderation_state' => 'draft',
    ]);

    // Ensure logged in users can access node while in draft.
    $this->visitCheckCode($node->toUrl(), Response::HTTP_OK);

    $this->markEntityForCleanup($node);

    // Check anonymous users cannot access the node whilst it's in draft.
    $this->drupalLogout();
    $this->visitCheckCode('/node/' . $node->id(), Response::HTTP_FORBIDDEN);

    $assertSession = $this->assertSession();
    $assertSession->statusCodeNotEquals(Response::HTTP_OK);

    // Login as Content manager, navigate to node edit page and publish content.
    $this->createUserWithPersonaAndLogin(['content_manager']);
    $nodeEditUrl = '/node/' . $node->id() . '/edit';
    $this->visitCheckCode($nodeEditUrl, Response::HTTP_OK);

    $this->submitForm([
      'moderation_state[0][state]' => 'published',
    ], 'Save');

    // Assert page has changed after successful form submission.
    $assertSession->statusCodeEquals(Response::HTTP_OK);
    $assertSession->addressNotEquals($nodeEditUrl);

    // Assert that page is now published and accessible to anonymous users.
    $this->drupalLogout();
    $this->visitCheckCode($node->toUrl(), Response::HTTP_OK);

    // Assert all fields are visible.
    $assertSession->pageTextContains('Test content title');
    $assertSession->pageTextContains('Test body content');
    $assertSession->pageTextContains('19/12/2023');
    $assertSession->pageTextContains('Test body content');
    $assertSession->responseContains('sample_image_hero.jpg');
  }

}
