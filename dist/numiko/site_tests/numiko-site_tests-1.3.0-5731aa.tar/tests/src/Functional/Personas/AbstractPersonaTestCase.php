<?php

namespace Drupal\Tests\site_tests\Functional\Personas;

use Drupal\site_tests\ContentTestTrait;
use Drupal\integration_tests\IntegrationTestBase;

/**
 * Test that persona functions as expected.
 */
abstract class AbstractPersonaTestCase extends IntegrationTestBase {
  use ContentTestTrait;

}
