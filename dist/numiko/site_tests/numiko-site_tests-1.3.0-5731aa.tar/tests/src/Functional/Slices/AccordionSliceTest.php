<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the accordion slice displays on a page.
 *
 * @group slices
 */
class AccordionSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding an accordion slice to a node.
   */
  public function testAccordionSliceDisplay() {
    $items[] = $this->createParagraph('accordion_item', [
      'field_title' => 'Accordion title 1',
      'field_content' => 'Accordion content 1',
    ]);
    $items[] = $this->createParagraph('accordion_item', [
      'field_title' => 'Accordion title 2',
      'field_content' => 'Accordion content 2',
    ]);

    $paragraphs[] = $this->createParagraph('slice_accordion', [
      'field_title' => 'Accordion Slice',
      'field_summary' => 'Accordion Summary',
      'field_items' => $items,

    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $assertSession->pageTextContains('Accordion Slice');
    $assertSession->pageTextContains('Accordion Summary');
    $assertSession->pageTextContains('Accordion title 1');
    $assertSession->pageTextContains('Accordion content 1');
    $assertSession->pageTextContains('Accordion title 2');
    $assertSession->pageTextContains('Accordion content 2');
  }

}
