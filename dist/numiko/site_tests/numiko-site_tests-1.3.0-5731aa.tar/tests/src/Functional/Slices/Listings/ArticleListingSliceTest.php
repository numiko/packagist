<?php

namespace Drupal\Tests\site_tests\Functional\Slices\Listings;

use Drupal\facets\Entity\Facet;
use Drupal\taxonomy\Entity\Vocabulary;
use Symfony\Component\HttpFoundation\Response;
use Drupal\Tests\listings_filter\Traits\ListingsFilterApiTrait;
use Drupal\integration_tests\IntegrationTestBase;
use Drupal\site_tests\ContentTestTrait;

/**
 * Test the case study listing.
 */
class ArticleListingSliceTest extends IntegrationTestBase {
  use ContentTestTrait, ListingsFilterApiTrait;

  /**
   * The slice to test.
   */
  protected const string SLICE_TYPE = 'slice_listing_article';

  /**
   * The taxonomoy thats used on the content type.
   */
  protected const string TAXONOMY = 'category';

  /**
   * The facet thats used.
   */
  protected const string FACET = 'category';

  /**
   * Test the case study listing slice display.
   */
  public function testCaseStudyListingsSliceDisplay(): void {
    // Create the listing node.
    $paragraph = $this->createParagraph(self::SLICE_TYPE, [
      'field_summary' => 'Test summary'
    ]);
    $node = $this->createPublishedNode(['field_slices' => $paragraph]);

    // Check slice display.
    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $this->assertSession()->responseContains('data-js-filter-listing-id="' . $paragraph->id() . '"');
  }

  /**
   * Test the case study listing slice api with no facets set.
   */
  public function testCaseStudyListingsSliceFacetBasic(): void {
    // Make sure with no facets set results with both taxonomies are returned.
    $category = Vocabulary::load(self::TAXONOMY);
    if (!$category) {
      $this->fail('Failed to load ' . self::TAXONOMY . ' taxonomy');
    }
    $category1 = $this->createTerm($category, ['name' => 'Test category 1']);
    $category2 = $this->createTerm($category, ['name' => 'Test category 2']);

    $node1 = $this->createPublishedNode([
      'type' => 'article',
      'title' => 'Test article 1',
      'field_publish_date' => '2023-12-19',
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser 1',
      'field_category' => $category1->id(),
    ]);
    $node2 = $this->createPublishedNode([
      'type' => 'article',
      'title' => 'Test article 2',
      'field_publish_date' => '2023-12-19',
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser 2',
      'field_category' => $category1->id(),
    ]);
    $node3 = $this->createPublishedNode([
      'type' => 'article',
      'title' => 'Test article 3',
      'field_publish_date' => '2023-12-19',
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser 3',
      'field_category' => $category2->id(),
    ]);
    $node4 = $this->createPublishedNode([
      'type' => 'page',
      'title' => 'Test not article',
      'field_publish_date' => '2023-12-19',
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser 4',
      'field_category' => $category1->id(),
    ]);

    // Index newly created nodes.
    $this->indexItemsInSearch();

    /** @var \Drupal\facets\FacetInterface $facet */
    $facet = Facet::load(self::FACET);

    /**
     * Create the listing paragraph
     *
     * @var \Drupal\paragraphs\ParagraphInterface $paragraph
     */
    $paragraph = $this->createParagraph(self::SLICE_TYPE, [
      'field_facet' => ['target_id' => $facet->id()],
    ]);
    $this->createPublishedNode([
      'type' => 'page',
      'field_slices' => $paragraph,
    ]);

    $response = $this->callListingFilterApi($paragraph);

    $this->assertResultsByUuid([$node1->uuid(), $node2->uuid(), $node3->uuid()], $response);
  }

  /**
   * Test the case study listing slice api with a facet set.
   */
  public function testCaseStudyListingsSliceFacet(): void {
    // Create category taxonomy.
    $category = Vocabulary::load(self::TAXONOMY);
    if (!$category) {
      $this->fail('Failed to load ' . self::TAXONOMY . ' taxonomy');
    }
    $category1 = $this->createTerm($category, ['name' => 'Test category 1']);
    $category2 = $this->createTerm($category, ['name' => 'Test category 2']);

    $node1 = $this->createPublishedNode([
      'type' => 'article',
      'title' => 'Test article 1',
      'field_publish_date' => '2023-12-19',
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser 1',
      'field_category' => $category1->id(),
    ]);
    $node2 = $this->createPublishedNode([
      'type' => 'article',
      'title' => 'Test article 2',
      'field_publish_date' => '2023-12-19',
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser 2',
      'field_category' => $category1->id(),
    ]);
    $node3 = $this->createPublishedNode([
      'type' => 'article',
      'title' => 'Test article 3',
      'field_publish_date' => '2023-12-19',
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser 3',
      'field_category' => $category2->id(),
    ]);
    $node4 = $this->createPublishedNode([
      'type' => 'page',
      'title' => 'Test not article',
      'field_publish_date' => '2023-12-19',
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser 4',
      'field_category' => $category1->id(),
    ]);

    // Index newly created nodes.
    $this->indexItemsInSearch();

    /** @var \Drupal\facets\FacetInterface $facet */
    $facet = Facet::load(self::FACET);

    /**
     * Create the listing paragraph
     *
     * @var \Drupal\paragraphs\ParagraphInterface $paragraph
     */
    $paragraph = $this->createParagraph(self::SLICE_TYPE, [
      'field_facet' => ['target_id' => $facet->id()],
    ]);
    $this->createPublishedNode([
      'type' => 'page',
      'field_slices' => $paragraph,
    ]);

    $response = $this->callListingFilterApi($paragraph, [
      'filter' => [
        $facet->id() => [
          'path' => $facet->get('field_identifier'),
          'value' => [$category1->id()],
        ],
      ],
    ]);

    $this->assertResultsByUuid([$node1->uuid(), $node2->uuid()], $response);
  }

}
