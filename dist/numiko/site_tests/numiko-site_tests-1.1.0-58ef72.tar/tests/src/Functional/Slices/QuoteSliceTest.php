<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the quote slice displays on a page.
 *
 * @group slices
 */
class QuoteSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a quote slice to a node.
   */
  public function testQuoteSliceDisplay() {
    static::markTestSkipped('Quote slice not yet implemented');

    $paragraphs[] = $this->createParagraph('slice_quote', [
      'field_content' => 'Test Quote',
      'field_name' => 'John Smith',
      'field_job_title' => 'Netrunner',
      'field_image' => $this->getSampleImageMedia([], 'sample_image_on_quote_slice.jpg')->id(),
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $assertSession->pageTextContains('Test Quote');
    $assertSession->pageTextContains('John Smith');
    $assertSession->pageTextContains('Netrunner');
    $assertSession->responseContains('sample_image_on_quote_slice.jpg');
  }

}
