<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the media slice displays on a page.
 *
 * @group slices
 */
class MediaSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a media slice to a node.
   */
  public function testMediaSliceDisplay() {
    static::markTestSkipped('Media slice not yet implemented');

    $paragraphs[] = $this->createParagraph('slice_media', [
      'field_summary' => 'Media slice caption',
      'field_media' => $this->getSampleImageMedia([], 'media_slice_image.jpg')->id(),
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $assertSession->pageTextContains('Media slice caption');
    $assertSession->responseContains('media_slice_image.jpg');
  }

}
