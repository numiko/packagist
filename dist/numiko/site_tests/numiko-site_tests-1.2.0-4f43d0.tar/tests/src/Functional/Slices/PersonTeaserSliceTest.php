<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the person teaser slice displays on a page.
 *
 * @group slices
 */
class PersonTeaserSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a person teaser slice to a node.
   */
  public function testPersonTeaserSliceDisplay() {
    static::markTestSkipped('Person teaser slice not yet implemented');

    $items = [
      [
        'target_id' => $this->createPublishedNode([
          'title' => 'Susan Smith',
          'type' => 'person',
          'field_email' => 'susan@smith.com',
        ])->id(),
      ],
      [
        'target_id' => $this->createPublishedNode([
          'title' => 'Janet Jones',
          'type' => 'person',
          'field_phone_number' => '0123456789',
        ])->id(),
      ],
      [
        'target_id' => $this->createPublishedNode([
          'title' => 'Bob Mortimer',
          'type' => 'person',
          'field_linkedin' => 'https://www.linkedin.com/bobmortimer/',
        ])->id(),
      ],
    ];

    $paragraphs[] = $this->createParagraph('slice_person_teaser', [
      'field_title' => 'Person teaser slice title',
      'field_content_items' => $items,
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);

    $assertSession->pageTextContains('Person teaser slice title');
    $assertSession->pageTextContains('Susan Smith');
    $assertSession->responseContains('susan@smith.com');
    $assertSession->pageTextContains('Janet Jones');
    $assertSession->responseContains('0123456789');
    $assertSession->pageTextContains('Bob Mortimer');
    $assertSession->responseContains('https://www.linkedin.com/bobmortimer/');
  }

}
