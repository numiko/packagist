<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the gallery slice displays on a page.
 *
 * @group slices
 */
class GallerySliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a gallery slice to a node.
   */
  public function testGallerySliceDisplay() {
    static::markTestSkipped('Gallery slice not yet implemented');

    $items[] = $this->createParagraph('gallery_item', [
      'field_title' => 'Gallery title 1',
      'field_description' => 'Gallery description 1',
      'field_media' => [
        'target_id' => $this->getSampleImageMedia(['field_caption' => 'Test caption on image asset'], 'sample_image_2_on_gallery_slice.jpg')->id(),
      ],
    ]);

    $items[] = $this->createParagraph('gallery_item', [
      'field_title' => 'Gallery title 2',
      'field_description' => 'Gallery description 2',
      'field_media' => [
        'target_id' => $this->getSampleImageMedia(['field_caption' => 'Test caption on image asset'], 'sample_image_1_on_gallery_slice.jpg')->id(),
      ],
    ]);

    $paragraphs[] = $this->createParagraph('slice_gallery', [
      'field_title' => 'Gallery slice title',
      'field_summary' => 'Gallery item description',
      'field_gallery_items' => $items
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();
    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);

    $assertSession->pageTextContains('Gallery slice title');
    $assertSession->pageTextNotContains('Test caption on image asset');
    $assertSession->responseContains('sample_image_1_on_gallery_slice.jpg');
    $assertSession->pageTextNotContains('Gallery item title for caption on video asset');
    $assertSession->pageTextNotContains('Test caption on video asset');
    $assertSession->responseContains('sample_image_2_on_gallery_slice.jpg');
  }

}
