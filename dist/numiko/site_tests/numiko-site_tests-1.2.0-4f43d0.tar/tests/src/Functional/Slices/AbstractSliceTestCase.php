<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Drupal\integration_tests\IntegrationTestBase;

/**
 * Test that the slices function as expected.
 *
 * @group slices
 */
abstract class AbstractSliceTestCase extends IntegrationTestBase {
}
