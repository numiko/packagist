# Site Tests

This module exists as the starting point for testing a site kit site.

The module is intended to be extended as the site is built; adding content types
personas, slices, and then tests for other functionality offered by the site.

## Outstanding issues

There is currently a problem with using the submitForm for buttons outside of the form element (as seen in the gin admin theme rc11).

```
    "patches": {
        "drupal/core": {
            "[3456202] PHPUnit tests: Support form actions being outside of a form": "https://git.drupalcode.org/project/drupal/-/merge_requests/8482/diffs.patch"
        }
    }
```
