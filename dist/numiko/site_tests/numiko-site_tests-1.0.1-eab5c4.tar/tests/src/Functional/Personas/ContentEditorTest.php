<?php

namespace Drupal\Tests\site_tests\Functional\Personas;

use Symfony\Component\HttpFoundation\Response;

/**
 * Test the site permissions.
 *
 * General site permissions tests, checks for adding / editing permissions
 * as well as access to site administration sections, such as but not exclusive
 * to:
 *   - Taxonomy
 *   - Menus
 *   - Webforms
 *   - People.
 *
 * @group personas
 */
class ContentEditorTest extends AbstractPersonaTestCase {

  const PERSONA = 'editor';

  /**
   * Initialise and create the user with the persona.
   */
  public function setUp(): void {
    parent::setUp();
    $this->createUserWithPersonaAndLogin([self::PERSONA]);
  }

  /**
   * Test admin pages.
   *
   * Test the personas access to administration functionality.
   */
  public function testAdminFunctions() {
    // Check they can view the content list.
    $this->visitCheckCode('admin/content', Response::HTTP_OK);

    // Check Taxonomy access.
    $this->visitCheckCode('admin/structure/taxonomy', Response::HTTP_FORBIDDEN);

    // Check Menu access.
    $this->visitCheckCode('admin/structure/menu', Response::HTTP_FORBIDDEN);

    // Check Webform access.
    $this->visitCheckCode('admin/structure/webform', Response::HTTP_FORBIDDEN);

    // Check Webform adding.
    $this->visitCheckCode('admin/structure/webform/add', Response::HTTP_FORBIDDEN);

    // Check the people list access.
    $this->visitCheckCode('admin/people', Response::HTTP_FORBIDDEN);

    // Check they can add people.
    $this->visitCheckCode('admin/people/create', Response::HTTP_FORBIDDEN);

    // Check they can view the file list.
    $this->visitCheckCode('admin/content/files', Response::HTTP_OK);

    // Check Taxonomy access.
    $this->visitCheckCode('admin/structure/taxonomy', Response::HTTP_FORBIDDEN);

    // Check Taxonomy adding.
    $this->visitCheckCode('admin/structure/taxonomy/add', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test unpublished content view access.
   */
  public function testContentViewUnpublished() {
    $this->assertViewUnpublishedContentTypeReturnsStatusCode('page', Response::HTTP_OK);
  }

  /**
   * Test unpublished content can be found in the content list.
   */
  public function testContentListShowsUnpublished() {
    $this->createNode([
      'title' => 'Content list test page',
      'type' => 'page',
    ]);
    $this->drupalGet('/admin/content');
    $this->assertSession()->responseContains("Content list test page");
  }

  /**
   * Test content add access.
   */
  public function testContentAdd() {
    $this->assertAddContentTypeReturnsStatusCode('article', Response::HTTP_OK);
    $this->assertAddContentTypeReturnsStatusCode('page', Response::HTTP_OK);
    $this->assertAddContentTypeReturnsStatusCode('person', Response::HTTP_OK);
    $this->assertAddContentTypeReturnsStatusCode('homepage', Response::HTTP_FORBIDDEN);
    $this->assertAddContentTypeReturnsStatusCode('listing', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test content edit access.
   */
  public function testContentEdit() {
    $this->assertEditContentTypeReturnsStatusCode('article', Response::HTTP_OK);
    $this->assertEditContentTypeReturnsStatusCode('page', Response::HTTP_OK);
    $this->assertEditContentTypeReturnsStatusCode('person', Response::HTTP_OK);
    $this->assertEditContentTypeReturnsStatusCode('homepage', Response::HTTP_OK);
    $this->assertEditContentTypeReturnsStatusCode('listing', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test content cannot be deleted.
   */
  public function testContentCannotDelete() {
    $this->assertDeleteContentTypeReturnsStatusCode('article', Response::HTTP_FORBIDDEN);
    $this->assertDeleteContentTypeReturnsStatusCode('page', Response::HTTP_FORBIDDEN);
    $this->assertDeleteContentTypeReturnsStatusCode('person', Response::HTTP_FORBIDDEN);
    $this->assertDeleteContentTypeReturnsStatusCode('homepage', Response::HTTP_FORBIDDEN);
    $this->assertDeleteContentTypeReturnsStatusCode('listing', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test the media add access.
   */
  public function testAddMediaAccess() {
    $this->assertAddMediaTypeReturnsStatusCode('image', Response::HTTP_OK);
    $this->assertAddMediaTypeReturnsStatusCode('core_video', Response::HTTP_OK);
    $this->assertAddMediaTypeReturnsStatusCode('document', Response::HTTP_OK);
  }

  /**
   * Test the media edit access.
   */
  public function testEditMediaAccess() {
    $this->assertEditMediaTypeReturnsStatusCode('image', Response::HTTP_OK);
    $this->assertEditMediaTypeReturnsStatusCode('core_video', Response::HTTP_OK);
    $this->assertEditMediaTypeReturnsStatusCode('document', Response::HTTP_OK);
  }

  /**
   * Test the media edit access.
   */
  public function testDeleteMediaAccess() {
    $this->assertDeleteMediaTypeReturnsStatusCode('image', Response::HTTP_OK);
    $this->assertDeleteMediaTypeReturnsStatusCode('core_video', Response::HTTP_OK);
    $this->assertDeleteMediaTypeReturnsStatusCode('document', Response::HTTP_OK);
  }

  /**
   * Test can create a draft.
   */
  public function testCanCreateDraft() {
    $this->assertCanUseTransition('draft');
  }

  /**
   * Test cannot publish.
   */
  public function testCannotPublish() {
    $this->assertCannotUseTransition('published');
  }

  /**
   * Test cannot archive.
   */
  public function testCannotArchive() {
    $this->assertCannotUseTransition('archived');
  }

}
