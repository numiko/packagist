<?php

namespace Drupal\Tests\site_tests\Functional\Personas;

use Drupal\site_tests\ContentTestTrait;
use Drupal\integration_tests\IntegrationTestBase;

/**
 * Test that persona functions as expected.
 */
abstract class AbstractPersonaTestCase extends IntegrationTestBase {

  use ContentTestTrait;

  /**
   * Test the given user cannot access the given moderation state.
   *
   * @param string $state
   *   The state to check.
   * @param array $settings
   *   The node settings.
   */
  protected function assertCannotUseTransition(string $state, array $settings = []) {
    $node = $this->createNode($settings);
    $this->drupalGet('node/' . $node->id() . '/edit');
    $this->assertStateNotShowingInModerationDropdown($state);
  }

}
