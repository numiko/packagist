<?php

declare(strict_types=1);

namespace Drupal\Tests\site_tests\Functional\Slices;

use PHPUnit\Framework\Attributes\Group;
use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the timeline slice displays on a page.
 */
#[Group('slices')]
class TimelineSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a timeline slice to a node.
   */
  public function testTimelineSliceDisplay(): void {
    $items[] = $this->createParagraph('timeline_item', [
      'field_title' => 'Timeline title 1',
      'field_content' => 'Timeline content 1',
      'field_link' => [
        'uri' => 'https://www.ecosia.org',
        'title' => 'CTA Timeline 1 button',
      ],
    ]);
    $items[] = $this->createParagraph('timeline_item', [
      'field_title' => 'Timeline title 2',
      'field_content' => 'Timeline content 2',
      'field_link' => [
        'uri' => 'https://duckduckgo.com',
        'title' => 'CTA Timeline 2 button',
      ],
    ]);

    $paragraphs[] = $this->createParagraph('slice_timeline', [
      'field_title' => 'Timeline Slice',
      'field_summary' => 'Timeline summary',
      'field_link' => [
        'uri' => 'https://www.google.com',
        'title' => 'CTA button',
      ],
      'field_items' => $items,
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $assertSession->pageTextContains('Timeline Slice');
    $assertSession->pageTextContains('Timeline summary');
    $assertSession->pageTextContains('CTA button');
    $assertSession->responseContains('https://www.google.com');
    $assertSession->pageTextContains('Timeline title 1');
    $assertSession->pageTextContains('Timeline content 1');
    $assertSession->pageTextContains('CTA Timeline 1 button');
    $assertSession->responseContains('https://www.ecosia.org');
    $assertSession->pageTextContains('Timeline title 2');
    $assertSession->pageTextContains('Timeline content 2');
    $assertSession->pageTextContains('CTA Timeline 2 button');
    $assertSession->responseContains('https://duckduckgo.com');
  }

}
