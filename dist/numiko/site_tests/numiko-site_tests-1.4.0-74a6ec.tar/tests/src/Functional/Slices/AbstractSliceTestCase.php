<?php

declare(strict_types=1);

namespace Drupal\Tests\site_tests\Functional\Slices;

use Drupal\integration_tests\IntegrationTestBase;

/**
 * Test that the slices function as expected.
 */
abstract class AbstractSliceTestCase extends IntegrationTestBase {
}
