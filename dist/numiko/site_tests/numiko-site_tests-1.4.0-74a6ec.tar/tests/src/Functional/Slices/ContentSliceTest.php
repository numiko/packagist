<?php

declare(strict_types=1);

namespace Drupal\Tests\site_tests\Functional\Slices;

use PHPUnit\Framework\Attributes\Group;
use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the content slice displays on a page.
 */
#[Group('slices')]
class ContentSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a content slice to a node.
   */
  public function testContentSliceDisplay(): void {
    $paragraphs[] = $this->createParagraph('slice_content', [
      'field_title' => 'Content Slice Title',
      'field_content' => 'Content Slice Content',
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $this->assertSession()->pageTextContains('Content Slice Title');
    $this->assertSession()->pageTextContains('Content Slice Content');
  }

}
