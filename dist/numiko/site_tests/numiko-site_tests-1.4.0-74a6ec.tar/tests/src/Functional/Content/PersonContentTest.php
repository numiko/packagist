<?php

declare(strict_types=1);

namespace Drupal\Tests\site_tests\Functional\Content;

use Drupal\integration_tests\IntegrationTestBase;
use Drupal\site_tests\ContentTestTrait;
use Drupal\taxonomy\Entity\Vocabulary;
use PHPUnit\Framework\Attributes\Group;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test that person page content functions as expected.
 */
#[Group('content')]
#[Group('page-content')]
class PersonContentTest extends IntegrationTestBase {

  use ContentTestTrait;

  /**
   * Test creation of person page and view.
   */
  public function testPersonContentCreateEditView(): void {
    // Create category taxonomy.
    $category = $this->createTerm(Vocabulary::load('category'), ['name' => 'Test category']);

    // Login as editor.
    $this->createUserWithPersonaAndLogin(['editor']);

    // Check access to create form.
    $this->visitCheckCode('/node/add/person', Response::HTTP_OK);

    $node = $this->createNode([
      'type' => 'person',
      'field_first_name' => 'Jane',
      'field_last_name' => 'Smith',
      'title' => 'Professor Jane Smith',
      'body' => 'Test body content',
      'field_position' => 'Test position',
      'field_organisation' => 'Test organisation',
      'field_email' => 'test@numiko.com',
      'field_phone_number' => '01234 56789',
      'field_linkedIn' => ['uri' => 'https://www.numiko.com'],
      'field_hero_media' => $this->getSampleImageMedia([], 'sample_image_hero.jpg')->id(),
      'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
      'field_teaser_summary' => 'Test teaser summary',
      'field_category' => [
        'target_id' => $category->id(),
      ],
      'moderation_state' => 'draft',
    ]);

    // Ensure logged in users can access node while in draft.
    $this->visitCheckCode($node->toUrl(), Response::HTTP_OK);

    $this->markEntityForCleanup($node);

    // Check anonymous users cannot access the node whilst it's in draft.
    $this->drupalLogout();
    $this->visitCheckCode('/node/' . $node->id(), Response::HTTP_FORBIDDEN);

    $assertSession = $this->assertSession();
    $assertSession->statusCodeNotEquals(Response::HTTP_OK);

    // Login as Content manager, navigate to node edit person page and publish
    // the test content.
    $this->createUserWithPersonaAndLogin(['content_manager']);
    $nodeEditUrl = '/node/' . $node->id() . '/edit';
    $this->visitCheckCode($nodeEditUrl, Response::HTTP_OK);

    $this->submitForm([
      'moderation_state[0][state]' => 'published',
    ], 'Save');

    // Assert person page has changed after successful form submission.
    $assertSession->statusCodeEquals(Response::HTTP_OK);
    $assertSession->addressNotEquals($nodeEditUrl);

    // Assert that person page is now published and accessible to anonymous
    // users.
    $this->drupalLogout();
    $this->visitCheckCode($node->toUrl(), Response::HTTP_OK);

    // Assert all fields are visible.
    $assertSession->pageTextContains('Professor Jane Smith');
    // $assertSession->pageTextContains('Test position');
    // $assertSession->pageTextContains('Test organisation');
    // $assertSession->pageTextContains('test@numiko.com');
    // $assertSession->pageTextContains('01234 56789');
    $assertSession->pageTextContains('Test body content');
    $assertSession->responseContains('sample_image_hero.jpg');
  }

}
