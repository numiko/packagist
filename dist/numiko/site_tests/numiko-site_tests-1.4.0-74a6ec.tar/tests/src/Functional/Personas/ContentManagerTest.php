<?php

declare(strict_types=1);

namespace Drupal\Tests\site_tests\Functional\Personas;

use PHPUnit\Framework\Attributes\Group;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test the site permissions.
 *
 * General site permissions tests, checks for adding / editing permissions
 * as well as access to site administration sections, such as but not exclusive
 * to:
 *   - Taxonomy
 *   - Menus
 *   - Webforms
 *   - People.
 */
#[Group('personas')]
class ContentManagerTest extends AbstractPersonaTestCase {

  const PERSONA = 'content_manager';

  /**
   * Initialise and create the user with the persona.
   */
  public function setUp(): void {
    parent::setUp();
    $this->createUserWithPersonaAndLogin([self::PERSONA]);
  }

  /**
   * Test admin pages.
   *
   * Test the personas access to administration functionality.
   */
  public function testAdminFunctions(): void {
    // Check they can view the content list.
    $this->visitCheckCode('admin/content', Response::HTTP_OK);

    // Check Taxonomy access.
    $this->visitCheckCode('admin/structure/taxonomy', Response::HTTP_OK);

    // Check Menu access.
    $this->visitCheckCode('admin/structure/menu', Response::HTTP_OK);

    // Check Webform access.
    $this->visitCheckCode('admin/structure/webform', Response::HTTP_FORBIDDEN);

    // Check Webform adding.
    $this->visitCheckCode('admin/structure/webform/add', Response::HTTP_FORBIDDEN);

    // Check the people list access.
    $this->visitCheckCode('admin/people', Response::HTTP_FORBIDDEN);

    // Check they can add people.
    $this->visitCheckCode('admin/people/create', Response::HTTP_FORBIDDEN);

    // Check they can view the file list.
    $this->visitCheckCode('admin/content/files', Response::HTTP_OK);

    // Check Taxonomy access.
    $this->visitCheckCode('admin/structure/taxonomy', Response::HTTP_OK);

    // Check Taxonomy adding.
    $this->visitCheckCode('admin/structure/taxonomy/add', Response::HTTP_OK);
  }

  /**
   * Test unpublished content can be viewed.
   */
  public function testContentViewUnpublished(): void {
    $this->assertViewUnpublishedContentTypeReturnsStatusCode('page', Response::HTTP_OK);
  }

  /**
   * Test unpublished content can be found in the content list.
   */
  public function testContentListShowsUnpublished(): void {
    $this->createNode([
      'title' => 'Content list test page',
      'type' => 'page',
    ]);
    $this->drupalGet('/admin/content');
    $this->assertSession()->responseContains("Content list test page");
  }

  /**
   * Test content add access.
   */
  public function testContentAdd(): void {
    $this->assertAddContentTypeReturnsStatusCode('article', Response::HTTP_OK);
    $this->assertAddContentTypeReturnsStatusCode('page', Response::HTTP_OK);
    $this->assertAddContentTypeReturnsStatusCode('person', Response::HTTP_OK);
    $this->assertAddContentTypeReturnsStatusCode('homepage', Response::HTTP_FORBIDDEN);
    $this->assertAddContentTypeReturnsStatusCode('listing', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test content edit access.
   */
  public function testContentEdit(): void {
    $this->assertEditContentTypeReturnsStatusCode('article', Response::HTTP_OK);
    $this->assertEditContentTypeReturnsStatusCode('page', Response::HTTP_OK);
    $this->assertEditContentTypeReturnsStatusCode('person', Response::HTTP_OK);
    $this->assertEditContentTypeReturnsStatusCode('homepage', Response::HTTP_OK);
    $this->assertEditContentTypeReturnsStatusCode('listing', Response::HTTP_OK);
  }

  /**
   * Test content cannot be deleted.
   */
  public function testContentCannotDelete(): void {
    $this->assertDeleteContentTypeReturnsStatusCode('article', Response::HTTP_FORBIDDEN);
    $this->assertDeleteContentTypeReturnsStatusCode('page', Response::HTTP_FORBIDDEN);
    $this->assertDeleteContentTypeReturnsStatusCode('person', Response::HTTP_FORBIDDEN);
    $this->assertDeleteContentTypeReturnsStatusCode('homepage', Response::HTTP_FORBIDDEN);
    $this->assertDeleteContentTypeReturnsStatusCode('listing', Response::HTTP_FORBIDDEN);
  }

  /**
   * Test the media add access.
   */
  public function testAddMediaAccess(): void {
    $this->assertAddMediaTypeReturnsStatusCode('image', Response::HTTP_OK);
    $this->assertAddMediaTypeReturnsStatusCode('core_video', Response::HTTP_OK);
    $this->assertAddMediaTypeReturnsStatusCode('document', Response::HTTP_OK);
  }

  /**
   * Test the media edit access.
   */
  public function testEditMediaAccess(): void {
    $this->assertEditMediaTypeReturnsStatusCode('image', Response::HTTP_OK);
    $this->assertEditMediaTypeReturnsStatusCode('core_video', Response::HTTP_OK);
    $this->assertEditMediaTypeReturnsStatusCode('document', Response::HTTP_OK);
  }

  /**
   * Test the media delete access.
   */
  public function testDeleteMediaAccess(): void {
    $this->assertDeleteMediaTypeReturnsStatusCode('image', Response::HTTP_OK);
    $this->assertDeleteMediaTypeReturnsStatusCode('core_video', Response::HTTP_OK);
    $this->assertDeleteMediaTypeReturnsStatusCode('document', Response::HTTP_OK);
  }

  /**
   * Test can create a draft.
   */
  public function testCanCreateDraft(): void {
    $this->assertCanUseTransition('draft');
  }

  /**
   * Test can publish.
   */
  public function testCanPublish(): void {
    $this->assertCanUseTransition('published');
  }

  /**
   * Test can archive.
   */
  public function testCanArchive(): void {
    $this->assertCanUseTransition('archived');
  }

}
