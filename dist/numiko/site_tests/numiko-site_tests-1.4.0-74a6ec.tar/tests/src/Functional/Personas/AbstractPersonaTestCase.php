<?php

declare(strict_types=1);

namespace Drupal\Tests\site_tests\Functional\Personas;

use Drupal\integration_tests\IntegrationTestBase;
use Drupal\site_tests\ContentTestTrait;

/**
 * Test that persona functions as expected.
 */
abstract class AbstractPersonaTestCase extends IntegrationTestBase {
  use ContentTestTrait;

}
