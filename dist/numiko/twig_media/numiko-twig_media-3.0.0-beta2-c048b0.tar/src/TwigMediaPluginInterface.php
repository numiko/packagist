<?php

namespace Drupal\twig_media;

use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\media\MediaInterface;

/**
 * Interface for a twig media plugin.
 */
interface TwigMediaPluginInterface extends PluginInspectionInterface {

  /**
   * Get attributes from the plugin.
   *
   * This will return the focal point attributes based on the given image file
   * as data attributes.
   */
  public function getAttributes(mixed $pluginOptions, MediaInterface $entity, int $fid, ?string $style = NULL, array $attributes = []): array;

}
