<?php

namespace Drupal\twig_media\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Template\AttributeString;

/**
 * Preprocess hook implementations for twig media.
 */
final class PreprocessHooks {

  /**
  * Implements hook_preprocess_responsive_image().
  *
  * Allow the overriding of the sizes attribute.
  *
  * @see Drupal\twig_media\Twig\TwigExtension::drupalImage()
  */
  #[Hook('preprocess_responsive_image')]
  public function preprocessResponsiveImage(array &$variables): void {
    if (!empty($variables['img_element']['#attributes']['override-sizes'])) {
      $variables['img_element']['#attributes']['sizes'] = new AttributeString('sizes', $variables['img_element']['#attributes']['override-sizes']);
      unset($variables['img_element']['#attributes']['override-sizes']);
    }
  }

}
