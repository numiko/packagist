# Twig Media

Twig filters to allow for the rendering of images from media entities directly in a content entity such as a node or paragraph.

```
{{ drupal_media(paragraph.field_media, 'image_style') }}

{{ drupal_media(paragraph.field_media, 'responsive_image_style', [], true) }}

{{ drupal_media(paragraph.field_media, 'image_style', {'class': ['my-class']}) }}
```
