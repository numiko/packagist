<?php

namespace Drupal\twig_media\Plugin\twig_media;

use Drupal\media\MediaInterface;
use Drupal\Component\Plugin\PluginBase;
use Drupal\twig_media\TwigMediaPluginInterface;

/**
 * Provides a title attribute that contains the alt text.
 *
 * @TwigMediaPlugin(
 *   id = "title_alt",
 *   name = @Translation("Alt Text as Title")
 * )
 */
class TwigMediaTitleAlt extends PluginBase implements TwigMediaPluginInterface {

  /**
   * Add a title attribute from the alt attribute.
   */
  public function getAttributes(mixed $pluginOptions, MediaInterface $entity, int $fid, string $style = NULL, array $attributes = []) : array {
    $attributes['title'] = $attributes['alt'];
    return $attributes;
  }

}
