<?php

namespace Drupal\twig_media\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Defines a data type of structured data.
 *
 * Plugin Namespace: Plugin\twig_media\TwigMediaPlugin.
 *
 * @see \Drupal\twig_media\TwigMediaPlugin
 * @see plugin_api
 *
 * @Annotation
 */
class TwigMediaPlugin extends Plugin {

  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

  /**
   * The name of the plugin.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $name;

}
