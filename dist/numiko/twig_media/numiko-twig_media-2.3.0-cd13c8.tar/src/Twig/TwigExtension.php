<?php

namespace Drupal\twig_media\Twig;

use Drupal\Core\Url;
use Twig\TwigFilter;
use Twig\TwigFunction;
use Drupal\file\Entity\File;
use Drupal\file\FileInterface;
use Drupal\Component\Uuid\Uuid;
use Drupal\media\MediaInterface;
use Drupal\image\Entity\ImageStyle;
use Twig\Extension\AbstractExtension;
use Drupal\Core\Entity\EntityInterface;
use Drupal\media\Plugin\media\Source\OEmbedInterface;
use Drupal\Core\Field\EntityReferenceFieldItemListInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\Plugin\Field\FieldType\EntityReferenceItem;

/**
 * Twig extension for handling media.
 *
 * Dependency injection is not used for performance reason.
 */
class TwigExtension extends AbstractExtension {

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return [
      new TwigFunction('drupal_entity', [$this, 'drupalEntity']),
      new TwigFunction('drupal_image_from_media', [
        $this,
        'drupalMediaEntityImage',
      ]),
      new TwigFunction('drupal_image', [$this, 'drupalImage']),
      new TwigFunction('drupal_url', [$this, 'drupalUrl']),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFilters() {
    $filters = [
      new TwigFilter('image_style', [$this, 'imageStyle']),
      new TwigFilter('file_url', [$this, 'fileUrl']),
      new TwigFilter('is_media_bundle', [$this, 'isMediaBundle']),
      new TwigFilter('media_image_style_url', [
        $this,
        'mediaEntityImageStyleUrl',
      ]),
    ];
    return $filters;
  }

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return 'twig_media';
  }

  /**
   * Returns the render array for an entity.
   *
   * @param string $entity_type
   *   The entity type.
   * @param mixed $id
   *   The ID of the entity to build.
   * @param string $view_mode
   *   (optional) The view mode that should be used to render the entity.
   * @param string $langcode
   *   (optional) For which language the entity should be rendered, defaults to
   *   the current content language.
   *
   * @return null|array
   *   A render array for the entity or NULL if the entity does not exist.
   */
  public function drupalEntity($entity_type, $id = NULL, $view_mode = NULL, $langcode = NULL) {
    $entity_type_manager = \Drupal::entityTypeManager();
    $entity = $id
      ? $entity_type_manager->getStorage($entity_type)->load($id)
      : \Drupal::routeMatch()->getParameter($entity_type);
    if ($entity && $entity->access('view')) {
      $render_controller = $entity_type_manager->getViewBuilder($entity_type);
      return $render_controller->view($entity, $view_mode, $langcode);
    }
  }

  /**
   * Builds an image from a media entity.
   *
   * @param Drupal\Core\Field\EntityReferenceFieldItemListInterface|array $item
   *   The render array or field item list referencing the media item.
   * @param string $style
   *   (Optional) Image style.
   * @param array $attributes
   *   (Optional) Image attributes.
   * @param array $options
   *   (Optional) Options to use to process the media.
   *
   * @return array|null
   *   A render array to represent the image.
   */
  public function drupalMediaEntityImage($item = NULL, $style = NULL, array $attributes = [], array $options = []) {
    $defaultOptions = ['responsive' => TRUE];
    $options = array_merge($defaultOptions, $options);
    if (is_array($item) && !empty($item['#items'])) {
      $item = $item['#items'];
    }
    $entity = $this->identifyEntityFromItem($item);
    if (!$entity) {
      return NULL;
    }
    if ($entity instanceof MediaInterface) {
      $sourceAttributes = \Drupal::service('plugin.manager.twig_media.source')->getSourceAttributes($entity);
      $attributes = array_merge($attributes, $sourceAttributes);
      if (!empty($attributes['fid'])) {
        $fid = $attributes['fid'];
        unset($attributes['fid']);
      }
    }
    elseif ($entity instanceof FileInterface) {
      $fid = $entity->id();
      if ($item instanceof FieldItemListInterface && empty($attributes['width'])) {
        $metadata = $item->first()->getValue();
        $attributes['width'] = $metadata['width'];
        $attributes['height'] = $metadata['height'];
      }
    }
    if (!$fid) {
      return NULL;
    }
    foreach ($options as $option => $pluginOptions) {
      if (\Drupal::service('plugin.manager.twig_media')->hasDefinition($option)) {
        $plugin = \Drupal::service('plugin.manager.twig_media')->createInstance($option);
        $attributes = $plugin->getAttributes($pluginOptions, $entity, $fid, $style, $attributes);
      }
    }
    return $this->drupalImage($fid, $style, $attributes, $options['responsive']);
  }

  /**
   * Checks for a media entity being a given bundle.
   *
   * @param Drupal\Core\Field\FieldItemListInterface|array $item
   *   The render array or field item list referencing the media item.
   * @param string $bundle
   *   The bundle to check for.
   *
   * @return bool
   *   Whether the media entity matches the bundle given.
   */
  public function isMediaBundle($item, $bundle) {
    if (is_array($item) && !empty($item['#items'])) {
      $item = $item['#items'];
    }
    $entity = $this->identifyEntityFromItem($item);
    if ($entity) {
      if ($entity instanceof MediaInterface) {
        return $entity->bundle() === $bundle;
      }
    }
    return FALSE;
  }

  /**
   * Builds an image style variant url from a media entity.
   *
   * Pass in the media field list and the image style.
   * @code
   *   {{ node.field_media|media_image_style_url('16_9') }}
   * @endcode
   *
   * @param Drupal\Core\Field\FieldItemListInterface|array $item
   *   The render array or field item list referencing the media item.
   * @param string $style
   *   (Optional) Image style.
   *
   * @return string|null
   *   A url to represent the image style.
   */
  public function mediaEntityImageStyleUrl($item = NULL, $style = NULL) {
    if (is_array($item) && !empty($item['#items'])) {
      $item = $item['#items'];
    }
    $entity = $this->identifyEntityFromItem($item);
    if ($entity) {
      if ($entity instanceof MediaInterface) {
        $source = $entity->getSource();
        $fid = $source->getSourceFieldValue($entity);
        $file = File::load($fid);
        if ($file) {
          $fileUrl = $file->getFileUri();
        }
      }
      elseif ($entity instanceof FileInterface) {
        $fileUrl = $entity->getFileUri();
      }
      if ($fileUrl) {
        return $this->imageStyle($fileUrl, $style);
      }
    }
  }

  /**
   * Identify the entity from the item passed to the twig function.
   *
   * @param Drupal\Core\Field\EntityReferenceFieldItemListInterface|MediaInterface $item
   *   The render array or field item list referencing the media item.
   *
   * @return EntityInterface|null
   */
  private function identifyEntityFromItem($item = NULL): ?EntityInterface {
    if ($item && is_object($item) && $item instanceof MediaInterface) {
      return $item;
    }
    if ($item && is_object($item) && $item instanceof EntityReferenceFieldItemListInterface) {
      return current($item->referencedEntities());
    }
    return NULL;
  }

  /**
   * Builds an image.
   *
   * @param mixed $property
   *   A property to identify the image.
   * @param string $style
   *   (Optional) Image style.
   * @param array $attributes
   *   (Optional) Image attributes.
   * @param bool $responsive
   *   (Optional) Indicates that the provided image style is responsive.
   *
   * @return array|null
   *   A render array to represent the image.
   */
  public function drupalImage($property, $style = NULL, array $attributes = [], $responsive = FALSE) {

    // Determine property type by its value.
    if (preg_match('/^\d+$/', $property)) {
      $property_type = 'fid';
    }
    elseif (Uuid::isValid($property)) {
      $property_type = 'uuid';
    }
    else {
      $property_type = 'uri';
    }

    $files = \Drupal::entityTypeManager()
      ->getStorage('file')
      ->loadByProperties([$property_type => $property]);

    // To avoid ambiguity render nothing unless exact one image was found.
    if (count($files) != 1) {
      return;
    }

    /** @var Drupal\file\Entity\File */
    $file = reset($files);

    if (!$file->access('view')) {
      return;
    }

    $build = [
      '#uri' => $file->getFileUri(),
      '#attributes' => $attributes,
    ];

    if ($style) {
      if ($responsive) {
        $build['#type'] = 'responsive_image';
        $build['#responsive_image_style_id'] = $style;
        // Pass in the height and width as the default these will be
        // overridden by image styles if found. This replicates
        // functionality used by the responsive image style formatter to avoid
        // an exception when dimensions are missing with uncropped image styles.
        // @see _responsive_image_build_source_attributes().
        $build['#width'] = $attributes['width'] ?? NULL;
        $build['#height'] = $attributes['height'] ?? NULL;
        // If sizes is set it will be replaced by the default for the image
        // style so store the sizes for override by the preprocessor.
        // @see twig_media_preprocess_responsive_image().
        if (!empty($build['#attributes']['sizes'])) {
          $build['#attributes']['override-sizes'] = $build['#attributes']['sizes'];
          unset($build['#attributes']['sizes']);
        }
      }
      else {
        $build['#theme'] = 'image_style';
        $build['#style_name'] = $style;
      }
    }
    else {
      $build['#theme'] = 'image';
    }

    return $build;
  }

  /**
   * Generates a URL from an internal path.
   *
   * @param string $user_input
   *   User input for a link or path.
   * @param array $options
   *   (optional) An array of options.
   *
   * @return \Drupal\Core\Url
   *   A new Url object based on user input.
   *
   * @see \Drupal\Core\Url::fromUserInput()
   */
  public function drupalUrl($user_input, array $options = []) {
    if (isset($options['langcode'])) {
      $language_manager = \Drupal::languageManager();
      if ($language = $language_manager->getLanguage($options['langcode'])) {
        $options['language'] = $language;
      }
    }
    if (!in_array($user_input[0], ['/', '#', '?'])) {
      $user_input = '/' . $user_input;
    }
    $url = Url::fromUserInput($user_input, $options);
    if ($url->access()) {
      return $url;
    }
  }

  /**
   * Returns the URL of this image derivative for an original image path or URI.
   *
   * @param string $path
   *   The path or URI to the original image.
   * @param string $style
   *   The image style.
   *
   * @return string
   *   The absolute URL where a style image can be downloaded, suitable for use
   *   in an <img> tag. Requesting the URL will cause the image to be created.
   */
  public function imageStyle($path, $style) {
    /** @var \Drupal\Image\ImageStyleInterface $image_style */
    if ($image_style = ImageStyle::load($style)) {
      return \Drupal::service('file_url_generator')->transformRelative($image_style->buildUrl($path));
    }
  }

  /**
   * Returns a URL path to the file.
   *
   * Examples:
   *
   * For string arguments it works similar to core file_url() Twig function.
   * @code
   *   {{ 'public://sea.jpg'|file_url }}
   * @endcode
   *
   * When field item list passed the URL will be extracted from the first item.
   * In order to get URL of specific item specify its delta explicitly using
   * array notation.
   * @code
   *   {{ node.field_image|file_url }}
   *   {{ node.field_image[0]|file_url }}
   * @endcode
   *
   * Media fields are fully supported including OEmbed resources.
   * @code
   *   {{ node.field_media|file_url }}
   * @endcode
   *
   * @param string|object $input
   *   Can be either file URI or an object that contains the URI.
   *
   * @return string|null
   *   A URL that may be used to access the file.
   */
  public function fileUrl($input) {
    if (is_string($input)) {
      return \Drupal::service('file_url_generator')->generateString($input);
    }
    if ($input instanceof EntityReferenceFieldItemListInterface) {
      $referenced_entities = $input->referencedEntities();
      if (isset($referenced_entities[0])) {
        return self::getUrlFromEntity($referenced_entities[0]);
      }
    }
    elseif ($input instanceof EntityReferenceItem) {
      return self::getUrlFromEntity($input->entity);
    }
  }

  /**
   * Extracts file URL form content entity.
   *
   * @param object $entity
   *   Entity object that contains information about the file.
   *
   * @return string|null
   *   A URL that may be used to access the file.
   */
  private static function getUrlFromEntity($entity) {
    if ($entity instanceof MediaInterface) {
      $source = $entity->getSource();
      $value = $source->getSourceFieldValue($entity);
      if ($source instanceof OEmbedInterface) {
        return $value;
      }
      elseif ($file = File::load($value)) {
        return $file->createFileUrl();
      }
    }
    elseif ($entity instanceof FileInterface) {
      return $entity->createFileUrl();
    }
  }

}
