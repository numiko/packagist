<?php

namespace Drupal\twig_media;

use Drupal\media\MediaInterface;
use Drupal\Component\Plugin\PluginInspectionInterface;

/**
 * Interface for a twig media plugin.
 */
interface TwigMediaSourcePluginInterface extends PluginInspectionInterface {

  /**
   * Get the file source attributes from the media source.
   *
   * This will return the file source attributes of the source file from
   * the media entity.
   */
  public function getSourceAttributes(MediaInterface $entity) : array;

}
