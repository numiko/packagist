<?php

namespace Drupal\twig_media_focal_point\Plugin\twig_media;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\media\MediaInterface;
use Drupal\twig_media\Attribute\TwigMediaPlugin;
use Drupal\twig_media\TwigMediaPluginInterface;
use Drupal\twig_media_focal_point\FocalPoint;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'focal point' twig media plugin.
 */
#[TwigMediaPlugin(
  id: 'focal_point',
  name: new TranslatableMarkup('Focal point')
)]
class TwigMediaFocalPoint extends PluginBase implements ContainerFactoryPluginInterface, TwigMediaPluginInterface {

  /**
   * The focal point service.
   */
  protected FocalPoint $focalPoint;

  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $static = new static(
      $configuration,
      $plugin_id,
      $plugin_definition
    );
    $static->focalPoint = $container->get('twig_media.focal_point');
    $static->entityTypeManager = $container->get(EntityTypeManagerInterface::class);
    return $static;
  }

  /**
   * Get attributes from the plugin.
   *
   * This will return the focal point attributes based on the given image file
   * as data attributes.
   */
  public function getAttributes(mixed $pluginOptions, MediaInterface $entity, int $fid, ?string $style = NULL, array $attributes = []) : array {
    $attributes['data-focal-position'] = FocalPoint::DEFAULT_POSITION;
    $source = $entity->getSource();
    $width = $source->getMetadata($entity, 'width');
    $height = $source->getMetadata($entity, 'height');
    $file = $this->entityTypeManager->getStorage('file')->load($fid);
    $attributes['data-focal-position'] = $this->focalPoint->getFocalPosition($file, $width, $height);
    return $attributes;
  }

}
