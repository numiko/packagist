<?php

namespace Drupal\twig_media\Attribute;

use Drupal\Component\Plugin\Attribute\Plugin;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines a twig media plugin.
 */
#[\Attribute(\Attribute::TARGET_CLASS)]
class TwigMediaPlugin extends Plugin {

  /**
   * Constructs a twig media attribute.
   *
   * @param string $id
   *   The plugin ID.
   * @param ?\Drupal\Core\StringTranslation\TranslatableMarkup $name
   *   The name of the plugin.
   */
  public function __construct(
    public readonly string $id,
    public readonly ?TranslatableMarkup $name = NULL,
  ) {}

}
