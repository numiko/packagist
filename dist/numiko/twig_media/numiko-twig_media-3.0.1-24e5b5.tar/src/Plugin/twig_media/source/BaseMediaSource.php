<?php

namespace Drupal\twig_media\Plugin\twig_media\source;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\media\MediaInterface;
use Drupal\twig_media\Attribute\TwigMediaSourcePlugin;
use Drupal\twig_media\TwigMediaSourcePluginInterface;

/**
 * Provides a base media source twig media plugin.
 */
#[TwigMediaSourcePlugin(
    id: 'base',
    name: new TranslatableMarkup('Base Media Source'),
 )]
class BaseMediaSource extends PluginBase implements TwigMediaSourcePluginInterface {

  /**
   * {@inheritDoc}
   */
  public function getSourceAttributes(MediaInterface $entity) : array {
    $source = $entity->getSource();
    $attributes['fid'] = $source->getSourceFieldValue($entity);
    if (!array_key_exists('alt', $attributes)) {
      $attributes['alt'] = $source->getMetadata($entity, 'thumbnail_alt_value');
    }
    if (!array_key_exists('width', $attributes)) {
      $attributes['width'] = $source->getMetadata($entity, 'width');
    }
    if (!array_key_exists('height', $attributes)) {
      $attributes['height'] = $source->getMetadata($entity, 'height');
    }
    return $attributes;
  }

}
