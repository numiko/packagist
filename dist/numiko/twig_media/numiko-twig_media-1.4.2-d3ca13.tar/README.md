# Twig Media

## Image Style URL from Media

Twig filter to allow for an image style URL to be generated from media entities directly in a content entity such as a node or paragraph.

```
<!-- Return an image style URL for a media entity field -->
{{ content.field_media|media_image_style_url('16_9') }}
```

## Image Tag from Media

Twig function to allow for the rendering of images from media entities directly in a content entity such as a node or paragraph.

```
<!-- Render a responsive image style -->
{{ drupal_image_from_media(content.field_media, 'responsive_image_style') }}

<!-- Render a responsive image style on a node (you can also pass in the field item list directly) -->
{{ drupal_image_from_media(node.field_media, 'responsive_image_style') }}

<!-- Render a responsive image style overriding the alt attribute (for example if its a decorative element) -->
{{ drupal_image_from_media(content.field_media, 'responsive_image_style', {alt: ''}) }}

<!-- Render a responsive image style overriding the sizes attribute -->
{{ drupal_image_from_media(content.field_media, 'responsive_image_style', {sizes: '50vw'}) }}

<!-- Render a non-responsive image style as an image tag (you can also pass in the field item list directly) -->
{{ drupal_image_from_media(paragraph.field_media, 'image_style'. {}, {responsive: false}) }}

<!-- Render a non-responsive image style as an image tag adding a class to the attributes -->
{{ drupal_image_from_media(content.field_media, 'image_style', {'class': ['my-class']}, {responsive: false}) }}
```

### Plugins

Twig media allows for plugins to be added that alter the output attributes.

The example of this is the bundled `twig_media_focal_point` sub-module, which when enabled allows for focal point data attributes to be added to media image.

```
<!-- Render a responsive image style with focal point data -->
{{ drupal_image_from_media(content.field_media, 'responsive_image_style', {}, {focal_point: true}) }}
```

## Drupal Media Bundle

Twig filter to identify if a media entity field (first item) is of a given bundle type.

```
<!-- Check if a field contains the correct media type -->
{% if content.field_media|is_media_bundle('image') %}
```