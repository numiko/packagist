<?php

namespace Drupal\twig_media;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\media\MediaInterface;
use Drupal\twig_media\Attribute\TwigMediaSourcePlugin;

/**
 * Plugin manager for twig media plugins.
 */
class TwigMediaSourcePluginManager extends DefaultPluginManager {

  /**
   * Constructs an TwigMediaSourcePluginManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke the alter hook with.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct('Plugin/twig_media/source', $namespaces, $module_handler, TwigMediaSourcePluginInterface::class, TwigMediaSourcePlugin::class);
    $this->alterInfo('twig_media_source_plugin_info');
    $this->setCacheBackend($cache_backend, 'twig_media_source_plugins');
  }

  /**
   * Find the appropriate plugin for the media entity and return the attributes.
   */
  public function getSourceAttributes(MediaInterface $media) {
    $definitions = $this->getDefinitions();
    foreach ($definitions as $definition) {
      if ($definition['source'] === $media->bundle()) {
        $source = $this->createInstance($definition['id'], []);
        return $source->getSourceAttributes($media);
      }
      elseif (!$definition['source']) {
        $defaultSource = $this->createInstance($definition['id'], []);
      }
    }
    return $defaultSource->getSourceAttributes($media);
  }

}
