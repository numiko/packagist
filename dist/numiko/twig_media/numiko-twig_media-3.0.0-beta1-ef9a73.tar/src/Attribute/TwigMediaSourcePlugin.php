<?php

namespace Drupal\twig_media\Attribute;

use Drupal\Component\Plugin\Attribute\Plugin;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines a twig media source plugin.
 */
#[\Attribute(\Attribute::TARGET_CLASS)]
class TwigMediaSourcePlugin extends Plugin {

  /**
   * Constructs a twig media source attribute.
   *
   * @param string $id
   *   The plugin ID.
   * @param ?\Drupal\Core\StringTranslation\TranslatableMarkup $name
   *   The name of the plugin.
   * @param ?string $type
   *   The media type.
   */
  public function __construct(
    public readonly string $id,
    public readonly ?TranslatableMarkup $name = NULL,
    public readonly ?string $type = NULL,
  ) {}

}
