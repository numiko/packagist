<?php

namespace Drupal\twig_media\Twig;

use Drupal\Component\Uuid\Uuid;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\EntityReferenceFieldItemListInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\Plugin\Field\FieldType\EntityReferenceItem;
use Drupal\Core\File\FileUrlGeneratorInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Url;
use Drupal\file\Entity\File;
use Drupal\file\FileInterface;
use Drupal\media\MediaInterface;
use Drupal\media\Plugin\media\Source\OEmbedInterface;
use Drupal\twig_media\TwigMediaPluginManager;
use Drupal\twig_media\TwigMediaSourcePluginManager;
use Symfony\Component\DependencyInjection\Attribute\AutowireServiceClosure;
use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;
use Twig\TwigFunction;

/**
 * Twig extension for handling media.
 */
class TwigExtension extends AbstractExtension {

  /**
   * Media twig extension constructor.
   *
   * Services should be injected here as service closures to keep dependencies
   * lightweight. The entity type manager has also certainly already been
   * instantiated anyway so just load it as normal.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   Entity type manager.
   * @param \Closure(): \Drupal\Core\Routing\RouteMatchInterface $currentRouteMatchClosure
   *   Route matcher.
   * @param \Closure(): \Drupal\twig_media\TwigMediaSourcePluginManager $twigMediaSourceManagerClosure
   *   Twig media source plugin manager.
   * @param \Closure(): \Drupal\twig_media\TwigMediaPluginManager $twigMediaManagerClosure
   *   Twig media plugin manager.
   * @param \Closure(): \Drupal\Core\Language\LanguageManagerInterface $languageManagerClosure
   *   Language manager.
   * @param \Closure(): \Drupal\Core\File\FileUrlGeneratorInterface $fileUrlGeneratorClosure
   *   File URL generator.
   */
  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    #[AutowireServiceClosure(RouteMatchInterface::class)]
    protected readonly \Closure $currentRouteMatchClosure,
    #[AutowireServiceClosure(TwigMediaSourcePluginManager::class)]
    protected readonly \Closure $twigMediaSourceManagerClosure,
    #[AutowireServiceClosure(TwigMediaPluginManager::class)]
    protected readonly \Closure $twigMediaManagerClosure,
    #[AutowireServiceClosure(LanguageManagerInterface::class)]
    protected readonly \Closure $languageManagerClosure,
    #[AutowireServiceClosure(FileUrlGeneratorInterface::class)]
    protected readonly \Closure $fileUrlGeneratorClosure,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return [
      new TwigFunction('drupal_entity', $this->drupalEntity(...)),
      new TwigFunction('drupal_image_from_media', $this->drupalMediaEntityImage(...)),
      new TwigFunction('drupal_image', $this->drupalImage(...)),
      new TwigFunction('drupal_url', $this->drupalUrl(...)),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFilters() {
    $filters = [
      new TwigFilter('image_style', $this->imageStyle(...)),
      new TwigFilter('file_url', $this->fileUrl(...)),
      new TwigFilter('is_media_bundle', $this->isMediaBundle(...)),
      new TwigFilter('media_image_style_url', $this->mediaEntityImageStyleUrl(...)),
    ];
    return $filters;
  }

  /**
   * {@inheritdoc}
   */
  public function getName(): string {
    return 'twig_media';
  }

  /**
   * Returns the render array for an entity.
   *
   * @param string $entity_type
   *   The entity type.
   * @param mixed $id
   *   The ID of the entity to build.
   * @param ?string $view_mode
   *   (optional) The view mode that should be used to render the entity.
   * @param ?string $langcode
   *   (optional) For which language the entity should be rendered, defaults to
   *   the current content language.
   *
   * @return ?array
   *   A render array for the entity or NULL if the entity does not exist.
   */
  public function drupalEntity(string $entity_type, $id = NULL, ?string $view_mode = NULL, ?string $langcode = NULL): ?array {
    if ($id) {
      $entity = $this->entityTypeManager->getStorage($entity_type)->load($id);
    }
    else {
      /** @var ?\Drupal\Core\Entity\EntityInterface $entity */
      $entity = ($this->currentRouteMatchClosure)()->getParameter($entity_type);
    }
    if ($entity && $entity->access('view')) {
      $render_controller = $this->entityTypeManager->getViewBuilder($entity_type);
      return $render_controller->view($entity, $view_mode, $langcode);
    }
    return NULL;
  }

  /**
   * Builds an image from a media entity.
   *
   * @param \Drupal\Core\Field\EntityReferenceFieldItemListInterface|array|null $item
   *   The render array or field item list referencing the media item.
   * @param ?string $style
   *   (Optional) Image style.
   * @param array $attributes
   *   (Optional) Image attributes.
   * @param array $options
   *   (Optional) Options to use to process the media.
   *
   * @return ?array
   *   A render array to represent the image.
   */
  public function drupalMediaEntityImage(
    EntityReferenceFieldItemListInterface|array|null $item = NULL,
    ?string $style = NULL,
    array $attributes = [],
    array $options = [],
  ): ?array {
    $defaultOptions = ['responsive' => TRUE];
    $options = array_merge($defaultOptions, $options);
    if (is_array($item) && !empty($item['#items'])) {
      $item = $item['#items'];
    }
    $entity = $this->identifyEntityFromItem($item);
    if (!$entity) {
      return NULL;
    }
    if ($entity instanceof MediaInterface) {
      $sourceAttributes = ($this->twigMediaSourceManagerClosure)()->getSourceAttributes($entity);
      $attributes = array_merge($attributes, $sourceAttributes);
      if (!empty($attributes['fid'])) {
        $fid = $attributes['fid'];
        unset($attributes['fid']);
      }
    }
    elseif ($entity instanceof FileInterface) {
      $fid = $entity->id();
      if ($item instanceof FieldItemListInterface && empty($attributes['width'])) {
        $metadata = $item->first()->getValue();
        $attributes['width'] = $metadata['width'];
        $attributes['height'] = $metadata['height'];
      }
    }
    if (empty($fid)) {
      return NULL;
    }

    $twig_media_plugin_manager = ($this->twigMediaManagerClosure)();
    foreach ($options as $option => $pluginOptions) {
      if ($twig_media_plugin_manager->hasDefinition($option)) {
        /** @var \Drupal\twig_media\TwigMediaPluginInterface $plugin */
        $plugin = $twig_media_plugin_manager->createInstance($option);
        $attributes = $plugin->getAttributes($pluginOptions, $entity, $fid, $style, $attributes);
      }
    }
    return $this->drupalImage($fid, $style, $attributes, $options['responsive']);
  }

  /**
   * Checks for a media entity being a given bundle.
   *
   * @param \Drupal\Core\Field\FieldItemListInterface|array $item
   *   The render array or field item list referencing the media item.
   * @param string $bundle
   *   The bundle to check for.
   *
   * @return bool
   *   Whether the media entity matches the bundle given.
   */
  public function isMediaBundle(FieldItemListInterface|array $item, string $bundle) {
    if (is_array($item) && !empty($item['#items'])) {
      $item = $item['#items'];
    }
    $entity = $this->identifyEntityFromItem($item);
    if ($entity) {
      if ($entity instanceof MediaInterface) {
        return $entity->bundle() === $bundle;
      }
    }
    return FALSE;
  }

  /**
   * Builds an image style variant url from a media entity.
   *
   * Pass in the media field list and the image style.
   * @code
   *   {{ node.field_media|media_image_style_url('16_9') }}
   * @endcode
   *
   * @param \Drupal\Core\Field\FieldItemListInterface|array|null $item
   *   The render array or field item list referencing the media item.
   * @param ?string $style
   *   (Optional) Image style.
   *
   * @return ?string
   *   A url to represent the image style.
   */
  public function mediaEntityImageStyleUrl(
    FieldItemListInterface|array|null $item = NULL,
    ?string $style = NULL,
  ): ?string {
    if (is_array($item) && !empty($item['#items'])) {
      $item = $item['#items'];
    }
    $entity = $this->identifyEntityFromItem($item);
    if ($entity) {
      if ($entity instanceof MediaInterface) {
        $source = $entity->getSource();
        $fid = $source->getSourceFieldValue($entity);
        $file = $this->entityTypeManager->getStorage('file')->load($fid);
        if ($file) {
          $fileUrl = $file->getFileUri();
        }
      }
      elseif ($entity instanceof FileInterface) {
        $fileUrl = $entity->getFileUri();
      }
      if ($fileUrl) {
        return $this->imageStyle($fileUrl, $style);
      }
    }

    return NULL;
  }

  /**
   * Identify the entity from the item passed to the twig function.
   *
   * @param \Drupal\Core\Field\EntityReferenceFieldItemListInterface|MediaInterface|null $item
   *   The render array or field item list referencing the media item.
   *
   * @return \Drupal\Core\Entity\EntityInterface|false
   */
  private function identifyEntityFromItem(
    EntityReferenceFieldItemListInterface|MediaInterface|null $item = NULL,
  ): EntityInterface|false {
    if ($item && $item instanceof MediaInterface) {
      return $item;
    }
    // $item now is either EntityReferenceFieldItemListInterface or null
    if ($item) {
      return current($item->referencedEntities());
    }
    return FALSE;
  }

  /**
   * Builds an image.
   *
   * @param mixed $property
   *   A property to identify the image.
   * @param ?string $style
   *   (Optional) Image style.
   * @param array $attributes
   *   (Optional) Image attributes.
   * @param bool $responsive
   *   (Optional) Indicates that the provided image style is responsive.
   *
   * @return ?array
   *   A render array to represent the image.
   */
  public function drupalImage($property, ?string $style = NULL, array $attributes = [], bool $responsive = FALSE): ?array {
    // Determine property type by its value.
    if (preg_match('/^\d+$/', $property)) {
      $property_type = 'fid';
    }
    elseif (Uuid::isValid($property)) {
      $property_type = 'uuid';
    }
    else {
      $property_type = 'uri';
    }

    $files = $this->entityTypeManager->getStorage('file')->loadByProperties([$property_type => $property]);
    // To avoid ambiguity render nothing unless exact one image was found.
    if (count($files) !== 1) {
      return NULL;
    }
    $file = reset($files);

    if (!$file->access('view')) {
      return NULL;
    }

    $build = [
      '#uri' => $file->getFileUri(),
      '#attributes' => $attributes,
    ];

    if ($style) {
      if ($responsive) {
        $build['#type'] = 'responsive_image';
        $build['#responsive_image_style_id'] = $style;
        // Pass in the height and width as the default these will be
        // overridden by image styles if found. This replicates
        // functionality used by the responsive image style formatter to avoid
        // an exception when dimensions are missing with uncropped image styles.
        // @see _responsive_image_build_source_attributes().
        $build['#width'] = $attributes['width'] ?? NULL;
        $build['#height'] = $attributes['height'] ?? NULL;
        // If sizes is set it will be replaced by the default for the image
        // style so store the sizes for override by the preprocessor.
        // @see twig_media_preprocess_responsive_image().
        if (!empty($build['#attributes']['sizes'])) {
          $build['#attributes']['override-sizes'] = $build['#attributes']['sizes'];
          unset($build['#attributes']['sizes']);
        }
      }
      else {
        $build['#theme'] = 'image_style';
        $build['#style_name'] = $style;
      }
    }
    else {
      $build['#theme'] = 'image';
    }

    return $build;
  }

  /**
   * Generates a URL from an internal path.
   *
   * @param string $user_input
   *   User input for a link or path.
   * @param array $options
   *   (optional) An array of options.
   *
   * @return ?\Drupal\Core\Url
   *   A new Url object based on user input.
   *
   * @see \Drupal\Core\Url::fromUserInput()
   */
  public function drupalUrl(string $user_input, array $options = []): ?Url {
    if (isset($options['langcode'])) {
      $language = ($this->languageManagerClosure)()->getLanguage($options['langcode']);
      if ($language) {
        $options['language'] = $language;
      }
    }
    if (!in_array($user_input[0], ['/', '#', '?'])) {
      $user_input = '/' . $user_input;
    }
    $url = Url::fromUserInput($user_input, $options);
    if ($url->access()) {
      return $url;
    }
    return NULL;
  }

  /**
   * Returns the URL of this image derivative for an original image path or URI.
   *
   * @param string $path
   *   The path or URI to the original image.
   * @param string $style
   *   The image style.
   *
   * @return ?string
   *   The absolute URL where a style image can be downloaded, suitable for use
   *   in an <img> tag. Requesting the URL will cause the image to be created.
   */
  public function imageStyle(string $path, string $style): ?string {
    $image_style = $this->entityTypeManager->getStorage('image_style')->load('style');
    if ($image_style) {
      return ($this->fileUrlGeneratorClosure)()->transformRelative($image_style->buildUrl($path));
    }
    return NULL;
  }

  /**
   * Returns a URL path to the file.
   *
   * Examples:
   *
   * For string arguments it works similar to core file_url() Twig function.
   * @code
   *   {{ 'public://sea.jpg'|file_url }}
   * @endcode
   *
   * When field item list passed the URL will be extracted from the first item.
   * In order to get URL of specific item specify its delta explicitly using
   * array notation.
   * @code
   *   {{ node.field_image|file_url }}
   *   {{ node.field_image[0]|file_url }}
   * @endcode
   *
   * Media fields are fully supported including OEmbed resources.
   * @code
   *   {{ node.field_media|file_url }}
   * @endcode
   *
   * @param string|object $input
   *   Can be either file URI or an object that contains the URI.
   *
   * @return string|null
   *   A URL that may be used to access the file.
   */
  public function fileUrl(string|object $input): ?string {
    if (is_string($input)) {
      return ($this->fileUrlGeneratorClosure)()->generateString($input);
    }
    if ($input instanceof EntityReferenceFieldItemListInterface) {
      $referenced_entities = $input->referencedEntities();
      if (isset($referenced_entities[0])) {
        return self::getUrlFromEntity($referenced_entities[0]);
      }
    }
    elseif ($input instanceof EntityReferenceItem) {
      return self::getUrlFromEntity($input->entity);
    }
    return NULL;
  }

  /**
   * Extracts file URL form content entity.
   *
   * @param mixed $entity
   *   Entity object that contains information about the file.
   *
   * @return ?string
   *   A URL that may be used to access the file.
   */
  private static function getUrlFromEntity(mixed $entity): ?string {
    if ($entity instanceof MediaInterface) {
      $source = $entity->getSource();
      $value = $source->getSourceFieldValue($entity);
      if ($source instanceof OEmbedInterface) {
        return $value;
      }
      elseif ($file = File::load($value)) {
        return $file->createFileUrl();
      }
    }
    elseif ($entity instanceof FileInterface) {
      return $entity->createFileUrl();
    }
    return NULL;
  }

}
