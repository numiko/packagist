<?php

namespace Drupal\twig_media\Plugin\twig_media\source;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\media\MediaInterface;
use Drupal\media\MediaSourceInterface;
use Drupal\twig_media\Attribute\TwigMediaSourcePlugin;
use Drupal\twig_media\TwigMediaSourcePluginInterface;

/**
 * Provides a base media source twig media plugin.
 */
#[TwigMediaSourcePlugin(
    id: 'base',
    name: new TranslatableMarkup('Base Media Source'),
 )]
class BaseMediaSource extends PluginBase implements TwigMediaSourcePluginInterface {

  /**
   * {@inheritDoc}
   */
  public function getSourceAttributes(MediaInterface $entity) : array {
    $source = $entity->getSource();
    $attributes['fid'] = $source->getSourceFieldValue($entity);
    if (!array_key_exists('alt', $attributes)) {
      $attributes['alt'] = $source->getMetadata($entity, 'thumbnail_alt_value');
    }
    if (!array_key_exists('width', $attributes)) {
      $attributes['width'] = $this->getStoredDimension($entity, $source, 'width');
    }
    if (!array_key_exists('height', $attributes)) {
      $attributes['height'] = $this->getStoredDimension($entity, $source, 'height');
    }
    return $attributes;
  }

  /**
   * Gets an image dimension, preferring the value stored on the field.
   *
   * The core image media source re-derives width/height by opening the
   * source file every time getMetadata() is called, rather than using the
   * value already cached on the source field. That fails whenever the
   * file isn't present locally (e.g. not yet fetched by Stage File Proxy),
   * so prefer the stored field value and only fall back to the live
   * lookup when it isn't available.
   */
  private function getStoredDimension(MediaInterface $entity, MediaSourceInterface $source, string $property): ?int {
    $field_name = $source->getConfiguration()['source_field'] ?? NULL;
    if ($field_name && $entity->hasField($field_name)) {
      $item = $entity->get($field_name)->first();
      if ($item && !empty($item->{$property})) {
        return (int) $item->{$property};
      }
    }
    return $source->getMetadata($entity, $property);
  }

}
