<?php

namespace Drupal\twig_media_focal_point;

use Drupal\focal_point\FocalPointManager;

/**
 * Calculate the focal point for a given image by uri.
 */
class FocalPoint {

  const DEFAULT_POSITION = 'center center';

  /**
   * The focal point manager.
   *
   * @var \Drupal\focal_point\FocalPointManager
   */
  private $focalPointManager;

  /**
   * Set meta tag manager.
   *
   * @param \Drupal\focal_point\FocalPointManager $focalPointManager
   *   Focal point manager.
   */
  public function setFocalPointManager(FocalPointManager $focalPointManager) {
    $this->focalPointManager = $focalPointManager;
  }

  /**
   * Get the focal position for a given file entity.
   */
  public function getFocalPosition($file, $width, $height) {
    if ($file && $this->focalPointManager) {
      /** @var \Drupal\crop\Entity\Crop $crop */
      $crop = $this->focalPointManager->getCropEntity($file, 'focal_point');
      if ($crop) {
        $xPosition = 'center';
        $yPosition = 'center';
        if ($crop->get('x')->value !== NULL) {
          // Get the X position.
          $xPercentage = ($width - $crop->get('x')->value) / $width * 100;
          if ($xPercentage <= 33) {
            $xPosition = 'right';
          }
          elseif ($xPercentage >= 66) {
            $xPosition = 'left';
          }
        }
        if ($crop->get('y')->value !== NULL) {
          // Get the Y position.
          $yPercentage = ($height - $crop->get('y')->value) / $height * 100;
          if ($yPercentage <= 33) {
            $yPosition = 'bottom';
          }
          elseif ($yPercentage >= 66) {
            $yPosition = 'top';
          }
        }
        return $yPosition . ' ' . $xPosition;
      }
    }
    return self::DEFAULT_POSITION;
  }

}
