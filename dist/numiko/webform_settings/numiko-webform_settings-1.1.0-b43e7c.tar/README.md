# Webform Settings

Defaults all new webforms to purge all submissions after 30 days.