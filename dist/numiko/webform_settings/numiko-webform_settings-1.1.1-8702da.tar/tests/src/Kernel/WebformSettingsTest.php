<?php

namespace Drupal\Tests\webform_settings\Kernel;

use Drupal\KernelTests\Core\Entity\EntityKernelTestBase;
use Drupal\webform\Entity\Webform;
use Drupal\webform\Entity\WebformSubmission;

/**
 * Tests that conditions, provided by the webform module, are working properly.
 *
 * @group webform
 */
class WebformSettingsTest extends EntityKernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  public static $modules = ['webform', 'webform_settings'];

  /**
   * Tests conditions.
   */
  public function testDefaultSettings() {
    $this->installSchema('webform', ['webform']);

    $this->createUser();

    // Create a webform.
    $webform = Webform::create(['id' => 'test']);
    $webform->save();

    // Assert that default settings have been applied.
    $this->assertEquals($webform->getSetting('purge'), 'all');
    $this->assertEquals($webform->getSetting('purge_days'), 30);
  }

}
