<?php
namespace Drupal\assigned_content\Controller;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
/**
 * Provides messaging when the assigned content view is missing.
 */
class AssignedContentDashboardController extends ControllerBase {
  /**
   * Renders a warning when the view route has not been created yet.
   *
   * @return array
   *   A renderable array.
   */
  public function missingView(): array {
    $message = $this->t('The Assigned content view has not been installed yet. Please clear the cache first. If this issue persists, please rerun the %recipe recipe and clear caches.', [
      '%recipe' => 'recipes/assigned-content-field-recipe',
    ]);
    $this->messenger()->addWarning($message);
    return [
      '#type' => 'container',
      '#attributes' => [
        'class' => ['assigned-content-missing-dashboard'],
      ],
      'description' => [
        '#markup' => $this->t('Once the recipe finishes provisioning, this tab will display a dashboard of assigned content. In the meantime you can use the <a href=":link">content overview</a>.', [
          ':link' => Url::fromRoute('system.admin_content')->toString(),
        ]),
      ],
    ];
  }
}