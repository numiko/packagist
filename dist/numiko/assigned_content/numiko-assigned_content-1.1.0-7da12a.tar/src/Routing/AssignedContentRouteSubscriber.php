<?php
namespace Drupal\assigned_content\Routing;
use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\Route;
use Symfony\Component\Routing\RouteCollection;
/**
 * Provides a fallback route while the view route is not yet available.
 */
class AssignedContentRouteSubscriber extends RouteSubscriberBase {
  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection) {
    if ($collection->get('view.assigned_content.assigned_content')) {
      return;
    }
    $route = new Route(
      '/admin/content/dashboard',
      [
        '_controller' => '\Drupal\assigned_content\Controller\AssignedContentDashboardController::missingView',
        '_title' => 'Assigned content',
      ],
      [
        '_permission' => 'access content overview',
      ]
    );
    // Flag as placeholder so it's easy to identify in debugging.
    $route->setOption('_view_route_placeholder', TRUE);
    $collection->add('view.assigned_content.assigned_content', $route);
  }
}