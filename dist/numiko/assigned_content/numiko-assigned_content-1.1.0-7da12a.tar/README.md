# Assigned Content

A Drupal module that provides access control for content based on assignees field. This module allows users listed in a `field_assignees` field to edit content, even if they don't normally have permission to edit that content type.

**Note:** This is not a standalone module and should be installed through the accompanying recipe that includes the required view and field configuration.

## What is this module for?

This module provides:
- **Content access control**: Allow specific users to edit content based on assignee field values
- **Dashboard integration**: Provides an "Assigned content" dashboard view for managing assigned content
- **Field automation**: Config action to automatically add assignee fields to all content bundles
- **Recipe integration**: Works with Drupal recipes for streamlined setup

## Requirements

- Drupal 10 or 11
- Content Moderation module
- DateTime module
- Node module
- User module
- Views module

## Installation

1. Install the module using Composer:
   ```bash
   composer require numiko/assigned_content
   ```

2. Enable the module:
   ```bash
   drush en assigned_content
   ```

3. Run the assigned content field recipe to set up the field and view:
   ```bash
   drush recipe recipes/assigned-content-field-recipe
   ```

4. Clear caches:
   ```bash
   drush cr
   ```

## How it works

### Access Control
The module implements `hook_node_access()` to grant edit access to users listed in the `field_assignees` field on content. Users can edit content they're assigned to, regardless of their normal content permissions.

### Dashboard
The module provides an "Assigned content" tab under `/admin/content/dashboard` that shows a view of content assigned to users. If the view hasn't been created yet (before running the recipe), it shows a warning message.

### Config Action
The module includes a config action plugin (`field_storage_config:addToAllContentBundles`) that can automatically add the assignees field to all content bundles, with options to:
- Include/exclude specific bundles
- Set field labels and descriptions
- Apply additional field configuration

## Configuration

### Field Setup
The assignees field (`field_assignees`) should be an entity reference field targeting users. This is typically set up through the accompanying recipe.

### Bundle Exclusions
By default, the config action excludes these bundle types:
- homepage
- listing

You can override this by specifying `bundles` or `exclude_bundles` in your recipe configuration.

## Usage

1. Add users to the `field_assignees` field on any content
2. Those users will be able to edit that content
3. View assigned content through the dashboard at `/admin/content/dashboard`

## Development

### Running Tests
Check your Drupal installation's testing documentation for running PHPUnit tests.

### Code Standards
This module follows Drupal coding standards. Run code quality checks using your project's configured tools.

## License

GPL-2.0+

## Maintainers

- Numiko (https://github.com/numiko)