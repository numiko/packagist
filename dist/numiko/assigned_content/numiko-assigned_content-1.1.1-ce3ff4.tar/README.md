# Assigned Content

A Drupal module that provides access control for content based on assignees field. This module allows users listed in a `field_assignees` field to edit content, even if they don't normally have permission to edit that content type.

**Note:** This is not a standalone module and should be installed through the accompanying recipe that includes the required view and field configuration.

## What is this module for?

This module provides:
- **Content access control**: Allow specific users to edit content based on assignee field values
- **Dashboard integration**: Provides an "Assigned content" dashboard view for managing assigned content
- **Field automation**: Config action to automatically add assignee fields to all content bundles

## Requirements

- Drupal 10 or 11
- Content Moderation module
- DateTime module
- Node module
- User module
- Views module

## Installation

### Recommended: Using the Recipe

Run the assigned content field recipe to install the module and set up the required field and view:
   ```bash
   drush recipe:install
   ```

## How it works

### Access Control
The module implements `hook_node_access()` to grant edit access to users listed in the `field_assignees` field on content. Users can edit content they're assigned to, regardless of their normal content permissions.

### Dashboard
The module provides an "Assigned content" tab under `/admin/content/dashboard` that shows a view of content assigned to users. If the view hasn't been created yet (before running the recipe), it shows a warning message.

### Config Action
The module includes a config action plugin (`field_storage_config:addToAllContentBundles`) that can automatically add the assignees field to all content bundles, with options to:
- Include/exclude specific bundles
- Set field labels and descriptions
- Apply additional field configuration

## Configuration

### Field Setup
The assignees field (`field_assignees`) should be an entity reference field targeting users. This is typically set up through the accompanying recipe.

### Bundle Exclusions
By default, the config action excludes these bundle types:
- homepage
- listing

## Usage

1. Add users to the `field_assignees` field on any content
2. Those users will be able to edit that content
3. View assigned content through the dashboard at `/admin/content/dashboard`
