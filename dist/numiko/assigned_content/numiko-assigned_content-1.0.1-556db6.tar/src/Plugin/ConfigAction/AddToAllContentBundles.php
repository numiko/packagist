<?php

declare(strict_types=1);

namespace Drupal\assigned_content\Plugin\ConfigAction;

use Drupal\Core\Config\Action\Attribute\ConfigAction;
use Drupal\Core\Config\Action\ConfigActionException;
use Drupal\Core\Config\Action\ConfigActionPluginInterface;
use Drupal\Core\Config\ConfigManagerInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\field\FieldStorageConfigInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Adds a field to all content bundles for its target entity type.
 *
 * @internal
 *   This API is experimental.
 */
#[ConfigAction(
  id: 'field_storage_config:addToAllContentBundles',
  admin_label: new TranslatableMarkup('Add a field to all content bundles'),
  entity_types: ['field_storage_config'],
)]
final class AddToAllContentBundles implements ConfigActionPluginInterface, ContainerFactoryPluginInterface {

  /**
   * Bundles to exclude when no specific allow list is provided.
   *
   * These are typically structural bundles rather than editorial content.
   */
  private const DEFAULT_EXCLUDED_BUNDLES = [
    'homepage',
    'listing',
  ];

  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly EntityTypeBundleInfoInterface $entityTypeBundleInfo,
    private readonly ConfigManagerInterface $configManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $container->get(EntityTypeManagerInterface::class),
      $container->get(EntityTypeBundleInfoInterface::class),
      $container->get(ConfigManagerInterface::class),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function apply(string $configName, mixed $value): void {
    assert(is_array($value));

    $field_storage = $this->configManager->loadConfigEntityByName($configName);
    assert($field_storage instanceof FieldStorageConfigInterface);

    $entity_type_id = $field_storage->getTargetEntityTypeId();
    if ($entity_type_id !== 'node') {
      throw new ConfigActionException(sprintf('The "%s" action only supports node field storage.', static::class));
    }

    $storage = $this->entityTypeManager->getStorage('field_config');
    $field_name = $field_storage->getName();

    $existing_fields = $storage->getQuery()
      ->condition('entity_type', $entity_type_id)
      ->condition('field_name', $field_name)
      ->execute();

    $bundles = array_keys($this->entityTypeBundleInfo->getBundleInfo($entity_type_id));
    $bundles = $this->filterBundles($bundles, $value);

    $field_config_overrides = $this->buildFieldConfigOverrides($value);

    foreach ($bundles as $bundle) {
      $id = "$entity_type_id.$bundle.$field_name";
      if (in_array($id, $existing_fields, TRUE)) {
        if (!empty($value['fail_if_exists'])) {
          throw new ConfigActionException(sprintf('Field %s already exists.', $id));
        }
        continue;
      }

      $storage->create([
        'label' => $value['label'] ?? $field_name,
        'bundle' => $bundle,
        'description' => $value['description'] ?? '',
        'field_storage' => $field_storage,
      ] + $field_config_overrides)->save();
    }
  }

  /**
   * Filter the bundles according to the provided configuration.
   *
   * @param array $bundles
   *   All bundles for the entity type.
   * @param array $configuration
   *   Configuration passed to the config action.
   *
   * @return array
   *   Bundles that should receive the field.
   */
  private function filterBundles(array $bundles, array $configuration): array {
    $allow_list = array_values(array_unique(array_filter(
      $configuration['bundles'] ?? [],
      static fn($bundle) => is_string($bundle) && $bundle !== '',
    )));

    $exclude_list = array_values(array_unique(array_filter(
      $configuration['exclude_bundles'] ?? self::DEFAULT_EXCLUDED_BUNDLES,
      static fn($bundle) => is_string($bundle) && $bundle !== '',
    )));

    if ($allow_list !== []) {
      $bundles = array_values(array_intersect($bundles, $allow_list));
    }

    if ($exclude_list !== []) {
      $bundles = array_values(array_diff($bundles, $exclude_list));
    }

    return $bundles;
  }

  /**
   * Prepare additional field config overrides supplied via the recipe.
   *
   * @param array $configuration
   *   Configuration passed to the config action.
   *
   * @return array
   *   Additional values to apply when creating the field config entity.
   */
  private function buildFieldConfigOverrides(array $configuration): array {
    $overrides = $configuration['field_config'] ?? [];
    if (!is_array($overrides)) {
      return [];
    }

    unset(
      $overrides['bundle'],
      $overrides['entity_type'],
      $overrides['field_name'],
      $overrides['field_storage']
    );

    return $overrides;
  }

}
