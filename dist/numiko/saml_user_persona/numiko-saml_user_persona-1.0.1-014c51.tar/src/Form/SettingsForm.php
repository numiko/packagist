<?php

namespace Drupal\saml_user_persona\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form builder for the saml_user_persona settings form.
 */
class SettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'saml_user_persona_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['saml_user_persona.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('saml_user_persona.settings');

    $form['user_info'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('User info and syncing'),
      '#collapsible' => FALSE,
    ];
    $form['user_info']['persona_population'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Automatic persona population from simpleSAMLphp attributes'),
      '#default_value' => $config->get('persona.population'),
      '#description' => $this->t('A pipe separated list of rules. Each rule consists of a Drupal persona id, a SimpleSAML attribute name, an operation and a value to match. <i>e.g. persona_id1:attribute_name,operation,value|persona_id2:attribute_name2,operation,value... etc</i><br /><br />Each operation may be either "@", "@=" or "~=". <ul><li>"=" requires the value exactly matches the attribute;</li><li>"@=" requires the portion after a "@" in the attribute to match the value;</li><li>"~=" allows the value to match any part of any element in the attribute array.</li></ul>For instance:<br /><i>staff:eduPersonPrincipalName,@=,uninett.no;affiliation,=,employee|admin:mail,=,andreas@uninett.no</i><br />would ensure any user with an eduPersonPrinciplaName SAML attribute matching .*@uninett.no would be assigned a staff persona and the user with the mail attribute exactly matching andreas@uninett.no would assume the admin persona.'),

      // A '=' requires the $value exactly matches the $attribute, A '@='
      // requires the portion after a '@' in the $attribute to match
      // theuninett.no $value and a '~=' allows the value to match any part of
      // any element in the $attribute array.
      // The full persona map string, when mapped to the variables below,
      // presents itself thus:
      // $persona_id:$key,$op,$value;$key,$op,$value|$persona_id:$key,$op,$value
      // etc.
    ];
    $form['user_info']['persona_eval_every_time'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Reevaluate personas every time the user logs in'),
      '#default_value' => $config->get('persona.eval_every_time'),
      '#description' => $this->t('NOTE: This means users could lose any personas that have been assigned manually in Drupal.'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);
    $config = $this->config('saml_user_persona.settings');

    $config->set('persona.population', $form_state->getValue('persona_population'));
    $config->set('persona.eval_every_time', $form_state->getValue('persona_eval_every_time'));
    $config->save();
  }

}
