<?php

namespace Drupal\saml_user_persona;

use Psr\Log\LoggerInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Handle rule evaluation to determine persona ID.
 */
class PersonaMapping {

  use StringTranslationTrait;

  /**
   * A configuration object.
   *
   * @var \Drupal\Core\Config\ImmutableConfig
   */
  protected $config;

  /**
   * A logger instance.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * {@inheritdoc}
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The configuration factory.
   * @param \Psr\Log\LoggerInterface $logger
   *   A logger instance.
   */
  public function __construct(ConfigFactoryInterface $config_factory, LoggerInterface $logger) {
    $this->config = $config_factory->get('saml_user_persona.settings');
    $this->logger = $logger;
  }

  /**
   * Get matching user personas to assign to user.
   *
   * Matching personas are based on retrieved SimpleSAMLphp attributes.
   *
   * @param array $attributes
   *   The simplesaml attributes array.
   *
   * @return array
   *   List of matching persona IDs to assign to user.
   */
  public function getMatchingPersonas(array $attributes) {
    $personas = [];
    // Obtain the persona map stored. The persona map is a concatenated string
    // of rules which, when SimpleSAML attributes on the user match, will add
    // personas to the user.
    // The full persona map string, when mapped to the variables below, presents
    // itself thus:
    // $persona_id:$key,$op,$value;$key,$op,$value;|$persona_id:$key,$op,$value
    // etc.
    if ($personamap = $this->config->get('persona.population')) {
      foreach (explode('|', $personamap) as $personarule) {
        list($persona_id, $persona_eval) = explode(':', $personarule, 2);

        foreach (explode(';', $persona_eval) as $persona_eval_part) {
          if ($this->evalPersonaRule($attributes, $persona_eval_part)) {
            $personas[$persona_id] = $persona_id;
          }
        }
      }
    }

    return $personas;
  }

  /**
   * Determines whether a persona should be added to an account.
   *
   * @param array $attributes
   *   The simplesaml attributes array.
   * @param string $persona_eval_part
   *   Part of the persona evaluation rule.
   *
   * @return bool
   *   Whether a persona should be added to the Drupal account.
   */
  protected function evalPersonaRule(array $attributes, $persona_eval_part) {
    list($key, $op, $value) = explode(',', $persona_eval_part);

    if ($this->config->get('debug')) {
      $this->logger->debug('Evaluate rule (key=%key,operator=%op,value=%val', [
        '%key' => $key,
        '%op' => $op,
        '%val' => $value,
      ]);
    }

    if (!array_key_exists($key, $attributes)) {
      return FALSE;
    }
    $attribute = $attributes[$key];

    // A '=' requires the $value exactly matches the $attribute, A '@='
    // requires the portion after a '@' in the $attribute to match the
    // $value and a '~=' allows the value to match any part of any
    // element in the $attribute array.
    switch ($op) {
      case '=':
        return in_array($value, $attribute);

      case '@=':
        list($before, $after) = explode('@', $attribute);
        return ($after == $value);

      case '~=':
        return array_filter($attribute, function ($subattr) use ($value) {
          return strpos($subattr, $value) !== FALSE;
        });
    }
  }

}
