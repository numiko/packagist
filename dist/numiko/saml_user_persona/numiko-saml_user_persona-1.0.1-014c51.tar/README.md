# SAML User Persona

Allows a user to have 1 or more personas mapped from SAML user roles.

## Settings

The settings form persona mapping field expects a pipe separated list of rules. Each rule consists of a Drupal persona id, a SimpleSAML attribute name, an operation and a value to match. `e.g. persona_id1:attribute_name,operation,value|persona_id2:attribute_name2,operation,value... etc`

Each operation may be either "@", "@=" or "~=".

* "=" requires the value exactly matches the attribute;
* "@=" requires the portion after a "@" in the attribute to match the value;
* "~=" allows the value to match any part of any element in the attribute array.

For instance:
`staff:eduPersonPrincipalName,@=,uninett.no;affiliation,=,employee|admin:mail,=,andreas@uninett.no`
would ensure any user with an eduPersonPrinciplaName SAML attribute matching .*@uninett.no would be assigned a staff persona and the user with the mail attribute exactly matching andreas@uninett.no would assume the admin persona.