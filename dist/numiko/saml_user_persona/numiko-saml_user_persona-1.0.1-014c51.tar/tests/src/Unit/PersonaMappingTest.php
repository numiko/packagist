<?php

namespace Drupal\Tests\saml_user_persona\Unit;

use Drupal\Tests\UnitTestCase;
use Drupal\saml_user_persona\PersonaMapping;

/**
 * PersonaMapping unit tests.
 *
 * @ingroup saml_user_persona
 *
 * @group saml_user_persona
 *
 * @coversDefaultClass \Drupal\saml_user_persona\PersonaMapping
 */
class PersonaMappingTest extends UnitTestCase {

  /**
   * A mocked config factory instance.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $configFactory;

  /**
   * The mocked logger instance.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit_Framework_MockObject_MockObject
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp() : void {
    parent::setUp();

    $this->configFactory = $this->getConfigFactoryStub([
      'saml_user_persona.settings' => [
        'persona' => [
          'population' => 'siteadmin:roles,=,admin|manager:roles,=,CMSManager|editor:roles,=,CMSEditor',
          'eval_every_time' => TRUE,
        ],
      ],
    ]);

    $this->logger = $this->getMockBuilder('\Psr\Log\LoggerInterface')
      ->disableOriginalConstructor()
      ->getMock();

  }

  /**
   * Get a new persona mapping instance using mocked constructor arguments.
   *
   * @return \Drupal\saml_user_persona\PersonaMapping
   *   A mocked persona mapping.
   */
  protected function getPersonaMappingInContext() {
    return new PersonaMapping(
      $this->configFactory,
      $this->logger,
    );
  }

  /**
   * Tests getMatchingPersonas() method.
   *
   * @covers ::__construct
   * @covers ::getMatchingPersonas
   */
  public function testMatchingExactPersona() {
    $mapping = $this->getPersonaMappingInContext();

    $attributes = [
      'uid' => ['admin_123'],
      'name' => ['Admin 123'],
      'mail' => ['admin_123@example.com'],
      'roles' => ['admin'],
    ];
    $personas = $mapping->getMatchingPersonas($attributes);

    $this->assertContains('siteadmin', $personas);
  }

  /**
   * Tests getMatchingPersonas() method.
   *
   * @covers ::__construct
   * @covers ::getMatchingPersonas
   */
  public function testMatchingPersonaAndIgnoresExtra() {
    $mapping = $this->getPersonaMappingInContext();

    $attributes = [
      'uid' => ['admin_123'],
      'name' => ['Admin 123'],
      'mail' => ['admin_123@example.com'],
      'roles' => ['admin', 'webmaster'],
    ];
    $personas = $mapping->getMatchingPersonas($attributes);

    $this->assertContains('siteadmin', $personas);
  }

  /**
   * Tests getMatchingPersonas() method.
   *
   * @covers ::__construct
   * @covers ::getMatchingPersonas
   */
  public function testMatchingMultiplePersona() {
    $mapping = $this->getPersonaMappingInContext();

    $attributes = [
      'uid' => ['manager_123'],
      'name' => ['Manager 123'],
      'mail' => ['manager_123@example.com'],
      'roles' => ['CMSManager', 'CMSEditor'],
    ];
    $personas = $mapping->getMatchingPersonas($attributes);

    $this->assertContains('editor', $personas);
    $this->assertContains('manager', $personas);
  }

}
