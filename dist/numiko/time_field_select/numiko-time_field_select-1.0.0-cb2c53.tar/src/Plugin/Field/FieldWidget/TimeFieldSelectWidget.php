<?php

namespace Drupal\time_field_select\Plugin\Field\FieldWidget;

use Drupal\Core\Field\WidgetBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Field\FieldItemListInterface;

/**
 * Allows a time to be selected from a list.
 *
 * @FieldWidget(
 *   id = "time_field_select",
 *   label = @Translation("Time Field Select list"),
 *   field_types = {
 *     "string"
 *   }
 * )
 */
class TimeFieldSelectWidget extends WidgetBase {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return [
      'mins_increment' => 5,
    ] + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $element['mins_increment'] = [
      '#type' => 'number',
      '#title' => t('Mins. increment'),
      '#default_value' => $this->getSetting('mins_increment'),
      '#required' => TRUE,
      '#min' => 1,
      '#max' => 30,
    ];
    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = [];

    $summary[] = t('Time select field: @mins_increment', ['@mins_increment' => $this->getSetting('mins_increment')]);

    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    $element['value'] = $element + [
      '#type' => 'select',
      '#options' => $this->getTimeOptions(),
      '#default_value' => $items[$delta]->value ?? NULL,
    ];

    return $element;
  }

  /**
   * Get the time options for the select widget.
   */
  protected function getTimeOptions() {
    $options = [''];

    foreach (['am', 'pm'] as $period) {
      for ($i = 0; $i < 12; $i++) {
        for ($j = 0; $j < 60; $j += $this->getSetting('mins_increment')) {
          $time = sprintf('%d:%02d %s', ($i == 0) ? 12 : $i, $j, $period);
          $options[$time] = $time;
        }
      }
    }

    return $options;
  }

}
