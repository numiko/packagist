# OpenID Azure Recipe

This recipe installs the necessary modules for OpenID Azure.

## Installation

The following will need to be obtained from the client:

1. Client ID
2. Client Secret
3. Authorization endpoint
4. Token endpoint

We need to provide them with the `Redirect URL`.

Client ID, Authorization endpoint, Token endpoint need to be set within `/admin/config/people/openid-connect/sso`

Client Secret should be placed in an env variable named `SSO_CLIENT_SHARED_SECRET`

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/openid-azure-recipe`
