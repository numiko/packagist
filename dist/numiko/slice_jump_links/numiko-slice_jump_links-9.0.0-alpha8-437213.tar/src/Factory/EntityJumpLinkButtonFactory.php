<?php

namespace Drupal\slice_jump_links\Factory;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\slice_jump_links\Entity\JumpLinkButton;
use Drupal\slice_jump_links\Exception\JumpLinkException;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Contains factory for creating jump link items from slices.
 *
 * This is used both to build jump links on slices and to collect them.
 *
 * @extends AbstractEntityJumpLinkFactory<\Drupal\slice_jump_links\Entity\JumpLinkButton>
 */
class EntityJumpLinkButtonFactory extends AbstractEntityJumpLinkFactory {

  public function __construct(
    LanguageManagerInterface $languageManager,
    #[Autowire(service: 'cache.default')]
    CacheBackendInterface $cache,
  ) {
    $this->languageManager = $languageManager;
    $this->cache = $cache;
  }

  /**
   * {@inheritDoc}
   */
  protected function getLanguageManager(): LanguageManagerInterface {
    return $this->languageManager;
  }

  /**
   * {@inheritDoc}
   */
  protected function getCache(): CacheBackendInterface {
    return $this->cache;
  }

  /**
   * {@inheritDoc}
   */
  protected function getJumpLinkType(): string {
    return 'jump_link_button';
  }

  /**
   * Create a button from an entity with a CTA field.
   */
  public function create(FieldableEntityInterface $entity): JumpLinkButton {
    if (!$entity->hasField(static::CTA_FIELD) || $entity->get(static::CTA_FIELD)->isEmpty()) {
      throw new JumpLinkException('No populated CTA field');
    }

    $jumpLinkButton = new JumpLinkButton();

    $ctaValue = $entity->get(static::CTA_FIELD)->first();
    if ($ctaValue && $ctaValue->getValue()) {
      $jumpLinkButton->setLabel($ctaValue->getValue()['title']);
    }
    else {
      throw new JumpLinkException('CTA field is empty');
    }
    if ($ctaValue->getUrl()) {
      $jumpLinkButton->setLink($ctaValue->getUrl());
    }

    if ($jumpLinkButton->isEmpty()) {
      throw new JumpLinkException('Not enough information to create a jump link button');
    }

    return $jumpLinkButton;
  }

}
