<?php

namespace Drupal\slice_jump_links\ItemList;

use Drupal\slice_jump_links\Entity\JumpLink;
use Drupal\slice_jump_links\Entity\JumpLinkButton;

/**
 * Contains a list of jump links (with CTA functionality).
 */
class JumpLinkItemList {

  /**
   * Jump links.
   *
   * @var list<\Drupal\slice_jump_links\Entity\JumpLink>
   */
  protected array $items = [];

  /**
   * Jump link buttons.
   *
   * @var list<\Drupal\slice_jump_links\Entity\JumpLinkButton>
   */
  protected array $buttons = [];

  /**
   * Add an item to the jump link list.
   */
  public function addItem(JumpLink $item): self {
    // Don't add items that only have anchors (no labels) to the visible list.
    //
    // This used to be done when the jump link was created but we do it here
    // instead as that way was quite confusing.
    if (!$item->justAnchor()) {
      $this->items[] = $item;
    }
    return $this;
  }

  /**
   * Add an item to the beginning jump link list.
   */
  public function addItemToBeginning(JumpLink $item): self {
    // Don't add items that only have anchors (no labels) to the visible list.
    //
    // This used to be done when the jump link was created but we do it here
    // instead as that way was quite confusing.
    if (!$item->justAnchor()) {
      array_unshift($this->items, $item);
    }
    return $this;
  }

  /**
   * Getter for items.
   *
   * @return list<\Drupal\slice_jump_links\Entity\JumpLink>
   *   Jump link items.
   */
  public function getItems(): array {
    return $this->items;
  }

  /**
   * Add a button to the jump link list.
   */
  public function addButton(JumpLinkButton $button): self {
    $this->buttons[] = $button;
    return $this;
  }

  /**
   * Getter for buttons.
   *
   * @return list<\Drupal\slice_jump_links\Entity\JumpLinkButton>
   *   Jump link buttons.
   */
  public function getButtons(): array {
    return $this->buttons;
  }

  /**
   * Are both lists of items and buttons empty?
   */
  public function isEmpty(): bool {
    return (empty($this->items) && empty($this->buttons)) ? TRUE : FALSE;
  }

  /**
   * Clear out the items from the jump link.
   */
  public function clearItems(): self {
    $this->items = [];
    return $this;
  }

}
