<?php

namespace Drupal\slice_jump_links\tests\Unit\Entity;

use Drupal\Tests\UnitTestCase;
use Drupal\slice_jump_links\Entity\JumpLinkButton;

/**
 * Check the jump link button object functions correctly.
 *
 * @group phpunit_example
 */
class JumpLinkButtonTest extends UnitTestCase {

  protected $jumpLinkButton;

  /**
   * Before a test method is run, setUp() is invoked.
   * Create new jump link button object.
   */
  public function setUp() {
    $this->jumpLinkButton = new JumpLinkButton();
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLinkButton::setLabel
   */
  public function testSetLabel() {
    $this->assertEquals(0, $this->jumpLinkButton->getLabel());
    $label = "Test Label";
    $this->jumpLinkButton->setLabel($label);
    $this->assertEquals($label, $this->jumpLinkButton->getLabel());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLinkButton::getAnchor
   */
  public function testGetAnchor() {
    $anchor = "test-label";
    $label = "Test Label";
    $this->jumpLinkButton->setLabel($label);
    $this->assertEquals($anchor, $this->jumpLinkButton->getAnchor());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLinkButton::getAnchor
   */
  public function testGetAnchorMultipleSpaces() {
    $anchor = "test-label";
    $label = "Test   Label  ";
    $this->jumpLinkButton->setLabel($label);
    $this->assertEquals($anchor, $this->jumpLinkButton->getAnchor());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLinkButton::getAnchor
   */
  public function testGetAnchorNumeric() {
    $anchor = "test12-label-123";
    $label = "Test12 Label 123";
    $this->jumpLinkButton->setLabel($label);
    $this->assertEquals($anchor, $this->jumpLinkButton->getAnchor());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLinkButton::getAnchor
   */
  public function testGetAnchorSpecialChars() {
    $anchor = "test-label";
    $label = "Test L£$%@$%£~''abel";
    $this->jumpLinkButton->setLabel($label);
    $this->assertEquals($anchor, $this->jumpLinkButton->getAnchor());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLinkButton::setAnchor
   */
  public function testSetAnchor() {
    $anchor = "test-anchor";
    $this->jumpLinkButton->setAnchor($anchor);
    $this->assertEquals($anchor, $this->jumpLinkButton->getAnchor());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLinkButton::getLink
   */
  public function testGetLinkFromAnchor() {
    $anchor = "test-anchor";
    $this->jumpLinkButton->setAnchor($anchor);
    $this->assertEquals('#' . $anchor, $this->jumpLinkButton->getLink());
  }

  /**
   * @covers Drupal\slice_jump_links\Entity\JumpLinkButton::setLink
   */
  public function testSetLink() {
    $anchor = "test-anchor";
    $this->jumpLinkButton->setAnchor($anchor);
    $link = "http://www.google.com";
    $this->jumpLinkButton->setLink($link);
    $this->assertEquals($link, $this->jumpLinkButton->getLink());
  }



  /**
   * Once test method has finished running, whether it succeeded or failed, tearDown() will be invoked.
   * Unset the $jumpLink object.
   */
  public function tearDown() {
    unset($this->jumpLinkButton);
  }

}
