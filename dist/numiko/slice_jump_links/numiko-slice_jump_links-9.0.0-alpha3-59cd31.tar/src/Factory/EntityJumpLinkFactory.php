<?php

namespace Drupal\slice_jump_links\Factory;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\slice_jump_links\Entity\JumpLink;
use Drupal\slice_jump_links\Exception\JumpLinkException;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Contains factory for creating jump link items from slice.
 *
 * @extends AbstractEntityJumpLinkFactory<\Drupal\slice_jump_links\Entity\JumpLink>
 */
class EntityJumpLinkFactory extends AbstractEntityJumpLinkFactory {

  public function __construct(
    protected LanguageManagerInterface $languageManager,
    #[Autowire(service: 'cache.default')]
    protected CacheBackendInterface $cache,
  ) {}

  /**
   * {@inheritDoc}
   */
  protected function getLanguageManager(): LanguageManagerInterface {
    return $this->languageManager;
  }

  /**
   * {@inheritDoc}
   */
  protected function getCache(): CacheBackendInterface {
    return $this->cache;
  }

  /**
   * {@inheritDoc}
   */
  protected function getJumpLinkType(): string {
    return 'jump_link_button';
  }

  /**
   * Create a jump link item from an entity with a jump link field.
   */
  public function create(FieldableEntityInterface $entity): JumpLink {
    // If there are more than one translations associated with a revision in a
    // slice then make sure to use the correct language.
    if ($entity->isTranslatable()) {
      $langcode = $this->languageManager->getCurrentLanguage()->getId();
      if ($entity->hasTranslation($langcode)) {
        $entity = $entity->getTranslation($langcode);
      }
    }

    $jumpLink = new JumpLink();

    if ($entity->hasField(static::JUMP_LINK_FIELD) && !$entity->get(static::JUMP_LINK_FIELD)->isEmpty()) {
      $jumpLink->setLabel($entity->get(static::JUMP_LINK_FIELD)->first()->getString());
    }

    if ($entity->hasField(static::ANCHOR_FIELD) && !$entity->get(static::ANCHOR_FIELD)->isEmpty()) {
      $jumpLink->setAnchor($entity->get(static::ANCHOR_FIELD)->first()->getString());
    }

    if ($jumpLink->isEmpty()) {
      throw new JumpLinkException('Not enough information to create a jump link');
    }

    return $jumpLink;

  }

}
