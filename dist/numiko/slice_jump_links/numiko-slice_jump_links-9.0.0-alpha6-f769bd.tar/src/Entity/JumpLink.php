<?php

namespace Drupal\slice_jump_links\Entity;

use Drupal\slice_jump_links\Exception\JumpLinkException;

/**
 * Contains a jump link entity.
 */
class JumpLink {

  /**
   * The jump link label (what the user sees in the jump link block)
   *
   * @var ?string
   */
  protected ?string $label = NULL;

  /**
   * The jump link anchor (the id of the paragraph we jump too)
   *
   * @var ?string
   */
  protected ?string $anchor = NULL;

  /**
   * Set the jump link label.
   */
  public function setLabel(string $label): self {
    $this->label = $label;
    return $this;
  }

  /**
   * Fetch the jump link label, if it is set.
   *
   * @return ?string
   *   The jump link label.
   */
  public function getLabel(): ?string {
    return $this->label;
  }

  /**
   * Set the jump link anchor.
   */
  public function setAnchor(string $anchor): self {
    $this->anchor = $anchor;
    return $this;
  }

  /**
   * Get the anchor; uses the label if no explicit anchor is set.
   */
  public function getAnchor(): ?string {
    $anchor = $this->anchor;
    if (!$anchor) {
      $label = $this->getLabel();
      if (!$label) {
        throw new JumpLinkException('Neither label nor anchor are set.');
      }
      $anchor = $label;
    }
    return $this->sanitizeAnchor($anchor);
  }

  /**
   * Santitize the given anchor.
   *
   * Using regex we will create a default anchor, replacing any amount
   * of spaces with a single hyphen and removing any non-alpha numeric
   * characters (except hyphens).
   *
   * @return ?string
   *   A sanitized anchor.
   */
  protected function sanitizeAnchor(string $anchor): ?string {
    return preg_replace('/[^\da-z\-]/i', '', preg_replace('/[ -]+/', '-', trim(strtolower($anchor))));
  }

  /**
   * Is just the anchor set.
   */
  public function justAnchor(): bool {
    if (!$this->label) {
      return TRUE;
    }
    return FALSE;
  }

  /**
   * Is this jump link empty?
   */
  public function isEmpty(): bool {
    if ($this->label || $this->anchor) {
      return FALSE;
    }
    return TRUE;
  }

}
