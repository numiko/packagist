<?php

namespace Drupal\slice_jump_links\Exception;

/**
 * This exception is thrown when a jump link cannot be created.
 */
class JumpLinkException extends \Exception {}
