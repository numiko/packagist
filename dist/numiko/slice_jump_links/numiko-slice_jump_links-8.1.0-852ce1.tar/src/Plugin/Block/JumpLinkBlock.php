<?php

namespace Drupal\slice_jump_links\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Block\BlockPluginInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a block for displaying jump links
 *
 * @Block(
 *   id = "jump_link_block",
 *   admin_label = @Translation("Jump link block"),
 * )
 */
class JumpLinkBlock extends BlockBase implements BlockPluginInterface {
  /**
   * {@inheritdoc}
   */
  public function build() {
    $config = $this->getConfiguration();
    $node = \Drupal::routeMatch()->getParameter('node');
    if ($node) {
      $jumpLinkList = \Drupal::Service('jump_link.list.factory.node')->fetch($node);
      if (!$jumpLinkList->isEmpty()) {
        return [
          '#theme' => 'slice_jump_links',
          '#list' => $jumpLinkList,
        ];
      }
    }
    return [];
  }
}