<?php

namespace Drupal\slice_jump_links\Factory;

use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Component\Utility\Timer;
use Drupal\node\NodeInterface;
use Drupal\slice_jump_links\Exception\JumpLinkException;
use Drupal\slice_jump_links\ItemList\JumpLinkItemList;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Contains factory for creating jump link list from node with slices.
 */
class NodeJumpLinkListFactory {
  const CACHING_ENABLED = TRUE;

  const SLICE_ENTITY_TYPE = 'paragraph';

  public function __construct(
    protected LanguageManagerInterface $languageManager,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ModuleHandlerInterface $moduleHandler,
    protected EntityJumpLinkFactory $jumpLinkFactory,
    protected EntityJumpLinkButtonFactory $jumpLinkButtonFactory,
    #[Autowire(service: 'cache.default')]
    protected CacheBackendInterface $cache,
  ) {}

  /**
   * Fetch the jump link list.
   */
  public function fetch(NodeInterface $node) {
    Timer::start('node_jump_links');

    $cache_key = ['slice_jump_links', 'list'];
    $cache_key[] = $this->languageManager->getCurrentLanguage()->getId();
    $cache_key[] = $node->getRevisionId();
    $cache_key[] = $node->get('changed')->first()->getValue()['value'];
    $cid = implode(':', $cache_key);

    $data = NULL;
    if (static::CACHING_ENABLED && $cache = $this->cache->get($cid)) {
      $data = $cache->data;
    }
    else {
      $data = $this->create($node);
      $this->cache->set($cid, $data);
    }

    return $data;
  }

  /**
   * Create a jump link list from an entity with a slices field.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node.
   *
   * @return \Drupal\slice_jump_links\ItemList\JumpLinkItemList
   *   Jump links.
   */
  public function create(NodeInterface $node): JumpLinkItemList {
    $jumpLinkList = new JumpLinkItemList();

    // Create the initial node jump link.
    try {
      $jumpLink = $this->jumpLinkFactory->fetch($node);
      $jumpLinkList->addItem($jumpLink);
    }
    catch (JumpLinkException $e) {
      // This is a non-jump linkable slice.
    }

    // Create a jump link for each of the slices.
    $slices = [];
    foreach ($node->getFieldDefinitions() as $field_name => $field) {
      $fieldStorage = $field->getFieldStorageDefinition();
      if ($fieldStorage->getType() == 'entity_reference_revisions' && $fieldStorage->getSetting('target_type') == self::SLICE_ENTITY_TYPE) {
        foreach ($node->get($field_name) as $slice) {
          $slices[] = $slice->getValue()['target_revision_id'];
        }
      }
    }

    if ($slices) {
      foreach ($this->entityTypeManager->getStorage(self::SLICE_ENTITY_TYPE)->loadMultipleRevisions($slices) as $slice) {
        if (!$slice->isPublished()) {
          continue;
        }
        try {
          $jumpLink = $this->jumpLinkFactory->fetch($slice);
          $jumpLinkList->addItem($jumpLink);
        }
        catch (JumpLinkException $e) {
          // This is a non-jump linkable slice.
        }
      }
    }

    // Create the CTA button.
    try {
      $jumpLinkButton = $this->jumpLinkButtonFactory->fetch($node);
      $jumpLinkList->addButton($jumpLinkButton);
    }
    catch (JumpLinkException $e) {
      // This is a non-jump linkable slice.
    }

    $this->moduleHandler->alter('slice_jump_links', $jumpLinkList, $node);

    return $jumpLinkList;
  }

}
