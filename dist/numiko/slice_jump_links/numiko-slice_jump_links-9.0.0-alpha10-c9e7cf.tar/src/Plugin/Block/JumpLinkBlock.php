<?php

namespace Drupal\slice_jump_links\Plugin\Block;

use Drupal\Core\Block\Attribute\Block;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Cache\Cache;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\Context\EntityContextDefinition;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\node\NodeInterface;
use Drupal\slice_jump_links\Factory\NodeJumpLinkListFactory;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a block for displaying jump links.
 */
#[Block(
  id: 'jump_link_block',
  admin_label: new TranslatableMarkup('Jump link block'),
  context_definitions: [
    'node' => new EntityContextDefinition('entity:node', new TranslatableMarkup('Node')),
  ],
)]
class JumpLinkBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * Jump link factory to generate jump links.
   */
  protected NodeJumpLinkListFactory $nodeJumpLinkListFactory;

  /**
   * Current route.
   */
  protected RouteMatchInterface $currentRouteMatch;

  /**
   * Language manager.
   */
  protected LanguageManagerInterface $languageManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    $instance = new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
    );

    $instance->currentRouteMatch = $container->get(RouteMatchInterface::class);
    $instance->nodeJumpLinkListFactory = $container->get(NodeJumpLinkListFactory::class);
    $instance->languageManager = $container->get(LanguageManagerInterface::class);
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function build(): array {
    $node = $this->getContextValue('node');
    if ($node instanceof NodeInterface) {
      // If the node has been translated, get the translated version of the node
      // instead.
      if ($node->isTranslatable()) {
        $langcode = $this->languageManager->getCurrentLanguage()->getId();
        if ($node->hasTranslation($langcode)) {
          $node = $node->getTranslation($langcode);
        }
      }
      $jumpLinkList = $this->nodeJumpLinkListFactory->fetch($node);
      if (!$jumpLinkList->isEmpty()) {
        return [
          '#theme' => 'slice_jump_links',
          '#list' => $jumpLinkList,
        ];
      }
    }
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts(): array {
    return Cache::mergeContexts(parent::getCacheContexts(), ['url']);
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheTags(): array {
    $tags = ['block:jump_link_block'];
    $node = $this->currentRouteMatch->getParameter('node');
    if ($node instanceof NodeInterface) {
      $tags[] = 'node:' . $node->id();
    }
    return Cache::mergeTags(parent::getCacheTags(), $tags);
  }

}
