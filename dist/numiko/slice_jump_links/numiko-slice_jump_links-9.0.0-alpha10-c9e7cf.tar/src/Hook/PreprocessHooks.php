<?php

namespace Drupal\slice_jump_links\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\slice_jump_links\Exception\JumpLinkException;
use Drupal\slice_jump_links\Factory\EntityJumpLinkFactory;

/**
 * These hooks actually add the jump links to the node.
 */
final class PreprocessHooks {

  public function __construct(protected EntityJumpLinkFactory $entityJumpLinkFactory) {}

  /**
 * Implements hook_preprocess_node().
 *
 * Adds a jump link to a slice if the jump link label fields have been added.
 */
  #[Hook('preprocess_node')]
  public function preprocesssNode(array &$variables): void {
    if ($variables['view_mode'] == 'full') {
      try {
        /** @var \Drupal\node\NodeInterface $node */
        $node = $variables['elements']['#node'];
        $variables['jump_link'] = $this->entityJumpLinkFactory->fetch($node);
      }
      catch (JumpLinkException $e) {
        // This is a non-jump linkable node.
      }
    }
  }

  /**
   * Implements hook_preprocess_paragraph().
   *
   * Adds a jump link to a slice if the anchor or jump link label fields have
   * been added.
   */
  #[Hook('preprocess_paragraph')]
  public function preprocesssParagraph(array &$variables): void {
    try {
      /** @var \Drupal\paragraphs\ParagraphInterface $slice */
      $slice = $variables['elements']['#paragraph'];
      $variables['jump_link'] = $this->entityJumpLinkFactory->fetch($slice);
    }
    catch (JumpLinkException $e) {
      // This is a non-jump linkable slice.
    }
  }

}
