<?php

namespace Drupal\slice_jump_links\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Hooks for slice_jump_links.
 *
 * Preprocess hooks are in their own file.
 */
final class SliceJumpLinksHooks {
  use StringTranslationTrait;

  public function __construct(TranslationInterface $stringTranslation) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Implements hook_help().
   */
  #[Hook('help')]
  public function help(string $route_name): string {
    switch ($route_name) {
      // Main module help for the slice_jump_links module.
      case 'help.page.slice_jump_links':
        $output = '';
        $output .= '<h3>' . $this->t('About') . '</h3>';
        $output .= '<p>' . $this->t('Add jump links from slices') . '</p>';
        return $output;

      default:
        return '';
    }
  }

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'slice_jump_links' => [
        'template' => 'slice_jump_links',
        'render element' => 'children',
        'variables' => [
          'list' => [],
        ],
      ],
    ];
  }

}
