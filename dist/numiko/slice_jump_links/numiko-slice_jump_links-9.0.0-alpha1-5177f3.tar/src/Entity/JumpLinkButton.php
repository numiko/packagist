<?php

namespace Drupal\slice_jump_links\Entity;

/**
 * Contains factory for creating jump link list from node with slices.
 */
class JumpLinkButton extends JumpLink {

  /**
   * The jump link itself as a link.
   */
  protected ?string $link;

  /**
   * Get the set link.
   */
  public function setLink(string $link): self {
    $this->link = $link;
    return $this;
  }

  /**
   * Get a link to this jump link.
   */
  public function getLink(): string {
    if ($this->link) {
      return $this->link;
    }
    else {
      return '#' . $this->getAnchor();
    }
  }

  /**
   * Is this jump link empty?
   */
  public function isEmpty(): bool {
    if ($this->label || $this->link) {
      return FALSE;
    }
    return TRUE;
  }

}
