<?php

namespace Drupal\slice_jump_links\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Cache\Cache;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\node\NodeInterface;
use Drupal\slice_jump_links\Factory\NodeJumpLinkListFactory;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Language\LanguageInterface;

/**
 * Provides a block for displaying jump links.
 *
 * @Block(
 *   id = "jump_link_block",
 *   admin_label = @Translation("Jump link block"),
 *   context_definitions = {
 *     "node" = @ContextDefinition("entity:node", label = @Translation("Node"))
 *   }
 * )
 */
class JumpLinkBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * @var \Drupal\slice_jump_links\Factory\NodeJumpLinkListFactory
   */
  private $nodeJumpLinkListFactory;

  /**
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  private $currentRouteMatch;

  /**
   * {@inheritdoc}
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, RouteMatchInterface $current_route_match, NodeJumpLinkListFactory $node_jump_link_list_factory) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->currentRouteMatch = $current_route_match;
    $this->nodeJumpLinkListFactory = $node_jump_link_list_factory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_route_match'),
      $container->get('jump_link.list.factory.node')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $node = $this->getContextValue('node');
    if ($node instanceof NodeInterface) {
      // If the node has been translated, get the translated version of the node
      // instead.
      if ($node->isTranslatable()) {
        $langcode = \Drupal::languageManager()->getCurrentLanguage()->getId();
        if ($node->hasTranslation($langcode)) {
          $node = $node->getTranslation($langcode);
        }
      }
      $jumpLinkList = $this->nodeJumpLinkListFactory->fetch($node);
      if (!$jumpLinkList->isEmpty()) {
        return [
          '#theme' => 'slice_jump_links',
          '#list' => $jumpLinkList,
        ];
      }
    }
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts() {
    return Cache::mergeContexts(parent::getCacheContexts(), ['url']);
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheTags() {
    $tags = ['block:jump_link_block'];
    $node = $this->currentRouteMatch->getParameter('node');
    if ($node instanceof NodeInterface) {
      $tags[] = 'node:' . $node->id();
    }
    return Cache::mergeTags(parent::getCacheTags(), $tags);
  }

}
