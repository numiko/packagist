<?php

namespace Drupal\slice_jump_links\Factory;

use Drupal\slice_jump_links\Entity\JumpLink;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Language\LanguageManagerInterface;

/**
 * Contains factory for creating jump link items from slice.
 *
 * @template T of \Drupal\slice_jump_links\Entity\JumpLink
 */
abstract class AbstractEntityJumpLinkFactory {

  const JUMP_LINK_FIELD = 'field_jump_link_label';
  const CTA_FIELD = 'field_jump_links_cta';
  const ANCHOR_FIELD = 'field_anchor';

  const CACHING_ENABLED = TRUE;

  /**
   * The jump link type (PHP doesn't have abstract class constants).
   */
  abstract protected function getJumpLinkType(): string;

  /**
   * Returns the injected language manager service.
   */
  abstract protected function getLanguageManager(): LanguageManagerInterface;

  /**
   * Returns the injected cache service.
   */
  abstract protected function getCache(): CacheBackendInterface;

  /**
   * Fetch a jump link or jump link button.
   *
   * @param \Drupal\Core\Entity\FieldableEntityInterface $entity
   *   Entity to get jump link from.
   *
   * @return T
   *   The jump link.
   */
  public function fetch(FieldableEntityInterface $entity): JumpLink {
    $jumpLinkType = $this->getJumpLinkType();

    $cache_key = ['slice_jump_links', $jumpLinkType, 'entity'];
    $cache_key[] = $this->getLanguageManager()->getCurrentLanguage()->getId();
    $cache_key[] = $entity->getType();
    $cache_key[] = $entity->getRevisionId();
    if ($entity->hasField('changed')) {
      $cache_key[] = $entity->get('changed')->first()->getValue()['value'];
    }
    else {
      // For paragraphs we take the parent entity to get the changed date.
      $parent = $entity->getParentEntity();
      if ($parent) {
        if ($parent->hasField('changed')) {
          $cache_key[] = $parent->get('changed')->first()->getValue()['value'];
        }
      }
    }
    $cid = implode(':', $cache_key);

    $cacheService = $this->getCache();

    $data = NULL;
    if (static::CACHING_ENABLED && $cache = $cacheService->get($cid)) {
      /** @var T $cacheData */
      $cacheData = $cache->data;
      return $cacheData;
    }
    else {
      $data = $this->create($entity);
      $cacheService->set($cid, $data);
    }

    return $data;
  }

  /**
   * Create a jump link item from an entity.
   *
   * @param \Drupal\Core\Entity\FieldableEntityInterface $entity
   *   The entity.
   *
   * @return T
   *   The jump link.
   */
  abstract public function create(FieldableEntityInterface $entity): JumpLink;

}
