<?php

namespace Drupal\simple_domain_path\Plugin\Validation\Constraint;

use Symfony\Component\Validator\Constraint;

/**
 * Validation constraint for unique path alias values per-domain.
 *
 * @Constraint(
 *   id = "UniqueDomainPathAlias",
 *   label = @Translation("Unique path alias on a domain.", context = "Validation"),
 * )
 */
class UniqueDomainPathAliasConstraint extends Constraint {

  /**
   * The default violation message.
   *
   * @var string
   */
  public $message = 'The alias %alias is already in use in this language on this domain.';

  /**
   * Violation message when the path alias exists with different capitalization.
   *
   * @var string
   */
  public $differentCapitalizationMessage = 'The alias %alias could not be added because it is already in use in this language on this domain with different capitalization: %stored_alias.';

}
