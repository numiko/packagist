<?php

namespace Drupal\simple_domain_path\PathProcessor;

use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\Core\PathProcessor\InboundPathProcessorInterface;
use Drupal\Core\PathProcessor\OutboundPathProcessorInterface;
use Drupal\simple_domain_path\SupportedEntities;
use Symfony\Component\HttpFoundation\Request;
use Drupal\domain\DomainNegotiatorInterface;
use Drupal\path_alias\AliasManagerInterface;

/**
 * A simple_domain_path processor for inbound and outbound paths.
 *
 * This class has been copied from the domain_path module and modified to
 * query the modified path_alias table rather than a custom domain_path table.
 *
 * This processor is meant to override the core alias processing when a domain
 * path exists for the current domain. For this reason the processing order is
 * important. The inbound processing needs to happen before the path module
 * alias processor so that we can turn domain path aliases into system paths
 * first. The outbound processing needs to happen after path module alias
 * processing so that we can be sure it doesn't mess with our domain path alias
 * after we're done with it.
 */
class DomainPathProcessor implements InboundPathProcessorInterface, OutboundPathProcessorInterface {

  /**
   * A language manager for looking up the current language.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * A domain path loader for loading domain path entities.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * An alias manager for looking up the system path.
   *
   * @var \Drupal\path_alias\AliasManagerInterface
   */
  protected $aliasManager;

  /**
   * A domain negotiator for looking up the current domain.
   *
   * @var \Drupal\domain\DomainNegotiatorInterface
   */
  protected $domainNegotiator;

  /**
   * Provides helper functions to determine if an entity is supported.
   *
   * @var \Drupal\simple_domain_path\SupportedEntities
   */
  protected $domainPathSupportedEntitiesService;

  /**
   * DomainPathProcessor constructor.
   *
   * @param \Drupal\Core\Language\LanguageManagerInterface $language_manager
   *   The language manager.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\path_alias\AliasManagerInterface $alias_manager
   *   The alias manager.
   * @param \Drupal\domain\DomainNegotiatorInterface $domain_negotiator
   *   The domain negotiator.
   * @param \Drupal\simple_domain_path\SupportedEntities $domain_path_supported_entities
   *   The domain path supported entity service.
   */
  public function __construct(LanguageManagerInterface $language_manager, EntityTypeManagerInterface $entity_type_manager, AliasManagerInterface $alias_manager, DomainNegotiatorInterface $domain_negotiator, SupportedEntities $domain_path_supported_entities) {
    $this->languageManager = $language_manager;
    $this->entityTypeManager = $entity_type_manager;
    $this->aliasManager = $alias_manager;
    $this->domainNegotiator = $domain_negotiator;
    $this->domainPathSupportedEntitiesService = $domain_path_supported_entities;
  }

  /**
   * {@inheritdoc}
   */
  public function processInbound($path, Request $request) {
    if ($active = $this->domainNegotiator->getActiveDomain()) {
      $properties = [
        'alias' => $path,
        'domain' => $this->domainNegotiator->getActiveDomain()->id(),
        'langcode' => $this->languageManager->getCurrentLanguage()->getId(),
      ];
      $domain_paths = $this->entityTypeManager->getStorage('path_alias')->loadByProperties($properties);
    }
    // If we can't find any domain specific aliases, use global.
    if (empty($domain_paths)) {
      $properties = [
        'alias' => $path,
        'domain' => '',
        'langcode' => $this->languageManager->getCurrentLanguage()->getId(),
      ];
      $domain_paths = $this->entityTypeManager->getStorage('path_alias')->loadByProperties($properties);
      // If we can't find any global aliases, no alias found.
      if (empty($domain_paths)) {
        return $path;
      }

    }
    $domain_path = reset($domain_paths);

    return $domain_path->getPath();
  }

  /**
   * {@inheritdoc}
   */
  public function processOutbound($path, &$options = [], Request $request = NULL, BubbleableMetadata $bubbleable_metadata = NULL) {
    if (empty($options['alias']) && ($active_domain = $this->domainNegotiator->getActiveDomain())) {
      // It's possible the path module has aliased this path already so we're
      // going to revert that.
//      $unaliased_path = $this->aliasManager->getPathByAlias($path);
      if (isset($options['language'])) {
        $language = $options['language'];
      }
      else {
        $language = $this->languageManager->getCurrentLanguage();
      }

      $domainSpecific = FALSE;
      if (isset($options['entity_type'])) {
        $domainSpecific = $this->domainPathSupportedEntitiesService->isPathForDomainPathEntity(
          $path,
          $options['entity_type']
        );
      }

      $domain_paths = $this->entityTypeManager
        ->getStorage('path_alias')
        ->loadByProperties([
          'path' => $path,
          'domain' => $domainSpecific ? $active_domain->id() : '',
          'langcode' => $language->getId(),
        ]);

      if (empty($domain_paths)) {
        return $path;
      }
      $domain_path = reset($domain_paths);
      // If the unaliased path matches our domain path source (internal url)
      // then we have a match and we output the alias, otherwise we just pass
      // the original $path along.
      return $domain_path->getAlias();
    }

    return $path;
  }

}
