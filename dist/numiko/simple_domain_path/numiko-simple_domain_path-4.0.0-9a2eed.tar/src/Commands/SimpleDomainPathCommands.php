<?php

namespace Drupal\simple_domain_path\Commands;

use Drupal\Core\Database\Connection;
use Drupal\Core\Database\DatabaseExceptionWrapper;
use Drupal\Core\Entity\EntityTypeManager;
use Drupal\Core\Language\LanguageManager;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\path_alias\Entity\PathAlias;
use Drupal\pathauto\PathautoGenerator;
use Drush\Commands\DrushCommands;

/**
 * We add Drush commands to run migrations.
 *
 * - `add:domain-to-aliases` (`ad2a`) will migrate the domain_path table to
 *  path_alias table.
 * - `validate:path-aliases` (`vpa`) will confirm a alias is accessable on the
 *  domains its node has domain access on.
 * - `dedup-path-alias` will replace domain aware aliases that exist on more
 *  one domain with a global path alias.
 */
class SimpleDomainPathCommands extends DrushCommands {

  /**
   * Messenger to allow us to write to the CLI.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface
   */
  protected MessengerInterface $messenger;

  /**
   * Language manager as alias are language dependent.
   *
   * @var \Drupal\Core\Language\LanguageManager
   */
  protected LanguageManager $languageManager;

  /**
   * The usual entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManager
   */
  protected EntityTypeManager $entityTypeManager;

  /**
   * The database connection to do database queries.
   *
   * @var \Drupal\Core\Database\Connection
   */
  protected Connection $db;

  public function __construct(MessengerInterface $messenger, LanguageManager $languageManager, EntityTypeManager $entityTypeManager, Connection $db) {
    $this->messenger = $messenger;
    $this->languageManager = $languageManager;
    $this->entityTypeManager = $entityTypeManager;
    $this->db = $db;
  }

  /**
   * Move domain IDs from existing domain_path table to path_alias table.
   *
   * @command add:domain-to-aliases
   *
   * @aliases ad2a,add-domain-to-aliases
   */
  public function domainToAliases() {
    $langcode = $this->languageManager->getDefaultLanguage()->getId();

    $missingDomains = [];
    try {
      $this->messenger->addMessage("\tPorting domain_path aliases to path_alias.");
      if ($this->db->schema()->tableExists('domain_path')) {
        $domainPathResult = $this->db->query(
          "SELECT * FROM domain_path;"
        );
        while ($domainPathRow = $domainPathResult->fetchAssoc()) {
          $pathAliasResult = $this->db->query(
            'SELECT * FROM path_alias WHERE path = :path',
            [':path' => $domainPathRow['source']]
          );
          $pathAliasRows = $pathAliasResult->fetchAll(\PDO::FETCH_ASSOC);
          $this->messenger->addMessage('Path from domain_path table: ' . $domainPathRow['source']);
          if ($pathAliasRows) {
            foreach ($pathAliasRows as $pathAliasRow) {
              $this->messenger->addMessage("\tAlias in path_alias: " . $pathAliasRow['alias']);
              $stringDomainId = $this->getStringDomainId($domainPathRow['domain_id']);
              if (!$stringDomainId) {
                throw new \Exception("Can't find domain ID");
              }
              $this->messenger->addMessage("\tSetting domain: " . $stringDomainId);
              $this->db->query("UPDATE path_alias SET domain = :domainId WHERE id = :id", [
                'domainId' => $stringDomainId,
                'id' => $pathAliasRow['id'],
              ]);
            }
          }
          else {
            // No path alias - create one.
            $this->messenger->addMessage("\tCreating new path alias");
            $domainId = $this->findDomainFromPath($domainPathRow['source']);
            if ($domainId) {
              $pathAlias = PathAlias::create([
                'langcode' => $langcode,
                'path' => $domainPathRow['source'],
                'alias' => $domainPathRow['alias'],
                'status' => 1,
                'domain' => $domainId,
              ]);
              $pathAlias->save();
            }
            else {
              $missingDomains[] = $domainPathRow['source'] . '/' . $domainPathRow['alias'] . "\tNo domain found!";
              $this->messenger->addMessage("\tNo domain found!");
            }
          }
        }
      }
      else {
        $this->messenger->addMessage("\tNo domain_path table found. No domain_path aliases ported.");
      }
    }
    catch (DatabaseExceptionWrapper $exception) {
      $this->messenger->addMessage("\tA database exception has occurred. Message: " . $exception->getMessage());
      throw new \Exception($exception->getMessage());
    }
    $this->messenger->addMessage("\tPorting existing path_alias aliases.");
    $pathAliases = $this->db->query(
      "SELECT * FROM path_alias WHERE domain is NULL OR domain = '';"
    );
    while ($pathAliasRow = $pathAliases->fetchAssoc()) {
      $this->messenger->addMessage("\tAlias in path_alias: " . $pathAliasRow['alias']);
      $domainId = $this->findDomainFromPath($pathAliasRow['path']);
      if (isset($domainId)) {
        $this->messenger->addMessage("\tSetting domain: " . $domainId);
        $this->db->query("UPDATE path_alias SET domain = :domainId WHERE id = :id", [
          'domainId' => $domainId,
          'id' => $pathAliasRow['id'],
        ]);
      }
      else {
        $missingDomains[] = $pathAliasRow['source'] . '/' . $pathAliasRow['alias'];
      }
    }
    if (!empty($missingDomains)) {
      $this->messenger->addMessage('Missing domains for:');
      drush_print_r($missingDomains);
    }
  }

  /**
   * Validate that all paths are accessible via their domain aliases.
   *
   * @command validate:path-aliases
   *
   * @aliases vpa,validate-path-aliases
   */
  public function pathAliases() {
    $this->validateAliasTable('domain_path');
    $this->validateAliasTable('path_alias');
  }

  /**
   * Finds the domain ID for a given path.
   *
   * Finds the domain ID for a given path. If the path is for a non-node
   * entity, the 'global' domain is returned, marked by an empty string.
   * If the path is for a node, but a domain for it cannot be found, NULL
   * is returned.
   *
   * @param string $path
   *   The subject entity path.
   *
   * @return string|null
   *   Domain ID if found, NULL otherwise.
   */
  protected function findDomainFromPath(string $path): ?string {
    if (strpos($path, '/node') === 0) {
      $nid = substr($path, 6);
      $node = $this->entityTypeManager
        ->getStorage('node')
        ->load($nid);
      if ($node) {
        $domain = $node->get('field_domain_access')->referencedEntities();
      }
    }
    else {
      // Not supported entity, mark as global.
      return '';
    }
    if ($domain) {
      return $domain[0]->id();
    }
    else {
      $this->messenger->addMessage("\tNo domain found!");
    }
    return NULL;
  }

  /**
   * This function returns a domain ID, if the domain exists.
   *
   * @param string $domainId
   *   Domain ID to check.
   *
   * @return string|null
   *   Domain ID if domain exists, NULL otherwise.
   */
  protected function getStringDomainId($domainId): ?string {
    static $domains;
    if (!$domains) {
      $domains = $this->entityTypeManager
        ->getStorage('domain')
        ->loadMultiple();
    }
    foreach ($domains as $domain) {
      if ($domain->getDomainId() == $domainId) {
        return $domain->id();
      }
    }
    return NULL;
  }

  /**
   * Makes request to validate that an alias is still accessible.
   *
   * @param array $allDomains
   *   Array of all site's domain entities.
   * @param string $alias
   *   The alias path to test.
   * @param string $domainId
   *   The domain from which to access the alias path.
   *
   * @return int|null
   *   Status code of response, NULL if domain not found.
   */
  protected function getRequestStatus(array $allDomains, string $alias, string $domainId): ?int {
    if ($domainId !== '') {
      if (isset($allDomains[$domainId])) {
        $domain = $allDomains[$domainId];
      }
      else {
        throw new \Exception("\tNo domain with ID $domainId found. Validation of alias failed");
      }
    }
    else {
      // If alias is global, test on any domain.
      $domain = reset($allDomains);
    }
    $host = $domain->getPath();
    // Alias starts with '/'. This is removed because host will end with '/'.
    $url = $host . substr($alias, 1);

    $client = \Drupal::httpClient();
    // Here http_errors is set to FALSE to prevent exceptions being thrown
    // for responses with status codes in the range 400 to 599.
    $response = $client->get($url, ['http_errors' => FALSE]);
    return $response->getStatusCode();
  }

  /**
   * Print formatted validation summary.
   *
   * @param int $total
   *   Total number of aliases checked.
   * @param array $invalidAliases
   *   Associative array of categorised, invalid aliases.
   * @param string $tableName
   *   Database table that was validated.
   */
  protected function printValidationSummary(int $total, array $invalidAliases, string $tableName) {
    $totalInvalidAliases = 0;
    foreach ($invalidAliases as $groupedAliases) {
      $totalInvalidAliases += count($groupedAliases);
    }
    $this->messenger->addMessage("\t$total aliases from $tableName checked");
    $totalPassed = $total - $totalInvalidAliases;
    $this->messenger->addMessage("\t$totalPassed aliases passed validation.");
    if (empty($invalidAliases)) {
      return;
    }
    $this->messenger->addMessage("\t$totalInvalidAliases aliases failed validation, please address these below:");
    foreach ($invalidAliases as $statusCode => $invalidAliasGroup) {
      if ($statusCode == 'Error') {
        $this->messenger->addMessage("\tThe following aliases failed with a request exception. The full error message is shown for each");
      }
      else {
        $this->messenger->addMessage("\tThe following aliases failed with status code $statusCode:");
      }
      foreach ($invalidAliasGroup as $invalidAlias) {
        $path = $invalidAlias['path'];
        $alias = $invalidAlias['alias'];
        $domain = $invalidAlias['domain'];
        $this->messenger->addMessage("\t\tPath:\t$path");
        $this->messenger->addMessage("\t\tAlias:\t$alias");
        if ($invalidAlias['domain'] === '') {
          $this->messenger->addMessage("\t\tDomain:\t--Global--");
        }
        else {
          $this->messenger->addMessage("\t\tDomain:\t$domain");
        }
        if ($statusCode == 'Error') {
          $errorMessage = $invalidAlias['message'];
          $this->messenger->addMessage("\t\tError message:\t$errorMessage");
        }
        // Print line break for formatting.
        $this->messenger->addMessage("\r\n");
      }
      // Print line break for formatting.
      $this->messenger->addMessage("\r\n");
    }
  }

  /**
   * Validates and outputs results for aliases from specific table.
   *
   * @param string $tableName
   *   Database table name that contains aliases to validate.
   */
  protected function validateAliasTable(string $tableName) {
    $allDomains = $this->entityTypeManager->getStorage('domain')->loadMultiple();
    if (!isset($allDomains) || empty($allDomains)) {
      throw new \Exception("\tNo domains found. Validation of aliases failed");
    }
    else {
      try {
        $this->messenger->addMessage("\tValidating $tableName aliases.");
        if ($this->db->schema()->tableExists($tableName)) {
          $processedAliases = 0;
          $invalidAliases = [];
          $queryResult = $this->db->query("SELECT * FROM $tableName;")->fetchAll();
          $totalAliases = count($queryResult);
          foreach ($queryResult as $queryRow) {
            try {
              $statusCode = $this->getRequestStatus($allDomains, $queryRow->alias, $queryRow->domain);
              if (isset($statusCode) && $statusCode != 200) {
                $invalidAliases[$statusCode][] = [
                  'path' => $queryRow->path,
                  'domain' => $queryRow->domain,
                  'alias' => $queryRow->alias,
                ];
              }
            }
            catch (\Exception $exception) {
              $invalidAliases['Error'][] = [
                'path' => $queryRow->path,
                'domain' => $queryRow->domain,
                'alias' => $queryRow->alias,
                'message' => $exception->getMessage(),
              ];
              throw new \Exception($exception->getMessage());
            }
            $processedAliases++;
            $this->messenger->addMessage("\t\tProcessed $processedAliases of $totalAliases");
          }
          $this->printValidationSummary($totalAliases, $invalidAliases, $tableName);
          $this->messenger->addMessage("\tCompleted $tableName alias validation.");
        }
        else {
          $this->messenger->addMessage("\t$tableName table does not exist. Validation of $tableName aliases skipped.");
        }
      }
      catch (DatabaseExceptionWrapper $exception) {
        $this->messenger->addMessage("\t$tableName alias validation failed! Please address error message below:");
        $this->messenger->addMessage($exception->getMessage());
        throw new \Exception($exception->getMessage());
      }
    }
  }

  /**
   * Deduplicate path aliases for the same node with multiple domains.
   *
   * This command will delete any aliases and regenerate them using
   * pathauto.
   *
   * @command dedup-path-alias
   */
  public function deduplicatePaths() {
    $duplicatedPaths = $this->db->select('path_alias')
      ->fields('path_alias', ['path'])
      ->groupBy('path_alias.path')
      ->having('COUNT(path_alias.path) > :matches', [':matches' => 1])
      ->distinct()
      ->execute()
      ->fetchAll();

    $pathStorage = $this->entityTypeManager->getStorage('path_alias');

    // Prepare the batch operations.
    if (!empty($duplicatedPaths)) {
      $operations = [];
      foreach ($duplicatedPaths as $path) {
        $operations[] = [
          '\Drupal\simple_domain_path\Commands\DeduplicatePathsBatchManager::processItem',
          [$path->path],
        ];
      }

      // Start the drush batch.
      $batch = [
        'title' => t('Deduplicating paths'),
        'operations' => $operations,
        'finished' => '\Drupal\simple_domain_path\Commands\DeduplicatePathsBatchManager::processFinished',
      ];
      batch_set($batch);
      drush_backend_batch_process();
    }
    else {
      $message = t('There were no duplicate paths found');
      $this->messenger->addMessage($message);
    }
  }

}
