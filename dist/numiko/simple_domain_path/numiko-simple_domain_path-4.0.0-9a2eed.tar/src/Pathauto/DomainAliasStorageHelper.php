<?php

declare(strict_types=1);

namespace Drupal\simple_domain_path\Pathauto;

use Drupal\Core\Language\LanguageInterface;
use Drupal\pathauto\AliasStorageHelper;
use Drupal\pathauto\PathautoGeneratorInterface;

/**
 * Add domain awareness to the Alias Storage Helper.
 */
class DomainAliasStorageHelper extends AliasStorageHelper {

  /**
   * {@inheritDoc}
   */
  public function save(array $path, $existing_alias = NULL, $op = NULL) {
    $config = $this->configFactory->get('pathauto.settings');

    // Set up all the variables needed to simplify the code below.
    $source = $path['source'];
    $alias = $path['alias'];
    $langcode = $path['language'];
    $domain = $path['domain'];
    if ($existing_alias) {
      /** @var \Drupal\path_alias\PathAliasInterface $existing_alias */
      $existing_alias = $this->entityTypeManager->getStorage('path_alias')->load($existing_alias['pid']);
    }

    // Alert users if they are trying to create an alias that is the same as the
    // internal system path.
    if ($source == $alias) {
      $this->messenger->addMessage($this->t('Ignoring alias %alias because it is the same as the internal path.', ['%alias' => $alias]));
      return NULL;
    }

    // Don't create a new alias if it is identical to the current alias.
    if ($existing_alias && $existing_alias->getAlias() == $alias) {
      return NULL;
    }

    $domainPrintable = fn ($domainArray) => $domainArray !== '' ? $domainArray->id() : 'all domains';

    // Update the existing alias if there is one and the configuration is set to
    // replace it.
    if ($existing_alias && $config->get('update_action') == PathautoGeneratorInterface::UPDATE_ACTION_DELETE) {
      $old_alias = $existing_alias->getAlias();
      $existing_alias->setAlias($alias);
      $existing_alias->set('domain', $domain)->save();

      $this->messenger->addMessage($this->t('Created new alias %alias for %source on %domain, replacing %old_alias.', [
        '%alias' => $alias,
        '%source' => $source,
        '%old_alias' => $old_alias,
        '%domain' => $domainPrintable($domain),
      ]));

      $return = $existing_alias;
    }
    else {
      // Otherwise, create a new alias.
      $path_alias = $this->entityTypeManager->getStorage('path_alias')->create([
        'path' => $source,
        'alias' => $alias,
        'langcode' => $langcode,
        'domain' => $domain,
      ]);
      $path_alias->save();

      $this->messenger->addMessage($this->t('Created new alias %alias for %source.', [
        '%alias' => $path_alias->getAlias(),
        '%source' => $path_alias->getPath(),
      ]));

      $return = $path_alias;
    }

    return [
      'source' => $return->getPath(),
      'alias' => $return->getAlias(),
      'pid' => $return->id(),
      'langcode' => $return->language()->getId(),
      'domain' => $return->domain,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function loadBySource($source, $language = LanguageInterface::LANGCODE_NOT_SPECIFIED) {
    $alias = $this->aliasRepository->lookupBySystemPath($source, $language);
    if ($alias) {
      return [
        'pid' => $alias['id'],
        'alias' => $alias['alias'],
        'source' => $alias['path'],
        'langcode' => $alias['langcode'],
        'domain' => $alias['domain'],
      ];
    }
  }

}
