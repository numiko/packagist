<?php

declare(strict_types=1);

namespace Drupal\simple_domain_path\Pathauto;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityMalformedException;
use Drupal\Core\Entity\Exception\UndefinedLinkTemplateException;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Language\LanguageInterface;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\domain\DomainInterface;
use Drupal\domain\DomainNegotiatorInterface;
use Drupal\pathauto\PathautoGenerator;
use Drupal\pathauto\PathautoGeneratorInterface;

/**
 * A domain aware version of `PathautoGenerator`.
 */
class DomainPathautoGenerator extends PathautoGenerator {

  /**
   * The domain negotiator.
   *
   * @var \Drupal\domain\DomainNegotiatorInterface
   */
  protected DomainNegotiatorInterface $domainNegotiator;

  /**
   * Set the domain negotiator.
   *
   * @param \Drupal\domain\DomainNegotiatorInterface $domainNegotiator
   *   Sets the domain negotiator (so it can be injected).
   */
  public function setDomainNegotiator(DomainNegotiatorInterface $domainNegotiator): void {
    $this->domainNegotiator = $domainNegotiator;
  }

  /**
   * {@inheritDoc}
   */
  public function createEntityAlias(EntityInterface $entity, $op) {
    // This function mostly `createEntityAlias` with domain functionality
    // bolted on.

    // Retrieve and apply the pattern for this content type.
    $pattern = $this->getPatternByEntity($entity);
    if (empty($pattern)) {
      // No pattern? Do nothing (otherwise we may blow away existing aliases...)
      return NULL;
    }

    try {
      $internalPath = $entity->toUrl()->getInternalPath();
    }
    catch (EntityMalformedException | UndefinedLinkTemplateException | \UnexpectedValueException $e) {
      return NULL;
    }

    $source = '/' . $internalPath;
    $config = $this->configFactory->get('pathauto.settings');
    $langcode = $entity->language()->getId();
    $domain = $this->getNewDomain($entity);

    // Core does not handle aliases with language Not Applicable.
    if ($langcode == LanguageInterface::LANGCODE_NOT_APPLICABLE) {
      $langcode = LanguageInterface::LANGCODE_NOT_SPECIFIED;
    }

    // Build token data.
    $data = [
      $this->tokenEntityMapper->getTokenTypeForEntityType($entity->getEntityTypeId()) => $entity,
    ];

    // Allow other modules to alter the pattern.
    $context = [
      'module' => $entity->getEntityType()->getProvider(),
      'op' => $op,
      'source' => $source,
      'data' => $data,
      'bundle' => $entity->bundle(),
      'language' => &$langcode,
    ];
    $pattern_original = $pattern->getPattern();
    $this->moduleHandler->alter('pathauto_pattern', $pattern, $context);
    $pattern_altered = $pattern->getPattern();

    // Special handling when updating an item which is already aliased.
    $existing_alias = NULL;
    if ($op == 'update' || $op == 'bulkupdate') {
      if ($existing_alias = $this->aliasStorageHelper->loadBySource($source, $langcode)) {
        switch ($config->get('update_action')) {
          case PathautoGeneratorInterface::UPDATE_ACTION_NO_NEW:
            // If an alias already exists,
            // and the update action is set to do nothing,
            // then gosh-darn it, do nothing.
            return NULL;
        }
      }
    }

    // Replace any tokens in the pattern.
    // Uses callback option to clean replacements. No sanitization.
    // Pass empty BubbleableMetadata object to explicitly ignore cacheablity,
    // as the result is never rendered.
    $alias = $this->token->replace($pattern->getPattern(), $data, [
      'clear' => TRUE,
      'callback' => [$this->aliasCleaner, 'cleanTokenValues'],
      'langcode' => $langcode,
      'pathauto' => TRUE,
    ], new BubbleableMetadata());

    // Check if the token replacement has not actually replaced any values. If
    // that is the case, then stop because we should not generate an alias.
    // @see token_scan()
    $pattern_tokens_removed = preg_replace('/\[[^\s\]:]*:[^\s\]]*\]/', '', $pattern->getPattern());
    if ($alias === $pattern_tokens_removed) {
      return NULL;
    }

    $alias = $this->aliasCleaner->cleanAlias($alias);

    // Allow other modules to alter the alias.
    $context['source'] = &$source;
    $context['pattern'] = $pattern;
    $this->moduleHandler->alter('pathauto_alias', $alias, $context);

    // If we have arrived at an empty string, discontinue.
    if (!mb_strlen($alias)) {
      return NULL;
    }

    // If the alias already exists, generate a new, hopefully unique, variant.
    $original_alias = $alias;
    $this->aliasUniquifier->uniquify($alias, $source, $langcode);
    if ($original_alias != $alias) {
      // Alert the user why this happened.
      $this->pathautoMessenger->addMessage($this->t('The automatically generated alias %original_alias conflicted with an existing alias. Alias changed to %alias.', [
        '%original_alias' => $original_alias,
        '%alias' => $alias,
      ]), $op);
    }

    // Return the generated alias if requested.
    if ($op == 'return') {
      return $alias;
    }

    // Build the new path alias array and send it off to be created.
    $path = [
      'source' => $source,
      'alias' => $alias,
      'language' => $langcode,
      'domain' => $domain,
    ];

    $return = $this->aliasStorageHelper->save($path, $existing_alias, $op);

    // Because there is no way to set an altered pattern to not be cached,
    // change it back to the original value.
    if ($pattern_altered !== $pattern_original) {
      $pattern->setPattern($pattern_original);
    }

    return $return;
  }

  /**
   * Get the domain the path alias should be set on.
   *
   * This supersedes the functionality of `simple_domain_path_entity_presave`.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity the path alias will point to.
   */
  protected function getNewDomain(EntityInterface $entity): DomainInterface | String {
    $domain = '';

    if ($entity instanceof FieldableEntityInterface) {
      $domainAccess = 'field_domain_access';
      if ($entity->hasField($domainAccess) && !$entity->get($domainAccess)->isEmpty()) {
        $domainCount = count($entity->get($domainAccess)->referencedEntities());
        // If the node is assigned to one domain, assign it to that one
        // If its assigned to none, assign it to the current domain if
        // possible. Otherwise (>=2) make it global.
        $domain = match ($domainCount) {
          1 => $entity->get($domainAccess)->referencedEntities()[0],
          0 => $this->domainNegotiator->getActiveDomain() ?? $this->entityTypeManager->getStorage('domain')->loadDefaultDomain(),
          default => '',
        };
      }
    }

    // If entity type is non-node (or the node cannot be found), this creates a
    // 'global' alias by using '' as the domain ID.
    return $domain;

  }

}
