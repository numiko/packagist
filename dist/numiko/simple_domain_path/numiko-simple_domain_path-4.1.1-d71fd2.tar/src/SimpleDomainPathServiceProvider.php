<?php

declare(strict_types=1);

namespace Drupal\simple_domain_path;

use Drupal\Core\DependencyInjection\ContainerBuilder;
use Drupal\Core\DependencyInjection\ServiceProviderBase;
use Drupal\simple_domain_path\Pathauto\DomainAliasStorageHelper;
use Drupal\simple_domain_path\Pathauto\DomainPathautoGenerator;
use Symfony\Component\DependencyInjection\Reference;

/**
 * Replace core alias services with Domain-aware ones.
 */
class SimpleDomainPathServiceProvider extends ServiceProviderBase {

  /**
   * {@inheritdoc}
   */
  public function alter(ContainerBuilder $container): void {
    if ($container->hasDefinition('path_alias.repository')) {
      $definition = $container->getDefinition('path_alias.repository');
      if (!$definition->isDeprecated()) {
        $definition
          ->setClass(DomainAliasRepository::class)
          ->addMethodCall('setDomainNegotiator', [new Reference('domain.negotiator')]);
      }
    }

    if ($container->hasDefinition('path_alias.manager')) {
      $definition = $container->getDefinition('path_alias.manager');
      if (!$definition->isDeprecated()) {
        $definition
          ->setClass(DomainAliasManager::class)
          ->addMethodCall('setDomainNegotiator', [new Reference('domain.negotiator')]);
      }
    }

    if ($container->hasDefinition('pathauto.generator')) {
      $definition = $container->getDefinition('pathauto.generator');
      if (!$definition->isDeprecated()) {
        $definition
          ->setClass(DomainPathautoGenerator::class)
          ->addMethodCall('setDomainNegotiator', [new Reference('domain.negotiator')]);
      }
    }

    if ($container->hasDefinition('pathauto.alias_storage_helper')) {
      $definition = $container->getDefinition('pathauto.alias_storage_helper');
      if (!$definition->isDeprecated()) {
        $definition->setClass(DomainAliasStorageHelper::class);
      }
    }
  }

}
