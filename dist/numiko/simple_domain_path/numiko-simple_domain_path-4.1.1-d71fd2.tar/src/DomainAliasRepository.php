<?php

declare(strict_types=1);

namespace Drupal\simple_domain_path;

use Drupal\domain\DomainNegotiatorInterface;
use Drupal\path_alias\AliasRepository as AliasRepositoryAlias;

/**
 * Extend core AliasRepository to allow Domain-aware path alias lookup operations.
 */
class DomainAliasRepository extends AliasRepositoryAlias {

  /**
   * The domain negotiator.
   *
   * @var \Drupal\domain\DomainNegotiatorInterface
   */
  protected DomainNegotiatorInterface $domainNegotiator;

  /**
   * Return the domain negotiator.
   *
   * @return \Drupal\domain\DomainNegotiatorInterface
   */
  public function getDomainNegotiator(): DomainNegotiatorInterface {
    return $this->domainNegotiator;
  }

  /**
   * Set the domain negotiator.
   *
   * @param \Drupal\domain\DomainNegotiatorInterface $domainNegotiator
   */
  public function setDomainNegotiator(DomainNegotiatorInterface $domainNegotiator): void {
    $this->domainNegotiator = $domainNegotiator;
  }

  /**
   * {@inheritDoc}
   */
  protected function getBaseQuery() {
    $query = $this->connection->select('path_alias', 'base_table');

    $activeDomain = $this->domainNegotiator->getActiveDomain();
    if ($activeDomain) {
      $or = $query->orConditionGroup();
      $or->condition('base_table.domain', $activeDomain->id());
      $or->condition('base_table.domain', '');
      $query->condition($or);
    }
    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function lookupBySystemPath($path, $langcode) {
    // See the queries above. Use LIKE for case-insensitive matching.
    $select = $this->getBaseQuery()
      ->fields('base_table', ['id', 'path', 'alias', 'langcode', 'domain'])
      ->condition('base_table.path', $this->connection->escapeLike($path), 'LIKE');

    $this->addLanguageFallback($select, $langcode);

    $select->orderBy('base_table.id', 'DESC');

    return $select->execute()->fetchAssoc() ?: NULL;
  }

}
