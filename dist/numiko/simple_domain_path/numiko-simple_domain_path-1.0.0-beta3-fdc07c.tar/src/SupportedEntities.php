<?php

namespace Drupal\simple_domain_path;

use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Class SupportedEntities.
 *
 * @package Drupal\simple_domain_path
 */
class SupportedEntities {

  /**
   * Array of entity type IDs supported by this module.
   *
   * @var array
   */
  const SUPPORTED_ENTITY_TYPES = ['node'];

  /**
   * A domain path loader for loading domain path entities.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * SupportedEntities constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * Returns entity type IDs that support domain paths.
   *
   * @return string[]
   *   Array of entity type IDs.
   */
  protected function getDomainPathEntityTypes() {
    return self::SUPPORTED_ENTITY_TYPES;
  }

  /**
   * Check if given path is for a domain path enabled entity.
   *
   * @param string $path
   *   Path to check.
   * @param string $entityType
   *   Entity type ID.
   *
   * @return bool
   *   TRUE if given path is for a domain path enabled entity.
   */
  public function isPathForDomainPathEntity(string $path, $entityType = '') {
    if ($entityType != '') {
      return in_array($entityType, $this->getDomainPathEntityTypes());
    }
    else {
      foreach ($this->getDomainPathEntityTypes() as $entityType) {
        if (strpos($path, '/' . $entityType) === 0) {
          return TRUE;
        }
      }
    }
    return FALSE;
  }

}
