<?php

namespace Drupal\simple_domain_path\Commands;

/**
 * Deduplicate path aliases and regenerate them with the correct domain.
 */
class DeduplicatePathsBatchManager {

  /**
   * Process an individual entity.
   *
   * @param string $path
   *   The path corresponding to a path alias.
   * @param array $context
   *   The batch context.
   */
  public static function processItem(string $path, array &$context): void {
    $pathStorage = \Drupal::entityTypeManager()->getStorage('path_alias');
    $baseEntity = \Drupal::service('simple_domain_path.supported_entities')->tryLoadBaseEntity($path);

    if ($baseEntity) {
      $context['message'] = t('Updating alias of "@label" (@entity_id)', [
        '@label' => $baseEntity->label(),
        '@entity_id' => $baseEntity->id(),
      ]);
      $context['results'][] = $path;

      $aliasesForPath = $pathStorage->loadByProperties([
        'path' => $path,
      ]);

      // Remove all paths for that node and regenerate them.
      $pathStorage->delete($aliasesForPath);
      \Drupal::service('pathauto.generator')->createEntityAlias($baseEntity, 'insert');
    }
  }

  /**
   * Batch Finished callback.
   *
   * @param bool $success
   *   Success of the operation.
   * @param array $results
   *   Array of results for post processing.
   */
  public static function processFinished(bool $success, array $results): void {
    if ($success) {
      $message = t('@count results processed.', ['@count' => count($results)]);
    }
    else {
      $message = t('Finished with an error.');
    }
    \Drupal::messenger()->addMessage($message);
  }

}
