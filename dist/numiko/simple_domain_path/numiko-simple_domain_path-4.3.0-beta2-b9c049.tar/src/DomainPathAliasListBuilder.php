<?php

declare(strict_types=1);

namespace Drupal\simple_domain_path;

use Drupal\Core\Entity\EntityInterface;
use Drupal\path\PathAliasListBuilder;

/**
 * Add domains to the path alias list.
 */
class DomainPathAliasListBuilder extends PathAliasListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header = [
      'domain' => [
        'data' => $this->t('Domain'),
        'field' => 'domain',
        'specifier' => 'domain',
      ],
    ];

    return $this->addToPenultimatePlace(parent::buildHeader(), $header);
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $domain = $entity->get('domain')->referencedEntities();
    if ($domain === [] || !isset($domain[0])) {
      $val['domain'] = 'All domains';
    }
    else {
      $val['domain'] = $domain[0]->label();
    }
    $parent = parent::buildRow($entity);
    $parent['data'] = $this->addToPenultimatePlace($parent['data'], $val);
    return $parent;

  }

  /**
   * Add a an element as the penultimate element in an array.
   */
  protected function addToPenultimatePlace(array $array, array $val) {
    $pos = -1;
    return array_slice($array, 0, $pos) + $val + array_slice($array, $pos);
  }

}
