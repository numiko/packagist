<?php

namespace Drupal\simple_domain_path;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\Entity\Node;

/**
 * Class SupportedEntities.
 *
 * @package Drupal\simple_domain_path
 */
class SupportedEntities {

  /**
   * Array of entity type IDs supported by this module.
   *
   * @var array
   */
  protected const SUPPORTED_ENTITY_TYPES = ['node'];

  /**
   * Check if given path is for a domain path enabled entity.
   *
   * @param string $path
   *   Path to check.
   * @param string $entityType
   *   Entity type ID.
   *
   * @return bool
   *   TRUE if given path is for a domain path enabled entity.
   */
  public static function isPathForDomainPathEntity(string $path, string $entityType = ''): bool {
    if ($entityType != '') {
      return in_array($entityType, self::SUPPORTED_ENTITY_TYPES);
    }
    else {
      foreach (self::SUPPORTED_ENTITY_TYPES as $entityType) {
        if (strpos($path, '/' . $entityType) === 0) {
          return TRUE;
        }
      }
    }
    return FALSE;
  }

  /**
   * Try to get the node object the path alias points to.
   *
   * @param string $path
   *   The path from the node alias.
   *
   * @return \Drupal\node\Enity\Node|null
   *   Returns the node if it is found.
   */
  public function tryLoadBaseEntity(string $path): ?Node {
    if (!self::isPathForDomainPathEntity($path)) {
      return NULL;
    }

    $pathComponents = explode('/', $path);
    if (!$pathComponents[2]) {
      return NULL;
    }
    else {
      return \Drupal::entityTypeManager()->getStorage($pathComponents[1])->load($pathComponents[2]);
    }
  }

}
