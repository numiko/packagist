# Media Remote File

The Media Remote File module provides support for adding a link field as media to link to a remote video file and output it as a video player within a template.

## Features

- Allows you to add a link field to your media entity.
- Supports linking to remote video files.
- Outputs the linked video file as a video player within your template.

## Installation

1. Download the module and place it in the `modules/contrib` directory of your Drupal installation, or install with composer.
2. Enable the module through the Drupal administration interface.

## Usage

1. Create a new media entity type.
2. Add a link field to the media entity and provide the URL of the remote video file.
3. In your template, use the appropriate rendering function to output the media entity as a video player.
