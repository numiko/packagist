<?php

declare(strict_types=1);

namespace Drupal\media_remote_file\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\media_remote_file\Form\RemoteVideoFileForm;

/**
 * Module hooks for media remote file (fancy new OOP hook).
 */
class RemoteFileHooks {

  /**
   * Implements hook_media_source_info_alter().
   */
  #[Hook('media_source_info_alter')]
  public function mediaSourceInfoAlter(array &$sources): void {
    if (empty($sources['remote_video_file']['forms']['media_library_add'])) {
      $sources['remote_video_file']['forms']['media_library_add'] = RemoteVideoFileForm::class;
    }
  }

}
