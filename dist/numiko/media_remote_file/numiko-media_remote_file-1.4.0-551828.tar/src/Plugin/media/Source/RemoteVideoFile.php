<?php

declare(strict_types=1);

namespace Drupal\media_remote_file\Plugin\media\Source;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\media\MediaInterface;
use Drupal\media\MediaSourceBase;
use Drupal\media\MediaTypeInterface;
use Drupal\media\Attribute\MediaSource;
use Drupal\link\Plugin\Field\FieldType\LinkItem;

/**
 * Remote HTML5 video file.
 */
#[MediaSource(
  id: 'remote_video_file',
  label: new TranslatableMarkup('Remote video file'),
  description: new TranslatableMarkup('Embed the URL of a remote HTML5 video file.'),
  allowed_field_types: ['link'],
  default_thumbnail_filename: 'remote-video-play.svg'
)]
class RemoteVideoFile extends MediaSourceBase {

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'source_field' => 'field_video_file_url',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $submitted_config = array_intersect_key(
      $form_state->getValues(),
      $this->configuration
    );
    foreach ($submitted_config as $config_key => $config_value) {
      $this->configuration[$config_key] = $config_value;
    }

    // For consistency, always use the default source_field field name.
    $default_field_name = $this->defaultConfiguration()['source_field'];
    // Check if it already exists so it can be used as a shared field.
    $storage = $this->entityTypeManager->getStorage('field_storage_config');
    $existing_source_field = $storage->load('media.' . $default_field_name);

    // Set or create the source field.
    if ($existing_source_field) {
      // If the default field already exists, return the default field name.
      $this->configuration['source_field'] = $default_field_name;
    }
    else {
      // Default source field name does not exist, so create a new one.
      $field_storage = $this->createSourceFieldStorage();
      $field_storage->save();
      $this->configuration['source_field'] = $field_storage->getName();
    }
  }

  /**
   * {@inheritdoc}
   */
  protected function createSourceFieldStorage() {
    $default_field_name = $this->defaultConfiguration()['source_field'];

    // Create the field.
    return $this->entityTypeManager->getStorage('field_storage_config')
      ->create([
        'entity_type' => 'media',
        'field_name' => $default_field_name,
        'type' => reset($this->pluginDefinition['allowed_field_types']),
      ])->setIndexes([
        'uri' => ['uri'],
      ]);
  }

  /**
   * {@inheritdoc}
   */
  public function getMetadataAttributes() {
    return [
      'url' => $this->t('Resource source URL'),
      'mime' => $this->t('Resource mime type (based on extension)'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getMetadata(MediaInterface $media, $name) {
    switch ($name) {
      case 'url':
        return $media->get($this->configuration['source_field'])->uri;

      case 'mime':
        $path = parse_url($media->get($this->configuration['source_field'])->uri, PHP_URL_PATH);
        $extension = pathinfo($path, PATHINFO_EXTENSION);
        return 'video/' . $extension;

      case 'thumbnail_uri':
        return parent::getMetadata($media, $name);

      case 'default_name':
        // Return empty string to force the user to name the media in the media
        // library.
        return '';

      default:
        return NULL;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function createSourceField(MediaTypeInterface $type) {
    $plugin_definition = $this->getPluginDefinition();

    $label = (string) $this->t('Remote file url', [
      '@type' => $plugin_definition['label'],
    ]);
    $field = parent::createSourceField($type)->set('label', $label);
    $field->set('settings', [
      'link_type' => LinkItem::LINK_EXTERNAL,
      'title' => DRUPAL_DISABLED,
    ]);
    return $field;
  }

}
