# Cloudflare Turnstile Recipe

This recipe installs the necessary modules for Cloudflare Turnstile.

## Installation

Setup Turnstile within Cloudflare, copy the site key and secret key to env variables.

Add to `settings.local.php`

```
$config['turnstile.settings']['secret_key'] = '';
$config['turnstile.settings']['site_key'] = '';
```

Within platform.sh

`d8config:turnstile.settings:site_key`
`d8config:turnstile.settings:secret_key`

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/cloudflare-turnstile-recipe`
