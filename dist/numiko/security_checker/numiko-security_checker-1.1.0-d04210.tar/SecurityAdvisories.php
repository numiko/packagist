<?php

/**
 * Script to scan Drupal 8 project for security updates without requiring DB to be loaded.
 */

require 'vendor/autoload.php';

// Semver library cloned from https://github.com/composer/semver
use Composer\Semver\Semver;

$advisories = fetchAdvisoryComposerJson();
$projects = fetchSiteComposerLock();
$updates = calculateSecurityUpdates($projects, $advisories);

if ($updates) {
  echo suggestComposerCommand($updates);
} else {
  echo '';
}

/**
 * @param $projects
 * @param $advisories
 *
 * @return array
 */
function calculateSecurityUpdates($projects, $advisories) {
  $updates = [];
  $both = array_merge($projects['packages-dev'], $projects['packages']);
  $conflict = $advisories['conflict'];
  foreach ($both as $package) {
    $name = $package['name'];
    if (!empty($conflict[$name]) && Semver::satisfies($package['version'], $advisories['conflict'][$name])) {
      // Check if core-recommended is used.
      if ($name == 'drupal/core') {
        // Drupal 9 will always be core-recommended.
        $name = 'drupal/core-*';
      }
      $updates[$name] = [
        'name' => $name,
        'version' => $package['version'],
      ];
    }
  }
  return $updates;
}

/**
 * Adapted from https://github.com/drush-ops/drush/blob/9.6.0/src/Commands/pm/SecurityUpdateCommands.php
 *
 * @return mixed
 * @throws Exception
 */
function fetchAdvisoryComposerJson() {
  try {
    // We use the v2 branch for now, as per https://github.com/drupal-composer/drupal-security-advisories/pull/11.
    $response_body = file_get_contents('https://raw.githubusercontent.com/drupal-composer/drupal-security-advisories/8.x-v2/composer.json');
    if ($response_body === false) {
      throw new Exception("Unable to fetch drupal-security-advisories information.");
    }
  } catch (Exception $e) {
    throw new Exception("Unable to fetch drupal-security-advisories information.");
  }
  $security_advisories_composer_json = json_decode($response_body, true);

  return $security_advisories_composer_json;
}

/**
 * Loads the contents of the local Drupal application's composer.lock file.
 *
 * @param $path
 *
 * @return array
 *
 * @throws \Exception
 */
function fetchSiteComposerLock() {
  $composer_lock_file_path = '/var/www/html/composer.lock';
  if (!file_exists($composer_lock_file_path)) {
    throw new Exception("Cannot find $composer_lock_file_path!");
  }
  $composer_lock_contents = file_get_contents($composer_lock_file_path);
  $composer_lock_data = json_decode($composer_lock_contents, true);
  if (!array_key_exists('packages', $composer_lock_data)) {
    throw new Exception("No packages were found in $composer_lock_file_path! Contents:\n $composer_lock_contents");
  }
  return $composer_lock_data;
}

/**
 * Emit suggested Composer command for security updates.
 *
 * @param $updates
 *
 * @return string
 */
function suggestComposerCommand($updates) {
  $packages = array();
  $suggested_command = '';
  foreach ($updates as $package) {
    $packages[$package['name']] = $package['name'];
  }

  if (!empty($packages)) {
    $suggested_command = implode(' ', $packages);
  }

  return $suggested_command;
}
