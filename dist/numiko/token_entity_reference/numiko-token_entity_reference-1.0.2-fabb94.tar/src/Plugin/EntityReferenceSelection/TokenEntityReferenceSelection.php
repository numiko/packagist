<?php

namespace Drupal\token_entity_reference\Plugin\EntityReferenceSelection;

use Drupal\views\Plugin\EntityReferenceSelection\ViewsSelection;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides specific access control for the node entity type (with details).
 *
 * @EntityReferenceSelection(
 *   id = "token_entity_reference_select",
 *   label = @Translation("Views: Filter by an entity reference view using tokens"),
 *   group = "token_entity_reference_select",
 *   weight = 5
 * )
 */
class TokenEntityReferenceSelection extends ViewsSelection {

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'token' => [
        'pattern' => '[node:title]',
      ],
    ] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);

    $token_settings = $this->getConfiguration()['token'];
    $default = ($token_settings['pattern']) ? $token_settings['pattern'] : '';
    $form['token']['pattern'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Display label'),
      '#default_value' => $default,
      '#required' => FALSE,
      '#description' => $this->t('Provide a display label to show may include tokens.'),
      '#element_validate' => array('token_element_validate'),
      '#after_build' => array('token_element_validate'),
    ];
    $form['token_help'] = array(
      '#theme' => 'token_tree_link',
      '#token_types' => ['node', 'term', 'media'],
    );
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getReferenceableEntities($match = NULL, $match_operator = 'CONTAINS', $limit = 0) {
    $handler_settings = $this->configuration['handler_settings'];
    $display_name = $handler_settings['view']['display_name'];
    $arguments = $handler_settings['view']['arguments'];
    $result = [];
    if ($this->initializeView($match, $match_operator, $limit)) {
      // Get the results.
      $result = $this->view->executeDisplay($display_name, $arguments);
    }

    $token_settings = $this->getConfiguration()['token'];
    $pattern = $token_settings['pattern'];
    $tokenOptions = ['clear' => TRUE];

    $return = [];
    if ($result) {
      foreach ($this->view->result as $row) {
        $entity = $row->_entity;
        $tokenData = [$entity->getEntityTypeId() => $entity];
        $return[$entity->bundle()][$entity->id()] = \Drupal::token()->replace($pattern, $tokenData, $tokenOptions);
      }
    }
    return $return;
  }

}
