# Token Entity Reference #

Extends the core view select plugin for entity reference fields adding a display label field, which can be populated with tokens for the entity type in use.

## Usage ##

After adding an entity reference field you normally have two options either 'Default' where you can choose bundle types *or* 'Views: Filter by an entity reference view' where you can select a view. After enabling this module you will have a third option 'Views: Filter by an entity reference view using tokens' which will add a 'Display label' field; add your tokens in here to define how the output will be displayed to the user.

## Requirements ##

* Token