<?php

namespace Drupal\token_entity_reference\Plugin\EntityReferenceSelection;

use Drupal\Core\Entity\Attribute\EntityReferenceSelection;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Utility\Token;
use Drupal\views\Plugin\EntityReferenceSelection\ViewsSelection;
use Symfony\Contracts\Service\Attribute\Required;

/**
 * Provides specific access control for the node entity type (with details).
 */
#[EntityReferenceSelection(
  id: 'token_entity_reference_select',
  label: new TranslatableMarkup('Views: Filter by an entity reference view using tokens'),
  group: 'token_entity_reference_select',
  weight: 5
)]
class TokenEntityReferenceSelection extends ViewsSelection {

  /**
   * The token service.
   */
  protected Token $token;

  /**
   * Inject the token service.
   */
  #[Required]
  public function getToken(Token $token): void {
    $this->token = $token;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'token' => [
        'pattern' => '[node:title]',
      ],
    ] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);

    $token_settings = $this->getConfiguration()['token'];
    $default = ($token_settings['pattern']) ? $token_settings['pattern'] : '';
    $form['token']['pattern'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Display label'),
      '#default_value' => $default,
      '#required' => FALSE,
      '#description' => $this->t('Provide a display label to show may include tokens.'),
      '#element_validate' => ['token_element_validate'],
      '#after_build' => ['token_element_validate'],
    ];
    $form['token_help'] = [
      '#theme' => 'token_tree_link',
      '#token_types' => ['node', 'term', 'media'],
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function getReferenceableEntities($match = NULL, $match_operator = 'CONTAINS', $limit = 0) {
    $display_name = $this->configuration['view']['display_name'];
    $arguments = $this->configuration['view']['arguments'];
    $result = [];
    if ($this->initializeView($match, $match_operator, $limit)) {
      // Get the results.
      $result = $this->view->executeDisplay($display_name, $arguments);
    }

    $token_settings = $this->getConfiguration()['token'];
    $pattern = $token_settings['pattern'];
    $tokenOptions = ['clear' => TRUE];

    $return = [];
    if ($result) {
      foreach ($this->view->result as $row) {
        $entity = $row->_entity;
        $tokenData = [$entity->getEntityTypeId() => $entity];
        $return[$entity->bundle()][$entity->id()] = $this->token->replace($pattern, $tokenData, $tokenOptions);
      }
    }
    return $return;
  }

}
