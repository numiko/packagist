<?php

declare(strict_types=1);

namespace Drupal\entity_embed_ckeditor\Plugin\Filter;

use Drupal\Component\Utility\Html;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Entity\EntityTypeRepositoryInterface;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\Core\Render\RenderContext;
use Drupal\Core\Render\RendererInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\entity_embed\EntityEmbedBuilderInterface;
use Drupal\entity_embed\Exception\EntityNotFoundException;
use Drupal\entity_embed\Exception\RecursiveRenderingException;
use Drupal\filter\Attribute\Filter;
use Drupal\filter\FilterProcessResult;
use Drupal\entity_embed\Plugin\Filter\EntityEmbedFilter;
use Drupal\filter\Plugin\FilterInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\entity_embed\EntityEmbedDisplay\EntityEmbedDisplayManager;
use Drupal\Core\File\FileUrlGeneratorInterface;

/**
 * Provides a filter to display embedded entities based on data attributes with a forced ckeditor view mode.
 */
#[Filter(
  id: "entity_embed_ckeditor",
  title: new TranslatableMarkup("Display embedded entities using a ckeditor view mode"),
  type: FilterInterface::TYPE_TRANSFORM_REVERSIBLE,
  description: new TranslatableMarkup("Embeds entities using data attributes: data-entity-type, data-entity-uuid, and data-view-mode overridden."),
)]
class EntityEmbedCkeditorFilter extends EntityEmbedFilter {

  /**
   * Whether or not we are using the admin theme.
   */
  protected ?bool $usingAdminTheme = NULL;

  /**
   * Constructs an EntityEmbedCkeditorFilter object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The renderer.
   * @param \Drupal\entity_embed\EntityEmbedBuilderInterface $builder
   *   The entity embed builder service.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   * @param \Drupal\Core\Entity\EntityTypeRepositoryInterface $entityTypeRepository
   *   The entity type repository service.
   * @param \Drupal\Core\Entity\EntityTypeBundleInfoInterface $entityTypeBundleInfo
   *   The entity type bundle info service.
   * @param \Drupal\entity_embed\EntityEmbedDisplay\EntityEmbedDisplayManager $displayPluginManager
   *   The Entity Embed Display plugin manager.
   * @param \Drupal\Core\File\FileUrlGeneratorInterface $file_url_generator
   *   The file URL generator.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entity_type_manager,
    RendererInterface $renderer,
    EntityEmbedBuilderInterface $builder,
    LoggerChannelFactoryInterface $logger_factory,
    protected readonly EntityTypeRepositoryInterface $entityTypeRepository,
    protected readonly EntityTypeBundleInfoInterface $entityTypeBundleInfo,
    protected readonly EntityEmbedDisplayManager $displayPluginManager,
    FileUrlGeneratorInterface $file_url_generator,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $entity_type_manager, $renderer, $builder, $logger_factory, $file_url_generator);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('renderer'),
      $container->get('entity_embed.builder'),
      $container->get('logger.factory'),
      $container->get('entity_type.repository'),
      $container->get('entity_type.bundle.info'),
      $container->get('plugin.manager.entity_embed.display'),
      $container->get('file_url_generator'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function process($text, $langcode): FilterProcessResult {
    $result = new FilterProcessResult($text);

    if (strpos($text, 'data-entity-type') !== FALSE && (strpos($text, 'data-entity-embed-display') !== FALSE || strpos($text, 'data-view-mode') !== FALSE)) {
      $dom = Html::load($text);
      $xpath = new \DOMXPath($dom);

      foreach ($xpath->query('//drupal-entity[@data-entity-type and (@data-entity-uuid or @data-entity-id) and (@data-entity-embed-display or @data-view-mode)]') as $node) {
        /** @var \DOMElement $node */
        $entity_type = $node->getAttribute('data-entity-type');
        $entity = NULL;
        $entity_output = '';

        // data-entity-embed-settings is deprecated, make sure we convert it to
        // data-entity-embed-display-settings.
        if (($settings = $node->getAttribute('data-entity-embed-settings')) && !$node->hasAttribute('data-entity-embed-display-settings')) {
          $node->setAttribute('data-entity-embed-display-settings', $settings);
          $node->removeAttribute('data-entity-embed-settings');
        }
        else {
          $node->setAttribute('data-entity-embed-display-settings', '');
        }

        try {
          // Load the entity either by UUID (preferred) or ID.
          $id = NULL;
          $entity = NULL;
          if ($id = $node->getAttribute('data-entity-uuid')) {
            $entity = $this->entityTypeManager->getStorage($entity_type)
              ->loadByProperties(['uuid' => $id]);
            $entity = current($entity);
          }
          else {
            $id = $node->getAttribute('data-entity-id');
            $entity = $this->entityTypeManager->getStorage($entity_type)->load($id);
          }

          if ($entity) {
            // Protect ourselves from recursive rendering.
            static $depth = 0;
            $depth++;
            if ($depth > 20) {
              throw new RecursiveRenderingException(sprintf('Recursive rendering detected when rendering embedded %s entity %s.', $entity_type, $entity->id()));
            }

            // If a UUID was not used, but is available, add it to the HTML.
            if (!$node->getAttribute('data-entity-uuid') && $uuid = $entity->uuid()) {
              $node->setAttribute('data-entity-uuid', $uuid);
            }

            $context = $this->getNodeAttributesAsArray($node);
            $context += ['data-langcode' => $langcode];

            $settings_id = $entity->getEntityTypeId() . '_' . $entity->bundle() . '_view_mode';
            if (!empty($this->settings[$settings_id])) {
              if ($this->usingAdminTheme()) {
                $context['data-entity-embed-display'] = $this->settings[$settings_id];
              }
            }

            $build = $this->builder->buildEntityEmbed($entity, $context);
            // We need to render the embedded entity:
            // - without replacing placeholders, so that the placeholders are
            //   only replaced at the last possible moment. Hence we cannot use
            //   either renderPlain() or renderRoot(), so we must use render().
            // - without bubbling beyond this filter, because filters must
            //   ensure that the bubbleable metadata for the changes they make
            //   when filtering text makes it onto the FilterProcessResult
            //   object that they return ($result). To prevent that bubbling, we
            //   must wrap the call to render() in a render context.
            $entity_output = (string) $this->renderer->executeInRenderContext(new RenderContext(), function () use (&$build) {
              return $this->renderer->render($build);
            });
            $result = $result->merge(BubbleableMetadata::createFromRenderArray($build));

            $depth--;
          }
          else {
            throw new EntityNotFoundException(sprintf('Unable to load embedded %s entity %s.', $entity_type, $id));
          }
        }
        catch (\Exception $e) {
          watchdog_exception('entity_embed', $e);
        }

        $this->replaceNodeContent($node, $entity_output);
      }

      $result->setProcessedText(Html::serialize($dom));
    }

    return $result;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state): array {
    foreach ($this->getEntityTypeOptions() as $group => $group_types) {
      foreach ($group_types as $entity_type_id => $entity_type_label) {
        $entity_type = $this->entityTypeManager->getDefinition($entity_type_id);
        $container_id = 'container_' . $entity_type_id;
        $form[$container_id] = [
          '#type' => 'details',
          '#title' => $entity_type_id,
        ];
        $container_open = FALSE;
        foreach ($this->getEntityBundleOptions($entity_type) as $bundle_id => $bundle_label) {
          $field_id = $entity_type_id . '_' . $bundle_id . '_view_mode';
          $form[$container_id][$field_id] = [
            '#type' => 'select',
            '#title' => $bundle_label,
            '#description' => $this->t('Select the view mode to use for ckeditor'),
            '#options' => $this->displayPluginManager->getDefinitionOptionsForEntityType($entity_type_id),
            '#default_value' => (!empty($this->settings[$field_id])) ? $this->settings[$field_id] : NULL,
            '#empty_value' => '',
            '#parents' => ['filters', $this->getPluginId(), 'settings', $field_id],
          ];
          if (isset($this->settings[$field_id]) && $this->settings[$field_id]) {
            $container_open = TRUE;
          }
        }
        $form[$container_id]['#open'] = $container_open;
      }
    }

    return $form;
  }

  /**
   * Builds a list of entity type options.
   *
   * Configuration entity types without a view builder are filtered out while
   * all other entity types are kept.
   *
   * @return array
   *   An array of entity type labels, keyed by entity type name.
   */
  protected function getEntityTypeOptions(): array {
    $options = $this->entityTypeRepository->getEntityTypeLabels(TRUE);

    foreach ($options as $group => $group_types) {
      foreach (array_keys($group_types) as $entity_type_id) {
        // Filter out entity types that do not have a view builder class.
        if (!$this->entityTypeManager->getDefinition($entity_type_id)->hasViewBuilderClass()) {
          unset($options[$group][$entity_type_id]);
        }
        // Filter out entity types that do not support UUIDs.
        if (!$this->entityTypeManager->getDefinition($entity_type_id)->hasKey('uuid')) {
          unset($options[$group][$entity_type_id]);
        }
        // Filter out entity types that will not have any Entity Embed Display
        // plugins.
        if (!$this->displayPluginManager->getDefinitionOptionsForEntityType($entity_type_id)) {
          unset($options[$group][$entity_type_id]);
        }
      }
    }

    return $options;
  }

  /**
   * Builds a list of entity type bundle options.
   *
   * Configuration entity types without a view builder are filtered out while
   * all other entity types are kept.
   *
   * @return array
   *   An array of bundle labels, keyed by bundle name.
   */
  protected function getEntityBundleOptions(EntityTypeInterface $entity_type): array {
    $bundle_options = [];
    // If the entity has bundles, allow option to restrict to bundle(s).
    if ($entity_type->hasKey('bundle')) {
      foreach ($this->entityTypeBundleInfo->getBundleInfo($entity_type->id()) as $bundle_id => $bundle_info) {
        $bundle_options[$bundle_id] = $bundle_info['label'];
      }
      natsort($bundle_options);
    }
    return $bundle_options;
  }

  protected function usingAdminTheme(): bool {
    if (!isset($this->usingAdminTheme)) {
      $this->usingAdminTheme = \Drupal::service('router.admin_context')->isAdminRoute();
      $current_path = \Drupal::service('path.current')->getPath();
      if (preg_match('/node\/(\d+)\/edit/', $current_path, $matches)) {
        $this->usingAdminTheme = TRUE;
      }
      if (preg_match('/entity-embed\/preview/', $current_path, $matches)) {
        $this->usingAdminTheme = TRUE;
      }
    }
    return $this->usingAdminTheme;
  }

}
