# Rich Text Slice Recipe

This recipe installs the necessary configuration to add a Rich Text Slice.

## Installation

Install using the recipe drush command:
`drush recipe:install`

Manual installation:
Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-rich-text-recipe`
