<?php

namespace Drupal\domain_simple_sitemap\Plugin\simple_sitemap\UrlGenerator;

use Drupal\domain\Entity\Domain;
use Drupal\domain_access\DomainAccessManagerInterface;
use Drupal\simple_sitemap\Entity\SimpleSitemapInterface;
use Drupal\simple_sitemap\Plugin\simple_sitemap\UrlGenerator\EntityUrlGenerator;
use Drupal\simple_sitemap\Plugin\simple_sitemap\UrlGenerator\UrlGeneratorInterface;

/**
 * Class DomainEntityUrlGenerator.
 *
 * @UrlGenerator(
 *   id = "domain_entity",
 *   label = @Translation("Domain entity URL generator"),
 *   description = @Translation("Generates URLs for entity bundles and bundle
 *   overrides."),
 * )
 */
class DomainEntityUrlGenerator extends EntityUrlGenerator {

  /**
   * {@inheritdoc}
   */
  public function getDataSets(): array {
    $data_sets = [];
    $sitemap_entity_types = $this->entityHelper->getSupportedEntityTypes();
    $all_bundle_settings = $this->entitiesManager->setVariants($this->sitemap->id())->getAllBundleSettings();

    if (isset($all_bundle_settings[$this->sitemap->id()])) {
      foreach ($all_bundle_settings[$this->sitemap->id()] as $entity_type_name => $bundles) {
        if (!isset($sitemap_entity_types[$entity_type_name])) {
          continue;
        }

        // Skip this entity type if another plugin is written to override its
        // generation.
        foreach ($this->urlGeneratorManager->getDefinitions() as $plugin) {
          if (isset($plugin['settings']['overrides_entity_type'])
            && $plugin['settings']['overrides_entity_type'] === $entity_type_name) {
            continue 2;
          }
        }

        $entityTypeStorage = $this->entityTypeManager->getStorage($entity_type_name);
        $keys = $sitemap_entity_types[$entity_type_name]->getKeys();

        foreach ($bundles as $bundle_name => $bundle_settings) {
          // Skip if "Content type" is excluded for selected variant.
          if (!empty($bundle_settings['index'])) {
            $query = $entityTypeStorage->getQuery();

            if (empty($keys['id'])) {
              $query->sort($keys['id'], 'ASC');
            }
            if (!empty($keys['bundle'])) {
              $query->condition($keys['bundle'], $bundle_name);
            }
            if (!empty($keys['status'])) {
              $query->condition($keys['status'], 1);
            }

            $activeId = \Drupal::service('domain.negotiator')->getActiveId();

            if (!empty($keys['bundle'])) {
              if ($keys['bundle'] == 'type' && $entity_type_name == 'node') {
                // Filtered by Node Domain access.
                $orGroupDomain = $query->orConditionGroup()
                  ->condition(DomainAccessManagerInterface::DOMAIN_ACCESS_FIELD . '.target_id', $activeId)
                  ->condition(DomainAccessManagerInterface::DOMAIN_ACCESS_ALL_FIELD, 1);
                $query->accessCheck(TRUE)->condition($orGroupDomain);
                foreach ($query->execute() as $entity_id) {
                  $data_sets[] = [
                    'entity_type' => $entity_type_name,
                    'id' => $entity_id,
                    'domain_source' => $activeId,
                  ];
                }
              }
              elseif ($keys['bundle'] == 'vid' && $entity_type_name == 'taxonomy_term') {
                // For taxonomy.
                foreach ($query->execute() as $entity_id) {
                  $data_sets[] = [
                    'entity_type' => $entity_type_name,
                    'id' => $entity_id,
                    'domain_source' => $activeId,
                  ];
                }
              }
            }
          }
        }
      }
    }
    return $data_sets;
  }

  /**
   * {@inheritdoc}
   *
   * Set the active domain.
   */
  public function setSitemap(SimpleSitemapInterface $sitemap): UrlGeneratorInterface {
    parent::setSitemap($sitemap);
    $domain = Domain::load($sitemap->id());
    if ($domain) {
      \Drupal::service('domain.negotiator')->setActiveDomain($domain);
    }

    return $this;
  }

  /**
   * Replace the url with the domain url.
   */
  protected function replaceBaseUrlWithCustom($url): string {
    $domain = \Drupal::service('domain.negotiator')->getActiveDomain();
    return str_replace($GLOBALS['base_url'], $domain->getScheme() . $domain->getCanonical(), $url);
  }

}
