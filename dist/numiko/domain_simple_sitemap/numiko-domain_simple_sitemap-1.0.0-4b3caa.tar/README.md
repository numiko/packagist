## Domain Access Sitemap

Adapted from https://www.drupal.org/project/domain_simple_sitemap

Domain Access Sitemap module generates sitemaps for all domains.

### Steps to generate map:

- Add a new domain
- Add a sitemap variant for the domain
- Allow node types to be added to new variant.
- Generate sitemaps.
- Your sitemap will be accessible in [you_new_domain]/sitemap.xml 
- The standard sitemap drush command can be used to generate.
