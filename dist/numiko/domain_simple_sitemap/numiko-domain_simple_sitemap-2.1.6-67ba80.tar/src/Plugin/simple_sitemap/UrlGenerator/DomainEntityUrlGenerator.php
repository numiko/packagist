<?php

namespace Drupal\domain_simple_sitemap\Plugin\simple_sitemap\UrlGenerator;

use Drupal\domain\Entity\Domain;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\domain_access\DomainAccessManagerInterface;
use Drupal\simple_sitemap\Entity\SimpleSitemapInterface;
use Drupal\simple_sitemap\Plugin\simple_sitemap\UrlGenerator\EntityUrlGenerator;
use Drupal\simple_sitemap\Plugin\simple_sitemap\UrlGenerator\UrlGeneratorInterface;

/**
 * Class DomainEntityUrlGenerator.
 *
 * @UrlGenerator(
 *   id = "domain_entity",
 *   label = @Translation("Domain entity URL generator"),
 *   description = @Translation("Generates URLs for entity bundles and bundle
 *   overrides."),
 * )
 */
class DomainEntityUrlGenerator extends EntityUrlGenerator {

  /**
   * {@inheritdoc}
   */
  public function getDataSets(): array {
    $data_sets = [];
    $sitemap_entity_types = $this->entityHelper->getSupportedEntityTypes();
    $all_bundle_settings = $this->entitiesManager->setSitemaps($this->sitemap->id())->getAllBundleSettings();

    if (isset($all_bundle_settings[$this->sitemap->id()])) {
      foreach ($all_bundle_settings[$this->sitemap->id()] as $entity_type_name => $bundles) {
        if (!isset($sitemap_entity_types[$entity_type_name])) {
          continue;
        }

        // Skip this entity type if another plugin is written to override its
        // generation.
        foreach ($this->urlGeneratorManager->getDefinitions() as $plugin) {
          if (isset($plugin['settings']['overrides_entity_type'])
            && $plugin['settings']['overrides_entity_type'] === $entity_type_name) {
            continue 2;
          }
        }

        $entityTypeStorage = $this->entityTypeManager->getStorage($entity_type_name);
        $keys = $sitemap_entity_types[$entity_type_name]->getKeys();

        foreach ($bundles as $bundle_name => $bundle_settings) {
          // Skip if "Content type" is excluded for selected variant.
          if (!empty($bundle_settings['index'])) {
            $query = $entityTypeStorage->getQuery()->accessCheck(TRUE);

            if (empty($keys['id'])) {
              $query->sort($keys['id'], 'ASC');
            }
            if (!empty($keys['bundle'])) {
              $query->condition($keys['bundle'], $bundle_name);
            }
            if (!empty($keys['status'])) {
              $query->condition($keys['status'], 1);
            }

            $activeId = \Drupal::service('domain.negotiator')->getActiveId();

            if (!empty($keys['bundle'])) {
              if ($keys['bundle'] == 'type' && $entity_type_name == 'node') {
                // Filtered by Node Domain access.
                $orGroupDomain = $query->orConditionGroup()
                  ->condition(DomainAccessManagerInterface::DOMAIN_ACCESS_FIELD . '.target_id', $activeId)
                  ->condition(DomainAccessManagerInterface::DOMAIN_ACCESS_ALL_FIELD, 1);
                $query->condition($orGroupDomain);
                foreach ($query->execute() as $entity_id) {
                  $data_sets[] = [
                    'entity_type' => $entity_type_name,
                    'id' => $entity_id,
                    'domain_source' => $activeId,
                  ];
                }
              }
              elseif ($keys['bundle'] == 'vid' && $entity_type_name == 'taxonomy_term') {
                // For taxonomy.
                foreach ($query->execute() as $entity_id) {
                  $data_sets[] = [
                    'entity_type' => $entity_type_name,
                    'id' => $entity_id,
                    'domain_source' => $activeId,
                  ];
                }
              }
            }
          }
        }
      }
    }
    return $data_sets;
  }

  /**
   * Processes the given entity.
   *
   * @param \Drupal\Core\Entity\ContentEntityInterface $entity
   *   The entity to process.
   *
   * @return array
   *   Processing result.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\Core\Entity\EntityMalformedException
   */
  protected function processEntity(ContentEntityInterface $entity): array {
    $data = parent::processEntity($entity);
    if ($entity->hasField('moderation_state') && !$entity->get('moderation_state')->isEmpty()) {
      $data['meta']['entity_info']['moderation_state'] = $entity->get('moderation_state')->getString();
    }
    return $data;
  }

  /**
   * {@inheritdoc}
   *
   * Set the active domain.
   */
  public function setSitemap(SimpleSitemapInterface $sitemap): UrlGeneratorInterface {
    parent::setSitemap($sitemap);
    $domain = Domain::load($sitemap->id());
    if ($domain) {
      // set the negotiated flag to TRUE. If setActiveDomain() is called while the
      // flag is FALSE, the next getActiveDomain() call will re-negotiate from
      // the HTTP request hostname and override the domain we set.
      \Drupal::service('domain.negotiator')->getActiveDomain();
      \Drupal::service('domain.negotiator')->setActiveDomain($domain);
    }

    return $this;
  }

  /**
   * Replace the url with the domain url.
   */
  protected function replaceBaseUrlWithCustom($url): string {
    $domain = \Drupal::service('domain.negotiator')->getActiveDomain();
    return str_replace($GLOBALS['base_url'], $domain->getScheme() . $domain->getCanonical(), $url);
  }

}
