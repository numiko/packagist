<?php

namespace Drupal\domain_simple_sitemap\Plugin\simple_sitemap\SitemapGenerator;

use Drupal\domain\Entity\Domain;
use Drupal\simple_sitemap\Plugin\simple_sitemap\SitemapGenerator\DefaultSitemapGenerator;

/**
 * Domain-aware sitemap generator.
 *
 * Overrides index content generation to use the correct per-domain base URL
 * instead of $GLOBALS['base_url'], which varies based on whichever hostname
 * triggered the cron run and causes wrong domains in pagination links.
 *
 * @SitemapGenerator(
 *   id = "domain_sitemap",
 *   label = @Translation("Domain sitemap generator"),
 *   description = @Translation("Generates a domain-aware sitemap with correct base URLs for pagination links."),
 * )
 */
class DomainSitemapGenerator extends DefaultSitemapGenerator {

  /**
   * {@inheritdoc}
   *
   * Overrides the parent to pass a domain-specific base URL when generating
   * pagination links inside the sitemap index, preventing $GLOBALS['base_url']
   * from leaking the cron request hostname into stored sitemap XML.
   */
  public function getIndexContent(): string {
    $this->writer->openMemory();
    $this->writer->setIndent(TRUE);
    $this->writer->startSitemapDocument();

    $this->addXslUrl();
    $this->writer->writeGeneratedBy();
    $this->writer->startElement('sitemapindex');

    $attributes = self::$indexAttributes;
    $this->moduleHandler->alter('simple_sitemap_index_attributes', $attributes, $this->sitemap);
    foreach ($attributes as $name => $value) {
      $this->writer->writeAttribute($name, $value);
    }

    $base_url = $this->resolveDomainBaseUrl();

    for ($delta = 1; $delta <= $this->sitemap->fromUnpublished()->getChunkCount(); $delta++) {
      $url_options = ['delta' => $delta];
      if ($base_url !== NULL) {
        $url_options['base_url'] = $base_url;
      }
      $this->writer->startElement('sitemap');
      $this->writer->writeElement('loc', $this->sitemap->toUrl('canonical', $url_options)->toString());
      $this->writer->writeElement('lastmod', date('c', $this->sitemap->fromUnpublished()->getCreated()));
      $this->writer->endElement();
    }

    $this->writer->endElement();
    $this->writer->endDocument();

    return $this->writer->outputMemory();
  }

  /**
   * Resolves the base URL for the domain matching this sitemap's ID.
   *
   * @return string|null
   *   e.g. "https://www.sas.ac.uk", or NULL if no matching domain found.
   */
  protected function resolveDomainBaseUrl(): ?string {
    $domain = Domain::load($this->sitemap->id());
    if ($domain) {
      // getRawPath() = scheme + '://' + hostname, e.g. "https://www.sas.ac.uk"
      return rtrim($domain->getRawPath(), '/');
    }
    return NULL;
  }

}