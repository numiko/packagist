## Domain Access Sitemap

Adapted from https://www.drupal.org/project/domain_simple_sitemap

Domain Access Sitemap module generates sitemaps for all domains.

### Module configuration

This module adds a "Domain Entity URL Generator". This should be added to 
a sitemap type in the "Sitemap Type" settings. When enabling this on a sitemap
type you must remove the "Entity URL Generator" as it is superseded by
"Domain Entity URL Generator".

### Steps to generate map:

- Make note of the target domain's machine name
- Ensure a domain enabled sitemap type is configured (see above)
- Add a sitemap variant for the domain ('Add sitemap')
  - It must use the same machine name as the domain record
  - It must use a domain enabled sitemap type
- In 'Inclusion' settings, ensure all relevant content types are set to be indexed in the new sitemap variant
- Rebuild queue & generate new sitemap
- Your sitemap will be accessible in [you_new_domain]/sitemap.xml 
- The standard sitemap drush command can be used to generate.
