## Domain Access Sitemap

Adapted from https://www.drupal.org/project/domain_simple_sitemap

Domain Access Sitemap module generates sitemaps for all domains.

### Module configuration

This module adds a "Domain Entity URL Generator" to be added under the "Sitemap Type" settings.
When enabling this on a sitemap type you must remove the "Entity URL Generator" as it 
is superseded by the former.

### Steps to generate map:

- Add a new domain
- Add a sitemap variant for the domain
- Allow node types to be added to new variant.
- Generate sitemaps.
- Your sitemap will be accessible in [you_new_domain]/sitemap.xml 
- The standard sitemap drush command can be used to generate.
