<?php

namespace Drupal\integration_tests;

/**
 * Trait ListingsFilterTrait
 *
 * Provides a trait for listing filter functionality.
 *
 * @package Drupal\integration_tests
 */
trait ListingsFilterTrait {

  /**
   * Return the relevant listing settings output from the JS.
   *
   * @param $listingSliceId
   *   ID of listing slice this test relates to.
   *
   * @return array
   *   Return the relevant drupalSettings.listing JS object as an array.
   *
   * @throws \Behat\Mink\Exception\DriverException
   * @throws \Behat\Mink\Exception\UnsupportedDriverActionException
   */
  protected function getListingObject($listingSliceId) {
    return $this
      ->getSession()
      ->getDriver()
      ->evaluateScript('drupalSettings.listing')[$listingSliceId];
  }

}
