<?php

namespace Drupal\integration_tests;

use Drupal\search_api_solr\Utility\SolrCommitTrait;

/**
 * Trait SearchIndexTrait
 *
 * A trait for search indexing and clearing search.
 *
 * @package Drupal\integration_tests
 */
trait SearchIndexTrait {

  use SolrCommitTrait;

  /**
   * Index any items that are waiting to be indexed.
   *
   * @param string $searchIndex
   *   The search index ID. The default 'site' is the one that comes with the
   *   install profile.
   *
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\search_api\SearchApiException
   */
  protected function indexItemsInSearch($searchIndex = 'site') {
    $index = \Drupal::service('entity_type.manager')
      ->getStorage('search_api_index')
      ->load($searchIndex);

    $index->indexItems();
    $this->ensureCommit($index);
  }

  /**
   * Indexes all (unindexed) items on the specified index.
   *
   * @param string $searchIndex
   *   The search index ID. The default 'site' is the one that comes with the
   *   install profile.
   *
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\search_api\SearchApiException
   */
  protected function clearIndex($searchIndex = 'site') {
    $index = \Drupal::service('entity_type.manager')
      ->getStorage('search_api_index')
      ->load($searchIndex);

    $index->clear();
    $this->ensureCommit($index);
  }

}
