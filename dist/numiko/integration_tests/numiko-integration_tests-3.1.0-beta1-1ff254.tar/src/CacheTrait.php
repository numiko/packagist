<?php

namespace Drupal\integration_tests;

/**
 * Trait CacheTrait
 *
 * Provides a trait to clear cache.
 *
 * @package Drupal\integration_tests
 */
trait CacheTrait {

  /**
   * Clear Drupal's cache.
   */
  protected function clearCache() {
    drupal_flush_all_caches();
  }

}
