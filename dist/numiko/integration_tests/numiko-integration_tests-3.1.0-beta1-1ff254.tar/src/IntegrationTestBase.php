<?php

namespace Drupal\integration_tests;

use weitzman\DrupalTestTraits\ExistingSiteBase;

/**
 * A test base class for integration tests.
 *
 * Useful methods are provided for testing a Drupal site loaded with
 * configuration.
 */
abstract class IntegrationTestBase extends ExistingSiteBase {

  use EntityCreationTrait, AssertTrait, SampleMediaTrait, UserTrait, SearchIndexTrait, CacheTrait;

  /**
   * {@inheritDoc}
   */
  protected function setUp(): void {
    parent::setUp();
    // It is necessary to clear the cache before each test so we have a
    // known state. If it is desirable to check whether functionality is
    // playing nicely with the cache, then create tests to check this
    // explicitly, rather than relying on the cache being preserved between
    // tests.
    $this->clearCache();
  }

}
