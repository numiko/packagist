<?php

namespace Drupal\integration_tests;

use Drupal\Core\File\FileSystemInterface;
use Drupal\file\FileInterface;

/**
 * A trait for creating sample file items.
 *
 * This includes documents and images (from a sample image - in the assets
 * folder).
 */
trait SampleFileTrait {

  use AssertTrait;

  /**
   * Get a sample document file.
   *
   * @param string $destinationFileName
   *   The destination file name.
   *
   * @return \Drupal\file\FileInterface
   */
  public function getSampleDocumentFile(string $destinationFileName = 'sample_document.pdf') : FileInterface {
    $source = __DIR__ . '/../tests/assets/sample_document.pdf';
    $destination = "public://" . $destinationFileName;
    return \Drupal::service('file.repository')->writeData(file_get_contents($source), $destination, FileSystemInterface::EXISTS_REPLACE);
  }

  /**
   * Get a sample image file.
   *
   * @param string $destinationFileName
   *   The destination file name.
   *
   * @return \Drupal\file\FileInterface
   */
  public function getSampleImageFile(string $destinationFileName = 'sample_image.jpg') : FileInterface {
    $source = __DIR__ . '/../tests/assets/sample_image.jpg';
    $destination = "public://" . $destinationFileName;
    return \Drupal::service('file.repository')->writeData(file_get_contents($source), $destination, FileSystemInterface::EXISTS_REPLACE);
  }

}
