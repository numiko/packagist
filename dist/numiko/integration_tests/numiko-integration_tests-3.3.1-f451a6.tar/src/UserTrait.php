<?php

namespace Drupal\integration_tests;

use Drupal\Core\Session\AnonymousUserSession;
use Drupal\Core\Url;

trait UserTrait {

  /**
   * Create a user with a persona and login.
   *
   * @param array $personas
   *   The personas to assign to a user.
   */
  protected function createUserWithPersonaAndLogin(array $personas) {
    // Create a user with the given personas.
    $user = $this->createUserWithPersonas($personas);

    // Login.
    $this->drupalGet('user/login');
    $this->submitForm([
      'name' => $user->getAccountName(),
      'pass' => $user->passRaw,
    ], 'Log in');

    $this->setCurrentUser($user);
  }

  /**
   * Create a user with a role and login.
   *
   * @param string $role
   *   The role to assign to a user.
   */
  protected function createUserWithRoleAndLogin(string $role) {
    // Create a user with the given role machine name.
    $user = $this->createUser();
    $user->addRole($role);
    $user->save();

    // Login.
    $this->drupalGet('user/login');
    $this->submitForm([
      'name' => $user->getAccountName(),
      'pass' => $user->passRaw,
    ], 'Log in');

    $this->setCurrentUser($user);
  }

  /**
   * Override UiHelperTrait::drupalLogout to allow for changes to login form.
   *
   * UiHelperTrait::drupalLogout checks for username and password fields on the
   * form. We may want to use email instead of username.
   */
  protected function drupalLogout() {
    $this->drupalGet(
      Url::fromRoute('user.logout', [], ['query' => ['destination' => 'user']])
    );

    // @see BrowserTestBase::drupalUserIsLoggedIn()
    unset($this->loggedInUser->sessionId);
    $this->loggedInUser = FALSE;
    $this->container->get('current_user')->setAccount(new AnonymousUserSession());
  }

}
