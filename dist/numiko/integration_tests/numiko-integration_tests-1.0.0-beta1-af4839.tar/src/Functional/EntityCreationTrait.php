<?php

namespace Drupal\integration_tests\Functional;

use Drupal\paragraphs\Entity\Paragraph;
use Drupal\pathauto\PathautoState;
use weitzman\DrupalTestTraits\Entity\NodeCreationTrait;
use weitzman\DrupalTestTraits\Entity\UserCreationTrait;

trait EntityCreationTrait {

  use NodeCreationTrait;
  use UserCreationTrait;

  /**
   * Based on UserCreationTrait::createUser
   *
   * @param array $personas
   * @param string $name
   *
   * @return \Drupal\Core\Session\AccountInterface
   */
  protected function createUserWithPersonas(array $personas = [], $name = NULL, $fields = []) {

    $account = $this->createUser([], $name, FALSE, $fields);

    if ($personas) {
      $account->personas = $personas;
      $account->save();
    }

    return $account;
  }

  /**
   * Convenience method for creating nodes that are published.
   *
   * @param array $settings
   *   Node fields to pass to parent method.
   * @param string $path
   *   URL path to the node e.g. /about-us
   *
   * @return \Drupal\node\NodeInterface
   *   The created node entity.
   */
  public function createPublishedNode($settings, string $path = '') {
    $settings += [
      'status' => 1,
      'moderation_state' => 'published',
    ];
    if ($path) {
      $settings['path'] = [
        'alias' => $path,
        'pathauto' => PathautoState::SKIP,
      ];
    }
    return $this->createNode($settings);
  }

  /**
   * Create a paragraph and return it.
   *
   * Note: this does not save the paragraph.
   *
   * Use it like:
   *
   *    $paragraph = $this->createParagraph(...)
   *    $this->createPublishedNode([
   *      'field_slices' => [
   *        0 => [
   *          'entity' => $paragraph,
   *        ],
   *      ],
   *    ]);
   *
   * @param string $type
   *   The paragraph bundle.
   * @param array $fields
   *   Field specification to pass to Paragraph::create().
   *
   * @return \Drupal\Core\Entity\EntityBase|\Drupal\Core\Entity\EntityInterface
   */
  public function createParagraph($type, array $fields = []) {
    $values = [
      'type' => $type,
    ];

    foreach ($fields as $fieldName => $fieldDetails) {
      $values[$fieldName] = $fieldDetails;
    }

    $paragraph = Paragraph::create($values);

    $this->cleanupEntities[] = $paragraph;

    return $paragraph;
  }

}
