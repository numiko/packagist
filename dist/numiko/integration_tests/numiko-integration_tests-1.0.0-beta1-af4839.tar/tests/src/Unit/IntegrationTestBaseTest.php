<?php

namespace Drupal\Tests\integration_tests\Unit;

use Drupal\Tests\UnitTestCase;

/**
 * @group test_tests
 */
class IntegrationTestBaseTest extends UnitTestCase {

  public function testAssetAppearsBefore() {
    $testClass = new TestSubClass();
    $containerString = 'string1string2';
    $testClass->assertAppearsBefore('string1', 'string2', $containerString);
    $containerString = 'jhsfdjhsdf string1 ksdjfhksd string2 skjdhfsdf';
    $testClass->assertAppearsBefore('string1', 'string2', $containerString);
  }

}
