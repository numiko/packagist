<?php

namespace Drupal\Tests\integration_tests\ExistingSite\Search;

use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test the site search is operating.
 *
 * This is a smoke test to ensure the anon user is getting search results
 * which requires the site search and solr setup to be functioning correctly.
 *
 * @group search
 * @group smoke_test
 */
class SearchTest extends IntegrationTestBase {

  /**
   * Test Anonymous User can see search results.
   */
  public function testAnonymousCanViewSiteSearch() {
    $this->visitCheckCode('search', Response::HTTP_OK);
    // Assert that an anon user sees at least one result.
    $this->assertSession()->responseContains('article');
  }

}
