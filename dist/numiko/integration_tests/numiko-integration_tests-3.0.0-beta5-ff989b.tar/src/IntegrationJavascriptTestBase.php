<?php

namespace Drupal\integration_tests;

use Drupal\search_api_solr\Utility\SolrCommitTrait;
use weitzman\DrupalTestTraits\ExistingSiteSelenium2DriverTestBase;

/**
 * Class IntegrationWebTestBase
 *
 * Used for Javascript tests using Selenium headless Chrome browser.
 *
 * @package Drupal\integration_tests
 */
class IntegrationJavascriptTestBase extends ExistingSiteSelenium2DriverTestBase {

  use SearchIndexTrait, EntityCreationTrait, SolrCommitTrait, CacheTrait, UserTrait, ListingsFilterTrait;

  /**
   * {@inheritDoc}
   */
  protected function setUp(): void {
    parent::setUp();
    // It is necessary to clear the cache before each test so we have a
    // known state. If it is desirable to check whether functionality is
    // playing nicely with the cache, then create tests to check this
    // explicitly, rather than relying on the cache being preserved between
    // tests.
    $this->clearCache();
  }

}
