<?php

namespace Drupal\Tests\integration_tests\Unit;

use Drupal\integration_tests\Functional\IntegrationTestBase;

/**
 * Subclass used for testing abstract IntegrationTestBase.
 */
class TestSubClass extends IntegrationTestBase {

}
