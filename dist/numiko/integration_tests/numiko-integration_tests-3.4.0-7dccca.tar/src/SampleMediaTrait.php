<?php

namespace Drupal\integration_tests;

use Drupal\media\MediaInterface;
use weitzman\DrupalTestTraits\Entity\MediaCreationTrait;

/**
 * A trait for creating sample media items.
 *
 * This includes core video and images (from a sample image - in the assets
 * folder).
 */
trait SampleMediaTrait {

  use AssertTrait, MediaCreationTrait, SampleFileTrait;

  /**
   * Get a sample document media item.
   *
   * @param array $settings
   *   The field values to create the media.
   * @param string $destinationFileName
   *   The destination file name.
   *
   * @return \Drupal\media\MediaInterface
   */
  public function getSampleDocumentMedia(array $settings = [], string $destinationFileName = 'sample_document.pdf') : MediaInterface {
    $file = $this->getSampleDocumentFile($destinationFileName);
    $settings += [
      'bundle' => 'document',
      'field_media_file' => ['target_id' => $file->id()],
    ];
    return $this->createMedia($settings);
  }

  /**
   * Get a sample image media item.
   *
   * @param array $settings
   *   The field values to create the media.
   * @param string $destinationFileName
   *   The destination file name.
   *
   * @return \Drupal\media\MediaInterface
   */
  public function getSampleImageMedia(array $settings = [], string $destinationFileName = 'sample_image.jpg') : MediaInterface {
    $file = $this->getSampleImageFile($destinationFileName);
    $settings += [
      'bundle' => 'image',
      'field_image' => ['target_id' => $file->id()],
    ];
    return $this->createMedia($settings);
  }

  /**
   * Get a sample core video media item.
   *
   * @param array $settings
   *   The field values to create the media.
   *
   * @return \Drupal\media\MediaInterface
   */
  public function getSampleCoreVideoMedia(array $settings = []) : MediaInterface {
    $settings += [
      'bundle' => 'core_video',
    ];
    return $this->createMedia($settings);
  }

  /**
   * Find the media image source.
   *
   * @param \Drupal\media\MediaInterface $media
   *   The media.
   *
   * @return mixed
   */
  protected function findMediaImageSource(MediaInterface $media) {
    return $media->field_image->entity->getFilename();
  }

}
