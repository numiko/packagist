<?php

namespace Drupal\Tests\integration_tests\Functional\Content;

use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test the home page is viewable.
 *
 * @group content
 * @group smoke_test
 */
class HomePageTest extends IntegrationTestBase {

  /**
   * Test the homepage can be viewed.
   */
  public function testAnonymousCanViewHomePage() {
    $this->visitCheckCode('<front>', Response::HTTP_OK);
  }

}
