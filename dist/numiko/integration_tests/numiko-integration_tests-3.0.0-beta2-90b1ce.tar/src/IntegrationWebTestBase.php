<?php

namespace Drupal\integration_tests;

use Drupal\search_api_solr\Utility\SolrCommitTrait;
use weitzman\DrupalTestTraits\ExistingSiteSelenium2DriverTestBase;

/**
 * Class IntegrationWebTestBase
 *
 * Used for Javascript tests using Selenium headless Chrome browser.
 *
 * @package Drupal\integration_tests
 */
class IntegrationWebTestBase extends ExistingSiteSelenium2DriverTestBase {

  use SearchIndexTrait, EntityCreationTrait, SolrCommitTrait, CacheTrait, UserTrait;

  /**
   * {@inheritDoc}
   */
  protected function setUp(): void {
    parent::setUp();
    // It is necessary to clear the cache before each test so we have a
    // known state. If it is desirable to check whether functionality is
    // playing nicely with the cache, then create tests to check this
    // explicitly, rather than relying on the cache being preserved between
    // tests.
    $this->clearCache();
  }

  /**
   * Return the relevant listing settings output from the JS.
   *
   * @param $listingSliceId
   *   ID of listing slice this test relates to.
   *
   * @return array
   *   Return the relevant drupalSettings.listing JS object as an array.
   *
   * @throws \Behat\Mink\Exception\DriverException
   * @throws \Behat\Mink\Exception\UnsupportedDriverActionException
   */
  protected function getListingObject($listingSliceId) {
    return $this
      ->getSession()
      ->getDriver()
      ->evaluateScript('drupalSettings.listing')[$listingSliceId];
  }

  /**
   * Run assertions to ensure filters are output correctly.
   *
   * @param $expectedFilterValues
   *   Array of expected filter values.
   * @param $actualFilters
   *   Array of actual filter values.
   * @param $actualFiltersKey
   *   Relevant filter key.
   */
  protected function assertFilterIsCorrect($expectedFilterValues, $actualFilters, $actualFiltersKey) {
    if (!empty($expectedFilterValues)) {
      $this->assertArrayHasKey($actualFiltersKey, $actualFilters);
      foreach ($expectedFilterValues as $expectedFilterValue) {
        // Expected filters can be entity reference arrays.
        // If entity reference array, re-assign so as to check for target id.
        if (is_array($expectedFilterValue) && array_key_exists('target_id', $expectedFilterValue)) {
          $expectedFilterValue = $expectedFilterValue['target_id'];
        }
        $foundFilter = FALSE;
        foreach ($actualFilters[$actualFiltersKey] as $filter) {
          if (is_array($filter) && in_array($expectedFilterValue, $filter)) {
            $foundFilter = TRUE;
            break;
          }
        }
        $this->assertTrue($foundFilter);
      }
    }
  }

  /**
   * Wait 10 seconds then find a given element.
   *
   * @param $type
   *   Selector type (css/xpath).
   * @param $selector
   *   Selector.
   */
  public function waitForAppearance($type, $selector) {
    $page = $this->getSession()->getPage();
    return $page->waitFor(10,
      function () use ($type, $selector, $page) {
        return $page->find($type, $selector);
      });
  }

}
