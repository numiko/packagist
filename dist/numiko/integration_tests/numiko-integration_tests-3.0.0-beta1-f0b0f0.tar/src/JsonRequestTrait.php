<?php

namespace Drupal\integration_tests;

use Drupal\Component\Serialization\Json;
use Drupal\Core\Url;
use Drupal\Tests\jsonapi\Functional\JsonApiRequestTestTrait;
use GuzzleHttp\RequestOptions;

/**
 * Trait JsonRequestTrait
 *
 *
 *
 * @package Drupal\integration_tests
 */
trait JsonRequestTrait {

  use JsonApiRequestTestTrait;

  /**
   * Makes a request to the search endpoint and returns the body.
   *
   * @param string $index
   *  The search index machine name.
   * @param array $query
   *   Query params.
   *
   * @return array
   *   The decoded body response.
   */
  protected function makeJsonApiSearchRequest(string $index, array $query = []): array {
    $requestOptions = [];
    $requestOptions[RequestOptions::HEADERS]['Accept'] = 'application/vnd.api+json';
    $url = Url::fromRoute('jsonapi_search_api.index_' . $index, [], ['query' => $query]);
    $response = $this->request('GET', $url, $requestOptions);
    return Json::decode((string) $response->getBody());
  }

  /**
   * Build the filter query in the JSON:API format.
   *
   * @param string $field
   *   The field name.
   * @param array $values
   *   The field value to filter on.
   * @param string $operator
   *   Accepts the following operators.
   *   '=', '<>', '>', '>=', '<', '<=', 'STARTS_WITH', 'CONTAINS', 'ENDS_WITH',
   *   'IN', 'NOT IN', 'IS NULL', 'IS NOT NULL',
   *
   * @return array
   *   The query.
   */
  protected function getFilter(string $field, array $values, string $operator = 'IN'): array {
    $filter = [
      $field . '-filter' => [
        'condition' => [
          'path' => $field,
          'operator' => $operator,
        ],
      ],
    ];
    foreach ($values as $value) {
      $filter[$field . '-filter']['condition']['value'][] = $value;
    }

    return $filter;
  }

  /**
   * Check the response contains $count documents.
   *
   * @param int $count
   *   The count.
   * @param mixed $responseDocument
   *   The response.
   */
  public function assertResponseCountEquals(int $count, $responseDocument) {
    $this->assertCount($count, $responseDocument['data']);
  }

  /**
   * Check a node id exists in the json response.
   *
   * @param array $nids
   *   Node ids to check.
   * @param mixed $responseDocument
   *   The json response.
   */
  protected function assertNodeIdExistsInResponse(array $nids, $responseDocument) {
    $this->assertSame($nids, array_map(static function (array $data) {
      return $data['attributes']['drupal_internal__nid'];
    }, $responseDocument['data']));
  }

}
