<?php

namespace Drupal\integration_tests;

trait DomainTestTrait {

  /**
   * Return the default domain.
   *
   * @return string
   */
  public function getDefaultDomain() {
    return getenv('DEFAULT_DOMAIN') ?? '';
  }

  /**
   * Load a domain by the domain id.
   *
   * @param string $domainId
   *   The domain id.
   *
   * @return \Drupal\domain\DomainInterface|null
   */
  public function getDomain(string $domainId) {
    return \Drupal::service('entity_type.manager')
      ->getStorage('domain')
      ->load($domainId);
  }

  /**
   * Load all published domains.
   *
   * @return array
   */
  public function getDomains() {
    return \Drupal::service('entity_type.manager')->getStorage('domain')->loadByProperties(['status' => 1]);
  }

  /**
   * Sets the active domain.
   *
   * Setting it as default means that the tests load the domain when browsing.
   *
   * @param string $domain_id
   *   The domain id.
   */
  public function setActiveDomain(string $domain_id) {
    $domain = $this->getDomain($domain_id);
    $domain->saveDefault();
    \Drupal::service('domain.negotiator')->setActiveDomain($domain);
  }

  /**
   * Create a user.
   *
   * @param array $roles
   *   Roles to assign.
   * @param string $domain
   *   Domain to assign.
   */
  public function createDomainUserWithRole(array $roles, $domain = 'sciencemuseum') {
    $user = $this->createUser();
    foreach ($roles as $role) {
      $user->addRole($role);
    }
    if (is_array($domain)) {
      $user->field_domain_access = $domain;
    }
    else {
      $user->field_domain_access = [$domain];
    }
    $user->save();

    return $user;
  }

  /**
   * Create a user and login.
   *
   * @param array $roles
   *   Roles to assign.
   * @param string $domain
   *   Domain to assign.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function createUserWithDomainAndLogin(array $roles, $domain = 'sciencemuseum') {
    $user = $this->createUser();
    foreach ($roles as $role) {
      $user->addRole($role);
    }
    if (is_array($domain)) {
      $user->field_domain_access = $domain;
    }
    else {
      $user->field_domain_access = [$domain];
    }
    $user->save();

    // Login.
    $this->drupalGet('user/login');
    $this->submitForm([
      'name' => $user->getAccountName(),
      'pass' => $user->passRaw,
    ], t('Log in'));

    $this->setCurrentUser($user);

    return $user;
  }

}
