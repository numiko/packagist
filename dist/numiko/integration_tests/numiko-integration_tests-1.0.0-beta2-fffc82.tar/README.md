# Full Configuration Drupal Functional Testing

Functional test infrastructure for tests that run on a site with configuration.

The idea is to be able to write tests that expect a "real" version of the site - one with the site's configuration loaded. Because much of what we do depends on config, core, contrib modules **and** our code.

The tests are run with `phpunit` and use [Mink](http://mink.behat.org/en/latest/) and [Goutte](https://github.com/FriendsOfPHP/Goutte) to browse the site. [Drupal Test Traits](https://gitlab.com/weitzman/drupal-test-traits) (DTT) is composer-required by this module to bootstrap Drupal and provides test data creation methods and UI helpers.

The `IntegrationTestBase` class provides some extra useful assertion and test data creation methods.

See `Example.php` for examples of how to use entity creation and assertions.

A testing environment should have all Drupal caches turned on for a realistic test (and these tests can be particularly useful to test how custom code works in different situations with the cache).  `IntegrationTestBase::setUp` clears the cache before each test.

Previous versions of this module attempted to install Drupal from scratch before tests were run, but this is unreliable and takes too long. Whether you write tests to be run on a site with content (e.g. a DB dump taken from prod) or with all entities deleted may depend on the application.

## Usage

The module does not need to be installed.

1. Write tests that extend `IntegrationTestBase`. See `TestDiagnosisTest` for some basic examples.
2. Make sure xdebug is turned off (so the tests run faster).
3. Make sure Drupal caches are on as they would be on production.
4. `cd docroot/modules/contrib/integration_tests`
5. Run `../../../../vendor/phpunit/phpunit/phpunit -v ../custom/` to run all full config tests for module in `modules/custom`.

It may be worth checking appropriate settings in `phpunit.xml` but the defaults should be fine. `DTT_BASE_URL` is set to `https://localhost` as whether your projects is running on Docker or not, that is the URL from the test's point of view.

## Creating test content

`EntityCreationTrait` uses the DTT entity creation methods but provides methods tailored to our particular needs. I would expect this trait to be expanded upon.

The `EntityCreationTrait::createPublishedNode()` is a useful method to create a published node (with moderation taken into account) optionally with a path.

`EntityCreationTrait::createUserWithPersonas` is useful for creating user with personas.

Any entities created using the DTT methods will automatically be deleted during `tearDown()`.

If you add custom-created entities (i.e. not using DTT or creation methods from this module), manually add them to `$this->cleanupEntities`so that they are during `tearDown()`.

 It is important that the tests do not leave any data behind that would prevent the tests running again successfully e.g. if the test expects only one node with a certain title.

## Test environment suggestions

Ways to set up the test environment:

1. Development - have a separate local docker environment with a clean DB (i.e. no content)
2. Development - have a second, clean DB in your docker environment
3. Development - write tests that allow for real content on the site
4. CI - have a process that will install Drupal and import config before running tests (future aim).

After using option 2 initially, I've settled on 3 during development. This may vary between projects.

## Comparision with other Drupal test types

[Official docs.](https://www.drupal.org/docs/8/testing/types-of-tests-in-drupal-8)

**Unit tests** – no access to the DB or Drupal. A Drupal website consists of code **and** config and usually doesn't make much sense without both. We should still always write these where we can (and they will be run by the same command that runs the integration tests).

**Kernel tests** - can access the DB and install modules. Slightly better for Drupal as config is involved, but all config needs to be imported or created programmatically which causes duplication and is hugely time-consuming.

**Browser and JS** – similar to integration tests in that they use a headless browser to test the site but have the same problem with config as kernel tests.
