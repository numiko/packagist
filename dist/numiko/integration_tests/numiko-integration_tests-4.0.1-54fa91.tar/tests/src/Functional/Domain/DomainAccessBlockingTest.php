<?php

namespace Drupal\Tests\integration_tests\Functional;

use Symfony\Component\HttpFoundation\Response;
use Drupal\integration_tests\IntegrationTestBase;
use Drupal\integration_tests\DomainTestTrait;

/**
 * Test ability of users to log in to only domain they are assigned to.
 *
 * In order to log in using built-in Domain module code ($this->domainLogin()),
 * this class needs to inherit from the Simpletest version of DomainTestsBase.
 *
 * @group DomainAccessBlocking
 */
class DomainAccessBlockingTest extends IntegrationTestBase {

  use DomainTestTrait;

  /**
   * {@inheritDoc}
   */
  public function setUp() : void {
    parent::setUp();
    $this->setActiveDomain($this->getDefaultDomain());
  }

  /**
   * Test a user can log into a domain.
   *
   * User is assigned default domain and logging into default domain.
   */
  public function testCorrectDomainUser() {
    $this->createUserWithDomainAndLogin(['site_editor']);
    $this->assertSession()->statusCodeEquals(200);
    $this->visitCheckCode('/admin/content', Response::HTTP_OK);
  }

  /**
   * Test a user with no domain cannot log in.
   */
  public function testUserWithNoDomain() {
    // Test that user is blocked from domains they are not assigned to.
    $user = $this->createDomainUserWithRole(['site_editor']);
    foreach ($this->getDomains() as $domain) {
      if ($domain->id() != $this->getDefaultDomain()) {
        $this->setActiveDomain($domain->id());
        $this->drupalLogin($user);
        $this->assertSession()->statusCodeEquals(Response::HTTP_FORBIDDEN);
      }
    }
  }

  /**
   * Test a user with domain cannot log into other domains.
   */
  public function testUserWithWrongDomain() {
    $this->createUserWithDomainAndLogin(['site_editor'], 'otherdomain');
    $this->assertSession()->statusCodeEquals(Response::HTTP_FORBIDDEN);
    $this->drupalLogout();

    $this->setActiveDomain('otherdomain');
    $this->createUserWithDomainAndLogin(['site_editor'], 'otherdomain');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
  }

}
