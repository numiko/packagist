<?php

declare(strict_types=1);

namespace Drupal\Tests\bulk_field_config\Functional;

use Drupal\Core\Entity\Entity\EntityFormDisplay;
use Drupal\Core\Entity\Entity\EntityFormMode;
use Drupal\Core\Entity\Entity\EntityViewDisplay;
use Drupal\Core\Entity\Entity\EntityViewMode;
use Drupal\Tests\BrowserTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

class CloneDisplayTest extends BrowserTestBase {

  protected static $modules = ['bulk_field_config', 'node', 'field'];

  protected $defaultTheme = 'stark';

  protected function setUp(): void {
    parent::setUp();
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    $this->drupalCreateContentType(['type' => 'page', 'name' => 'Page']);
    $this->drupalCreateContentType(['type' => 'blog', 'name' => 'Blog']);

    FieldStorageConfig::create([
      'field_name' => 'field_display_test',
      'entity_type' => 'node',
      'type' => 'string',
    ])->save();
    FieldConfig::create([
      'field_name' => 'field_display_test',
      'entity_type' => 'node',
      'bundle' => 'article',
      'label' => 'Display test',
    ])->save();

    // Register the 'bulk_edit' form mode so form displays using it can be saved.
    EntityFormMode::create([
      'targetEntityType' => 'node',
      'id' => 'node.bulk_edit',
      'label' => 'Bulk Edit',
      'status' => TRUE,
    ])->save();

    // Register the 'sidebar' view mode so displays using it can be saved.
    EntityViewMode::create([
      'targetEntityType' => 'node',
      'id' => 'node.sidebar',
      'label' => 'Sidebar',
      'status' => TRUE,
    ])->save();

    // Create a 'sidebar' view display on article only — this gives us a source
    // mode that page and blog do not already have, so step 3 shows eligible targets.
    EntityViewDisplay::create([
      'targetEntityType' => 'node',
      'bundle' => 'article',
      'mode' => 'sidebar',
      'status' => TRUE,
    ])->save();
  }

  public function testCloneDisplayFormLoads(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Step 1 of 4');
    $this->assertSession()->fieldExists('display_type');
    $this->assertSession()->fieldExists('entity_type');
    $this->assertSession()->fieldExists('source_bundle');
    $this->assertSession()->fieldExists('source_mode');
  }

  public function testStep1AdvancesToStep2(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm([
      'display_type' => 'view',
      'entity_type' => 'node',
      'source_bundle' => 'article',
      'source_mode' => 'sidebar',
    ], 'Next →');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Step 2 of 4');
    $this->assertSession()->fieldExists('target_mode');
  }

  public function testStep2AdvancesToStep3(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm(['display_type' => 'view', 'entity_type' => 'node', 'source_bundle' => 'article', 'source_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_mode' => 'sidebar'], 'Next →');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Step 3 of 4');
    $this->assertSession()->pageTextContains('Target bundles');
    // page and blog don't have 'sidebar' — they should appear as options.
    $this->assertSession()->fieldExists('target_bundles[page]');
    $this->assertSession()->fieldExists('target_bundles[blog]');
  }

  public function testStep3AdvancesToStep4(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm(['display_type' => 'view', 'entity_type' => 'node', 'source_bundle' => 'article', 'source_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_bundles[page]' => 'page'], 'Next →');
    $this->assertSession()->pageTextContains('Step 4 of 4');
    $this->assertSession()->pageTextContains('Preview of changes');
    $this->assertSession()->buttonExists('Clone display');
  }

  public function testBackNavigationFromStep2(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm(['display_type' => 'view', 'entity_type' => 'node', 'source_bundle' => 'article', 'source_mode' => 'sidebar'], 'Next →');
    $this->assertSession()->pageTextContains('Step 2 of 4');
    $this->submitForm([], '← Back');
    $this->assertSession()->pageTextContains('Step 1 of 4');
  }

  public function testStep3ValidationRequiresBundleSelection(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm(['display_type' => 'view', 'entity_type' => 'node', 'source_bundle' => 'article', 'source_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_mode' => 'sidebar'], 'Next →');
    $this->submitForm([], 'Next →');
    $this->assertSession()->pageTextContains('Select at least one target bundle');
  }

  public function testViewDisplayIsCloнedToTargetBundle(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm(['display_type' => 'view', 'entity_type' => 'node', 'source_bundle' => 'article', 'source_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_bundles[page]' => 'page'], 'Next →');
    $this->submitForm([], 'Clone display');

    $this->assertSession()->pageTextContains('Cloned display to 1 bundle(s)');
    $this->assertNotNull(EntityViewDisplay::load('node.page.sidebar'));
  }

  public function testFormDisplayIsCloнedToTargetBundle(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm(['display_type' => 'form', 'entity_type' => 'node', 'source_bundle' => 'article', 'source_mode' => 'default'], 'Next →');
    // Use a target mode that doesn't exist on any bundle.
    $this->submitForm(['target_mode' => 'bulk_edit'], 'Next →');
    $this->submitForm(['target_bundles[page]' => 'page'], 'Next →');
    $this->submitForm([], 'Clone display');

    $this->assertSession()->pageTextContains('Cloned display to 1 bundle(s)');
    $this->assertNotNull(EntityFormDisplay::load('node.page.bulk_edit'));
  }

  public function testEligibleTargetsExcludeBundlesWithExistingMode(): void {
    // Give page a 'sidebar' view display — it should then be excluded from targets.
    EntityViewDisplay::create([
      'targetEntityType' => 'node',
      'bundle' => 'page',
      'mode' => 'sidebar',
      'status' => TRUE,
    ])->save();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm(['display_type' => 'view', 'entity_type' => 'node', 'source_bundle' => 'article', 'source_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_mode' => 'sidebar'], 'Next →');
    // page already has 'sidebar' — must not appear as a target.
    $this->assertSession()->fieldNotExists('target_bundles[page]');
    // blog does not have 'sidebar' — must appear.
    $this->assertSession()->fieldExists('target_bundles[blog]');
  }

  public function testNoEligibleTargetsMessageWhenAllHaveMode(): void {
    // Give all bundles a 'sidebar' display.
    foreach (['page', 'blog'] as $bundle) {
      EntityViewDisplay::create([
        'targetEntityType' => 'node',
        'bundle' => $bundle,
        'mode' => 'sidebar',
        'status' => TRUE,
      ])->save();
    }

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm(['display_type' => 'view', 'entity_type' => 'node', 'source_bundle' => 'article', 'source_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_mode' => 'sidebar'], 'Next →');
    $this->assertSession()->pageTextContains('No eligible target bundles');
  }

  public function testPreviewShowsDryRunResults(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->submitForm(['display_type' => 'view', 'entity_type' => 'node', 'source_bundle' => 'article', 'source_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_mode' => 'sidebar'], 'Next →');
    $this->submitForm(['target_bundles[blog]' => 'blog'], 'Next →');
    $this->assertSession()->pageTextContains('dry_run');
  }

  public function testAccessDeniedWithoutPermission(): void {
    $user = $this->drupalCreateUser([]);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/clone-display');
    $this->assertSession()->statusCodeEquals(403);
  }

}
