<?php

declare(strict_types=1);

namespace Drupal\Tests\bulk_field_config\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

class CloneFieldTest extends BrowserTestBase {

  protected static $modules = ['bulk_field_config', 'node', 'field'];

  protected $defaultTheme = 'stark';

  protected function setUp(): void {
    parent::setUp();
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    $this->drupalCreateContentType(['type' => 'page', 'name' => 'Page']);

    FieldStorageConfig::create([
      'field_name' => 'field_clone_test',
      'entity_type' => 'node',
      'type' => 'string',
    ])->save();

    FieldConfig::create([
      'field_name' => 'field_clone_test',
      'entity_type' => 'node',
      'bundle' => 'article',
      'label' => 'Clone Test',
    ])->save();
  }

  public function testCloneFormLoads(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Step 1 of 4');
    $this->assertSession()->pageTextContains('Source bundle');
    $this->assertSession()->fieldExists('source_bundle');
  }

  public function testCloneFormStep1AdvancesToStep2(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Step 2 of 4');
    $this->assertSession()->pageTextContains('Target bundles');
    $this->assertSession()->fieldExists('target_bundles[page]');
  }

  public function testCloneFormStep2DoesNotShowSourceBundle(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    // article is the source so it should not appear as a target.
    $this->assertSession()->fieldNotExists('target_bundles[article]');
  }

  public function testCloneFormStep2AdvancesToStep3(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    $this->submitForm(['target_bundles[page]' => 'page'], 'Next →');
    $this->assertSession()->pageTextContains('Step 3 of 4');
    $this->assertSession()->fieldExists('label_override');
    $this->assertSession()->fieldExists('copy_displays');
  }

  public function testCloneFormStep3AdvancesToStep4(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    $this->submitForm(['target_bundles[page]' => 'page'], 'Next →');
    $this->submitForm([], 'Next →');
    $this->assertSession()->pageTextContains('Step 4 of 4');
    $this->assertSession()->pageTextContains('Preview of changes');
    $this->assertSession()->buttonExists('Clone field');
  }

  public function testCloneFormBackNavigation(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    $this->assertSession()->pageTextContains('Step 2 of 4');
    $this->submitForm([], '← Back');
    $this->assertSession()->pageTextContains('Step 1 of 4');
  }

  public function testCloneFormStep2ValidationRequiresSelection(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    $this->submitForm([], 'Next →');
    $this->assertSession()->pageTextContains('Select at least one target bundle');
    $this->assertSession()->pageTextContains('Step 2 of 4');
  }

  public function testCloneFieldCopiesConfigToTargetBundle(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    $this->submitForm(['target_bundles[page]' => 'page'], 'Next →');
    $this->submitForm([], 'Next →');
    $this->submitForm([], 'Clone field');

    $this->assertSession()->pageTextContains('Cloned field to 1 bundle(s)');
    $this->assertNotNull(FieldConfig::loadByName('node', 'page', 'field_clone_test'));
  }

  public function testClonePreservesSourceLabel(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    $this->submitForm(['target_bundles[page]' => 'page'], 'Next →');
    $this->submitForm([], 'Next →');
    $this->submitForm([], 'Clone field');

    $cloned = FieldConfig::loadByName('node', 'page', 'field_clone_test');
    $this->assertEquals('Clone Test', $cloned->getLabel());
  }

  public function testCloneWithLabelOverride(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    $this->submitForm(['target_bundles[page]' => 'page'], 'Next →');
    $this->submitForm(['label_override' => 'Overridden Label'], 'Next →');
    $this->submitForm([], 'Clone field');

    $cloned = FieldConfig::loadByName('node', 'page', 'field_clone_test');
    $this->assertEquals('Overridden Label', $cloned->getLabel());
  }

  public function testCloneSkipsAlreadyAttachedBundle(): void {
    // Attach field to page first.
    FieldConfig::create([
      'field_name' => 'field_clone_test',
      'entity_type' => 'node',
      'bundle' => 'page',
      'label' => 'Clone Test (page)',
    ])->save();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    // page already has the field, so no target checkboxes are shown.
    $this->assertSession()->pageTextContains('All bundles already have this field attached');
  }

  public function testClonePreviewShowsDryRunResults(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->submitForm(['source_bundle' => 'article'], 'Next →');
    $this->submitForm(['target_bundles[page]' => 'page'], 'Next →');
    $this->submitForm([], 'Next →');
    $this->assertSession()->pageTextContains('dry_run');
  }

  public function testAccessDeniedWithoutPermission(): void {
    $user = $this->drupalCreateUser([]);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_clone_test/clone');
    $this->assertSession()->statusCodeEquals(403);
  }

}
