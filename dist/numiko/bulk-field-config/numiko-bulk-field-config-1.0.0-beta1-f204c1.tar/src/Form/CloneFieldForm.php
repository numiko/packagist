<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Form;

use Drupal\bulk_field_config\Service\BulkFieldCloneService;
use Drupal\bulk_field_config\Service\BulkFieldQueryService;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

final class CloneFieldForm extends FormBase {

  public function __construct(
    protected BulkFieldCloneService $cloneService,
    protected BulkFieldQueryService $queryService,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('bulk_field_config.bulk_field_clone'),
      $container->get('bulk_field_config.bulk_field_query'),
    );
  }

  public function getFormId(): string {
    return 'bulk_field_config_clone_field';
  }

  public function buildForm(array $form, FormStateInterface $form_state): array {
    $entity_type = $this->getRouteMatch()->getParameter('entity_type');
    $field_name = $this->getRouteMatch()->getParameter('field_name');
    $step = $form_state->get('step') ?? 1;

    $form['step_indicator'] = [
      '#markup' => '<p class="field-tools-step-indicator">' . $this->t('Step @step of 4', ['@step' => $step]) . '</p>',
    ];
    $form['header'] = [
      '#markup' => '<p>' . $this->t('Field: <strong>@field</strong>', ['@field' => $field_name]) . '</p>',
    ];
    $form['#cache'] = ['max-age' => 0];

    return match ($step) {
      1 => $this->buildStep1($form, $form_state, $entity_type, $field_name),
      2 => $this->buildStep2($form, $form_state, $entity_type, $field_name),
      3 => $this->buildStep3($form, $form_state, $entity_type, $field_name),
      4 => $this->buildStep4($form, $form_state, $entity_type, $field_name),
      default => $this->buildStep1($form, $form_state, $entity_type, $field_name),
    };
  }

  private function buildStep1(array $form, FormStateInterface $form_state, string $entity_type, string $field_name): array {
    $detail = $this->queryService->getFieldStorageDetail($entity_type, $field_name);
    if (!$detail) {
      $form['error'] = ['#markup' => $this->t('Field not found.')];
      return $form;
    }

    $bundle_options = [];
    foreach ($detail['instances'] as $bundle => $config) {
      $bundle_options[$bundle] = $this->queryService->getBundleLabel($entity_type, $bundle) . ' (' . $bundle . ')';
    }

    $s1 = $form_state->get('step1') ?? [];

    if (empty($bundle_options)) {
      $form['notice'] = ['#markup' => '<p>' . $this->t('This field is not attached to any bundles and cannot be cloned.') . '</p>'];
      $form['actions'] = $this->cancelAction($entity_type, $field_name);
      return $form;
    }

    $form['source_bundle'] = [
      '#type' => 'select',
      '#title' => $this->t('Source bundle'),
      '#description' => $this->t('The bundle to copy the field configuration from.'),
      '#options' => $bundle_options,
      '#default_value' => $s1['source_bundle'] ?? NULL,
      '#required' => TRUE,
    ];

    $form['actions'] = $this->buildNextActions(NULL, 'submitStep1', $entity_type, $field_name);
    return $form;
  }

  private function buildStep2(array $form, FormStateInterface $form_state, string $entity_type, string $field_name): array {
    $s1 = $form_state->get('step1');
    $source_bundle = $s1['source_bundle'];

    $targets = $this->cloneService->getCloneableTargets($entity_type, $field_name, $source_bundle);
    $s2 = $form_state->get('step2') ?? [];

    if (empty($targets)) {
      $form['notice'] = ['#markup' => '<p>' . $this->t('All bundles already have this field attached. There are no targets to clone to.') . '</p>'];
      $form['target_bundles'] = ['#type' => 'value', '#value' => []];
    }
    else {
      $form['target_bundles'] = [
        '#type' => 'checkboxes',
        '#title' => $this->t('Target bundles'),
        '#description' => $this->t('Select one or more bundles to clone the field to.'),
        '#options' => $targets,
        '#default_value' => $s2['target_bundles'] ?? [],
      ];
    }

    $form['actions'] = $this->buildNextActions('submitStepBack', empty($targets) ? NULL : 'submitStep2', $entity_type, $field_name);
    return $form;
  }

  private function buildStep3(array $form, FormStateInterface $form_state, string $entity_type, string $field_name): array {
    $s1 = $form_state->get('step1');
    $s3 = $form_state->get('step3') ?? [];

    $form['label_override'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Label override'),
      '#description' => $this->t('Optional. Leave empty to copy the label from the source bundle.'),
      '#default_value' => $s3['label_override'] ?? '',
    ];

    $form['copy_displays'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Copy display settings'),
      '#description' => $this->t('Copy this field\'s component settings (formatter/widget configuration) from the source display instances.'),
      '#default_value' => $s3['copy_displays'] ?? FALSE,
    ];

    $view_modes = $this->cloneService->getAvailableViewModes($entity_type, $s1['source_bundle']);
    $form['view_modes'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('View modes to copy'),
      '#options' => $view_modes,
      '#default_value' => $s3['view_modes'] ?? [],
      '#states' => ['visible' => [':input[name="copy_displays"]' => ['checked' => TRUE]]],
    ];

    $form_modes = $this->cloneService->getAvailableFormModes($entity_type, $s1['source_bundle']);
    $form['form_modes'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Form modes to copy'),
      '#options' => $form_modes,
      '#default_value' => $s3['form_modes'] ?? [],
      '#states' => ['visible' => [':input[name="copy_displays"]' => ['checked' => TRUE]]],
    ];

    $form['actions'] = $this->buildNextActions('submitStepBack', 'submitStep3', $entity_type, $field_name);
    return $form;
  }

  private function buildStep4(array $form, FormStateInterface $form_state, string $entity_type, string $field_name): array {
    $s1 = $form_state->get('step1');
    $s2 = $form_state->get('step2');
    $s3 = $form_state->get('step3');

    $results = $this->cloneService->clone(
      $entity_type,
      $field_name,
      $s1['source_bundle'],
      $s2['target_bundles'],
      [
        'label_override' => $s3['label_override'],
        'copy_displays' => $s3['copy_displays'],
        'view_modes' => array_keys(array_filter($s3['view_modes'] ?? [])),
        'form_modes' => array_keys(array_filter($s3['form_modes'] ?? [])),
      ],
      TRUE,
    );

    $rows = [];
    foreach ($results as $result) {
      $bundle_label = $result->bundle === '*' ? '*' : $this->queryService->getBundleLabel($entity_type, $result->bundle);
      $rows[] = [$result->bundle, $bundle_label, $result->status, $result->message];
    }

    $form['preview'] = [
      '#type' => 'table',
      '#caption' => $this->t('Preview of changes:'),
      '#header' => [$this->t('Bundle'), $this->t('Name'), $this->t('Status'), $this->t('Details')],
      '#rows' => $rows,
      '#empty' => $this->t('No changes to apply.'),
    ];

    $form['actions'] = $this->buildNextActions('submitStepBack', NULL, $entity_type, $field_name);
    $form['actions']['confirm'] = [
      '#type' => 'submit',
      '#value' => $this->t('Clone field'),
    ];

    return $form;
  }

  public function submitStep1(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step1', ['source_bundle' => $form_state->getValue('source_bundle')]);
    $form_state->set('step', 2);
    $form_state->setRebuild(TRUE);
  }

  public function submitStep2(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step2', [
      'target_bundles' => array_keys(array_filter($form_state->getValue('target_bundles', []))),
    ]);
    $form_state->set('step', 3);
    $form_state->setRebuild(TRUE);
  }

  public function submitStep3(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step3', [
      'label_override' => $form_state->getValue('label_override'),
      'copy_displays' => (bool) $form_state->getValue('copy_displays'),
      'view_modes' => $form_state->getValue('view_modes', []),
      'form_modes' => $form_state->getValue('form_modes', []),
    ]);
    $form_state->set('step', 4);
    $form_state->setRebuild(TRUE);
  }

  public function submitStepBack(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step', max(1, ($form_state->get('step') ?? 2) - 1));
    $form_state->setRebuild(TRUE);
  }

  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $step = $form_state->get('step') ?? 1;

    if ($step === 2 && !array_filter($form_state->getValue('target_bundles', []))) {
      $form_state->setErrorByName('target_bundles', $this->t('Select at least one target bundle.'));
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $entity_type = $this->getRouteMatch()->getParameter('entity_type');
    $field_name = $this->getRouteMatch()->getParameter('field_name');
    $s1 = $form_state->get('step1');
    $s2 = $form_state->get('step2');
    $s3 = $form_state->get('step3');

    $results = $this->cloneService->clone(
      $entity_type,
      $field_name,
      $s1['source_bundle'],
      $s2['target_bundles'],
      [
        'label_override' => $s3['label_override'],
        'copy_displays' => $s3['copy_displays'],
        'view_modes' => array_keys(array_filter($s3['view_modes'] ?? [])),
        'form_modes' => array_keys(array_filter($s3['form_modes'] ?? [])),
      ],
    );

    $success = count(array_filter($results, fn($r) => $r->isSuccess()));
    $skipped = count(array_filter($results, fn($r) => $r->isSkipped()));
    $errors = count(array_filter($results, fn($r) => $r->isError()));

    if ($success) {
      $this->messenger()->addStatus($this->t('Cloned field to @count bundle(s).', ['@count' => $success]));
    }
    if ($skipped) {
      $this->messenger()->addWarning($this->t('Skipped @count bundle(s) — field already exists.', ['@count' => $skipped]));
    }
    if ($errors) {
      $this->messenger()->addError($this->t('Failed on @count bundle(s) — check logs.', ['@count' => $errors]));
    }

    $form_state->setRedirect('bulk_field_config.field_detail', [
      'entity_type' => $entity_type,
      'field_name' => $field_name,
    ]);
  }

  private function buildNextActions(?string $back_submit, ?string $next_submit, string $entity_type, string $field_name): array {
    $actions = ['#type' => 'actions'];

    if ($next_submit) {
      $actions['next'] = [
        '#type' => 'submit',
        '#value' => $this->t('Next →'),
        '#submit' => ['::' . $next_submit],
      ];
    }

    if ($back_submit) {
      $actions['back'] = [
        '#type' => 'submit',
        '#value' => $this->t('← Back'),
        '#submit' => ['::' . $back_submit],
        '#limit_validation_errors' => [],
      ];
    }

    $actions['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromRoute('bulk_field_config.field_detail', ['entity_type' => $entity_type, 'field_name' => $field_name]),
      '#attributes' => ['class' => ['button', 'button--secondary']],
    ];

    return $actions;
  }

  private function cancelAction(string $entity_type, string $field_name): array {
    return [
      '#type' => 'actions',
      'cancel' => [
        '#type' => 'link',
        '#title' => $this->t('Back to field detail'),
        '#url' => Url::fromRoute('bulk_field_config.field_detail', ['entity_type' => $entity_type, 'field_name' => $field_name]),
        '#attributes' => ['class' => ['button', 'button--secondary']],
      ],
    ];
  }

}
