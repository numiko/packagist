<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Form;

use Drupal\bulk_field_config\Service\BulkDisplayCloneService;
use Drupal\bulk_field_config\Service\BulkFieldQueryService;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

final class CloneDisplayForm extends FormBase {

  public function __construct(
    protected BulkDisplayCloneService $displayCloneService,
    protected BulkFieldQueryService $queryService,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('bulk_field_config.bulk_display_clone'),
      $container->get('bulk_field_config.bulk_field_query'),
    );
  }

  public function getFormId(): string {
    return 'bulk_field_config_clone_display';
  }

  public function buildForm(array $form, FormStateInterface $form_state): array {
    $step = $form_state->get('step') ?? 1;

    $form['step_indicator'] = [
      '#markup' => '<p class="field-tools-step-indicator">' . $this->t('Step @step of 4', ['@step' => $step]) . '</p>',
    ];
    $form['#cache'] = ['max-age' => 0];

    return match ($step) {
      1 => $this->buildStep1($form, $form_state),
      2 => $this->buildStep2($form, $form_state),
      3 => $this->buildStep3($form, $form_state),
      4 => $this->buildStep4($form, $form_state),
      default => $this->buildStep1($form, $form_state),
    };
  }

  /**
   * Step 1: choose display type, entity type, source bundle and source mode.
   */
  private function buildStep1(array $form, FormStateInterface $form_state): array {
    $s1 = $form_state->get('step1') ?? [];

    $form['display_type'] = [
      '#type' => 'radios',
      '#title' => $this->t('Display type'),
      '#options' => [
        'view' => $this->t('View display (how content is rendered)'),
        'form' => $this->t('Form display (how fields appear in edit forms)'),
      ],
      '#default_value' => $s1['display_type'] ?? 'view',
      '#required' => TRUE,
    ];

    $entity_type_options = array_combine(
      array_keys(BulkFieldQueryService::ENTITY_TYPE_LABELS),
      array_values(BulkFieldQueryService::ENTITY_TYPE_LABELS),
    );

    $form['entity_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Entity type'),
      '#options' => $entity_type_options,
      '#default_value' => $s1['entity_type'] ?? 'node',
      '#required' => TRUE,
    ];

    $form['source_bundle'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Source bundle machine name'),
      '#description' => $this->t('e.g. article, page, blog_post'),
      '#default_value' => $s1['source_bundle'] ?? '',
      '#required' => TRUE,
    ];

    $form['source_mode'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Source display mode'),
      '#description' => $this->t('e.g. default, teaser, full'),
      '#default_value' => $s1['source_mode'] ?? 'default',
      '#required' => TRUE,
    ];

    $form['actions'] = $this->buildNextActions(NULL, 'submitStep1');
    return $form;
  }

  /**
   * Step 2: choose the target mode name.
   *
   * Collecting target_mode before bundle selection ensures step 3 can
   * pre-filter correctly (bundles where target_mode already exists are excluded).
   */
  private function buildStep2(array $form, FormStateInterface $form_state): array {
    $s1 = $form_state->get('step1');
    $s2 = $form_state->get('step2') ?? [];

    $form['target_mode'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Target display mode name'),
      '#description' => $this->t('The mode to create on each target bundle. Defaults to the source mode name. Only bundles that do not already have this mode will be available in the next step.'),
      '#default_value' => $s2['target_mode'] ?? $s1['source_mode'],
      '#required' => TRUE,
    ];

    $form['actions'] = $this->buildNextActions('submitStepBack', 'submitStep2');
    return $form;
  }

  /**
   * Step 3: select target bundles, pre-filtered by target_mode from step 2.
   */
  private function buildStep3(array $form, FormStateInterface $form_state): array {
    $s1 = $form_state->get('step1');
    $s2 = $form_state->get('step2');
    $s3 = $form_state->get('step3') ?? [];

    $eligible = $this->displayCloneService->getEligibleTargets(
      $s1['entity_type'],
      $s1['source_bundle'],
      $s1['source_mode'],
      $s2['target_mode'],
      $s1['display_type'],
    );

    if (empty($eligible)) {
      $form['notice'] = ['#markup' => '<p>' . $this->t('No eligible target bundles — all bundles already have the <em>@mode</em> display mode.', ['@mode' => $s2['target_mode']]) . '</p>'];
      $form['target_bundles'] = ['#type' => 'value', '#value' => []];
    }
    else {
      $form['target_bundles'] = [
        '#type' => 'checkboxes',
        '#title' => $this->t('Target bundles'),
        '#description' => $this->t('Bundles that already have the <em>@mode</em> display mode are not shown.', ['@mode' => $s2['target_mode']]),
        '#options' => $eligible,
        '#default_value' => $s3['target_bundles'] ?? [],
      ];
    }

    $form['actions'] = $this->buildNextActions('submitStepBack', empty($eligible) ? NULL : 'submitStep3');
    return $form;
  }

  /**
   * Step 4: preview (dry run) and confirm.
   */
  private function buildStep4(array $form, FormStateInterface $form_state): array {
    $s1 = $form_state->get('step1');
    $s2 = $form_state->get('step2');
    $s3 = $form_state->get('step3');

    $results = $this->displayCloneService->clone(
      $s1['entity_type'],
      $s1['source_bundle'],
      $s1['source_mode'],
      $s3['target_bundles'],
      $s2['target_mode'],
      $s1['display_type'],
      TRUE,
    );

    $rows = [];
    foreach ($results as $result) {
      $bundle_label = $result->bundle === '*' ? '*' : $this->queryService->getBundleLabel($s1['entity_type'], $result->bundle);
      $rows[] = [$result->bundle, $bundle_label, $result->status, $result->message];
    }

    $form['preview'] = [
      '#type' => 'table',
      '#caption' => $this->t('Preview of changes:'),
      '#header' => [$this->t('Bundle'), $this->t('Name'), $this->t('Status'), $this->t('Details')],
      '#rows' => $rows,
      '#empty' => $this->t('No changes to apply.'),
    ];

    $form['actions'] = $this->buildNextActions('submitStepBack', NULL);
    $form['actions']['confirm'] = [
      '#type' => 'submit',
      '#value' => $this->t('Clone display'),
    ];

    return $form;
  }

  public function submitStep1(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step1', [
      'display_type' => $form_state->getValue('display_type'),
      'entity_type' => $form_state->getValue('entity_type'),
      'source_bundle' => $form_state->getValue('source_bundle'),
      'source_mode' => $form_state->getValue('source_mode'),
    ]);
    $form_state->set('step', 2);
    $form_state->setRebuild(TRUE);
  }

  public function submitStep2(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step2', ['target_mode' => $form_state->getValue('target_mode')]);
    $form_state->set('step', 3);
    $form_state->setRebuild(TRUE);
  }

  public function submitStep3(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step3', [
      'target_bundles' => array_keys(array_filter($form_state->getValue('target_bundles', []))),
    ]);
    $form_state->set('step', 4);
    $form_state->setRebuild(TRUE);
  }

  public function submitStepBack(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step', max(1, ($form_state->get('step') ?? 2) - 1));
    $form_state->setRebuild(TRUE);
  }

  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $step = $form_state->get('step') ?? 1;

    if ($step === 3 && !array_filter($form_state->getValue('target_bundles', []))) {
      $form_state->setErrorByName('target_bundles', $this->t('Select at least one target bundle.'));
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $s1 = $form_state->get('step1');
    $s2 = $form_state->get('step2');
    $s3 = $form_state->get('step3');

    $results = $this->displayCloneService->clone(
      $s1['entity_type'],
      $s1['source_bundle'],
      $s1['source_mode'],
      $s3['target_bundles'],
      $s2['target_mode'],
      $s1['display_type'],
    );

    $success = count(array_filter($results, fn($r) => $r->isSuccess()));
    $skipped = count(array_filter($results, fn($r) => $r->isSkipped()));
    $errors = count(array_filter($results, fn($r) => $r->isError()));

    if ($success) {
      $this->messenger()->addStatus($this->t('Cloned display to @count bundle(s).', ['@count' => $success]));
    }
    if ($skipped) {
      $this->messenger()->addWarning($this->t('Skipped @count bundle(s) — display already exists.', ['@count' => $skipped]));
    }
    if ($errors) {
      $this->messenger()->addError($this->t('Failed on @count bundle(s) — check logs.', ['@count' => $errors]));
    }

    $form_state->setRedirect('bulk_field_config.overview_type', [
      'entity_type' => $s1['entity_type'],
    ]);
  }

  private function buildNextActions(?string $back_submit, ?string $next_submit): array {
    $actions = ['#type' => 'actions'];

    if ($next_submit) {
      $actions['next'] = [
        '#type' => 'submit',
        '#value' => $this->t('Next →'),
        '#submit' => ['::' . $next_submit],
      ];
    }

    if ($back_submit) {
      $actions['back'] = [
        '#type' => 'submit',
        '#value' => $this->t('← Back'),
        '#submit' => ['::' . $back_submit],
        '#limit_validation_errors' => [],
      ];
    }

    $actions['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromRoute('bulk_field_config.overview'),
      '#attributes' => ['class' => ['button', 'button--secondary']],
    ];

    return $actions;
  }

}
