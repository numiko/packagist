<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\bulk_field_config\Service\BulkFieldAttachService;
use Drupal\bulk_field_config\Service\BulkFieldQueryService;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Two-panel field manager for a specific entity type / bundle.
 */
final class BulkManagerController extends ControllerBase {

  public function __construct(
    protected readonly BulkFieldQueryService $bulkFieldQuery,
    protected readonly BulkFieldAttachService $bulkFieldAttach,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('bulk_field_config.bulk_field_query'),
      $container->get('bulk_field_config.bulk_field_attach'),
    );
  }

  /**
   * Renders the two-panel field manager for a bundle.
   */
  public function manager(string $entity_type, string $bundle): array {
    // --- Bundle tabs -------------------------------------------------------
    $bundle_tabs = [];
    foreach ($this->bulkFieldQuery->getAllBundles($entity_type) as $bundle_id => $bundle_label) {
      $bundle_tabs[] = [
        'label' => $bundle_label,
        'url' => Url::fromRoute('bulk_field_config.manager', [
          'entity_type' => $entity_type,
          'bundle' => $bundle_id,
        ])->toString(),
        'active' => $bundle_id === $bundle,
      ];
    }

    // --- Current fields (left panel) ---------------------------------------
    $field_instances = $this->entityTypeManager()
      ->getStorage('field_config')
      ->loadByProperties([
        'entity_type' => $entity_type,
        'bundle' => $bundle,
      ]);

    $current_rows = [];
    foreach ($field_instances as $config) {
      $field_name = $config->getName();
      $storage = $this->entityTypeManager()
        ->getStorage('field_storage_config')
        ->load($entity_type . '.' . $field_name);

      $cardinality = $storage ? $storage->getCardinality() : 1;
      $cardinality_label = $cardinality === -1
        ? $this->t('Unlimited')
        : (string) $cardinality;

      $type_label = $storage
        ? $this->bulkFieldQuery->getTypeLabel($storage->getType())
        : '';

      $current_rows[] = [
        (string) $config->getLabel(),
        $field_name,
        $type_label,
        $cardinality_label,
        [
          'data' => [
            '#type' => 'container',
            '#attributes' => ['class' => ['field-tools-actions']],
            'edit' => [
              '#type' => 'link',
              '#title' => $this->t('Edit'),
              '#url' => Url::fromRoute('bulk_field_config.edit', [
                'entity_type' => $entity_type,
                'field_name' => $field_name,
              ]),
              '#attributes' => ['class' => ['button', 'button--extrasmall']],
            ],
            'clone' => [
              '#type' => 'link',
              '#title' => $this->t('Clone'),
              '#url' => Url::fromRoute('bulk_field_config.clone_field', [
                'entity_type' => $entity_type,
                'field_name' => $field_name,
              ]),
              '#attributes' => ['class' => ['button', 'button--extrasmall']],
            ],
            'delete' => [
              '#type' => 'link',
              '#title' => $this->t('Delete'),
              '#url' => Url::fromRoute('bulk_field_config.delete', [
                'entity_type' => $entity_type,
                'field_name' => $field_name,
              ]),
              '#attributes' => ['class' => ['button', 'button--extrasmall', 'button--danger']],
            ],
          ],
        ],
      ];
    }

    $current_fields = [
      '#type' => 'table',
      '#header' => [
        $this->t('Label'),
        $this->t('Machine name'),
        $this->t('Type'),
        $this->t('Cardinality'),
        $this->t('Actions'),
      ],
      '#rows' => $current_rows,
      '#empty' => $this->t('No fields attached to this bundle.'),
      '#attributes' => ['class' => ['field-tools-table']],
    ];

    // --- Available fields (right panel) ------------------------------------
    $attachable = $this->bulkFieldAttach->getAttachableStorages($entity_type, $bundle);

    $available_rows = [];
    foreach ($attachable as $storage) {
      $available_rows[] = [
        $storage->getName(),
        $this->bulkFieldQuery->getTypeLabel($storage->getType()),
        [
          'data' => [
            '#type' => 'link',
            '#title' => $this->t('Attach'),
            '#url' => Url::fromRoute('bulk_field_config.attach', [
              'entity_type' => $entity_type,
              'field_name' => $storage->getName(),
            ]),
            '#attributes' => ['class' => ['button', 'button--extrasmall', 'button--primary']],
          ],
        ],
      ];
    }

    $available_fields = [
      '#type' => 'table',
      '#header' => [
        $this->t('Field name'),
        $this->t('Type'),
        $this->t('Action'),
      ],
      '#rows' => $available_rows,
      '#empty' => $this->t('All available fields are already attached.'),
      '#attributes' => ['class' => ['field-tools-table']],
    ];

    return [
      '#theme' => 'bulk_manager',
      '#entity_type' => $entity_type,
      '#bundle' => $bundle,
      '#bundle_tabs' => $bundle_tabs,
      '#current_fields' => $current_fields,
      '#available_fields' => $available_fields,
      '#attached' => ['library' => ['bulk_field_config/admin', 'bulk_field_config/bulk-manager']],
      '#cache' => ['max-age' => 0],
    ];
  }

  /**
   * Title callback for the manager route.
   */
  public function getTitle(string $entity_type, string $bundle): string {
    $bundle_label = $this->bulkFieldQuery->getBundleLabel($entity_type, $bundle);
    return $bundle_label . ' — Field Manager';
  }

}
