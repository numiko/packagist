<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Service;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldTypePluginManagerInterface;

final class BulkFieldQueryService {

  const ENTITY_TYPES = ['node', 'media', 'paragraph', 'taxonomy_term'];

  const BUNDLE_ENTITY_TYPE_MAP = [
    'node' => 'node_type',
    'media' => 'media_type',
    'paragraph' => 'paragraphs_type',
    'taxonomy_term' => 'taxonomy_vocabulary',
  ];

  const ENTITY_TYPE_LABELS = [
    'node' => 'Content',
    'media' => 'Media',
    'paragraph' => 'Paragraphs',
    'taxonomy_term' => 'Taxonomy',
  ];

  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    protected readonly FieldTypePluginManagerInterface $fieldTypeManager,
  ) {}

  public function getAllBundles(string $entity_type): array {
    $bundle_entity_type_id = self::BUNDLE_ENTITY_TYPE_MAP[$entity_type] ?? NULL;
    if (!$bundle_entity_type_id || !$this->entityTypeManager->hasDefinition($bundle_entity_type_id)) {
      return [];
    }
    $result = [];
    foreach ($this->entityTypeManager->getStorage($bundle_entity_type_id)->loadMultiple() as $bundle) {
      $result[$bundle->id()] = (string) $bundle->label();
    }
    return $result;
  }

  public function getFieldStorageSummaries(string $entity_type): array {
    $storages = $this->entityTypeManager
      ->getStorage('field_storage_config')
      ->loadByProperties(['entity_type' => $entity_type]);

    $summaries = [];
    foreach ($storages as $storage) {
      $field_name = $storage->getName();
      $instances = $this->entityTypeManager
        ->getStorage('field_config')
        ->loadByProperties(['entity_type' => $entity_type, 'field_name' => $field_name]);

      $bundles = array_map(
        static fn($c) => $c->getTargetBundle(),
        $instances,
      );

      $summaries[$field_name] = [
        'storage' => $storage,
        'type' => $storage->getType(),
        'cardinality' => $storage->getCardinality(),
        'bundles' => array_values($bundles),
        'bundle_count' => count($bundles),
      ];
    }

    ksort($summaries);
    return $summaries;
  }

  public function getFieldStorageDetail(string $entity_type, string $field_name): ?array {
    $storage = $this->entityTypeManager
      ->getStorage('field_storage_config')
      ->load($entity_type . '.' . $field_name);

    if (!$storage) {
      return NULL;
    }

    $instances = $this->entityTypeManager
      ->getStorage('field_config')
      ->loadByProperties(['entity_type' => $entity_type, 'field_name' => $field_name]);

    $keyed = [];
    foreach ($instances as $config) {
      $keyed[$config->getTargetBundle()] = $config;
    }

    return [
      'storage' => $storage,
      'instances' => $keyed,
    ];
  }

  public function getTypeLabel(string $type): string {
    $definitions = $this->fieldTypeManager->getDefinitions();
    return isset($definitions[$type]) ? (string) $definitions[$type]['label'] : $type;
  }

  public function getBundleLabel(string $entity_type, string $bundle): string {
    $bundle_entity_type_id = self::BUNDLE_ENTITY_TYPE_MAP[$entity_type] ?? NULL;
    if (!$bundle_entity_type_id || !$this->entityTypeManager->hasDefinition($bundle_entity_type_id)) {
      return $bundle;
    }
    $entity = $this->entityTypeManager->getStorage($bundle_entity_type_id)->load($bundle);
    return $entity ? (string) $entity->label() : $bundle;
  }

}
