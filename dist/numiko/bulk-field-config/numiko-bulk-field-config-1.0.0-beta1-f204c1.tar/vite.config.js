import { defineConfig } from 'vite';

export default defineConfig({
  build: {
    lib: {
      entry: {
        'bundle-selector': 'js/src/bundle-selector.js',
        'bulk-manager': 'js/src/bulk-manager.js',
      },
      formats: ['es'],
    },
    outDir: 'js/dist',
    rollupOptions: {
      output: {
        entryFileNames: '[name].js',
      },
    },
  },
});
