# Bulk Field Config

A developer tool for managing fields and display modes across multiple entity bundles in a single operation. Intended for use during site-building, not on production by editors.

## Requirements

- Drupal 11+
- PHP 8.3+
- Core modules: `field`

## Installation

```bash
composer require numiko/bulk-field-config
drush en bulk_field_config -y
```

The module adds a **Field Tools** section under **Administration > Configuration** (`/admin/config/field-tools`).

## Permissions

| Permission | Description |
|---|---|
| `administer bulk field config` | Full access to all tools. Marked `restrict access` — assign to developers only. |

## Features

### Field overview

`/admin/config/field-tools` lists all field storage definitions grouped by entity type (Content, Media, Paragraphs, Taxonomy). Each row links to a field detail page showing which bundles have the field attached, their labels, and cardinality.

### Bulk attach

Attach an existing field storage to multiple bundles in one step. A 3-step wizard lets you choose the source bundle to copy configuration from, select target bundles, then review a dry-run preview before confirming.

### Bulk edit

Update field settings (label, required, cardinality) across multiple bundles simultaneously. 3-step wizard with preview step.

### Bulk delete

Remove a field from multiple bundles. Uses the Drupal Batch API so large operations don't time out. Requires confirmation.

### Create field

Create a new field storage and attach it to one or more bundles in a single 4-step flow: choose field type → configure → select bundles → confirm.

### Clone field

Copy a field (and optionally its display component settings) from one bundle to others that don't yet have it. Optionally copies widget/formatter configuration from selected view modes and form modes.

### Clone display mode

Copy an entire view display or form display from one bundle to others, creating the display mode on each target bundle. Only bundles that don't already have the target mode are shown.

### Field manager

`/admin/config/field-tools/manager/{entity_type}/{bundle}` — a two-panel dashboard for a specific bundle showing current fields (with Edit, Clone, Delete actions) and available fields (shared storages not yet attached, with Attach links). Navigate between bundles using the tab bar.

## Building JavaScript assets

The module ships with source JS in `js/src/` and uses [Vite](https://vitejs.dev/) to compile to `js/dist/`.

```bash
cd docroot/modules/contrib/bulk_field_config
nvm use          # or ensure Node 18+
npm install
npm run build    # production build
npm run dev      # watch mode
```

## Running tests

The module has a full functional test suite. Run from the Drupal root inside the web container:

```bash
docker compose exec web php vendor/bin/phpunit \
  docroot/modules/contrib/bulk_field_config/tests \
  --configuration docroot/phpunit.xml.dist
```

Test classes are in `tests/src/Functional/` and cover all wizards, validation, access control, and service operations.
