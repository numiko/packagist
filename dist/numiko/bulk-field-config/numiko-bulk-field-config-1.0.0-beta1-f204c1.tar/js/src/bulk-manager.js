/**
 * @file bulk-manager.js
 * Two-panel field manager enhancements:
 *  - Highlights the active bundle tab pill
 *  - Field card keyboard navigation
 *  - Confirms destructive actions before following links
 */

(function (Drupal, once) {
  'use strict';

  /**
   * Highlight the active bundle tab and wire up any dynamic pill behaviour.
   */
  Drupal.behaviors.bfcManagerTabs = {
    attach(context) {
      once('bfc-manager-tabs', '.field-tools-entity-tabs', context).forEach(nav => {
        const currentPath = window.location.pathname;
        nav.querySelectorAll('a.tabs__link').forEach(link => {
          if (link.getAttribute('href') === currentPath) {
            link.classList.add('is-active');
            link.setAttribute('aria-current', 'page');
          }
        });
      });
    },
  };

  /**
   * Add a confirmation dialog to Delete action links within the manager panels.
   */
  Drupal.behaviors.bfcManagerDeleteConfirm = {
    attach(context) {
      once('bfc-manager-delete-confirm', '.field-tools-manager a[href*="/delete"]', context).forEach(link => {
        link.addEventListener('click', e => {
          if (!window.confirm(Drupal.t('Remove this field from the bundle? This will open the delete form where you can confirm.'))) {
            e.preventDefault();
          }
        });
      });
    },
  };

  /**
   * Make field rows keyboard-navigable: Enter on a row's label navigates to
   * the field detail page (if a detail link is present).
   */
  Drupal.behaviors.bfcManagerFieldRows = {
    attach(context) {
      once('bfc-manager-field-rows', '.field-tools-manager .field-tools-table tbody tr', context).forEach(row => {
        row.setAttribute('tabindex', '0');
        row.addEventListener('keydown', e => {
          if (e.key === 'Enter') {
            // Follow the first link in the row if present.
            const link = row.querySelector('a');
            if (link) link.click();
          }
        });
      });
    },
  };

})(Drupal, once);
