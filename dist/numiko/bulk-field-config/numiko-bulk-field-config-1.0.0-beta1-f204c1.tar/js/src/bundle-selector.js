/**
 * @file bundle-selector.js
 * Progressive enhancement: converts a checkboxes element into a dual-column
 * Available → Selected drag interface, using SortableJS from core/sortable.
 *
 * Activated on any element with [data-js-bundle-selector].
 * Falls back to plain checkboxes when JS is unavailable.
 */

(function (Drupal, once) {
  'use strict';

  /**
   * Build a dual-column widget from a checkbox list.
   *
   * @param {HTMLElement} wrapper  The container holding the original checkboxes.
   */
  function initBundleSelector(wrapper) {
    const checkboxes = Array.from(wrapper.querySelectorAll('input[type="checkbox"]'));
    if (!checkboxes.length) return;

    // Build the dual-column shell.
    const ui = document.createElement('div');
    ui.className = 'bfc-bundle-selector';
    ui.setAttribute('data-js-bundle-selector-ui', '');
    ui.innerHTML = `
      <div class="bfc-bundle-selector__col bfc-bundle-selector__col--available" role="listbox" aria-label="${Drupal.t('Available')}">
        <p class="bfc-bundle-selector__heading">${Drupal.t('Available')}</p>
        <input class="bfc-bundle-selector__search" type="search" placeholder="${Drupal.t('Filter…')}" aria-label="${Drupal.t('Filter available bundles')}">
        <ul class="bfc-bundle-selector__list" id="${wrapper.id}-available" aria-multiselectable="true"></ul>
      </div>
      <div class="bfc-bundle-selector__divider" aria-hidden="true">↔</div>
      <div class="bfc-bundle-selector__col bfc-bundle-selector__col--selected" role="listbox" aria-label="${Drupal.t('Selected')}">
        <p class="bfc-bundle-selector__heading">${Drupal.t('Selected')}</p>
        <ul class="bfc-bundle-selector__list" id="${wrapper.id}-selected" aria-multiselectable="true"></ul>
      </div>
    `;

    const availableList = ui.querySelector('#' + wrapper.id + '-available');
    const selectedList  = ui.querySelector('#' + wrapper.id + '-selected');
    const searchInput   = ui.querySelector('.bfc-bundle-selector__search');

    /**
     * Create a list item for a single bundle option.
     */
    function makeItem(checkbox) {
      const li = document.createElement('li');
      li.className = 'bfc-bundle-selector__item';
      li.setAttribute('role', 'option');
      li.setAttribute('tabindex', '0');
      li.setAttribute('data-value', checkbox.value);
      li.setAttribute('aria-selected', checkbox.checked ? 'true' : 'false');
      if (checkbox.disabled) {
        li.classList.add('bfc-bundle-selector__item--disabled');
        li.setAttribute('aria-disabled', 'true');
        li.removeAttribute('tabindex');
      }
      li.textContent = checkbox.labels[0]?.textContent?.trim() || checkbox.value;
      return li;
    }

    /**
     * Sync the hidden checkboxes to match the current column state.
     */
    function syncCheckboxes() {
      const selectedValues = new Set(
        Array.from(selectedList.querySelectorAll('.bfc-bundle-selector__item'))
             .map(li => li.dataset.value)
      );
      checkboxes.forEach(cb => { cb.checked = selectedValues.has(cb.value); });
    }

    /**
     * Move an item from one list to the other.
     */
    function transfer(li, from, to) {
      if (li.classList.contains('bfc-bundle-selector__item--disabled')) return;
      to.appendChild(li);
      li.setAttribute('aria-selected', to === selectedList ? 'true' : 'false');
      syncCheckboxes();
    }

    // Populate lists based on initial checkbox state.
    checkboxes.forEach(cb => {
      const li = makeItem(cb);
      (cb.checked ? selectedList : availableList).appendChild(li);
    });

    // Click to transfer.
    function handleClick(e) {
      const li = e.target.closest('.bfc-bundle-selector__item');
      if (!li) return;
      const isInSelected = selectedList.contains(li);
      transfer(li, isInSelected ? selectedList : availableList, isInSelected ? availableList : selectedList);
    }

    availableList.addEventListener('click', handleClick);
    selectedList.addEventListener('click', handleClick);

    // Keyboard: Space/Enter to toggle, arrow keys to navigate.
    function handleKeydown(e) {
      const li = e.target.closest('.bfc-bundle-selector__item');
      if (!li) return;

      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        const isInSelected = selectedList.contains(li);
        transfer(li, isInSelected ? selectedList : availableList, isInSelected ? availableList : selectedList);
        li.focus();
      }

      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const items = Array.from(li.parentElement.querySelectorAll('.bfc-bundle-selector__item:not(.bfc-bundle-selector__item--disabled)'));
        const idx = items.indexOf(li);
        const next = e.key === 'ArrowDown' ? items[idx + 1] : items[idx - 1];
        if (next) next.focus();
      }
    }

    ui.addEventListener('keydown', handleKeydown);

    // Search/filter on available column.
    searchInput.addEventListener('input', () => {
      const q = searchInput.value.toLowerCase();
      availableList.querySelectorAll('.bfc-bundle-selector__item').forEach(li => {
        const match = li.textContent.toLowerCase().includes(q);
        li.style.display = match ? '' : 'none';
      });
    });

    // Initialise SortableJS on both lists if available (loaded via core/sortable).
    if (typeof Sortable !== 'undefined') {
      const sortableOpts = {
        group: wrapper.id + '-group',
        animation: 150,
        filter: '.bfc-bundle-selector__item--disabled',
        onEnd() { syncCheckboxes(); },
      };
      Sortable.create(availableList, { ...sortableOpts });
      Sortable.create(selectedList,  { ...sortableOpts });
    }

    // Hide the original checkboxes and insert the UI.
    wrapper.querySelectorAll('.form-checkboxes, .form-type--checkboxes').forEach(el => {
      el.style.display = 'none';
    });
    wrapper.appendChild(ui);
  }

  Drupal.behaviors.bfcBundleSelector = {
    attach(context) {
      once('bfc-bundle-selector', '[data-js-bundle-selector]', context).forEach(initBundleSelector);
    },
  };

})(Drupal, once);
