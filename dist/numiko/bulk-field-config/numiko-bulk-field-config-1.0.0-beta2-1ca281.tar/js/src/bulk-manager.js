/**
 * @file bulk-manager.js
 * Field manager enhancements:
 *  - Field card keyboard navigation
 *  - Confirms destructive actions before following links
 *
 * Active-bundle highlighting in the sidebar rail is server-rendered (the
 * `is-active` class comes from BulkManagerController), so no JS is needed
 * for that anymore.
 */

(function (Drupal, once) {
  'use strict';

  /**
   * Add a confirmation dialog to Delete action links within the manager panels.
   */
  Drupal.behaviors.bfcManagerDeleteConfirm = {
    attach(context) {
      once('bfc-manager-delete-confirm', '.field-tools-manager a[href*="/delete"]', context).forEach(link => {
        link.addEventListener('click', e => {
          if (!window.confirm(Drupal.t('Remove this field from the bundle? This will open the delete form where you can confirm.'))) {
            e.preventDefault();
          }
        });
      });
    },
  };

  /**
   * Make field rows keyboard-navigable: Enter on a row's label navigates to
   * the field detail page (if a detail link is present).
   */
  Drupal.behaviors.bfcManagerFieldRows = {
    attach(context) {
      once('bfc-manager-field-rows', '.field-tools-manager .field-tools-table tbody tr', context).forEach(row => {
        row.setAttribute('tabindex', '0');
        row.addEventListener('keydown', e => {
          if (e.key === 'Enter') {
            // Follow the first link in the row if present.
            const link = row.querySelector('a');
            if (link) link.click();
          }
        });
      });
    },
  };

})(Drupal, once);
