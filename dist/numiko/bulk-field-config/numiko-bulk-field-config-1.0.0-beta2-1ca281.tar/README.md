# Bulk Field Config

A developer tool for managing fields and display modes across multiple entity bundles in a single operation. Intended for use during site-building, not on production by editors.

## Requirements

- Drupal 11+
- PHP 8.3+
- Core modules: `field`

## Installation

```bash
composer require numiko/bulk-field-config
drush en bulk_field_config -y
```

The module adds a **Field Tools** section under **Administration > Structure** (`/admin/config/field-tools`).

## Permissions

| Permission | Description |
|---|---|
| `administer bulk field config` | Full access to all tools. Marked `restrict access` — assign to developers only. |

## Features

### Field overview

`/admin/config/field-tools` lists all field storage definitions grouped by entity type (Content, Media, Paragraphs, Taxonomy). Each row links to a field detail page showing which bundles have the field attached, their labels, and cardinality.

### Bulk attach

Attach an existing field storage to multiple bundles in one step. A 2-step wizard lets you select target bundles and settings, then review a dry-run preview before confirming.

### Bulk edit

Update field settings (label, required, cardinality) across multiple bundles simultaneously. 2-step wizard: edit values, then review a diff preview before applying.

### Bulk delete

Remove a field from multiple bundles. Uses the Drupal Batch API so large operations don't time out. Requires confirmation.

### Create field

Create a new field storage and attach it to one or more bundles in a single 4-step flow: choose field type → configure → select bundles → confirm.

### Clone field

Copy a field (and optionally its display component settings) from one bundle to others that don't yet have it. Optionally copies widget/formatter configuration from selected view modes and form modes.

### Clone display mode

Copy an entire view display or form display from one bundle to others, creating the display mode on each target bundle. Only bundles that don't already have the target mode are shown.

### Field manager

`/admin/config/field-tools/manager/{entity_type}/{bundle}` — a two-panel dashboard for a specific bundle showing current fields (with Edit, Clone, Delete actions) and available fields (shared storages not yet attached, with Attach links). Navigate between bundles using the tab bar.

## JavaScript

The module ships a small amount of vanilla JS in `js/src/` (plain `Drupal.behaviors`, no imports), declared directly in `bulk_field_config.libraries.yml` with no build step required.

## Running tests

The module has a full functional test suite. Run from the Drupal root inside the web container:

```bash
docker compose exec web env \
  SIMPLETEST_BASE_URL=http://localhost \
  SIMPLETEST_DB=mysql://drupal:drupal@db/drupal \
  BROWSERTEST_OUTPUT_DIRECTORY=/var/www/html/sites/simpletest/browser_output \
  vendor/bin/phpunit -c docroot/core \
  docroot/modules/custom/bulk_field_config/tests/src/Functional
```

Test classes are in `tests/src/Functional/` and cover all wizards, validation, access control, and service operations.
