<?php

declare(strict_types=1);

namespace Drupal\Tests\bulk_field_config\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

class BulkFieldCreateTest extends BrowserTestBase {

  protected static $modules = ['bulk_field_config', 'node', 'field'];

  protected $defaultTheme = 'stark';

  protected function setUp(): void {
    parent::setUp();
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    $this->drupalCreateContentType(['type' => 'page', 'name' => 'Page']);
  }

  public function testCreateFormLoads(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 1);
    $this->assertSession()->fieldExists('entity_type');
    $this->assertSession()->fieldExists('field_type');
  }

  public function testStep1AdvancesToStep2(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm([
      'entity_type' => 'node',
      'field_name' => 'wizard_test',
      'field_type' => 'string',
    ], 'Next →');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 2);
    $this->assertSession()->fieldExists('label');
    $this->assertSession()->fieldExists('cardinality_type');
  }

  public function testStep2AdvancesToStep3(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'wizard_test', 'field_type' => 'string'], 'Next →');
    $this->submitForm(['label' => 'Wizard Test', 'cardinality_type' => '1'], 'Next →');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 3);
    $this->assertSession()->pageTextContains('Attach to bundles');
  }

  public function testStep3AdvancesToStep4(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'wizard_test', 'field_type' => 'string'], 'Next →');
    $this->submitForm(['label' => 'Wizard Test', 'cardinality_type' => '1'], 'Next →');
    $this->submitForm(['bundles[article]' => 'article'], 'Next →');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 4);
    $this->assertSession()->pageTextContains('field_wizard_test');
    $this->assertSession()->buttonExists('Create field');
  }

  public function testBackNavigationFromStep2(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'wizard_test', 'field_type' => 'string'], 'Next →');
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 2);
    $this->submitForm([], '← Back');
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 1);
  }

  public function testBackNavigationFromStep3(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'wizard_test', 'field_type' => 'string'], 'Next →');
    $this->submitForm(['label' => 'Wizard Test', 'cardinality_type' => '1'], 'Next →');
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 3);
    $this->submitForm([], '← Back');
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 2);
  }

  public function testStep2EntityReferenceShowsTargetTypeField(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'wizard_ref', 'field_type' => 'entity_reference'], 'Next →');
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 2);
    $this->assertSession()->fieldExists('target_type');
  }

  public function testStep2NonEntityReferenceHidesTargetTypeField(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'wizard_test', 'field_type' => 'string'], 'Next →');
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 2);
    $this->assertSession()->fieldNotExists('target_type');
  }

  public function testStep2ValidationRejectsCustomCardinalityBelowTwo(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'wizard_test', 'field_type' => 'string'], 'Next →');
    $this->submitForm(['label' => 'Wizard Test', 'cardinality_type' => 'custom', 'cardinality_number' => 1], 'Next →');
    $this->assertSession()->pageTextContains('Custom cardinality must be at least 2');
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 2);
  }

  public function testStep3ValidationRequiresBundleSelection(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'wizard_test', 'field_type' => 'string'], 'Next →');
    $this->submitForm(['label' => 'Wizard Test', 'cardinality_type' => '1'], 'Next →');
    // Submit with nothing checked.
    $this->submitForm([], 'Next →');
    $this->assertSession()->pageTextContains('Select at least one bundle');
    $this->assertSession()->elementsCount('css', '.field-tools-stepper__segment.is-complete', 3);
  }

  public function testFullWizardCreatesFieldAndAttaches(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'full_wizard', 'field_type' => 'string'], 'Next →');
    $this->submitForm(['label' => 'Full Wizard', 'cardinality_type' => '1'], 'Next →');
    $this->submitForm(['bundles[article]' => 'article', 'bundles[page]' => 'page'], 'Next →');
    $this->submitForm([], 'Create field');

    $this->assertSession()->pageTextContains('Created field');
    $this->assertNotNull(FieldStorageConfig::load('node.field_full_wizard'));
    $this->assertNotNull(FieldConfig::loadByName('node', 'article', 'field_full_wizard'));
    $this->assertNotNull(FieldConfig::loadByName('node', 'page', 'field_full_wizard'));
  }

  public function testFullWizardSetsLabel(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'label_test', 'field_type' => 'string'], 'Next →');
    $this->submitForm(['label' => 'My Custom Label', 'cardinality_type' => '1'], 'Next →');
    $this->submitForm(['bundles[article]' => 'article'], 'Next →');
    $this->submitForm([], 'Create field');

    $config = FieldConfig::loadByName('node', 'article', 'field_label_test');
    $this->assertNotNull($config);
    $this->assertEquals('My Custom Label', $config->getLabel());
  }

  public function testFullWizardSetsCardinality(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->submitForm(['entity_type' => 'node', 'field_name' => 'cardinality_test', 'field_type' => 'string'], 'Next →');
    $this->submitForm(['label' => 'Cardinality Test', 'cardinality_type' => 'custom', 'cardinality_number' => 3], 'Next →');
    $this->submitForm(['bundles[article]' => 'article'], 'Next →');
    $this->submitForm([], 'Create field');

    $storage = FieldStorageConfig::load('node.field_cardinality_test');
    $this->assertNotNull($storage);
    $this->assertEquals(3, $storage->getCardinality());
  }

  public function testAccessDeniedWithoutPermission(): void {
    $user = $this->drupalCreateUser([]);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/create');
    $this->assertSession()->statusCodeEquals(403);
  }

}
