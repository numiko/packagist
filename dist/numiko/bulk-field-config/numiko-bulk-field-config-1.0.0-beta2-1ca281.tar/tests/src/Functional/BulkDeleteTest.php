<?php

declare(strict_types=1);

namespace Drupal\Tests\bulk_field_config\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

class BulkDeleteTest extends BrowserTestBase {

  protected static $modules = ['bulk_field_config', 'node', 'field'];

  protected $defaultTheme = 'stark';

  protected function setUp(): void {
    parent::setUp();
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    FieldStorageConfig::create([
      'field_name' => 'field_delete_test',
      'entity_type' => 'node',
      'type' => 'string',
    ])->save();
    FieldConfig::create([
      'field_name' => 'field_delete_test',
      'entity_type' => 'node',
      'bundle' => 'article',
      'label' => 'Delete test',
    ])->save();
  }

  public function testDeleteFormLoads(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_delete_test/delete');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Type the field machine name to confirm');
  }

  public function testDeleteFormFailsWithWrongConfirmation(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_delete_test/delete');
    $this->submitForm([
      'bundles[article]' => 'article',
      'confirm_name' => 'wrong_name',
    ], 'Delete from selected bundles');
    $this->assertSession()->pageTextContains('Field name does not match');
  }

  public function testDeleteRemovesField(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_delete_test/delete');
    $this->submitForm([
      'bundles[article]' => 'article',
      'confirm_name' => 'field_delete_test',
    ], 'Delete from selected bundles');

    $this->assertSession()->pageTextContains('Removed field from 1 bundle(s)');
    $this->assertNull(FieldConfig::loadByName('node', 'article', 'field_delete_test'));
  }

  public function testDeleteStorageWhenLastBundle(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_delete_test/delete');
    $this->submitForm([
      'bundles[article]' => 'article',
      'delete_storage' => TRUE,
      'confirm_name' => 'field_delete_test',
    ], 'Delete from selected bundles');

    $this->assertNull(FieldStorageConfig::load('node.field_delete_test'));
  }

}
