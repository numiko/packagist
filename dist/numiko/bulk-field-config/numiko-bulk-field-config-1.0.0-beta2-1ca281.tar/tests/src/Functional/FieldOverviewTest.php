<?php

declare(strict_types=1);

namespace Drupal\Tests\bulk_field_config\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

class FieldOverviewTest extends BrowserTestBase {

  protected static $modules = [
    'bulk_field_config',
    'node',
    'field',
  ];

  protected $defaultTheme = 'stark';

  public function testOverviewLoads(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->elementExists('css', '.field-tools-overview');
  }

  public function testEntityTypeTabSwitching(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    foreach (['node', 'media', 'paragraph', 'taxonomy_term'] as $entity_type) {
      $this->drupalGet('/admin/config/field-tools/' . $entity_type);
      $this->assertSession()->statusCodeEquals(200);
    }
  }

  public function testSearchFilter(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools', ['query' => ['search' => 'body']]);
    $this->assertSession()->statusCodeEquals(200);
  }

  public function testAccessDeniedWithoutPermission(): void {
    $user = $this->drupalCreateUser([]);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools');
    $this->assertSession()->statusCodeEquals(403);
  }

  public function testFieldDetailLoadsForExistingField(): void {
    // Create a content type with a field so there's something to drill into.
    $this->drupalCreateContentType(['type' => 'test_article', 'name' => 'Test Article']);
    \Drupal::service('entity_type.manager')
      ->getStorage('field_storage_config')
      ->create([
        'field_name' => 'field_test_text',
        'entity_type' => 'node',
        'type' => 'string',
      ])->save();
    \Drupal::service('entity_type.manager')
      ->getStorage('field_config')
      ->create([
        'field_name' => 'field_test_text',
        'entity_type' => 'node',
        'bundle' => 'test_article',
        'label' => 'Test text',
      ])->save();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_test_text');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('field_test_text');
  }

  public function testOverviewTableShowsFieldRows(): void {
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    FieldStorageConfig::create(['field_name' => 'field_overview_row', 'entity_type' => 'node', 'type' => 'string'])->save();
    FieldConfig::create(['field_name' => 'field_overview_row', 'entity_type' => 'node', 'bundle' => 'article', 'label' => 'Overview row'])->save();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools');
    $this->assertSession()->pageTextContains('field_overview_row');
  }

  public function testSearchFilterNarrowsResults(): void {
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    FieldStorageConfig::create(['field_name' => 'field_searchable', 'entity_type' => 'node', 'type' => 'string'])->save();
    FieldConfig::create(['field_name' => 'field_searchable', 'entity_type' => 'node', 'bundle' => 'article', 'label' => 'Searchable'])->save();
    FieldStorageConfig::create(['field_name' => 'field_other', 'entity_type' => 'node', 'type' => 'string'])->save();
    FieldConfig::create(['field_name' => 'field_other', 'entity_type' => 'node', 'bundle' => 'article', 'label' => 'Other'])->save();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools', ['query' => ['search' => 'field_searchable']]);
    $this->assertSession()->pageTextContains('field_searchable');
    $this->assertSession()->pageTextNotContains('field_other');
  }

  public function testFieldDetailShowsTypeAndCardinality(): void {
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    FieldStorageConfig::create(['field_name' => 'field_typed', 'entity_type' => 'node', 'type' => 'integer', 'cardinality' => 3])->save();
    FieldConfig::create(['field_name' => 'field_typed', 'entity_type' => 'node', 'bundle' => 'article', 'label' => 'Typed field'])->save();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_typed');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('field_typed');
    $this->assertSession()->pageTextContains('3');
  }

  public function testFieldDetailShowsActionLinks(): void {
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    FieldStorageConfig::create(['field_name' => 'field_actions', 'entity_type' => 'node', 'type' => 'string'])->save();
    FieldConfig::create(['field_name' => 'field_actions', 'entity_type' => 'node', 'bundle' => 'article', 'label' => 'Actions'])->save();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_actions');
    $this->assertSession()->linkExists('Attach to bundles');
    $this->assertSession()->linkExists('Edit across bundles');
    $this->assertSession()->linkExists('Clone to bundles');
    $this->assertSession()->linkExists('Delete from bundles');
  }

  public function testFieldDetailReturns404ForMissingField(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_does_not_exist');
    $this->assertSession()->statusCodeEquals(404);
  }

}
