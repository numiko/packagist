<?php

declare(strict_types=1);

namespace Drupal\Tests\bulk_field_config\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

class BulkFieldEditTest extends BrowserTestBase {

  protected static $modules = ['bulk_field_config', 'node', 'field'];

  protected $defaultTheme = 'stark';

  protected function setUp(): void {
    parent::setUp();
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    FieldStorageConfig::create([
      'field_name' => 'field_edit_test',
      'entity_type' => 'node',
      'type' => 'string',
    ])->save();
    FieldConfig::create([
      'field_name' => 'field_edit_test',
      'entity_type' => 'node',
      'bundle' => 'article',
      'label' => 'Original label',
      'required' => FALSE,
    ])->save();
  }

  public function testEditFormLoads(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_edit_test/edit');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->fieldValueEquals('bundles[article][label]', 'Original label');
  }

  public function testEditPreviewStep(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_edit_test/edit');
    $this->submitForm(['bundles[article][label]' => 'New label'], 'Preview changes');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->buttonExists('Apply changes');
  }

  public function testEditAppliesChanges(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_edit_test/edit');
    $this->submitForm([
      'bundles[article][label]' => 'Updated label',
      'bundles[article][required]' => TRUE,
    ], 'Preview changes');
    $this->submitForm([], 'Apply changes');

    $this->assertSession()->pageTextContains('Updated 1 bundle instance(s)');
    $config = FieldConfig::loadByName('node', 'article', 'field_edit_test');
    $this->assertEquals('Updated label', $config->getLabel());
    $this->assertTrue($config->isRequired());
  }

  public function testEditUpdatesDescription(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_edit_test/edit');
    $this->submitForm([
      'bundles[article][label]' => 'Original label',
      'bundles[article][description]' => 'A helpful hint',
    ], 'Preview changes');
    $this->submitForm([], 'Apply changes');

    $config = FieldConfig::loadByName('node', 'article', 'field_edit_test');
    $this->assertEquals('A helpful hint', $config->getDescription());
  }

  public function testEditNoChangesSkipsUpdate(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_edit_test/edit');
    // Submit with the existing values unchanged.
    $this->submitForm(['bundles[article][label]' => 'Original label'], 'Preview changes');
    $this->assertSession()->pageTextContains('No changes detected');
  }

}
