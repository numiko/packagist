<?php

declare(strict_types=1);

namespace Drupal\Tests\bulk_field_config\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

/**
 * Functional tests for BulkManagerController.
 *
 * @group bulk_field_config
 */
class BulkManagerTest extends BrowserTestBase {

  protected static $modules = ['bulk_field_config', 'node', 'field'];

  protected $defaultTheme = 'stark';

  /**
   * Shared field storage name used across tests.
   */
  private const FIELD_NAME = 'field_manager_test';

  protected function setUp(): void {
    parent::setUp();

    // Create article and page content types.
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    $this->drupalCreateContentType(['type' => 'page', 'name' => 'Page']);

    // Create a shared field storage.
    FieldStorageConfig::create([
      'field_name' => self::FIELD_NAME,
      'entity_type' => 'node',
      'type' => 'string',
    ])->save();

    // Attach the field to article only.
    FieldConfig::create([
      'field_name' => self::FIELD_NAME,
      'entity_type' => 'node',
      'bundle' => 'article',
      'label' => 'Manager Test Field',
    ])->save();
  }

  public function testManagerPageLoads(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/manager/node/article');
    $this->assertSession()->statusCodeEquals(200);
  }

  public function testManagerShowsBundleTabs(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/manager/node/article');
    $this->assertSession()->statusCodeEquals(200);
    // Both content types should appear as bundle tabs.
    $this->assertSession()->pageTextContains('Article');
    $this->assertSession()->pageTextContains('Page');
  }

  public function testManagerShowsCurrentField(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/manager/node/article');
    $this->assertSession()->statusCodeEquals(200);
    // The field attached to article should appear in the current fields panel.
    $this->assertSession()->pageTextContains(self::FIELD_NAME);
    $this->assertSession()->pageTextContains('Manager Test Field');
  }

  public function testManagerShowsAvailableField(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    // On the page bundle, field_manager_test is not yet attached → available.
    $this->drupalGet('/admin/config/field-tools/manager/node/page');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains(self::FIELD_NAME);
  }

  public function testManagerActionLinksPresent(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/manager/node/article');
    // Current fields panel should have Edit, Clone, Delete action links.
    $this->assertSession()->linkExists('Edit');
    $this->assertSession()->linkExists('Clone');
    $this->assertSession()->linkExists('Delete');
  }

  public function testManagerAvailableFieldHasAttachLink(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    // On page, the field is available and should show an Attach link.
    $this->drupalGet('/admin/config/field-tools/manager/node/page');
    $this->assertSession()->linkExists('Attach');
  }

  public function testManagerSwitchToDifferentBundle(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/manager/node/page');
    $this->assertSession()->statusCodeEquals(200);
    // The page panel should load and show the correct heading.
    $this->assertSession()->elementExists('css', '.field-tools-manager');
  }

  public function testManagerAccessDenied(): void {
    $user = $this->drupalCreateUser([]);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/manager/node/article');
    $this->assertSession()->statusCodeEquals(403);
  }

  public function testManagerCurrentFieldsEmptyMessage(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    // Create a bundle with no fields attached.
    $this->drupalCreateContentType(['type' => 'empty_bundle', 'name' => 'Empty Bundle']);
    // drupalCreateContentType adds a body field by default — remove it so the bundle is truly empty.
    FieldConfig::loadByName('node', 'empty_bundle', 'body')?->delete();
    $this->drupalGet('/admin/config/field-tools/manager/node/empty_bundle');
    $this->assertSession()->pageTextContains('No fields attached to this bundle.');
  }

}
