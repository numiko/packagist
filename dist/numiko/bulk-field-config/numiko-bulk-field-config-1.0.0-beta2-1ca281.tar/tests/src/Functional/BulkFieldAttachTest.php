<?php

declare(strict_types=1);

namespace Drupal\Tests\bulk_field_config\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

class BulkFieldAttachTest extends BrowserTestBase {

  protected static $modules = ['bulk_field_config', 'node', 'field'];

  protected $defaultTheme = 'stark';

  private function createTestField(string $entity_type = 'node'): void {
    FieldStorageConfig::create([
      'field_name' => 'field_attach_test',
      'entity_type' => $entity_type,
      'type' => 'string',
    ])->save();
  }

  public function testAttachFormLoads(): void {
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    $this->createTestField();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_attach_test/attach');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->pageTextContains('Attach to bundles');
  }

  public function testAttachFormShowsNoBundlesWhenAllAttached(): void {
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    $this->createTestField();
    FieldConfig::create([
      'field_name' => 'field_attach_test',
      'entity_type' => 'node',
      'bundle' => 'article',
      'label' => 'Test',
    ])->save();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_attach_test/attach');
    $this->assertSession()->pageTextContains('already attached to all available bundles');
  }

  public function testAttachPreviewStep(): void {
    $this->drupalCreateContentType(['type' => 'page', 'name' => 'Page']);
    $this->createTestField();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_attach_test/attach');
    $this->submitForm(['bundles[page]' => 'page'], 'Preview');
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->buttonExists('Confirm & attach');
  }

  public function testAttachConfirm(): void {
    $this->drupalCreateContentType(['type' => 'blog', 'name' => 'Blog']);
    $this->createTestField();

    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);
    $this->drupalGet('/admin/config/field-tools/field/node/field_attach_test/attach');
    $this->submitForm(['bundles[blog]' => 'blog'], 'Preview');
    $this->submitForm([], 'Confirm & attach');

    $this->assertSession()->pageTextContains('Attached field to 1 bundle(s)');
    $this->assertNotNull(FieldConfig::loadByName('node', 'blog', 'field_attach_test'));
  }

}
