<?php

declare(strict_types=1);

namespace Drupal\Tests\bulk_field_config\Functional;

use Drupal\Tests\BrowserTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

/**
 * Verifies every route returns 403 for a user without the required permission.
 */
class AccessControlTest extends BrowserTestBase {

  protected static $modules = ['bulk_field_config', 'node', 'field'];

  protected $defaultTheme = 'stark';

  protected function setUp(): void {
    parent::setUp();
    $this->drupalCreateContentType(['type' => 'article', 'name' => 'Article']);
    FieldStorageConfig::create([
      'field_name' => 'field_access_test',
      'entity_type' => 'node',
      'type' => 'string',
    ])->save();
    FieldConfig::create([
      'field_name' => 'field_access_test',
      'entity_type' => 'node',
      'bundle' => 'article',
      'label' => 'Access test',
    ])->save();
  }

  public function testAllEndpointsReturn403WithoutPermission(): void {
    $user = $this->drupalCreateUser([]);
    $this->drupalLogin($user);

    $paths = [
      '/admin/config/field-tools',
      '/admin/config/field-tools/node',
      '/admin/config/field-tools/media',
      '/admin/config/field-tools/paragraph',
      '/admin/config/field-tools/taxonomy_term',
      '/admin/config/field-tools/field/node/field_access_test',
      '/admin/config/field-tools/create',
      '/admin/config/field-tools/field/node/field_access_test/attach',
      '/admin/config/field-tools/field/node/field_access_test/edit',
      '/admin/config/field-tools/field/node/field_access_test/delete',
      '/admin/config/field-tools/field/node/field_access_test/clone',
      '/admin/config/field-tools/clone-display',
      '/admin/config/field-tools/manager/node/article',
    ];

    foreach ($paths as $path) {
      $this->drupalGet($path);
      $this->assertSame(403, $this->getSession()->getStatusCode(), "Expected 403 for: $path");
    }
  }

  public function testAllEndpointsReturn200WithPermission(): void {
    $user = $this->drupalCreateUser(['administer bulk field config']);
    $this->drupalLogin($user);

    $paths = [
      '/admin/config/field-tools',
      '/admin/config/field-tools/node',
      '/admin/config/field-tools/media',
      '/admin/config/field-tools/paragraph',
      '/admin/config/field-tools/taxonomy_term',
      '/admin/config/field-tools/field/node/field_access_test',
      '/admin/config/field-tools/create',
      '/admin/config/field-tools/field/node/field_access_test/attach',
      '/admin/config/field-tools/field/node/field_access_test/edit',
      '/admin/config/field-tools/field/node/field_access_test/delete',
      '/admin/config/field-tools/field/node/field_access_test/clone',
      '/admin/config/field-tools/clone-display',
      '/admin/config/field-tools/manager/node/article',
    ];

    foreach ($paths as $path) {
      $this->drupalGet($path);
      $this->assertSame(200, $this->getSession()->getStatusCode(), "Expected 200 for: $path");
    }
  }

  public function testAnonymousUserIsRedirectedToLoginOrDenied(): void {
    $this->drupalGet('/admin/config/field-tools');
    $code = $this->getSession()->getStatusCode();
    $url = $this->getUrl();
    $this->assertTrue(
      $code === 403 || str_contains($url, 'user/login'),
      "Expected 403 or login redirect for anonymous user, got {$code} at {$url}",
    );
  }

}
