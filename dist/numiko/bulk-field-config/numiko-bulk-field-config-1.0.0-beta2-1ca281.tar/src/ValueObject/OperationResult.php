<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\ValueObject;

final class OperationResult {

  private function __construct(
    public readonly string $bundle,
    public readonly string $status,
    public readonly string $message,
  ) {}

  public static function success(string $bundle, string $message = ''): static {
    return new static($bundle, 'success', $message);
  }

  public static function skipped(string $bundle, string $message): static {
    return new static($bundle, 'skipped', $message);
  }

  public static function error(string $bundle, string $message): static {
    return new static($bundle, 'error', $message);
  }

  public static function dryRun(string $bundle, string $message): static {
    return new static($bundle, 'dry_run', $message);
  }

  public function isSuccess(): bool { return $this->status === 'success'; }
  public function isSkipped(): bool { return $this->status === 'skipped'; }
  public function isError(): bool { return $this->status === 'error'; }
  public function isDryRun(): bool { return $this->status === 'dry_run'; }

}
