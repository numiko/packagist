<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Hook;

use Drupal\Core\Hook\Attribute\Hook;

final class BulkFieldConfigHooks {

  #[Hook('theme')]
  public function theme(): array {
    return [
      'field_overview' => [
        'variables' => [
          'entity_type' => NULL,
          'tabs' => [],
          'table' => [],
          'search_form' => [],
          'create_link' => [],
          'field_count' => 0,
        ],
      ],
      'field_detail' => [
        'variables' => [
          'entity_type' => NULL,
          'field_name' => NULL,
          'type_label' => NULL,
          'cardinality_label' => NULL,
          'is_locked' => FALSE,
          'stat_chips' => [],
          'instances_table' => [],
          'back_link' => [],
          'action_primary' => [],
          'action_toolbar' => [],
          'action_delete' => [],
        ],
      ],
      'bulk_manager' => [
        'variables' => [
          'entity_type' => NULL,
          'bundle' => NULL,
          'bundle_tabs' => [],
          'field_summary' => NULL,
          'current_fields' => [],
          'available_fields' => [],
        ],
      ],
    ];
  }

}
