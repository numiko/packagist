<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Service;

use Drupal\bulk_field_config\ValueObject\OperationResult;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

final class BulkFieldAttachService {

  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    protected readonly LoggerChannelFactoryInterface $loggerFactory,
  ) {}

  public function canAttach(string $entity_type, string $field_name, string $bundle): bool {
    $storage = FieldStorageConfig::load($entity_type . '.' . $field_name);
    if (!$storage || $storage->getTargetEntityTypeId() !== $entity_type) {
      return FALSE;
    }
    return FieldConfig::loadByName($entity_type, $bundle, $field_name) === NULL;
  }

  /**
   * Returns FieldStorageConfigs not yet attached to the given bundle.
   *
   * @return \Drupal\field\Entity\FieldStorageConfig[]
   */
  public function getAttachableStorages(string $entity_type, string $bundle): array {
    $storages = $this->entityTypeManager
      ->getStorage('field_storage_config')
      ->loadByProperties(['entity_type' => $entity_type]);

    return array_filter(
      $storages,
      fn($storage) => FieldConfig::loadByName($entity_type, $bundle, $storage->getName()) === NULL,
    );
  }

  /**
   * @param array $options  Keys: label (string), required (bool).
   * @return OperationResult[]
   */
  public function attach(string $entity_type, string $field_name, array $bundles, array $options = [], bool $dry_run = FALSE): array {
    $results = [];
    foreach ($bundles as $bundle) {
      if (!$this->canAttach($entity_type, $field_name, $bundle)) {
        $results[] = OperationResult::skipped($bundle, "Already attached or storage not found.");
        continue;
      }

      if ($dry_run) {
        $results[] = OperationResult::dryRun($bundle, "Would create FieldConfig for {$field_name} on {$bundle}.");
        continue;
      }

      try {
        $storage = FieldStorageConfig::load($entity_type . '.' . $field_name);
        $field_config = FieldConfig::create([
          'field_name' => $field_name,
          'entity_type' => $entity_type,
          'bundle' => $bundle,
          'label' => $options['label'] ?: ((string) $storage->getLabel() ?: $field_name),
          'required' => (bool) ($options['required'] ?? FALSE),
        ]);
        $field_config->save();

        $this->addToFormDisplay($entity_type, $bundle, $field_name);

        $results[] = OperationResult::success($bundle, "Attached {$field_name} to {$bundle}.");
      }
      catch (\Exception $e) {
        $results[] = OperationResult::error($bundle, $e->getMessage());
        $this->loggerFactory->get('bulk_field_config')->error(
          'Failed to attach @field to @bundle: @msg',
          ['@field' => $field_name, '@bundle' => $bundle, '@msg' => $e->getMessage()],
        );
      }
    }
    return $results;
  }

  protected function addToFormDisplay(string $entity_type, string $bundle, string $field_name): void {
    $display = $this->entityTypeManager
      ->getStorage('entity_form_display')
      ->load($entity_type . '.' . $bundle . '.default');

    if (!$display) {
      return;
    }

    $display->setComponent($field_name, ['weight' => 99])->save();
  }

}
