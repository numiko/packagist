<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Service;

use Drupal\bulk_field_config\ValueObject\OperationResult;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\field\Entity\FieldConfig;

final class BulkDisplayCloneService {

  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    protected readonly LoggerChannelFactoryInterface $loggerFactory,
    protected readonly BulkFieldQueryService $queryService,
  ) {}

  /**
   * Returns display modes that exist for the given entity type, bundle, and display type.
   *
   * @param string $display_type 'view' or 'form'
   * @return array<string, string> mode_id => label
   */
  public function getAvailableModes(string $entity_type, string $bundle, string $display_type): array {
    $storage_id = $display_type === 'form' ? 'entity_form_display' : 'entity_view_display';
    $displays = $this->entityTypeManager->getStorage($storage_id)
      ->loadByProperties(['targetEntityType' => $entity_type, 'bundle' => $bundle, 'status' => TRUE]);
    $modes = [];
    foreach ($displays as $display) {
      $mode = $display->getMode();
      $modes[$mode] = $mode === 'default' ? 'Default' : ucwords(str_replace('_', ' ', $mode));
    }
    return $modes;
  }

  /**
   * Returns bundles where the target display mode does NOT already exist.
   *
   * Bundles that already have the target mode are excluded — they cannot be targets.
   *
   * @param string $display_type 'view' or 'form'
   * @return array<string, string> bundle_id => label
   */
  public function getEligibleTargets(string $entity_type, string $source_bundle, string $source_mode, string $target_mode, string $display_type): array {
    $storage_id = $display_type === 'form' ? 'entity_form_display' : 'entity_view_display';
    $all_bundles = $this->queryService->getAllBundles($entity_type);
    $result = [];

    foreach ($all_bundles as $bundle_id => $label) {
      // Skip same-bundle same-mode clone.
      if ($bundle_id === $source_bundle && $source_mode === $target_mode) {
        continue;
      }
      $existing = $this->entityTypeManager->getStorage($storage_id)
        ->load("{$entity_type}.{$bundle_id}.{$target_mode}");
      if ($existing === NULL) {
        $result[$bundle_id] = $label;
      }
    }

    return $result;
  }

  /**
   * Clones a display from source to target bundles.
   *
   * Fields on the source display that do not exist on a target bundle are removed
   * from the cloned display for that bundle (reported in the result message).
   *
   * @param string $display_type 'view' or 'form'
   * @return OperationResult[]
   */
  public function clone(string $entity_type, string $source_bundle, string $source_mode, array $target_bundles, string $target_mode, string $display_type, bool $dry_run = FALSE): array {
    $storage_id = $display_type === 'form' ? 'entity_form_display' : 'entity_view_display';

    $source_display = $this->entityTypeManager->getStorage($storage_id)
      ->load("{$entity_type}.{$source_bundle}.{$source_mode}");

    if (!$source_display) {
      return [OperationResult::error('*', "Source display not found: {$entity_type}.{$source_bundle}.{$source_mode}")];
    }

    $results = [];
    foreach ($target_bundles as $bundle) {
      $existing = $this->entityTypeManager->getStorage($storage_id)
        ->load("{$entity_type}.{$bundle}.{$target_mode}");

      if ($existing !== NULL) {
        $results[] = OperationResult::skipped($bundle, "Display mode '{$target_mode}' already exists on {$bundle} — skipped.");
        continue;
      }

      if ($dry_run) {
        $skipped_fields = $this->findMissingFields($source_display, $entity_type, $bundle);
        $note = $skipped_fields
          ? " Note: " . count($skipped_fields) . " field(s) not on target will be omitted."
          : '';
        $results[] = OperationResult::dryRun($bundle, "Would clone {$source_mode} display to {$bundle}/{$target_mode}.{$note}");
        continue;
      }

      try {
        $new_display = $source_display->createDuplicate();
        $new_display->set('bundle', $bundle);
        $new_display->set('id', "{$entity_type}.{$bundle}.{$target_mode}");
        $new_display->set('mode', $target_mode);

        // Remove components for fields that don't exist on the target bundle.
        foreach ($this->findMissingFields($new_display, $entity_type, $bundle) as $field_name) {
          $new_display->removeComponent($field_name);
        }

        $new_display->save();
        $results[] = OperationResult::success($bundle, "Cloned {$source_mode} display to {$bundle}/{$target_mode}.");
      }
      catch (\Exception $e) {
        $results[] = OperationResult::error($bundle, $e->getMessage());
        $this->loggerFactory->get('bulk_field_config')->error(
          'Failed to clone display to @bundle/@mode: @msg',
          ['@bundle' => $bundle, '@mode' => $target_mode, '@msg' => $e->getMessage()],
        );
      }
    }

    return $results;
  }

  /**
   * Returns field names that appear in the display but don't exist on the target bundle.
   */
  private function findMissingFields(object $display, string $entity_type, string $bundle): array {
    $missing = [];
    foreach (array_keys($display->getComponents()) as $field_name) {
      // Only check configurable fields (field_* prefix convention).
      if (str_starts_with($field_name, 'field_') && !FieldConfig::loadByName($entity_type, $bundle, $field_name)) {
        $missing[] = $field_name;
      }
    }
    return $missing;
  }

}
