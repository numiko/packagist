<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Service;

use Drupal\bulk_field_config\ValueObject\OperationResult;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\field\Entity\FieldConfig;

final class BulkFieldCloneService {

  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    protected readonly LoggerChannelFactoryInterface $loggerFactory,
    protected readonly BulkFieldQueryService $queryService,
  ) {}

  /**
   * Returns bundles that don't already have this field (eligible clone targets).
   *
   * @return array<string, string> bundle_id => label
   */
  public function getCloneableTargets(string $entity_type, string $field_name, string $source_bundle): array {
    $all_bundles = $this->queryService->getAllBundles($entity_type);
    $result = [];
    foreach ($all_bundles as $bundle_id => $label) {
      if ($bundle_id === $source_bundle) {
        continue;
      }
      if (FieldConfig::loadByName($entity_type, $bundle_id, $field_name) === NULL) {
        $result[$bundle_id] = $label;
      }
    }
    return $result;
  }

  /**
   * Returns view modes that have an active display for this entity type + bundle.
   *
   * @return array<string, string> mode_id => label
   */
  public function getAvailableViewModes(string $entity_type, string $bundle): array {
    return $this->loadDisplayModes('entity_view_display', $entity_type, $bundle);
  }

  /**
   * Returns form modes that have an active display for this entity type + bundle.
   *
   * @return array<string, string> mode_id => label
   */
  public function getAvailableFormModes(string $entity_type, string $bundle): array {
    return $this->loadDisplayModes('entity_form_display', $entity_type, $bundle);
  }

  /**
   * Clones a FieldConfig from source bundle to one or more target bundles.
   *
   * @param array $options  Keys: label_override (string), copy_displays (bool), view_modes (string[]), form_modes (string[]).
   * @return OperationResult[]
   */
  public function clone(string $entity_type, string $field_name, string $source_bundle, array $target_bundles, array $options = [], bool $dry_run = FALSE): array {
    $source_config = FieldConfig::loadByName($entity_type, $source_bundle, $field_name);
    if (!$source_config) {
      return [OperationResult::error('*', "Source field config not found: {$entity_type}.{$source_bundle}.{$field_name}")];
    }

    $results = [];
    foreach ($target_bundles as $bundle) {
      if (FieldConfig::loadByName($entity_type, $bundle, $field_name) !== NULL) {
        $results[] = OperationResult::skipped($bundle, "Field already exists on {$bundle} — skipped.");
        continue;
      }

      if ($dry_run) {
        $label = !empty($options['label_override']) ? $options['label_override'] : $source_config->getLabel();
        $results[] = OperationResult::dryRun($bundle, "Would clone {$field_name} ({$label}) from {$source_bundle} to {$bundle}.");
        continue;
      }

      try {
        $new_config = $source_config->createDuplicate();
        $new_config->set('bundle', $bundle);
        $new_config->set('id', "{$entity_type}.{$bundle}.{$field_name}");

        if (!empty($options['label_override'])) {
          $new_config->set('label', $options['label_override']);
        }

        $new_config->save();

        if (!empty($options['copy_displays'])) {
          $this->copyDisplayComponents(
            $entity_type,
            $field_name,
            $source_bundle,
            $bundle,
            $options['view_modes'] ?? [],
            $options['form_modes'] ?? [],
          );
        }

        $results[] = OperationResult::success($bundle, "Cloned {$field_name} from {$source_bundle} to {$bundle}.");
      }
      catch (\Exception $e) {
        $results[] = OperationResult::error($bundle, $e->getMessage());
        $this->loggerFactory->get('bulk_field_config')->error(
          'Failed to clone @field to @bundle: @msg',
          ['@field' => $field_name, '@bundle' => $bundle, '@msg' => $e->getMessage()],
        );
      }
    }

    return $results;
  }

  protected function copyDisplayComponents(string $entity_type, string $field_name, string $source_bundle, string $target_bundle, array $view_modes, array $form_modes): void {
    foreach ($view_modes as $mode) {
      $this->copyComponentToDisplay('entity_view_display', $entity_type, $field_name, $source_bundle, $target_bundle, $mode);
    }
    foreach ($form_modes as $mode) {
      $this->copyComponentToDisplay('entity_form_display', $entity_type, $field_name, $source_bundle, $target_bundle, $mode);
    }
  }

  private function copyComponentToDisplay(string $storage_id, string $entity_type, string $field_name, string $source_bundle, string $target_bundle, string $mode): void {
    $source_display = $this->entityTypeManager->getStorage($storage_id)
      ->load("{$entity_type}.{$source_bundle}.{$mode}");
    if (!$source_display) {
      return;
    }

    $component = $source_display->getComponent($field_name);
    if (!$component) {
      return;
    }

    $target_display = $this->entityTypeManager->getStorage($storage_id)
      ->load("{$entity_type}.{$target_bundle}.{$mode}");
    if ($target_display) {
      $target_display->setComponent($field_name, $component)->save();
    }
  }

  private function loadDisplayModes(string $storage_id, string $entity_type, string $bundle): array {
    $displays = $this->entityTypeManager->getStorage($storage_id)
      ->loadByProperties(['targetEntityType' => $entity_type, 'bundle' => $bundle, 'status' => TRUE]);
    $modes = [];
    foreach ($displays as $display) {
      $mode = $display->getMode();
      $modes[$mode] = $mode === 'default' ? 'Default' : ucwords(str_replace('_', ' ', $mode));
    }
    return $modes;
  }

}
