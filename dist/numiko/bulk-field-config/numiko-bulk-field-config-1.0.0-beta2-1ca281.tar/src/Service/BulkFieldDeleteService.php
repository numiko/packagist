<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Service;

use Drupal\bulk_field_config\ValueObject\OperationResult;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

final class BulkFieldDeleteService {

  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    protected readonly LoggerChannelFactoryInterface $loggerFactory,
    protected readonly ConfigFactoryInterface $configFactory,
  ) {}

  public function getBatchThreshold(): int {
    return (int) $this->configFactory->get('bulk_field_config.settings')->get('batch_threshold');
  }

  public function getDataCount(string $entity_type, string $bundle, string $field_name): int {
    $definition = $this->entityTypeManager->getDefinition($entity_type, FALSE);
    if (!$definition) {
      return 0;
    }

    $query = $this->entityTypeManager
      ->getStorage($entity_type)
      ->getQuery()
      ->condition($field_name, NULL, 'IS NOT NULL')
      ->accessCheck(FALSE);

    $bundle_key = $definition->getKey('bundle');
    if ($bundle_key) {
      $query->condition($bundle_key, $bundle);
    }

    return (int) $query->count()->execute();
  }

  /**
   * @return OperationResult[]
   */
  public function delete(string $entity_type, string $field_name, array $bundles, bool $delete_storage = FALSE, bool $dry_run = FALSE): array {
    $results = [];

    foreach ($bundles as $bundle) {
      $config = FieldConfig::loadByName($entity_type, $bundle, $field_name);

      if (!$config) {
        $results[] = OperationResult::skipped($bundle, "Field is not attached to {$bundle}.");
        continue;
      }

      if ($dry_run) {
        $results[] = OperationResult::dryRun($bundle, "Would remove FieldConfig for {$field_name} from {$bundle}.");
        continue;
      }

      try {
        $config->delete();
        $results[] = OperationResult::success($bundle, "Removed {$field_name} from {$bundle}.");
      }
      catch (\Exception $e) {
        $results[] = OperationResult::error($bundle, $e->getMessage());
        $this->loggerFactory->get('bulk_field_config')->error(
          'Failed to delete @field from @bundle: @msg',
          ['@field' => $field_name, '@bundle' => $bundle, '@msg' => $e->getMessage()],
        );
      }
    }

    if (!$dry_run && $delete_storage) {
      $remaining = $this->entityTypeManager
        ->getStorage('field_config')
        ->loadByProperties(['entity_type' => $entity_type, 'field_name' => $field_name]);

      if (empty($remaining)) {
        $storage = FieldStorageConfig::load($entity_type . '.' . $field_name);
        if ($storage && !$storage->isLocked()) {
          try {
            $storage->delete();
          }
          catch (\Exception $e) {
            $this->loggerFactory->get('bulk_field_config')->error(
              'Failed to delete storage @field: @msg',
              ['@field' => $field_name, '@msg' => $e->getMessage()],
            );
          }
        }
      }
    }

    return $results;
  }

  public static function batchDelete(string $entity_type, string $field_name, string $bundle, array &$context): void {
    /** @var static $service */
    $service = \Drupal::service('bulk_field_config.bulk_field_delete');
    $results = $service->delete($entity_type, $field_name, [$bundle]);
    $context['results'] = array_merge($context['results'] ?? [], $results);
    $context['message'] = t('Removing @field from @bundle…', ['@field' => $field_name, '@bundle' => $bundle]);
  }

  public static function batchDeleteStorage(string $entity_type, string $field_name, array &$context): void {
    /** @var static $service */
    $service = \Drupal::service('bulk_field_config.bulk_field_delete');
    $remaining = \Drupal::entityTypeManager()
      ->getStorage('field_config')
      ->loadByProperties(['entity_type' => $entity_type, 'field_name' => $field_name]);

    if (empty($remaining)) {
      $storage = FieldStorageConfig::load($entity_type . '.' . $field_name);
      if ($storage && !$storage->isLocked()) {
        $storage->delete();
        $context['results'][] = OperationResult::success('storage', "Deleted storage for {$field_name}.");
      }
    }
  }

  public static function batchFinished(bool $success, array $results, array $operations): void {
    if (!$success) {
      \Drupal::messenger()->addError(t('Batch processing encountered an error.'));
      return;
    }
    $success_count = count(array_filter($results, static fn($r) => $r instanceof OperationResult && $r->isSuccess()));
    $error_count = count(array_filter($results, static fn($r) => $r instanceof OperationResult && $r->isError()));
    if ($success_count) {
      \Drupal::messenger()->addStatus(t('Removed field from @count bundle(s).', ['@count' => $success_count]));
    }
    if ($error_count) {
      \Drupal::messenger()->addError(t('Failed on @count bundle(s) — check the logs.', ['@count' => $error_count]));
    }
  }

}
