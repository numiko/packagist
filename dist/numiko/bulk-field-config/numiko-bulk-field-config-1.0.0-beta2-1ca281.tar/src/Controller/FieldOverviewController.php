<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\bulk_field_config\Service\BulkFieldQueryService;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

final class FieldOverviewController extends ControllerBase {

  public function __construct(
    protected readonly BulkFieldQueryService $bulkFieldQuery,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('bulk_field_config.bulk_field_query'),
    );
  }

  public function overview(Request $request, string $entity_type = 'node'): array {
    $search = trim((string) $request->query->get('search', ''));

    $entity_type_labels = BulkFieldQueryService::ENTITY_TYPE_LABELS;

    $tabs = [];
    foreach ($entity_type_labels as $type => $label) {
      $tabs[] = [
        'url' => Url::fromRoute('bulk_field_config.overview_type', ['entity_type' => $type])->toString(),
        'label' => $this->t($label),
        'active' => $type === $entity_type,
      ];
    }

    $summaries = $this->bulkFieldQuery->getFieldStorageSummaries($entity_type);

    if ($search !== '') {
      $search_lower = mb_strtolower($search);
      $summaries = array_filter(
        $summaries,
        static fn($s, $name) => str_contains(mb_strtolower($name), $search_lower),
        ARRAY_FILTER_USE_BOTH,
      );
    }

    $rows = [];
    foreach ($summaries as $field_name => $summary) {
      $cardinality = $summary['cardinality'] === -1
        ? $this->t('Unlimited')
        : (string) $summary['cardinality'];

      $rows[] = [
        [
          'data' => [
            '#type' => 'link',
            '#title' => $field_name,
            '#url' => Url::fromRoute('bulk_field_config.field_detail', [
              'entity_type' => $entity_type,
              'field_name' => $field_name,
            ]),
          ],
        ],
        [
          'data' => [
            '#type' => 'container',
            '#attributes' => ['class' => ['field-tools-type']],
            'dot' => [
              '#type' => 'container',
              '#attributes' => [
                'class' => ['field-tools-type__dot'],
                'style' => 'background: ' . BulkFieldQueryService::getTypeDotColor($summary['type']) . ';',
              ],
            ],
            'label' => ['#plain_text' => $this->bulkFieldQuery->getTypeLabel($summary['type'])],
          ],
        ],
        $cardinality,
        (string) $summary['bundle_count'],
        implode(', ', $summary['bundles']),
      ];
    }

    $table = [
      '#type' => 'table',
      '#header' => [
        $this->t('Field name'),
        $this->t('Type'),
        $this->t('Cardinality'),
        $this->t('Bundles'),
        $this->t('Used in'),
      ],
      '#rows' => $rows,
      '#empty' => $search !== ''
        ? $this->t('No fields matching "@search".', ['@search' => $search])
        : $this->t('No custom fields found for this entity type.'),
      '#attributes' => ['class' => ['field-tools-table']],
    ];

    $search_form = $this->formBuilder()->getForm(
      '\Drupal\bulk_field_config\Form\FieldSearchForm',
      $entity_type,
      $search,
    );

    $create_link = [
      '#type' => 'link',
      '#title' => $this->t('+ Create new field'),
      '#url' => Url::fromRoute('bulk_field_config.create', [], ['query' => ['entity_type' => $entity_type]]),
      '#attributes' => ['class' => ['button', 'button--primary', 'button--small']],
    ];

    return [
      '#theme' => 'field_overview',
      '#entity_type' => $entity_type,
      '#tabs' => $tabs,
      '#table' => $table,
      '#search_form' => $search_form,
      '#create_link' => $create_link,
      '#field_count' => count($summaries),
      '#attached' => ['library' => ['bulk_field_config/admin']],
      '#cache' => ['max-age' => 0],
    ];
  }

}
