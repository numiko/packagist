<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Url;
use Drupal\bulk_field_config\Service\BulkFieldQueryService;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

final class FieldDetailController extends ControllerBase {

  public function __construct(
    protected readonly BulkFieldQueryService $bulkFieldQuery,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('bulk_field_config.bulk_field_query'),
    );
  }

  public function detail(string $entity_type, string $field_name): array {
    $detail = $this->bulkFieldQuery->getFieldStorageDetail($entity_type, $field_name);
    if (!$detail) {
      throw new NotFoundHttpException();
    }

    $storage = $detail['storage'];
    $cardinality = $storage->getCardinality();
    $cardinality_label = $cardinality === -1
      ? $this->t('Unlimited')
      : (string) $cardinality;

    $rows = [];
    foreach ($detail['instances'] as $bundle => $config) {
      $bundle_label = $this->bulkFieldQuery->getBundleLabel($entity_type, $bundle);
      $rows[] = [
        $bundle_label . ' (' . $bundle . ')',
        (string) $config->getLabel(),
        $config->isRequired() ? $this->t('Yes') : $this->t('No'),
        (string) ($config->getDescription() ?: '—'),
      ];
    }

    $instances_table = [
      '#type' => 'table',
      '#header' => [
        $this->t('Bundle'),
        $this->t('Label'),
        $this->t('Required'),
        $this->t('Description'),
      ],
      '#rows' => $rows,
      '#empty' => $this->t('This field is not attached to any bundles.'),
      '#attributes' => ['class' => ['field-tools-table']],
    ];

    $back_link = [
      '#type' => 'link',
      '#title' => $this->t('← Back to overview'),
      '#url' => Url::fromRoute('bulk_field_config.overview_type', ['entity_type' => $entity_type]),
      '#attributes' => ['class' => ['button', 'button--small', 'button--secondary']],
    ];

    $actions = [
      '#type' => 'container',
      '#attributes' => ['class' => ['field-tools-actions']],
      'attach' => [
        '#type' => 'link',
        '#title' => $this->t('Attach to bundles'),
        '#url' => Url::fromRoute('bulk_field_config.attach', ['entity_type' => $entity_type, 'field_name' => $field_name]),
        '#attributes' => ['class' => ['button', 'button--small', 'button--primary']],
      ],
      'edit' => [
        '#type' => 'link',
        '#title' => $this->t('Edit across bundles'),
        '#url' => Url::fromRoute('bulk_field_config.edit', ['entity_type' => $entity_type, 'field_name' => $field_name]),
        '#attributes' => ['class' => ['button', 'button--small']],
      ],
      'clone' => [
        '#type' => 'link',
        '#title' => $this->t('Clone to bundles'),
        '#url' => Url::fromRoute('bulk_field_config.clone_field', ['entity_type' => $entity_type, 'field_name' => $field_name]),
        '#attributes' => ['class' => ['button', 'button--small']],
      ],
      'delete' => [
        '#type' => 'link',
        '#title' => $this->t('Delete from bundles'),
        '#url' => Url::fromRoute('bulk_field_config.delete', ['entity_type' => $entity_type, 'field_name' => $field_name]),
        '#attributes' => ['class' => ['button', 'button--small', 'button--danger']],
      ],
    ];

    // Add a "Manage" link pointing to the manager for the first attached bundle.
    $first_bundle = array_key_first($detail['instances']);
    if ($first_bundle !== NULL) {
      $actions['manage'] = [
        '#type' => 'link',
        '#title' => $this->t('Manage bundle fields'),
        '#url' => Url::fromRoute('bulk_field_config.manager', [
          'entity_type' => $entity_type,
          'bundle' => $first_bundle,
        ]),
        '#attributes' => ['class' => ['button', 'button--small']],
      ];
    }

    $action_toolbar = [
      '#type' => 'container',
      '#attributes' => ['class' => ['field-tools-action-toolbar']],
      'edit' => $actions['edit'],
      'clone' => $actions['clone'],
    ];
    if (isset($actions['manage'])) {
      $action_toolbar['manage'] = $actions['manage'];
    }

    $type_label = $this->bulkFieldQuery->getTypeLabel($storage->getType());
    $stat_chips = [
      [
        'label' => $type_label,
        'dot_color' => BulkFieldQueryService::getTypeDotColor($storage->getType()),
      ],
      [
        'label' => $cardinality === -1 ? $this->t('Unlimited cardinality') : $this->t('Cardinality: @count', ['@count' => $cardinality]),
        'dot_color' => NULL,
      ],
      [
        'label' => $this->formatPlural(count($detail['instances']), 'Used in 1 bundle', 'Used in @count bundles'),
        'dot_color' => NULL,
      ],
    ];

    return [
      '#theme' => 'field_detail',
      '#entity_type' => $entity_type,
      '#field_name' => $field_name,
      '#type_label' => $type_label,
      '#cardinality_label' => $cardinality_label,
      '#is_locked' => $storage->isLocked(),
      '#stat_chips' => $stat_chips,
      '#instances_table' => $instances_table,
      '#back_link' => $back_link,
      '#action_primary' => $actions['attach'],
      '#action_toolbar' => $action_toolbar,
      '#action_delete' => $actions['delete'],
      '#attached' => ['library' => ['bulk_field_config/admin']],
      '#cache' => ['max-age' => 0],
    ];
  }

  public function getTitle(string $entity_type, string $field_name): string {
    return $field_name;
  }

}
