<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Form;

use Drupal\bulk_field_config\Service\BulkFieldAttachService;
use Drupal\bulk_field_config\Service\BulkFieldQueryService;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldTypePluginManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\field\Entity\FieldStorageConfig;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

final class BulkFieldCreateForm extends FormBase {

  use FieldToolsStepperTrait;

  public function __construct(
    protected BulkFieldAttachService $attachService,
    protected BulkFieldQueryService $queryService,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected FieldTypePluginManagerInterface $fieldTypeManager,
    protected Request $request,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('bulk_field_config.bulk_field_attach'),
      $container->get('bulk_field_config.bulk_field_query'),
      $container->get('entity_type.manager'),
      $container->get('plugin.manager.field.field_type'),
      $container->get('request_stack')->getCurrentRequest(),
    );
  }

  public function getFormId(): string {
    return 'bulk_field_config_create';
  }

  public function buildForm(array $form, FormStateInterface $form_state): array {
    $step = $form_state->get('step') ?? 1;

    $form['#attributes']['class'][] = 'field-tools-wizard-form';
    $form['#attached']['library'][] = 'bulk_field_config/admin';
    $form['step_indicator'] = $this->buildStepper($step, [
      $this->t('Field type'),
      $this->t('Label & settings'),
      $this->t('Bundles'),
      $this->t('Confirm'),
    ]);

    return match ($step) {
      1 => $this->buildStep1($form, $form_state),
      2 => $this->buildStep2($form, $form_state),
      3 => $this->buildStep3($form, $form_state),
      4 => $this->buildStep4($form, $form_state),
      default => $this->buildStep1($form, $form_state),
    };
  }

  private function buildStep1(array $form, FormStateInterface $form_state): array {
    $s1 = $form_state->get('step1') ?? [];

    $form['entity_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Entity type'),
      '#options' => [
        'node' => $this->t('Content (Node)'),
        'media' => $this->t('Media'),
        'paragraph' => $this->t('Paragraph'),
        'taxonomy_term' => $this->t('Taxonomy term'),
      ],
      '#default_value' => $s1['entity_type'] ?? ($this->request->query->get('entity_type') ?? 'node'),
      '#required' => TRUE,
    ];

    $form['field_name'] = [
      '#type' => 'machine_name',
      '#title' => $this->t('Field machine name'),
      '#description' => $this->t('Will be stored with <code>field_</code> prefix. Use lowercase letters, numbers, underscores.'),
      '#default_value' => $s1['field_name'] ?? '',
      '#machine_name' => [
        'exists' => [$this, 'fieldNameExists'],
        // No 'source': there's no separate "label" field on this step to
        // auto-derive from (label is entered later, in step 2). Without a
        // source, core's machine_name element skips its JS auto-hide/preview
        // behavior and just renders a normal, always-editable text input.
        // A self-referential source (this field naming itself) was here
        // before, which made core's machine-name.js hide this exact input
        // as its own "target", leaving no way to enter a value at all.
        'replace_pattern' => '[^a-z0-9_]+',
        'replace' => '_',
      ],
      '#field_prefix' => 'field_',
      '#required' => TRUE,
    ];

    $form['field_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Field type'),
      '#options' => $this->getFieldTypeOptions(),
      '#default_value' => $s1['field_type'] ?? 'string',
      '#required' => TRUE,
    ];

    $form['actions'] = $this->buildNextActions(NULL, 'submitStep1');
    return $form;
  }

  private function buildStep2(array $form, FormStateInterface $form_state): array {
    $s1 = $form_state->get('step1');
    $s2 = $form_state->get('step2') ?? [];

    $form['info'] = ['#markup' => '<p>' . $this->t('Field type: <strong>@type</strong>', ['@type' => $s1['field_type']]) . '</p>'];

    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Field label'),
      '#default_value' => $s2['label'] ?? ucwords(str_replace('_', ' ', $s1['field_name'])),
      '#required' => TRUE,
    ];

    $form['cardinality_type'] = [
      '#type' => 'radios',
      '#title' => $this->t('Allowed values'),
      '#options' => [
        '1' => $this->t('1 (single value)'),
        '-1' => $this->t('Unlimited'),
        'custom' => $this->t('Custom number'),
      ],
      '#default_value' => $s2['cardinality_type'] ?? '1',
      '#required' => TRUE,
    ];

    $form['cardinality_number'] = [
      '#type' => 'number',
      '#title' => $this->t('Number of values'),
      '#default_value' => $s2['cardinality_number'] ?? 2,
      '#states' => [
        'visible' => [':input[name="cardinality_type"]' => ['value' => 'custom']],
      ],
    ];

    if ($s1['field_type'] === 'entity_reference') {
      $form['target_type'] = [
        '#type' => 'select',
        '#title' => $this->t('Target entity type'),
        '#options' => $this->getContentEntityTypeOptions(),
        '#default_value' => $s2['target_type'] ?? 'node',
        '#required' => TRUE,
      ];
    }

    $form['actions'] = $this->buildNextActions('submitStepBack', 'submitStep2');
    return $form;
  }

  private function buildStep3(array $form, FormStateInterface $form_state): array {
    $s1 = $form_state->get('step1');
    $s3 = $form_state->get('step3') ?? [];

    $bundles = $this->queryService->getAllBundles($s1['entity_type']);
    $field_machine_name = 'field_' . $s1['field_name'];

    // Step 1 already validates the field name is unique, so the storage does
    // not exist yet and all bundles are available to attach to.
    $available = $bundles;

    $form['bundles'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Attach to bundles'),
      '#options' => $available,
      '#default_value' => $s3['bundles'] ?? [],
    ];

    if (empty($available)) {
      $form['bundles']['#description'] = $this->t('All bundles already have a field with this name.');
    }

    $form['actions'] = $this->buildNextActions('submitStepBack', 'submitStep3');
    return $form;
  }

  private function buildStep4(array $form, FormStateInterface $form_state): array {
    $s1 = $form_state->get('step1');
    $s2 = $form_state->get('step2');
    $s3 = $form_state->get('step3');

    $field_machine_name = 'field_' . $s1['field_name'];
    $cardinality = $s2['cardinality_type'] === 'custom'
      ? (int) $s2['cardinality_number']
      : (int) $s2['cardinality_type'];

    $rows = [
      [$this->t('Entity type'), $s1['entity_type']],
      [$this->t('Field name'), $field_machine_name],
      [$this->t('Field type'), $s1['field_type']],
      [$this->t('Label'), $s2['label']],
      [$this->t('Cardinality'), $cardinality === -1 ? $this->t('Unlimited') : (string) $cardinality],
    ];

    if (!empty($s2['target_type'])) {
      $rows[] = [$this->t('Target entity type'), $s2['target_type']];
    }

    $form['summary'] = [
      '#type' => 'table',
      '#caption' => $this->t('Field storage that will be created:'),
      '#rows' => $rows,
      '#attributes' => ['class' => ['field-tools-summary']],
    ];

    $bundle_labels = [];
    foreach ($s3['bundles'] as $bundle) {
      $bundle_labels[] = $this->queryService->getBundleLabel($s1['entity_type'], $bundle) . ' (' . $bundle . ')';
    }

    $form['bundle_list'] = [
      '#theme' => 'item_list',
      '#title' => $this->t('Will be attached to:'),
      '#items' => $bundle_labels,
      '#attributes' => ['class' => ['field-tools-bundle-chips']],
    ];

    $form['actions'] = $this->buildNextActions('submitStepBack', NULL);
    $form['actions']['confirm'] = [
      '#type' => 'submit',
      '#value' => $this->t('Create field'),
    ];

    return $form;
  }

  public function submitStep1(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step1', [
      'entity_type' => $form_state->getValue('entity_type'),
      'field_name' => $form_state->getValue('field_name'),
      'field_type' => $form_state->getValue('field_type'),
    ]);
    $form_state->set('step', 2);
    $form_state->setRebuild(TRUE);
  }

  public function submitStep2(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step2', [
      'label' => $form_state->getValue('label'),
      'cardinality_type' => $form_state->getValue('cardinality_type'),
      'cardinality_number' => $form_state->getValue('cardinality_number'),
      'target_type' => $form_state->getValue('target_type'),
    ]);
    $form_state->set('step', 3);
    $form_state->setRebuild(TRUE);
  }

  public function submitStep3(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step3', [
      'bundles' => array_keys(array_filter($form_state->getValue('bundles', []))),
    ]);
    $form_state->set('step', 4);
    $form_state->setRebuild(TRUE);
  }

  public function submitStepBack(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step', max(1, ($form_state->get('step') ?? 2) - 1));
    $form_state->setRebuild(TRUE);
  }

  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $s1 = $form_state->get('step1');
    $s2 = $form_state->get('step2');
    $s3 = $form_state->get('step3');

    $field_machine_name = 'field_' . $s1['field_name'];
    $entity_type = $s1['entity_type'];
    $cardinality = $s2['cardinality_type'] === 'custom'
      ? (int) $s2['cardinality_number']
      : (int) $s2['cardinality_type'];

    try {
      $storage_def = [
        'field_name' => $field_machine_name,
        'entity_type' => $entity_type,
        'type' => $s1['field_type'],
        'cardinality' => $cardinality,
      ];
      if ($s1['field_type'] === 'entity_reference' && !empty($s2['target_type'])) {
        $storage_def['settings'] = ['target_type' => $s2['target_type']];
      }
      $field_storage = FieldStorageConfig::create($storage_def);
      $field_storage->save();
    }
    catch (\Exception $e) {
      $this->messenger()->addError($this->t('Failed to create field storage: @msg', ['@msg' => $e->getMessage()]));
      return;
    }

    $results = $this->attachService->attach(
      $entity_type,
      $field_machine_name,
      $s3['bundles'],
      ['label' => $s2['label']],
    );

    $success = count(array_filter($results, fn($r) => $r->isSuccess()));
    $errors = count(array_filter($results, fn($r) => $r->isError()));

    $this->messenger()->addStatus($this->t(
      'Created field <em>@field</em> and attached to @count bundle(s).',
      ['@field' => $field_machine_name, '@count' => $success],
    ));
    if ($errors) {
      $this->messenger()->addError($this->t('Failed to attach to @count bundle(s) — check logs.', ['@count' => $errors]));
    }

    $form_state->setRedirect('bulk_field_config.field_detail', [
      'entity_type' => $entity_type,
      'field_name' => $field_machine_name,
    ]);
  }

  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $step = $form_state->get('step') ?? 1;

    if ($step === 2 && $form_state->getValue('cardinality_type') === 'custom') {
      $n = (int) $form_state->getValue('cardinality_number');
      if ($n < 2) {
        $form_state->setErrorByName('cardinality_number', $this->t('Custom cardinality must be at least 2.'));
      }
    }

    if ($step === 3 && !array_filter($form_state->getValue('bundles', []))) {
      $form_state->setErrorByName('bundles', $this->t('Select at least one bundle.'));
    }
  }

  public function fieldNameExists(string $value, array $element, FormStateInterface $form_state): bool {
    $entity_type = $form_state->getValue('entity_type') ?? 'node';
    return FieldStorageConfig::load($entity_type . '.field_' . $value) !== NULL;
  }

  private function buildNextActions(?string $back_submit, ?string $next_submit): array {
    $actions = ['#type' => 'actions'];

    if ($next_submit) {
      $actions['next'] = [
        '#type' => 'submit',
        '#value' => $this->t('Next →'),
        '#submit' => ['::' . $next_submit],
      ];
    }

    if ($back_submit) {
      $actions['back'] = [
        '#type' => 'submit',
        '#value' => $this->t('← Back'),
        '#submit' => ['::' . $back_submit],
        '#limit_validation_errors' => [],
      ];
    }

    $actions['cancel'] = [
      '#type' => 'link',
      '#title' => $this->t('Cancel'),
      '#url' => Url::fromRoute('bulk_field_config.overview'),
      '#attributes' => ['class' => ['button', 'button--secondary']],
    ];

    return $actions;
  }

  private function getFieldTypeOptions(): array {
    $definitions = $this->fieldTypeManager->getDefinitions();
    $options = [];
    foreach ($definitions as $id => $definition) {
      $category = isset($definition['category']) ? (string) $definition['category'] : 'Other';
      $options[$category][$id] = (string) $definition['label'];
    }
    ksort($options);
    foreach ($options as &$group) {
      asort($group);
    }
    return $options;
  }

  private function getContentEntityTypeOptions(): array {
    $options = [];
    foreach ($this->entityTypeManager->getDefinitions() as $id => $definition) {
      if ($definition->getGroup() === 'content') {
        $options[$id] = (string) $definition->getLabel();
      }
    }
    asort($options);
    return $options;
  }

}
