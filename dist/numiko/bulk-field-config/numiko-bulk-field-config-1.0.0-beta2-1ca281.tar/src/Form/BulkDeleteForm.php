<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Form;

use Drupal\bulk_field_config\Service\BulkFieldDeleteService;
use Drupal\bulk_field_config\Service\BulkFieldQueryService;
use Drupal\Core\Batch\BatchBuilder;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

final class BulkDeleteForm extends FormBase {

  public function __construct(
    protected BulkFieldDeleteService $deleteService,
    protected BulkFieldQueryService $queryService,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('bulk_field_config.bulk_field_delete'),
      $container->get('bulk_field_config.bulk_field_query'),
      $container->get('current_route_match'),
    );
  }

  public function getFormId(): string {
    return 'bulk_field_config_delete';
  }

  public function buildForm(array $form, FormStateInterface $form_state): array {
    $entity_type = $this->getRouteMatch()->getParameter('entity_type');
    $field_name = $this->getRouteMatch()->getParameter('field_name');

    $detail = $this->queryService->getFieldStorageDetail($entity_type, $field_name);
    if (!$detail) {
      $form['error'] = ['#markup' => $this->t('Field not found.')];
      return $form;
    }

    $form['#attached']['library'][] = 'bulk_field_config/admin';
    $form['field_info'] = [
      '#markup' => '<p>' . $this->t('Field: <strong>@field</strong>', ['@field' => $field_name]) . '</p>',
    ];

    // Build bundle options with data-count warnings.
    $bundle_options = [];
    $data_warnings = [];
    foreach ($detail['instances'] as $bundle => $config) {
      $label = $this->queryService->getBundleLabel($entity_type, $bundle);
      $bundle_options[$bundle] = $label . ' (' . $bundle . ')';
      $count = $this->deleteService->getDataCount($entity_type, $bundle, $field_name);
      if ($count > 0) {
        $data_warnings[$bundle] = $count;
      }
    }

    if ($data_warnings) {
      $warning_items = [];
      foreach ($data_warnings as $bundle => $count) {
        $warning_items[] = $this->t('@bundle: @count content item(s) have data in this field and will lose it.', [
          '@bundle' => $bundle_options[$bundle] ?? $bundle,
          '@count' => $count,
        ]);
      }
      $form['data_warning'] = [
        '#theme' => 'item_list',
        '#title' => $this->t('⚠ Data loss warning'),
        '#items' => $warning_items,
        '#attributes' => ['class' => ['messages', 'messages--warning']],
      ];
    }

    $form['bundles'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Remove from bundles'),
      '#options' => $bundle_options,
      '#default_value' => array_keys($bundle_options),
      '#required' => TRUE,
    ];

    $form['delete_storage'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Also delete field storage if no bundles remain after this operation'),
      '#description' => $this->t('This will permanently delete the FieldStorageConfig and all associated data.'),
      '#default_value' => FALSE,
    ];

    $form['confirm_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Type the field machine name to confirm'),
      '#description' => $this->t('Type <em>@field</em> to confirm deletion.', ['@field' => $field_name]),
      '#required' => TRUE,
      '#size' => 40,
    ];

    $form['actions'] = [
      '#type' => 'actions',
      'delete' => [
        '#type' => 'submit',
        '#value' => $this->t('Delete from selected bundles'),
        '#attributes' => ['class' => ['button--danger']],
      ],
      'cancel' => [
        '#type' => 'link',
        '#title' => $this->t('Cancel'),
        '#url' => Url::fromRoute('bulk_field_config.field_detail', ['entity_type' => $entity_type, 'field_name' => $field_name]),
        '#attributes' => ['class' => ['button', 'button--secondary']],
      ],
    ];

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $field_name = $this->getRouteMatch()->getParameter('field_name');
    if (trim($form_state->getValue('confirm_name')) !== $field_name) {
      $form_state->setErrorByName('confirm_name', $this->t('Field name does not match.'));
    }
    if (!array_filter($form_state->getValue('bundles', []))) {
      $form_state->setErrorByName('bundles', $this->t('Select at least one bundle.'));
    }
  }

  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $entity_type = $this->getRouteMatch()->getParameter('entity_type');
    $field_name = $this->getRouteMatch()->getParameter('field_name');
    $bundles = array_keys(array_filter($form_state->getValue('bundles')));
    $delete_storage = (bool) $form_state->getValue('delete_storage');
    $threshold = $this->deleteService->getBatchThreshold();

    if (count($bundles) > $threshold) {
      $batch = new BatchBuilder();
      $batch->setTitle($this->t('Removing field @field…', ['@field' => $field_name]));
      $batch->setFinishedCallback([BulkFieldDeleteService::class, 'batchFinished']);
      foreach ($bundles as $bundle) {
        $batch->addOperation([BulkFieldDeleteService::class, 'batchDelete'], [$entity_type, $field_name, $bundle]);
      }
      if ($delete_storage) {
        $batch->addOperation([BulkFieldDeleteService::class, 'batchDeleteStorage'], [$entity_type, $field_name]);
      }
      batch_set($batch->toArray());
      $form_state->setRedirect('bulk_field_config.overview_type', ['entity_type' => $entity_type]);
      return;
    }

    $results = $this->deleteService->delete($entity_type, $field_name, $bundles, $delete_storage);
    $success = count(array_filter($results, fn($r) => $r->isSuccess()));
    $errors = count(array_filter($results, fn($r) => $r->isError()));

    if ($success) {
      $this->messenger()->addStatus($this->t('Removed field from @count bundle(s).', ['@count' => $success]));
    }
    if ($errors) {
      $this->messenger()->addError($this->t('Failed on @count bundle(s) — check logs.', ['@count' => $errors]));
    }

    // Redirect to detail if instances remain, otherwise to overview.
    $remaining = \Drupal::entityTypeManager()
      ->getStorage('field_config')
      ->loadByProperties(['entity_type' => $entity_type, 'field_name' => $field_name]);

    if (!empty($remaining)) {
      $form_state->setRedirect('bulk_field_config.field_detail', ['entity_type' => $entity_type, 'field_name' => $field_name]);
    }
    else {
      $form_state->setRedirect('bulk_field_config.overview_type', ['entity_type' => $entity_type]);
    }
  }

}
