<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

final class FieldSearchForm extends FormBase {

  public function getFormId(): string {
    return 'bulk_field_config_field_search';
  }

  public function buildForm(array $form, FormStateInterface $form_state, string $entity_type = 'node', string $search = ''): array {
    $form['#method'] = 'get';
    $form['#action'] = Url::fromRoute('bulk_field_config.overview_type', ['entity_type' => $entity_type])->toString();
    $form['#attributes']['class'][] = 'field-tools-search-form';

    $form['search'] = [
      '#type' => 'search',
      '#title' => $this->t('Filter fields'),
      '#title_display' => 'invisible',
      '#default_value' => $search,
      '#placeholder' => $this->t('Filter by field name...'),
      '#size' => 30,
    ];

    $form['actions'] = [
      '#type' => 'actions',
      'submit' => [
        '#type' => 'submit',
        '#value' => $this->t('Filter'),
        '#attributes' => ['class' => ['button--small']],
      ],
    ];

    if ($search !== '') {
      $form['actions']['clear'] = [
        '#type' => 'link',
        '#title' => $this->t('Clear'),
        '#url' => Url::fromRoute('bulk_field_config.overview_type', ['entity_type' => $entity_type]),
        '#attributes' => ['class' => ['button', 'button--small', 'button--secondary']],
      ];
    }

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state): void {}

}
