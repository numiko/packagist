<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Form;

use Drupal\bulk_field_config\Service\BulkFieldQueryService;
use Drupal\Component\Diff\Diff;
use Drupal\Core\Diff\DiffFormatter;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Yaml\Yaml;

final class BulkFieldEditForm extends FormBase {

  use FieldToolsStepperTrait;

  public function __construct(
    protected BulkFieldQueryService $queryService,
    protected DiffFormatter $diffFormatter,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('bulk_field_config.bulk_field_query'),
      $container->get('diff.formatter'),
    );
  }

  public function getFormId(): string {
    return 'bulk_field_config_edit';
  }

  public function buildForm(array $form, FormStateInterface $form_state): array {
    $entity_type = $this->getRouteMatch()->getParameter('entity_type');
    $field_name = $this->getRouteMatch()->getParameter('field_name');
    $step = $form_state->get('step') ?? 1;

    $form['#attributes']['class'][] = 'field-tools-wizard-form';
    $form['#attached']['library'][] = 'bulk_field_config/admin';
    $form['header'] = [
      '#markup' => '<p>' . $this->t('Field: <strong>@field</strong>', ['@field' => $field_name]) . '</p>',
    ];
    $form['step_indicator'] = $this->buildStepper($step, [
      $this->t('Edit values'),
      $this->t('Confirm'),
    ]);

    if ($step === 1) {
      return $this->buildStep1($form, $form_state, $entity_type, $field_name);
    }
    return $this->buildStep2($form, $form_state, $entity_type, $field_name);
  }

  private function buildStep1(array $form, FormStateInterface $form_state, string $entity_type, string $field_name): array {
    $detail = $this->queryService->getFieldStorageDetail($entity_type, $field_name);
    if (!$detail) {
      $form['error'] = ['#markup' => $this->t('Field not found.')];
      return $form;
    }

    $saved_values = $form_state->get('edit_values') ?? [];

    $form['bundles'] = [
      '#type' => 'table',
      '#caption' => $this->t('Edit field properties across all attached bundles:'),
      '#header' => [
        $this->t('Bundle'),
        $this->t('Label'),
        $this->t('Required'),
        $this->t('Description'),
      ],
      '#empty' => $this->t('No bundles are using this field.'),
    ];

    foreach ($detail['instances'] as $bundle => $config) {
      $bundle_label = $this->queryService->getBundleLabel($entity_type, $bundle);
      $saved = $saved_values[$bundle] ?? [];

      $form['bundles'][$bundle]['bundle'] = [
        '#markup' => '<strong>' . $bundle_label . '</strong><br><small>' . $bundle . '</small>',
      ];
      $form['bundles'][$bundle]['label'] = [
        '#type' => 'textfield',
        '#default_value' => $saved['label'] ?? $config->getLabel(),
        '#size' => 30,
        '#required' => TRUE,
      ];
      $form['bundles'][$bundle]['required'] = [
        '#type' => 'checkbox',
        '#default_value' => $saved['required'] ?? $config->isRequired(),
      ];
      $form['bundles'][$bundle]['description'] = [
        '#type' => 'textfield',
        '#default_value' => $saved['description'] ?? $config->getDescription(),
        '#size' => 40,
      ];
    }

    $form['actions'] = [
      '#type' => 'actions',
      'next' => ['#type' => 'submit', '#value' => $this->t('Preview changes'), '#submit' => ['::submitStep1']],
      'cancel' => [
        '#type' => 'link',
        '#title' => $this->t('Cancel'),
        '#url' => Url::fromRoute('bulk_field_config.field_detail', ['entity_type' => $entity_type, 'field_name' => $field_name]),
        '#attributes' => ['class' => ['button', 'button--secondary']],
      ],
    ];

    return $form;
  }

  private function buildStep2(array $form, FormStateInterface $form_state, string $entity_type, string $field_name): array {
    $edit_values = $form_state->get('edit_values');
    $detail = $this->queryService->getFieldStorageDetail($entity_type, $field_name);

    $form['diffs'] = ['#type' => 'container'];
    $any_changes = FALSE;

    foreach ($detail['instances'] as $bundle => $config) {
      $proposed = $edit_values[$bundle] ?? [];
      $config_name = "field.field.{$entity_type}.{$bundle}.{$field_name}";
      $current_data = $this->config($config_name)->getRawData();

      $new_data = $current_data;
      $new_data['label'] = $proposed['label'] ?? $current_data['label'];
      $new_data['required'] = (bool) ($proposed['required'] ?? $current_data['required']);
      $new_data['description'] = $proposed['description'] ?? $current_data['description'];

      if ($new_data === $current_data) {
        continue;
      }

      $any_changes = TRUE;
      $old_lines = explode("\n", Yaml::dump($current_data, PHP_INT_MAX, 2));
      $new_lines = explode("\n", Yaml::dump($new_data, PHP_INT_MAX, 2));
      $diff = new Diff($old_lines, $new_lines);

      $bundle_label = $this->queryService->getBundleLabel($entity_type, $bundle);
      $form['diffs'][$bundle] = [
        '#type' => 'details',
        '#title' => $bundle_label . ' (' . $bundle . ')',
        '#open' => TRUE,
        'diff_table' => [
          '#type' => 'table',
          '#rows' => $this->diffFormatter->format($diff),
          '#attributes' => ['class' => ['diff']],
        ],
      ];
    }

    if (!$any_changes) {
      $form['diffs']['no_changes'] = ['#markup' => '<p>' . $this->t('No changes detected.') . '</p>'];
    }

    $form['#attached']['library'][] = 'system/diff';

    $form['actions'] = [
      '#type' => 'actions',
      'confirm' => ['#type' => 'submit', '#value' => $this->t('Apply changes')],
      'back' => [
        '#type' => 'submit',
        '#value' => $this->t('Back'),
        '#submit' => ['::goBack'],
        '#limit_validation_errors' => [],
      ],
    ];

    return $form;
  }

  public function submitStep1(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step', 2);
    $form_state->set('edit_values', $form_state->getValue('bundles', []));
    $form_state->setRebuild(TRUE);
  }

  public function goBack(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step', 1);
    $form_state->setRebuild(TRUE);
  }

  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $entity_type = $this->getRouteMatch()->getParameter('entity_type');
    $field_name = $this->getRouteMatch()->getParameter('field_name');
    $edit_values = $form_state->get('edit_values');

    $detail = $this->queryService->getFieldStorageDetail($entity_type, $field_name);
    $updated = 0;
    $errors = 0;

    foreach ($detail['instances'] as $bundle => $config) {
      $proposed = $edit_values[$bundle] ?? NULL;
      if (!$proposed) {
        continue;
      }

      try {
        $config->set('label', $proposed['label']);
        $config->set('required', (bool) $proposed['required']);
        $config->set('description', $proposed['description']);
        $config->save();
        $updated++;
      }
      catch (\Exception $e) {
        $errors++;
        \Drupal::logger('bulk_field_config')->error(
          'Failed to edit @field on @bundle: @msg',
          ['@field' => $field_name, '@bundle' => $bundle, '@msg' => $e->getMessage()],
        );
      }
    }

    if ($updated) {
      $this->messenger()->addStatus($this->t('Updated @count bundle instance(s).', ['@count' => $updated]));
    }
    if ($errors) {
      $this->messenger()->addError($this->t('Failed on @count instance(s) — check logs.', ['@count' => $errors]));
    }

    $form_state->setRedirect('bulk_field_config.field_detail', [
      'entity_type' => $entity_type,
      'field_name' => $field_name,
    ]);
  }

}
