<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Form;

use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Builds the segmented step-progress indicator shared by the wizard forms.
 */
trait FieldToolsStepperTrait {

  /**
   * @param TranslatableMarkup[] $labels
   *   One label per step, in order.
   */
  protected function buildStepper(int $current, array $labels): array {
    $segments = [];
    foreach ($labels as $i => $label) {
      $step_num = $i + 1;
      $is_current = $step_num === $current;
      $segments[$i] = [
        '#type' => 'container',
        '#attributes' => ['class' => ['field-tools-stepper__segment', $step_num <= $current ? 'is-complete' : '']],
        'bar' => ['#type' => 'container', '#attributes' => ['class' => ['field-tools-stepper__bar']]],
        'label' => [
          '#markup' => '<span class="field-tools-stepper__seg-label' . ($is_current ? ' is-current' : '') . '">' . $label . '</span>',
        ],
      ];
    }

    return [
      '#type' => 'container',
      '#attributes' => ['class' => ['field-tools-stepper', 'field-tools-stepper--segmented']],
      'segments' => $segments,
    ];
  }

}
