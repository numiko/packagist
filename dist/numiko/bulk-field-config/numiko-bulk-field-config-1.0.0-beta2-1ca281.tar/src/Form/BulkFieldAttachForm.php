<?php

declare(strict_types=1);

namespace Drupal\bulk_field_config\Form;

use Drupal\bulk_field_config\Service\BulkFieldAttachService;
use Drupal\bulk_field_config\Service\BulkFieldQueryService;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Symfony\Component\DependencyInjection\ContainerInterface;

final class BulkFieldAttachForm extends FormBase {

  use FieldToolsStepperTrait;

  public function __construct(
    protected BulkFieldAttachService $attachService,
    protected BulkFieldQueryService $queryService,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('bulk_field_config.bulk_field_attach'),
      $container->get('bulk_field_config.bulk_field_query'),
      $container->get('current_route_match'),
    );
  }

  public function getFormId(): string {
    return 'bulk_field_config_attach';
  }

  public function buildForm(array $form, FormStateInterface $form_state): array {
    $entity_type = $this->getRouteMatch()->getParameter('entity_type');
    $field_name = $this->getRouteMatch()->getParameter('field_name');
    $step = $form_state->get('step') ?? 1;

    $form['#entity_type'] = $entity_type;
    $form['#field_name'] = $field_name;
    $form['#attributes']['class'][] = 'field-tools-wizard-form';
    $form['#attached']['library'][] = 'bulk_field_config/admin';

    $form['header'] = [
      '#markup' => '<p>' . $this->t('Field: <strong>@field</strong>', ['@field' => $field_name]) . '</p>',
    ];
    $form['step_indicator'] = $this->buildStepper($step, [
      $this->t('Target bundles'),
      $this->t('Confirm'),
    ]);

    if ($step === 1) {
      return $this->buildStep1($form, $form_state, $entity_type, $field_name);
    }
    return $this->buildStep2($form, $form_state, $entity_type, $field_name);
  }

  private function buildStep1(array $form, FormStateInterface $form_state, string $entity_type, string $field_name): array {
    $all_bundles = $this->queryService->getAllBundles($entity_type);
    $attachable = array_filter(
      $all_bundles,
      fn($id) => $this->attachService->canAttach($entity_type, $field_name, $id),
      ARRAY_FILTER_USE_KEY,
    );

    if (empty($attachable)) {
      $form['message'] = ['#markup' => '<p>' . $this->t('This field is already attached to all available bundles.') . '</p>'];
      $form['back'] = [
        '#type' => 'link',
        '#title' => $this->t('Back to field detail'),
        '#url' => Url::fromRoute('bulk_field_config.field_detail', ['entity_type' => $entity_type, 'field_name' => $field_name]),
        '#attributes' => ['class' => ['button', 'button--secondary']],
      ];
      return $form;
    }

    $form['bundles'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Attach to bundles'),
      '#options' => $attachable,
      '#required' => TRUE,
    ];

    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Field label'),
      '#description' => $this->t('Applied to all selected bundles. Leave empty to use the storage label.'),
      '#default_value' => $form_state->get('label') ?? '',
    ];

    $form['required'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Required'),
      '#default_value' => $form_state->get('required') ?? FALSE,
    ];

    $form['actions'] = [
      '#type' => 'actions',
      'next' => [
        '#type' => 'submit',
        '#value' => $this->t('Preview'),
        '#submit' => ['::submitStep1'],
      ],
      'cancel' => [
        '#type' => 'link',
        '#title' => $this->t('Cancel'),
        '#url' => Url::fromRoute('bulk_field_config.field_detail', ['entity_type' => $entity_type, 'field_name' => $field_name]),
        '#attributes' => ['class' => ['button', 'button--secondary']],
      ],
    ];

    return $form;
  }

  private function buildStep2(array $form, FormStateInterface $form_state, string $entity_type, string $field_name): array {
    $bundles = $form_state->get('bundles');
    $options = ['label' => $form_state->get('label'), 'required' => $form_state->get('required')];

    $results = $this->attachService->attach($entity_type, $field_name, $bundles, $options, TRUE);

    $rows = [];
    foreach ($results as $result) {
      $rows[] = [$result->bundle, $result->message];
    }

    $form['preview'] = [
      '#type' => 'table',
      '#caption' => $this->t('The following changes will be applied:'),
      '#header' => [$this->t('Bundle'), $this->t('Action')],
      '#rows' => $rows,
      '#attributes' => ['class' => ['field-tools-preview-table']],
    ];

    $form['actions'] = [
      '#type' => 'actions',
      'confirm' => ['#type' => 'submit', '#value' => $this->t('Confirm & attach')],
      'back' => [
        '#type' => 'submit',
        '#value' => $this->t('Back'),
        '#submit' => ['::goBack'],
        '#limit_validation_errors' => [],
      ],
    ];

    return $form;
  }

  public function submitStep1(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step', 2);
    $form_state->set('bundles', array_keys(array_filter($form_state->getValue('bundles'))));
    $form_state->set('label', $form_state->getValue('label'));
    $form_state->set('required', $form_state->getValue('required'));
    $form_state->setRebuild(TRUE);
  }

  public function goBack(array &$form, FormStateInterface $form_state): void {
    $form_state->set('step', 1);
    $form_state->setRebuild(TRUE);
  }

  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $entity_type = $this->getRouteMatch()->getParameter('entity_type');
    $field_name = $this->getRouteMatch()->getParameter('field_name');
    $bundles = $form_state->get('bundles');
    $options = ['label' => $form_state->get('label'), 'required' => $form_state->get('required')];

    $results = $this->attachService->attach($entity_type, $field_name, $bundles, $options);

    $success = count(array_filter($results, fn($r) => $r->isSuccess()));
    $skipped = count(array_filter($results, fn($r) => $r->isSkipped()));
    $errors = count(array_filter($results, fn($r) => $r->isError()));

    if ($success) {
      $this->messenger()->addStatus($this->t('Attached field to @count bundle(s).', ['@count' => $success]));
    }
    if ($skipped) {
      $this->messenger()->addWarning($this->t('Skipped @count bundle(s) — already attached.', ['@count' => $skipped]));
    }
    if ($errors) {
      $this->messenger()->addError($this->t('Failed on @count bundle(s) — check logs.', ['@count' => $errors]));
    }

    $form_state->setRedirect('bulk_field_config.field_detail', [
      'entity_type' => $entity_type,
      'field_name' => $field_name,
    ]);
  }

  public function validateForm(array &$form, FormStateInterface $form_state): void {
    if (($form_state->get('step') ?? 1) === 1 && !array_filter($form_state->getValue('bundles', []))) {
      $form_state->setErrorByName('bundles', $this->t('Select at least one bundle.'));
    }
  }

}
