<?php

namespace Drupal\domain_access_blocking\EventSubscriber;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\domain\DomainNegotiatorInterface;
use Drupal\domain_access\DomainAccessManagerInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\HttpKernelInterface;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Denies access to CMS users if they are not assigned to the current domain.
 *
 * This stops strange caching problems where the only context is that a user
 * has domain permissions (not something we can easily add to cache contexts).
 */
class DomainLoginSubscriber implements EventSubscriberInterface {

  /**
   * @var AccountProxyInterface
   */
  private $currentUser;

  /**
   * @var \Drupal\domain_access\DomainAccessManagerInterface
   */
  private $domainAccessManager;

  /**
   * @var \Drupal\domain\DomainNegotiatorInterface
   */
  private $domainNegotiator;

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  private $entityTypeManager;

  /**
   * @param AccountProxyInterface $currentUser
   * @param DomainAccessManagerInterface $domainAccessManager
   * @param DomainNegotiatorInterface $domainNegotiator
   */
  public function __construct(
    AccountProxyInterface $currentUser,
    EntityTypeManagerInterface $entityTypeManager,
    DomainAccessManagerInterface $domainAccessManager,
    DomainNegotiatorInterface $domainNegotiator
  ) {
    $this->currentUser = $currentUser;
    $this->entityTypeManager = $entityTypeManager;
    $this->domainAccessManager = $domainAccessManager;
    $this->domainNegotiator = $domainNegotiator;
  }

  /**
   * This runs on every request, so I've tried to keep as light as possible.
   */
  public function checkDomain(GetResponseEvent $event) {
    if (!$event->isMasterRequest()) {
      // This stops an infinite loop after we throw the exception later.
      return;
    }

    if ($this->currentUser->id() == 1 || !$this->currentUser->isAuthenticated()) {
      return;
    }

    if ($event->getRequest()->getPathInfo() == '/user/logout') {
      return;
    }

    // Check that the user can access the current domain
    $user = $this->entityTypeManager
      ->getStorage('user')
      ->load($this->currentUser->id());

    $allowedDomains = $this->domainAccessManager->getAccessValues($user);
    $domainId = $this->domainNegotiator->getActiveDomain()->id();

    if (!isset($allowedDomains[$domainId])) {
      throw new AccessDeniedHttpException('You have no access to the current domain. Please login to the correct site domain.');
    }
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents() {
    $events[KernelEvents::REQUEST][] = 'checkDomain';
    return $events;
  }
}