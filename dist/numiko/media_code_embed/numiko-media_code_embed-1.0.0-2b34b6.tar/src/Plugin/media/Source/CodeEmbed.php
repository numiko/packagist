<?php

namespace Drupal\media_code_embed\Plugin\media\Source;

use Drupal\media\MediaInterface;
use Drupal\media\MediaSourceBase;
use Drupal\media\MediaTypeInterface;

/**
 * Observable media source.
 *
 * @MediaSource(
 *   id = "code_embed",
 *   label = @Translation("Code embed"),
 *   description = @Translation("Third party code embed."),
 *   allowed_field_types = {
 *     "text_long"
 *   },
 *   default_thumbnail_filename = "code.svg"
 * )
 */
class CodeEmbed extends MediaSourceBase {

  /**
   * {@inheritdoc}
   */
  public function getMetadataAttributes() {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function getMetadata(MediaInterface $media, $name) {
    switch ($name) {
      case 'embed_code':
        return $media->get('field_embed_code')->value;

      case 'thumbnail_uri':
        $default_thumbnail_filename = $this->pluginDefinition['default_thumbnail_filename'];
        return $this->configFactory->get('media.settings')->get('icon_base_uri') . '/' . $default_thumbnail_filename;
    }

    return NULL;
  }

  /**
   * {@inheritdoc}
   */
  public function createSourceField(MediaTypeInterface $type) {
    $plugin_definition = $this->getPluginDefinition();

    $label = (string) $this->t('@type embed', [
      '@type' => $plugin_definition['label'],
    ]);
    return parent::createSourceField($type)->set('label', $label);
  }

}
