<?php

namespace Drupal\media_code_embed\Plugin\media\Source;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\media\Attribute\MediaSource;
use Drupal\media\MediaInterface;
use Drupal\media\MediaSourceBase;
use Drupal\media\MediaTypeInterface;
use Drupal\media_code_embed\Form\CodeEmbedAddForm;

/**
 * Observable media source.
 */
#[MediaSource(
  id: 'code_embed',
  label: new TranslatableMarkup('Code Embed'),
  description: new TranslatableMarkup('Third party code embed.'),
  allowed_field_types: ['text_long'],
  default_thumbnail_filename: 'code.svg',
  forms: ['media_library_add' => CodeEmbedAddForm::class]
)]
class CodeEmbed extends MediaSourceBase {

  /**
   * {@inheritdoc}
   */
  public function getMetadataAttributes() {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function getMetadata(MediaInterface $media, $name) {
    return match ($name) {
      'default_name' => $media->get('name')->value ?? 'Code Embed',
      'embed_code' => $media->get('field_embed_code')->value,
      'thumbnail_uri' => $this->configFactory->get('media.settings')->get('icon_base_uri') . '/' . $this->pluginDefinition['default_thumbnail_filename'],
      default => NULL,
    };
  }

  /**
   * {@inheritdoc}
   */
  public function createSourceField(MediaTypeInterface $type) {
    $plugin_definition = $this->getPluginDefinition();

    $label = (string) $this->t('@type embed', [
      '@type' => $plugin_definition['label'],
    ]);
    return parent::createSourceField($type)->set('label', $label);
  }

}
