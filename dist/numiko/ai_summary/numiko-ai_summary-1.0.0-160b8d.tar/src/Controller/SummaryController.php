<?php

namespace Drupal\ai_summary\Controller;

use Drupal\ai\AiProviderPluginManager;
use Drupal\Core\Controller\ControllerBase;
use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

class SummaryController extends ControllerBase {

  /**
   * The provider manager.
   *
   * @var \Drupal\ai\AiProviderPluginManager
   */
  protected $aiProviderManager;

  public function __construct(AiProviderPluginManager $aiProviderManager) {
    $this->aiProviderManager = $aiProviderManager;
  }

  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('ai.provider')
    );
  }

  public function getSummary(ConfigEntityInterface $prompt) {
    $content = \Drupal::request()->request->get('content');

    $sets = $this->aiProviderManager->getDefaultProviderForOperationType('chat');
    $provider = $this->aiProviderManager->createInstance($sets['provider_id']);

    $messages = new ChatInput([
      new ChatMessage('system', $prompt->prompt),
      new ChatMessage('user', $content),
    ]);
    $model = $prompt->model ?? $sets['model_id'];
    try{
      $message = $provider->chat($messages, $model)->getNormalized();
      $response = $message->getText();

      if (!$response) {
        throw new \Exception("No response received");
      }

      return new JsonResponse([
        'status' => 'success',
        'summary' => $response,
      ]);
    }
    catch (\Exception $e) {
      return new JsonResponse([
        'status' => 'error',
        'message' => $e->getMessage()
      ], 500);
    }
  }
}
