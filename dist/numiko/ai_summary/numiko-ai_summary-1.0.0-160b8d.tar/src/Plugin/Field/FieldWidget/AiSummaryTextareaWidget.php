<?php

namespace Drupal\ai_summary\Plugin\Field\FieldWidget;

use Drupal\Core\Render\Markup;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Field\Attribute\FieldWidget;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\text\Plugin\Field\FieldWidget\TextareaWidget;
use Symfony\Component\Validator\ConstraintViolationInterface;

/**
 * Plugin implementation of the 'text_textarea' widget.
 */
#[FieldWidget(
  id: 'text_ai_summary',
  label: new TranslatableMarkup('Text area (with AI Summary)'),
  field_types: ['text_long'],
)]
class AiSummaryTextareaWidget extends TextareaWidget {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return [
      'prompt' => '',
    ] + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $element = parent::settingsForm($form, $form_state);

    $element['rows']['#description'] = $this->t('Text editors may override this setting.');

    $entities = \Drupal::entityTypeManager()->getStorage('ai_prompt')->loadByProperties(['status' => TRUE]);
    $options = [];
    foreach ($entities as $entity) {
      $options[$entity->id()] = $entity->label();
    }

    $element['prompt'] = [
      '#type' => 'select',
      '#required' => TRUE,
      '#title' => $this->t('Select the prompt'),
      '#default_value' => $this->getSetting('prompt'),
      '#options' => $options,
    ];
    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = parent::settingsSummary();

    $prompt = $this->getSetting('prompt');
    if (!empty($prompt)) {
      $entity = \Drupal::entityTypeManager()->getStorage('ai_prompt')->load($prompt);
      $summary[] = $this->t('Prompt: @prompt', ['@prompt' => $entity->label()]);
    }

    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    $element = parent::formElement($items, $delta, $element, $form, $form_state);

    $element['#attributes']['class'][] = 'ai-summary-field';

    if ($this->getSetting('prompt')) {
      $element['#suffix'] = Markup::create("<button type='button' data-prompt='{$this->getSetting('prompt')}' class='button button--secondary ai-summarise'>Generate Summary</button>");
    }

    $element['#attached']['library'][] = 'ai_summary/ai_summary';

    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function errorElement(array $element, ConstraintViolationInterface $violation, array $form, FormStateInterface $form_state) {
    if (isset($element['format']['#access']) && !$element['format']['#access'] && preg_match('/^[0-9]*\.format$/', $violation->getPropertyPath())) {
      // Ignore validation errors for formats if formats may not be changed,
      // such as when existing formats become invalid.
      // See \Drupal\filter\Element\TextFormat::processFormat().
      return FALSE;
    }
    return $element;
  }

}
