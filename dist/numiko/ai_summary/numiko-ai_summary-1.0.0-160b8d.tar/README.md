# AI Summary

Add a summarise button to any text format field, this will collect all of the content on the page and send for a summary using a prompt stored in config.

## Usage

1. Install the AI module, and configure a chat provider and the key module.
2. Setup an AI prompt (Structure >> AI Prompt).
3. Change the field widget to use the field widget with AI summary (this will the allow selection of a prompt).
4. On the node edit form the field will now show a "Generate Summary" button.
