
(function ($, Drupal) {
  Drupal.behaviors.aiSummary = {
    attach: function (context, settings) {
      $('.ai-summarise').on('click', function(e) {
        e.preventDefault();
        const $button = $(e.currentTarget);
        const buttonText = $button.html();
        const currentEditorKey = String($button.parent('.js-form-wrapper').find('.form-element').data('ckeditor5Id'));
        const prompt = $button.data('prompt');
        if (!prompt) {
          return;
        }

        const throbber = Drupal.theme(
          'ajaxProgressThrobber',
          buttonText,
        );
        $button.prop('disabled', true);
        $button.html(throbber);

        let combinedContent = '';
        $('.js-text-full').each(function () {
          let editorId = String($(this).data('ckeditor5Id'));
          if (editorId == currentEditorKey) {
            return true;
          }
          if (editorId && Drupal.CKEditor5Instances.get(editorId) && Drupal.CKEditor5Instances.get(editorId).getData) {
            combinedContent += $(Drupal.CKEditor5Instances.get(editorId).getData()).text() + ' ';
          }
          else {
            combinedContent += $(this).val() + ' ';
          }
        });
        if (!combinedContent) {
          return;
        }

        $.ajax({
          url: '/ai-summary/generate/' + prompt,
          method: 'POST',
          data: {
            content: combinedContent.trim()
          },
          success: function(response) {
            if (response.summary) {
              Drupal.CKEditor5Instances.get(currentEditorKey).setData(response.summary);
              $button.prop('disabled', false);
              $button.html(buttonText);
            }
          },
          error: function(xhr, status, error) {
            console.error('Error generating summary:', error);
            $button.prop('disabled', false);
            $button.html(buttonText);
          }
        });
      });
    }
  };
})(jQuery, Drupal);
