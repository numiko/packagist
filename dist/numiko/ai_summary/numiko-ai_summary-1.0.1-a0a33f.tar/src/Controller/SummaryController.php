<?php

namespace Drupal\ai_summary\Controller;

use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\ai\AiProviderPluginManager;
use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

class SummaryController extends ControllerBase {

  public function __construct(
    #[Autowire(service: 'ai.provider')]
    protected readonly AiProviderPluginManager $aiProviderManager,
  ) {}

  public function getSummary(Request $request, ConfigEntityInterface $prompt) {
    $content = $request->get('content');

    $sets = $this->aiProviderManager->getDefaultProviderForOperationType('chat');
    $provider = $this->aiProviderManager->createInstance($sets['provider_id']);
    $provider->setConfiguration($provider->getConfiguration() + ['max_tokens' => 4096]);

    $messages = new ChatInput([
      new ChatMessage('system', $prompt->prompt),
      new ChatMessage('user', $content),
    ]);

    // If the prompt does not contain a model; fallback to the default model.
    if (!$prompt->model || $prompt->model === '') {
      $model = $sets['model_id'];
    }
    else {
      $model = $prompt->model;
    }

    try {
      $message = $provider->chat($messages, $model)->getNormalized();
      $response = $message->getText();

      if (!$response) {
        throw new \Exception("No response received");
      }

      return new JsonResponse([
        'status' => 'success',
        'summary' => $response,
      ]);
    }
    catch (\Exception $e) {
      return new JsonResponse([
        'status' => 'error',
        'message' => $e->getMessage(),
      ], 500);
    }
  }

}
