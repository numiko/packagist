<?php

declare(strict_types=1);

namespace Drupal\openid_connect_form_amends;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\openid_connect_form_amends\Form\SettingsForm;

/**
 * Class LoginFormAmends
 *
 * This class is responsible for making amends to the login form.
 */
class LoginFormAmends {

  /**
   * Constructor method for the class.
   *
   * @param ConfigFactoryInterface $configFactory
   *    The entity type manager.
   */
  public function __construct(protected ConfigFactoryInterface $configFactory, protected AccountProxyInterface $accountProxy, protected EntityTypeManagerInterface $entityTypeManager) {}

  /**
   * Validates if a user has the permission to log in using Drupal login.
   *
   * Sets an error on the form_state if the user does not have the required
   * permission.
   *
   * @param array $form
   *    The form being used.
   * @param FormStateInterface $form_state
   *    The current state of the form.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function validateHasDrupalLoginPermission(&$form, &$form_state): void {
    $accountUsername = $form_state->getValue('name');
    $account = $this->entityTypeManager->getStorage('user')->loadByProperties(['name' => $accountUsername]);
    if (empty($account)) {
      return;
    }
    $account = reset($account);
    if (!$account->hasPermission('login using drupal login')) {
      $config = $this->configFactory->get(SettingsForm::CONFIG_NAME);
      $loginLabel = $config->get('drupal_login_details_wrapper_label') ?? 'Drupal login';
      $form_state->setErrorByName('name', "You do not have permission to login using the $loginLabel.");
    }
  }

  /**
   * Amend the Drupal login form based on configuration settings.
   *
   * @param array &$form
   *    The Drupal login form array, passed by reference.
   */
  public function amendDrupalLoginForm(&$form): void {
    $config = $this->configFactory->get(SettingsForm::CONFIG_NAME);

    if ($config->get('restrict_drupal_login')) {
      $form['#validate'][] = [$this, 'validateHasDrupalLoginPermission'];
    }

    if ($config->get('drupal_login_details_wrapper')) {
      $form['login'] = [
        '#type' => 'details',
        '#title' => $config->get('drupal_login_details_wrapper_label') ?? 'Drupal login',
        '#collapsed' => TRUE,
      ];
      $form['login']['name'] = $form['name'];
      $form['login']['pass'] = $form['pass'];
      $form['login']['actions'] = $form['actions'];

      unset($form['name']);
      unset($form['pass']);
      unset($form['actions']);
    }
  }

  /**
   * Amends the OpenID Connect login form with custom labels.
   *
   * @param array $form
   *    The OpenID Connect login form array that will be modified.
   */
  public function amendOpenIdConnectLoginForm(&$form): void {
    $config = $this->configFactory->get(SettingsForm::CONFIG_NAME);
    if (!isset($form['openid_connect_client_sso_login'])) {
      return;
    }
    if ($ssoLabel = $config->get('login_with_sso_label')) {
      $form['openid_connect_client_sso_login']['#value'] = $ssoLabel;
    }
    if ($ssoHelpText = $config->get('login_with_sso_help_text')) {
      $form['sso_help_text'] = [
        '#type' => 'markup',
        '#markup' => "<p>$ssoHelpText</p>",
        '#weight' => '-50',
      ];
    }
  }

}
