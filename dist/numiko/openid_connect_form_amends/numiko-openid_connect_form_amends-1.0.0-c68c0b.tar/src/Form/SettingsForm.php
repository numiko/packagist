<?php

declare(strict_types=1);

namespace Drupal\openid_connect_form_amends\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class SettingsForm
 *
 * Provides a form to edit and save the module's settings.
 */
class SettingsForm extends ConfigFormBase {

  /**
   * Configuration name for OpenID Connect login form adjustments.
   */
  public const CONFIG_NAME = 'openid_connect_form_amends.settings';

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'openid_connect_form_amends_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [self::CONFIG_NAME];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config(self::CONFIG_NAME);
    $form['login_with_sso_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('\'Login with SSO\' button label'),
      '#default_value' => $config->get('login_with_sso_label'),
      '#description' => $this->t('Label for the Single Sign-On login button.'),
    ];

    $form['login_with_sso_help_text'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Help text for the SSO login'),
      '#default_value' => $config->get('login_with_sso_help_text'),
      '#description' => $this->t('Help text displayed for Single Sign-On login.'),
    ];

    $form['drupal_login_details_wrapper'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Hide the standard Drupal login in a details tab'),
      '#default_value' => $config->get('drupal_login_details_wrapper'),
    ];

    $form['drupal_login_details_wrapper_label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Drupal login details tab label'),
      '#default_value' => $config->get('drupal_login_details_wrapper_label'),
      '#description' => $this->t('Label for the details tab for standard Drupal login.'),
    ];

    $form['restrict_drupal_login'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Prevent access to the Drupal login for those without the \'login using drupal login\' permission'),
      '#default_value' => $config->get('restrict_drupal_login'),
    ];
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->configFactory->getEditable(self::CONFIG_NAME)
      ->set('login_with_sso_label', $form_state->getValue('login_with_sso_label'))
      ->set('login_with_sso_help_text', $form_state->getValue('login_with_sso_help_text'))
      ->set('drupal_login_details_wrapper', $form_state->getValue('drupal_login_details_wrapper'))
      ->set('drupal_login_details_wrapper_label', $form_state->getValue('drupal_login_details_wrapper_label'))
      ->set('restrict_drupal_login', $form_state->getValue('restrict_drupal_login'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}