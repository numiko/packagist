<?php

namespace Drupal\Tests\openid_connect_form_amends\Functional;

use Drupal\integration_tests\IntegrationTestBase;

/**
 * Tests for LoginFormAmendsTest class.
 *
 * @group openid_connect_form_amends
 */
class LoginFormAmendsTest extends IntegrationTestBase {

  /**
   * Test amending the wrapper and title of the Drupal login.
   */
  public function testDrupalLoginAmend() {
    // Set configuration for testing.
   \Drupal::configFactory()->getEditable('openid_connect_form_amends.settings')
      ->set('drupal_login_details_wrapper', TRUE)
      ->set('drupal_login_details_wrapper_label', 'Custom Drupal Login')
      ->save();

    // Visit the login page.
    $this->drupalGet('user/login');

    // Assert the custom wrapper and title is present.
    $this->assertSession()->elementExists('css', 'details#edit-login');
    $this->assertSession()->elementTextContains('css', 'details#edit-login', 'Custom Drupal Login');
  }


  /**
   * Test amending the label and help text of the SSO login.
   */
  public function testSsoLoginAmend() {
    // Set configuration for testing.
    \Drupal::configFactory()->getEditable('openid_connect_form_amends.settings')
      ->set('login_with_sso_label', 'Custom SSO Label')
      ->set('login_with_sso_help_text', 'Please use your SSO credentials to login.')
      ->save();

    // Visit the login page.
    $this->drupalGet('user/login');

    // Assert the custom label is present.
    $this->assertSession()
      ->elementAttributeContains('css', '#edit-openid-connect-client-sso-login', 'value', 'Custom SSO Label');

    // Assert the custom help text is present.
    $this->assertSession()
      ->pageTextContains('Please use your SSO credentials to login.');
  }

  /**
   * Test that users without permission cannot login using Drupal login.
   */
  public function testUserWithoutPermissionCannotLoginUsingDrupalLogin() {
    // Set configuration for testing.
    \Drupal::configFactory()->getEditable('openid_connect_form_amends.settings')
      ->set('restrict_drupal_login', TRUE)
      ->set('drupal_login_details_wrapper_label', 'Drupal Login')
      ->save();
   
    // Create the 'empty_role' role with no permissions.
    $this->createRole([], 'empty_role');

    // Create a user with the 'drupal_login' role and attempt login.
    $this->createUserWithRoleAndLogin('empty_role');

    // Assert that the user is not logged in.
    $this->assertSession()
      ->pageTextContains('You do not have permission to login using the Drupal login.');
  }

  /**
   * Test that users with permission can login using Drupal login.
   */
  public function testUserWithPermissionCanLoginUsingDrupalLogin() {
    // Set configuration for testing.
    \Drupal::configFactory()->getEditable('openid_connect_form_amends.settings')
      ->set('drupal_login_details_wrapper_label', 'Drupal Login')
      ->save();

    // Create the 'drupal_login' role with the permission 'login using drupal login'.
    $this->createRole(['login using drupal login'], 'drupal_login');
    // Create a user with the 'drupal_login' role and attempt login.
    $this->createUserWithRoleAndLogin('drupal_login');

    // Assert that the user is not logged in.
    $this->assertSession()
      ->pageTextNotContains('You do not have permission to login using the Drupal login.');
  }

}