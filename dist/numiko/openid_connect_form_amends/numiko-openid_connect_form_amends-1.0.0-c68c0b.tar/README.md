# OpenID Connect Form Amends
This module provides customisation options for the Drupal login and the OpenID Connection forms.

The OpenID Connection login form will only be altered if the SSO client has the machine name `sso`.

Options can be configured at `/admin/config/people/openid-connect-form-amends/settings`.

This module was based on the UOL `login_form_amends` module, which solves some of the same problems.

See: https://bitbucket.org/numiko/university-of-london/src/dae6713a47becaecf52ea3b28694b4be1a749cb3/docroot/modules/custom/login_form_amends/?at=feature%2Fpeople-roles-responsibility