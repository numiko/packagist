# Accordion Slice Recipe

This recipe installs accordion config.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-accordion-recipe
