<?php

namespace Drupal\Tests\responsive_image_class\Unit;

use Drupal\Tests\UnitTestCase;
use Drupal\responsive_image_class\ClassFormatter;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

/**
 * Unit tests to ensure ResponsiveImageClassFormatter formats classes correctly.
 */
#[Group('responsive_image_class')]
#[Group('image_formatter')]
#[CoversClass(ClassFormatter::class)]
class ResponsiveImageClassFormatterTest extends UnitTestCase {

  /**
   * The class instance being tested.
   */
  protected ClassFormatter $classFormatter;

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();
    $this->classFormatter = new ClassFormatter();
  }

  /**
   * Tests the classStringToArray method.
   */
  public function testClassStringToArray(): void {
    $inputElement = ['#item_attributes' => ['class' => ['existing-class']]];
    $inputClasses = 'new-class test-class';

    $expectedOutput = ['existing-class', 'new-class', 'test-class'];
    $actualOutput = $this->classFormatter->classStringToArray($inputElement, $inputClasses);
    $this->assertEquals(
      $expectedOutput,
      $actualOutput,
      'Unexpected result when adding a single class to an image element with no classes.',
    );

    $inputElement = [];

    $expectedOutput = ['new-class', 'test-class'];
    $actualOutput = $this->classFormatter->classStringToArray($inputElement, $inputClasses);
    $this->assertEquals(
      $expectedOutput,
      $actualOutput,
      'Unexpected result when adding a single class to an image element with no classes.',
    );
  }

}
