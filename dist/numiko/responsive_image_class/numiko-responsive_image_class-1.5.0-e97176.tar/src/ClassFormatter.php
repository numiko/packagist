<?php

namespace Drupal\responsive_image_class;

/**
 * Class Formatter helper to convert class strings to array.
 *
 * @package Drupal\responsive_image_class
 */
class ClassFormatter {

  /**
   * Converts the class string to an array.
   *
   * @param array $element
   *   The image element.
   * @param string $imageClassSettings
   *   The image class settings.
   *
   * @return array
   *   Array of classes.
   */
  public function classStringToArray(array $element, string $imageClassSettings) {
    // Handle multiple classes separated by a space.
    $classes = explode(' ', $imageClassSettings);
    // Remove any empty array values, then reset their index.
    $classes = array_values(array_filter($classes));
    if (isset($element['#item_attributes']['class'])) {
      return array_merge($element['#item_attributes']['class'], $classes);
    }
    return $classes;
  }

}
