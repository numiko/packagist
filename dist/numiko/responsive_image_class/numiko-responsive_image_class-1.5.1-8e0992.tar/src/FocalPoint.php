<?php

namespace Drupal\responsive_image_class;

use Drupal\file\Entity\File;
use Drupal\focal_point\FocalPointManager;

/**
 * Calculate the focal point for a given image by uri.
 */
class FocalPoint {

  /**
   * The default focal position.
   */
  const DEFAULT_POSITION = 'center center';

  /**
   * The Focal Point Manager.
   *
   * @var \Drupal\focal_point\FocalPointManager
   */
  protected $focalPointManager;

  /**
   * Set meta tag manager.
   *
   * @param \Drupal\focal_point\FocalPointManager $focalPointManager
   *   Focal point manager.
   */
  public function setFocalPointManager(FocalPointManager $focalPointManager) {
    $this->focalPointManager = $focalPointManager;
  }

  /**
   * Get the focal position for a given file entity.
   *
   * @param \Drupal\file\Entity\File $file
   *   The file entity.
   * @param int $width
   *   The width of the image.
   * @param int $height
   *   The height of the image.
   *
   * @return string
   *   The focal position in the format "Y X".
   */
  public function getFocalPosition(File $file, int $width, int $height) {
    if ($this->focalPointManager) {
      /** @var \Drupal\crop\Entity\Crop $crop */
      $crop = $this->focalPointManager->getCropEntity($file, 'focal_point');
      if ($crop) {
        $xPosition = 'center';
        $yPosition = 'center';
        if ($crop->get('x')->value !== NULL) {
          // Get the X position.
          $xPercentage = ($width - $crop->get('x')->value) / $width * 100;
          if ($xPercentage <= 33) {
            $xPosition = 'right';
          }
          elseif ($xPercentage >= 66) {
            $xPosition = 'left';
          }
        }
        if ($crop->get('y')->value !== NULL) {
          // Get the Y position.
          $yPercentage = ($height - $crop->get('y')->value) / $height * 100;
          if ($yPercentage <= 33) {
            $yPosition = 'bottom';
          }
          elseif ($yPercentage >= 66) {
            $yPosition = 'top';
          }
        }
        return $yPosition . ' ' . $xPosition;
      }
    }
    return self::DEFAULT_POSITION;
  }

}
