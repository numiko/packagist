<?php

namespace Drupal\Tests\responsive_image_class\Unit;

use Drupal\responsive_image_class\ClassFormatter;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests to ensure ResponsiveImageClassFormatter formats classes correctly.
 *
 * @group responsive_image_class
 * @group image_formatter
 */
class ResponsiveImageClassFormatterTest extends UnitTestCase {

  /**
   * The class instance being tested.
   *
   * @var \Drupal\responsive_image_class\ClassFormatter
   */
  protected $classFormatter;

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();
    $this->classFormatter = new ClassFormatter();
  }

  /**
   * Tests the classStringToArray method.
   *
   * @covers ::classStringToArray
   */
  public function testClassStringToArray() {
    $inputElement = ['#item_attributes' => ['class' => ['existing-class']]];
    $inputClasses = 'new-class test-class';

    $expectedOutput = ['existing-class', 'new-class', 'test-class'];
    $actualOutput = $this->classFormatter->classStringToArray($inputElement, $inputClasses);
    $this->assertEquals(
      $expectedOutput,
      $actualOutput,
      'Unexpected result when adding a single class to an image element with no classes.',
    );

    $inputElement = [];

    $expectedOutput = ['new-class', 'test-class'];
    $actualOutput = $this->classFormatter->classStringToArray($inputElement, $inputClasses);
    $this->assertEquals(
      $expectedOutput,
      $actualOutput,
      'Unexpected result when adding a single class to an image element with no classes.',
    );
  }

}
