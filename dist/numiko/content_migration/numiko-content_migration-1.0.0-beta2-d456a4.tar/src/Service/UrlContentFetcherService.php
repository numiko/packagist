<?php

namespace Drupal\content_migration\Service;

use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use fivefilters\Readability\Readability;
use fivefilters\Readability\Configuration;
use fivefilters\Readability\ParseException;

/**
 * Service for fetching content from URLs.
 */
class UrlContentFetcherService {

  /**
   * The HTTP client.
   *
   * @var \GuzzleHttp\ClientInterface
   */
  protected $httpClient;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * Constructs a UrlContentFetcherService object.
   *
   * @param \GuzzleHttp\ClientInterface $http_client
   *   The HTTP client.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   */
  public function __construct(
    ClientInterface $http_client,
    LoggerChannelFactoryInterface $logger_factory,
  ) {
    $this->httpClient = $http_client;
    $this->loggerFactory = $logger_factory;
  }

  /**
   * Fetches content from a URL.
   *
   * @param string $url
   *   The URL to fetch content from.
   *
   * @return string
   *   The HTML content from the URL.
   *
   * @throws \Exception
   *   Throws an exception if the content cannot be fetched.
   */
  public function fetchContent($url) {
    try {
      $response = $this->httpClient->request('GET', $url, [
        'headers' => [
          'User-Agent' => 'Mozilla/5.0 (compatible; Drupal/10.0; +http://drupal.org/)',
        ],
        'timeout' => 30,
      ]);

      $content_type = $response->getHeaderLine('Content-Type');
      if (strpos($content_type, 'text/html') === FALSE && strpos($content_type, 'application/xhtml+xml') === FALSE) {
        throw new \Exception("URL does not return HTML content: {$content_type}");
      }

      $body = (string) $response->getBody();
      if (empty($body)) {
        throw new \Exception('Empty response received from URL.');
      }

      return $body;
    }
    catch (RequestException $e) {
      $this->loggerFactory->get('content_migration')->error(
        'Error fetching URL @url: @error',
        ['@url' => $url, '@error' => $e->getMessage()]
      );
      throw new \Exception("Failed to fetch content from URL: " . $e->getMessage());
    }
  }

  /**
   * Sanitizes and extracts the main content from HTML.
   *
   * @param string $html
   *   The raw HTML content.
   *
   * @return array
   *   The sanitized HTML content with unnecessary parts removed & the title.
   */
  public function sanitizeHtml($html) : array {
    $readability = new Readability(new Configuration([
      'StripUnlikelyCandidates' => FALSE,
      'KeepClasses' => TRUE,
    ]));

    try {
        $readability->parse($html);
    } catch (ParseException $e) {
        throw new \Exception(sprintf('Error processing text: %s', $e->getMessage()));
    }

    return [
      'title' => $readability->getTitle(),
      'content' => $readability->getContent(),
    ];
  }

}
