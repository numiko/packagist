# Content Migration

A Drupal module that automatically imports content from URLs using AI-powered content extraction via the Claude API.

## Features

- **AI-Powered Content Extraction**: Uses Anthropic's Claude API to intelligently extract title and body content from web pages
- **Batch Processing**: Import multiple URLs at once with batch processing
- **Flexible Field Mapping**: Map extracted content to any text fields on your content types
- **Content Rewriting**: Automatically rewrite imported content and track changes
- **Menu Integration**: Automatically add imported content to your site's main menu
- **URL Redirects**: Create redirects from original URLs to new nodes (requires Redirect module)
- **Configurable Prompts**: Customize the AI extraction prompt to fit your needs
- **Multiple Claude Models**: Choose from different Claude models based on your quality/cost requirements

## Requirements

- Drupal 9.x or 10.x
- Claude API key from [Anthropic Console](https://console.anthropic.com/)
- PHP 8.1+
- Guzzle HTTP client (included with Drupal)

### Optional Dependencies
- **Redirect module**: For creating URL redirects from imported content
- **Menu Link Content**: For menu integration (core module)

## Installation

1. Download and enable the module:
   ```bash
   drush en content_migration
   ```

2. Configure your Claude API settings:
   - Navigate to `/admin/config/content/url-import`
   - Enter your Claude API key
   - Select your preferred Claude model
   - Optionally customize the extraction prompt

## Configuration

### API Settings

Configure the module at `/admin/config/content/url-import`:

- **Claude API Key**: Required. Get one from [Anthropic Console](https://console.anthropic.com/)
- **Claude Model**: Choose between:
  - Claude 3 Haiku (Faster, lower cost)
  - Claude 3 Sonnet (Balanced)
  - Claude 3 Opus (Highest quality)
- **Extraction Prompt**: Customize how Claude extracts content from web pages

### Permissions

Grant the following permissions to appropriate roles:
- `import content from url`: Access to the import form
- `administer site configuration`: Access to module settings

## Usage

### Import Content

1. Navigate to `/admin/content/url-import`
2. Enter one or more URLs (one per line)
3. Select a content type to create
4. Map the extracted content to your fields:
   - **Body Content Field**: Where the original extracted content is saved
   - **Rewritten Content Field**: Where AI-rewritten content is saved
   - **Rewrite Changes Field**: Summary of changes made during rewriting
5. Optionally:
   - Generate teaser summaries
   - Add to main menu under a parent item
   - Create URL redirects
6. Click "Import Content"

### Content Extraction Process

The module follows this process for each URL:

1. **Fetch**: Downloads the HTML content from the URL
2. **Sanitize**: Removes scripts, styles, and attempts to identify main content
3. **Extract**: Sends sanitized HTML to Claude API for intelligent content extraction
4. **Process**: Creates a new node with the extracted content
5. **Enhance**: Optionally adds menu links and URL redirects

## Field Mapping

The module extracts the following content types:

- **Title**: Page title (preferring H1 over HTML title tag)
- **Body**: Main article content (navigation, headers, footers removed)
- **Rewrite**: AI-rewritten version of the body content
- **Rewrite Changes**: Summary of changes made during rewriting
- **Summary**: Optional teaser summary (saved to `field_teaser_summary`)

## API Integration

### Claude API

The module uses Anthropic's Claude API for content extraction. The default prompt instructs Claude to:

- Extract the main page title
- Identify and extract the primary content area
- Ignore navigation, headers, footers, sidebars
- Return structured JSON with title and body fields

You can customize this prompt in the module settings to better suit your content needs.

#### Sample Custom Prompt

```
    I'll provide you with HTML content from a webpage. Please extract the following information:

    1. The page title - use the main heading (usually an h1) rather than the HTML title tag if they differ
    2. The main body content - extract the main article text, ignoring navigation, headers, footers, sidebars, comments, etc. Look for elements such as 'article', 'main', 'div[id="content"]', 'div[class*="content"]', 'div[id="main"]', 'div[class*="main"]', 'div[id="main-content"]', 'div[class*="main-content"]', 'section[id="content"]', 'section[class*="content"]', 'section[id="main"]', 'section[class*="main"]', 'section[id="main-content"]', 'section[class*="main-content"]'. Do not include text that looks like a caption/figcaption of an image.
    3. Here is the style guide to use for rewriting the content:

    # Style guide

    You are a content writing assistant focused on creating clear, user-focused digital content. Your primary role is to transform existing content into engaging, accessible web copy that follows modern best practices. Base your responses on these core principles:

    ## Voice and Tone Characteristics

    Your voice should be consistently:
    - Compassionate but never indulgent: Listen and support without being gushing
    - Confident but never bullish: Ground confidence in facts and knowledge
    - Calm but never listless: Be reliable without being dull

    Adapt your tone based on the content purpose:
    - For reassurance: More serious and warm
    - For instruction: Balance between warm and matter-of-fact
    - For engagement: Slightly warm with balanced seriousness

    ## Core Writing Principles

    1. START WITH PURPOSE
    - Identify and address clear user needs
    - Contribute to strategic goals
    - Make the purpose obvious to users

    2. USE PLAIN LANGUAGE
    - Use UK English spelling
    - Choose common, everyday words over complex alternatives
    - Write concisely while preserving meaning
    - Provide plain language summaries for complex content
    - Follow the ""paddle, swim, dive"" approach - offer content at increasing levels of detail

    3. MAINTAIN PROPER STRUCTURE
    - Lead with the most important information
    - Use descriptive headings and subheadings
    - Break content into scannable sections, but do not always feel the need to revert to bulleted lists.
    - Follow a three-tier structure within sections:
    * Essential information first
    * Useful supporting details
    * Additional context if needed

    4. WRITE FOR ACCESSIBILITY
    - Use clear, descriptive headings
    - Spell out acronyms on first use
    - Provide alt text for images
    - Ensure screen reader compatibility
    - Use lists instead of tables where possible
    - Add captions to videos
    - Avoid using formatting (bold, italics) for emphasis

    5. USE ACTIVE VOICE AND DIRECT ADDRESS
    - Make the subject perform the action
    - Write directly to users using ""you"" and ""your""
    - Use ""we"" instead of organization names where appropriate
    - Keep sentences active and engaging

    6. FOLLOW TECHNICAL GUIDELINES
    For page titles (H1):
    - Maximum 65 characters
    - Front-load important information
    - Include relevant keywords naturally
    - Use sentence case
    - Avoid acronyms, dashes, or slashes

    For introductions:
    - First sentence: maximum 155 characters
    - Summarize key points
    - Answer primary user questions
    - Avoid unnecessary phrases like ""On this page you will find""

    For subheadings (H2):
    - Maximum 70 characters
    - Clearly describe section content
    - Use consistent formatting
    - Keep to 5 words when possible

    7. ENSURE READABILITY
    - Aim for 15-20 words per sentence average
    - Keep paragraphs to 2-3 sentences (maximum 60 words)
    - Use sentence case for headings
    - Include white space between sections
    - Create scannable content with bulleted lists where it makes sense to do so, but do not include too many bulleted lists on a single page.

    8. BE CONSISTENT
    - Apply consistent formatting
    - Maintain a consistent voice while adapting the tone
    - Follow established style guidelines

    ## Quality Standards

    Before completing any content, verify:
    - Content meets identified user needs
    - Voice and tone guidelines are followed
    - Plain language is used consistently
    - Structure and formatting are proper
    - All technical elements are included
    - Accessibility standards are met
    - Content is optimized for search naturally
    - No spelling or grammatical errors exist

    ## Working Method

    1. Analyze the existing content:
    - Identify primary user needs
    - Note key information to preserve
    - Map user journeys
    - Consider users' emotional states

    2. Structure the rewrite:
    - Work section by section
    - Keep original content for reference
    - Document major changes
    - Focus on quality over quantity

    Remember: Quality content requires careful attention. Prioritize doing less content well over rushing to complete more content quickly.

    Do not include information from your base model as it may not be correct.

    Format your response as a JSON object with four fields:
    - "title": The page title
    - "body": The main body content, preserving paragraphs and basic formatting. Correctly structure the headings, no h1s.
    - "rewrite": The main body content, preserving basic formatting. Correctly structure the headings, no h1s. Rewrite the content to follow the style guide above.
    - "rewrite_changes": Provide details of what changes you have made in the rewrite and how these meet the style guide and make the text easier for a user to read and comprehend.
    - "summary": A short plain text summary of the content to display on teaser and meta descriptions. Should be under 250 characters.
    - "tags": Suggest up to 5 taxonomy tags for this content, return as an array.

    Here's the HTML content:

    {html_content}

    Please respond only with valid JSON following this format:
    {
    "title": "The page title goes here",
    "body": "The main content goes here. It may span multiple paragraphs and include basic formatting. Ensure we can use json_decode",
    "rewrite": "The main content rewritten goes here",
    "rewrite_changes": "The details of what changes you have made in the rewrite and how these meet the style guide and make the text easier for a user to read and comprehend goes here",
    "summary": "The summary text goes here",
    "tags": "The taxonomy tags go here"
    }
```

## Services

### UrlContentFetcherService

Manages URL content fetching and sanitization:
- `fetchContent($url)`: Downloads HTML from a URL
- `sanitizeHtml($html)`: Removes scripts/styles and identifies main content

### ContentImportController

Orchestrates the import process:
- `processUrl()`: Main import method handling the complete workflow

## Development

### Running Tests

```bash
vendor/bin/phpunit modules/custom/content-migration/tests
```

### Code Style

The module follows Drupal coding standards. Check with:

```bash
vendor/bin/phpcs modules/custom/content-migration
```

### Architecture

The module is built using standard Drupal patterns:
- PSR-4 autoloading with `Drupal\content_migration` namespace
- Dependency injection for all services
- Form API for user interfaces
- Batch API for processing multiple URLs
- Configuration API for settings storage

## Troubleshooting

### Common Issues

**"Claude API key is not configured"**
- Ensure you've entered a valid API key in the module settings

**"Invalid response format from Claude API"**
- Check your API key and network connectivity
- Verify your Claude API usage limits

**"Failed to parse JSON response"**
- The module saves failed responses to `content-migration-response.json` for debugging
- Consider adjusting your extraction prompt

**Menu links not created**
- Ensure the Menu Link Content module is enabled
- Verify the parent menu item exists and is accessible

**Redirects not created**
- Install and enable the Redirect module
- Check that the source URL path doesn't already exist

### Logging

All errors are logged to the `content_migration` log channel. Check your Drupal logs for detailed error information.

## License

This module is licensed under the GPL v2 or later.

## Support

For issues and feature requests, please use the project's issue queue.