# Content Quality Assessment JSON Schema

## Overview

This document describes the JSON schema used for storing content quality assessment results in Drupal fields. The schema is defined in `QualityAnalysisPluginBase::getResultsSchema()` and is designed to support:

- Storage of multiple assessment results per content item
- Tracking of both original and rewritten content assessments
- Aggregation and comparison of scores across multiple pages
- Support for multiple quality analysis plugins

## Schema Version

Current version: **1.0**

## JSON Structure

```json
{
  "schema_version": "1.0",
  "node_id": 123,
  "node_title": "Example Article Title",
  "assessment_timestamp": 1704884400,
  "assessment_date": "2024-01-10 10:00:00",
  "assessments": [
    {
      "plugin_id": "style_guide",
      "plugin_label": "Style Guide Analysis",
      "content_label": "Original Content",
      "content_type": "original",
      "overall_score": "8/10",
      "overall_score_numeric": 80.0,
      "scores": {
        "Content Structure": {
          "score": "9/10",
          "score_numeric": 90.0,
          "comments": "Well organized with clear headings and logical flow"
        },
        "Writing Style": {
          "score": "7/10",
          "score_numeric": 70.0,
          "comments": "Generally clear but could be more concise in places"
        },
        "Tone and Voice": {
          "score": "8/10",
          "score_numeric": 80.0,
          "comments": "Appropriate tone for target audience"
        }
      },
      "summary": "The content demonstrates strong adherence to the style guide...",
      "audience_term_id": 456
    },
    {
      "plugin_id": "style_guide",
      "plugin_label": "Style Guide Analysis",
      "content_label": "Paragraph: Main Content (text_block) #1",
      "content_type": "paragraph",
      "overall_score": "7.5/10",
      "overall_score_numeric": 75.0,
      "scores": {
        "Content Structure": {
          "score": "8/10",
          "score_numeric": 80.0,
          "comments": "Good paragraph structure"
        }
      },
      "summary": "Paragraph content is well-structured...",
      "audience_term_id": 456
    },
    {
      "plugin_id": "factual_accuracy",
      "plugin_label": "Factual Accuracy Check",
      "content_label": "Factual Accuracy: Original vs Rewritten",
      "content_type": "comparison",
      "overall_score": "85%",
      "overall_score_numeric": 85.0,
      "scores": {
        "Section 1: Introduction and background": {
          "score": "100%",
          "score_numeric": 100.0,
          "comments": "1 items checked"
        },
        "Section 2: Product features": {
          "score": "85%",
          "score_numeric": 85.0,
          "comments": "2 items checked"
        }
      },
      "summary": "<p>The content maintains good factual accuracy overall...</p>",
      "sections": [
        {
          "number": 1,
          "description": "Introduction and background",
          "original_text": "Our company was founded in 1995 by John Smith...",
          "new_text": "We were founded in 1995 by John Smith...",
          "accuracy_score": "100%",
          "accuracy_score_numeric": 100,
          "differences": [
            {
              "type": "NONE",
              "description": "No factual differences in this section"
            }
          ]
        },
        {
          "number": 2,
          "description": "Product features",
          "original_text": "Launched in March 2023, serving 500 companies...",
          "new_text": "Launched in 2023, serving hundreds of companies...",
          "accuracy_score": "85%",
          "accuracy_score_numeric": 85,
          "differences": [
            {
              "type": "MISSING",
              "description": "Specific month (March) omitted"
            },
            {
              "type": "CHANGED",
              "description": "'500 companies' became 'hundreds' - less precise"
            }
          ]
        }
      ],
      "factual_differences": [
        {
          "type": "MISSING",
          "description": "Section 2: Specific month (March) omitted",
          "section": 2
        },
        {
          "type": "CHANGED",
          "description": "Section 2: '500 companies' became 'hundreds' - less precise",
          "section": 2
        }
      ],
      "audience_term_id": 456
    }
  ]
}
```

## Field Definitions

### Root Level Fields

| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `schema_version` | string | Version of the schema format | "1.0" |
| `node_id` | integer | Drupal node ID being assessed | 123 |
| `node_title` | string | Title of the node | "Example Article" |
| `assessment_timestamp` | integer | Unix timestamp when assessment was run | 1704884400 |
| `assessment_date` | string | Human-readable assessment date | "2024-01-10 10:00:00" |
| `assessments` | array | Array of assessment results | See below |

### Assessment Object Fields

Each item in the `assessments` array contains:

| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `plugin_id` | string | ID of the quality analysis plugin | "style_guide" |
| `plugin_label` | string | Human-readable plugin name | "Style Guide Analysis" |
| `content_label` | string | Label identifying the content assessed | "Original Content" |
| `content_type` | string | Type of content: "original", "rewritten", "paragraph", or "comparison" | "original" |
| `overall_score` | string | Overall quality score as provided by plugin | "8/10" |
| `overall_score_numeric` | float | Normalized score on 0-100 scale | 80.0 |
| `scores` | object | Detailed scores by assessment area | See below |
| `summary` | string | Detailed analysis text | "The content demonstrates..." |
| `sections` | array | (Factual accuracy only) Section-by-section comparison data | See below |
| `factual_differences` | array | (Factual accuracy only) List of all factual differences | See below |
| `raw_response` | string | (Optional) Raw AI response for debugging | "..." |
| `audience_term_id` | integer\|null | Taxonomy term ID if audience-specific | 456 |

### Score Object Fields

Each item in the `scores` object is keyed by the area name and contains:

| Field | Type | Description | Example |
|-------|------|-------------|---------|
| `score` | string | Score as provided by plugin | "9/10" |
| `score_numeric` | float | Normalized score on 0-100 scale | 90.0 |
| `comments` | string | Comments about this area | "Well organized..." |

### Sections Array (Factual Accuracy Plugin)

For factual accuracy comparisons (`content_type: "comparison"`), the `sections` array contains section-by-section comparison data:

```json
"sections": [
  {
    "number": 1,
    "description": "Introduction and background",
    "original_text": "Our company was founded in 1995 by John Smith...",
    "new_text": "We were founded in 1995 by John Smith...",
    "accuracy_score": "100%",
    "accuracy_score_numeric": 100,
    "differences": [
      {
        "type": "NONE",
        "description": "No factual differences in this section"
      }
    ]
  },
  {
    "number": 2,
    "description": "Product features and benefits",
    "original_text": "Launched in March 2023, our product serves 500 companies...",
    "new_text": "We launched our product in 2023 serving hundreds of companies...",
    "accuracy_score": "85%",
    "accuracy_score_numeric": 85,
    "differences": [
      {
        "type": "MISSING",
        "description": "Specific launch date (March) omitted"
      },
      {
        "type": "CHANGED",
        "description": "'500 companies' became 'hundreds of companies' - less precise"
      }
    ]
  },
  {
    "number": 3,
    "description": "Technical specifications",
    "original_text": "Developed by Dr. Smith with ISO 9001 certification...",
    "new_text": "Created by Dr. Jones with industry-leading technology...",
    "accuracy_score": "60%",
    "accuracy_score_numeric": 60,
    "differences": [
      {
        "type": "NEW",
        "description": "Partnership with VSC mentioned in new field but not in original"
      },
      {
        "type": "MISSING",
        "description": "ISO 9001 certification not mentioned in new field"
      },
      {
        "type": "INCORRECT",
        "description": "'Dr. Smith' changed to 'Dr. Jones' - different person"
      }
    ]
  }
]
```

#### Section Object Fields

| Field | Type | Description |
|-------|------|-------------|
| `number` | integer | Section number (1-based) |
| `description` | string | Brief description of section topic |
| `original_text` | string | Extracted text from original field for this section |
| `new_text` | string | Extracted text from new field for this section |
| `accuracy_score` | string | Accuracy score for this section as percentage |
| `accuracy_score_numeric` | float | Normalized accuracy score (0-100) |
| `differences` | array | Array of difference objects |

#### Difference Object Fields

| Field | Type | Description | Values |
|-------|------|-------------|--------|
| `type` | string | Type of factual difference | "NEW", "MISSING", "CHANGED", "INCORRECT", "NONE" |
| `description` | string | Human-readable description of the difference | "Specific launch date (March) omitted" |

**Difference Types:**
- **NEW**: Fact present in new field but not in original field (information added)
- **MISSING**: Fact present in original but absent in new field (information removed)
- **CHANGED**: Fact altered (less precise, different number, etc.)
- **INCORRECT**: Fact is wrong or contradicts original
- **NONE**: No factual differences in this section

### Factual Differences Array (Factual Accuracy Plugin)

For backwards compatibility and quick access, the `factual_differences` array provides a flat list of all differences:

```json
"factual_differences": [
  {
    "type": "MISSING",
    "description": "Section 2: Specific launch date (March) omitted",
    "section": 2
  },
  {
    "type": "CHANGED",
    "description": "Section 2: '500 companies' became 'hundreds of companies' - less precise",
    "section": 2
  },
  {
    "type": "NEW",
    "description": "Section 3: Partnership with VSC mentioned in new field but not in original",
    "section": 3
  },
  {
    "type": "MISSING",
    "description": "Section 3: ISO 9001 certification not mentioned in new field",
    "section": 3
  },
  {
    "type": "INCORRECT",
    "description": "Section 3: 'Dr. Smith' changed to 'Dr. Jones' - different person",
    "section": 3
  }
]
```

## Score Normalization

The `QualityAnalysisPluginBase::normalizeScore()` method converts various score formats to a normalized 0-100 scale:

- **Fraction format**: "8/10" → 80.0
- **Percentage format**: "85%" → 85.0
- **Numeric (0-10 scale)**: "8.5" → 85.0
- **Numeric (0-100 scale)**: "85" → 85.0

This normalization allows for:
- Consistent aggregation across different scoring methods
- Easy comparison of scores across multiple pages
- Generation of reports and statistics

## Usage

### Storing Assessment Results

Results are automatically stored in JSON format when:
1. A user runs the Content Quality Checker tool
2. A "Quality Assessment Field" is configured for the content type in the Content Migration settings
3. The field is a text field type (text, text_long, text_with_summary, or text_plain_long)

### Retrieving and Aggregating Results

To retrieve and aggregate results across multiple nodes:

```php
// Load node and get the quality assessment field value
$node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
$quality_data = $node->get('field_quality_assessment')->value;

// Decode JSON
$assessment = json_decode($quality_data, TRUE);

// Access overall score
$overall_score = $assessment['assessments'][0]['overall_score_numeric'];

// Access individual area scores
foreach ($assessment['assessments'][0]['scores'] as $area => $score_data) {
  $area_name = $area;
  $numeric_score = $score_data['score_numeric'];
  // Process scores...
}
```

### Example: Calculating Average Scores

```php
// Calculate average overall score across multiple nodes
$total_score = 0;
$count = 0;

foreach ($nodes as $node) {
  $quality_data = $node->get('field_quality_assessment')->value;
  $assessment = json_decode($quality_data, TRUE);

  if (!empty($assessment['assessments'][0]['overall_score_numeric'])) {
    $total_score += $assessment['assessments'][0]['overall_score_numeric'];
    $count++;
  }
}

$average_score = $count > 0 ? $total_score / $count : 0;
```

## Configuration

To configure content quality assessment storage:

1. Navigate to **Configuration → Content Migration → Settings**
2. Expand **Content Type & Taxonomy Settings**
3. Select allowed content types
4. Expand **Default Field Mappings**
5. For each content type, select a text field for **Quality Assessment Field**
6. Save configuration

## Future Enhancements

The schema is designed to support future enhancements:

- Multiple plugin assessments per content item
- Comparison of before/after rewrite scores
- Historical tracking of assessment changes over time
- Batch processing and reporting tools
- Export capabilities for external analysis

## Version History

- **1.0** (2024): Initial schema implementation
  - Support for single/multiple assessments per node
  - Normalized scoring system
  - Plugin-based architecture
