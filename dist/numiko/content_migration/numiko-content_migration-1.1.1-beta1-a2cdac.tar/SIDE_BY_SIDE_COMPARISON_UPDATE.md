# Side-by-Side Before/After Comparison Update

## Date
2025-11-04

## Summary

Updated the Factual Accuracy plugin to display a **three-column side-by-side comparison** showing the original field content, new field content, and differences for each section. This provides a much more visual and actionable way to review factual accuracy.

## What Changed

### 1. Display Format Change

**Before:**
```
Section 1: Introduction and Background
Accuracy Score: 100%
Factual Differences:
  - No factual differences in this section
```

**After:**
```
┌─────────────────────────────────────────────────────────────┐
│ Section 1: Introduction and Background    Accuracy: 100%    │
├──────────────────┬──────────────────┬──────────────────────┤
│ ORIGINAL FIELD   │ NEW FIELD        │ DIFFERENCES          │
│ (light yellow)   │ (light blue)     │ (light gray)         │
├──────────────────┼──────────────────┼──────────────────────┤
│ Our company was  │ We were founded  │ ✓ No factual         │
│ founded in 1995  │ in 1995 by John  │   differences in     │
│ by John Smith... │ Smith...         │   this section       │
└──────────────────┴──────────────────┴──────────────────────┘
```

### 2. AI Prompt Updates

**FactualAccuracyAnalysis.php** - `buildComparisonPrompt()`:

**New Instructions:**
```
Please perform a detailed section-by-section factual accuracy check with before/after comparison:

1. Divide the original content into logical sections
2. For each section, extract the relevant text from BOTH the original and new fields
3. Identify all factual statements in each section
4. Compare the two versions side-by-side
5. Rate the accuracy of each section individually
6. List factual discrepancies with clear notes
```

**New Output Format Expected:**
```
SECTION 1: [Description]
Original Text: [Extract relevant text from original - 2-4 sentences]
New Text: [Extract corresponding text from new field - 2-4 sentences]
Accuracy Score: [Percentage]
Differences:
- [Type: MISSING/CHANGED/INCORRECT] [Brief note]
```

### 3. Response Parsing Updates

**FactualAccuracyAnalysis.php** - `parseComparisonResponse()`:

Added extraction of text fields:

```php
// Extract original text
if (preg_match('/Original\s+Text:\s*(.+?)(?=New\s+Text:|$)/is', $section_content, $orig_match)) {
  $section_data['original_text'] = trim($orig_match[1]);
}

// Extract new text
if (preg_match('/New\s+Text:\s*(.+?)(?=Accuracy\s+Score:|$)/is', $section_content, $new_match)) {
  $section_data['new_text'] = trim($new_match[1]);
}
```

**Section Data Structure:**
```php
$section_data = [
  'number' => 1,
  'description' => 'Introduction and background',
  'original_text' => 'Text from original field...',
  'new_text' => 'Text from new field...',
  'accuracy_score' => '100%',
  'accuracy_score_numeric' => 100,
  'differences' => [...]
];
```

### 4. Display Implementation

**ContentQualityCheckForm.php** - `formatSectionAnalysis()`:

Created a three-column grid layout using CSS Grid:

```php
// Three-column layout
$output .= '<div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 0;">';

// Column 1: Original Text (light yellow background)
$output .= '<div style="padding: 15px; border-right: 1px solid #ddd; background-color: #fffbf0;">';
$output .= '<div style="font-weight: bold; color: #856404;">ORIGINAL FIELD</div>';
$output .= nl2br(htmlspecialchars($section['original_text']));

// Column 2: New Text (light blue background)
$output .= '<div style="padding: 15px; border-right: 1px solid #ddd; background-color: #f0f8ff;">';
$output .= '<div style="font-weight: bold; color: #0056b3;">NEW FIELD</div>';
$output .= nl2br(htmlspecialchars($section['new_text']));

// Column 3: Differences (light gray background)
$output .= '<div style="padding: 15px; background-color: #f9f9f9;">';
$output .= '<div style="font-weight: bold; color: #555;">DIFFERENCES</div>';
// ... differences with color-coded badges ...
```

### 5. Visual Design

**Section Header:**
- Gray background (#f5f5f5)
- Section number and description on the left
- Accuracy score on the right
- Flexbox layout for alignment

**Original Field Column:**
- Light yellow background (#fffbf0)
- Brown text for header (#856404)
- Shows extracted text from original field

**New Field Column:**
- Light blue background (#f0f8ff)
- Blue text for header (#0056b3)
- Shows extracted text from new field

**Differences Column:**
- Light gray background (#f9f9f9)
- Color-coded badges:
  - 🔵 NEW - Blue badge (#007bff) - Facts added to new field
  - 🟨 MISSING - Yellow badge (#ffc107) - Facts removed from original
  - 🔵 CHANGED - Cyan badge (#17a2b8) - Facts altered between fields
  - 🔴 INCORRECT - Red badge (#dc3545) - Facts that are wrong
  - ✅ NONE - Green checkmark - No differences

## Benefits of Side-by-Side Comparison

### 1. **Visual Context**
Users can now SEE the actual content being compared instead of just reading about differences in the abstract.

**Before:**
> "Original mentions 500 participants but new field says hundreds"

**After:**
> Left column shows: "...serves 500 companies..."
> Right column shows: "...serving hundreds of companies..."
> Differences: [CHANGED] "500 companies" became "hundreds"

### 2. **Easier to Verify**
Editors can directly read both versions and judge whether the change is acceptable.

### 3. **Better Understanding of Context**
See the surrounding text to understand if the factual change matters in context.

### 4. **Faster Review Process**
No need to switch between fields or search for content - it's all visible at once.

### 5. **Clear Visual Separation**
Color-coded columns make it immediately clear which is original vs new vs notes.

## Example Usage

When you run a factual accuracy check on a page with both original and new content fields:

### Step 1: Analysis Runs
The AI divides content into sections and extracts matching text from both fields.

### Step 2: Display Appears
You see a series of comparison blocks:

```html
┌────────────────────────────────────────────────────────────────┐
│ Section 1: Company History                    Accuracy: 100%   │
├──────────────────┬──────────────────┬─────────────────────────┤
│ ORIGINAL FIELD   │ NEW FIELD        │ DIFFERENCES             │
│                  │                  │                         │
│ Founded in 1995  │ Established in   │ ✓ No factual           │
│ by John Smith in │ 1995 by John     │   differences          │
│ Silicon Valley,  │ Smith in Silicon │                         │
│ we started...    │ Valley...        │                         │
└──────────────────┴──────────────────┴─────────────────────────┘

┌────────────────────────────────────────────────────────────────┐
│ Section 2: Product Launch                     Accuracy: 85%    │
├──────────────────┬──────────────────┬─────────────────────────┤
│ ORIGINAL FIELD   │ NEW FIELD        │ DIFFERENCES             │
│                  │                  │                         │
│ Launched in      │ We launched our  │ [MISSING] Launch month  │
│ March 2023, our  │ product in 2023  │ (March) omitted         │
│ product serves   │ serving hundreds │                         │
│ 500 companies... │ of companies...  │ [CHANGED] "500" became  │
│                  │                  │ "hundreds" (less        │
│                  │                  │ precise)                │
└──────────────────┴──────────────────┴─────────────────────────┘
```

### Step 3: Review Each Section
- Scan the original text (left)
- Compare to the new text (middle)
- Read the differences notes (right)
- Check the accuracy score in the header

### Step 4: Take Action
- Sections with 100% accuracy need no action
- Sections with lower scores show exactly what needs fixing
- Can see if changes are acceptable or need correction

## Technical Details

### Grid Layout
Uses CSS Grid for equal-width columns:
```css
display: grid;
grid-template-columns: 1fr 1fr 1fr;
gap: 0;
```

### Responsive Considerations
Currently uses fixed 3-column layout. For mobile, would need:
```css
@media (max-width: 768px) {
  grid-template-columns: 1fr;
}
```

### Text Extraction
The AI extracts 2-4 sentences or key points from each field for each section. This keeps the display concise while showing the essential content.

### Border Styling
- Outer border: 1px solid #ddd
- Column separators: border-right 1px solid #ddd
- Header separator: border-bottom 2px solid #ddd

## Files Modified

1. **src/Plugin/QualityAnalysis/FactualAccuracyAnalysis.php**
   - `buildComparisonPrompt()`: Updated to request text extraction
   - `parseComparisonResponse()`: Added extraction of original_text and new_text

2. **src/Form/ContentQualityCheckForm.php**
   - `formatSectionAnalysis()`: Completely rewritten for three-column layout
   - Added color-coded backgrounds
   - Added badge styling for difference types

3. **FACTUAL_ACCURACY_PLUGIN.md**
   - Updated "Output Format" section with visual example
   - Added "Visual Features" explanation

4. **SIDE_BY_SIDE_COMPARISON_UPDATE.md** (this file)

## Migration Notes

**Backwards Compatible:**
- Old assessments without text extraction will still display
- Columns will show "No text extracted" if data is missing
- Dashboard continues to work with section scores

**New Assessments:**
- Will automatically include extracted text
- Display in three-column format
- Much more visual and informative

## Future Enhancements

1. **Text Highlighting**
   - Highlight specific facts that changed
   - Use yellow highlight for missing facts
   - Use red underline for incorrect facts

2. **Collapsible Sections**
   - Allow collapsing sections with 100% accuracy
   - Focus on problem sections

3. **Export to PDF**
   - Generate PDF report with side-by-side comparison
   - Include for client review or archiving

4. **Diff View Option**
   - Add toggle to show word-by-word diff
   - Similar to Git diff view

5. **Responsive Mobile View**
   - Stack columns vertically on mobile
   - Maintain usability on smaller screens

## Testing Recommendations

1. **Content Length Testing**
   - Short sections (1-2 sentences)
   - Medium sections (3-5 sentences)
   - Long sections (6+ sentences)
   - Verify AI extracts appropriate amount

2. **Visual Testing**
   - Check alignment of columns
   - Verify borders display correctly
   - Test with very long text in one column
   - Ensure readability of difference badges

3. **Cross-browser Testing**
   - Test CSS Grid support
   - Verify colors display consistently
   - Check text wrapping behavior

4. **Content Variety**
   - Test with bulleted lists
   - Test with numbered facts
   - Test with tables (if applicable)
   - Test with special characters

## Conclusion

The side-by-side comparison format transforms the factual accuracy review from an abstract list of differences into a visual, contextual comparison. Users can now directly see what was in the original field, what's in the new field, and what differs - all at a glance.

This makes the factual accuracy check much more useful and actionable for content editors, reviewers, and anyone responsible for ensuring content quality during migration or rewriting.
