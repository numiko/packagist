<?php

namespace Drupal\content_migration\Form;

use Drupal\Core\DependencyInjection\AutowireTrait;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Menu\MenuLinkManagerInterface;
use Drupal\Core\Url;
use Drupal\content_migration\Controller\ContentImportController;
use Drupal\content_migration\Plugin\AiMigrationPluginManager;
use Drupal\content_migration\Service\TaxonomyPromptService;
use Drupal\field\Entity\FieldConfig;
use Drupal\file\Entity\File;

/**
 * Form for importing content from URLs using Claude API.
 */
class ContentImportForm extends FormBase {
  use AutowireTrait;

  /**
   * Constructs a ContentImportForm object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entityFieldManager
   *   The entity field manager.
   * @param \Drupal\content_migration\Controller\ContentImportController $contentImportController
   *   The content import controller.
   * @param \Drupal\Core\Menu\MenuLinkManagerInterface $menuLinkManager
   *   The menu link manager.
   * @param \Drupal\content_migration\Plugin\AiMigrationPluginManager $aiMigrationPluginManager
   *   The AI migration plugin manager.
   * @param \Drupal\content_migration\Service\TaxonomyPromptService $taxonomyPromptService
   *   The taxonomy prompt service.
   * @param \Drupal\Core\File\FileSystemInterface $fileSystem
   *   File system.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected EntityFieldManagerInterface $entityFieldManager,
    protected ContentImportController $contentImportController,
    protected MenuLinkManagerInterface $menuLinkManager,
    protected AiMigrationPluginManager $aiMigrationPluginManager,
    protected TaxonomyPromptService $taxonomyPromptService,
    protected FileSystemInterface $fileSystem,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'content_migration_import_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Enable file uploads.
    $form['#attributes']['enctype'] = 'multipart/form-data';

    // Get configured content types for selection.
    $config = $this->config('content_migration.settings');
    $allowed_content_types = $config->get('allowed_content_types') ?: [];

    if (empty($allowed_content_types)) {
      $form['no_content_types'] = [
        '#markup' => '<div class="messages messages--warning">' . $this->t('No content types are configured for migration. Please visit the <a href="@settings_url">Content Migration settings</a> to configure allowed content types and their taxonomies.', [
          '@settings_url' => Url::fromRoute('content_migration.settings')->toString(),
        ]) . '</div>',
      ];
      return $form;
    }

    $content_type_options = [];
    foreach ($allowed_content_types as $content_type_id) {
      $content_type = $this->entityTypeManager->getStorage('node_type')->load($content_type_id);
      if ($content_type) {
        $content_type_options[$content_type_id] = $content_type->label();
      }
    }

    // Build import type options based on configuration.
    $import_type_options = [];
    if ($config->get('enable_url_import') ?? TRUE) {
      $import_type_options['urls'] = $this->t('Import from URLs');
    }
    if ($config->get('enable_pdf_import') ?? TRUE) {
      $import_type_options['pdf'] = $this->t('Extract content from PDF');
    }
    if ($config->get('enable_title_import') ?? TRUE) {
      $import_type_options['titles'] = $this->t('Create empty pages from titles');
    }
    if ($config->get('enable_csv_import') ?? TRUE) {
      $import_type_options['csv'] = $this->t('Upload CSV/TSV with page structure');
    }

    // If no import types are enabled, show error message.
    if (empty($import_type_options)) {
      $form['no_import_types'] = [
        '#markup' => '<div class="messages messages--warning">' . $this->t('No import types are enabled. Please visit the <a href="@settings_url">Content Migration settings</a> to enable at least one import type.', [
          '@settings_url' => Url::fromRoute('content_migration.settings')->toString(),
        ]) . '</div>',
      ];
      return $form;
    }

    $form['import_type'] = [
      '#type' => 'radios',
      '#title' => $this->t('Import Type'),
      '#options' => $import_type_options,
      '#required' => TRUE,
      '#ajax' => [
        'callback' => '::updateFormContent',
        'wrapper' => 'form-content-wrapper',
      ],
    ];

    $form['form_content_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'form-content-wrapper'],
    ];

    $form['form_content_wrapper']['import_options_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'import-options-wrapper'],
    ];

    // Get import type early for conditional form building.
    $import_type = $form_state->getValue('import_type');
    if (!$import_type) {
      $user_input = $form_state->getUserInput();
      $import_type = $user_input['import_type'] ?? NULL;
    }

    $this->buildImportOptionsForm($form['form_content_wrapper'], $form_state);

    // Merge options - only for URL imports.
    if ($import_type === 'urls') {
      $form['form_content_wrapper']['merge_urls'] = [
        '#type' => 'checkbox',
        '#title' => $this->t('Merge multiple URLs into one page'),
        '#description' => $this->t('When enabled, content from all URLs will be merged into a single page instead of creating separate pages for each URL.'),
        '#default_value' => FALSE,
      ];

      $form['form_content_wrapper']['merge_options'] = [
        '#type' => 'details',
        '#title' => $this->t('Merge Options'),
        '#open' => FALSE,
        '#states' => [
          'visible' => [
            ':input[name="merge_urls"]' => ['checked' => TRUE],
          ],
        ],
        'merged_title' => [
          '#type' => 'textfield',
          '#title' => $this->t('Title for merged page'),
          '#description' => $this->t('Enter a title for the merged page. Leave empty to use the title from the first URL.'),
        ],
        'include_source_headers' => [
          '#type' => 'checkbox',
          '#title' => $this->t('Include source headers'),
          '#description' => $this->t('Add headings to separate content from different URLs, showing the source URL or page title.'),
          '#default_value' => TRUE,
        ],
        'content_separator' => [
          '#type' => 'select',
          '#title' => $this->t('Content separation method'),
          '#description' => $this->t('How to separate content from different URLs.'),
          '#options' => [
            'headers' => $this->t('Use headings with source titles'),
            'dividers' => $this->t('Use horizontal dividers'),
            'none' => $this->t('No separation (continuous content)'),
          ],
          '#default_value' => 'headers',
        ],
      ];

    }

    // Audience and content type - only show after import type is
    // selected (and for non-CSV imports).
    if ($import_type && $import_type !== 'csv') {
      // Audience field - hide for 'titles' import type.
      if ($import_type !== 'titles') {
        // Get audience vocabulary from configuration.
        $audience_vocabulary_id = $config->get('audience_vocabulary');
        $audience_options = [];

        if ($audience_vocabulary_id && $this->taxonomyPromptService->vocabularyHasTermsWithPrompts($audience_vocabulary_id)) {
          $audience_options = $this->taxonomyPromptService->getTermOptions($audience_vocabulary_id);
        }

        $form['form_content_wrapper']['audience'] = [
          '#type' => 'select',
          '#title' => $this->t('Target Audience'),
          '#options' => $audience_options,
          '#required' => TRUE,
          '#description' => $this->t('Select the target audience for the content. This will be used by AI processing plugins to tailor the content.'),
          '#weight' => -10,
        ];
      }

      $form['form_content_wrapper'] = $form['form_content_wrapper'] + [
        'content_type' => [
          '#type' => 'select',
          '#title' => $this->t('Content Type'),
          '#options' => $content_type_options,
          '#required' => TRUE,
          '#ajax' => [
            'callback' => '::updateFieldOptions',
            'wrapper' => 'field-options-wrapper',
          ],
          '#weight' => -9,
        ],
        // Add menu parent selection field:
        'parent_menu_item' => [
          '#type' => 'select',
          '#title' => $this->t('Parent Menu Item'),
          '#options' => $this->getMainMenuOptions(),
          '#empty_option' => $this->t('- Do not add to menu -'),
          '#description' => $this->t('Select a parent menu item. New nodes will be added as children of this item in the main menu.'),
        ],
        'field_options_wrapper' => [
          '#type' => 'container',
          '#attributes' => ['id' => 'field-options-wrapper'],
        ],
      ];
    }

    $content_type = $form_state->getValue('content_type');

    // Build field options only after import type is selected
    // (and for non-CSV imports)
    if ($import_type && $import_type !== 'csv') {
      // (URL and PDF) Base content field.
      if ($import_type === 'urls' || $import_type === 'pdf') {
        if ($content_type) {
          $default_mappings = $config->get('content_type_field_mappings')[$content_type] ?? [];
          $default_original_content = $default_mappings['original_content'] ?? '';

          // Check form state first to preserve user input during AJAX rebuilds.
          $field_body_value = $form_state->getValue('field_body');
          if (!$field_body_value) {
            $user_input = $form_state->getUserInput();
            $field_body_value = $user_input['field_body'] ?? '';
          }
          if (!$field_body_value) {
            $field_body_value = $default_original_content;
          }

          $description = $import_type === 'pdf'
            ? $this->t('Select the field where the extracted PDF content should be saved.')
            : $this->t('Select the field where the extracted body content should be saved.');

          $form['form_content_wrapper']['field_options_wrapper']['field_body'] = [
            '#type' => 'select',
            '#title' => $this->t('Field for extracted content'),
            '#options' => $this->getTextFieldOptionsWithCompositeKeys($content_type),
            '#required' => TRUE,
            '#default_value' => $field_body_value,
            '#description' => $description,
          ];
        }
        else {
          $form['form_content_wrapper']['field_options_wrapper']['field_body'] = [
            '#type' => 'select',
            '#title' => $this->t('Field for extracted body content'),
            '#options' => [],
            '#description' => $this->t('Select a content type first.'),
            '#disabled' => TRUE,
          ];
        }
      }

      // Add taxonomy term selection based on configured taxonomies for this
      // content type.
      $taxonomy_fields = $this->getTaxonomyFieldsForContentType($content_type);
      if (!empty($taxonomy_fields)) {
        $form['form_content_wrapper']['field_options_wrapper']['taxonomy_terms'] = [
          '#type' => 'details',
          '#title' => $this->t('Taxonomy Terms'),
          '#open' => TRUE,
          '#tree' => TRUE,
        ];

        foreach ($taxonomy_fields as $vocabulary_id => $vocabulary_info) {
          $form['form_content_wrapper']['field_options_wrapper']['taxonomy_terms'][$vocabulary_id] = [
            '#type' => 'checkboxes',
            '#title' => $vocabulary_info['label'],
            '#options' => $this->getTaxonomyTermOptions($vocabulary_id),
            '#description' => $this->t('Select one or more terms from @vocabulary for this content.', ['@vocabulary' => $vocabulary_info['label']]),
          ];
        }
      }

      // (URL and PDF) AI Plugins:
      if ($import_type === 'urls' || $import_type === 'pdf') {
        if ($content_type) {
          // AI plugins configuration.
          $form['form_content_wrapper']['field_options_wrapper']['ai_plugins'] = [
            '#type' => 'details',
            '#title' => $this->t('AI Processing Options'),
            '#open' => TRUE,
            '#tree' => TRUE,
          ];
          $ai_plugins = &$form['form_content_wrapper']['field_options_wrapper']['ai_plugins'];

          // Get all available AI plugins.
          $available_plugins = $this->aiMigrationPluginManager->getDefinitions();
          /** @var array $default_enabled_plugins */
          $default_enabled_plugins = $config->get('default_enabled_ai_plugins') ?: [];

          foreach ($available_plugins as $plugin_id => $plugin_definition) {
            /** @var \Drupal\content_migration\Plugin\AiMigrationInterface $plugin_instance */
            $plugin_instance = $this->aiMigrationPluginManager->createInstance($plugin_id);

            if ($plugin_instance->hasBeenCancelled($content_type)) {
              continue;
            }

            $ai_plugins[$plugin_id] = [
              '#type' => 'details',
              '#title' => $plugin_instance->getLabel(),
              '#description' => $plugin_instance->getDescription(),
              '#open' => FALSE,
              '#tree' => TRUE,
              'enabled' => [
                '#type' => 'checkbox',
                '#title' => $this->t('Enable @plugin', ['@plugin' => $plugin_instance->getLabel()]),
                '#default_value' => in_array($plugin_id, $default_enabled_plugins),
              ],
            ];

            // Get the plugin's configuration form with default field mappings.
            $plugin_config = $form_state->getValue(['ai_plugins', $plugin_id, 'config']) ?? [];

            // Check if this is an AJAX rebuild triggered by content type
            // change.
            $triggering_element = $form_state->getTriggeringElement();
            $is_content_type_change = $triggering_element && $triggering_element['#name'] === 'content_type';

            // Always apply defaults if config is empty, or if this is a content
            // type change. This ensures defaults are shown on initial load and
            // when content type changes.
            if (empty($plugin_config) || $is_content_type_change) {
              $plugin_config = $this->applyDefaultFieldMappings($plugin_id, $content_type, [], $config);
            }

            // Create a temporary form state with the correct content type for
            // the plugin.
            $temp_form_state = clone $form_state;
            $temp_form_state->setValue('content_type', $content_type);

            $plugin_form = $plugin_instance->configurationForm([], $temp_form_state, $plugin_config);

            if (!empty($plugin_form)) {
              $ai_plugins[$plugin_id]['config'] = [
                '#tree' => TRUE,
                '#states' => [
                  'visible' => [
                    ':input[name="ai_plugins[' . $plugin_id . '][enabled]"]' => ['checked' => TRUE],
                  ],
                ],
              ] + $plugin_form;
            }
          }
        }
        else {
          $form['form_content_wrapper']['field_options_wrapper']['ai_plugins'] = [
            '#markup' => $this->t('Please select a content type first to configure AI processing options.'),
          ];
        }

        // Create redirects option:
        //
        // Get current value or default to TRUE.
        $create_redirects_value = $form_state->getValue('create_redirects');
        $default_create_redirects = ($create_redirects_value !== NULL) ? $create_redirects_value : TRUE;

        $form['form_content_wrapper']['create_redirects'] = [
          '#type' => 'checkbox',
          '#title' => $this->t('Create URL redirects'),
          '#description' => $this->t('Create redirects from the original URLs to the newly created nodes.'),
          '#default_value' => $default_create_redirects,
        ];
      }
    }

    $form['form_content_wrapper']['actions'] = [
      '#type' => 'actions',
      'submit' => [
        '#type' => 'submit',
        '#value' => $this->t('Import Content!'),
      ],
    ];

    return $form;
  }

  /**
   * Ajax callback to update the field options based on selected content type.
   */
  public function updateFieldOptions(array &$form, FormStateInterface $form_state): array {
    return $form['form_content_wrapper']['field_options_wrapper'];
  }

  /**
   * Ajax callback to update import options based on import type.
   */
  public function updateImportOptions(array &$form, FormStateInterface $form_state): array {
    return $form['form_content_wrapper']['import_options_wrapper'];
  }

  /**
   * Ajax callback to update the entire form content when import type changes.
   */
  public function updateFormContent(array &$form, FormStateInterface $form_state): array {
    // Clear all form values except import_type to reset the form.
    $triggering_element = $form_state->getTriggeringElement();
    if ($triggering_element && $triggering_element['#name'] === 'import_type') {
      $import_type = $form_state->getValue('import_type');

      // Clear all values except import_type.
      $form_state->setValues(['import_type' => $import_type]);
      $form_state->setUserInput(['import_type' => $import_type]);

      // Rebuild the form.
      $form_state->setRebuild(TRUE);
    }

    return $form['form_content_wrapper'];
  }

  /**
   * Get text and text long field options for the given content type.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field labels keyed by field names.
   */
  protected function getTextFieldOptions($content_type): array {
    $field_options = [];
    $fields = $this->entityFieldManager->getFieldDefinitions('node', $content_type);

    foreach ($fields as $field_name => $field_definition) {
      if ($field_definition instanceof FieldConfig) {
        $field_type = $field_definition->getType();
        // Get fields of type text, text_long, text_with_summary.
        if (in_array($field_type, ['text_with_summary', 'text_long', 'text'])) {
          $field_options[$field_name] = $field_definition->getLabel();
        }
      }
    }

    return $field_options;
  }

  /**
   * Get text field options with composite keys for the given content type.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field labels keyed by composite keys.
   */
  protected function getTextFieldOptionsWithCompositeKeys($content_type): array {
    $field_options = [];
    $fields = $this->entityFieldManager->getFieldDefinitions('node', $content_type);

    foreach ($fields as $field_name => $field_definition) {
      if ($field_definition instanceof FieldConfig) {
        $field_type = $field_definition->getType();

        if (in_array($field_type, ['text_with_summary', 'text_long', 'text', 'entity_reference_revisions'])) {
          // Create composite key: type:field_name.
          $composite_key = $field_type . ':' . $field_name;

          // Add type suffix to label for clarity.
          $type_suffix = '';
          if ($field_type === 'entity_reference_revisions') {
            $target_type = $field_definition->getSetting('target_type');
            if ($target_type === 'paragraph') {
              $type_suffix = ' (Paragraph)';
            }
          }
          else {
            $type_suffix = ' (Text)';
          }

          $field_options[$composite_key] = $field_definition->getLabel() . $type_suffix;
        }
      }
    }

    return $field_options;
  }

  /**
   * Get main menu items as options for the select list.
   *
   * @return array
   *   An array of menu item titles keyed by menu link IDs.
   */
  protected function getMainMenuOptions(): array {
    $options = [];

    // Load all menu links from the main menu.
    $menu_links = $this->menuLinkManager->loadLinksByRoute('entity.node.canonical', [], 'main');

    // Also get menu links that might not be node-based.
    $all_main_links = $this->entityTypeManager->getStorage('menu_link_content')->loadByProperties(['menu_name' => 'main']);

    foreach ($all_main_links as $menu_link) {
      if ($menu_link->isEnabled()) {
        $title = $menu_link->getTitle();
        $options[$menu_link->getPluginId()] = $title;
      }
    }

    return $options;
  }

  /**
   * Get taxonomy fields configured for a specific content type.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of vocabulary information keyed by vocabulary ID.
   */
  protected function getTaxonomyFieldsForContentType($content_type): array {
    $config = $this->config('content_migration.settings');
    $content_type_taxonomies = $config->get('content_type_taxonomies') ?: [];

    if (empty($content_type_taxonomies[$content_type])) {
      return [];
    }

    $taxonomy_fields = [];
    foreach ($content_type_taxonomies[$content_type] as $vocabulary_id) {
      $vocabulary = $this->entityTypeManager->getStorage('taxonomy_vocabulary')->load($vocabulary_id);
      if ($vocabulary) {
        $taxonomy_fields[$vocabulary_id] = [
          'label' => $vocabulary->label(),
          'id' => $vocabulary_id,
        ];
      }
    }

    return $taxonomy_fields;
  }

  /**
   * Get taxonomy term options for a specific vocabulary.
   *
   * @param string $vocabulary_id
   *   The vocabulary ID.
   *
   * @return array
   *   An array of term names keyed by term IDs.
   */
  protected function getTaxonomyTermOptions($vocabulary_id): array {
    $options = [];
    $terms = $this->entityTypeManager->getStorage('taxonomy_term')->loadTree($vocabulary_id);

    foreach ($terms as $term) {
      $options[$term->tid] = $term->name;
    }

    return $options;
  }

  /**
   * Build the import options form based on import type.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  protected function buildImportOptionsForm(array &$form, FormStateInterface $form_state) {
    $config = $this->config('content_migration.settings');
    $import_type = $form_state->getValue('import_type');

    // During AJAX callbacks, check user input for import_type.
    if (!$import_type) {
      $user_input = $form_state->getUserInput();
      $import_type = $user_input['import_type'] ?? NULL;
    }

    if ($import_type === 'urls') {
      $form['import_options_wrapper']['url_input'] = [
        '#type' => 'textarea',
        '#title' => $this->t('URLs'),
        '#description' => $this->t('Enter one or more URLs, one per line. Content will be extracted from these URLs.'),
        '#required' => TRUE,
        '#rows' => 5,
      ];

      $form['import_options_wrapper']['url_extraction_mode'] = [
        '#type' => 'radios',
        '#title' => $this->t('Content Extraction Mode'),
        '#options' => [
          'article' => $this->t('Article Mode - Extract main article content (recommended for news articles and blog posts)'),
          'full_page' => $this->t('Full Page Mode - Extract all body content (recommended for structured pages with multiple sections)'),
        ],
        '#default_value' => $config->get('default_extraction_mode') ?: 'article',
        '#description' => $this->t('Choose how content should be extracted from source URLs. Article mode uses smart extraction to find the main content, while Full Page mode extracts all content from the page body.'),
      ];

      $form['import_options_wrapper']['url_content_selector'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Content Selector (Optional)'),
        '#default_value' => $config->get('default_content_selector') ?: '',
        '#description' => $this->t('Specify a CSS selector to extract specific content in Full Page mode. Examples: "main", ".content", ".main-content", "#article". Leave empty to extract all body content.'),
        '#states' => [
          'visible' => [
            ':input[name="url_extraction_mode"]' => ['value' => 'full_page'],
          ],
        ],
      ];

      $form['import_options_wrapper']['url_tags_to_remove'] = [
        '#type' => 'textarea',
        '#title' => $this->t('Elements to Remove (Optional)'),
        '#description' => $this->t('Comma-separated list of HTML tags, classes, or IDs to remove during extraction in Full Page mode. Supports tag names (e.g., "nav", "footer"), class selectors (e.g., ".sidebar", ".advertisement"), or ID selectors (e.g., "#header-nav", "#ads"). Default: header, footer, aside, nav, script, style, noscript, iframe. Examples: "nav, .sidebar, footer" or "header, footer, .ads, #main-nav, script, style".'),
        '#default_value' => $config->get('default_tags_to_remove') ?: 'header, footer, aside, nav, script, style, noscript, iframe',
        '#states' => [
          'visible' => [
            ':input[name="url_extraction_mode"]' => ['value' => 'full_page'],
          ],
        ],
      ];
    }
    elseif ($import_type === 'pdf') {
      // PDF file upload field.
      if (version_compare(\Drupal::VERSION, '11', '>=')) {
        $form['import_options_wrapper']['pdf_file'] = [
          '#type' => 'managed_file',
          '#title' => $this->t('PDF File'),
          '#description' => $this->t('Upload a PDF file to extract content from. The text content will be extracted using Claude AI.'),
          '#required' => TRUE,
          '#upload_location' => 'temporary://content_migration_pdf/',
          '#upload_validators' => [
            'FileExtension' => [
              'extensions' => 'pdf',
            ],
          ],
        ];
      }
      else {
        $form['import_options_wrapper']['pdf_file'] = [
          '#type' => 'managed_file',
          '#title' => $this->t('PDF File'),
          '#description' => $this->t('Upload a PDF file to extract content from. The text content will be extracted using Claude AI.'),
          '#required' => TRUE,
          '#upload_location' => 'temporary://content_migration_pdf/',
          '#upload_validators' => [
            'file_validate_extensions' => ['pdf'],
          ],
        ];
      }
    }
    elseif ($import_type === 'titles') {
      $form['import_options_wrapper']['title_input'] = [
        '#type' => 'textarea',
        '#title' => $this->t('Page Titles'),
        '#description' => $this->t('Enter one or more page titles, one per line. Empty pages will be created with these titles.'),
        '#required' => TRUE,
        '#rows' => 5,
      ];
    }
    elseif ($import_type === 'csv') {
      // Override file extension validator for D11.
      if (version_compare(\Drupal::VERSION, '11', '>=')) {
        $form['import_options_wrapper']['csv_file'] = [
          '#type' => 'managed_file',
          '#title' => $this->t('CSV/TSV File'),
          '#description' => $this->t('Upload a CSV or TSV file with required columns: page_title, content_type, parent_page_title. Optional column: source_url (if provided, content will be fetched from the URL). The delimiter (comma or tab) is auto-detected. Pages will be created hierarchically based on parent relationships.'),
          '#required' => TRUE,
          '#upload_location' => 'temporary://content_migration_csv/',
          '#upload_validators' => [
            'FileExtension' => [
              'extensions' => 'csv tsv txt',
            ],
          ],
        ];
      }
      else {
        $form['import_options_wrapper']['csv_file'] = [
          '#type' => 'managed_file',
          '#title' => $this->t('CSV/TSV File'),
          '#description' => $this->t('Upload a CSV or TSV file with required columns: page_title, content_type, parent_page_title. Optional column: source_url (if provided, content will be fetched from the URL). The delimiter (comma or tab) is auto-detected. Pages will be created hierarchically based on parent relationships.'),
          '#required' => TRUE,
          '#upload_location' => 'temporary://content_migration_csv/',
          '#upload_validators' => [
            'file_validate_extensions' => ['csv', 'tsv', 'txt'],
          ],
        ];

      }

      $form['import_options_wrapper']['csv_format_help'] = [
        '#type' => 'details',
        '#title' => $this->t('CSV/TSV Format Help'),
        '#open' => FALSE,
        'example' => [
          '#markup' => $this->t('<p><strong>Format:</strong> Both comma-separated (CSV) and tab-separated (TSV) files are supported. The delimiter is automatically detected.</p>
          <p><strong>CSV Example (without source URLs):</strong></p>
          <pre>page_title,content_type,parent_page_title
"Home Page",page,
"About Us",page,"Home Page"
"Services",page,"Home Page"
"Web Development",page,"Services"
"SEO Services",page,"Services"</pre>
          <p><strong>CSV Example (with source URLs):</strong></p>
          <pre>page_title,content_type,parent_page_title,source_url
"Home Page",page,,https://example.com/
"About Us",page,"Home Page",https://example.com/about
"Services",page,"Home Page",https://example.com/services
"Web Development",page,"Services",https://example.com/services/web-dev
"SEO Services",page,"Services",</pre>
          <p><strong>TSV Example:</strong></p>
          <pre>page_title	content_type	parent_page_title	source_url
Home Page	page		https://example.com/
About Us	page	Home Page	https://example.com/about
Services	page	Home Page	https://example.com/services
Web Development	page	Services	https://example.com/services/web-dev
SEO Services	page	Services	</pre>
          <p><strong>Column Descriptions:</strong></p>
          <ul>
            <li><strong>page_title</strong> (required): The title of the page to create (must be unique)</li>
            <li><strong>content_type</strong> (required): Machine name of the content type (must be configured in settings)</li>
            <li><strong>parent_page_title</strong> (required): The title of the parent page (leave empty for root level)</li>
            <li><strong>source_url</strong> (optional): URL to fetch content from. When provided, only the content (body) will be extracted from this URL and populated into the configured rewritten_content field for the content type. The original_content field will remain empty. If "Create URL redirects" is enabled, a redirect will be created from this URL to the new node.</li>
          </ul>
          <p><strong>Notes:</strong></p>
          <ul>
            <li>Pages are created in hierarchy order with proper menu weighting</li>
            <li>Parent pages must be defined before child pages in the file</li>
            <li>File extensions: .csv, .tsv, or .txt</li>
            <li>Field mapping for rewritten_content must be configured in the module settings for each content type</li>
            <li>If source_url is omitted or empty, an empty page will be created</li>
            <li>URL redirects are only created for rows with source_url specified when "Create URL redirects" is enabled</li>
          </ul>'),
        ],
      ];

      $form['import_options_wrapper']['csv_create_redirects'] = [
        '#type' => 'checkbox',
        '#title' => $this->t('Create URL redirects'),
        '#description' => $this->t('Create redirects from the source URLs to the newly created nodes. Only applies to rows with source_url specified.'),
        '#default_value' => FALSE,
      ];

      $form['import_options_wrapper']['csv_extraction_mode'] = [
        '#type' => 'radios',
        '#title' => $this->t('Content Extraction Mode'),
        '#options' => [
          'article' => $this->t('Article Mode - Extract main article content (recommended for news articles and blog posts)'),
          'full_page' => $this->t('Full Page Mode - Extract all body content (recommended for structured pages with multiple sections)'),
        ],
        '#default_value' => $config->get('default_extraction_mode') ?: 'article',
        '#description' => $this->t('Choose how content should be extracted from source URLs. Article mode uses smart extraction to find the main content, while Full Page mode extracts all content from the page body.'),
      ];

      $form['import_options_wrapper']['csv_content_selector'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Content Selector (Optional)'),
        '#default_value' => $config->get('default_content_selector') ?: '',
        '#description' => $this->t('Specify a CSS selector to extract specific content in Full Page mode. Examples: "main", ".content", ".main-content", "#article". Leave empty to extract all body content.'),
        '#states' => [
          'visible' => [
            ':input[name="csv_extraction_mode"]' => ['value' => 'full_page'],
          ],
        ],
      ];

      $form['import_options_wrapper']['csv_tags_to_remove'] = [
        '#type' => 'textarea',
        '#title' => $this->t('Elements to Remove (Optional)'),
        '#description' => $this->t('Comma-separated list of HTML tags, classes, or IDs to remove during extraction in Full Page mode. Supports tag names (e.g., "nav", "footer"), class selectors (e.g., ".sidebar", ".advertisement"), or ID selectors (e.g., "#header-nav", "#ads"). Default: header, footer, aside, nav, script, style, noscript, iframe. Examples: "nav, .sidebar, footer" or "header, footer, .ads, #main-nav, script, style".'),
        '#default_value' => $config->get('default_tags_to_remove') ?: 'header, footer, aside, nav, script, style, noscript, iframe',
        '#states' => [
          'visible' => [
            ':input[name="csv_extraction_mode"]' => ['value' => 'full_page'],
          ],
        ],
      ];
    }
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $import_type = $form_state->getValue('import_type');

    if ($import_type === 'urls') {
      // Validate URLs.
      $urls = explode("\n", trim($form_state->getValue('url_input') ?: ''));
      $urls = array_map('trim', $urls);
      $urls = array_filter($urls);

      if (empty($urls)) {
        $form_state->setErrorByName('url_input', $this->t('Please enter at least one valid URL.'));
      }

      foreach ($urls as $url) {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
          $form_state->setErrorByName('url_input', $this->t('@url is not a valid URL.', ['@url' => $url]));
        }
      }

      // Validate merge options.
      $merge_urls = $form_state->getValue('merge_urls');
      if ($merge_urls && count($urls) < 2) {
        $form_state->setErrorByName('url_input', $this->t('At least 2 URLs are required for merging content.'));
      }
    }
    elseif ($import_type === 'pdf') {
      // Validate PDF file upload.
      $pdf_file = $form_state->getValue('pdf_file');
      if (empty($pdf_file) || $pdf_file[0] == 0) {
        $form_state->setErrorByName('pdf_file', $this->t('Please upload a PDF file.'));
        return;
      }

      // Validate that the uploaded file is indeed a PDF.
      $file = $this->entityTypeManager->getStorage('file')->load($pdf_file[0]);
      if (!$file) {
        $form_state->setErrorByName('pdf_file', $this->t('Unable to load the uploaded file.'));
        return;
      }

      $mime_type = $file->getMimeType();
      if ($mime_type !== 'application/pdf') {
        $form_state->setErrorByName('pdf_file', $this->t('The uploaded file must be a PDF file.'));
        return;
      }
    }
    elseif ($import_type === 'titles') {
      // Validate titles.
      $titles = explode("\n", trim($form_state->getValue('title_input') ?: ''));
      $titles = array_map('trim', $titles);
      $titles = array_filter($titles);

      if (empty($titles)) {
        $form_state->setErrorByName('title_input', $this->t('Please enter at least one page title.'));
      }

      // Check for empty titles.
      foreach ($titles as $title) {
        if (empty($title)) {
          $form_state->setErrorByName('title_input', $this->t('All titles must be non-empty.'));
          break;
        }
      }
    }
    elseif ($import_type === 'csv') {
      // Validate CSV file upload.
      $csv_file = $form_state->getValue('csv_file');
      if (empty($csv_file) || $csv_file[0] == 0) {
        $form_state->setErrorByName('csv_file', $this->t('Please upload a CSV file.'));
        return;
      }

      // Load and validate CSV content.
      $file = $this->entityTypeManager->getStorage('file')->load($csv_file[0]);
      if (!$file) {
        $form_state->setErrorByName('csv_file', $this->t('Unable to load the uploaded file.'));
        return;
      }

      $csv_data = $this->parseCsvFile($file);
      if ($csv_data === FALSE) {
        $form_state->setErrorByName('csv_file', $this->t('Unable to parse the CSV file.'));
        return;
      }

      if (empty($csv_data)) {
        $form_state->setErrorByName('csv_file', $this->t('The CSV file is empty or has no valid data rows.'));
        return;
      }

      // Validate CSV structure and content.
      $this->validateCsvData($csv_data, $form_state);
    }

    // Validate field_body is selected for URL and PDF imports.
    if ($import_type === 'urls' || $import_type === 'pdf') {
      $field_body_value = $form_state->getValue('field_body');
      if (!$field_body_value) {
        $user_input = $form_state->getUserInput();
        $field_body_value = $user_input['field_body'] ?? '';
      }

      if (empty($field_body_value)) {
        $error_message = $import_type === 'pdf'
          ? $this->t('Please select a field for the extracted PDF content.')
          : $this->t('Please select a field for the extracted body content.');
        $form_state->setErrorByName('field_body', $error_message);
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $import_type = $form_state->getValue('import_type');
    $content_type = $form_state->getValue('content_type');

    // Set up fields array - include body field for URL and PDF imports.
    $fields = [];
    if ($import_type === 'urls' || $import_type === 'pdf') {
      $field_body_value = $form_state->getValue('field_body');
      if (!$field_body_value) {
        $user_input = $form_state->getUserInput();
        $field_body_value = $user_input['field_body'] ?? '';
      }
      $fields['body'] = $field_body_value;
    }

    // Get selected taxonomy terms for the content type.
    $taxonomy_terms = [];
    $selected_taxonomy_terms = $form_state->getValue('taxonomy_terms');
    if ($selected_taxonomy_terms) {
      foreach ($selected_taxonomy_terms as $vocabulary_id => $terms) {
        $filtered_terms = array_filter($terms);
        if (!empty($filtered_terms)) {
          $taxonomy_terms[$vocabulary_id] = array_keys($filtered_terms);
        }
      }
    }

    // Get AI plugin configurations (for URL and PDF imports).
    $ai_plugins = [];
    if ($import_type === 'urls' || $import_type === 'pdf') {
      $ai_plugin_values = $form_state->getValue('ai_plugins') ?? [];
      $audience = $form_state->getValue('audience');

      foreach ($ai_plugin_values as $plugin_id => $plugin_data) {
        if (!empty($plugin_data['enabled'])) {
          $ai_plugins[$plugin_id] = $plugin_data['config'] ?? [];
          $ai_plugins[$plugin_id]['enabled'] = TRUE;
          // Pass the audience selection to all plugins.
          if ($audience) {
            $ai_plugins[$plugin_id]['taxonomy_term'] = $audience;
          }
        }
      }
    }

    $parent_menu_item = $form_state->getValue('parent_menu_item');
    $create_redirects = $form_state->getValue('create_redirects');

    if ($import_type === 'urls') {
      $urls = explode("\n", trim($form_state->getValue('url_input')));
      $urls = array_map('trim', $urls);
      $urls = array_filter($urls);
      $merge_urls = $form_state->getValue('merge_urls');
      $extraction_mode = $form_state->getValue('url_extraction_mode') ?? 'article';
      $content_selector = $form_state->getValue('url_content_selector') ?? NULL;

      // Parse tags to remove from comma-separated string to array.
      $tags_to_remove = NULL;
      $tags_input = $form_state->getValue('url_tags_to_remove');
      if (!empty($tags_input)) {
        $tags_to_remove = array_map('trim', explode(',', $tags_input));
        $tags_to_remove = array_filter($tags_to_remove);
      }

      $batch = [
        'title' => $this->t('Importing content from URLs'),
        'operations' => [],
        'finished' => '\Drupal\content_migration\Form\ContentImportForm::batchFinished',
        'init_message' => $this->t('Starting content import...'),
        'progress_message' => $this->t('Processed @current out of @total.'),
        'error_message' => $this->t('Content import has encountered an error.'),
      ];

      if ($merge_urls) {
        // Single batch operation for merged content.
        $merge_options = [
          'merged_title' => $form_state->getValue('merged_title'),
          'include_source_headers' => $form_state->getValue('include_source_headers'),
          'content_separator' => $form_state->getValue('content_separator'),
        ];

        $batch['operations'][] = [
          '\Drupal\content_migration\Form\ContentImportForm::processMergedUrlsBatch',
          [
            $urls, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, $merge_options, $taxonomy_terms, $extraction_mode, $content_selector, $tags_to_remove,
          ],
        ];
      }
      else {
        // Individual batch operations for each URL.
        foreach ($urls as $index => $url) {
          $batch['operations'][] = [
            '\Drupal\content_migration\Form\ContentImportForm::processUrlBatch',
            [$url, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, $taxonomy_terms, $extraction_mode, $content_selector, $tags_to_remove],
          ];
        }
      }
    }
    elseif ($import_type === 'pdf') {
      // Handle PDF content extraction.
      $pdf_file = File::load($form_state->getValue('pdf_file')[0]);

      $batch = [
        'title' => $this->t('Extracting content from PDF'),
        'operations' => [],
        'finished' => '\Drupal\content_migration\Form\ContentImportForm::batchFinished',
        'init_message' => $this->t('Starting PDF content extraction...'),
        'progress_message' => $this->t('Processing PDF...'),
        'error_message' => $this->t('PDF content extraction has encountered an error.'),
      ];

      // Single batch operation for PDF processing.
      $batch['operations'][] = [
        '\Drupal\content_migration\Form\ContentImportForm::processPdfBatch',
        [$pdf_file, $content_type, $fields, $ai_plugins, $parent_menu_item, $taxonomy_terms],
      ];
    }
    elseif ($import_type === 'titles') {
      // Handle title-based page creation.
      $titles = explode("\n", trim($form_state->getValue('title_input')));
      $titles = array_map('trim', $titles);
      $titles = array_filter($titles);

      $batch = [
        'title' => $this->t('Creating pages from titles'),
        'operations' => [],
        'finished' => '\Drupal\content_migration\Form\ContentImportForm::batchFinished',
        'init_message' => $this->t('Starting page creation...'),
        'progress_message' => $this->t('Processed @current out of @total.'),
        'error_message' => $this->t('Page creation has encountered an error.'),
      ];

      // Individual batch operations for each title.
      foreach ($titles as $index => $title) {
        $batch['operations'][] = [
          '\Drupal\content_migration\Form\ContentImportForm::processTitleBatch',
          [$title, $content_type, $fields, $ai_plugins, $parent_menu_item, $taxonomy_terms],
        ];
      }
    }
    elseif ($import_type === 'csv') {
      // Handle CSV-based page creation.
      $csv_file = File::load($form_state->getValue('csv_file')[0]);
      $csv_data = $this->parseCsvFile($csv_file);
      $csv_create_redirects = $form_state->getValue('csv_create_redirects') ?? FALSE;
      $csv_extraction_mode = $form_state->getValue('csv_extraction_mode') ?? 'article';
      $csv_content_selector = $form_state->getValue('csv_content_selector') ?? NULL;

      // Parse tags to remove from comma-separated string to array.
      $csv_tags_to_remove = NULL;
      $csv_tags_input = $form_state->getValue('csv_tags_to_remove');
      if (!empty($csv_tags_input)) {
        $csv_tags_to_remove = array_map('trim', explode(',', $csv_tags_input));
        $csv_tags_to_remove = array_filter($csv_tags_to_remove);
      }

      // Get field mappings for all content types that might be in the CSV.
      $config = $this->config('content_migration.settings');
      $all_field_mappings = $config->get('content_type_field_mappings') ?? [];

      $batch = [
        'title' => $this->t('Creating pages from CSV'),
        'operations' => [],
        'finished' => '\Drupal\content_migration\Form\ContentImportForm::batchFinished',
        'init_message' => $this->t('Starting CSV page creation...'),
        'progress_message' => $this->t('Processed @current out of @total.'),
        'error_message' => $this->t('CSV page creation has encountered an error.'),
      ];

      // Single batch operation to process the entire CSV hierarchically.
      $batch['operations'][] = [
        '\Drupal\content_migration\Form\ContentImportForm::processCsvBatch',
        [$csv_data, NULL, $taxonomy_terms, $all_field_mappings, $csv_create_redirects, $csv_extraction_mode, $csv_content_selector, $csv_tags_to_remove],
      ];
    }

    batch_set($batch);
  }

  /**
   * Batch operation to process a URL.
   */
  public static function processUrlBatch($url, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, $taxonomy_terms, $extraction_mode, $content_selector, $tags_to_remove, &$context): void {
    $controller = \Drupal::service('content_migration.content_import_controller');
    try {
      $controller->processUrl($url, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, $taxonomy_terms, $extraction_mode, $content_selector, $tags_to_remove);
      $context['results'][] = $url;
      $context['message'] = t('Imported content from @url', ['@url' => $url]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = t('Error importing from @url: @error', [
        '@url' => $url,
        '@error' => $e->getMessage(),
      ]);
    }
  }

  /**
   * Batch operation to process multiple URLs as merged content.
   */
  public static function processMergedUrlsBatch($urls, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, $merge_options, $taxonomy_terms, $extraction_mode, $content_selector, $tags_to_remove, &$context): void {
    $controller = \Drupal::service('content_migration.content_import_controller');
    try {
      $controller->processMergedUrls($urls, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, $merge_options, $taxonomy_terms, $extraction_mode, $content_selector, $tags_to_remove);
      $context['results'][] = t('Merged content from @count URLs', ['@count' => count($urls)]);
      $context['message'] = t('Imported merged content from @count URLs', ['@count' => count($urls)]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = t('Error importing merged content: @error', [
        '@error' => $e->getMessage(),
      ]);
    }
  }

  /**
   * Batch operation to process a title and create an empty page.
   */
  public static function processTitleBatch($title, $content_type, $fields, $ai_plugins, $parent_menu_item, $taxonomy_terms, &$context): void {
    $controller = \Drupal::service('content_migration.content_import_controller');
    try {
      $controller->processTitle($title, $content_type, $fields, $ai_plugins, $parent_menu_item, $taxonomy_terms);
      $context['results'][] = $title;
      $context['message'] = t('Created page with title "@title"', ['@title' => $title]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = t('Error creating page "@title": @error', [
        '@title' => $title,
        '@error' => $e->getMessage(),
      ]);
    }
  }

  /**
   * Batch operation to process a PDF file and extract content.
   */
  public static function processPdfBatch($pdf_file, $content_type, $fields, $ai_plugins, $parent_menu_item, $taxonomy_terms, &$context): void {
    $controller = \Drupal::service('content_migration.content_import_controller');
    try {
      $controller->processPdf($pdf_file, $content_type, $fields, $ai_plugins, $parent_menu_item, $taxonomy_terms);
      $context['results'][] = $pdf_file->getFilename();
      $context['message'] = t('Extracted content from PDF "@filename"', ['@filename' => $pdf_file->getFilename()]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = t('Error extracting content from PDF "@filename": @error', [
        '@filename' => $pdf_file->getFilename(),
        '@error' => $e->getMessage(),
      ]);
    }
  }

  /**
   * Batch operation to process CSV data and create hierarchical pages.
   */
  public static function processCsvBatch($csv_data, $parent_menu_item, $taxonomy_terms, $field_mappings, $create_redirects, $extraction_mode, $content_selector, $tags_to_remove, &$context): void {
    $controller = \Drupal::service('content_migration.content_import_controller');
    try {
      $controller->processCsv($csv_data, $parent_menu_item, $taxonomy_terms, $field_mappings, $create_redirects, $extraction_mode, $content_selector, $tags_to_remove);
      $context['results'][] = t('Created @count pages from CSV', ['@count' => count($csv_data)]);
      $context['message'] = t('Created hierarchical pages from CSV with @count entries', ['@count' => count($csv_data)]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = t('Error creating pages from CSV: @error', [
        '@error' => $e->getMessage(),
      ]);
    }
  }

  /**
   * Batch finished callback.
   */
  public static function batchFinished($success, $results, $operations): void {
    $messenger = \Drupal::messenger();
    $is_csv_import = FALSE;

    if ($success) {
      // Check if this is a CSV/merged/PDF import by looking at the first result.
      $has_custom_message = FALSE;
      if (!empty($results) && !isset($results['errors'])) {
        $first_result = reset($results);
        // CSV and merged imports return TranslatableMarkup objects with custom messages.
        if (is_object($first_result) && method_exists($first_result, '__toString')) {
          $messenger->addStatus($first_result);
          $has_custom_message = TRUE;

          // Check if this is a CSV import by looking at the message content.
          $message_string = (string) $first_result;
          if (stripos($message_string, 'CSV') !== FALSE) {
            $is_csv_import = TRUE;
          }
        }
      }

      // Use generic URL message for standard URL/title imports.
      if (!$has_custom_message) {
        $count = count($results) - (isset($results['errors']) ? 1 : 0);
        if ($count > 0) {
          $messenger->addStatus(\Drupal::translation()->formatPlural(
            $count,
            'Successfully imported content from 1 item.',
            'Successfully imported content from @count items.'
          ));
        }
      }

      if (isset($results['errors'])) {
        foreach ($results['errors'] as $error) {
          $messenger->addError($error);
        }
      }

      // Redirect to content view after successful CSV import.
      if ($is_csv_import && empty($results['errors'])) {
        $url = \Drupal\Core\Url::fromRoute('system.admin_content')->toString();
        $response = new \Symfony\Component\HttpFoundation\RedirectResponse($url);
        $response->send();
      }
    }
    else {
      $messenger->addError(t('An error occurred while importing content.'));
    }
  }

  /**
   * Parse CSV/TSV file and return data array.
   *
   * @param \Drupal\file\Entity\File $file
   *   The uploaded CSV/TSV file.
   *
   * @return array|false
   *   Array of CSV data or FALSE on error.
   */
  protected function parseCsvFile($file): array|false {
    $file_path = $file->getFileUri();
    $real_path = $this->fileSystem->realpath($file_path);

    if (!$real_path || !file_exists($real_path)) {
      return FALSE;
    }

    // Auto-detect delimiter.
    $delimiter = $this->detectDelimiter($real_path);

    $csv_data = [];
    $header = NULL;

    if (($handle = fopen($real_path, 'r')) !== FALSE) {
      while (($row = fgetcsv($handle, 0, $delimiter)) !== FALSE) {
        if ($header === NULL) {
          // First row is header - trim and normalize.
          $header = array_map(function($value) {
            // Remove BOM if present.
            $value = trim($value);
            $value = str_replace("\xEF\xBB\xBF", '', $value);
            // Remove any non-printable characters.
            $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value);
            return trim($value);
          }, $row);
          continue;
        }

        // Skip empty rows.
        if (empty(array_filter($row))) {
          continue;
        }

        // Trim row data.
        $row_data = array_map('trim', $row);

        // Ensure row has same number of columns as header.
        if (count($row_data) < count($header)) {
          // Pad with empty strings if row has fewer columns.
          $row_data = array_pad($row_data, count($header), '');
        }
        elseif (count($row_data) > count($header)) {
          // Truncate if row has more columns.
          $row_data = array_slice($row_data, 0, count($header));
        }

        // Combine header with row data.
        $csv_data[] = array_combine($header, $row_data);
      }
      fclose($handle);
    }
    else {
      return FALSE;
    }

    return $csv_data;
  }

  /**
   * Auto-detect CSV delimiter by analyzing the first few lines.
   *
   * @param string $file_path
   *   The path to the CSV file.
   *
   * @return string
   *   The detected delimiter (comma or tab).
   */
  protected function detectDelimiter($file_path): string {
    if (($handle = fopen($file_path, 'r')) !== FALSE) {
      $sample_lines = [];
      $line_count = 0;

      // Read first 5 lines for delimiter detection.
      while (($line = fgets($handle)) !== FALSE && $line_count < 5) {
        $sample_lines[] = $line;
        $line_count++;
      }
      fclose($handle);

      if (empty($sample_lines)) {
        // Default to comma.
        return ',';
      }

      // Count occurrences of potential delimiters.
      $comma_count = 0;
      $tab_count = 0;

      foreach ($sample_lines as $line) {
        $comma_count += substr_count($line, ',');
        $tab_count += substr_count($line, "\t");
      }

      // Return the delimiter with more occurrences
      // If equal or no delimiters found, default to comma.
      return ($tab_count > $comma_count) ? "\t" : ',';
    }

    // Default to comma if file can't be read.
    return ',';
  }

  /**
   * Validate CSV data structure and content.
   *
   * @param array $csv_data
   *   The parsed CSV data.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  protected function validateCsvData(array $csv_data, FormStateInterface $form_state): void {
    // Check if CSV has any data.
    if (empty($csv_data)) {
      $form_state->setErrorByName('csv_file', $this->t('CSV file is empty or has no data rows.'));
      return;
    }

    // Check required columns.
    $required_columns = ['page_title', 'content_type', 'parent_page_title'];
    $first_row = reset($csv_data);
    $columns = array_keys($first_row);

    foreach ($required_columns as $required_column) {
      if (!in_array($required_column, $columns)) {
        $form_state->setErrorByName('csv_file', $this->t('CSV file is missing required column: @column. Found columns: @found', [
          '@column' => $required_column,
          '@found' => implode(', ', array_map(function($col) { return '"' . $col . '"'; }, $columns)),
        ]));
        return;
      }
    }

    // Get configured content types for validation.
    $config = $this->config('content_migration.settings');
    $allowed_content_types = $config->get('allowed_content_types') ?: [];

    // Validate each row.
    $page_titles = [];
    // Start at 1 since we skip header.
    $row_number = 1;

    foreach ($csv_data as $row) {
      $row_number++;

      // Validate page_title.
      $page_title = trim($row['page_title']);
      if (empty($page_title)) {
        $form_state->setErrorByName('csv_file', $this->t('Row @row: page_title cannot be empty.', ['@row' => $row_number]));
        continue;
      }

      // Check for duplicate page_titles.
      if (in_array($page_title, $page_titles)) {
        $form_state->setErrorByName('csv_file', $this->t('Row @row: Duplicate page_title "@title" found.', ['@row' => $row_number, '@title' => $page_title]));
        continue;
      }
      $page_titles[] = $page_title;

      // Validate content_type.
      if (empty($row['content_type'])) {
        $form_state->setErrorByName('csv_file', $this->t('Row @row: content_type cannot be empty.', ['@row' => $row_number]));
        continue;
      }

      if (!in_array($row['content_type'], $allowed_content_types)) {
        $form_state->setErrorByName('csv_file', $this->t('Row @row: content_type "@type" is not configured in settings.', ['@row' => $row_number, '@type' => $row['content_type']]));
        continue;
      }

      // Validate parent_page_title (can be empty for root level)
      $parent_page_title = trim($row['parent_page_title']);
      // If parent_page_title is not empty, validate it exists in previous rows.
      if (!empty($parent_page_title)) {
        if (!in_array($parent_page_title, $page_titles)) {
          $form_state->setErrorByName('csv_file', $this->t('Row @row: parent_page_title "@parent" not found. Parent pages must be defined before child pages in the CSV.', ['@row' => $row_number, '@parent' => $parent_page_title]));
          continue;
        }
      }
    }
  }

  /**
   * Apply default field mappings to plugin configuration.
   *
   * @param string $plugin_id
   *   The plugin ID.
   * @param string $content_type
   *   The content type ID.
   * @param array $plugin_config
   *   The current plugin configuration.
   * @param \Drupal\Core\Config\Config $config
   *   The module configuration.
   *
   * @return array
   *   Updated plugin configuration with default field mappings.
   */
  protected function applyDefaultFieldMappings(string $plugin_id, string $content_type, array $plugin_config, $config): array {
    $default_mappings = $config->get('content_type_field_mappings')[$content_type] ?? [];

    // Apply defaults for fields that are not set or are empty.
    switch ($plugin_id) {
      case 'rewrite_content':
        if (isset($default_mappings['rewritten_content']) && empty($plugin_config['rewrite_field'])) {
          $plugin_config['rewrite_field'] = $default_mappings['rewritten_content'];
        }
        if (isset($default_mappings['changes_summary']) && empty($plugin_config['changes_field'])) {
          $plugin_config['changes_field'] = $default_mappings['changes_summary'];
        }
        if (isset($default_mappings['intermediate_summary']) && empty($plugin_config['summary_field'])) {
          $plugin_config['summary_field'] = $default_mappings['intermediate_summary'];
        }
        break;

      case 'introduction_content':
        if (isset($default_mappings['introduction_content']) && empty($plugin_config['target_field'])) {
          $plugin_config['target_field'] = $default_mappings['introduction_content'];
        }
        break;

      case 'summary_content':
        if (isset($default_mappings['summary_content']) && empty($plugin_config['target_field'])) {
          $plugin_config['target_field'] = $default_mappings['summary_content'];
        }
        break;
    }

    return $plugin_config;
  }

}
