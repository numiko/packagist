<?php

namespace Drupal\content_migration\Plugin;

use Drupal\node\NodeInterface;

/**
 * Interface for quality analysis plugins.
 */
interface QualityAnalysisInterface {

  /**
   * Gets the plugin label.
   *
   * @return string
   *   The plugin label.
   */
  public function getLabel(): string;

  /**
   * Gets the plugin description.
   *
   * @return string
   *   The plugin description.
   */
  public function getDescription(): string;

  /**
   * Gets the plugin weight for ordering.
   *
   * @return int
   *   The weight (lower numbers run first).
   */
  public function getWeight(): int;

  /**
   * Analyzes content quality.
   *
   * @param string $content
   *   The content to analyze.
   * @param \Drupal\node\NodeInterface $node
   *   The node being analyzed.
   * @param array $context
   *   Additional context (e.g., audience_term_id, style_guide, etc.).
   *
   * @return array
   *   Analysis results with structure:
   *   - overall_score: Overall quality score (optional)
   *   - scores: Array of scores by area ['area_name' => ['score' => '8/10', 'comments' => '...']]
   *   - summary: Detailed analysis summary (optional)
   *   - raw_response: Raw response from analysis (optional)
   */
  public function analyze(string $content, NodeInterface $node, array $context = []): array;

  /**
   * Checks if this plugin is available for the given context.
   *
   * @param array $context
   *   The context array.
   *
   * @return bool
   *   TRUE if available, FALSE otherwise.
   */
  public function isAvailable(array $context = []): bool;

}
