<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\QualityAnalysis;

use Drupal\content_migration\Attribute\QualityAnalysis;
use Drupal\content_migration\Plugin\QualityAnalysisPluginBase;
use Drupal\content_migration\Service\TaxonomyPromptService;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\node\NodeInterface;
use GuzzleHttp\ClientInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Analyzes content quality against the configured style guide.
 */
#[QualityAnalysis(
  id: 'style_guide',
  label: new TranslatableMarkup('Style Guide Analysis'),
  description: new TranslatableMarkup('Analyzes content quality against the configured style guide and audience requirements.'),
  weight: 0
)]
class StyleGuideAnalysis extends QualityAnalysisPluginBase {

  /**
   * The taxonomy prompt service.
   *
   * @var \Drupal\content_migration\Service\TaxonomyPromptService
   */
  protected TaxonomyPromptService $taxonomyPromptService;

  /**
   * {@inheritdoc}
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    ClientInterface $http_client,
    ConfigFactoryInterface $config_factory,
    LoggerChannelFactoryInterface $logger_factory,
    TaxonomyPromptService $taxonomy_prompt_service
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $http_client, $config_factory, $logger_factory);
    $this->taxonomyPromptService = $taxonomy_prompt_service;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('http_client'),
      $container->get('config.factory'),
      $container->get('logger.factory'),
      $container->get(TaxonomyPromptService::class)
    );
  }

  /**
   * {@inheritdoc}
   */
  public function isAvailable(array $context = []): bool {
    $this->logger->info('StyleGuideAnalysis: Checking if plugin is available...');

    $config = $this->configFactory->get('content_migration.settings');
    $audience_vocabulary_id = $config->get('audience_vocabulary');

    $this->logger->info('StyleGuideAnalysis: Audience vocabulary ID from config: @vocab_id', [
      '@vocab_id' => $audience_vocabulary_id ?? 'NULL',
    ]);

    if (empty($audience_vocabulary_id)) {
      $this->logger->info('StyleGuideAnalysis: No audience vocabulary configured. Plugin is NOT AVAILABLE.');
      return FALSE;
    }

    $this->logger->info('StyleGuideAnalysis: Checking for root term in vocabulary "@vocab_id"...', [
      '@vocab_id' => $audience_vocabulary_id,
    ]);

    $root_term = $this->taxonomyPromptService->getRootTerm($audience_vocabulary_id);

    $this->logger->info('StyleGuideAnalysis: Root term data: @data', [
      '@data' => !empty($root_term) ? json_encode($root_term) : 'NULL',
    ]);

    $has_prompt = !empty($root_term) && !empty($root_term['prompt']);

    if ($has_prompt) {
      $this->logger->info('StyleGuideAnalysis: Root term has a style guide prompt. Plugin IS AVAILABLE.');
    }
    else {
      $this->logger->info('StyleGuideAnalysis: Root term is missing or has no prompt. Plugin is NOT AVAILABLE.');
    }

    return $has_prompt;
  }

  /**
   * {@inheritdoc}
   */
  public function analyze(string $content, NodeInterface $node, array $context = []): array {
    $config = $this->configFactory->get('content_migration.settings');

    // Get the audience vocabulary.
    $audience_vocabulary_id = $config->get('audience_vocabulary');

    if (empty($audience_vocabulary_id)) {
      throw new \Exception('No audience vocabulary is configured.');
    }

    // Get the style guide from the root term of the audience vocabulary.
    $root_term = $this->taxonomyPromptService->getRootTerm($audience_vocabulary_id);

    if (empty($root_term) || empty($root_term['prompt'])) {
      throw new \Exception('No style guide is configured in the audience vocabulary root term.');
    }

    // Use analysis_prompt field if available, otherwise fall back to prompt.
    $style_guide = $root_term['analysis_prompt'] ?? $root_term['prompt'];

    $this->logger->info('StyleGuideAnalysis: Using style guide from @source', [
      '@source' => isset($root_term['analysis_prompt']) ? 'analysis_prompt field' : 'description field',
    ]);

    $audience_prompt = '';
    $audience_term_id = $context['audience_term_id'] ?? NULL;

    // If an audience is specified, get its specific prompt.
    if ($audience_term_id) {
      $hierarchical_prompts = $this->taxonomyPromptService->getHierarchicalPrompt($audience_term_id);
      $audience_prompt = $hierarchical_prompts['audience_prompt'] ?? '';
    }

    // Extract key areas from the style guide.
    $key_areas = $this->extractKeyAreasFromStyleGuide($style_guide);

    // Build the quality assessment prompt.
    $prompt = $this->buildQualityAssessmentPrompt($content, $style_guide, $audience_prompt, $key_areas);

    $this->logger->info('StyleGuideAnalysis: Assessing quality for node @nid with audience @audience, Key areas: @areas', [
      '@nid' => $node->id(),
      '@audience' => $audience_term_id ? (string) $audience_term_id : 'none',
      '@areas' => implode(', ', $key_areas),
    ]);

    // Make the API call.
    $response = $this->makeClaudeRequest($prompt);

    // Log the raw response for debugging.
    $this->logger->info('StyleGuideAnalysis: Raw AI response for node @nid:<br/><pre>@response</pre>', [
      '@nid' => $node->id(),
      '@response' => $response,
    ]);

    // Parse the response.
    $results = $this->parseQualityResponse($response);

    // Log the parsed results.
    $this->logger->info('StyleGuideAnalysis: Parsed results for node @nid - Overall: @overall, Scores count: @scores_count, Summary length: @summary_length', [
      '@nid' => $node->id(),
      '@overall' => $results['overall_score'] ?? 'none',
      '@scores_count' => count($results['scores'] ?? []),
      '@summary_length' => strlen($results['summary'] ?? ''),
    ]);

    // Include the raw response for debugging.
    $results['raw_response'] = $response;

    return $results;
  }

  /**
   * Extracts key areas from the style guide.
   *
   * Only extracts numbered items under the "Style Guide Requirements" section.
   *
   * @param string $style_guide
   *   The style guide text.
   *
   * @return array
   *   Array of key area names.
   */
  protected function extractKeyAreasFromStyleGuide(string $style_guide): array {
    $areas = [];
    $lines = explode("\n", $style_guide);
    $in_requirements_section = FALSE;

    foreach ($lines as $line) {
      $line = trim($line);

      if (empty($line)) {
        continue;
      }

      // Check if we've entered the "Style Guide Requirements" section.
      if (preg_match('/^#+\s*Style Guide Requirements/i', $line)) {
        $in_requirements_section = TRUE;
        continue;
      }

      // Check if we've entered a different major section at same or higher level (exit requirements).
      // A heading at the same level (##) as "Style Guide Requirements" means we've left that section.
      if ($in_requirements_section && preg_match('/^##\s+(?!#)/', $line)) {
        // This is a level-2 heading, which means we've left the requirements section.
        $in_requirements_section = FALSE;
        continue;
      }

      // Only match numbered sections when inside the requirements section.
      // Handle both plain numbered lines and numbered markdown headings.
      if ($in_requirements_section) {
        // Match markdown headings with numbers: ### 1. General Rule
        if (preg_match('/^#{3,}\s*\d+[\.\)]\s+(.+)$/', $line, $matches)) {
          $text = trim($matches[1]);
          // Remove trailing colons and asterisks.
          $text = rtrim($text, ':*');
          // Remove bold markdown if present.
          $text = preg_replace('/^\*\*(.+?)\*\*$/', '$1', $text);
          if (!empty($text) && strlen($text) < 100) {
            $areas[] = $text;
          }
          continue;
        }

        // Also match plain numbered lines: 1. General Rule
        if (preg_match('/^\d+[\.\)]\s+(.+)$/', $line, $matches)) {
          $text = trim($matches[1]);
          // Remove trailing colons and asterisks.
          $text = rtrim($text, ':*');
          // Remove bold markdown if present.
          $text = preg_replace('/^\*\*(.+?)\*\*$/', '$1', $text);
          if (!empty($text) && strlen($text) < 100) {
            $areas[] = $text;
          }
        }
      }
    }

    $areas = array_unique($areas);

    if (empty($areas)) {
      $areas = [
        'Content Structure',
        'Writing Style',
        'Clarity and Readability',
        'Accuracy',
        'Tone and Voice',
      ];
    }

    return array_values($areas);
  }

  /**
   * Builds the quality assessment prompt.
   *
   * @param string $content
   *   The content to assess.
   * @param string $style_guide
   *   The style guide.
   * @param string $audience_prompt
   *   Optional audience prompt.
   * @param array $key_areas
   *   Array of key area names.
   *
   * @return string
   *   The complete prompt.
   */
  protected function buildQualityAssessmentPrompt(string $content, string $style_guide, string $audience_prompt = '', array $key_areas = []): string {
    $audience_section = '';
    if (!empty($audience_prompt)) {
      $audience_section = "\n\n**TARGET AUDIENCE REQUIREMENTS:**\n{$audience_prompt}\n\nPlease also assess how well the content is tailored for this specific audience.";
    }

    $area_list = '';
    if (!empty($key_areas)) {
      $area_list = "\n\n**KEY AREAS TO ASSESS (use these EXACT names in your SCORES section):**\n";
      foreach ($key_areas as $area) {
        $area_list .= "- {$area}\n";
      }
      $area_list .= "\nIMPORTANT: Use these exact area names in your SCORES section. Do not rephrase or modify them.";
    }

    return <<<EOT
I need you to assess the quality of the following content against our style guide. Please provide a comprehensive quality assessment.

**STYLE GUIDE:**
{$style_guide}{$audience_section}{$area_list}

**CONTENT TO ASSESS:**
{$content}

**ASSESSMENT INSTRUCTIONS:**

Please analyze the content and provide:

1. An overall quality score (e.g., "8/10" or "75%")
2. Individual scores for each key area mentioned in the style guide
3. A detailed summary of your assessment

**CRITICAL OUTPUT FORMAT:**

You must structure your response EXACTLY as follows, using the EXACT area names provided above.

DO NOT include any instructional text, placeholders, or examples like "[Your score here]" or "N/A" in your response. Only include actual assessment results.

OVERALL_SCORE: (provide actual numeric score only, e.g., "8/10" or "75%")

SCORES:
(List each area with actual score and specific comment - do not include placeholders or "N/A")
Area Name 1: 8/10 - Specific observation about this area
Area Name 2: 75% - Specific observation about this area
(Continue for ALL key areas listed above using EXACT names)

SUMMARY:
(Provide detailed analysis with specific examples. Format with HTML: <p>, <strong>, <ul>, <li>)

**CRITICAL REQUIREMENTS:**
- DO NOT include placeholder text like "[Your assessment here]" or "[Score]" in your output
- DO NOT include "N/A" or "Not Applicable" entries - only assess areas where you can provide meaningful feedback
- Use EXACT area names from the "KEY AREAS TO ASSESS" section - do not paraphrase
- Provide actual numeric scores (e.g., "8/10", "85%", "4/5")
- Include specific, actionable feedback based on the content
- Format SUMMARY section with HTML tags for readability

Please provide your assessment now with actual results only:
EOT;
  }

  /**
   * Parses the quality assessment response.
   *
   * @param string $response
   *   The API response.
   *
   * @return array
   *   Parsed results.
   */
  protected function parseQualityResponse(string $response): array {
    $results = [
      'overall_score' => '',
      'scores' => [],
      'summary' => '',
    ];

    // Extract overall score.
    if (preg_match('/OVERALL_SCORE:\s*(.+?)(?:\n|$)/i', $response, $matches)) {
      $score = trim($matches[1]);
      // Filter out placeholder text.
      if (!$this->isPlaceholderText($score)) {
        $results['overall_score'] = $score;
      }
    }

    // Extract individual scores.
    if (preg_match('/SCORES:\s*(.+?)(?=SUMMARY:|$)/is', $response, $matches)) {
      $scores_section = trim($matches[1]);
      $lines = explode("\n", $scores_section);

      foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) {
          continue;
        }

        // Skip instructional lines.
        if ($this->isInstructionalLine($line)) {
          continue;
        }

        // Parse format: "Area Name: Score - Comment"
        if (preg_match('/^(.+?):\s*([^-]+)(?:\s*-\s*(.+))?$/i', $line, $line_matches)) {
          $area = trim($line_matches[1]);
          $score = trim($line_matches[2]);
          $comment = isset($line_matches[3]) ? trim($line_matches[3]) : '';

          // Skip if area name or score looks like a placeholder.
          if ($this->isPlaceholderText($area) || $this->isPlaceholderText($score)) {
            continue;
          }

          // Skip if marked as N/A or Not Applicable.
          if ($this->isNotApplicable($score) || $this->isNotApplicable($comment)) {
            continue;
          }

          $results['scores'][$area] = [
            'score' => $score,
            'comments' => $comment,
          ];
        }
      }
    }

    // Extract summary.
    if (preg_match('/SUMMARY:\s*(.+)$/is', $response, $matches)) {
      $summary = trim($matches[1]);
      // Clean up any instructional text from summary.
      $summary = $this->cleanInstructionalText($summary);
      $results['summary'] = $summary;
    }

    // Fallback: if parsing failed, use the entire response as summary.
    if (empty($results['overall_score']) && empty($results['scores']) && empty($results['summary'])) {
      $results['summary'] = $response;
    }

    return $results;
  }

  /**
   * Checks if text is a placeholder or example.
   *
   * @param string $text
   *   The text to check.
   *
   * @return bool
   *   TRUE if text appears to be a placeholder.
   */
  protected function isPlaceholderText(string $text): bool {
    $text_lower = strtolower($text);

    // Check for bracketed placeholders.
    if (preg_match('/\[.*?\]/', $text)) {
      return TRUE;
    }

    // Check for common placeholder phrases.
    $placeholders = [
      'your score',
      'your assessment',
      'your analysis',
      'score here',
      'comment here',
      'provide',
      'list each',
      'continue for',
      'exact area name',
      'area name 1',
      'area name 2',
    ];

    foreach ($placeholders as $placeholder) {
      if (str_contains($text_lower, $placeholder)) {
        return TRUE;
      }
    }

    return FALSE;
  }

  /**
   * Checks if text indicates not applicable.
   *
   * @param string $text
   *   The text to check.
   *
   * @return bool
   *   TRUE if text indicates N/A or not applicable.
   */
  protected function isNotApplicable(string $text): bool {
    $text_lower = trim(strtolower($text));

    $na_patterns = [
      'n/a',
      'n.a.',
      'not applicable',
      'not relevant',
      'does not apply',
      'cannot assess',
    ];

    foreach ($na_patterns as $pattern) {
      if ($text_lower === $pattern || str_starts_with($text_lower, $pattern)) {
        return TRUE;
      }
    }

    return FALSE;
  }

  /**
   * Checks if a line is instructional rather than actual content.
   *
   * @param string $line
   *   The line to check.
   *
   * @return bool
   *   TRUE if line appears to be instructional.
   */
  protected function isInstructionalLine(string $line): bool {
    $line_lower = strtolower($line);

    // Lines that start with parentheses are usually instructions.
    if (preg_match('/^\(.*\)$/', trim($line))) {
      return TRUE;
    }

    // Common instructional phrases.
    $instructional_phrases = [
      'list each area',
      'continue for',
      'do not include',
      'provide actual',
      'format with',
    ];

    foreach ($instructional_phrases as $phrase) {
      if (str_contains($line_lower, $phrase)) {
        return TRUE;
      }
    }

    return FALSE;
  }

  /**
   * Cleans instructional text from summary content.
   *
   * @param string $text
   *   The text to clean.
   *
   * @return string
   *   Cleaned text.
   */
  protected function cleanInstructionalText(string $text): string {
    // Remove lines that are entirely in parentheses (instructions).
    $lines = explode("\n", $text);
    $cleaned_lines = [];

    foreach ($lines as $line) {
      $trimmed = trim($line);

      // Skip empty lines.
      if (empty($trimmed)) {
        $cleaned_lines[] = $line;
        continue;
      }

      // Skip lines that are instructions in parentheses.
      if (preg_match('/^\(.*\)$/', $trimmed)) {
        continue;
      }

      $cleaned_lines[] = $line;
    }

    return implode("\n", $cleaned_lines);
  }

}
