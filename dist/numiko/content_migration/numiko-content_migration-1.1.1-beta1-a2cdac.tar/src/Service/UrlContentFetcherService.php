<?php

namespace Drupal\content_migration\Service;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use fivefilters\Readability\Configuration;
use fivefilters\Readability\ParseException;
use fivefilters\Readability\Readability;

/**
 * Service for fetching content from URLs.
 */
class UrlContentFetcherService {

  /**
   * Constructs a UrlContentFetcherService object.
   *
   * @param \GuzzleHttp\ClientInterface $httpClient
   *   The HTTP client.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    protected readonly ClientInterface $httpClient,
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * Fetches content from a URL.
   *
   * @param string $url
   *   The URL to fetch content from.
   *
   * @return string
   *   The HTML content from the URL.
   *
   * @throws \Exception
   *   Throws an exception if the content cannot be fetched.
   */
  public function fetchContent($url) {
    try {
      $response = $this->httpClient->request('GET', $url, [
        'headers' => [
          'User-Agent' => 'Mozilla/5.0 (compatible; Drupal/10.0; +http://drupal.org/)',
        ],
        'timeout' => 600,
      ]);

      $content_type = $response->getHeaderLine('Content-Type');
      if (strpos($content_type, 'text/html') === FALSE && strpos($content_type, 'application/xhtml+xml') === FALSE) {
        throw new \Exception("URL does not return HTML content: {$content_type}");
      }

      $body = (string) $response->getBody();
      if (empty($body)) {
        throw new \Exception('Empty response received from URL.');
      }

      return $body;
    }
    catch (RequestException $e) {
      $this->logger->error(
        'Error fetching URL @url: @error',
        ['@url' => (string) $url, '@error' => (string) $e->getMessage()]
      );
      throw new \Exception("Failed to fetch content from URL: " . $e->getMessage());
    }
  }

  /**
   * Sanitizes and extracts the main content from HTML.
   *
   * @param string $html
   *   The raw HTML content.
   * @param string $mode
   *   The extraction mode: 'article' (default) or 'full_page'.
   *   - 'article': Uses Readability to extract main article content.
   *   - 'full_page': Extracts all body content, removing only scripts/styles.
   * @param string|null $selector
   *   Optional CSS selector to extract specific content (only used in full_page mode).
   *   Supports tag names (e.g., 'main', 'article') or class selectors (e.g., '.content', '.main-content').
   * @param array|null $tags_to_remove
   *   Optional array of selectors (tag names, classes, or IDs) to remove during extraction (only used in full_page mode).
   *   Supports tag names (e.g., 'nav', 'footer'), class selectors (e.g., '.sidebar', '.ads'), or ID selectors (e.g., '#header-nav', '#ads').
   *   If NULL, uses default: header, footer, aside, nav, script, style, noscript, iframe.
   *
   * @return array
   *   The sanitized HTML content with unnecessary parts removed & the title.
   */
  public function sanitizeHtml($html, $mode = 'article', $selector = NULL, $tags_to_remove = NULL) : array {
    if ($mode === 'full_page') {
      return $this->extractFullPage($html, $selector, $tags_to_remove);
    }

    // Default: Use Readability for article extraction.
    $readability = new Readability(new Configuration([
      'StripUnlikelyCandidates' => FALSE,
      'KeepClasses' => TRUE,
    ]));

    try {
      $readability->parse($html);
    }
    catch (ParseException $e) {
      throw new \Exception(sprintf('Error processing text: %s', $e->getMessage()));
    }

    $title = $readability->getTitle();
    // If title contains '|', only use the part before it.
    if (strpos($title, '|') !== FALSE) {
      $title = trim(substr($title, 0, strpos($title, '|')));
    }

    return [
      'title' => $title,
      'content' => $readability->getContent(),
    ];
  }

  /**
   * Extracts full page content, removing specified elements.
   *
   * @param string $html
   *   The raw HTML content.
   * @param string|null $selector
   *   Optional CSS selector to extract specific content.
   *   Supports tag names (e.g., 'main', 'article') or class selectors (e.g., '.content', '.main-content').
   * @param array|null $tags_to_remove
   *   Optional array of selectors (tag names, classes, or IDs) to remove.
   *   Supports tag names (e.g., 'nav', 'footer'), class selectors (e.g., '.sidebar', '.ads'), or ID selectors (e.g., '#header-nav', '#ads').
   *   If NULL, uses default tags.
   *
   * @return array
   *   The full page content with specified elements removed & the title.
   */
  protected function extractFullPage($html, $selector = NULL, $tags_to_remove = NULL) : array {
    $dom = new \DOMDocument();
    // Suppress warnings for malformed HTML.
    $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

    // Extract title.
    $titleElements = $dom->getElementsByTagName('title');
    $title = $titleElements->length > 0 ? $titleElements->item(0)->textContent : '';

    // If title contains '|', only use the part before it.
    if (strpos($title, '|') !== FALSE) {
      $title = trim(substr($title, 0, strpos($title, '|')));
    }

    // If selector is provided, extract content from matching elements first.
    // This limits the scope before removing elements.
    $scopedDom = NULL;
    if (!empty($selector)) {
      // Extract the content by selector into a new DOM document
      $scopedDom = $this->extractAndCreateScopedDom($dom, $selector);
    }
    else {
      // Use the full document
      $scopedDom = $dom;
    }

    // Use provided tags or default list.
    if ($tags_to_remove === NULL) {
      $tagsToRemove = [
        'header',
        'footer',
        'aside',
        'nav',
        'script',
        'style',
        'noscript',
        'iframe',
      ];
    }
    else {
      $tagsToRemove = $tags_to_remove;
    }

    // Remove unwanted elements from the scoped DOM (by tag name or class).
    foreach ($tagsToRemove as $removeSelector) {
      $elementsArray = [];

      // Check if selector is a class (.classname)
      if (strpos($removeSelector, '.') === 0) {
        $className = substr($removeSelector, 1);
        $xpath = new \DOMXPath($scopedDom);
        $elements = $xpath->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' $className ')]");

        foreach ($elements as $element) {
          $elementsArray[] = $element;
        }
      }
      // Check if selector is an ID (#idname)
      if (strpos($removeSelector, '#') === 0) {
        $idName = substr($removeSelector, 1);
        $xpath = new \DOMXPath($scopedDom);
        $elements = $xpath->query("//*[contains(concat(' ', normalize-space(@id), ' '), ' $idName ')]");

        foreach ($elements as $element) {
          $elementsArray[] = $element;
        }
      }
      // Otherwise treat as tag name
      else {
        $elements = $scopedDom->getElementsByTagName($removeSelector);
        foreach ($elements as $element) {
          $elementsArray[] = $element;
        }
      }

      // Remove the collected elements
      foreach ($elementsArray as $element) {
        if ($element->parentNode) {
          $element->parentNode->removeChild($element);
        }
      }
    }

    // Get the final content from the scoped/cleaned DOM
    if (!empty($selector)) {
      // If selector was used, get content from the body of scoped DOM
      $body = $scopedDom->getElementsByTagName('body')->item(0);
      if ($body) {
        $content = '';
        foreach ($body->childNodes as $node) {
          $content .= $scopedDom->saveHTML($node);
        }
      }
      else {
        $content = $scopedDom->saveHTML();
      }
    }
    else {
      // Get body content from full DOM
      $body = $scopedDom->getElementsByTagName('body')->item(0);
      if ($body) {
        $content = '';
        foreach ($body->childNodes as $node) {
          $content .= $scopedDom->saveHTML($node);
        }
      }
      else {
        // Fallback: return all content if no body tag found.
        $content = $scopedDom->saveHTML();
      }
    }

    // Remove XML encoding declaration if present
    $content = $this->removeXmlDeclaration($content);

    return [
      'title' => $title,
      'content' => $content,
    ];
  }

  /**
   * Extract content by selector and create a new scoped DOM document.
   *
   * @param \DOMDocument $dom
   *   The source DOM document.
   * @param string $selector
   *   The CSS selector (tag name, .classname, or #id).
   *
   * @return \DOMDocument
   *   A new DOM document containing only the selected content.
   */
  protected function extractAndCreateScopedDom(\DOMDocument $dom, string $selector) : \DOMDocument {
    $content = $this->extractBySelector($dom, $selector);

    // Create a new DOM document with the extracted content
    $scopedDom = new \DOMDocument();
    $scopedDom->loadHTML('<?xml encoding="UTF-8">' . $content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

    return $scopedDom;
  }

  /**
   * Extract content from DOM using a CSS selector.
   *
   * @param \DOMDocument $dom
   *   The DOM document.
   * @param string $selector
   *   The CSS selector (tag name, .classname, or #id).
   *
   * @return string
   *   The extracted content.
   */
  protected function extractBySelector(\DOMDocument $dom, string $selector) : string {
    $content = '';
    $selector = trim($selector);

    // Check if selector is a class (.classname)
    if (strpos($selector, '.') === 0) {
      $className = substr($selector, 1);
      $xpath = new \DOMXPath($dom);
      $elements = $xpath->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' $className ')]");

      if ($elements->length > 0) {
        foreach ($elements as $element) {
          $content .= $dom->saveHTML($element);
        }
      }
    }
    // Check if selector is an ID (#idname)
    elseif (strpos($selector, '#') === 0) {
      $idName = substr($selector, 1);
      $element = $dom->getElementById($idName);

      if ($element) {
        $content = $dom->saveHTML($element);
      }
    }
    // Assume it's a tag name
    else {
      $elements = $dom->getElementsByTagName($selector);

      if ($elements->length > 0) {
        foreach ($elements as $element) {
          $content .= $dom->saveHTML($element);
        }
      }
    }

    // If no content found with selector, fall back to body content.
    if (empty($content)) {
      $this->logger->warning('Selector "@selector" did not match any elements. Falling back to full body content.', ['@selector' => $selector]);
      $body = $dom->getElementsByTagName('body')->item(0);
      if ($body) {
        foreach ($body->childNodes as $node) {
          $content .= $dom->saveHTML($node);
        }
      }
    }

    return $content;
  }

  /**
   * Remove XML encoding declaration from HTML content.
   *
   * @param string $content
   *   The HTML content that may contain an XML declaration.
   *
   * @return string
   *   The content with XML declaration removed.
   */
  protected function removeXmlDeclaration(string $content) : string {
    $content = preg_replace('/<\?xml.+?>/i', '', $content);
    return $content;
  }

}
