<?php

namespace Drupal\content_migration\Service;

use Drupal\content_migration\Plugin\QualityAnalysisPluginManager;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\node\NodeInterface;

/**
 * Service for assessing content quality using plugins.
 */
class ContentQualityService {

  /**
   * The logger.
   *
   * @var \Drupal\Core\Logger\LoggerChannelInterface
   */
  protected $logger;

  /**
   * The quality analysis plugin manager.
   *
   * @var \Drupal\content_migration\Plugin\QualityAnalysisPluginManager
   */
  protected QualityAnalysisPluginManager $pluginManager;

  /**
   * Constructs a ContentQualityService object.
   *
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   * @param \Drupal\content_migration\Plugin\QualityAnalysisPluginManager $plugin_manager
   *   The quality analysis plugin manager.
   */
  public function __construct(
    LoggerChannelFactoryInterface $logger_factory,
    QualityAnalysisPluginManager $plugin_manager
  ) {
    $this->logger = $logger_factory->get('content_migration');
    $this->pluginManager = $plugin_manager;
  }

  /**
   * Assesses content quality using all available analysis plugins.
   *
   * @param string $content
   *   The content to assess.
   * @param \Drupal\node\NodeInterface $node
   *   The node being assessed.
   * @param int|null $audience_term_id
   *   Optional audience term ID to use for assessment.
   *
   * @return array
   *   Combined assessment results from all plugins.
   */
  public function assessContent(string $content, NodeInterface $node, ?int $audience_term_id = NULL): array {
    $this->logger->info('ContentQualityService: ===== STARTING CONTENT ASSESSMENT =====');
    $this->logger->info('ContentQualityService: Node ID: @nid, Type: @type, Title: @title', [
      '@nid' => $node->id(),
      '@type' => $node->bundle(),
      '@title' => $node->getTitle(),
    ]);
    $this->logger->info('ContentQualityService: Audience Term ID: @audience, Content length: @length chars', [
      '@audience' => $audience_term_id ?? 'NULL',
      '@length' => strlen($content),
    ]);

    $context = [
      'audience_term_id' => $audience_term_id,
      'node' => $node,
    ];

    $this->logger->info('ContentQualityService: Requesting available plugins from PluginManager...');

    // Get all available plugins for this context.
    $plugins = $this->pluginManager->getAvailablePlugins($context);

    $this->logger->info('ContentQualityService: PluginManager returned @count available plugins.', [
      '@count' => count($plugins),
    ]);

    if (empty($plugins)) {
      $this->logger->error('ContentQualityService: NO PLUGINS AVAILABLE! Cannot proceed with assessment.');
      throw new \Exception('No quality analysis plugins are available. Please configure at least one analysis method.');
    }

    $this->logger->info('ContentQualityService: Will run the following plugins in order:');
    $plugin_counter = 1;
    foreach ($plugins as $plugin_id => $plugin) {
      $this->logger->info('ContentQualityService:   [@counter] "@id" - @label', [
        '@counter' => $plugin_counter++,
        '@id' => $plugin_id,
        '@label' => $plugin->getLabel(),
      ]);
    }

    // Run all available plugins and collect their results.
    $all_results = [];
    $errors = [];

    $this->logger->info('ContentQualityService: ===== BEGINNING PLUGIN EXECUTION =====');

    $execution_counter = 1;
    foreach ($plugins as $plugin_id => $plugin) {
      $this->logger->info('ContentQualityService: [@counter/@total] Executing plugin "@plugin" (ID: @id)...', [
        '@counter' => $execution_counter++,
        '@total' => count($plugins),
        '@plugin' => $plugin->getLabel(),
        '@id' => $plugin_id,
      ]);

      try {
        $results = $plugin->analyze($content, $node, $context);

        $all_results[$plugin_id] = [
          'plugin_id' => $plugin_id,
          'plugin_label' => $plugin->getLabel(),
          'results' => $results,
        ];

        $this->logger->info('ContentQualityService: ✓ Plugin "@plugin" completed successfully. Overall score: @score', [
          '@plugin' => $plugin->getLabel(),
          '@score' => $results['overall_score'] ?? 'N/A',
        ]);
      }
      catch (\Exception $e) {
        $this->logger->error('ContentQualityService: ✗ Plugin "@plugin" failed: @error', [
          '@plugin' => $plugin->getLabel(),
          '@error' => $e->getMessage(),
        ]);
        $errors[$plugin_id] = $e->getMessage();
      }
    }

    $this->logger->info('ContentQualityService: ===== PLUGIN EXECUTION COMPLETE =====');

    // If all plugins failed, throw an exception.
    if (empty($all_results)) {
      $this->logger->error('ContentQualityService: ALL PLUGINS FAILED! Cannot return any results.');
      throw new \Exception('All quality analysis plugins failed. Errors: ' . implode('; ', $errors));
    }

    $this->logger->info('ContentQualityService: Successfully completed @success of @total plugins. Returning results.', [
      '@success' => count($all_results),
      '@total' => count($plugins),
    ]);

    // Return all results keyed by plugin ID.
    return $all_results;
  }

  /**
   * Compares original and rewritten content for factual accuracy.
   *
   * @param string $original_content
   *   The original content.
   * @param string $rewritten_content
   *   The rewritten content.
   * @param \Drupal\node\NodeInterface $node
   *   The node being assessed.
   * @param int|null $audience_term_id
   *   Optional audience term ID.
   *
   * @return array
   *   Comparison results.
   */
  public function compareContent(string $original_content, string $rewritten_content, NodeInterface $node, ?int $audience_term_id = NULL): array {
    $context = [
      'audience_term_id' => $audience_term_id,
      'node' => $node,
    ];

    // Get the factual accuracy plugin specifically.
    try {
      $plugin = $this->pluginManager->createInstance('factual_accuracy');

      $this->logger->info('ContentQualityService: Running factual accuracy comparison for node @nid', [
        '@nid' => $node->id(),
      ]);

      $results = $plugin->compareContent($original_content, $rewritten_content, $node, $context);

      $this->logger->info('ContentQualityService: Comparison completed for node @nid', [
        '@nid' => $node->id(),
      ]);

      return $results;
    }
    catch (\Exception $e) {
      $this->logger->error('ContentQualityService: Comparison failed for node @nid: @error', [
        '@nid' => $node->id(),
        '@error' => $e->getMessage(),
      ]);
      throw $e;
    }
  }

}
