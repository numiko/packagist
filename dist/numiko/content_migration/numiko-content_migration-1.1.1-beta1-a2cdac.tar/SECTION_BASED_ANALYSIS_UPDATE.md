# Section-Based Factual Accuracy Analysis Update

## Date
2025-11-04

## Summary

Updated the Factual Accuracy plugin from category-based scoring to **section-by-section analysis** with per-section accuracy ratings. This provides more granular and actionable feedback about where factual issues occur within content.

## What Changed

### 1. Analysis Approach

**Before:**
- Single analysis of all content
- Four category-based scores: Factual Completeness, Factual Accuracy, Numerical Accuracy, Name/Entity Accuracy
- One overall list of factual differences

**After:**
- Content divided into logical sections (3-8 sections)
- Each section gets its own accuracy score
- Factual differences organized by section
- Overall score calculated as average of section scores

### 2. AI Prompt Changes

**FactualAccuracyAnalysis.php** - `buildComparisonPrompt()` method:

**New Instructions:**
```
Please perform a detailed section-by-section factual accuracy check:

1. Divide the original content into logical sections (paragraphs, topics, or themes)
2. For each section, identify all factual statements
3. Find the corresponding content in the new field and verify facts are preserved
4. Rate the accuracy of each section individually
5. List any factual discrepancies per section
```

**New Output Format:**
```
OVERALL_ACCURACY: [Percentage]

SECTION_ANALYSIS:

SECTION 1: [Description]
Accuracy Score: [Percentage]
Factual Differences:
- [Type: MISSING/CHANGED/INCORRECT] [Description]

SECTION 2: [Description]
Accuracy Score: [Percentage]
...

OVERALL_SUMMARY:
[Comprehensive summary]
```

### 3. Response Parsing Updates

**FactualAccuracyAnalysis.php** - `parseComparisonResponse()` method:

**New Structure:**
```php
$results = [
  'overall_score' => '85%',
  'overall_score_numeric' => 85,
  'sections' => [
    [
      'number' => 1,
      'description' => 'Introduction and background',
      'accuracy_score' => '100%',
      'accuracy_score_numeric' => 100,
      'differences' => [
        ['type' => 'NONE', 'description' => 'No factual differences in this section']
      ]
    ],
    [
      'number' => 2,
      'description' => 'Key features',
      'accuracy_score' => '85%',
      'accuracy_score_numeric' => 85,
      'differences' => [
        ['type' => 'MISSING', 'description' => 'Launch date omitted'],
        ['type' => 'CHANGED', 'description' => '500 became hundreds']
      ]
    ]
  ],
  'scores' => [
    'Section 1: Introduction and background' => [
      'score' => '100%',
      'score_numeric' => 100,
      'comments' => '1 items checked'
    ],
    'Section 2: Key features' => [
      'score' => '85%',
      'score_numeric' => 85,
      'comments' => '2 items checked'
    ]
  ],
  'summary' => '...',
  'factual_differences' => [
    ['type' => 'MISSING', 'description' => 'Section 2: Launch date omitted', 'section' => 2],
    ['type' => 'CHANGED', 'description' => 'Section 2: 500 became hundreds', 'section' => 2]
  ]
];
```

### 4. Display Updates

**ContentQualityCheckForm.php** - New display method:

Added `formatSectionAnalysis()` method that creates a visually structured display:

```html
<div class="quality-sections">
  <h4>Section-by-Section Factual Accuracy Analysis:</h4>

  <div class="section-analysis">
    <div class="section-header">
      <strong>Section 1:</strong> Introduction and background
    </div>
    <div class="section-score">
      <strong>Accuracy Score:</strong> <span class="score-excellent">100%</span>
    </div>
    <div class="section-differences">
      <strong>Factual Differences:</strong>
      <ul>
        <li>✓ No factual differences in this section</li>
      </ul>
    </div>
  </div>

  <div class="section-analysis">
    <div class="section-header">
      <strong>Section 2:</strong> Key features and benefits
    </div>
    <div class="section-score">
      <strong>Accuracy Score:</strong> <span class="score-good">85%</span>
    </div>
    <div class="section-differences">
      <strong>Factual Differences:</strong>
      <ul>
        <li><span class="badge-missing">MISSING</span> Launch date omitted</li>
        <li><span class="badge-changed">CHANGED</span> 500 became hundreds</li>
      </ul>
    </div>
  </div>
</div>
```

**Visual Features:**
- Color-coded badges for difference types (MISSING, CHANGED, INCORRECT)
- Clear section headers with descriptions
- Inline scores with color classes
- Bordered/padded containers for easy reading

### 5. Backwards Compatibility

**Maintained for Dashboard:**
- `scores` array still populated with section-based scores
- `factual_differences` array still includes all differences (with section prefix)
- Existing dashboard code continues to work

**New Data Available:**
- `sections` array with detailed per-section data
- Richer structure for custom reporting

## Benefits of Section-Based Analysis

### 1. **Pinpoint Issues**
Instead of:
> "You have 5 factual issues across the entire content"

Now:
> "Section 1 (Introduction): 100% accurate
> Section 2 (Features): 85% accurate - 2 issues found
> Section 3 (Specifications): 60% accurate - 3 issues found"

### 2. **Easier Review Process**
Editors can focus on specific sections with problems rather than hunting through entire content.

### 3. **Better Understanding of Content Quality**
- See which parts of content were well-preserved
- Identify patterns (e.g., technical sections lose more facts)
- Prioritize fixes based on section importance

### 4. **More Actionable Feedback**
Each section shows exactly what's wrong:
- "Section 2: Missing launch date"
- "Section 3: Changed Dr. Smith to Dr. Jones"

### 5. **Granular Metrics**
Track factual accuracy at section level:
- Which sections consistently have issues?
- Does intro preserve facts better than conclusion?
- Are numerical sections more error-prone?

## Example Output

### Content Quality Check Result

**Overall Factual Accuracy: 85%**

#### Section-by-Section Analysis

**Section 1: Company History and Background**
- Accuracy: 100%
- ✓ No factual differences

**Section 2: Product Features**
- Accuracy: 90%
- ⚠ [CHANGED] "Launched in March 2023" → "Launched in 2023" (less precise)

**Section 3: Customer Testimonials**
- Accuracy: 75%
- ⚠ [MISSING] Customer name "Sarah Johnson" omitted
- ⚠ [CHANGED] "500 companies" → "hundreds of companies"

**Section 4: Technical Specifications**
- Accuracy: 70%
- ✗ [INCORRECT] "ISO 9001 certified" → "ISO 9002 certified" (wrong certification)
- ⚠ [MISSING] Operating temperature range not mentioned

## Files Modified

1. **src/Plugin/QualityAnalysis/FactualAccuracyAnalysis.php**
   - Updated `buildComparisonPrompt()` - section-based instructions
   - Updated `parseComparisonResponse()` - parse section structure
   - Added section regex patterns and data extraction

2. **src/Form/ContentQualityCheckForm.php**
   - Added `formatSectionAnalysis()` method
   - Updated display logic to check for sections first
   - Added inline styling for visual clarity

3. **FACTUAL_ACCURACY_PLUGIN.md**
   - Updated "Analysis Process" section
   - Changed "Score Categories" to "Section-Based Scoring"
   - Updated "Output Format" with section examples
   - Added section scoring criteria

4. **SECTION_BASED_ANALYSIS_UPDATE.md** (this file)
   - Complete documentation of the changes

## Migration Notes

### For Existing Installations

**No breaking changes:**
- Old format will still parse (but won't show section detail)
- Dashboard continues to work with section-based scores
- All existing code remains functional

**New assessments:**
- Will automatically use section-based analysis
- Previous assessments remain readable
- Mix of old and new formats supported

### For Developers

**Using section data:**
```php
// Get assessment results
$results = $plugin->compareFieldContent($original, $new, $node);

// Access section-based data
foreach ($results['sections'] as $section) {
  echo "Section {$section['number']}: {$section['description']}\n";
  echo "Score: {$section['accuracy_score']}\n";

  foreach ($section['differences'] as $diff) {
    echo "  - [{$diff['type']}] {$diff['description']}\n";
  }
}

// Or use traditional scores array (backwards compatible)
foreach ($results['scores'] as $area => $data) {
  echo "{$area}: {$data['score']}\n";
}
```

## Testing Recommendations

1. **Run on various content lengths:**
   - Short (1-2 paragraphs) - should create 2-3 sections
   - Medium (5-8 paragraphs) - should create 4-6 sections
   - Long (10+ paragraphs) - should create 6-8 sections

2. **Verify section detection:**
   - Sections should align with natural content breaks
   - Each section should have meaningful description
   - Scores should vary based on actual issues per section

3. **Check difference attribution:**
   - Each difference should be assigned to correct section
   - Section numbers should match descriptions
   - No differences lost between sections

4. **Dashboard compatibility:**
   - Verify scores display in dashboard
   - Check that section labels appear correctly
   - Ensure percentages calculate properly

## Future Enhancements

Possible future improvements:
1. Section importance weighting (intro more important than conclusion?)
2. Confidence scores per section
3. Section-level recommendations
4. Heatmap visualization showing which sections need work
5. Historical tracking of section-level improvements
