# Debugging Plugin Selection

## Overview

The content quality checker now includes comprehensive debugging that shows exactly how the system decides which plugins to run during a quality assessment.

## How to View Debug Logs

### Option 1: Drupal Recent Log Messages (Web UI)

1. Navigate to **Reports → Recent log messages** (`/admin/reports/dblog`)
2. Filter by type: **content_migration**
3. Run a quality check on any content page
4. Refresh the log page to see the debug output

### Option 2: Drush Command Line

```bash
# Watch logs in real-time
drush watchdog:tail --filter=content_migration

# Or view recent logs
drush watchdog:show --type=content_migration --count=100
```

### Option 3: Database Query

```bash
drush sqlq "SELECT * FROM watchdog WHERE type = 'content_migration' ORDER BY wid DESC LIMIT 50;"
```

## What Gets Logged

### 1. Plugin Discovery Phase

**QualityAnalysisPluginManager** logs:
- How many plugin definitions were discovered
- Details about each discovered plugin (ID, label, weight)
- Plugin instantiation attempts
- Availability check for each plugin
- Final list of available plugins

**Example Output:**
```
QualityAnalysisPluginManager: Starting plugin discovery. Found 2 plugin definitions.
QualityAnalysisPluginManager: Discovered plugin "style_guide" - Label: Style Guide Analysis, Weight: 0
QualityAnalysisPluginManager: Discovered plugin "factual_accuracy" - Label: Factual Accuracy Check, Weight: 10
QualityAnalysisPluginManager: Plugins sorted by weight. Processing availability checks...
QualityAnalysisPluginManager: Attempting to create instance of "style_guide"
QualityAnalysisPluginManager: Plugin "style_guide" instantiated successfully. Checking availability...
QualityAnalysisPluginManager: ✓ Plugin "style_guide" is AVAILABLE and will be used.
QualityAnalysisPluginManager: Attempting to create instance of "factual_accuracy"
QualityAnalysisPluginManager: Plugin "factual_accuracy" instantiated successfully. Checking availability...
QualityAnalysisPluginManager: ✗ Plugin "factual_accuracy" is NOT AVAILABLE (isAvailable returned false). Skipping.
QualityAnalysisPluginManager: Plugin discovery complete. 1 of 2 plugins are available: style_guide
```

### 2. Individual Plugin Availability Checks

**StyleGuideAnalysis** logs:
- Whether audience vocabulary is configured
- Whether root term exists with a style guide prompt
- Final availability decision

**Example Output:**
```
StyleGuideAnalysis: Checking if plugin is available...
StyleGuideAnalysis: Audience vocabulary ID from config: audience
StyleGuideAnalysis: Checking for root term in vocabulary "audience"...
StyleGuideAnalysis: Root term data: {"tid":"1","name":"All Audiences","prompt":"..."}
StyleGuideAnalysis: Root term has a style guide prompt. Plugin IS AVAILABLE.
```

**FactualAccuracyAnalysis** logs:
- Why it's not available for single-content analysis

**Example Output:**
```
FactualAccuracyAnalysis: Checking if plugin is available...
FactualAccuracyAnalysis: This plugin requires both original and rewritten content for comparison. It is NOT AVAILABLE for standard single-content analysis.
```

### 3. Content Assessment Execution

**ContentQualityService** logs:
- Node information being assessed
- Request to plugin manager for available plugins
- List of plugins that will be executed
- Execution progress for each plugin
- Success/failure status for each plugin
- Overall completion summary

**Example Output:**
```
ContentQualityService: ===== STARTING CONTENT ASSESSMENT =====
ContentQualityService: Node ID: 123, Type: page, Title: Test Page
ContentQualityService: Audience Term ID: 5, Content length: 1547 chars
ContentQualityService: Requesting available plugins from PluginManager...
ContentQualityService: PluginManager returned 1 available plugins.
ContentQualityService: Will run the following plugins in order:
ContentQualityService:   [1] "style_guide" - Style Guide Analysis
ContentQualityService: ===== BEGINNING PLUGIN EXECUTION =====
ContentQualityService: [1/1] Executing plugin "Style Guide Analysis" (ID: style_guide)...
ContentQualityService: ✓ Plugin "Style Guide Analysis" completed successfully. Overall score: 8.5/10
ContentQualityService: ===== PLUGIN EXECUTION COMPLETE =====
ContentQualityService: Successfully completed 1 of 1 plugins. Returning results.
```

## Debugging Factual Accuracy Comparisons

The system runs factual accuracy comparisons in two scenarios and logs detailed information for each.

### Scenario 1: Original vs Rewritten Content Detection

The system logs detailed information about detecting rewritten content:

**Example Output:**
```
ContentQualityCheckForm: ===== CHECKING FOR REWRITTEN CONTENT =====
ContentQualityCheckForm: Content type: page
ContentQualityCheckForm: Field mappings: {"original_content":"text:body","rewritten_content":"text:field_rewritten"}
getRewrittenContent: Starting rewritten content detection for node 123
getRewrittenContent: Rewritten content field from mappings: text:field_rewritten
getRewrittenContent: Parsed composite field - Type: text, Name: field_rewritten
getRewrittenContent: Checking if node has field "field_rewritten"...
getRewrittenContent: Node has field "field_rewritten". Checking if empty...
getRewrittenContent: ✓ Found rewritten content in field "field_rewritten" - Length: 1245 chars
ContentQualityCheckForm: Rewritten content result: FOUND (1245 chars)
ContentQualityCheckForm: ✓ Rewritten content exists. Running factual accuracy comparison...
```

**If rewritten content is NOT found:**
```
ContentQualityCheckForm: ===== CHECKING FOR REWRITTEN CONTENT =====
getRewrittenContent: Starting rewritten content detection for node 123
getRewrittenContent: Rewritten content field from mappings: NULL (not configured)
getRewrittenContent: No rewritten content field configured for this content type. Returning NULL.
ContentQualityCheckForm: Rewritten content result: NOT FOUND
ContentQualityCheckForm: ✗ No rewritten content found. Skipping factual accuracy comparison.
```

### Scenario 2: Original vs Paragraph Content Detection

When a page has original content and paragraph fields with content, the system runs factual accuracy comparisons between the original and each paragraph:

**Example Output:**
```
ContentQualityCheckForm: ===== CHECKING FOR PARAGRAPH CONTENT =====
ContentQualityCheckForm: Found 2 paragraph assessments
ContentQualityCheckForm: Both original content and paragraph content exist. Checking for factual accuracy comparisons...
ContentQualityCheckForm: Running factual accuracy comparison between original content and Paragraph: Content (text_paragraph) #1
ContentQualityService: ===== STARTING CONTENT ASSESSMENT =====
ContentQualityService: Node ID: 123, Type: page, Title: Test Page
ContentQualityService: Calling compareContent for factual accuracy...
ContentQualityCheckForm: Factual accuracy comparison complete for Paragraph: Content (text_paragraph) #1
ContentQualityCheckForm: Running factual accuracy comparison between original content and Paragraph: Content (text_paragraph) #2
ContentQualityCheckForm: Factual accuracy comparison complete for Paragraph: Content (text_paragraph) #2
```

**If no paragraph content is found:**
```
ContentQualityCheckForm: ===== CHECKING FOR PARAGRAPH CONTENT =====
ContentQualityCheckForm: No paragraph content found.
```

**Result:** Each paragraph with content will have its own factual accuracy comparison showing how well it preserved facts from the original content.

## Understanding Plugin Selection Logic

### Plugin Discovery
1. System scans `src/Plugin/QualityAnalysis/` directory
2. Finds all classes with `#[QualityAnalysis]` attribute
3. Extracts plugin definition (id, label, description, weight)

### Plugin Sorting
- Plugins are sorted by `weight` (lower = runs first)
- Current weights:
  - `style_guide`: 0 (runs first)
  - `factual_accuracy`: 10 (would run second if available)

### Availability Determination
Each plugin's `isAvailable()` method decides if it should run:

**StyleGuideAnalysis Requirements:**
- ✓ Audience vocabulary must be configured in settings
- ✓ Root term must exist in that vocabulary
- ✓ Root term must have a style guide prompt

**FactualAccuracyAnalysis Requirements:**
- Always returns FALSE for single-content analysis
- Only runs when explicitly called via `compareContent()` method
- Used only for original vs rewritten content comparison

### Execution
- All available plugins run sequentially
- Each plugin receives the content and context
- Results collected and returned together
- If one plugin fails, others continue (graceful degradation)

## Common Scenarios

### Scenario 1: No Plugins Available
**Symptoms:** Error message "No quality analysis plugins are available"

**Debug Steps:**
1. Check logs for plugin discovery output
2. Look for why each plugin is unavailable
3. Common causes:
   - No audience vocabulary configured
   - No root term in vocabulary
   - No style guide prompt on root term

**Log Pattern:**
```
QualityAnalysisPluginManager: Plugin discovery complete. 0 of 2 plugins are available:
ContentQualityService: NO PLUGINS AVAILABLE! Cannot proceed with assessment.
```

### Scenario 2: Only Style Guide Plugin Runs
**Symptoms:** Only seeing Style Guide Analysis results

**This is normal behavior!** The Factual Accuracy plugin is specifically designed NOT to run during standard assessments. It only runs when comparing original vs rewritten content.

**Log Pattern:**
```
QualityAnalysisPluginManager: ✓ Plugin "style_guide" is AVAILABLE and will be used.
QualityAnalysisPluginManager: ✗ Plugin "factual_accuracy" is NOT AVAILABLE
ContentQualityService: Will run the following plugins in order:
ContentQualityService:   [1] "style_guide" - Style Guide Analysis
```

### Scenario 3: Factual Accuracy Comparison Not Running
**Symptoms:** The factual accuracy plugin doesn't run even though you have both original and rewritten content

**Debug Steps:**
1. Check if rewritten content field is configured in settings
2. Look for the "CHECKING FOR REWRITTEN CONTENT" log section
3. Verify the field mapping is correct
4. Check if the rewritten content field actually has data

**Common Causes:**
- Rewritten content field not configured in **Configuration → Content Migration → Settings**
- Field mapping uses wrong field name
- Rewritten content field exists but is empty
- Field name has incorrect prefix (e.g., missing "text:" prefix)

**Log Pattern (NOT configured):**
```
ContentQualityCheckForm: ===== CHECKING FOR REWRITTEN CONTENT =====
getRewrittenContent: Rewritten content field from mappings: NULL (not configured)
ContentQualityCheckForm: ✗ No rewritten content found. Skipping factual accuracy comparison.
```

**Log Pattern (configured but empty):**
```
ContentQualityCheckForm: ===== CHECKING FOR REWRITTEN CONTENT =====
getRewrittenContent: Rewritten content field from mappings: text:field_rewritten
getRewrittenContent: Node has field "field_rewritten". Checking if empty...
getRewrittenContent: Field "field_rewritten" is EMPTY. Returning NULL.
ContentQualityCheckForm: ✗ No rewritten content found. Skipping factual accuracy comparison.
```

**Log Pattern (field doesn't exist on node):**
```
ContentQualityCheckForm: ===== CHECKING FOR REWRITTEN CONTENT =====
getRewrittenContent: Rewritten content field from mappings: text:field_rewritten
getRewrittenContent: Node does NOT have field "field_rewritten". Returning NULL.
ContentQualityCheckForm: ✗ No rewritten content found. Skipping factual accuracy comparison.
```

**Solution:**
1. Go to **Configuration → Content Migration → Settings**
2. Find your content type in the field mappings
3. Set the "Rewritten Content Field" to the correct field
4. Ensure the field actually contains content on your test node

### Scenario 4: Plugin Fails During Execution
**Symptoms:** Some plugins complete, some fail

**Log Pattern:**
```
ContentQualityService: [1/2] Executing plugin "Style Guide Analysis"...
ContentQualityService: ✓ Plugin "Style Guide Analysis" completed successfully.
ContentQualityService: [2/2] Executing plugin "Custom Analysis"...
ContentQualityService: ✗ Plugin "Custom Analysis" failed: API connection timeout
ContentQualityService: Successfully completed 1 of 2 plugins.
```

## Adding Your Own Plugins

When you add a new quality analysis plugin, the debugging will automatically show:
1. Whether your plugin was discovered
2. Why it is/isn't available (based on your `isAvailable()` logic)
3. Whether it executes successfully
4. Any errors that occur

**Pro tip:** Add your own logging inside your plugin's `isAvailable()` method to show your custom logic:

```php
public function isAvailable(array $context = []): bool {
  $this->logger->info('MyPlugin: Checking if plugin is available...');

  if (!$this->someRequirement()) {
    $this->logger->info('MyPlugin: Requirement not met. Plugin is NOT AVAILABLE.');
    return FALSE;
  }

  $this->logger->info('MyPlugin: All requirements met. Plugin IS AVAILABLE.');
  return TRUE;
}
```

## Performance Note

This verbose logging is helpful for debugging but may create many log entries in production. Consider:
- Using a lower log level (debug instead of info) in future
- Adding a setting to enable/disable verbose plugin debugging
- Clearing old logs regularly: `drush watchdog:delete all`
