# JSON Storage Update for Factual Accuracy Comparison

## Date
2025-11-05

## Summary

Updated the JSON storage system to save the **full structured comparison data** from the Factual Accuracy plugin, including the complete sections array with original_text, new_text, and differences for each section. This enables the dashboard and other tools to display the side-by-side comparison without re-running the analysis.

## Problem

Previously, when factual accuracy comparisons were saved to JSON, only the overall score, summary, and basic scores were stored. The detailed section-by-section comparison data (which includes extracted text from both fields and the differences) was not being saved.

This meant:
- Dashboard couldn't show the side-by-side comparison
- Users would need to re-run the check to see detailed differences
- Historical comparison data was lost

## Solution

### 1. Updated JSON Structure

**File**: `src/Form/ContentQualityCheckForm.php`

**Method**: `buildJsonResults()` (lines 1038-1051)

Added three new fields to the assessment JSON:

```php
// Add sections array (for factual accuracy plugin with side-by-side comparison).
if (!empty($assessment_results['sections'])) {
  $assessment_entry['sections'] = $assessment_results['sections'];
}

// Add factual differences array (for factual accuracy plugin).
if (!empty($assessment_results['factual_differences'])) {
  $assessment_entry['factual_differences'] = $assessment_results['factual_differences'];
}

// Add raw response if available (useful for debugging).
if (!empty($assessment_results['raw_response'])) {
  $assessment_entry['raw_response'] = $assessment_results['raw_response'];
}
```

### 2. Data Now Saved

Each factual accuracy assessment in the JSON now includes:

#### **sections** (array)
Complete section-by-section comparison with:
- `number`: Section number (1-based)
- `description`: Brief description of section topic
- `original_text`: Extracted text from original field (2-4 sentences)
- `new_text`: Extracted text from new field (2-4 sentences)
- `accuracy_score`: Section accuracy as percentage string (e.g., "85%")
- `accuracy_score_numeric`: Normalized score (0-100)
- `differences`: Array of difference objects with:
  - `type`: "NEW", "MISSING", "CHANGED", "INCORRECT", or "NONE"
  - `description`: Human-readable description of the difference

#### **factual_differences** (array)
Flat list of all differences for quick access:
- `type`: Difference type
- `description`: Description with section number prefix
- `section`: Section number where difference was found

#### **raw_response** (string, optional)
The complete AI response for debugging purposes.

## Example JSON Output

```json
{
  "plugin_id": "factual_accuracy",
  "plugin_label": "Factual Accuracy Check",
  "content_label": "Factual Accuracy: Original vs Rewritten",
  "content_type": "comparison",
  "overall_score": "85%",
  "overall_score_numeric": 85.0,
  "summary": "<p>The content maintains good factual accuracy...</p>",
  "sections": [
    {
      "number": 1,
      "description": "Introduction and background",
      "original_text": "Our company was founded in 1995 by John Smith...",
      "new_text": "We were founded in 1995 by John Smith...",
      "accuracy_score": "100%",
      "accuracy_score_numeric": 100,
      "differences": [
        {
          "type": "NONE",
          "description": "No factual differences in this section"
        }
      ]
    },
    {
      "number": 2,
      "description": "Product features",
      "original_text": "Launched in March 2023, serving 500 companies...",
      "new_text": "Launched in 2023, serving hundreds of companies...",
      "accuracy_score": "85%",
      "accuracy_score_numeric": 85,
      "differences": [
        {
          "type": "NEW",
          "description": "Partnership with VSC mentioned in new field"
        },
        {
          "type": "MISSING",
          "description": "Specific month (March) omitted"
        },
        {
          "type": "CHANGED",
          "description": "'500 companies' became 'hundreds' - less precise"
        }
      ]
    }
  ],
  "factual_differences": [
    {
      "type": "NEW",
      "description": "Section 2: Partnership with VSC mentioned in new field",
      "section": 2
    },
    {
      "type": "MISSING",
      "description": "Section 2: Specific month (March) omitted",
      "section": 2
    },
    {
      "type": "CHANGED",
      "description": "Section 2: '500 companies' became 'hundreds' - less precise",
      "section": 2
    }
  ],
  "audience_term_id": 456
}
```

## Benefits

### 1. **Dashboard Display**
The dashboard can now display the full side-by-side comparison without re-running the analysis:
- Show original text vs new text for each section
- Display color-coded differences (NEW, MISSING, CHANGED, INCORRECT)
- Present section-by-section accuracy scores

### 2. **Historical Tracking**
Users can see the detailed comparison results from previous assessments:
- Track which sections improved or degraded over time
- Compare different versions of rewrites
- Audit trail for content changes

### 3. **Reporting and Export**
The structured data can be used for:
- Generating reports on factual accuracy across multiple pages
- Exporting comparison data to external tools
- Analyzing patterns in factual changes

### 4. **Performance**
Avoid re-running expensive AI analysis:
- Display cached results instantly
- Reduce API costs
- Enable bulk reporting without re-analysis

## Dashboard Integration

To display the side-by-side comparison in the dashboard:

### 1. Load the Assessment JSON

```php
$node = \Drupal::entityTypeManager()->getStorage('node')->load($nid);
$quality_data = $node->get('field_quality_assessment')->value;
$assessment = json_decode($quality_data, TRUE);
```

### 2. Find Factual Accuracy Assessment

```php
$factual_assessment = NULL;
foreach ($assessment['assessments'] as $item) {
  if ($item['plugin_id'] === 'factual_accuracy' && $item['content_type'] === 'comparison') {
    $factual_assessment = $item;
    break;
  }
}
```

### 3. Render Sections

```php
if (!empty($factual_assessment['sections'])) {
  foreach ($factual_assessment['sections'] as $section) {
    // Display three-column layout:
    // - Column 1: $section['original_text']
    // - Column 2: $section['new_text']
    // - Column 3: Loop through $section['differences']

    // Each difference has:
    // - $diff['type'] for badge color (NEW/MISSING/CHANGED/INCORRECT)
    // - $diff['description'] for display text
  }
}
```

### 4. Display Difference Badges

Use the same badge styling from ContentQualityCheckForm:
- **NEW**: Blue badge (#007bff) - Facts added
- **MISSING**: Yellow badge (#ffc107) - Facts removed
- **CHANGED**: Cyan badge (#17a2b8) - Facts altered
- **INCORRECT**: Red badge (#dc3545) - Facts wrong

## Files Modified

1. **src/Form/ContentQualityCheckForm.php**
   - `buildJsonResults()`: Added sections, factual_differences, and raw_response to JSON

2. **QUALITY_ASSESSMENT_JSON_SCHEMA.md**
   - Updated Assessment Object Fields table to include new fields
   - Added "Sections Array (Factual Accuracy Plugin)" section with complete schema
   - Added "Factual Differences Array (Factual Accuracy Plugin)" section
   - Added complete example in main JSON structure

3. **JSON_STORAGE_UPDATE.md** (this file)

## Backwards Compatibility

✅ **Fully backwards compatible**

- Old assessments without sections array will continue to work
- Dashboard can check for existence of `sections` field before displaying
- If sections are missing, fall back to showing summary text only
- All existing functionality remains unchanged

## Testing

### Verify JSON Storage

1. Run a factual accuracy check on a page with both original and rewritten content
2. View the quality assessment field JSON on the node
3. Confirm the JSON includes:
   - `sections` array with all section data
   - `factual_differences` array
   - Each section has `original_text`, `new_text`, and `differences`
   - Differences have proper `type` (NEW/MISSING/CHANGED/INCORRECT)

### Verify Dashboard Display

1. Navigate to the quality dashboard
2. Click on a factual accuracy score cell
3. Confirm the side-by-side comparison displays correctly
4. Verify all badges are color-coded properly
5. Check that original and new text are extracted correctly

## Future Enhancements

1. **Interactive Dashboard**
   - Click section in dashboard to expand/collapse details
   - Filter sections by accuracy score
   - Sort sections by number of differences

2. **Comparison Over Time**
   - Store multiple assessments in array
   - Show trend of factual accuracy over time
   - Highlight sections that improved or degraded

3. **Bulk Analysis**
   - Generate report across all pages
   - Show aggregate statistics on NEW/MISSING/CHANGED facts
   - Identify common patterns in factual changes

4. **Export Options**
   - Export comparison data to CSV
   - Generate PDF report with side-by-side layout
   - Create summary dashboards for stakeholders

## Conclusion

By saving the complete structured comparison data to JSON, we enable the dashboard and other tools to display rich, detailed factual accuracy information without needing to re-run the expensive AI analysis. This provides users with instant access to historical comparison data and enables powerful reporting and tracking capabilities.

The structured format with sections, original_text, new_text, and typed differences makes it easy to build sophisticated UIs for reviewing and managing factual accuracy across large content migrations.
