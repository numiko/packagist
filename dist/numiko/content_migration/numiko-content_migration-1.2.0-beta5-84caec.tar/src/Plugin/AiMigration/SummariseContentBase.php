<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

use Drupal\Core\Form\FormStateInterface;
use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Exception\AiProcessingException;
use Drupal\content_migration\Plugin\AiMigration\AiMigrationPluginBase;
use Drupal\content_migration\Service\TaxonomyPromptService;
use Drupal\node\NodeInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Base class for content summarization plugins.
 */
abstract class SummariseContentBase extends AiMigrationPluginBase {

  /**
   * Taxonomy prompt service.
   */
  protected TaxonomyPromptService $taxonomyPrompt;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    $instance = parent::create(
      $container,
      $configuration,
      $plugin_id,
      $plugin_definition,
    );
    $instance->taxonomyPrompt = $container->get(TaxonomyPromptService::class);
    return $instance;
  }

  /**
   * Gets the field title for the form.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup|string
   *   The field title.
   */
  abstract protected function getFieldTitle();

  /**
   * Gets the field description for the form.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup|string
   *   The field description.
   */
  abstract protected function getFieldDescription();

  /**
   * Gets the style title for the form.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup|string
   *   The style title.
   */
  abstract protected function getStyleTitle();

  /**
   * Gets the style description for the form.
   *
   * @return \Drupal\Core\StringTranslation\TranslatableMarkup|string
   *   The style description.
   */
  abstract protected function getStyleDescription();

  /**
   * Gets the available style options.
   *
   * @return array
   *   Array of style options.
   */
  abstract protected function getStyleOptions(): array;

  /**
   * Gets the default style.
   *
   * @return string
   *   The default style key.
   */
  abstract protected function getDefaultStyle(): string;

  /**
   * Gets the default maximum length.
   *
   * @return int
   *   The default maximum length.
   */
  abstract protected function getDefaultMaxLength(): int;

  /**
   * Gets the content type name for prompts.
   *
   * @return string
   *   The content type name (e.g., 'summary', 'introduction').
   */
  abstract protected function getContentTypeName(): string;

  /**
   * Gets style-specific instructions for the content generation.
   *
   * @param string $style
   *   The content style.
   *
   * @return string
   *   The style-specific instructions.
   */
  abstract protected function getStyleInstructions(string $style): string;

  /**
   * Gets the default text format to use when none is configured.
   *
   * @return string
   *   The text format machine name.
   */
  abstract protected function getDefaultTextFormat(): string;

  /**
   * Gets the text format to use for the generated content.
   *
   * Resolves the format from the module's 'field_text_formats' config, keyed
   * by the target field's machine name, falling back to the plugin's default
   * when unset. Keying by field keeps this consistent with the profile-based
   * extraction path, which resolves the same config in NodeBuilderService.
   *
   * @param string $fieldName
   *   The machine name of the target field.
   *
   * @return string
   *   The text format machine name.
   */
  protected function getTextFormat(string $fieldName): string {
    $formats = $this->configFactory
      ->get(ContentMigrationConstants::CONFIG_KEY)
      ->get('field_text_formats') ?? [];

    $format = $formats[$fieldName] ?? '';

    return $format !== '' ? $format : $this->getDefaultTextFormat();
  }

  /**
   * {@inheritdoc}
   */
  public function configurationForm(array $form, FormStateInterface $form_state, array $configuration = []): array {
    $content_type = $form_state->getValue('content_type');

    if (!$content_type) {
      return [
        '#markup' => $this->t('Please select a content type first.'),
      ];
    }

    $field_options = $this->getTextFieldOptionsWithType($content_type);

    // Filter to only show text fields (not paragraphs)
    $target_field_options = array_filter($field_options, fn ($key) => $this->isTextFieldKey($key), ARRAY_FILTER_USE_KEY);

    $form['target_field'] = [
      '#type' => 'select',
      '#title' => $this->getFieldTitle(),
      '#options' => ['' => $this->t('- Select a field -')] + $target_field_options,
      '#default_value' => $configuration['target_field'] ?? '',
      '#description' => $this->getFieldDescription(),
    ];

    $form['max_length'] = [
      '#type' => 'number',
      '#title' => $this->t('Maximum Length'),
      '#default_value' => $configuration['max_length'] ?? $this->getDefaultMaxLength(),
      '#min' => 50,
      '#max' => 1000,
      '#step' => 10,
      '#description' => $this->t('The maximum number of characters for the generated content.'),
    ];

    $form['content_style'] = [
      '#type' => 'select',
      '#title' => $this->getStyleTitle(),
      '#options' => $this->getStyleOptions(),
      '#default_value' => $configuration['content_style'] ?? $this->getDefaultStyle(),
      '#description' => $this->getStyleDescription(),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $target_field_key = $form_state->getValue('target_field');

    // Only validate if field is selected (allowing empty to disable plugin)
    if ($target_field_key) {
      try {
        // Validate composite key format.
        $this->parseCompositeKey($target_field_key);

        // Validate it's a text field.
        if (!$this->isTextFieldKey($target_field_key)) {
          $form_state->setError(
            $form['target_field'],
            $this->t('@field_title must be a text field, not a paragraph field.', ['@field_title' => $this->getFieldTitle()])
          );
        }
      }
      catch (\InvalidArgumentException $e) {
        $form_state->setError(
          $form['target_field'],
          $this->t('Invalid field selection format.')
        );
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function processContent(string $content, NodeInterface $node, array $configuration): array {
    $target_field_key = $configuration['target_field'] ?? '';
    $max_length = (int) ($configuration['max_length'] ?? $this->getDefaultMaxLength());
    $content_style = $configuration['content_style'] ?? $this->getDefaultStyle();

    // If no field configured, skip processing.
    if (empty($target_field_key)) {
      return [
        'skipped' => TRUE,
        'reason' => 'No field configured for this plugin',
      ];
    }

    // Get hierarchical prompts from taxonomy selection if available.
    if (!empty($configuration['taxonomy_term'])) {
      $hierarchical_prompts = $this->taxonomyPrompt->getHierarchicalPrompt((int) $configuration['taxonomy_term']);
      $style_guide = $hierarchical_prompts['style_guide'] ?? '';
      $taxonomy_prompt = $hierarchical_prompts['audience_prompt'] ?? '';

      // Add to configuration for use in prompt building.
      // Always set these, even if empty, to ensure they're available.
      $configuration['style_guide'] = $style_guide;
      $configuration['taxonomy_prompt'] = $taxonomy_prompt;
    }

    // Parse the composite key.
    $field_info = $this->parseCompositeKey($target_field_key);
    $target_field = $field_info['field_name'];

    // Validate it's a text field.
    if (!$this->isTextFieldKey($target_field_key)) {
      throw new AiProcessingException($this->getFieldTitle() . ' must be a text field, not a paragraph field.');
    }

    // Log the configuration being passed to buildContentPrompt.
    $this->logger->info('SummariseContentBase: Configuration being passed to buildContentPrompt - Style Guide: @style_guide, Taxonomy Prompt: @taxonomy_prompt, Taxonomy Term: @taxonomy_term', [
      '@style_guide' => !empty($configuration['style_guide']) ? substr((string) $configuration['style_guide'], 0, 200) . '...' : 'none',
      '@taxonomy_prompt' => !empty($configuration['taxonomy_prompt']) ? substr((string) $configuration['taxonomy_prompt'], 0, 200) . '...' : 'none',
      '@taxonomy_term' => !empty($configuration['taxonomy_term']) ? (string) $configuration['taxonomy_term'] : 'none',
    ]);

    // Build the prompt for generating content.
    $prompt = $this->buildContentPrompt($content, $max_length, $content_style, $configuration);

    // Log the full prompt being sent to Claude.
    $this->logger->info('SummariseContentBase: Full summary prompt being sent to Claude API:<br/><pre>@prompt</pre>', [
      '@prompt' => (string) $prompt,
    ]);

    // Make the API call.
    $generated_content = $this->makeClaudeRequest($prompt);

    // Clean up the content (remove quotes, extra whitespace).
    $generated_content = trim($generated_content, '"\'');
    $generated_content = trim($generated_content);

    // If content is too long, regenerate with stricter prompt.
    if (strlen($generated_content) > $max_length) {
      $this->logger->warning(
        'Generated @content_type was too long (@length chars), regenerating with stricter requirements for node @nid',
        [
          '@content_type' => (string) $this->getContentTypeName(),
          '@length' => (string) strlen($generated_content),
          '@nid' => (string) $node->id(),
        ]
      );

      // Try again with a stricter prompt.
      $strict_prompt = $this->buildStrictLengthPrompt($content, $max_length, $content_style, $configuration);

      // Log the full strict prompt being sent to Claude.
      $this->logger->info('SummariseContentBase: Full strict length prompt being sent to Claude API (content was too long):<br/><pre>@prompt</pre>', [
        '@prompt' => (string) $strict_prompt,
      ]);

      $generated_content = $this->makeClaudeRequest($strict_prompt);
      $generated_content = trim($generated_content, '"\'');
      $generated_content = trim($generated_content);

      // If still too long, intelligently truncate at sentence boundary.
      if (strlen($generated_content) > $max_length) {
        $generated_content = $this->intelligentTruncate($generated_content, $max_length);
      }
    }

    // Set the field on the node.
    $node->set($target_field, [
      'value' => $generated_content,
      'format' => $this->getTextFormat($target_field),
    ]);

    return [
      'generated_content' => $generated_content,
      'field_type' => $field_info['type'],
      'field_name' => $target_field,
      'content_type' => $this->getContentTypeName(),
    ];
  }

  /**
   * Builds the prompt for content generation.
   *
   * @param string $content
   *   The content to process.
   * @param int $max_length
   *   The maximum length of the generated content.
   * @param string $style
   *   The style of content to generate.
   * @param array $configuration
   *   The plugin configuration settings.
   *
   * @return string
   *   The complete prompt for Claude API.
   */
  protected function buildContentPrompt(string $content, int $max_length, string $style, array $configuration = []): string {
    $style_instructions = $this->getStyleInstructions($style);
    $content_type = $this->getContentTypeName();

    // Check if we have hierarchical prompts for style guide and audience
    // targeting.
    $style_guide_section = '';
    $audience_guidance = '';

    if (!empty($configuration['style_guide'])) {
      $style_guide_section = "\n**STYLE GUIDE:**\n" . $configuration['style_guide'] . "\n";
    }

    if (!empty($configuration['taxonomy_prompt'])) {
      $audience_guidance = "\n**AUDIENCE TARGETING:**\n" . $configuration['taxonomy_prompt'] . "\n";
      $this->logger->info('SummariseContentBase: Using hierarchical prompts in buildContentPrompt. Style: @style, Max length: @max_length, Style Guide: @style_guide, Audience: @audience', [
        '@style' => (string) $style,
        '@max_length' => (string) $max_length,
        '@style_guide' => !empty($configuration['style_guide']) ? substr((string) $configuration['style_guide'], 0, 100) . '...' : 'none',
        '@audience' => substr((string) ($configuration['taxonomy_prompt'] ?? ''), 0, 100) . (strlen((string) ($configuration['taxonomy_prompt'] ?? '')) > 100 ? '...' : ''),
      ]);
    }

    return <<<EOT
Please create a {$content_type} of the following content. The {$content_type} MUST be under {$max_length} characters and should {$style_instructions}.{$style_guide_section}{$audience_guidance}

Content to process:
{$content}

**CRITICAL LENGTH REQUIREMENT:**
- The {$content_type} MUST be under {$max_length} characters
- Count characters carefully as you write
- If approaching the limit, complete the current sentence and stop
- Do not exceed {$max_length} characters under any circumstances

**STYLE REQUIREMENTS:**
- {$style_instructions}
- Use UK English spelling
- Do not include quotes around the {$content_type}
- Make it engaging and informative
- Write complete sentences that end naturally

**CRITICAL OUTPUT REQUIREMENTS:**
- Your response must contain ONLY the {$content_type} text, nothing else
- Do not include any explanations, comments, or wrapper text
- Do not wrap the content in code blocks or markdown
- Do not include any text before or after the {$content_type}
- Start immediately with the {$content_type} content
- REMEMBER: Maximum {$max_length} characters!

Please provide only the {$content_type} text, nothing else.
EOT;
  }

  /**
   * Builds a stricter prompt when the first attempt was too long.
   *
   * @param string $content
   *   The content to process.
   * @param int $max_length
   *   The maximum length of the generated content.
   * @param string $style
   *   The style of content to generate.
   * @param array $configuration
   *   The plugin configuration settings.
   *
   * @return string
   *   The strict prompt for Claude API.
   */
  protected function buildStrictLengthPrompt(string $content, int $max_length, string $style, array $configuration = []): string {
    $style_instructions = $this->getStyleInstructions($style);
    $content_type = $this->getContentTypeName();
    // 20 character buffer
    $buffer_length = $max_length - 20;

    // Check if we have hierarchical prompts for style guide and audience targeting.
    $style_guide_section = '';
    $audience_guidance = '';

    if (!empty($configuration['style_guide'])) {
      $style_guide_section = "\n**STYLE GUIDE:**\n" . $configuration['style_guide'] . "\n";
    }

    if (!empty($configuration['taxonomy_prompt'])) {
      $audience_guidance = "\n**AUDIENCE TARGETING:**\n" . $configuration['taxonomy_prompt'] . "\n";
      $this->logger->info('SummariseContentBase: Using hierarchical prompts in buildStrictLengthPrompt (content was too long). Style: @style, Max length: @max_length, Style Guide: @style_guide, Audience: @audience', [
        '@style' => (string) $style,
        '@max_length' => (string) $max_length,
        '@style_guide' => !empty($configuration['style_guide']) ? substr((string) $configuration['style_guide'], 0, 100) . '...' : 'none',
        '@audience' => substr((string) ($configuration['taxonomy_prompt'] ?? ''), 0, 100) . (strlen((string) ($configuration['taxonomy_prompt'] ?? '')) > 100 ? '...' : ''),
      ]);
    }

    return <<<EOT
URGENT: Previous {$content_type} was too long. Create a SHORTER {$content_type} that is STRICTLY under {$max_length} characters.{$style_guide_section}{$audience_guidance}

Content to process:
{$content}

**ABSOLUTE REQUIREMENTS - NO EXCEPTIONS:**
- MAXIMUM {$buffer_length} characters (staying well under {$max_length})
- Count every character including spaces and punctuation
- Stop writing before reaching the limit
- End with a complete sentence
- {$style_instructions}

**STRICT WRITING INSTRUCTIONS:**
- Write concisely and efficiently
- Use shorter sentences
- Avoid unnecessary words
- Focus on the most essential information
- Do not exceed {$buffer_length} characters under any circumstances

**OUTPUT FORMAT:**
- ONLY the {$content_type} text
- No explanations, comments, or wrapper text
- No quotes or markdown
- Must be under {$buffer_length} characters

Write the {$content_type} now, staying well under the character limit:
EOT;
  }

  /**
   * Intelligently truncates content at sentence boundaries.
   *
   * @param string $content
   *   The content to truncate.
   * @param int $max_length
   *   The maximum allowed length.
   *
   * @return string
   *   The truncated content.
   */
  protected function intelligentTruncate(string $content, int $max_length): string {
    // If content is within limit, return as-is.
    if (strlen($content) <= $max_length) {
      return $content;
    }

    // Try to find the last complete sentence within the limit.
    $truncated = substr($content, 0, $max_length);

    // Look for sentence endings (. ! ?) working backwards.
    $sentence_endings = ['. ', '! ', '? '];
    $last_sentence_pos = 0;

    foreach ($sentence_endings as $ending) {
      $pos = strrpos($truncated, $ending);
      if ($pos !== FALSE && $pos > $last_sentence_pos) {
        // Include the punctuation.
        $last_sentence_pos = $pos + strlen($ending) - 1;
      }
    }

    // If we found a sentence boundary, use it.
    if ($last_sentence_pos > 0) {
      return substr($content, 0, $last_sentence_pos + 1);
    }

    // Fallback: look for word boundaries.
    $word_boundary = strrpos($truncated, ' ');
    if ($word_boundary !== FALSE && $word_boundary > ($max_length * 0.7)) {
      return substr($content, 0, $word_boundary);
    }

    // Last resort: hard truncate but log a warning.
    $this->logger->warning(
      'Had to hard-truncate @content_type content - no good sentence or word boundary found',
      ['@content_type' => (string) $this->getContentTypeName()]
    );

    return substr($content, 0, $max_length - 3) . '...';
  }

}
