/**
 * JavaScript for Content Quality Dashboard
 */

(function (Drupal) {
  'use strict';

  Drupal.behaviors.qualityDashboard = {
    attach: function (context, settings) {
      // Handle clickable score cells
      document.querySelectorAll('.clickable-score-cell', context).forEach(function (cell) {
        // Remove existing listeners to prevent duplicates
        var newCell = cell.cloneNode(true);
        cell.parentNode.replaceChild(newCell, cell);

        newCell.addEventListener('click', function (e) {
          e.stopPropagation();

          // Get the node ID and plugin ID from the cell
          var nodeId = this.getAttribute('data-node-id');
          var pluginId = this.getAttribute('data-plugin-id');

          // Find the detail row with matching node ID and plugin ID
          var detailRow = document.querySelector('.detail-row[data-node-id="' + nodeId + '"][data-plugin-id="' + pluginId + '"]');

          if (detailRow) {
            // Close all other detail rows for this node
            document.querySelectorAll('.detail-row[data-node-id="' + nodeId + '"]').forEach(function (row) {
              if (row !== detailRow && row.classList.contains('expanded')) {
                row.classList.remove('expanded');
              }
            });

            // Remove expanded class from all cells in this row
            document.querySelectorAll('.clickable-score-cell[data-node-id="' + nodeId + '"]').forEach(function (c) {
              c.classList.remove('cell-expanded');
            });

            // Toggle the detail row
            detailRow.classList.toggle('expanded');

            // Add visual indication that this cell is expanded
            if (detailRow.classList.contains('expanded')) {
              this.classList.add('cell-expanded');
            }
          }
        });
      });

      // Handle feedback toggle
      document.querySelectorAll('.feedback-toggle', context).forEach(function (toggle) {
        // Remove existing listeners to prevent duplicates
        var newToggle = toggle.cloneNode(true);
        toggle.parentNode.replaceChild(newToggle, toggle);

        newToggle.addEventListener('click', function (e) {
          e.stopPropagation();

          // Find the feedback content
          var feedbackContent = this.nextElementSibling;
          var toggleIcon = this.querySelector('.toggle-icon');

          if (feedbackContent && feedbackContent.classList.contains('feedback-content')) {
            // Toggle visibility
            if (feedbackContent.style.display === 'none') {
              feedbackContent.style.display = 'block';
              if (toggleIcon) {
                toggleIcon.textContent = '▼';
              }
            } else {
              feedbackContent.style.display = 'none';
              if (toggleIcon) {
                toggleIcon.textContent = '▶';
              }
            }
          }
        });
      });
    }
  };

})(Drupal);
