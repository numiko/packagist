<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\Exception\ContentFetchException;
use Drupal\content_migration\Service\HtmlParserService;
use Drupal\content_migration\Service\UrlContentFetcherService;
use Drupal\Tests\UnitTestCase;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the UrlContentFetcherService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\UrlContentFetcherService
 * @group content_migration
 */
class UrlContentFetcherServiceTest extends UnitTestCase {

  /**
   * The service under test.
   *
   * @var \Drupal\content_migration\Service\UrlContentFetcherService
   */
  protected UrlContentFetcherService $service;

  /**
   * Mock HTTP client.
   *
   * @var \GuzzleHttp\ClientInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $httpClient;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * Mock HTML parser service.
   *
   * @var \Drupal\content_migration\Service\HtmlParserService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $htmlParser;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->httpClient = $this->createMock(ClientInterface::class);
    $this->logger = $this->createMock(LoggerInterface::class);
    $this->htmlParser = $this->createMock(HtmlParserService::class);

    $this->service = new UrlContentFetcherService(
      $this->httpClient,
      $this->logger,
      $this->htmlParser
    );
  }

  /**
   * Tests fetchContent returns HTML content successfully.
   *
   * @covers ::fetchContent
   */
  public function testFetchContentSuccess(): void {
    $htmlContent = '<html><body><h1>Test</h1></body></html>';
    $response = new Response(200, ['Content-Type' => 'text/html'], $htmlContent);

    $this->httpClient->expects($this->once())
      ->method('request')
      ->with('GET', 'https://example.com/page', $this->anything())
      ->willReturn($response);

    $result = $this->service->fetchContent('https://example.com/page');

    $this->assertEquals($htmlContent, $result);
  }

  /**
   * Tests fetchContent handles XHTML content type.
   *
   * @covers ::fetchContent
   */
  public function testFetchContentXhtml(): void {
    $htmlContent = '<html><body><h1>XHTML Test</h1></body></html>';
    $response = new Response(200, ['Content-Type' => 'application/xhtml+xml'], $htmlContent);

    $this->httpClient->expects($this->once())
      ->method('request')
      ->willReturn($response);

    $result = $this->service->fetchContent('https://example.com/xhtml');

    $this->assertEquals($htmlContent, $result);
  }

  /**
   * Tests fetchContent throws exception for invalid content type.
   *
   * @covers ::fetchContent
   */
  public function testFetchContentInvalidContentType(): void {
    $response = new Response(200, ['Content-Type' => 'application/json'], '{"data": "test"}');

    $this->httpClient->expects($this->once())
      ->method('request')
      ->willReturn($response);

    $this->expectException(ContentFetchException::class);

    $this->service->fetchContent('https://example.com/api');
  }

  /**
   * Tests fetchContent throws exception for empty response.
   *
   * @covers ::fetchContent
   */
  public function testFetchContentEmptyResponse(): void {
    $response = new Response(200, ['Content-Type' => 'text/html'], '');

    $this->httpClient->expects($this->once())
      ->method('request')
      ->willReturn($response);

    $this->expectException(ContentFetchException::class);

    $this->service->fetchContent('https://example.com/empty');
  }

  /**
   * Tests fetchContent throws exception on HTTP error.
   *
   * @covers ::fetchContent
   */
  public function testFetchContentHttpError(): void {
    $request = new Request('GET', 'https://example.com/404');
    $exception = new RequestException('Not Found', $request, new Response(404));

    $this->httpClient->expects($this->once())
      ->method('request')
      ->willThrowException($exception);

    $this->logger->expects($this->once())
      ->method('error');

    $this->expectException(ContentFetchException::class);

    $this->service->fetchContent('https://example.com/404');
  }

  /**
   * Tests sanitizeHtml delegates to HtmlParserService.
   *
   * @covers ::sanitizeHtml
   */
  public function testSanitizeHtmlDelegates(): void {
    $this->htmlParser->expects($this->once())
      ->method('sanitizeHtml')
      ->with('<html>test</html>', 'article', NULL, NULL)
      ->willReturn(['title' => 'Test', 'content' => 'test']);

    $result = $this->service->sanitizeHtml('<html>test</html>');

    $this->assertEquals('Test', $result['title']);
    $this->assertEquals('test', $result['content']);
  }

  /**
   * Tests extractWithProfile delegates to HtmlParserService.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfileDelegates(): void {
    $profile = ['mappings' => []];
    $expectedResult = ['title' => 'Test', 'extractions' => []];

    $this->htmlParser->expects($this->once())
      ->method('extractWithProfile')
      ->with('<html>test</html>', $profile)
      ->willReturn($expectedResult);

    $result = $this->service->extractWithProfile('<html>test</html>', $profile);

    $this->assertEquals($expectedResult, $result);
  }

  /**
   * Tests applyHighlights delegates to HtmlParserService.
   *
   * @covers ::applyHighlights
   */
  public function testApplyHighlightsDelegates(): void {
    $highlights = [['selector' => '.test', 'color' => 'yellow']];

    $this->htmlParser->expects($this->once())
      ->method('applyHighlights')
      ->with('<p>test</p>', $highlights)
      ->willReturn('<p class="highlight">test</p>');

    $result = $this->service->applyHighlights('<p>test</p>', $highlights);

    $this->assertEquals('<p class="highlight">test</p>', $result);
  }

  /**
   * Tests getHtmlParser returns the parser service.
   *
   * @covers ::getHtmlParser
   */
  public function testGetHtmlParser(): void {
    $result = $this->service->getHtmlParser();
    $this->assertSame($this->htmlParser, $result);
  }

}
