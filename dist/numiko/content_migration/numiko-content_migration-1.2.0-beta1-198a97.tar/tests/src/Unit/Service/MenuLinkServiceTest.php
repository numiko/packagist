<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\menu_link_content\MenuLinkContentInterface;
use Drupal\node\NodeInterface;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the MenuLinkService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\MenuLinkService
 * @group content_migration
 */
class MenuLinkServiceTest extends UnitTestCase {

  /**
   * The menu link service under test.
   *
   * @var \Drupal\content_migration\Service\MenuLinkService
   */
  protected MenuLinkService $menuLinkService;

  /**
   * Mock entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $entityTypeManager;

  /**
   * Mock messenger.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $messenger;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $this->messenger = $this->createMock(MessengerInterface::class);
    $this->logger = $this->createMock(LoggerInterface::class);

    $this->menuLinkService = new MenuLinkService(
      $this->entityTypeManager,
      $this->messenger,
      $this->logger
    );
    $this->menuLinkService->setStringTranslation($this->getStringTranslationStub());
  }

  /**
   * Tests createMenuLink creates menu link with correct parameters.
   *
   * @covers ::createMenuLink
   */
  public function testCreateMenuLink(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');
    $mockNode->method('getTitle')->willReturn('Test Page');

    $mockMenuLink = $this->createMock(MenuLinkContentInterface::class);
    $mockStorage = $this->createMock(EntityStorageInterface::class);

    $mockStorage->expects($this->once())
      ->method('create')
      ->with([
        'title' => 'Test Page',
        'link' => ['uri' => 'entity:node/123'],
        'menu_name' => ContentMigrationConstants::DEFAULT_MENU_NAME,
        'weight' => 0,
        'expanded' => FALSE,
        'enabled' => TRUE,
      ])
      ->willReturn($mockMenuLink);

    $mockMenuLink->expects($this->once())
      ->method('save');

    $this->entityTypeManager->expects($this->once())
      ->method('getStorage')
      ->with('menu_link_content')
      ->willReturn($mockStorage);

    $result = $this->menuLinkService->createMenuLink($mockNode);
    $this->assertSame($mockMenuLink, $result);
  }

  /**
   * Tests createMenuLink with parent menu item.
   *
   * @covers ::createMenuLink
   */
  public function testCreateMenuLinkWithParent(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('456');
    $mockNode->method('getTitle')->willReturn('Child Page');

    $mockMenuLink = $this->createMock(MenuLinkContentInterface::class);
    $mockStorage = $this->createMock(EntityStorageInterface::class);

    $mockStorage->expects($this->once())
      ->method('create')
      ->with([
        'title' => 'Child Page',
        'link' => ['uri' => 'entity:node/456'],
        'menu_name' => 'main',
        'weight' => 5,
        'expanded' => TRUE,
        'enabled' => TRUE,
        'parent' => 'menu_link_content:parent-uuid',
      ])
      ->willReturn($mockMenuLink);

    $mockMenuLink->expects($this->once())
      ->method('save');

    $this->entityTypeManager->expects($this->once())
      ->method('getStorage')
      ->with('menu_link_content')
      ->willReturn($mockStorage);

    $result = $this->menuLinkService->createMenuLink(
      $mockNode,
      'menu_link_content:parent-uuid',
      'main',
      5,
      TRUE
    );
    $this->assertSame($mockMenuLink, $result);
  }

  /**
   * Tests createMenuLink handles exception gracefully.
   *
   * @covers ::createMenuLink
   */
  public function testCreateMenuLinkException(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('789');
    $mockNode->method('getTitle')->willReturn('Error Page');

    $mockStorage = $this->createMock(EntityStorageInterface::class);
    $mockStorage->expects($this->once())
      ->method('create')
      ->willThrowException(new \Exception('Database error'));

    $this->entityTypeManager->expects($this->once())
      ->method('getStorage')
      ->with('menu_link_content')
      ->willReturn($mockStorage);

    $this->logger->expects($this->once())
      ->method('error');

    $this->messenger->expects($this->once())
      ->method('addWarning');

    $result = $this->menuLinkService->createMenuLink($mockNode);
    $this->assertNull($result);
  }

  /**
   * Tests createHierarchicalMenuLink creates link with expanded flag.
   *
   * @covers ::createHierarchicalMenuLink
   */
  public function testCreateHierarchicalMenuLink(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('100');

    $mockMenuLink = $this->createMock(MenuLinkContentInterface::class);
    $mockStorage = $this->createMock(EntityStorageInterface::class);

    $mockStorage->expects($this->once())
      ->method('create')
      ->with([
        'title' => 'Hierarchy Page',
        'link' => ['uri' => 'entity:node/100'],
        'menu_name' => 'main',
        'weight' => 2,
        'expanded' => TRUE,
        'enabled' => TRUE,
      ])
      ->willReturn($mockMenuLink);

    $mockMenuLink->expects($this->once())
      ->method('save');

    $this->entityTypeManager->expects($this->once())
      ->method('getStorage')
      ->with('menu_link_content')
      ->willReturn($mockStorage);

    $result = $this->menuLinkService->createHierarchicalMenuLink(
      $mockNode,
      'Hierarchy Page',
      NULL,
      2
    );
    $this->assertSame($mockMenuLink, $result);
  }

  /**
   * Tests getPluginId retrieves plugin ID from menu link.
   *
   * @covers ::getPluginId
   */
  public function testGetPluginId(): void {
    $mockMenuLink = $this->createMock(MenuLinkContentInterface::class);
    $mockMenuLink->expects($this->once())
      ->method('getPluginId')
      ->willReturn('menu_link_content:test-uuid');

    $result = $this->menuLinkService->getPluginId($mockMenuLink);
    $this->assertEquals('menu_link_content:test-uuid', $result);
  }

}
