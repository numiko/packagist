<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\Service\TaxonomyPromptService;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\taxonomy\TermInterface;
use Drupal\taxonomy\VocabularyInterface;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for the TaxonomyPromptService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\TaxonomyPromptService
 * @group content_migration
 */
class TaxonomyPromptServiceTest extends UnitTestCase {

  /**
   * The service under test.
   *
   * @var \Drupal\content_migration\Service\TaxonomyPromptService
   */
  protected TaxonomyPromptService $service;

  /**
   * Mock entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $this->service = new TaxonomyPromptService($this->entityTypeManager);
  }

  /**
   * Tests getVocabularyOptions returns vocabulary list.
   *
   * @covers ::getVocabularyOptions
   */
  public function testGetVocabularyOptions(): void {
    $mockVocab1 = $this->createMock(VocabularyInterface::class);
    $mockVocab1->method('id')->willReturn('tags');
    $mockVocab1->method('label')->willReturn('Tags');

    $mockVocab2 = $this->createMock(VocabularyInterface::class);
    $mockVocab2->method('id')->willReturn('audience');
    $mockVocab2->method('label')->willReturn('Audience');

    $mockStorage = $this->createMock(EntityStorageInterface::class);
    $mockStorage->method('loadMultiple')
      ->willReturn(['tags' => $mockVocab1, 'audience' => $mockVocab2]);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_vocabulary')
      ->willReturn($mockStorage);

    $options = $this->service->getVocabularyOptions();

    $this->assertArrayHasKey('', $options);
    $this->assertEquals('- None -', $options['']);
    $this->assertArrayHasKey('tags', $options);
    $this->assertEquals('Tags', $options['tags']);
    $this->assertArrayHasKey('audience', $options);
    $this->assertEquals('Audience', $options['audience']);
  }

  /**
   * Tests getTermsWithPrompts returns empty array for empty vocabulary ID.
   *
   * @covers ::getTermsWithPrompts
   */
  public function testGetTermsWithPromptsEmptyVocabulary(): void {
    $result = $this->service->getTermsWithPrompts('');
    $this->assertEmpty($result);
  }

  /**
   * Tests getTermPrompt returns null for non-existent term.
   *
   * @covers ::getTermPrompt
   */
  public function testGetTermPromptNonExistent(): void {
    $mockStorage = $this->createMock(EntityStorageInterface::class);
    $mockStorage->method('load')
      ->with(999)
      ->willReturn(NULL);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->getTermPrompt(999);
    $this->assertNull($result);
  }

  /**
   * Tests getTermPrompt returns description for existing term.
   *
   * @covers ::getTermPrompt
   */
  public function testGetTermPromptReturnsDescription(): void {
    $mockTerm = $this->createMock(TermInterface::class);
    $mockTerm->method('getDescription')
      ->willReturn('This is the prompt for the term.');

    $mockStorage = $this->createMock(EntityStorageInterface::class);
    $mockStorage->method('load')
      ->with(42)
      ->willReturn($mockTerm);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->getTermPrompt(42);
    $this->assertEquals('This is the prompt for the term.', $result);
  }

  /**
   * Tests getHierarchicalPrompt returns empty for non-existent term.
   *
   * @covers ::getHierarchicalPrompt
   */
  public function testGetHierarchicalPromptNonExistent(): void {
    $mockStorage = $this->createMock(EntityStorageInterface::class);
    $mockStorage->method('load')
      ->with(999)
      ->willReturn(NULL);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->getHierarchicalPrompt(999);
    $this->assertEquals('', $result['style_guide']);
    $this->assertEquals('', $result['audience_prompt']);
  }

  /**
   * Tests vocabularyHasTermsWithPrompts returns false for empty vocabulary.
   *
   * @covers ::vocabularyHasTermsWithPrompts
   */
  public function testVocabularyHasTermsWithPromptsEmpty(): void {
    // Create a mock with the loadTree method since TermStorageInterface has it.
    $mockStorage = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['loadTree'])
      ->getMock();
    $mockStorage->method('loadTree')
      ->willReturn([]);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->vocabularyHasTermsWithPrompts('empty_vocab');
    $this->assertFalse($result);
  }

}
