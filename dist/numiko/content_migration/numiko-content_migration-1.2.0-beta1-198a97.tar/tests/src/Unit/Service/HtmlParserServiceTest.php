<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Service\HtmlParserService;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the HtmlParserService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\HtmlParserService
 * @group content_migration
 */
class HtmlParserServiceTest extends UnitTestCase {

  /**
   * The HTML parser service under test.
   *
   * @var \Drupal\content_migration\Service\HtmlParserService
   */
  protected HtmlParserService $htmlParser;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->logger = $this->createMock(LoggerInterface::class);
    $this->htmlParser = new HtmlParserService($this->logger);
  }

  /**
   * Tests cssToXPath conversion with simple selectors.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathSimpleTag(): void {
    $xpath = $this->htmlParser->cssToXPath('div');
    $this->assertEquals('//div', $xpath);
  }

  /**
   * Tests cssToXPath conversion with class selectors.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathClass(): void {
    $xpath = $this->htmlParser->cssToXPath('.content');
    $this->assertEquals("//*[contains(concat(' ', normalize-space(@class), ' '), ' content ')]", $xpath);
  }

  /**
   * Tests cssToXPath conversion with ID selectors.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathId(): void {
    $xpath = $this->htmlParser->cssToXPath('#main');
    $this->assertEquals("//*[@id='main']", $xpath);
  }

  /**
   * Tests cssToXPath conversion with tag and class.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathTagAndClass(): void {
    $xpath = $this->htmlParser->cssToXPath('div.content');
    $this->assertEquals("//div[contains(concat(' ', normalize-space(@class), ' '), ' content ')]", $xpath);
  }

  /**
   * Tests cssToXPath conversion with tag and ID.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathTagAndId(): void {
    $xpath = $this->htmlParser->cssToXPath('div#main');
    $this->assertEquals("//div[@id='main']", $xpath);
  }

  /**
   * Tests cssToXPath conversion with descendant combinator.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathDescendant(): void {
    $xpath = $this->htmlParser->cssToXPath('div p');
    $this->assertEquals('//div//p', $xpath);
  }

  /**
   * Tests extractPlainText removes HTML tags.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextRemovesTags(): void {
    $html = '<p>Hello <strong>World</strong></p>';
    $result = $this->htmlParser->extractPlainText($html);
    $this->assertEquals("Hello World", $result);
  }

  /**
   * Tests extractPlainText preserves paragraph breaks.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextPreservesParagraphs(): void {
    $html = '<p>First paragraph.</p><p>Second paragraph.</p>';
    $result = $this->htmlParser->extractPlainText($html);
    $this->assertStringContainsString("First paragraph.", $result);
    $this->assertStringContainsString("Second paragraph.", $result);
  }

  /**
   * Tests extractPlainText handles empty input.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextEmpty(): void {
    $result = $this->htmlParser->extractPlainText('');
    $this->assertEquals('', $result);
  }

  /**
   * Tests extractPlainText handles whitespace-only input.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextWhitespace(): void {
    $result = $this->htmlParser->extractPlainText('   ');
    $this->assertEquals('', $result);
  }

  /**
   * Tests sanitizeHtml in article mode.
   *
   * @covers ::sanitizeHtml
   */
  public function testSanitizeHtmlArticleMode(): void {
    $html = '<!DOCTYPE html><html><head><title>Test Page</title></head><body><article><h1>Title</h1><p>Content</p></article></body></html>';
    $result = $this->htmlParser->sanitizeHtml($html, ContentMigrationConstants::EXTRACTION_MODE_ARTICLE);

    $this->assertArrayHasKey('title', $result);
    $this->assertArrayHasKey('content', $result);
  }

  /**
   * Tests sanitizeHtml in full page mode.
   *
   * @covers ::sanitizeHtml
   */
  public function testSanitizeHtmlFullPageMode(): void {
    $html = '<!DOCTYPE html><html><head><title>Test Page</title></head><body><div class="content"><h1>Title</h1><p>Content</p></div></body></html>';
    $result = $this->htmlParser->sanitizeHtml($html, ContentMigrationConstants::EXTRACTION_MODE_FULL_PAGE);

    $this->assertArrayHasKey('title', $result);
    $this->assertArrayHasKey('content', $result);
  }

  /**
   * Tests applyHighlights adds styles to matching elements.
   *
   * @covers ::applyHighlights
   */
  public function testApplyHighlights(): void {
    $html = '<div><p class="highlight-me">Content</p></div>';
    $highlights = [
      [
        'selector' => '.highlight-me',
        'color' => 'yellow',
      ],
    ];

    $result = $this->htmlParser->applyHighlights($html, $highlights);
    $this->assertStringContainsString('background-color: yellow', $result);
  }

  /**
   * Tests applyHighlights with empty highlights array.
   *
   * @covers ::applyHighlights
   */
  public function testApplyHighlightsEmpty(): void {
    $html = '<div><p>Content</p></div>';
    $result = $this->htmlParser->applyHighlights($html, []);
    $this->assertEquals($html, $result);
  }

  /**
   * Tests extractWithProfile with basic profile.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfile(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body><div class="content"><p>Content here</p></div></body></html>';
    $profile = [
      'label' => 'Test Profile',
      'mappings' => [
        [
          'selector' => '.content',
          'target_field' => 'entity_reference_revisions:field_content',
          'paragraph_type' => 'slice_content',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertArrayHasKey('title', $result);
    $this->assertArrayHasKey('extractions', $result);
    $this->assertEquals('Test', $result['title']);
    // Each extraction now has its own target_field.
    $this->assertNotEmpty($result['extractions']);
    $this->assertArrayHasKey('target_field', $result['extractions'][0]);
    $this->assertEquals('entity_reference_revisions:field_content', $result['extractions'][0]['target_field']);
    $this->assertEquals('slice_content', $result['extractions'][0]['paragraph_type']);
  }

}
