<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\ParagraphInterface;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the NodeBuilderService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\NodeBuilderService
 * @group content_migration
 */
class NodeBuilderServiceTest extends UnitTestCase {

  /**
   * The node builder service under test.
   *
   * @var \Drupal\content_migration\Service\NodeBuilderService
   */
  protected NodeBuilderService $nodeBuilder;

  /**
   * Mock entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $entityTypeManager;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $this->logger = $this->createMock(LoggerInterface::class);

    $this->nodeBuilder = new NodeBuilderService(
      $this->entityTypeManager,
      $this->logger
    );
  }

  /**
   * Tests parseCompositeKey with full composite key.
   *
   * @covers ::parseCompositeKey
   */
  public function testParseCompositeKeyFull(): void {
    $result = $this->nodeBuilder->parseCompositeKey('paragraph:field_content');

    $this->assertEquals('paragraph', $result['type']);
    $this->assertEquals('field_content', $result['name']);
    $this->assertTrue($result['is_paragraph']);
  }

  /**
   * Tests parseCompositeKey with entity_reference_revisions type.
   *
   * @covers ::parseCompositeKey
   */
  public function testParseCompositeKeyEntityReference(): void {
    $result = $this->nodeBuilder->parseCompositeKey('entity_reference_revisions:field_slices');

    $this->assertEquals('entity_reference_revisions', $result['type']);
    $this->assertEquals('field_slices', $result['name']);
    $this->assertTrue($result['is_paragraph']);
  }

  /**
   * Tests parseCompositeKey with text type.
   *
   * @covers ::parseCompositeKey
   */
  public function testParseCompositeKeyText(): void {
    $result = $this->nodeBuilder->parseCompositeKey('text:field_body');

    $this->assertEquals('text', $result['type']);
    $this->assertEquals('field_body', $result['name']);
    $this->assertFalse($result['is_paragraph']);
  }

  /**
   * Tests parseCompositeKey with simple field name (no delimiter).
   *
   * @covers ::parseCompositeKey
   */
  public function testParseCompositeKeySimple(): void {
    $result = $this->nodeBuilder->parseCompositeKey('field_body');

    $this->assertEquals('text', $result['type']);
    $this->assertEquals('field_body', $result['name']);
    $this->assertFalse($result['is_paragraph']);
  }

  /**
   * Tests isParagraphField returns true for paragraph type.
   *
   * @covers ::isParagraphField
   */
  public function testIsParagraphFieldTrue(): void {
    $this->assertTrue($this->nodeBuilder->isParagraphField('paragraph:field_content'));
    $this->assertTrue($this->nodeBuilder->isParagraphField('entity_reference_revisions:field_slices'));
  }

  /**
   * Tests isParagraphField returns false for text types.
   *
   * @covers ::isParagraphField
   */
  public function testIsParagraphFieldFalse(): void {
    $this->assertFalse($this->nodeBuilder->isParagraphField('text:field_body'));
    $this->assertFalse($this->nodeBuilder->isParagraphField('field_body'));
    $this->assertFalse($this->nodeBuilder->isParagraphField('text_with_summary:field_intro'));
  }

  /**
   * Tests createNode creates node with correct parameters.
   *
   * @covers ::createNode
   */
  public function testCreateNode(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockStorage = $this->createMock(EntityStorageInterface::class);

    $mockStorage->expects($this->once())
      ->method('create')
      ->with([
        'type' => 'article',
        'title' => 'Test Title',
        'status' => 1,
        'uid' => ContentMigrationConstants::DEFAULT_ADMIN_UID,
      ])
      ->willReturn($mockNode);

    $this->entityTypeManager->expects($this->once())
      ->method('getStorage')
      ->with('node')
      ->willReturn($mockStorage);

    $result = $this->nodeBuilder->createNode('article', 'Test Title');
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests createNode with custom user ID.
   *
   * @covers ::createNode
   */
  public function testCreateNodeWithCustomUid(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockStorage = $this->createMock(EntityStorageInterface::class);

    $mockStorage->expects($this->once())
      ->method('create')
      ->with([
        'type' => 'page',
        'title' => 'Custom Page',
        'status' => 1,
        'uid' => 5,
      ])
      ->willReturn($mockNode);

    $this->entityTypeManager->expects($this->once())
      ->method('getStorage')
      ->with('node')
      ->willReturn($mockStorage);

    $result = $this->nodeBuilder->createNode('page', 'Custom Page', 5);
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests createNode with unpublished status.
   *
   * @covers ::createNode
   */
  public function testCreateNodeUnpublished(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockStorage = $this->createMock(EntityStorageInterface::class);

    $mockStorage->expects($this->once())
      ->method('create')
      ->with([
        'type' => 'draft',
        'title' => 'Draft Page',
        'status' => 0,
        'uid' => ContentMigrationConstants::DEFAULT_ADMIN_UID,
      ])
      ->willReturn($mockNode);

    $this->entityTypeManager->expects($this->once())
      ->method('getStorage')
      ->with('node')
      ->willReturn($mockStorage);

    $result = $this->nodeBuilder->createNode('draft', 'Draft Page', NULL, FALSE);
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests createParagraph creates paragraph with correct parameters.
   *
   * @covers ::createParagraph
   */
  public function testCreateParagraph(): void {
    $mockParagraph = $this->createMock(ParagraphInterface::class);
    $mockStorage = $this->createMock(EntityStorageInterface::class);

    $mockStorage->expects($this->once())
      ->method('create')
      ->with([
        'type' => 'slice_content',
        'field_content' => [
          'value' => '<p>Test content</p>',
          'format' => ContentMigrationConstants::DEFAULT_TEXT_FORMAT_FULL,
        ],
      ])
      ->willReturn($mockParagraph);

    $this->entityTypeManager->expects($this->once())
      ->method('getStorage')
      ->with('paragraph')
      ->willReturn($mockStorage);

    $result = $this->nodeBuilder->createParagraph('slice_content', '<p>Test content</p>');
    $this->assertSame($mockParagraph, $result);
  }

  /**
   * Tests extractPlainText removes HTML tags.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainText(): void {
    $html = '<p>Hello <strong>World</strong>!</p>';
    $result = $this->nodeBuilder->extractPlainText($html);
    $this->assertEquals("Hello World!", $result);
  }

  /**
   * Tests extractPlainText handles empty input.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextEmpty(): void {
    $this->assertEquals('', $this->nodeBuilder->extractPlainText(''));
    $this->assertEquals('', $this->nodeBuilder->extractPlainText('  '));
  }

  /**
   * Tests extractPlainText preserves line breaks.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextPreservesBreaks(): void {
    $html = '<p>First</p><p>Second</p>';
    $result = $this->nodeBuilder->extractPlainText($html);
    $this->assertStringContainsString('First', $result);
    $this->assertStringContainsString('Second', $result);
  }

  /**
   * Tests getTruncationWarnings returns empty array initially.
   *
   * @covers ::getTruncationWarnings
   */
  public function testGetTruncationWarningsEmpty(): void {
    $warnings = $this->nodeBuilder->getTruncationWarnings();
    $this->assertIsArray($warnings);
    $this->assertEmpty($warnings);
  }

  /**
   * Tests clearTruncationWarnings clears any stored warnings.
   *
   * @covers ::clearTruncationWarnings
   */
  public function testClearTruncationWarnings(): void {
    // This just ensures the method doesn't throw an error.
    $this->nodeBuilder->clearTruncationWarnings();
    $warnings = $this->nodeBuilder->getTruncationWarnings();
    $this->assertEmpty($warnings);
  }

  /**
   * Tests setFieldValue strips HTML for plain text fields.
   *
   * @covers ::setFieldValue
   */
  public function testSetFieldValueStripsHtmlForPlainTextField(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockFieldDefinition = $this->createMock(FieldDefinitionInterface::class);

    // Set up field definition to return 'string' type (plain text).
    $mockFieldDefinition->expects($this->atLeastOnce())
      ->method('getType')
      ->willReturn('string');

    $mockFieldDefinition->expects($this->any())
      ->method('getSetting')
      ->with('max_length')
      ->willReturn(255);

    $mockNode->expects($this->atLeastOnce())
      ->method('hasField')
      ->with('field_phone')
      ->willReturn(TRUE);

    $mockNode->expects($this->atLeastOnce())
      ->method('getFieldDefinition')
      ->with('field_phone')
      ->willReturn($mockFieldDefinition);

    // Expect the value to be plain text (HTML stripped).
    $mockNode->expects($this->once())
      ->method('set')
      ->with('field_phone', '01onal 865 616711');

    $htmlContent = '<div class="contact"><span>01onal 865 616711</span></div>';
    $this->nodeBuilder->setFieldValue($mockNode, 'string:field_phone', $htmlContent);
  }

  /**
   * Tests setFieldValue preserves HTML for formatted text fields.
   *
   * @covers ::setFieldValue
   */
  public function testSetFieldValuePreservesHtmlForFormattedTextField(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockFieldDefinition = $this->createMock(FieldDefinitionInterface::class);

    // Set up field definition to return 'text_long' type (formatted text).
    $mockFieldDefinition->expects($this->atLeastOnce())
      ->method('getType')
      ->willReturn('text_long');

    $mockFieldDefinition->expects($this->any())
      ->method('getSetting')
      ->with('max_length')
      ->willReturn(NULL);

    $mockNode->expects($this->atLeastOnce())
      ->method('hasField')
      ->with('field_body')
      ->willReturn(TRUE);

    $mockNode->expects($this->atLeastOnce())
      ->method('getFieldDefinition')
      ->with('field_body')
      ->willReturn($mockFieldDefinition);

    // Expect the value to preserve HTML formatting.
    $htmlContent = '<p>Hello <strong>World</strong></p>';
    $mockNode->expects($this->once())
      ->method('set')
      ->with('field_body', [
        'value' => $htmlContent,
        'format' => ContentMigrationConstants::DEFAULT_TEXT_FORMAT_BASIC,
      ]);

    $this->nodeBuilder->setFieldValue($mockNode, 'text_long:field_body', $htmlContent);
  }

  /**
   * Tests extractEmailFromHtml extracts email from mailto link.
   *
   * @covers ::extractEmailFromHtml
   */
  public function testExtractEmailFromMailtoLink(): void {
    $html = '<div class="contact"><a href="mailto:test@example.com">Contact Us</a></div>';
    $result = $this->nodeBuilder->extractEmailFromHtml($html);
    $this->assertEquals('test@example.com', $result);
  }

  /**
   * Tests extractEmailFromHtml extracts email from mailto link with query params.
   *
   * @covers ::extractEmailFromHtml
   */
  public function testExtractEmailFromMailtoLinkWithParams(): void {
    $html = '<a href="mailto:info@company.org?subject=Hello">Email us</a>';
    $result = $this->nodeBuilder->extractEmailFromHtml($html);
    $this->assertEquals('info@company.org', $result);
  }

  /**
   * Tests extractEmailFromHtml extracts email from text content.
   *
   * @covers ::extractEmailFromHtml
   */
  public function testExtractEmailFromTextContent(): void {
    $html = '<div class="email-field"><span>support@website.net</span></div>';
    $result = $this->nodeBuilder->extractEmailFromHtml($html);
    $this->assertEquals('support@website.net', $result);
  }

  /**
   * Tests extractEmailFromHtml handles plain text email.
   *
   * @covers ::extractEmailFromHtml
   */
  public function testExtractEmailFromPlainText(): void {
    $html = 'user@domain.co.uk';
    $result = $this->nodeBuilder->extractEmailFromHtml($html);
    $this->assertEquals('user@domain.co.uk', $result);
  }

  /**
   * Tests extractEmailFromHtml returns empty for invalid email.
   *
   * @covers ::extractEmailFromHtml
   */
  public function testExtractEmailFromInvalidContent(): void {
    $this->logger->expects($this->once())
      ->method('warning');

    $html = '<div class="email">Not an email address</div>';
    $result = $this->nodeBuilder->extractEmailFromHtml($html);
    $this->assertEquals('', $result);
  }

  /**
   * Tests extractEmailFromHtml handles empty input.
   *
   * @covers ::extractEmailFromHtml
   */
  public function testExtractEmailFromEmpty(): void {
    $this->assertEquals('', $this->nodeBuilder->extractEmailFromHtml(''));
    $this->assertEquals('', $this->nodeBuilder->extractEmailFromHtml('   '));
  }

  /**
   * Tests extractEmailFromHtml extracts email from complex nested HTML.
   *
   * @covers ::extractEmailFromHtml
   */
  public function testExtractEmailFromNestedHtml(): void {
    $html = '<div class="field-name-field-contact-email">
      <div class="field-items">
        <div class="field-item even">
          <a href="mailto:contact@organization.com">contact@organization.com</a>
        </div>
      </div>
    </div>';
    $result = $this->nodeBuilder->extractEmailFromHtml($html);
    $this->assertEquals('contact@organization.com', $result);
  }

  /**
   * Tests extractEmailFromHtml decodes Cloudflare protected email.
   *
   * @covers ::extractEmailFromHtml
   */
  public function testExtractEmailFromCloudflareProtected(): void {
    // Real example from Cloudflare email protection.
    $html = '<div class="field field-name-field-contact-email field-type-email field-label-hidden">
      <span class="field-item-single">
        <a href="/cdn-cgi/l/email-protection#07736f686a6674296f666b6247657464296877296662297268">
          <span class="__cf_email__" data-cfemail="07736f686a6674296f666b6247657464296877296662297268">[email protected]</span>
        </a>
      </span>
    </div>';
    $result = $this->nodeBuilder->extractEmailFromHtml($html);
    // The encoded value 07736f686a6674296f666b6247657464296877296662297268 should decode to an email.
    $this->assertNotEmpty($result);
    $this->assertMatchesRegularExpression('/^[^@]+@[^@]+\.[^@]+$/', $result);
  }

  /**
   * Tests extractEmailFromHtml with the example Cloudflare encoding.
   *
   * @covers ::extractEmailFromHtml
   */
  public function testExtractEmailFromCloudflareExample(): void {
    // Using the example from the user: data-cfemail="07736f686a6674296f666b624765746029687f29666429726c"
    $html = '<span class="__cf_email__" data-cfemail="07736f686a6674296f666b6247657460296877296662297268">[email protected]</span>';
    $result = $this->nodeBuilder->extractEmailFromHtml($html);
    $this->assertNotEmpty($result);
    // Should be a valid email format.
    $this->assertNotFalse(filter_var($result, FILTER_VALIDATE_EMAIL));
  }

  /**
   * Tests setFieldValue extracts email correctly for email field type.
   *
   * @covers ::setFieldValue
   */
  public function testSetFieldValueExtractsEmailForEmailField(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockFieldDefinition = $this->createMock(FieldDefinitionInterface::class);

    // Set up field definition to return 'email' type.
    $mockFieldDefinition->expects($this->atLeastOnce())
      ->method('getType')
      ->willReturn('email');

    $mockFieldDefinition->expects($this->any())
      ->method('getSetting')
      ->with('max_length')
      ->willReturn(NULL);

    $mockNode->expects($this->atLeastOnce())
      ->method('hasField')
      ->with('field_email')
      ->willReturn(TRUE);

    $mockNode->expects($this->atLeastOnce())
      ->method('getFieldDefinition')
      ->with('field_email')
      ->willReturn($mockFieldDefinition);

    // Expect the value to be the extracted email address.
    $mockNode->expects($this->once())
      ->method('set')
      ->with('field_email', 'hello@example.com');

    $htmlContent = '<a href="mailto:hello@example.com">Email us</a>';
    $this->nodeBuilder->setFieldValue($mockNode, 'email:field_email', $htmlContent);
  }

}
