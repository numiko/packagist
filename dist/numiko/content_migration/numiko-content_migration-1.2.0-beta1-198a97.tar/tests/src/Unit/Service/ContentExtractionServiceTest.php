<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Exception\ExtractionProfileNotFoundException;
use Drupal\content_migration\Service\ContentExtractionService;
use Drupal\content_migration\Service\HtmlParserService;
use Drupal\content_migration\Service\UrlContentFetcherService;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the ContentExtractionService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\ContentExtractionService
 * @group content_migration
 */
class ContentExtractionServiceTest extends UnitTestCase {

  /**
   * The content extraction service under test.
   *
   * @var \Drupal\content_migration\Service\ContentExtractionService
   */
  protected ContentExtractionService $contentExtractionService;

  /**
   * Mock URL content fetcher service.
   *
   * @var \Drupal\content_migration\Service\UrlContentFetcherService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $urlContentFetcher;

  /**
   * Mock HTML parser service.
   *
   * @var \Drupal\content_migration\Service\HtmlParserService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $htmlParser;

  /**
   * Mock config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $configFactory;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * Mock config object.
   *
   * @var \Drupal\Core\Config\ImmutableConfig|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $config;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->urlContentFetcher = $this->createMock(UrlContentFetcherService::class);
    $this->htmlParser = $this->createMock(HtmlParserService::class);
    $this->configFactory = $this->createMock(ConfigFactoryInterface::class);
    $this->logger = $this->createMock(LoggerInterface::class);
    $this->config = $this->createMock(ImmutableConfig::class);

    $this->configFactory->method('get')
      ->with(ContentMigrationConstants::CONFIG_KEY)
      ->willReturn($this->config);

    $this->contentExtractionService = new ContentExtractionService(
      $this->urlContentFetcher,
      $this->htmlParser,
      $this->configFactory,
      $this->logger
    );
  }

  /**
   * Tests extractFromUrl fetches and parses content.
   *
   * @covers ::extractFromUrl
   */
  public function testExtractFromUrl(): void {
    $url = 'https://example.com/page';
    $htmlContent = '<html><body><p>Content</p></body></html>';
    $expectedResult = ['title' => 'Test', 'content' => '<p>Content</p>'];

    $this->urlContentFetcher->expects($this->once())
      ->method('fetchContent')
      ->with($url)
      ->willReturn($htmlContent);

    $this->htmlParser->expects($this->once())
      ->method('sanitizeHtml')
      ->with($htmlContent, ContentMigrationConstants::EXTRACTION_MODE_ARTICLE, NULL, NULL)
      ->willReturn($expectedResult);

    $result = $this->contentExtractionService->extractFromUrl($url);
    $this->assertEquals($expectedResult, $result);
  }

  /**
   * Tests extractFromUrl with full page mode.
   *
   * @covers ::extractFromUrl
   */
  public function testExtractFromUrlFullPageMode(): void {
    $url = 'https://example.com/page';
    $htmlContent = '<html><body><p>Content</p></body></html>';
    $expectedResult = ['title' => 'Test', 'content' => '<body><p>Content</p></body>'];

    $this->urlContentFetcher->expects($this->once())
      ->method('fetchContent')
      ->with($url)
      ->willReturn($htmlContent);

    $this->htmlParser->expects($this->once())
      ->method('sanitizeHtml')
      ->with($htmlContent, ContentMigrationConstants::EXTRACTION_MODE_FULL_PAGE, '.content', ['nav', 'footer'])
      ->willReturn($expectedResult);

    $result = $this->contentExtractionService->extractFromUrl(
      $url,
      ContentMigrationConstants::EXTRACTION_MODE_FULL_PAGE,
      '.content',
      ['nav', 'footer']
    );
    $this->assertEquals($expectedResult, $result);
  }

  /**
   * Tests getExtractionProfile returns profile when exists.
   *
   * @covers ::getExtractionProfile
   */
  public function testGetExtractionProfile(): void {
    $profiles = [
      'test_profile' => [
        'label' => 'Test Profile',
        'rules' => [],
      ],
    ];

    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn($profiles);

    $result = $this->contentExtractionService->getExtractionProfile('test_profile');
    $this->assertEquals($profiles['test_profile'], $result);
  }

  /**
   * Tests getExtractionProfile throws exception for missing profile.
   *
   * @covers ::getExtractionProfile
   */
  public function testGetExtractionProfileNotFound(): void {
    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn([]);

    $this->expectException(ExtractionProfileNotFoundException::class);
    $this->contentExtractionService->getExtractionProfile('nonexistent');
  }

  /**
   * Tests getExtractionProfiles returns all profiles.
   *
   * @covers ::getExtractionProfiles
   */
  public function testGetExtractionProfiles(): void {
    $profiles = [
      'profile1' => ['label' => 'Profile 1'],
      'profile2' => ['label' => 'Profile 2'],
    ];

    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn($profiles);

    $result = $this->contentExtractionService->getExtractionProfiles();
    $this->assertEquals($profiles, $result);
  }

  /**
   * Tests getExtractionProfiles returns empty array when none exist.
   *
   * @covers ::getExtractionProfiles
   */
  public function testGetExtractionProfilesEmpty(): void {
    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn(NULL);

    $result = $this->contentExtractionService->getExtractionProfiles();
    $this->assertEquals([], $result);
  }

  /**
   * Tests profileExists returns true for existing profile.
   *
   * @covers ::profileExists
   */
  public function testProfileExistsTrue(): void {
    $profiles = [
      'test_profile' => ['label' => 'Test'],
    ];

    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn($profiles);

    $this->assertTrue($this->contentExtractionService->profileExists('test_profile'));
  }

  /**
   * Tests profileExists returns false for missing profile.
   *
   * @covers ::profileExists
   */
  public function testProfileExistsFalse(): void {
    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn([]);

    $this->assertFalse($this->contentExtractionService->profileExists('nonexistent'));
  }

  /**
   * Tests getContentHighlights returns highlight rules.
   *
   * @covers ::getContentHighlights
   */
  public function testGetContentHighlights(): void {
    $highlights = [
      ['selector' => '.important', 'style' => 'background: yellow;'],
    ];

    $this->config->expects($this->once())
      ->method('get')
      ->with('content_highlights')
      ->willReturn($highlights);

    $result = $this->contentExtractionService->getContentHighlights();
    $this->assertEquals($highlights, $result);
  }

  /**
   * Tests applyContentHighlights applies highlights via parser.
   *
   * @covers ::applyContentHighlights
   */
  public function testApplyContentHighlights(): void {
    $html = '<p class="important">Content</p>';
    $highlights = [
      ['selector' => '.important', 'style' => 'background: yellow;'],
    ];
    $expectedHtml = '<p class="important" style="background: yellow;">Content</p>';

    $this->config->expects($this->once())
      ->method('get')
      ->with('content_highlights')
      ->willReturn($highlights);

    $this->htmlParser->expects($this->once())
      ->method('applyHighlights')
      ->with($html, $highlights)
      ->willReturn($expectedHtml);

    $result = $this->contentExtractionService->applyContentHighlights($html);
    $this->assertEquals($expectedHtml, $result);
  }

  /**
   * Tests applyContentHighlights returns unchanged HTML when no highlights.
   *
   * @covers ::applyContentHighlights
   */
  public function testApplyContentHighlightsNoRules(): void {
    $html = '<p>Content</p>';

    $this->config->expects($this->once())
      ->method('get')
      ->with('content_highlights')
      ->willReturn([]);

    $result = $this->contentExtractionService->applyContentHighlights($html);
    $this->assertEquals($html, $result);
  }

  /**
   * Tests getFieldMappings returns mappings for content type.
   *
   * @covers ::getFieldMappings
   */
  public function testGetFieldMappings(): void {
    $allMappings = [
      'article' => [
        'body' => 'text:field_body',
        'summary' => 'text:field_summary',
      ],
      'page' => [
        'body' => 'paragraph:field_content',
      ],
    ];

    $this->config->expects($this->once())
      ->method('get')
      ->with('content_type_field_mappings')
      ->willReturn($allMappings);

    $result = $this->contentExtractionService->getFieldMappings('article');
    $this->assertEquals($allMappings['article'], $result);
  }

  /**
   * Tests getFieldMappings returns empty array for unknown content type.
   *
   * @covers ::getFieldMappings
   */
  public function testGetFieldMappingsUnknownType(): void {
    $this->config->expects($this->once())
      ->method('get')
      ->with('content_type_field_mappings')
      ->willReturn([]);

    $result = $this->contentExtractionService->getFieldMappings('unknown');
    $this->assertEquals([], $result);
  }

  /**
   * Tests processExtractions separates field and paragraph extractions.
   *
   * @covers ::processExtractions
   */
  public function testProcessExtractions(): void {
    $extractions = [
      ['paragraph_type' => 'slice_content', 'content' => '<p>Body</p>'],
      ['paragraph_type' => 'field:introduction', 'content' => 'Intro text'],
      ['paragraph_type' => 'slice_content', 'content' => '<p>More body</p>'],
    ];

    $fieldMappings = [
      'introduction' => 'text:field_intro',
    ];

    $this->config->expects($this->once())
      ->method('get')
      ->with('content_type_field_mappings')
      ->willReturn(['article' => $fieldMappings]);

    $result = $this->contentExtractionService->processExtractions($extractions, 'article');

    $this->assertCount(2, $result['paragraph_extractions']);
    $this->assertArrayHasKey('introduction', $result['field_extractions']);
    $this->assertEquals(['Intro text'], $result['field_extractions']['introduction']);
    $this->assertEquals($fieldMappings, $result['field_mappings']);
  }

  /**
   * Tests getProfilesForContentType returns profiles matching content type.
   *
   * @covers ::getProfilesForContentType
   */
  public function testGetProfilesForContentType(): void {
    $profiles = [
      'profile_article' => [
        'label' => 'Article Profile',
        'content_type' => 'article',
        'target_field' => 'entity_reference_revisions:field_content',
      ],
      'profile_page' => [
        'label' => 'Page Profile',
        'content_type' => 'page',
        'target_field' => 'entity_reference_revisions:field_sections',
      ],
      'profile_generic' => [
        'label' => 'Generic Profile',
        'content_type' => '',
        'target_field' => 'entity_reference_revisions:field_body',
      ],
    ];

    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn($profiles);

    $result = $this->contentExtractionService->getProfilesForContentType('article');

    // Should return profile_article (matches content type) and profile_generic (no content type = legacy).
    $this->assertCount(2, $result);
    $this->assertArrayHasKey('profile_article', $result);
    $this->assertArrayHasKey('profile_generic', $result);
    $this->assertArrayNotHasKey('profile_page', $result);
  }

  /**
   * Tests getProfilesForContentType returns legacy profiles for any content type.
   *
   * @covers ::getProfilesForContentType
   */
  public function testGetProfilesForContentTypeLegacyProfiles(): void {
    $profiles = [
      'legacy_profile' => [
        'label' => 'Legacy Profile',
        'target_field' => 'entity_reference_revisions:field_content',
        // No content_type key - legacy profile.
      ],
    ];

    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn($profiles);

    $result = $this->contentExtractionService->getProfilesForContentType('article');

    // Legacy profile should be included for any content type.
    $this->assertCount(1, $result);
    $this->assertArrayHasKey('legacy_profile', $result);
  }

  /**
   * Tests getProfilesForContentType returns empty array when no profiles match.
   *
   * @covers ::getProfilesForContentType
   */
  public function testGetProfilesForContentTypeNoMatch(): void {
    $profiles = [
      'profile_article' => [
        'label' => 'Article Profile',
        'content_type' => 'article',
        'target_field' => 'entity_reference_revisions:field_content',
      ],
    ];

    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn($profiles);

    $result = $this->contentExtractionService->getProfilesForContentType('page');

    // No profiles match 'page' content type.
    $this->assertCount(0, $result);
  }

  /**
   * Tests getProfilesForContentType handles empty profiles gracefully.
   *
   * @covers ::getProfilesForContentType
   */
  public function testGetProfilesForContentTypeEmpty(): void {
    $this->config->expects($this->once())
      ->method('get')
      ->with('extraction_profiles')
      ->willReturn([]);

    $result = $this->contentExtractionService->getProfilesForContentType('article');

    $this->assertEquals([], $result);
  }

}
