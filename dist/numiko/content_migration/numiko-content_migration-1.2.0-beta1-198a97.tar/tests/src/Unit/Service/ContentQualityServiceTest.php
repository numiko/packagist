<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\QualityAnalysisInterface;
use Drupal\content_migration\QualityAnalysisPluginManager;
use Drupal\content_migration\Service\ContentQualityService;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Logger\LoggerChannelInterface;
use Drupal\node\NodeInterface;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for the ContentQualityService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\ContentQualityService
 * @group content_migration
 */
class ContentQualityServiceTest extends UnitTestCase {

  /**
   * The service under test.
   *
   * @var \Drupal\content_migration\Service\ContentQualityService
   */
  protected ContentQualityService $service;

  /**
   * Mock logger channel factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $loggerFactory;

  /**
   * Mock logger channel.
   *
   * @var \Drupal\Core\Logger\LoggerChannelInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * Mock plugin manager.
   *
   * @var \Drupal\content_migration\QualityAnalysisPluginManager|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $pluginManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->logger = $this->createMock(LoggerChannelInterface::class);
    $this->loggerFactory = $this->createMock(LoggerChannelFactoryInterface::class);
    $this->loggerFactory->method('get')
      ->with('content_migration')
      ->willReturn($this->logger);

    $this->pluginManager = $this->createMock(QualityAnalysisPluginManager::class);

    $this->service = new ContentQualityService(
      $this->loggerFactory,
      $this->pluginManager
    );
  }

  /**
   * Tests assessContent with available plugins.
   *
   * @covers ::assessContent
   */
  public function testAssessContentWithPlugins(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');
    $mockNode->method('bundle')->willReturn('article');
    $mockNode->method('getTitle')->willReturn('Test Article');

    $mockPlugin = $this->createMock(QualityAnalysisInterface::class);
    $mockPlugin->method('getLabel')->willReturn('Style Guide Analysis');
    $mockPlugin->method('analyze')
      ->willReturn([
        'overall_score' => 85,
        'feedback' => 'Good quality content.',
      ]);

    $this->pluginManager->expects($this->once())
      ->method('getAvailablePlugins')
      ->willReturn(['style_guide' => $mockPlugin]);

    $content = '<p>Test content for quality assessment.</p>';
    $results = $this->service->assessContent($content, $mockNode);

    $this->assertIsArray($results);
    $this->assertArrayHasKey('style_guide', $results);
    $this->assertEquals('style_guide', $results['style_guide']['plugin_id']);
    $this->assertEquals('Style Guide Analysis', $results['style_guide']['plugin_label']);
    $this->assertEquals(85, $results['style_guide']['results']['overall_score']);
  }

  /**
   * Tests assessContent throws exception when no plugins available.
   *
   * @covers ::assessContent
   */
  public function testAssessContentThrowsExceptionWhenNoPlugins(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');
    $mockNode->method('bundle')->willReturn('article');
    $mockNode->method('getTitle')->willReturn('Test Article');

    $this->pluginManager->expects($this->once())
      ->method('getAvailablePlugins')
      ->willReturn([]);

    $this->expectException(\Exception::class);
    $this->expectExceptionMessage('No quality analysis plugins are available.');

    $this->service->assessContent('Test content', $mockNode);
  }

  /**
   * Tests assessContent with multiple plugins.
   *
   * @covers ::assessContent
   */
  public function testAssessContentWithMultiplePlugins(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');
    $mockNode->method('bundle')->willReturn('article');
    $mockNode->method('getTitle')->willReturn('Test Article');

    $mockPlugin1 = $this->createMock(QualityAnalysisInterface::class);
    $mockPlugin1->method('getLabel')->willReturn('Style Guide Analysis');
    $mockPlugin1->method('analyze')
      ->willReturn(['overall_score' => 85]);

    $mockPlugin2 = $this->createMock(QualityAnalysisInterface::class);
    $mockPlugin2->method('getLabel')->willReturn('Factual Accuracy');
    $mockPlugin2->method('analyze')
      ->willReturn(['overall_score' => 90]);

    $this->pluginManager->expects($this->once())
      ->method('getAvailablePlugins')
      ->willReturn([
        'style_guide' => $mockPlugin1,
        'factual_accuracy' => $mockPlugin2,
      ]);

    $results = $this->service->assessContent('Test content', $mockNode);

    $this->assertCount(2, $results);
    $this->assertArrayHasKey('style_guide', $results);
    $this->assertArrayHasKey('factual_accuracy', $results);
  }

  /**
   * Tests assessContent handles plugin failure gracefully.
   *
   * @covers ::assessContent
   */
  public function testAssessContentHandlesPluginFailure(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');
    $mockNode->method('bundle')->willReturn('article');
    $mockNode->method('getTitle')->willReturn('Test Article');

    $mockPlugin1 = $this->createMock(QualityAnalysisInterface::class);
    $mockPlugin1->method('getLabel')->willReturn('Failing Plugin');
    $mockPlugin1->method('analyze')
      ->willThrowException(new \Exception('Plugin failed'));

    $mockPlugin2 = $this->createMock(QualityAnalysisInterface::class);
    $mockPlugin2->method('getLabel')->willReturn('Working Plugin');
    $mockPlugin2->method('analyze')
      ->willReturn(['overall_score' => 80]);

    $this->pluginManager->expects($this->once())
      ->method('getAvailablePlugins')
      ->willReturn([
        'failing' => $mockPlugin1,
        'working' => $mockPlugin2,
      ]);

    $results = $this->service->assessContent('Test content', $mockNode);

    // Should still return results from working plugin.
    $this->assertCount(1, $results);
    $this->assertArrayHasKey('working', $results);
    $this->assertArrayNotHasKey('failing', $results);
  }

  /**
   * Tests assessContent throws exception when all plugins fail.
   *
   * @covers ::assessContent
   */
  public function testAssessContentThrowsExceptionWhenAllPluginsFail(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');
    $mockNode->method('bundle')->willReturn('article');
    $mockNode->method('getTitle')->willReturn('Test Article');

    $mockPlugin = $this->createMock(QualityAnalysisInterface::class);
    $mockPlugin->method('getLabel')->willReturn('Failing Plugin');
    $mockPlugin->method('analyze')
      ->willThrowException(new \Exception('Plugin failed'));

    $this->pluginManager->expects($this->once())
      ->method('getAvailablePlugins')
      ->willReturn(['failing' => $mockPlugin]);

    $this->expectException(\Exception::class);
    $this->expectExceptionMessage('All quality analysis plugins failed.');

    $this->service->assessContent('Test content', $mockNode);
  }

  /**
   * Tests assessContent passes audience term ID to context.
   *
   * @covers ::assessContent
   */
  public function testAssessContentPassesAudienceTermId(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');
    $mockNode->method('bundle')->willReturn('article');
    $mockNode->method('getTitle')->willReturn('Test Article');

    $mockPlugin = $this->createMock(QualityAnalysisInterface::class);
    $mockPlugin->method('getLabel')->willReturn('Style Guide');
    $mockPlugin->method('analyze')
      ->willReturn(['overall_score' => 85]);

    $this->pluginManager->expects($this->once())
      ->method('getAvailablePlugins')
      ->with($this->callback(function ($context) {
        return isset($context['audience_term_id']) && $context['audience_term_id'] === 42;
      }))
      ->willReturn(['style_guide' => $mockPlugin]);

    $results = $this->service->assessContent('Test content', $mockNode, 42);

    $this->assertNotEmpty($results);
  }

  /**
   * Tests compareContent calls factual accuracy plugin.
   *
   * @covers ::compareContent
   */
  public function testCompareContent(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');

    // Create a mock that adds the compareContent method.
    $mockPlugin = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['compareContent'])
      ->getMock();
    $mockPlugin->method('compareContent')
      ->with(
        'Original content',
        'Rewritten content',
        $mockNode,
        $this->anything()
      )
      ->willReturn([
        'accuracy_score' => 95,
        'issues' => [],
      ]);

    $this->pluginManager->expects($this->once())
      ->method('createInstance')
      ->with('factual_accuracy')
      ->willReturn($mockPlugin);

    $results = $this->service->compareContent(
      'Original content',
      'Rewritten content',
      $mockNode
    );

    $this->assertEquals(95, $results['accuracy_score']);
    $this->assertEmpty($results['issues']);
  }

  /**
   * Tests compareContent throws exception on plugin failure.
   *
   * @covers ::compareContent
   */
  public function testCompareContentThrowsExceptionOnFailure(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');

    // Create a mock that adds the compareContent method.
    $mockPlugin = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['compareContent'])
      ->getMock();
    $mockPlugin->method('compareContent')
      ->willThrowException(new \Exception('Comparison failed'));

    $this->pluginManager->expects($this->once())
      ->method('createInstance')
      ->with('factual_accuracy')
      ->willReturn($mockPlugin);

    $this->expectException(\Exception::class);
    $this->expectExceptionMessage('Comparison failed');

    $this->service->compareContent('Original', 'Rewritten', $mockNode);
  }

}
