<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\Service\RedirectService;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\node\NodeInterface;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the RedirectService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\RedirectService
 * @group content_migration
 */
class RedirectServiceTest extends UnitTestCase {

  /**
   * The redirect service under test.
   *
   * @var \Drupal\content_migration\Service\RedirectService
   */
  protected RedirectService $redirectService;

  /**
   * Mock module handler.
   *
   * @var \Drupal\Core\Extension\ModuleHandlerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $moduleHandler;

  /**
   * Mock messenger.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $messenger;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->moduleHandler = $this->createMock(ModuleHandlerInterface::class);
    $this->messenger = $this->createMock(MessengerInterface::class);
    $this->logger = $this->createMock(LoggerInterface::class);

    $this->redirectService = new RedirectService(
      $this->moduleHandler,
      $this->messenger,
      $this->logger
    );
    $this->redirectService->setStringTranslation($this->getStringTranslationStub());
  }

  /**
   * Tests isRedirectModuleEnabled returns true when module exists.
   *
   * @covers ::isRedirectModuleEnabled
   */
  public function testIsRedirectModuleEnabledTrue(): void {
    $this->moduleHandler->expects($this->once())
      ->method('moduleExists')
      ->with('redirect')
      ->willReturn(TRUE);

    $this->assertTrue($this->redirectService->isRedirectModuleEnabled());
  }

  /**
   * Tests isRedirectModuleEnabled returns false when module not exists.
   *
   * @covers ::isRedirectModuleEnabled
   */
  public function testIsRedirectModuleEnabledFalse(): void {
    $this->moduleHandler->expects($this->once())
      ->method('moduleExists')
      ->with('redirect')
      ->willReturn(FALSE);

    $this->assertFalse($this->redirectService->isRedirectModuleEnabled());
  }

  /**
   * Tests createRedirect returns false when redirect module not enabled.
   *
   * @covers ::createRedirect
   */
  public function testCreateRedirectModuleNotEnabled(): void {
    $mockNode = $this->createMock(NodeInterface::class);

    $this->moduleHandler->expects($this->once())
      ->method('moduleExists')
      ->with('redirect')
      ->willReturn(FALSE);

    $this->messenger->expects($this->once())
      ->method('addWarning');

    $result = $this->redirectService->createRedirect('https://example.com/old-page', $mockNode);
    $this->assertFalse($result);
  }

  /**
   * Tests createMultipleRedirects tracks success and failures.
   *
   * @covers ::createMultipleRedirects
   */
  public function testCreateMultipleRedirectsModuleNotEnabled(): void {
    $mockNode = $this->createMock(NodeInterface::class);

    // Module not enabled, so all redirects will fail.
    $this->moduleHandler->method('moduleExists')
      ->with('redirect')
      ->willReturn(FALSE);

    $urls = [
      'https://example.com/page1',
      'https://example.com/page2',
      'https://example.com/page3',
    ];

    $result = $this->redirectService->createMultipleRedirects($urls, $mockNode);

    $this->assertEquals(0, $result['success']);
    $this->assertEquals(3, $result['failed']);
  }

}
