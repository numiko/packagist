<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Form\Builder;

use Drupal\content_migration\Form\Builder\UrlImportFormBuilder;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for the UrlImportFormBuilder.
 *
 * @coversDefaultClass \Drupal\content_migration\Form\Builder\UrlImportFormBuilder
 * @group content_migration
 */
class UrlImportFormBuilderTest extends UnitTestCase {

  /**
   * The form builder under test.
   *
   * @var \Drupal\content_migration\Form\Builder\UrlImportFormBuilder
   */
  protected UrlImportFormBuilder $formBuilder;

  /**
   * Mock config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $configFactory;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->configFactory = $this->createMock(ConfigFactoryInterface::class);
    $mockConfig = $this->createMock(ImmutableConfig::class);
    $this->configFactory->method('get')->willReturn($mockConfig);

    $this->formBuilder = new UrlImportFormBuilder($this->configFactory);
    $this->formBuilder->setStringTranslation($this->getStringTranslationStub());
  }

  /**
   * Tests getId returns correct identifier.
   *
   * @covers ::getId
   */
  public function testGetId(): void {
    $this->assertEquals('url', $this->formBuilder->getId());
  }

  /**
   * Tests getLabel returns correct label.
   *
   * @covers ::getLabel
   */
  public function testGetLabel(): void {
    $this->assertEquals('URL Import', $this->formBuilder->getLabel());
  }

  /**
   * Tests buildForm creates expected form structure.
   *
   * @covers ::buildForm
   */
  public function testBuildForm(): void {
    $form = [];
    $formState = $this->createMock(FormStateInterface::class);

    $result = $this->formBuilder->buildForm($form, $formState);

    $this->assertArrayHasKey('url_import', $result);
    $this->assertArrayHasKey('urls', $result['url_import']);
    $this->assertArrayHasKey('extraction_mode', $result['url_import']);
    $this->assertArrayHasKey('extraction_profile', $result['url_import']);
    $this->assertArrayHasKey('content_selector', $result['url_import']);
    $this->assertArrayHasKey('tags_to_remove', $result['url_import']);
    $this->assertArrayHasKey('create_redirects', $result['url_import']);
    $this->assertArrayHasKey('merge_options', $result['url_import']);
  }

  /**
   * Tests buildForm includes extraction profiles in options.
   *
   * @covers ::buildForm
   */
  public function testBuildFormWithProfiles(): void {
    $form = [];
    $formState = $this->createMock(FormStateInterface::class);
    $options = [
      'extraction_profiles' => [
        'profile1' => ['label' => 'Profile One'],
        'profile2' => ['label' => 'Profile Two'],
      ],
    ];

    $result = $this->formBuilder->buildForm($form, $formState, $options);

    $this->assertArrayHasKey('#options', $result['url_import']['extraction_profile']);
    $this->assertArrayHasKey('profile1', $result['url_import']['extraction_profile']['#options']);
    $this->assertArrayHasKey('profile2', $result['url_import']['extraction_profile']['#options']);
  }

  /**
   * Tests validateForm sets error for missing URLs.
   *
   * @covers ::validateForm
   */
  public function testValidateFormMissingUrls(): void {
    $form = [];
    $formState = $this->createMock(FormStateInterface::class);

    $formState->method('getValue')
      ->willReturnMap([
        ['import_type', NULL, 'url'],
        ['urls', NULL, ''],
      ]);

    $formState->expects($this->once())
      ->method('setErrorByName')
      ->with('urls', $this->anything());

    $this->formBuilder->validateForm($form, $formState);
  }

  /**
   * Tests validateForm sets error for invalid URL.
   *
   * @covers ::validateForm
   */
  public function testValidateFormInvalidUrl(): void {
    $form = [];
    $formState = $this->createMock(FormStateInterface::class);

    $formState->method('getValue')
      ->willReturnMap([
        ['import_type', NULL, 'url'],
        ['urls', NULL, "not-a-valid-url"],
      ]);

    $formState->expects($this->once())
      ->method('setErrorByName')
      ->with('urls', $this->anything());

    $this->formBuilder->validateForm($form, $formState);
  }

  /**
   * Tests validateForm passes for valid URLs.
   *
   * @covers ::validateForm
   */
  public function testValidateFormValidUrls(): void {
    $form = [];
    $formState = $this->createMock(FormStateInterface::class);

    $formState->method('getValue')
      ->willReturnMap([
        ['import_type', NULL, 'url'],
        ['urls', NULL, "https://example.com/page1\nhttps://example.com/page2"],
      ]);

    $formState->expects($this->never())
      ->method('setErrorByName');

    $this->formBuilder->validateForm($form, $formState);
  }

  /**
   * Tests validateForm skips validation for non-URL import types.
   *
   * @covers ::validateForm
   */
  public function testValidateFormSkipsForOtherTypes(): void {
    $form = [];
    $formState = $this->createMock(FormStateInterface::class);

    $formState->method('getValue')
      ->willReturnMap([
        ['import_type', NULL, 'pdf'],
        ['urls', NULL, ''],
      ]);

    $formState->expects($this->never())
      ->method('setErrorByName');

    $this->formBuilder->validateForm($form, $formState);
  }

}
