<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Exception;

use Drupal\content_migration\Exception\ApiConfigurationException;
use Drupal\content_migration\Exception\ContentFetchException;
use Drupal\content_migration\Exception\ContentMigrationException;
use Drupal\content_migration\Exception\ContentParseException;
use Drupal\content_migration\Exception\ExtractionProfileNotFoundException;
use PHPUnit\Framework\TestCase;

/**
 * Tests for content migration exception classes.
 *
 * @group content_migration
 * @coversDefaultClass \Drupal\content_migration\Exception\ContentMigrationException
 */
class ContentMigrationExceptionTest extends TestCase {

  /**
   * Tests that ContentMigrationException extends RuntimeException.
   *
   * @covers ::__construct
   */
  public function testContentMigrationExceptionExtendsRuntimeException(): void {
    $exception = new ContentMigrationException('Test message');
    $this->assertInstanceOf(\RuntimeException::class, $exception);
    $this->assertEquals('Test message', $exception->getMessage());
  }

  /**
   * Tests exception error code constants.
   */
  public function testErrorCodeConstants(): void {
    $this->assertEquals(0, ContentMigrationException::ERROR_UNKNOWN);
    $this->assertEquals(1, ContentMigrationException::ERROR_FETCH);
    $this->assertEquals(2, ContentMigrationException::ERROR_PARSE);
    $this->assertEquals(3, ContentMigrationException::ERROR_CONFIG);
    $this->assertEquals(4, ContentMigrationException::ERROR_PROFILE);
  }

  /**
   * Tests ExtractionProfileNotFoundException.
   *
   * @covers \Drupal\content_migration\Exception\ExtractionProfileNotFoundException
   */
  public function testExtractionProfileNotFoundException(): void {
    $exception = new ExtractionProfileNotFoundException('my_profile');

    $this->assertInstanceOf(ContentMigrationException::class, $exception);
    $this->assertEquals("Extraction profile 'my_profile' not found.", $exception->getMessage());
    $this->assertEquals(ContentMigrationException::ERROR_PROFILE, $exception->getCode());
  }

  /**
   * Tests ApiConfigurationException.
   *
   * @covers \Drupal\content_migration\Exception\ApiConfigurationException
   */
  public function testApiConfigurationException(): void {
    $exception = new ApiConfigurationException('Custom message');

    $this->assertInstanceOf(ContentMigrationException::class, $exception);
    $this->assertEquals('Custom message', $exception->getMessage());
    $this->assertEquals(ContentMigrationException::ERROR_CONFIG, $exception->getCode());
  }

  /**
   * Tests ApiConfigurationException::missingApiKey factory method.
   *
   * @covers \Drupal\content_migration\Exception\ApiConfigurationException::missingApiKey
   */
  public function testApiConfigurationExceptionMissingApiKey(): void {
    $exception = ApiConfigurationException::missingApiKey();

    $this->assertEquals('Claude API key is not configured.', $exception->getMessage());
  }

  /**
   * Tests ApiConfigurationException::missingApiModel factory method.
   *
   * @covers \Drupal\content_migration\Exception\ApiConfigurationException::missingApiModel
   */
  public function testApiConfigurationExceptionMissingApiModel(): void {
    $exception = ApiConfigurationException::missingApiModel();

    $this->assertEquals('Claude API model is not configured.', $exception->getMessage());
  }

  /**
   * Tests ContentFetchException with URL.
   *
   * @covers \Drupal\content_migration\Exception\ContentFetchException
   */
  public function testContentFetchException(): void {
    $exception = new ContentFetchException('Fetch failed', 'https://example.com');

    $this->assertInstanceOf(ContentMigrationException::class, $exception);
    $this->assertEquals('Fetch failed', $exception->getMessage());
    $this->assertEquals('https://example.com', $exception->getUrl());
    $this->assertEquals(ContentMigrationException::ERROR_FETCH, $exception->getCode());
  }

  /**
   * Tests ContentFetchException::invalidContentType factory method.
   *
   * @covers \Drupal\content_migration\Exception\ContentFetchException::invalidContentType
   */
  public function testContentFetchExceptionInvalidContentType(): void {
    $exception = ContentFetchException::invalidContentType('https://example.com', 'application/pdf');

    $this->assertStringContainsString('non-HTML content type', $exception->getMessage());
    $this->assertStringContainsString('application/pdf', $exception->getMessage());
    $this->assertEquals('https://example.com', $exception->getUrl());
  }

  /**
   * Tests ContentFetchException::emptyResponse factory method.
   *
   * @covers \Drupal\content_migration\Exception\ContentFetchException::emptyResponse
   */
  public function testContentFetchExceptionEmptyResponse(): void {
    $exception = ContentFetchException::emptyResponse('https://example.com');

    $this->assertStringContainsString('empty content', $exception->getMessage());
    $this->assertEquals('https://example.com', $exception->getUrl());
  }

  /**
   * Tests ContentFetchException::httpError factory method.
   *
   * @covers \Drupal\content_migration\Exception\ContentFetchException::httpError
   */
  public function testContentFetchExceptionHttpError(): void {
    $exception = ContentFetchException::httpError('https://example.com', 404);

    $this->assertStringContainsString('HTTP 404', $exception->getMessage());
    $this->assertEquals('https://example.com', $exception->getUrl());
  }

  /**
   * Tests ContentParseException.
   *
   * @covers \Drupal\content_migration\Exception\ContentParseException
   */
  public function testContentParseException(): void {
    $exception = new ContentParseException('Parse failed');

    $this->assertInstanceOf(ContentMigrationException::class, $exception);
    $this->assertEquals('Parse failed', $exception->getMessage());
    $this->assertEquals(ContentMigrationException::ERROR_PARSE, $exception->getCode());
  }

  /**
   * Tests ContentParseException::invalidHtml factory method.
   *
   * @covers \Drupal\content_migration\Exception\ContentParseException::invalidHtml
   */
  public function testContentParseExceptionInvalidHtml(): void {
    $exception = ContentParseException::invalidHtml('Malformed tag');

    $this->assertStringContainsString('Failed to parse HTML', $exception->getMessage());
    $this->assertStringContainsString('Malformed tag', $exception->getMessage());
  }

  /**
   * Tests ContentParseException::selectorNotFound factory method.
   *
   * @covers \Drupal\content_migration\Exception\ContentParseException::selectorNotFound
   */
  public function testContentParseExceptionSelectorNotFound(): void {
    $exception = ContentParseException::selectorNotFound('.my-selector');

    $this->assertStringContainsString('.my-selector', $exception->getMessage());
    $this->assertStringContainsString('did not match', $exception->getMessage());
  }

  /**
   * Tests ContentParseException::domManipulationFailed factory method.
   *
   * @covers \Drupal\content_migration\Exception\ContentParseException::domManipulationFailed
   */
  public function testContentParseExceptionDomManipulationFailed(): void {
    $exception = ContentParseException::domManipulationFailed('appendChild');

    $this->assertStringContainsString('DOM manipulation failed', $exception->getMessage());
    $this->assertStringContainsString('appendChild', $exception->getMessage());
  }

  /**
   * Tests exception hierarchy.
   */
  public function testExceptionHierarchy(): void {
    // All custom exceptions should extend ContentMigrationException.
    $this->assertTrue(
      is_subclass_of(ExtractionProfileNotFoundException::class, ContentMigrationException::class)
    );
    $this->assertTrue(
      is_subclass_of(ApiConfigurationException::class, ContentMigrationException::class)
    );
    $this->assertTrue(
      is_subclass_of(ContentFetchException::class, ContentMigrationException::class)
    );
    $this->assertTrue(
      is_subclass_of(ContentParseException::class, ContentMigrationException::class)
    );

    // ContentMigrationException should extend RuntimeException.
    $this->assertTrue(
      is_subclass_of(ContentMigrationException::class, \RuntimeException::class)
    );
  }

  /**
   * Tests that all exceptions can be caught with ContentMigrationException.
   */
  public function testCatchAllExceptions(): void {
    $exceptions = [
      new ExtractionProfileNotFoundException('test'),
      ApiConfigurationException::missingApiKey(),
      ContentFetchException::emptyResponse('https://example.com'),
      ContentParseException::invalidHtml(),
    ];

    foreach ($exceptions as $exception) {
      try {
        throw $exception;
      }
      catch (ContentMigrationException $e) {
        // All exceptions should be caught here.
        $this->assertInstanceOf(ContentMigrationException::class, $e);
      }
    }
  }

}
