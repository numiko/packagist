<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit;

use Drupal\content_migration\ContentMigrationConstants;
use PHPUnit\Framework\TestCase;

/**
 * Tests for ContentMigrationConstants class.
 *
 * @group content_migration
 * @coversDefaultClass \Drupal\content_migration\ContentMigrationConstants
 */
class ContentMigrationConstantsTest extends TestCase {

  /**
   * Tests default paragraph type constant.
   *
   * @covers ::DEFAULT_PARAGRAPH_TYPE
   */
  public function testDefaultParagraphType(): void {
    $this->assertEquals('slice_content', ContentMigrationConstants::DEFAULT_PARAGRAPH_TYPE);
  }

  /**
   * Tests default text format constants.
   *
   * @covers ::DEFAULT_TEXT_FORMAT_FULL
   * @covers ::DEFAULT_TEXT_FORMAT_BASIC
   */
  public function testDefaultTextFormats(): void {
    $this->assertEquals('full_html', ContentMigrationConstants::DEFAULT_TEXT_FORMAT_FULL);
    $this->assertEquals('basic_html', ContentMigrationConstants::DEFAULT_TEXT_FORMAT_BASIC);
  }

  /**
   * Tests default menu name constant.
   *
   * @covers ::DEFAULT_MENU_NAME
   */
  public function testDefaultMenuName(): void {
    $this->assertEquals('main', ContentMigrationConstants::DEFAULT_MENU_NAME);
  }

  /**
   * Tests default API timeout constant.
   *
   * @covers ::DEFAULT_API_TIMEOUT
   */
  public function testDefaultApiTimeout(): void {
    $this->assertEquals(600, ContentMigrationConstants::DEFAULT_API_TIMEOUT);
    // Timeout should be a reasonable value (10 minutes in seconds).
    $this->assertGreaterThan(0, ContentMigrationConstants::DEFAULT_API_TIMEOUT);
  }

  /**
   * Tests default admin UID constant.
   *
   * @covers ::DEFAULT_ADMIN_UID
   */
  public function testDefaultAdminUid(): void {
    $this->assertEquals(1, ContentMigrationConstants::DEFAULT_ADMIN_UID);
  }

  /**
   * Tests paragraph content field constant.
   *
   * @covers ::PARAGRAPH_CONTENT_FIELD
   */
  public function testParagraphContentField(): void {
    $this->assertEquals('field_content', ContentMigrationConstants::PARAGRAPH_CONTENT_FIELD);
  }

  /**
   * Tests composite key delimiter constant.
   *
   * @covers ::COMPOSITE_KEY_DELIMITER
   */
  public function testCompositeKeyDelimiter(): void {
    $this->assertEquals(':', ContentMigrationConstants::COMPOSITE_KEY_DELIMITER);
  }

  /**
   * Tests field prefix constants.
   *
   * @covers ::PARAGRAPH_FIELD_PREFIX
   * @covers ::TEXT_FIELD_PREFIX
   */
  public function testFieldPrefixes(): void {
    $this->assertEquals('paragraph', ContentMigrationConstants::PARAGRAPH_FIELD_PREFIX);
    $this->assertEquals('text', ContentMigrationConstants::TEXT_FIELD_PREFIX);
  }

  /**
   * Tests config key constant.
   *
   * @covers ::CONFIG_KEY
   */
  public function testConfigKey(): void {
    $this->assertEquals('content_migration.settings', ContentMigrationConstants::CONFIG_KEY);
  }

  /**
   * Tests logger channel constant.
   *
   * @covers ::LOGGER_CHANNEL
   */
  public function testLoggerChannel(): void {
    $this->assertEquals('content_migration', ContentMigrationConstants::LOGGER_CHANNEL);
  }

  /**
   * Tests extraction mode constants.
   *
   * @covers ::EXTRACTION_MODE_ARTICLE
   * @covers ::EXTRACTION_MODE_FULL_PAGE
   */
  public function testExtractionModes(): void {
    $this->assertEquals('article', ContentMigrationConstants::EXTRACTION_MODE_ARTICLE);
    $this->assertEquals('full_page', ContentMigrationConstants::EXTRACTION_MODE_FULL_PAGE);
  }

  /**
   * Tests that the class is final.
   */
  public function testClassIsFinal(): void {
    $reflection = new \ReflectionClass(ContentMigrationConstants::class);
    $this->assertTrue($reflection->isFinal());
  }

  /**
   * Tests that all constants are public.
   */
  public function testAllConstantsArePublic(): void {
    $reflection = new \ReflectionClass(ContentMigrationConstants::class);
    $constants = $reflection->getReflectionConstants();

    foreach ($constants as $constant) {
      $this->assertTrue(
        $constant->isPublic(),
        sprintf('Constant %s should be public', $constant->getName())
      );
    }
  }

}
