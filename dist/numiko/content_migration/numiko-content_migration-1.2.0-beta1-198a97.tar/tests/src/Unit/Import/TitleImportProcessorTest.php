<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Import;

use Drupal\content_migration\AiMigrationPluginManager;
use Drupal\content_migration\Import\TitleImportProcessor;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\content_migration\Service\RedirectService;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\node\NodeInterface;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the TitleImportProcessor.
 *
 * @coversDefaultClass \Drupal\content_migration\Import\TitleImportProcessor
 * @group content_migration
 */
class TitleImportProcessorTest extends UnitTestCase {

  /**
   * The processor under test.
   *
   * @var \Drupal\content_migration\Import\TitleImportProcessor
   */
  protected TitleImportProcessor $processor;

  /**
   * Mock node builder.
   *
   * @var \Drupal\content_migration\Service\NodeBuilderService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $nodeBuilder;

  /**
   * Mock menu link service.
   *
   * @var \Drupal\content_migration\Service\MenuLinkService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $menuLinkService;

  /**
   * Mock redirect service.
   *
   * @var \Drupal\content_migration\Service\RedirectService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $redirectService;

  /**
   * Mock AI migration plugin manager.
   *
   * @var \Drupal\content_migration\AiMigrationPluginManager|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $aiMigrationPluginManager;

  /**
   * Mock messenger.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $messenger;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->nodeBuilder = $this->createMock(NodeBuilderService::class);
    $this->menuLinkService = $this->createMock(MenuLinkService::class);
    $this->redirectService = $this->createMock(RedirectService::class);
    $this->aiMigrationPluginManager = $this->createMock(AiMigrationPluginManager::class);
    $this->messenger = $this->createMock(MessengerInterface::class);
    $this->logger = $this->createMock(LoggerInterface::class);

    $this->processor = new TitleImportProcessor(
      $this->nodeBuilder,
      $this->menuLinkService,
      $this->redirectService,
      $this->aiMigrationPluginManager,
      $this->messenger,
      $this->logger
    );
    $this->processor->setStringTranslation($this->getStringTranslationStub());
  }

  /**
   * Tests getId returns correct identifier.
   *
   * @covers ::getId
   */
  public function testGetId(): void {
    $this->assertEquals('title', $this->processor->getId());
  }

  /**
   * Tests getLabel returns correct label.
   *
   * @covers ::getLabel
   */
  public function testGetLabel(): void {
    $this->assertEquals('Title Import', $this->processor->getLabel());
  }

  /**
   * Tests validateData returns error for missing title.
   *
   * @covers ::validateData
   */
  public function testValidateDataMissingTitle(): void {
    $errors = $this->processor->validateData([]);
    $this->assertNotEmpty($errors);
    $this->assertContains('Title is required.', $errors);
  }

  /**
   * Tests validateData returns empty for valid data.
   *
   * @covers ::validateData
   */
  public function testValidateDataValid(): void {
    $errors = $this->processor->validateData(['title' => 'Test Page']);
    $this->assertEmpty($errors);
  }

  /**
   * Tests validateConfiguration returns error for missing content type.
   *
   * @covers ::validateConfiguration
   */
  public function testValidateConfigurationMissingContentType(): void {
    $errors = $this->processor->validateConfiguration([]);
    $this->assertNotEmpty($errors);
    $this->assertContains('Content type is required.', $errors);
  }

  /**
   * Tests validateConfiguration returns empty for valid config.
   *
   * @covers ::validateConfiguration
   */
  public function testValidateConfigurationValid(): void {
    $errors = $this->processor->validateConfiguration(['content_type' => 'article']);
    $this->assertEmpty($errors);
  }

  /**
   * Tests process creates a node with the given title.
   *
   * @covers ::process
   */
  public function testProcess(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');

    $this->nodeBuilder->expects($this->once())
      ->method('createNode')
      ->with('article', 'Test Page')
      ->willReturn($mockNode);

    $mockNode->expects($this->once())
      ->method('save');

    $data = ['title' => 'Test Page'];
    $configuration = ['content_type' => 'article'];

    $result = $this->processor->process($data, $configuration);
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests process sets body field when configured.
   *
   * @covers ::process
   */
  public function testProcessWithBodyField(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');

    $this->nodeBuilder->expects($this->once())
      ->method('createNode')
      ->willReturn($mockNode);

    $this->nodeBuilder->expects($this->once())
      ->method('setFieldValue')
      ->with($mockNode, 'paragraph:field_content', '');

    $mockNode->expects($this->once())
      ->method('save');

    $data = ['title' => 'Test Page'];
    $configuration = [
      'content_type' => 'article',
      'fields' => ['body' => 'paragraph:field_content'],
    ];

    $this->processor->process($data, $configuration);
  }

  /**
   * Tests process creates menu link when parent specified.
   *
   * @covers ::process
   */
  public function testProcessWithMenuLink(): void {
    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn('123');

    $this->nodeBuilder->expects($this->once())
      ->method('createNode')
      ->willReturn($mockNode);

    $mockNode->expects($this->once())
      ->method('save');

    $this->menuLinkService->expects($this->once())
      ->method('createMenuLink')
      ->with($mockNode, 'menu_link_content:parent-uuid');

    $data = ['title' => 'Test Page'];
    $configuration = [
      'content_type' => 'article',
      'parent_menu_item' => 'menu_link_content:parent-uuid',
    ];

    $this->processor->process($data, $configuration);
  }

}
