<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Import;

use Drupal\content_migration\AiMigrationPluginManager;
use Drupal\content_migration\Import\UrlImportProcessor;
use Drupal\content_migration\Service\ContentExtractionService;
use Drupal\content_migration\Service\HtmlParserService;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\content_migration\Service\RedirectService;
use Drupal\content_migration\Service\UrlContentFetcherService;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the UrlImportProcessor.
 *
 * @coversDefaultClass \Drupal\content_migration\Import\UrlImportProcessor
 * @group content_migration
 */
class UrlImportProcessorTest extends UnitTestCase {

  /**
   * The processor under test.
   *
   * @var \Drupal\content_migration\Import\UrlImportProcessor
   */
  protected UrlImportProcessor $processor;

  /**
   * Mock node builder.
   *
   * @var \Drupal\content_migration\Service\NodeBuilderService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $nodeBuilder;

  /**
   * Mock URL content fetcher.
   *
   * @var \Drupal\content_migration\Service\UrlContentFetcherService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $urlContentFetcher;

  /**
   * Mock content extraction service.
   *
   * @var \Drupal\content_migration\Service\ContentExtractionService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $contentExtraction;

  /**
   * Mock HTML parser.
   *
   * @var \Drupal\content_migration\Service\HtmlParserService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $htmlParser;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->nodeBuilder = $this->createMock(NodeBuilderService::class);
    $menuLinkService = $this->createMock(MenuLinkService::class);
    $redirectService = $this->createMock(RedirectService::class);
    $aiMigrationPluginManager = $this->createMock(AiMigrationPluginManager::class);
    $messenger = $this->createMock(MessengerInterface::class);
    $logger = $this->createMock(LoggerInterface::class);
    $this->urlContentFetcher = $this->createMock(UrlContentFetcherService::class);
    $this->contentExtraction = $this->createMock(ContentExtractionService::class);
    $this->htmlParser = $this->createMock(HtmlParserService::class);

    $this->processor = new UrlImportProcessor(
      $this->nodeBuilder,
      $menuLinkService,
      $redirectService,
      $aiMigrationPluginManager,
      $messenger,
      $logger,
      $this->urlContentFetcher,
      $this->contentExtraction,
      $this->htmlParser
    );
    $this->processor->setStringTranslation($this->getStringTranslationStub());
  }

  /**
   * Tests getId returns correct identifier.
   *
   * @covers ::getId
   */
  public function testGetId(): void {
    $this->assertEquals('url', $this->processor->getId());
  }

  /**
   * Tests getLabel returns correct label.
   *
   * @covers ::getLabel
   */
  public function testGetLabel(): void {
    $this->assertEquals('URL Import', $this->processor->getLabel());
  }

  /**
   * Tests validateData returns error for missing URL.
   *
   * @covers ::validateData
   */
  public function testValidateDataMissingUrl(): void {
    $errors = $this->processor->validateData([]);
    $this->assertNotEmpty($errors);
    $this->assertContains('URL is required.', $errors);
  }

  /**
   * Tests validateData returns error for invalid URL.
   *
   * @covers ::validateData
   */
  public function testValidateDataInvalidUrl(): void {
    $errors = $this->processor->validateData(['url' => 'not-a-valid-url']);
    $this->assertNotEmpty($errors);
    $this->assertContains('Invalid URL format.', $errors);
  }

  /**
   * Tests validateData returns empty for valid URL.
   *
   * @covers ::validateData
   */
  public function testValidateDataValidUrl(): void {
    $errors = $this->processor->validateData(['url' => 'https://example.com/page']);
    $this->assertEmpty($errors);
  }

  /**
   * Tests validateData validates multiple URLs.
   *
   * @covers ::validateData
   */
  public function testValidateDataMultipleUrls(): void {
    $data = [
      'urls' => [
        'https://example.com/page1',
        'https://example.com/page2',
      ],
    ];
    $errors = $this->processor->validateData($data);
    $this->assertEmpty($errors);
  }

  /**
   * Tests validateData returns error for invalid URL in array.
   *
   * @covers ::validateData
   */
  public function testValidateDataInvalidUrlInArray(): void {
    $data = [
      'urls' => [
        'https://example.com/page1',
        'not-valid',
      ],
    ];
    $errors = $this->processor->validateData($data);
    $this->assertNotEmpty($errors);
  }

}
