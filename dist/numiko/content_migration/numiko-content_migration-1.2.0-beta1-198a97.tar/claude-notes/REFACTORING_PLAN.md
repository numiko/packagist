# Content Migration Module - Refactoring Plan

## Executive Summary

This document provides a comprehensive assessment of the Content Migration Drupal module against Drupal 8+ module development standards and OOP best practices, verified against official Drupal documentation. While the module demonstrates several modern patterns (PHP 8 attributes, autowiring, plugin architecture), there are significant opportunities to improve code organization, maintainability, and adherence to Drupal conventions.

**Documentation Sources:**
- [Drupal Plugin API](https://www.drupal.org/docs/drupal-apis/plugin-api)
- [Attribute-based Plugins](https://www.drupal.org/docs/drupal-apis/plugin-api/attribute-based-plugins)
- [Creating Your Own Plugin Manager](https://www.drupal.org/docs/drupal-apis/plugin-api/creating-your-own-plugin-manager)
- [Services and Dependency Injection](https://www.drupal.org/docs/drupal-apis/services-and-dependency-injection)
- [Dependency Injection for Forms](https://www.drupal.org/docs/drupal-apis/services-and-dependency-injection/dependency-injection-for-a-form)
- [Structure of a Service File](https://www.drupal.org/docs/drupal-apis/services-and-dependency-injection/structure-of-a-service-file)
- [Drupal Coding Standards](https://www.drupal.org/docs/develop/standards/coding-standards)

---

## Part 1: Current State Assessment

### 1.1 Strengths

The module exhibits several positive characteristics:

| Aspect | Implementation | Drupal Standard Compliance |
|--------|----------------|---------------------------|
| **PHP Version** | Uses PHP 8.1+ features: typed properties, constructor property promotion, attributes | Exceeds minimum requirements |
| **Plugin Architecture** | PHP 8 attributes (`#[AiMigration]`, `#[QualityAnalysis]`) for discovery | Follows Drupal 10.2+ standard |
| **Form DI** | Uses `AutowireTrait` (Drupal 10.2+) for automatic service injection | Modern best practice |
| **Plugin Discovery** | Plugins in `src/Plugin/{type}/` with correct namespace | Per documentation: `Drupal\{module}\Plugin\{type}` |
| **Service Naming** | Uses `plugin.manager.` prefix for plugin managers | Per documentation convention |
| **Autoloading** | Proper PSR-4 namespace structure under `src/` | Required standard |
| **Configuration** | Schema defined in `config/schema/`, uses ConfigFactoryInterface | Best practice |
| **Access Control** | Custom access checker implementing `AccessInterface` | Correct pattern |
| **Logging** | Dedicated logger channel via `logger.channel_base` parent | Best practice |

### 1.2 Architecture Overview

```
src/
├── Access/                    # Access checkers
├── Attribute/                 # PHP 8 plugin attributes
├── Controller/               # Controllers (1 file, 1453 lines)
├── Form/                     # Forms (4 files)
├── Plugin/                   # Plugin system
│   ├── AiMigration/         # AI transformation plugins
│   └── QualityAnalysis/     # Quality analysis plugins
└── Service/                  # Services (3 files)
```

---

## Part 2: Identified Issues

### 2.1 Critical: Single Responsibility Principle Violations

#### Issue 2.1.1: ContentImportController is a God Class

**Location:** `src/Controller/ContentImportController.php` (1,453 lines)

**Problem:** The controller handles:
- URL processing
- PDF processing
- CSV processing
- Title-based page creation
- Menu link creation
- Redirect creation
- Taxonomy term assignment
- Paragraph entity creation
- HTML content merging
- Profile-based extraction
- Claude API integration for PDF extraction

**Impact:**
- Difficult to test individual components
- High cognitive load for maintenance
- Changes risk unintended side effects

#### Issue 2.1.2: ContentImportForm is Oversized

**Location:** `src/Form/ContentImportForm.php` (1,557 lines)

**Problem:** The form handles:
- 4 different import types (URL, PDF, title, CSV)
- Complex conditional form building
- CSV parsing and validation
- Batch operation callbacks (static methods)
- Field mapping logic

### 2.2 High: Drupal Convention Violations

#### Issue 2.2.1: Controller Registered as Service

**Location:** `content_migration.services.yml:19-21`

```yaml
content_migration.content_import_controller:
  class: Drupal\content_migration\Controller\ContentImportController
```

**Problem:** Per [Drupal DI documentation](https://www.drupal.org/docs/drupal-apis/services-and-dependency-injection), controllers that extend `ControllerBase` should use the `create()` factory method for dependency injection, NOT be registered as services.

The current implementation mixes both patterns - extends ControllerBase AND is registered as a service. This is an anti-pattern.

**Standard Pattern (per Drupal docs):**
```php
class MyController extends ControllerBase {

  public function __construct(
    protected MyServiceInterface $myService,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('my.service'),
    );
  }
}
```

**Note:** The controller is registered as a service so it can be called from batch callbacks via `\Drupal::service()`. The solution is to create a separate processor service class (see Phase 2.3).

#### Issue 2.2.2: Static Service Container Access

Per [Drupal DI documentation](https://www.drupal.org/docs/drupal-apis/services-and-dependency-injection/structure-of-a-service-file), services should be injected via constructor, not accessed statically. Multiple files use `\Drupal::` static calls:

| File | Line | Violation | Severity |
|------|------|-----------|----------|
| `ContentImportController.php` | 187 | `\Drupal::config()` | High - should be injected |
| `ContentImportController.php` | 258-268 | `\Drupal::logger()` | High - should be injected |
| `ContentImportController.php` | 896 | `\Drupal::config()` | High - should be injected |
| `ContentImportController.php` | 1300 | `\Drupal::config()` | High - should be injected |
| `ContentImportController.php` | 1310 | `\Drupal::service('file_system')` | High - should be injected |
| `ContentImportController.php` | 1353 | `\Drupal::httpClient()` | High - should be injected |
| `ContentImportForm.php` | 688 | `\Drupal::VERSION` | Low - constant access acceptable |
| `ContentImportForm.php` | 1177-1250 | `\Drupal::service()` in batch callbacks | **Acceptable** - required for batch |

**Impact:** Breaks testability, violates dependency injection principles (except for batch callbacks where it's necessary).

#### Issue 2.2.3: Plugin Directory Structure

**Current Structure:**
```
src/Plugin/
├── AiMigrationInterface.php      # Interface at plugin root
├── AiMigrationPluginBase.php     # Base at plugin root
├── AiMigrationPluginManager.php  # Manager at plugin root
├── AiMigration/                  # Implementations in subdirectory
│   ├── IntroductionContent.php
│   └── ...
```

**Per [Drupal Plugin Documentation](https://www.drupal.org/docs/drupal-apis/plugin-api/attribute-based-plugins):**

Plugin classes must be in `src/Plugin/{plugin_type}/` with namespace `Drupal\{module}\Plugin\{plugin_type}`. The documentation states: "The plugin is placed into the `Drupal\$module_name\Plugin\Block` namespace so the plugin manager can find it."

Per [Plugin Manager Documentation](https://www.drupal.org/docs/drupal-apis/plugin-api/creating-your-own-plugin-manager), plugin managers should extend `DefaultPluginManager` and can be placed at the module's top-level `src/` directory (like Drupal core's `ArchiverManager` in `Drupal\Core\Archiver`).

**Recommended Drupal Standard Structure:**
```
src/
├── AiMigrationInterface.php           # Top-level interface (Drupal convention)
├── AiMigrationPluginManager.php       # Top-level manager (per core examples)
├── Plugin/
│   └── AiMigration/                   # Plugin implementations only
│       ├── AiMigrationPluginBase.php  # Base class with implementations
│       ├── IntroductionContent.php
│       └── ...
```

**Note:** The current structure with interfaces/managers in `src/Plugin/` is functional but non-standard. Moving to the standard structure improves discoverability and aligns with Drupal core patterns.

### 2.3 Medium: Code Quality Issues

#### Issue 2.3.1: Generic Exception Usage

Throughout the codebase, generic `\Exception` is thrown:

```php
throw new \Exception("Extraction profile '$extraction_profile_id' not found.");
throw new \Exception('No content could be fetched from any of the provided URLs.');
throw new \Exception('Claude API key is not configured.');
```

**Recommendation:** Create custom exception classes:
- `ContentMigrationException`
- `ExtractionProfileNotFoundException`
- `ApiConfigurationException`
- `ContentFetchException`

#### Issue 2.3.2: Hard-coded Values

| Value | Location | Issue |
|-------|----------|-------|
| `'slice_content'` | Controller, multiple places | Hard-coded paragraph type |
| `'full_html'`, `'basic_html'` | Controller | Hard-coded text formats |
| `'main'` | Controller:362, 1068 | Hard-coded menu name |
| `600` timeout | Multiple API calls | Should be configurable |
| `'admin'` user uid:1 | Controller:882 | Hard-coded user ID |

#### Issue 2.3.3: Duplicate Code Patterns

The following patterns are duplicated across files:

1. **Composite key parsing** (4+ occurrences):
```php
$body_field_parts = explode(':', $fields['body']);
$field_type = $body_field_parts[0];
$field_name = $body_field_parts[1] ?? $fields['body'];
```

2. **Paragraph creation** (5+ occurrences):
```php
$paragraph = $this->entityTypeManager()->getStorage('paragraph')->create([
  'type' => 'slice_content',
  'field_content' => [
    'value' => $content,
    'format' => 'full_html',
  ],
]);
$paragraph->save();
```

3. **Menu link creation** (duplicated in Controller and Form batch callbacks)

#### Issue 2.3.4: Missing Type Declarations

Per [Drupal Coding Standards](https://www.drupal.org/docs/develop/standards/coding-standards): "Type hinting is required for all new functions and methods beginning with Drupal 9."

Some methods lack return type declarations:

| Method | File | Issue |
|--------|------|-------|
| `processTitle()` | ContentImportController.php:563 | Returns array but no declaration |
| `mergeUrlContents()` | ContentImportController.php:650 | Returns string but no declaration |
| `preservePageStructure()` | ContentImportController.php:710 | Returns string but no declaration |
| `processCsv()` | ContentImportController.php:861 | Returns void but no declaration |

#### Issue 2.3.5: Missing `declare(strict_types=1)`

Per Drupal coding standards, PHP files should include `declare(strict_types=1);` after the file DocBlock. Some files in the module have this, but it should be consistent across all PHP files.

### 2.4 Low: Minor Issues

#### Issue 2.4.1: Service Layer Responsibility

`UrlContentFetcherService` handles both:
1. HTTP content fetching
2. HTML parsing and transformation

These should be separate services per Single Responsibility Principle.

#### Issue 2.4.2: Batch Callback Pattern (Acceptable)

Batch callbacks in `ContentImportForm` are static methods that use `\Drupal::service()`:

```php
public static function processUrlBatch($url, ..., &$context): void {
  $controller = \Drupal::service('content_migration.content_import_controller');
  // ...
}
```

**Note:** This is actually the **correct pattern** for Drupal batch callbacks. Batch operations are serialized and cannot use dependency injection directly. Using `\Drupal::service()` in batch callbacks is necessary and acceptable.

However, the callbacks should call a dedicated **service** (not a controller). See Phase 2.3 for the recommended refactoring.

#### Issue 2.4.3: Form Service Visibility (Potential AJAX Issue)

Per [Drupal Form DI documentation](https://www.drupal.org/docs/drupal-apis/services-and-dependency-injection/dependency-injection-for-a-form): "Be sure to **not** set any service properties in your form class to have private visibility" as private properties won't serialize correctly during AJAX requests.

**Recommendation:** Audit all form classes to ensure injected services use `protected` (not `private`) visibility. The module currently uses `protected` which is correct.

---

## Part 3: Refactoring Plan

### Phase 1: Extract Services (Foundation)

**Goal:** Decompose the controller into focused services.

#### 1.1 Create Node Builder Service

**New file:** `src/Service/NodeBuilderService.php`

Responsibilities:
- Create nodes from extracted content
- Handle composite key field mapping
- Create paragraph entities
- Set field values with proper format

#### 1.2 Create Content Extraction Service

**New file:** `src/Service/ContentExtractionService.php`

Responsibilities:
- Profile-based extraction orchestration
- Content highlight application
- Plain text extraction

**Refactor:** Move `extractPlainText()`, `applyHighlights()` from Controller.

#### 1.3 Create Menu Service

**New file:** `src/Service/MenuLinkService.php`

Responsibilities:
- Create menu links
- Handle hierarchical menu structure
- Manage menu weights

#### 1.4 Create Redirect Service

**New file:** `src/Service/RedirectService.php`

Responsibilities:
- Create redirects from source URLs
- Validate redirect module availability

#### 1.5 Split UrlContentFetcherService

**Modify:** `src/Service/UrlContentFetcherService.php`
**New file:** `src/Service/HtmlParserService.php`

- `UrlContentFetcherService`: HTTP operations only
- `HtmlParserService`: DOM manipulation, CSS-to-XPath, HTML sanitization

### Phase 2: Refactor Controller

**Goal:** Reduce controller to orchestration role only.

#### 2.1 Implement Proper Dependency Injection

```php
class ContentImportController extends ControllerBase {

  public function __construct(
    protected NodeBuilderService $nodeBuilder,
    protected ContentExtractionService $contentExtraction,
    protected UrlContentFetcherService $urlFetcher,
    protected HtmlParserService $htmlParser,
    protected MenuLinkService $menuService,
    protected RedirectService $redirectService,
    protected AiMigrationPluginManager $aiPluginManager,
    protected ConfigFactoryInterface $configFactory,
  ) {}

  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get(NodeBuilderService::class),
      // ... inject all services
    );
  }
}
```

#### 2.2 Remove Service Registration

Remove from `services.yml`:
```yaml
# DELETE:
content_migration.content_import_controller:
  class: Drupal\content_migration\Controller\ContentImportController
```

#### 2.3 Create Import Processors

**New files:**
- `src/Import/UrlImportProcessor.php`
- `src/Import/PdfImportProcessor.php`
- `src/Import/CsvImportProcessor.php`
- `src/Import/TitleImportProcessor.php`
- `src/Import/ImportProcessorInterface.php`

Each processor handles one import type, using the shared services.

### Phase 3: Refactor Form

**Goal:** Simplify form and improve batch processing.

#### 3.1 Extract Form Builders

**New files:**
- `src/Form/Builder/UrlImportFormBuilder.php`
- `src/Form/Builder/PdfImportFormBuilder.php`
- `src/Form/Builder/CsvImportFormBuilder.php`
- `src/Form/Builder/TitleImportFormBuilder.php`

Each builder handles form elements for one import type.

#### 3.2 Create Batch Processor Service

**New file:** `src/Batch/ImportBatchProcessor.php`

```php
class ImportBatchProcessor {

  public function __construct(
    protected UrlImportProcessor $urlProcessor,
    protected PdfImportProcessor $pdfProcessor,
    // ...
  ) {}

  public function processUrlBatch(string $url, array $config, array &$context): void {
    // Delegate to processor
  }
}
```

#### 3.3 Refactor Batch Callbacks

Change from static methods using `\Drupal::service()` to callable array syntax:

```php
$batch['operations'][] = [
  [ImportBatchProcessor::class, 'processUrlBatch'],
  [$url, $config],
];
```

### Phase 4: Plugin Architecture Cleanup

**Goal:** Align with Drupal plugin conventions.

#### 4.1 Reorganize Plugin Files

**Move:**
- `src/Plugin/AiMigrationInterface.php` → `src/AiMigrationInterface.php`
- `src/Plugin/AiMigrationPluginManager.php` → `src/AiMigrationPluginManager.php`
- Keep `AiMigrationPluginBase.php` in `src/Plugin/AiMigration/`

Same for QualityAnalysis plugins.

#### 4.2 Remove Static Calls from Plugins

Audit and fix any `\Drupal::` calls in plugin implementations.

### Phase 5: Exception Handling

**Goal:** Implement proper exception hierarchy.

#### 5.1 Create Exception Classes

**New directory:** `src/Exception/`

```php
// src/Exception/ContentMigrationException.php
class ContentMigrationException extends \RuntimeException {}

// src/Exception/ExtractionProfileNotFoundException.php
class ExtractionProfileNotFoundException extends ContentMigrationException {}

// src/Exception/ApiConfigurationException.php
class ApiConfigurationException extends ContentMigrationException {}

// src/Exception/ContentFetchException.php
class ContentFetchException extends ContentMigrationException {}

// src/Exception/ContentParseException.php
class ContentParseException extends ContentMigrationException {}
```

### Phase 6: Configuration and Constants

**Goal:** Remove hard-coded values.

#### 6.1 Add Configuration Options

Add to settings form and schema:
- Default paragraph type for content
- Default text format
- API timeout duration
- Default menu name

#### 6.2 Create Constants Class

**New file:** `src/ContentMigrationConstants.php`

```php
final class ContentMigrationConstants {
  public const DEFAULT_PARAGRAPH_TYPE = 'slice_content';
  public const DEFAULT_TEXT_FORMAT = 'full_html';
  public const DEFAULT_MENU_NAME = 'main';
  public const API_TIMEOUT = 600;
}
```

---

## Part 4: Implementation Phases

### Recommended Order

| Phase | Effort | Risk | Dependency |
|-------|--------|------|------------|
| Phase 5: Exceptions | Low | Low | None |
| Phase 6: Configuration | Low | Low | None |
| Phase 1: Extract Services | High | Medium | None |
| Phase 4: Plugin Cleanup | Medium | Low | None |
| Phase 2: Refactor Controller | High | High | Phase 1 |
| Phase 3: Refactor Form | High | Medium | Phase 1, 2 |

### Suggested Sprint Breakdown

**Sprint 1: Foundation**
- Phase 5: Exception classes
- Phase 6: Configuration constants
- Phase 1.5: Split UrlContentFetcherService

**Sprint 2: Services**
- Phase 1.1: NodeBuilderService
- Phase 1.2: ContentExtractionService
- Phase 1.3-1.4: Menu and Redirect services

**Sprint 3: Controller Refactor**
- Phase 2.1-2.2: Controller DI refactor
- Phase 2.3: Import processors

**Sprint 4: Form and Plugins**
- Phase 3: Form refactoring
- Phase 4: Plugin reorganization

---

## Part 5: Target Architecture

### Proposed Directory Structure

```
src/
├── Access/
│   └── QualityFeaturesAccessCheck.php
├── Attribute/
│   ├── AiMigration.php
│   └── QualityAnalysis.php
├── Batch/
│   └── ImportBatchProcessor.php
├── Controller/
│   └── ContentImportController.php (200-300 lines)
├── Exception/
│   ├── ApiConfigurationException.php
│   ├── ContentFetchException.php
│   ├── ContentMigrationException.php
│   ├── ContentParseException.php
│   └── ExtractionProfileNotFoundException.php
├── Form/
│   ├── Builder/
│   │   ├── CsvImportFormBuilder.php
│   │   ├── PdfImportFormBuilder.php
│   │   ├── TitleImportFormBuilder.php
│   │   └── UrlImportFormBuilder.php
│   ├── ContentImportForm.php (400-500 lines)
│   ├── ContentQualityCheckForm.php
│   ├── ContentQualityDashboardForm.php
│   └── SettingsForm.php
├── Import/
│   ├── CsvImportProcessor.php
│   ├── ImportProcessorInterface.php
│   ├── PdfImportProcessor.php
│   ├── TitleImportProcessor.php
│   └── UrlImportProcessor.php
├── Plugin/
│   ├── AiMigration/
│   │   ├── AiMigrationPluginBase.php
│   │   ├── IntroductionContent.php
│   │   ├── RewriteContent.php
│   │   ├── SiteSectionSuggestions.php
│   │   ├── SummariseContentBase.php
│   │   ├── SummaryContent.php
│   │   ├── TaxonomyBase.php
│   │   └── TaxonomySuggestions.php
│   └── QualityAnalysis/
│       ├── FactualAccuracyAnalysis.php
│       ├── QualityAnalysisPluginBase.php
│       └── StyleGuideAnalysis.php
├── Service/
│   ├── ContentExtractionService.php
│   ├── ContentQualityService.php
│   ├── HtmlParserService.php
│   ├── MenuLinkService.php
│   ├── NodeBuilderService.php
│   ├── RedirectService.php
│   ├── TaxonomyPromptService.php
│   └── UrlContentFetcherService.php
├── AiMigrationInterface.php
├── AiMigrationPluginManager.php
├── ContentMigrationConstants.php
├── QualityAnalysisInterface.php
└── QualityAnalysisPluginManager.php
```

### Services Registry (Updated)

```yaml
services:
  _defaults:
    autowire: true

  # Content fetching and parsing
  Drupal\content_migration\Service\UrlContentFetcherService: ~
  Drupal\content_migration\Service\HtmlParserService: ~
  Drupal\content_migration\Service\ContentExtractionService: ~

  # Node and entity operations
  Drupal\content_migration\Service\NodeBuilderService: ~
  Drupal\content_migration\Service\MenuLinkService: ~
  Drupal\content_migration\Service\RedirectService: ~

  # Business logic
  Drupal\content_migration\Service\TaxonomyPromptService: ~
  Drupal\content_migration\Service\ContentQualityService: ~

  # Import processors
  Drupal\content_migration\Import\UrlImportProcessor: ~
  Drupal\content_migration\Import\PdfImportProcessor: ~
  Drupal\content_migration\Import\CsvImportProcessor: ~
  Drupal\content_migration\Import\TitleImportProcessor: ~

  # Batch processing
  Drupal\content_migration\Batch\ImportBatchProcessor: ~

  # Plugin managers
  plugin.manager.ai_migration:
    class: Drupal\content_migration\AiMigrationPluginManager
    parent: default_plugin_manager
  Drupal\content_migration\AiMigrationPluginManager: '@plugin.manager.ai_migration'

  plugin.manager.quality_analysis:
    class: Drupal\content_migration\QualityAnalysisPluginManager
    parent: default_plugin_manager
  Drupal\content_migration\QualityAnalysisPluginManager: '@plugin.manager.quality_analysis'

  # Access checks
  content_migration.quality_features_access_check:
    class: Drupal\content_migration\Access\QualityFeaturesAccessCheck
    tags:
      - { name: access_check, applies_to: _quality_features_enabled }

  # Logging
  logger.channel.content_migration:
    parent: logger.channel_base
    arguments: ['content_migration']
```

---

## Part 6: Testing Strategy

### Unit Tests Required

| Component | Test Coverage |
|-----------|---------------|
| NodeBuilderService | Field mapping, paragraph creation |
| HtmlParserService | CSS-to-XPath conversion, content extraction |
| ContentExtractionService | Profile-based extraction |
| Exception classes | Exception hierarchy |
| Import processors | Each import type |

### Integration Tests Required

| Scenario | Coverage |
|----------|----------|
| URL import end-to-end | Full workflow |
| CSV import with hierarchy | Menu structure |
| PDF extraction | Claude API integration |
| AI plugin processing | Plugin orchestration |

---

## Part 7: Risk Mitigation

### Breaking Changes

The refactoring should maintain backward compatibility for:
- Configuration schema (no changes to saved config)
- Plugin API (no changes to plugin interface)
- Routing (no changes to URLs)
- Permissions (no changes to permission names)

### Incremental Delivery

Each phase should:
1. Be independently deployable
2. Include comprehensive tests
3. Maintain existing functionality
4. Be reversible if issues arise

---

## Appendix A: Code Smells Summary

| Smell | Count | Severity | Notes |
|-------|-------|----------|-------|
| Static `\Drupal::` calls | 15+ | High | Except batch callbacks (acceptable) |
| God class (>500 lines) | 2 | High | Controller + Form |
| Duplicate code blocks | 10+ | Medium | Composite key parsing, paragraph creation |
| Missing type declarations | 5+ | Low | Required since Drupal 9 |
| Hard-coded values | 8+ | Medium | paragraph type, text formats, menu name |
| Generic exceptions | 10+ | Medium | Should use custom exception classes |
| Missing strict_types | Some | Low | Should be consistent |

## Appendix B: Compliance Summary

### Already Compliant with Drupal Standards

| Area | Status | Notes |
|------|--------|-------|
| PSR-4 Autoloading | ✅ Compliant | Proper `src/` structure |
| PHP 8 Attributes for Plugins | ✅ Compliant | Uses Drupal 10.2+ pattern |
| Plugin Namespace | ✅ Compliant | `Drupal\{module}\Plugin\{type}` |
| Service Naming | ✅ Compliant | `plugin.manager.` prefix |
| AutowireTrait for Forms | ✅ Compliant | Modern Drupal 10.2+ pattern |
| Form Service Visibility | ✅ Compliant | Uses `protected` not `private` |
| Interface Naming | ✅ Compliant | Ends with `Interface` suffix |
| ContainerFactoryPluginInterface | ✅ Compliant | Proper plugin DI |

### Requires Refactoring

| Area | Current | Standard |
|------|---------|----------|
| Controller DI | Service registration | `create()` factory method |
| Static \Drupal:: calls | Throughout controller | Constructor injection |
| Plugin Manager location | `src/Plugin/` | `src/` (top level) |
| Plugin Interface location | `src/Plugin/` | `src/` (top level) |
| Class size | 1400+ lines | <500 lines recommended |
| Exception types | Generic `\Exception` | Custom exception classes |

## Appendix C: Drupal Documentation References

- [Drupal Coding Standards](https://www.drupal.org/docs/develop/standards/coding-standards)
- [Plugin API Overview](https://www.drupal.org/docs/drupal-apis/plugin-api)
- [Attribute-based Plugins](https://www.drupal.org/docs/drupal-apis/plugin-api/attribute-based-plugins)
- [Creating Your Own Plugin Manager](https://www.drupal.org/docs/drupal-apis/plugin-api/creating-your-own-plugin-manager)
- [Services and Dependency Injection](https://www.drupal.org/docs/drupal-apis/services-and-dependency-injection)
- [Dependency Injection for Forms](https://www.drupal.org/docs/drupal-apis/services-and-dependency-injection/dependency-injection-for-a-form)
- [Structure of a Service File](https://www.drupal.org/docs/drupal-apis/services-and-dependency-injection/structure-of-a-service-file)
- [Creating Modules](https://www.drupal.org/docs/develop/creating-modules)
- [Form API](https://www.drupal.org/docs/drupal-apis/form-api)
