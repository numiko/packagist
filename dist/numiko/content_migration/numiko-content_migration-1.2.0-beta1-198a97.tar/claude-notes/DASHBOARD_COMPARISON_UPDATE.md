# Dashboard Side-by-Side Comparison Update

## Date
2025-11-05

## Summary

Updated the Quality Dashboard to display the same three-column side-by-side comparison when expanding factual accuracy plugin results. The dashboard now reads the `sections` array from the stored JSON and renders it using the same format as the Content Quality Check form.

## Changes Made

### File: `src/Form/ContentQualityDashboardForm.php`

#### 1. Updated `renderSinglePluginDetailView()` (lines 625-634)

Added special handling for factual accuracy comparisons:

```php
// Special handling for factual accuracy comparison (side-by-side view).
if ($plugin_id === 'factual_accuracy') {
  foreach ($plugin_assessments as $content_type => $assess) {
    if ($content_type === 'comparison' && !empty($assess['sections'])) {
      $output .= $this->formatFactualAccuracySections($assess['sections']);
      $output .= '</div>';
      return $output;
    }
  }
}
```

**How it works:**
- Checks if the plugin ID is `factual_accuracy`
- Looks for assessments with `content_type: "comparison"`
- If the assessment has a `sections` array, renders using the three-column format
- Otherwise falls back to the standard area-based display

#### 2. Added `formatFactualAccuracySections()` Method (lines 1024-1135)

New method that formats the three-column side-by-side comparison:

```php
protected function formatFactualAccuracySections(array $sections): string
```

**Features:**
- Three-column table layout (Original Field | New Field | Differences)
- Color-coded column headers and backgrounds:
  - Original Field: Light yellow (#fffbf0)
  - New Field: Light blue (#f0f8ff)
  - Differences: Light gray (#f9f9f9)
- Section header showing section number, description, and accuracy score
- Color-coded difference badges:
  - 🔵 **NEW**: Blue (#007bff) - Facts added
  - 🟨 **MISSING**: Yellow (#ffc107) - Facts removed
  - 🔵 **CHANGED**: Cyan (#17a2b8) - Facts altered
  - 🔴 **INCORRECT**: Red (#dc3545) - Facts wrong
  - ✅ **NONE**: Green checkmark - No differences
- Extracted text from both original and new fields displayed side-by-side

## User Experience

### Before This Update

When clicking on a factual accuracy score in the dashboard, users saw:
- A generic area-by-area score table
- No visibility into what actually changed between fields
- No extracted text to review

### After This Update

When clicking on a factual accuracy score in the dashboard, users now see:
- **Section-by-section breakdown** with numbered sections
- **Side-by-side comparison** showing original text vs new text
- **Extracted text** from both fields for each section (2-4 sentences)
- **Color-coded differences** with clear badges (NEW/MISSING/CHANGED/INCORRECT)
- **Accuracy score per section** prominently displayed

## Example Dashboard Display

When expanding a factual accuracy comparison row:

```
┌─────────────────────────────────────────────────────────────────────┐
│ Factual Accuracy Check - Detailed Score Breakdown                    │
├─────────────────────────────────────────────────────────────────────┤
│ Section-by-Section Before/After Comparison:                          │
│                                                                       │
│ ┌───────────────────────────────────────────────────────────────┐   │
│ │ Section 1: Introduction and Background      Accuracy: 100%    │   │
│ ├─────────────────┬─────────────────┬─────────────────────────┤   │
│ │ ORIGINAL FIELD  │ NEW FIELD       │ DIFFERENCES             │   │
│ ├─────────────────┼─────────────────┼─────────────────────────┤   │
│ │ Our company was │ We were founded │ ✓ No factual            │   │
│ │ founded in 1995 │ in 1995 by John │   differences in        │   │
│ │ by John Smith...│ Smith...        │   this section          │   │
│ └─────────────────┴─────────────────┴─────────────────────────┘   │
│                                                                       │
│ ┌───────────────────────────────────────────────────────────────┐   │
│ │ Section 2: Product Features                  Accuracy: 85%    │   │
│ ├─────────────────┬─────────────────┬─────────────────────────┤   │
│ │ ORIGINAL FIELD  │ NEW FIELD       │ DIFFERENCES             │   │
│ ├─────────────────┼─────────────────┼─────────────────────────┤   │
│ │ Launched in     │ Launched in     │ [NEW] Partnership with  │   │
│ │ March 2023,     │ 2023 with VSC   │ VSC mentioned in new    │   │
│ │ serving 500     │ partnership,    │ field                   │   │
│ │ companies...    │ serving         │                         │   │
│ │                 │ hundreds...     │ [MISSING] Specific      │   │
│ │                 │                 │ month (March) omitted   │   │
│ │                 │                 │                         │   │
│ │                 │                 │ [CHANGED] "500" became  │   │
│ │                 │                 │ "hundreds" - less       │   │
│ │                 │                 │ precise                 │   │
│ └─────────────────┴─────────────────┴─────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────┘
```

## Benefits

### 1. **Consistent Experience**
The dashboard now shows exactly the same comparison format as the Content Quality Check form, providing consistency across the system.

### 2. **No Re-Analysis Required**
All comparison data is loaded from the stored JSON - no need to re-run the expensive AI analysis.

### 3. **Better Decision Making**
Users can see the actual text extracts and specific differences, making it easier to:
- Understand what changed between versions
- Judge whether changes are acceptable
- Identify problematic sections that need revision

### 4. **Complete Information**
Users now see:
- What facts were added (NEW)
- What facts were removed (MISSING)
- What facts changed (CHANGED/INCORRECT)
- The actual text context for each change

### 5. **Historical Review**
Since the data is stored in JSON, users can review past assessments and see the exact comparison that was generated at that time.

## Technical Details

### Data Flow

1. **Storage**: When a factual accuracy check runs, the full sections array is saved to the quality assessment field JSON
2. **Retrieval**: Dashboard loads all assessment data from nodes with quality assessment fields
3. **Detection**: When rendering detail view, checks if plugin is `factual_accuracy` and has `sections` array
4. **Display**: Renders using `formatFactualAccuracySections()` method with three-column table layout

### Fallback Behavior

If a factual accuracy assessment doesn't have a `sections` array (e.g., older assessments before this feature), the dashboard falls back to the standard area-based display showing scores by area.

## Testing

### Test Steps

1. Run a factual accuracy check on a page with both original and rewritten content
2. Navigate to the Quality Dashboard
3. Find the page in the dashboard table
4. Click on the factual accuracy score cell to expand details
5. Verify:
   - Three-column layout displays correctly
   - Original text and new text are shown side-by-side
   - Differences are listed with proper color-coded badges
   - Section headers show accuracy scores
   - All badges (NEW/MISSING/CHANGED/INCORRECT) display with correct colors

### Expected Results

✅ Dashboard shows the same three-column side-by-side comparison as the check form
✅ Original text, new text, and differences are all visible
✅ Color-coded badges match the check form styling
✅ Section accuracy scores are prominently displayed
✅ No errors in browser console
✅ Layout is clean and readable

## Files Modified

1. **src/Form/ContentQualityDashboardForm.php**
   - Updated `renderSinglePluginDetailView()` to detect factual accuracy comparisons
   - Added `formatFactualAccuracySections()` method for three-column display

## Related Documentation

- [JSON Storage Update](JSON_STORAGE_UPDATE.md) - How sections data is stored
- [Side-by-Side Comparison Update](SIDE_BY_SIDE_COMPARISON_UPDATE.md) - Original implementation
- [New/Missing Facts Update](NEW_MISSING_FACTS_UPDATE.md) - Enhanced fact detection
- [Quality Assessment JSON Schema](QUALITY_ASSESSMENT_JSON_SCHEMA.md) - Complete JSON structure

## Conclusion

The dashboard now provides a rich, detailed view of factual accuracy comparisons using the same three-column side-by-side format as the check form. This gives users complete visibility into what changed between the original and new content fields, with clear visual indicators for NEW, MISSING, CHANGED, and INCORRECT facts. All of this is done without re-running the AI analysis, using the structured data saved in the JSON assessment.
