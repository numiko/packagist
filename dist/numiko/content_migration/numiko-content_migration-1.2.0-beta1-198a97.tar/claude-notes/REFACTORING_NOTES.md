# Factual Accuracy Plugin Refactoring

## Date
2025-11-04

## Summary

Refactored the Factual Accuracy Analysis plugin to clearly communicate that it compares **content fields within the same page**, not content from two different pages.

## What Changed

### 1. Class Documentation (FactualAccuracyAnalysis.php)

**Before:**
```php
/**
 * Analyzes factual accuracy by comparing original and rewritten content.
 */
```

**After:**
```php
/**
 * Compares different content fields within the same page for factual accuracy.
 *
 * This plugin is specifically designed to compare content from different fields
 * on the SAME page/node (e.g., original content field vs rewritten content field,
 * or original content vs paragraph field content).
 *
 * This plugin does NOT compare content from two different pages.
 */
```

### 2. New Primary Method: `compareFieldContent()`

Added a new method with clearer naming and documentation:

```php
/**
 * Compares content from two different fields within the same page.
 *
 * This method compares content from different fields on the same node/page
 * to verify that factual information has been preserved. Common use cases:
 * - Original content field vs rewritten content field
 * - Original content field vs paragraph field content
 * - Body field vs migrated content field
 *
 * IMPORTANT: Both content pieces must be from the SAME page/node.
 *
 * @param string $original_content
 *   Content from the original/source field on this page.
 * @param string $rewritten_content
 *   Content from the new/target field on this page.
 * @param \Drupal\node\NodeInterface $node
 *   The node/page containing both fields being compared.
 */
public function compareFieldContent(...)
```

### 3. Backwards Compatibility

The old `compareContent()` method still works but now delegates to `compareFieldContent()`:

```php
/**
 * @deprecated Use compareFieldContent() instead for clarity.
 */
public function compareContent(...) {
  return $this->compareFieldContent(...);
}
```

**No breaking changes** - existing code continues to work.

### 4. Updated AI Prompt

**Before:**
- "I need you to compare two versions of content..."
- "ORIGINAL CONTENT:" / "REWRITTEN CONTENT:"

**After:**
- "I need you to compare content from two different fields within the same page..."
- "ORIGINAL FIELD CONTENT:" / "NEW FIELD CONTENT:"
- Explicit instruction: "Remember: These are different content fields on the SAME PAGE"

### 5. Updated Logging

All log messages now emphasize "field comparison within same page":

```php
$this->logger->info('Starting field comparison for node @nid (comparing fields within the same page)');
$this->logger->info('Original field content length: @orig chars, New field content length: @new chars');
```

### 6. Updated Documentation

**FACTUAL_ACCURACY_PLUGIN.md** now includes:

- Prominent note at top: "This plugin compares fields on the SAME page"
- New "Common Use Cases" section with examples
- Updated "Technical Details" with "Important Design Principle" section
- All references changed from "content versions" to "content fields"

## Why This Matters

### Prevents Misuse

The old naming ("compareContent") could be misinterpreted as comparing:
- Two different pages
- Content from different nodes
- Historical versions of the same page

This refactoring makes it crystal clear the plugin is for **intra-page field comparison only**.

### Clarifies Intent

When reviewing code or API calls, it's now immediately obvious:
```php
// Old - unclear what's being compared
$plugin->compareContent($content1, $content2, $node);

// New - clear this is comparing fields on same page
$plugin->compareFieldContent($original_field, $new_field, $node);
```

### Better AI Prompting

The AI now receives explicit context that it's comparing fields on the same page, which should improve:
- Understanding of the comparison context
- Interpretation of what "differences" mean
- Quality of factual accuracy analysis

## Migration Path

**For existing code:**
1. No changes required - `compareContent()` still works
2. Optional: Update to use `compareFieldContent()` for clarity
3. No rush - the deprecated method will remain for backwards compatibility

**For new code:**
- Use `compareFieldContent()` for clarity
- Document clearly that you're comparing fields on the same page

## Use Cases (Confirmed)

The plugin is correctly used for:

✓ Comparing original body field vs rewritten_content field on **same page**
✓ Comparing original body field vs paragraph fields on **same page**
✓ Comparing any two content fields on **same page**

The plugin should NOT be used for:

✗ Comparing content from two different pages/nodes
✗ Comparing historical revisions (use revision comparison instead)
✗ Cross-page content similarity checks

## Files Modified

1. `src/Plugin/QualityAnalysis/FactualAccuracyAnalysis.php`
   - Updated class documentation
   - Added `compareFieldContent()` method
   - Made `compareContent()` a backwards compatibility wrapper
   - Updated AI prompt text
   - Updated logging messages

2. `FACTUAL_ACCURACY_PLUGIN.md`
   - Added prominent warning about same-page comparison
   - Added "Common Use Cases" section
   - Updated all terminology from "versions" to "fields"
   - Added "Important Design Principle" section
   - Updated technical documentation

3. `REFACTORING_NOTES.md` (this file)
   - Documentation of the refactoring

## Testing

No functional changes - all existing tests should pass without modification.

The refactoring is purely about:
- Clearer naming
- Better documentation
- More explicit logging
- Improved AI prompt context

## Future Considerations

If there's ever a need to compare content from **different pages**, create a separate plugin:
- `ContentSimilarityAnalysis` - for comparing two different pages
- `RevisionComparisonAnalysis` - for comparing historical revisions
- Keep `FactualAccuracyAnalysis` focused on same-page field comparison
