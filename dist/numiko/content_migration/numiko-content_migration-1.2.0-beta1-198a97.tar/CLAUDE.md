# Content Migration Module - Claude Instructions

## Commands

```bash
# Run tests
docker-compose exec web ./vendor/bin/phpunit --testsuite unit

# Clear cache (after service/config changes)
docker-compose exec web drush cr
```

## Testing Process

1. Update/create tests for any code changes
2. Tests go in `tests/src/Unit/` mirroring `src/` structure
3. Run tests before committing

## Drupal Standards

### Required

- `declare(strict_types=1);` in all PHP files
- Type declarations on all methods
- Constructor injection for dependencies (no `\Drupal::` static calls)
- `protected` visibility for form service properties (not `private`)
- Custom exceptions in `src/Exception/` (not generic `\Exception`)

### Controllers

Use `create()` factory, not service registration:

```php
public static function create(ContainerInterface $container): static {
  return new static($container->get('my.service'));
}
```

### Plugins

- Interfaces/managers at `src/` top level
- Plugin classes in `src/Plugin/{type}/`
- Use PHP 8 attributes for discovery

### Avoid

- Static `\Drupal::` calls (except batch callbacks)
- Hard-coded values (use constants class or config)
- God classes (>500 lines)
- Duplicate code patterns
