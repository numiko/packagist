<?php

declare(strict_types=1);

namespace Drupal\content_migration\Import;

use Drupal\node\NodeInterface;

/**
 * Import processor for creating empty pages from titles.
 *
 * This processor creates pages with just a title and empty body content,
 * useful for creating placeholder pages in a site structure.
 */
class TitleImportProcessor extends ImportProcessorBase {

  /**
   * {@inheritdoc}
   */
  public function getId(): string {
    return 'title';
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return 'Title Import';
  }

  /**
   * {@inheritdoc}
   */
  public function validateData(array $data): array {
    $errors = [];

    if (empty($data['title'])) {
      $errors[] = 'Title is required.';
    }

    return $errors;
  }

  /**
   * {@inheritdoc}
   */
  public function process(array $data, array $configuration): NodeInterface {
    $title = $data['title'];
    $contentType = $configuration['content_type'];

    // Create the node.
    $node = $this->nodeBuilder->createNode($contentType, $title);

    // Set empty content for the body field if specified.
    $fields = $configuration['fields'] ?? [];
    if (!empty($fields['body'])) {
      $this->nodeBuilder->setFieldValue($node, $fields['body'], '');
    }

    // Handle taxonomy terms.
    $this->handleTaxonomyTerms($node, $configuration);

    // Save the node.
    $node->save();

    // Handle menu link.
    $this->handleMenuLink($node, $configuration);

    $this->messenger->addStatus($this->t('Empty page "@title" created successfully as node @id.', [
      '@title' => $title,
      '@id' => $node->id(),
    ]));

    return $node;
  }

}
