<?php

declare(strict_types=1);

namespace Drupal\content_migration\Import;

use Drupal\content_migration\AiMigrationPluginManager;
use Drupal\content_migration\Service\ContentExtractionService;
use Drupal\content_migration\Service\HtmlParserService;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\content_migration\Service\RedirectService;
use Drupal\content_migration\Service\UrlContentFetcherService;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\node\NodeInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Import processor for CSV-based hierarchical page imports.
 *
 * Creates pages with menu hierarchy based on CSV data containing
 * page_title, content_type, parent_page_title, and optional source_url.
 */
class CsvImportProcessor extends ImportProcessorBase {

  /**
   * Constructs a CsvImportProcessor object.
   *
   * @param \Drupal\content_migration\Service\NodeBuilderService $nodeBuilder
   *   The node builder service.
   * @param \Drupal\content_migration\Service\MenuLinkService $menuLinkService
   *   The menu link service.
   * @param \Drupal\content_migration\Service\RedirectService $redirectService
   *   The redirect service.
   * @param \Drupal\content_migration\AiMigrationPluginManager $aiMigrationPluginManager
   *   The AI migration plugin manager.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   * @param \Drupal\content_migration\Service\UrlContentFetcherService $urlContentFetcher
   *   The URL content fetcher service.
   * @param \Drupal\content_migration\Service\ContentExtractionService $contentExtraction
   *   The content extraction service.
   * @param \Drupal\content_migration\Service\HtmlParserService $htmlParser
   *   The HTML parser service.
   */
  public function __construct(
    NodeBuilderService $nodeBuilder,
    MenuLinkService $menuLinkService,
    RedirectService $redirectService,
    AiMigrationPluginManager $aiMigrationPluginManager,
    MessengerInterface $messenger,
    #[Autowire(service: 'logger.channel.content_migration')]
    LoggerInterface $logger,
    protected readonly UrlContentFetcherService $urlContentFetcher,
    protected readonly ContentExtractionService $contentExtraction,
    protected readonly HtmlParserService $htmlParser,
  ) {
    parent::__construct(
      $nodeBuilder,
      $menuLinkService,
      $redirectService,
      $aiMigrationPluginManager,
      $messenger,
      $logger
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getId(): string {
    return 'csv';
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return 'CSV Import';
  }

  /**
   * {@inheritdoc}
   */
  public function validateData(array $data): array {
    $errors = [];

    if (empty($data['row'])) {
      $errors[] = 'CSV row data is required.';
      return $errors;
    }

    $row = $data['row'];

    if (empty($row['page_title'])) {
      $errors[] = 'Page title is required in CSV row.';
    }

    if (empty($row['content_type'])) {
      $errors[] = 'Content type is required in CSV row.';
    }

    return $errors;
  }

  /**
   * {@inheritdoc}
   */
  public function process(array $data, array $configuration): NodeInterface {
    $row = $data['row'];
    $pageTitle = trim($row['page_title']);
    $contentType = $row['content_type'];
    $sourceUrl = isset($row['source_url']) ? trim($row['source_url']) : '';

    // Track menu links and weights from batch context.
    $menuLinks = $data['menu_links'] ?? [];
    $weightCounters = $data['weight_counters'] ?? [];
    $parentPageTitle = trim($row['parent_page_title'] ?? '');

    // Create the node.
    $node = $this->nodeBuilder->createNode($contentType, $pageTitle);

    // If source_url is provided, fetch content and populate fields.
    if (!empty($sourceUrl)) {
      $this->populateFromUrl($node, $sourceUrl, $contentType, $configuration);
    }

    // Apply taxonomy terms if provided.
    $this->handleTaxonomyTerms($node, $configuration);

    // Save the node.
    $node->save();

    // Create redirect if requested and source_url is provided.
    if (!empty($sourceUrl) && !empty($configuration['create_redirects'])) {
      $this->redirectService->createRedirect($sourceUrl, $node);
    }

    // Create menu link with proper hierarchy.
    $parentMenuPluginId = $this->resolveParentMenuPluginId(
      $parentPageTitle,
      $menuLinks
    );

    $weight = $this->calculateWeight($parentPageTitle, $weightCounters);

    $menuLink = $this->menuLinkService->createHierarchicalMenuLink(
      $node,
      $pageTitle,
      $parentMenuPluginId,
      $weight
    );

    // Store the menu link for child pages to reference.
    if ($menuLink) {
      $data['menu_links'][$pageTitle] = $menuLink;
    }

    $this->messenger->addStatus($this->t('Created page "@title" with menu link in hierarchy.', [
      '@title' => $pageTitle,
    ]));

    return $node;
  }

  /**
   * Processes an entire CSV dataset creating hierarchical pages.
   *
   * @param array $csvData
   *   The parsed CSV data.
   * @param array $configuration
   *   The import configuration.
   *
   * @return array
   *   Array of created nodes.
   */
  public function processAll(array $csvData, array $configuration): array {
    $createdPages = [];
    $menuLinks = [];
    $weightCounters = [];

    foreach ($csvData as $row) {
      $data = [
        'row' => $row,
        'menu_links' => $menuLinks,
        'weight_counters' => $weightCounters,
      ];

      $node = $this->process($data, $configuration);
      $pageTitle = trim($row['page_title']);
      $createdPages[$pageTitle] = $node;

      // Update tracking arrays.
      if (isset($data['menu_links'][$pageTitle])) {
        $menuLinks[$pageTitle] = $data['menu_links'][$pageTitle];
      }
    }

    $this->messenger->addStatus($this->t('Successfully created @count hierarchical pages from CSV.', [
      '@count' => count($csvData),
    ]));

    return $createdPages;
  }

  /**
   * Populates node fields from URL content.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to populate.
   * @param string $sourceUrl
   *   The URL to fetch content from.
   * @param string $contentType
   *   The content type.
   * @param array $configuration
   *   The import configuration.
   */
  protected function populateFromUrl(NodeInterface $node, string $sourceUrl, string $contentType, array $configuration): void {
    $fieldMappings = $configuration['field_mappings'][$contentType] ?? [];
    $extractionProfile = $this->getExtractionProfile($configuration);

    try {
      $htmlContent = $this->urlContentFetcher->fetchContent($sourceUrl);

      if (!empty($extractionProfile) && $this->contentExtraction->profileExists($extractionProfile)) {
        $this->populateFromProfile($node, $htmlContent, $contentType, $extractionProfile);
      }
      else {
        $this->populateFromStandardExtraction($node, $htmlContent, $fieldMappings, $configuration);
      }
    }
    catch (\Exception $e) {
      $this->messenger->addWarning($this->t('Could not fetch content from @url for page "@title": @error', [
        '@url' => $sourceUrl,
        '@title' => $node->getTitle(),
        '@error' => $e->getMessage(),
      ]));
    }
  }

  /**
   * Populates node from profile-based extraction.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to populate.
   * @param string $htmlContent
   *   The HTML content.
   * @param string $contentType
   *   The content type.
   * @param string $extractionProfile
   *   The extraction profile ID.
   */
  protected function populateFromProfile(NodeInterface $node, string $htmlContent, string $contentType, string $extractionProfile): void {
    $extractionResult = $this->contentExtraction->extractFromHtmlWithProfile(
      $htmlContent,
      $extractionProfile
    );

    $targetField = $extractionResult['target_field'] ?? '';
    if (empty($targetField)) {
      return;
    }

    $parsed = $this->nodeBuilder->parseCompositeKey($targetField);
    $paragraphFieldName = $parsed['name'];

    // Process extractions.
    $processed = $this->contentExtraction->processExtractions(
      $extractionResult['extractions'],
      $contentType
    );

    // Process field extractions.
    foreach ($processed['field_extractions'] as $fieldKey => $contents) {
      $fieldMapping = $processed['field_mappings'][$fieldKey] ?? '';
      if (!empty($fieldMapping)) {
        $mappingParsed = $this->nodeBuilder->parseCompositeKey($fieldMapping);
        $actualFieldName = $mappingParsed['name'];

        $cleanedContents = array_map(
          fn($c) => $this->nodeBuilder->extractPlainText($c),
          $contents
        );
        $combinedContent = trim(implode("\n", $cleanedContents));

        $node->set($actualFieldName, $combinedContent);
      }
    }

    // Get content highlights.
    $contentHighlights = $this->contentExtraction->getContentHighlights();

    // Create paragraphs.
    $paragraphReferences = [];
    foreach ($processed['paragraph_extractions'] as $extraction) {
      $content = $extraction['content'];

      if (!empty($contentHighlights)) {
        $content = $this->htmlParser->applyHighlights($content, $contentHighlights);
      }

      $paragraphRef = $this->nodeBuilder->createAndSaveParagraph(
        $extraction['paragraph_type'],
        $content
      );
      $paragraphReferences[] = $paragraphRef;
    }

    if (!empty($paragraphReferences)) {
      $this->nodeBuilder->setParagraphReferences($node, $paragraphFieldName, $paragraphReferences);
    }
  }

  /**
   * Populates node from standard extraction.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to populate.
   * @param string $htmlContent
   *   The HTML content.
   * @param array $fieldMappings
   *   The field mappings for the content type.
   * @param array $configuration
   *   The import configuration.
   */
  protected function populateFromStandardExtraction(NodeInterface $node, string $htmlContent, array $fieldMappings, array $configuration): void {
    $extractionMode = $this->getExtractionMode($configuration);
    $contentSelector = $this->getContentSelector($configuration);
    $tagsToRemove = $this->getTagsToRemove($configuration);

    $sanitizedContent = $this->htmlParser->sanitizeHtml(
      $htmlContent,
      $extractionMode,
      $contentSelector,
      $tagsToRemove
    );

    $content = $sanitizedContent['content'];

    // Populate rewritten_content field if configured.
    if (!empty($fieldMappings['rewritten_content'])) {
      $this->nodeBuilder->populateContentField(
        $node,
        $fieldMappings['rewritten_content'],
        $content
      );
    }
  }

  /**
   * Resolves the parent menu plugin ID.
   *
   * @param string $parentPageTitle
   *   The parent page title.
   * @param array $menuLinks
   *   Array of created menu links.
   *
   * @return string|null
   *   The parent menu plugin ID or NULL.
   */
  protected function resolveParentMenuPluginId(string $parentPageTitle, array $menuLinks): ?string {
    if (empty($parentPageTitle)) {
      return NULL;
    }

    if (isset($menuLinks[$parentPageTitle])) {
      return $this->menuLinkService->getPluginId($menuLinks[$parentPageTitle]);
    }

    return NULL;
  }

  /**
   * Calculates the weight for a menu link.
   *
   * @param string $parentPageTitle
   *   The parent page title (or empty for root).
   * @param array &$weightCounters
   *   Reference to weight counters array.
   *
   * @return int
   *   The calculated weight.
   */
  protected function calculateWeight(string $parentPageTitle, array &$weightCounters): int {
    $weightKey = empty($parentPageTitle) ? 'root' : $parentPageTitle;

    if (!isset($weightCounters[$weightKey])) {
      $weightCounters[$weightKey] = 0;
    }

    return $weightCounters[$weightKey]++;
  }

}
