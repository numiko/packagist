<?php

declare(strict_types=1);

namespace Drupal\content_migration\Import;

use Drupal\content_migration\AiMigrationPluginManager;
use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Service\ContentExtractionService;
use Drupal\content_migration\Service\HtmlParserService;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\content_migration\Service\RedirectService;
use Drupal\content_migration\Service\UrlContentFetcherService;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\node\NodeInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Import processor for URL-based content imports.
 *
 * Handles single URL imports, merged URL imports, and profile-based
 * extractions.
 */
class UrlImportProcessor extends ImportProcessorBase {

  /**
   * Constructs a UrlImportProcessor object.
   *
   * @param \Drupal\content_migration\Service\NodeBuilderService $nodeBuilder
   *   The node builder service.
   * @param \Drupal\content_migration\Service\MenuLinkService $menuLinkService
   *   The menu link service.
   * @param \Drupal\content_migration\Service\RedirectService $redirectService
   *   The redirect service.
   * @param \Drupal\content_migration\AiMigrationPluginManager $aiMigrationPluginManager
   *   The AI migration plugin manager.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   * @param \Drupal\content_migration\Service\UrlContentFetcherService $urlContentFetcher
   *   The URL content fetcher service.
   * @param \Drupal\content_migration\Service\ContentExtractionService $contentExtraction
   *   The content extraction service.
   * @param \Drupal\content_migration\Service\HtmlParserService $htmlParser
   *   The HTML parser service.
   */
  public function __construct(
    NodeBuilderService $nodeBuilder,
    MenuLinkService $menuLinkService,
    RedirectService $redirectService,
    AiMigrationPluginManager $aiMigrationPluginManager,
    MessengerInterface $messenger,
    #[Autowire(service: 'logger.channel.content_migration')]
    LoggerInterface $logger,
    protected readonly UrlContentFetcherService $urlContentFetcher,
    protected readonly ContentExtractionService $contentExtraction,
    protected readonly HtmlParserService $htmlParser,
  ) {
    parent::__construct(
      $nodeBuilder,
      $menuLinkService,
      $redirectService,
      $aiMigrationPluginManager,
      $messenger,
      $logger
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getId(): string {
    return 'url';
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return 'URL Import';
  }

  /**
   * {@inheritdoc}
   */
  public function validateData(array $data): array {
    $errors = [];

    if (empty($data['url']) && empty($data['urls'])) {
      $errors[] = 'URL is required.';
    }

    if (!empty($data['url']) && !filter_var($data['url'], FILTER_VALIDATE_URL)) {
      $errors[] = 'Invalid URL format.';
    }

    if (!empty($data['urls'])) {
      foreach ($data['urls'] as $url) {
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
          $errors[] = "Invalid URL format: $url";
        }
      }
    }

    return $errors;
  }

  /**
   * {@inheritdoc}
   */
  public function process(array $data, array $configuration): NodeInterface {
    // Handle merged URLs.
    if (!empty($data['urls']) && is_array($data['urls'])) {
      return $this->processMergedUrls($data['urls'], $configuration);
    }

    $url = $data['url'];
    $contentType = $configuration['content_type'];
    $extractionProfile = $this->getExtractionProfile($configuration);

    // Fetch HTML content from the URL.
    $htmlContent = $this->urlContentFetcher->fetchContent($url);

    // Check if we should use profile-based extraction.
    if (!empty($extractionProfile)) {
      return $this->processWithProfile(
        $url,
        $htmlContent,
        $configuration
      );
    }

    // Standard extraction.
    return $this->processStandard($url, $htmlContent, $configuration);
  }

  /**
   * Process URL with standard extraction.
   *
   * @param string $url
   *   The source URL.
   * @param string $htmlContent
   *   The fetched HTML content.
   * @param array $configuration
   *   The import configuration.
   *
   * @return \Drupal\node\NodeInterface
   *   The created node.
   */
  protected function processStandard(string $url, string $htmlContent, array $configuration): NodeInterface {
    $contentType = $configuration['content_type'];
    $extractionMode = $this->getExtractionMode($configuration);
    $contentSelector = $this->getContentSelector($configuration);
    $tagsToRemove = $this->getTagsToRemove($configuration);

    // Extract content.
    $content = $this->htmlParser->sanitizeHtml(
      $htmlContent,
      $extractionMode,
      $contentSelector,
      $tagsToRemove
    );

    // Create the node.
    $node = $this->nodeBuilder->createNode($contentType, $content['title']);

    // Set the body field.
    $fields = $configuration['fields'] ?? [];
    if (!empty($fields['body'])) {
      $this->nodeBuilder->setFieldValue($node, $fields['body'], $content['content']);
    }

    // Process AI plugins.
    $aiPlugins = $configuration['ai_plugins'] ?? [];
    $this->processAiPlugins($node, $content['content'], $aiPlugins);

    // Handle taxonomy terms.
    $this->handleTaxonomyTerms($node, $configuration);

    // Save the node.
    $node->save();

    // Handle menu link.
    $this->handleMenuLink($node, $configuration);

    // Handle redirect.
    $this->handleRedirect($url, $node, $configuration);

    // Check for truncation warnings and report them.
    $truncationWarnings = $this->nodeBuilder->getTruncationWarnings();
    if (!empty($truncationWarnings)) {
      foreach ($truncationWarnings as $warning) {
        $this->messenger->addWarning($this->t('Field "@field" content was truncated from @original to @max characters (exceeded by @truncated characters).', [
          '@field' => $warning['field'],
          '@original' => $warning['original_length'],
          '@max' => $warning['max_length'],
          '@truncated' => $warning['truncated_by'],
        ]));
      }
    }

    $this->messenger->addStatus($this->t('Content successfully imported from @url and saved to node @id.', [
      '@url' => $url,
      '@id' => $node->id(),
    ]));

    return $node;
  }

  /**
   * Process URL with profile-based extraction.
   *
   * @param string $url
   *   The source URL.
   * @param string $htmlContent
   *   The fetched HTML content.
   * @param array $configuration
   *   The import configuration.
   *
   * @return \Drupal\node\NodeInterface
   *   The created node.
   */
  protected function processWithProfile(string $url, string $htmlContent, array $configuration): NodeInterface {
    $contentType = $configuration['content_type'];
    $extractionProfile = $this->getExtractionProfile($configuration);

    // Extract content using the profile.
    $extractionResult = $this->contentExtraction->extractFromHtmlWithProfile(
      $htmlContent,
      $extractionProfile
    );

    // Create the node.
    $node = $this->nodeBuilder->createNode($contentType, $extractionResult['title']);

    // Populate fields from extraction result (each extraction has its own target_field).
    if (!empty($extractionResult['extractions'])) {
      $this->populateFromExtractionResult($node, $extractionResult, $contentType);
    }

    // Process AI plugins with combined content.
    $combinedContent = $this->combineExtractions($extractionResult['extractions']);
    $aiPlugins = $configuration['ai_plugins'] ?? [];
    $this->processAiPlugins($node, $combinedContent, $aiPlugins);

    // Handle taxonomy terms.
    $this->handleTaxonomyTerms($node, $configuration);

    // Save the node.
    $node->save();

    // Handle menu link.
    $this->handleMenuLink($node, $configuration);

    // Handle redirect.
    $this->handleRedirect($url, $node, $configuration);

    // Check for truncation warnings and report them.
    $truncationWarnings = $this->nodeBuilder->getTruncationWarnings();
    if (!empty($truncationWarnings)) {
      foreach ($truncationWarnings as $warning) {
        $this->messenger->addWarning($this->t('Field "@field" content was truncated from @original to @max characters (exceeded by @truncated characters).', [
          '@field' => $warning['field'],
          '@original' => $warning['original_length'],
          '@max' => $warning['max_length'],
          '@truncated' => $warning['truncated_by'],
        ]));
      }
    }

    $profile = $this->contentExtraction->getExtractionProfile($extractionProfile);
    $this->messenger->addStatus($this->t('Content successfully imported from @url using profile "@profile" and saved to node @id with @count extractions.', [
      '@url' => $url,
      '@profile' => $profile['label'],
      '@id' => $node->id(),
      '@count' => count($extractionResult['extractions']),
    ]));

    return $node;
  }

  /**
   * Process merged URLs into a single node.
   *
   * @param array $urls
   *   Array of URLs to merge.
   * @param array $configuration
   *   The import configuration.
   *
   * @return \Drupal\node\NodeInterface
   *   The created node.
   */
  protected function processMergedUrls(array $urls, array $configuration): NodeInterface {
    $contentType = $configuration['content_type'];
    $extractionMode = $this->getExtractionMode($configuration);
    $contentSelector = $this->getContentSelector($configuration);
    $tagsToRemove = $this->getTagsToRemove($configuration);
    $mergeOptions = $configuration['merge_options'] ?? [];

    $urlContents = [];
    $mergedTitle = $mergeOptions['merged_title'] ?? '';

    foreach ($urls as $url) {
      try {
        $htmlContent = $this->urlContentFetcher->fetchContent($url);
        $content = $this->htmlParser->sanitizeHtml(
          $htmlContent,
          $extractionMode,
          $contentSelector,
          $tagsToRemove
        );

        $urlContents[] = [
          'url' => $url,
          'title' => $content['title'],
          'content' => $content['content'],
        ];

        // Use first URL's title if no merged title provided.
        if (empty($mergedTitle)) {
          $mergedTitle = $content['title'];
        }
      }
      catch (\Exception $e) {
        $this->messenger->addWarning($this->t('Failed to fetch content from @url: @error', [
          '@url' => $url,
          '@error' => $e->getMessage(),
        ]));
      }
    }

    if (empty($urlContents)) {
      throw new \Exception('No content could be fetched from any of the provided URLs.');
    }

    // Merge content.
    $mergedContent = $this->mergeUrlContents($urlContents, $mergeOptions);

    // Create the node.
    $node = $this->nodeBuilder->createNode($contentType, $mergedTitle);

    // Set the body field.
    $fields = $configuration['fields'] ?? [];
    if (!empty($fields['body'])) {
      $this->nodeBuilder->setFieldValue($node, $fields['body'], $mergedContent);
    }

    // Process AI plugins.
    $aiPlugins = $configuration['ai_plugins'] ?? [];
    $this->processAiPlugins($node, $mergedContent, $aiPlugins);

    // Handle taxonomy terms.
    $this->handleTaxonomyTerms($node, $configuration);

    // Save the node.
    $node->save();

    // Handle menu link.
    $this->handleMenuLink($node, $configuration);

    // Create redirects for all URLs if requested.
    if (!empty($configuration['create_redirects'])) {
      foreach ($urls as $url) {
        $this->redirectService->createRedirect($url, $node);
      }
    }

    $this->messenger->addStatus($this->t('Content successfully merged from @count URLs and saved to node @id.', [
      '@count' => count($urls),
      '@id' => $node->id(),
    ]));

    return $node;
  }

  /**
   * Populates node fields from extraction result.
   *
   * Each extraction now has its own target_field, so we group by field
   * and populate accordingly.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to populate.
   * @param array $extractionResult
   *   The extraction result.
   * @param string $contentType
   *   The content type.
   */
  protected function populateFromExtractionResult(NodeInterface $node, array $extractionResult, string $contentType): void {
    $extractions = $extractionResult['extractions'];
    $contentHighlights = $this->contentExtraction->getContentHighlights();

    // Group extractions by target field.
    $groupedByField = [];
    foreach ($extractions as $extraction) {
      $targetField = $extraction['target_field'] ?? '';
      if (empty($targetField)) {
        continue;
      }
      if (!isset($groupedByField[$targetField])) {
        $groupedByField[$targetField] = [];
      }
      $groupedByField[$targetField][] = $extraction;
    }

    // Process each target field.
    foreach ($groupedByField as $targetField => $fieldExtractions) {
      $parsed = $this->nodeBuilder->parseCompositeKey($targetField);
      $fieldType = $parsed['type'];
      $fieldName = $parsed['name'];

      // Determine if this is a text field or paragraph reference field.
      // Include email, telephone, link and other simple field types.
      $isTextField = in_array($fieldType, [
        'text_with_summary',
        'text_long',
        'text',
        'string_long',
        'string',
        'email',
        'telephone',
        'link',
      ]);
      $isParagraphField = $fieldType === 'entity_reference_revisions';

      if ($isTextField) {
        // For text field targets, combine all extractions into one value.
        $combinedContent = $this->combineExtractionsForTextField($fieldExtractions);

        // Apply highlights.
        if (!empty($contentHighlights)) {
          $combinedContent = $this->htmlParser->applyHighlights($combinedContent, $contentHighlights);
        }

        // Set the text field value.
        $this->nodeBuilder->setFieldValue($node, $targetField, $combinedContent);
      }
      elseif ($isParagraphField) {
        // For paragraph reference fields, create paragraphs.
        $paragraphReferences = [];
        foreach ($fieldExtractions as $extraction) {
          $content = $extraction['content'];
          $paragraphType = $extraction['paragraph_type'] ?? '';

          // Apply highlights.
          if (!empty($contentHighlights)) {
            $content = $this->htmlParser->applyHighlights($content, $contentHighlights);
          }

          if (!empty($paragraphType)) {
            $paragraphRef = $this->nodeBuilder->createAndSaveParagraph(
              $paragraphType,
              $content
            );
            $paragraphReferences[] = $paragraphRef;
          }
        }

        if (!empty($paragraphReferences)) {
          $this->nodeBuilder->setParagraphReferences($node, $fieldName, $paragraphReferences);
        }
      }
    }
  }

  /**
   * Combines paragraph extractions into a single text value for text fields.
   *
   * @param array $extractions
   *   The paragraph extractions.
   *
   * @return string
   *   The combined HTML content.
   */
  protected function combineExtractionsForTextField(array $extractions): string {
    $combined = '';
    foreach ($extractions as $extraction) {
      $content = trim($extraction['content']);
      if (!empty($content)) {
        $combined .= $content . "\n\n";
      }
    }
    return trim($combined);
  }

  /**
   * Combines extraction content for AI processing.
   *
   * @param array $extractions
   *   The extractions array.
   *
   * @return string
   *   The combined content.
   */
  protected function combineExtractions(array $extractions): string {
    $combined = '';
    foreach ($extractions as $extraction) {
      $combined .= $extraction['content'] . "\n";
    }
    return $combined;
  }

  /**
   * Merges content from multiple URLs.
   *
   * @param array $urlContents
   *   Array of content from URLs.
   * @param array $mergeOptions
   *   Options for merging.
   *
   * @return string
   *   The merged content.
   */
  protected function mergeUrlContents(array $urlContents, array $mergeOptions): string {
    $separator = $mergeOptions['content_separator'] ?? 'headers';
    $includeSourceHeaders = $mergeOptions['include_source_headers'] ?? TRUE;

    $mergedParts = [];

    foreach ($urlContents as $index => $urlContent) {
      $contentPart = '';

      // Wrap each page's content in a section.
      $contentPart .= "<div class=\"merged-page-content\" data-source-url=\"{$urlContent['url']}\">\n";

      // Add source header if enabled.
      if ($includeSourceHeaders && $separator === 'headers') {
        $headerText = $urlContent['title'];
        $contentPart .= "<h2 class=\"source-page-title\">{$headerText}</h2>\n";
      }

      $contentPart .= $this->preservePageStructure($urlContent['content']);
      $contentPart .= "\n</div>";

      // Add separator between content sections.
      if ($index < count($urlContents) - 1) {
        switch ($separator) {
          case 'dividers':
            $contentPart .= "\n<hr class=\"page-separator\">\n";
            break;

          case 'headers':
          case 'none':
            $contentPart .= "\n\n";
            break;
        }
      }

      $mergedParts[] = $contentPart;
    }

    return implode('', $mergedParts);
  }

  /**
   * Preserves the structure of page content.
   *
   * @param string $content
   *   The raw content from a page.
   *
   * @return string
   *   The content with preserved structure.
   */
  protected function preservePageStructure(string $content): string {
    $content = trim($content);

    // If content doesn't start with a block-level element, wrap it.
    if (!preg_match('/^\s*<(h[1-6]|p|div|section|article|ul|ol|blockquote|table|figure|pre)/i', $content)) {
      $content = "<div class=\"page-content\">\n{$content}\n</div>";
    }

    // Ensure proper spacing.
    $content = preg_replace('/(<\/h[1-6]>)(\s*)(<h[1-6])/i', '$1' . "\n\n" . '$3', $content);
    $content = preg_replace('/(<\/p>)(\s*)(<p)/i', '$1' . "\n\n" . '$3', $content);
    $content = preg_replace('/(<\/ul>|<\/ol>)(\s*)(<h[1-6]|<p)/i', '$1' . "\n\n" . '$3', $content);
    $content = preg_replace('/(<\/h[1-6]>|<\/p>)(\s*)(<ul|<ol)/i', '$1' . "\n\n" . '$3', $content);
    $content = preg_replace('/(<\/blockquote>)(\s*)(<h[1-6]|<p)/i', '$1' . "\n\n" . '$3', $content);
    $content = preg_replace('/(<\/h[1-6]>|<\/p>)(\s*)(<blockquote)/i', '$1' . "\n\n" . '$3', $content);

    return $content;
  }

}
