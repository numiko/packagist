<?php

declare(strict_types=1);

namespace Drupal\content_migration\Import;

use Drupal\node\NodeInterface;

/**
 * Interface for import processors.
 *
 * Import processors handle the logic for importing content from different
 * sources (URLs, PDFs, CSVs, etc.) into Drupal nodes.
 */
interface ImportProcessorInterface {

  /**
   * Processes import data and creates a node.
   *
   * @param array $data
   *   The data to process. Structure varies by processor type:
   *   - UrlImportProcessor: ['url' => string, ...]
   *   - PdfImportProcessor: ['file' => FileInterface, ...]
   *   - CsvImportProcessor: ['row' => array, ...]
   *   - TitleImportProcessor: ['title' => string, ...]
   *
   * @param array $configuration
   *   Configuration options for the import. May include:
   *   - content_type: The content type to create.
   *   - fields: Field mappings.
   *   - ai_plugins: AI plugin configurations.
   *   - parent_menu_item: Parent menu item ID.
   *   - create_redirects: Whether to create redirects.
   *   - taxonomy_terms: Taxonomy terms to assign.
   *   - extraction_mode: Content extraction mode.
   *   - content_selector: CSS selector for extraction.
   *   - tags_to_remove: Tags to remove during extraction.
   *   - extraction_profile: Extraction profile ID.
   *
   * @return \Drupal\node\NodeInterface
   *   The created node entity.
   *
   * @throws \Drupal\content_migration\Exception\ContentFetchException
   *   If content cannot be fetched.
   * @throws \Drupal\content_migration\Exception\ContentParseException
   *   If content cannot be parsed.
   * @throws \Exception
   *   For other processing errors.
   */
  public function process(array $data, array $configuration): NodeInterface;

  /**
   * Gets the unique identifier for this processor.
   *
   * @return string
   *   The processor ID (e.g., 'url', 'pdf', 'csv', 'title').
   */
  public function getId(): string;

  /**
   * Gets a human-readable label for this processor.
   *
   * @return string
   *   The processor label.
   */
  public function getLabel(): string;

  /**
   * Validates the input data for this processor.
   *
   * @param array $data
   *   The data to validate.
   *
   * @return array
   *   An array of validation error messages. Empty if valid.
   */
  public function validateData(array $data): array;

  /**
   * Validates the configuration for this processor.
   *
   * @param array $configuration
   *   The configuration to validate.
   *
   * @return array
   *   An array of validation error messages. Empty if valid.
   */
  public function validateConfiguration(array $configuration): array;

}
