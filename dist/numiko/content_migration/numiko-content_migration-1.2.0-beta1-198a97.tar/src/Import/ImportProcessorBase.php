<?php

declare(strict_types=1);

namespace Drupal\content_migration\Import;

use Drupal\content_migration\AiMigrationPluginManager;
use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\content_migration\Service\RedirectService;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\node\NodeInterface;
use Psr\Log\LoggerInterface;

/**
 * Base class for import processors.
 *
 * Provides common functionality used by all import processors.
 */
abstract class ImportProcessorBase implements ImportProcessorInterface {

  use StringTranslationTrait;

  /**
   * Constructs an ImportProcessorBase object.
   *
   * @param \Drupal\content_migration\Service\NodeBuilderService $nodeBuilder
   *   The node builder service.
   * @param \Drupal\content_migration\Service\MenuLinkService $menuLinkService
   *   The menu link service.
   * @param \Drupal\content_migration\Service\RedirectService $redirectService
   *   The redirect service.
   * @param \Drupal\content_migration\AiMigrationPluginManager $aiMigrationPluginManager
   *   The AI migration plugin manager.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    protected readonly NodeBuilderService $nodeBuilder,
    protected readonly MenuLinkService $menuLinkService,
    protected readonly RedirectService $redirectService,
    protected readonly AiMigrationPluginManager $aiMigrationPluginManager,
    protected readonly MessengerInterface $messenger,
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function validateData(array $data): array {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfiguration(array $configuration): array {
    $errors = [];

    if (empty($configuration['content_type'])) {
      $errors[] = 'Content type is required.';
    }

    return $errors;
  }

  /**
   * Processes AI plugins on a node.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to process.
   * @param string $content
   *   The content to process with AI plugins.
   * @param array $aiPlugins
   *   The AI plugin configurations.
   */
  protected function processAiPlugins(NodeInterface $node, string $content, array $aiPlugins): void {
    foreach ($aiPlugins as $pluginId => $pluginConfig) {
      if (!empty($pluginConfig['enabled'])) {
        try {
          $pluginInstance = $this->aiMigrationPluginManager->createInstance($pluginId);
          $pluginInstance->processContent($content, $node, $pluginConfig);
        }
        catch (\Exception $e) {
          $this->messenger->addWarning($this->t('Failed to process content with @plugin: @error', [
            '@plugin' => $pluginId,
            '@error' => $e->getMessage(),
          ]));
          $this->logger->warning('AI plugin @plugin failed: @error', [
            '@plugin' => $pluginId,
            '@error' => $e->getMessage(),
          ]);
        }
      }
    }
  }

  /**
   * Creates a menu link for a node if parent is specified.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to create a menu link for.
   * @param array $configuration
   *   The configuration containing parent_menu_item.
   */
  protected function handleMenuLink(NodeInterface $node, array $configuration): void {
    if (!empty($configuration['parent_menu_item'])) {
      $this->menuLinkService->createMenuLink($node, $configuration['parent_menu_item']);
    }
  }

  /**
   * Creates a redirect if configured.
   *
   * @param string $sourceUrl
   *   The source URL to redirect from.
   * @param \Drupal\node\NodeInterface $node
   *   The node to redirect to.
   * @param array $configuration
   *   The configuration containing create_redirects flag.
   */
  protected function handleRedirect(string $sourceUrl, NodeInterface $node, array $configuration): void {
    if (!empty($configuration['create_redirects'])) {
      $this->redirectService->createRedirect($sourceUrl, $node);
    }
  }

  /**
   * Adds taxonomy terms to a node if provided.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to add terms to.
   * @param array $configuration
   *   The configuration containing taxonomy_terms.
   */
  protected function handleTaxonomyTerms(NodeInterface $node, array $configuration): void {
    if (!empty($configuration['taxonomy_terms'])) {
      $this->nodeBuilder->addTaxonomyTermsToNode($node, $configuration['taxonomy_terms']);
    }
  }

  /**
   * Gets a configuration value with a default.
   *
   * @param array $configuration
   *   The configuration array.
   * @param string $key
   *   The configuration key.
   * @param mixed $default
   *   The default value.
   *
   * @return mixed
   *   The configuration value or default.
   */
  protected function getConfigValue(array $configuration, string $key, mixed $default = NULL): mixed {
    return $configuration[$key] ?? $default;
  }

  /**
   * Gets the extraction mode from configuration.
   *
   * @param array $configuration
   *   The configuration array.
   *
   * @return string
   *   The extraction mode.
   */
  protected function getExtractionMode(array $configuration): string {
    return $this->getConfigValue(
      $configuration,
      'extraction_mode',
      ContentMigrationConstants::EXTRACTION_MODE_ARTICLE
    );
  }

  /**
   * Gets the extraction profile ID from configuration.
   *
   * @param array $configuration
   *   The configuration array.
   *
   * @return string
   *   The extraction profile ID or empty string.
   */
  protected function getExtractionProfile(array $configuration): string {
    return $this->getConfigValue($configuration, 'extraction_profile', '');
  }

  /**
   * Gets the content selector from configuration.
   *
   * @param array $configuration
   *   The configuration array.
   *
   * @return string|null
   *   The content selector or NULL.
   */
  protected function getContentSelector(array $configuration): ?string {
    return $this->getConfigValue($configuration, 'content_selector');
  }

  /**
   * Gets tags to remove from configuration.
   *
   * @param array $configuration
   *   The configuration array.
   *
   * @return array|null
   *   Array of tags to remove or NULL.
   */
  protected function getTagsToRemove(array $configuration): ?array {
    return $this->getConfigValue($configuration, 'tags_to_remove');
  }

}
