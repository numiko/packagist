<?php

declare(strict_types=1);

namespace Drupal\content_migration\Import;

use Drupal\content_migration\AiMigrationPluginManager;
use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Exception\ApiConfigurationException;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\content_migration\Service\RedirectService;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\file\FileInterface;
use Drupal\node\NodeInterface;
use GuzzleHttp\ClientInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Import processor for PDF-based content imports.
 *
 * Uses Claude API to extract content from PDF files.
 */
class PdfImportProcessor extends ImportProcessorBase {

  /**
   * Constructs a PdfImportProcessor object.
   *
   * @param \Drupal\content_migration\Service\NodeBuilderService $nodeBuilder
   *   The node builder service.
   * @param \Drupal\content_migration\Service\MenuLinkService $menuLinkService
   *   The menu link service.
   * @param \Drupal\content_migration\Service\RedirectService $redirectService
   *   The redirect service.
   * @param \Drupal\content_migration\AiMigrationPluginManager $aiMigrationPluginManager
   *   The AI migration plugin manager.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   * @param \GuzzleHttp\ClientInterface $httpClient
   *   The HTTP client.
   * @param \Drupal\Core\File\FileSystemInterface $fileSystem
   *   The file system service.
   */
  public function __construct(
    NodeBuilderService $nodeBuilder,
    MenuLinkService $menuLinkService,
    RedirectService $redirectService,
    AiMigrationPluginManager $aiMigrationPluginManager,
    MessengerInterface $messenger,
    #[Autowire(service: 'logger.channel.content_migration')]
    LoggerInterface $logger,
    protected readonly ConfigFactoryInterface $configFactory,
    protected readonly ClientInterface $httpClient,
    protected readonly FileSystemInterface $fileSystem,
  ) {
    parent::__construct(
      $nodeBuilder,
      $menuLinkService,
      $redirectService,
      $aiMigrationPluginManager,
      $messenger,
      $logger
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getId(): string {
    return 'pdf';
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return 'PDF Import';
  }

  /**
   * {@inheritdoc}
   */
  public function validateData(array $data): array {
    $errors = [];

    if (empty($data['file'])) {
      $errors[] = 'PDF file is required.';
    }
    elseif (!($data['file'] instanceof FileInterface)) {
      $errors[] = 'Invalid file object provided.';
    }

    return $errors;
  }

  /**
   * {@inheritdoc}
   */
  public function process(array $data, array $configuration): NodeInterface {
    /** @var \Drupal\file\FileInterface $pdfFile */
    $pdfFile = $data['file'];
    $contentType = $configuration['content_type'];

    // Extract content from PDF using Claude API.
    $extractedContent = $this->extractPdfContent($pdfFile);

    // Use the filename (without extension) as default title.
    $defaultTitle = pathinfo($pdfFile->getFilename(), PATHINFO_FILENAME);
    $title = $extractedContent['title'] ?: $defaultTitle;

    // Create the node.
    $node = $this->nodeBuilder->createNode($contentType, $title);

    // Set the body field.
    $fields = $configuration['fields'] ?? [];
    if (!empty($fields['body'])) {
      $this->nodeBuilder->setFieldValue($node, $fields['body'], $extractedContent['content']);
    }

    // Process AI plugins.
    $aiPlugins = $configuration['ai_plugins'] ?? [];
    $this->processAiPlugins($node, $extractedContent['content'], $aiPlugins);

    // Handle taxonomy terms.
    $this->handleTaxonomyTerms($node, $configuration);

    // Save the node.
    $node->save();

    // Handle menu link.
    $this->handleMenuLink($node, $configuration);

    $this->messenger->addStatus($this->t('Content successfully extracted from PDF "@filename" and saved to node @id.', [
      '@filename' => $pdfFile->getFilename(),
      '@id' => $node->id(),
    ]));

    return $node;
  }

  /**
   * Extracts content from a PDF file using Claude API.
   *
   * @param \Drupal\file\FileInterface $pdfFile
   *   The PDF file to process.
   *
   * @return array
   *   An array with 'title' and 'content' keys.
   *
   * @throws \Drupal\content_migration\Exception\ApiConfigurationException
   *   If the API is not configured.
   * @throws \Exception
   *   If the PDF processing fails.
   */
  protected function extractPdfContent(FileInterface $pdfFile): array {
    $config = $this->configFactory->get(ContentMigrationConstants::CONFIG_KEY);
    $apiKey = $config->get('claude_api_key');
    $model = $config->get('claude_api_model') ?: 'claude-3-5-sonnet-20241022';
    $timeout = $config->get('api_timeout') ?: ContentMigrationConstants::DEFAULT_API_TIMEOUT;

    if (empty($apiKey)) {
      throw ApiConfigurationException::missingApiKey();
    }

    // Get the file path and encode as base64.
    $fileUri = $pdfFile->getFileUri();
    $filePath = $this->fileSystem->realpath($fileUri);

    if (!file_exists($filePath)) {
      throw new \Exception('PDF file not found on filesystem.');
    }

    $fileData = file_get_contents($filePath);
    if ($fileData === FALSE) {
      throw new \Exception('Unable to read PDF file.');
    }

    $base64Pdf = base64_encode($fileData);

    $this->logger->info('Attempting PDF extraction for file: @filename', [
      '@filename' => $pdfFile->getFilename(),
    ]);

    try {
      $requestPayload = [
        'model' => $model,
        'max_tokens' => 8192,
        'messages' => [
          [
            'role' => 'user',
            'content' => [
              [
                'type' => 'document',
                'source' => [
                  'type' => 'base64',
                  'media_type' => 'application/pdf',
                  'data' => $base64Pdf,
                ],
              ],
              [
                'type' => 'text',
                'text' => 'Extract the text content from this PDF document and provide the response in valid JSON format with two fields: "title" (a suitable title for the document) and "content" (the complete text formatted as clean HTML). Use semantic HTML elements like h2, h3, p, ul, ol, etc. to preserve the document structure.',
              ],
            ],
          ],
        ],
      ];

      $response = $this->httpClient->request('POST', 'https://api.anthropic.com/v1/messages', [
        'headers' => [
          'x-api-key' => $apiKey,
          'anthropic-version' => '2023-06-01',
          'Content-Type' => 'application/json',
        ],
        'json' => $requestPayload,
        'timeout' => $timeout,
      ]);

      $responseBody = (string) $response->getBody();

      $this->logger->info('Claude API raw response: @response', [
        '@response' => substr($responseBody, 0, 1000) . '...',
      ]);

      $result = json_decode($responseBody, TRUE);

      if (json_last_error() !== JSON_ERROR_NONE) {
        throw new \Exception('Unable to parse Claude API response JSON: ' . json_last_error_msg());
      }

      if (empty($result['content']) || empty($result['content'][0]['text'])) {
        $this->logger->error('Invalid Claude API response structure: @response', [
          '@response' => $responseBody,
        ]);
        throw new \Exception('Invalid response format from Claude API.');
      }

      $claudeResponse = $result['content'][0]['text'];

      // Try to extract JSON from Claude's response.
      $jsonPattern = '/\{[\s\S]*\}/';
      if (preg_match($jsonPattern, $claudeResponse, $matches)) {
        $jsonString = $matches[0];
      }
      else {
        $jsonString = $claudeResponse;
      }

      // Parse the JSON response from Claude.
      $extractedData = json_decode($jsonString, TRUE);
      if (json_last_error() !== JSON_ERROR_NONE) {
        // If JSON parsing fails, create a fallback structure.
        $this->logger->warning('JSON parsing failed, creating fallback response.');

        $defaultTitle = pathinfo($pdfFile->getFilename(), PATHINFO_FILENAME);
        return [
          'title' => $defaultTitle,
          'content' => '<div class="pdf-extracted-content">' . nl2br(htmlspecialchars($claudeResponse)) . '</div>',
        ];
      }

      if (!isset($extractedData['title']) || !isset($extractedData['content'])) {
        $this->logger->warning('Claude response missing required fields.');

        $defaultTitle = pathinfo($pdfFile->getFilename(), PATHINFO_FILENAME);
        return [
          'title' => $extractedData['title'] ?? $defaultTitle,
          'content' => $extractedData['content'] ?? '<div class="pdf-extracted-content">' . nl2br(htmlspecialchars($claudeResponse)) . '</div>',
        ];
      }

      return [
        'title' => $extractedData['title'],
        'content' => $extractedData['content'],
      ];
    }
    catch (\GuzzleHttp\Exception\RequestException $e) {
      $this->logger->error('HTTP error calling Claude API for PDF extraction: @error', [
        '@error' => $e->getMessage(),
      ]);
      throw new \Exception("Failed to extract content from PDF using Claude API: " . $e->getMessage());
    }
  }

}
