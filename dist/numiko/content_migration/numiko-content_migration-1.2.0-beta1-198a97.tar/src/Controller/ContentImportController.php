<?php

declare(strict_types=1);

namespace Drupal\content_migration\Controller;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Import\CsvImportProcessor;
use Drupal\content_migration\Import\PdfImportProcessor;
use Drupal\content_migration\Import\TitleImportProcessor;
use Drupal\content_migration\Import\UrlImportProcessor;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\file\FileInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Controller for handling URL content import operations.
 *
 * This controller delegates to specialized import processors for actual
 * import logic. It serves as a thin coordination layer.
 */
class ContentImportController extends ControllerBase implements ContainerInjectionInterface {

  /**
   * Constructs a ContentImportController object.
   *
   * @param \Drupal\content_migration\Import\UrlImportProcessor $urlProcessor
   *   The URL import processor.
   * @param \Drupal\content_migration\Import\TitleImportProcessor $titleProcessor
   *   The title import processor.
   * @param \Drupal\content_migration\Import\PdfImportProcessor $pdfProcessor
   *   The PDF import processor.
   * @param \Drupal\content_migration\Import\CsvImportProcessor $csvProcessor
   *   The CSV import processor.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   */
  public function __construct(
    protected readonly UrlImportProcessor $urlProcessor,
    protected readonly TitleImportProcessor $titleProcessor,
    protected readonly PdfImportProcessor $pdfProcessor,
    protected readonly CsvImportProcessor $csvProcessor,
    protected readonly MessengerInterface $messenger,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get(UrlImportProcessor::class),
      $container->get(TitleImportProcessor::class),
      $container->get(PdfImportProcessor::class),
      $container->get(CsvImportProcessor::class),
      $container->get('messenger'),
    );
  }

  /**
   * Process content from a URL and save to a node.
   *
   * @param string $url
   *   The URL to import content from.
   * @param string $content_type
   *   The content type to create or update.
   * @param array $fields
   *   The fields to save the content to.
   * @param array $ai_plugins
   *   The AI plugin configurations to apply.
   * @param string|null $parent_menu_item
   *   The parent menu item ID to add the new node under.
   * @param bool $create_redirects
   *   Whether to create URL redirects.
   * @param array $taxonomy_terms
   *   The taxonomy terms to assign.
   * @param string $extraction_mode
   *   The content extraction mode ('article' or 'full_page').
   * @param string|null $content_selector
   *   Optional CSS selector for content extraction in full_page mode.
   * @param array|null $tags_to_remove
   *   Optional array of HTML tags to remove during extraction.
   * @param string $extraction_profile
   *   Optional extraction profile ID.
   *
   * @return array
   *   A render array showing the results.
   */
  public function processUrl(
    string $url,
    string $content_type,
    array $fields,
    array $ai_plugins,
    ?string $parent_menu_item = NULL,
    bool $create_redirects = FALSE,
    array $taxonomy_terms = [],
    string $extraction_mode = ContentMigrationConstants::EXTRACTION_MODE_ARTICLE,
    ?string $content_selector = NULL,
    ?array $tags_to_remove = NULL,
    string $extraction_profile = '',
  ): array {
    try {
      $configuration = $this->buildConfiguration(
        $content_type,
        $fields,
        $ai_plugins,
        $parent_menu_item,
        $create_redirects,
        $taxonomy_terms,
        $extraction_mode,
        $content_selector,
        $tags_to_remove,
        $extraction_profile
      );

      $this->urlProcessor->process(['url' => $url], $configuration);

      return ['#markup' => $this->t('Content imported successfully.')];
    }
    catch (\Exception $e) {
      $this->messenger->addError($this->t('Error importing content: @error', [
        '@error' => $e->getMessage(),
      ]));
      return ['#markup' => $this->t('Import failed. See the error message for details.')];
    }
  }

  /**
   * Process content from multiple URLs and merge them into a single node.
   *
   * @param array $urls
   *   Array of URLs to import content from.
   * @param string $content_type
   *   The content type to create.
   * @param array $fields
   *   The fields to save the content to.
   * @param array $ai_plugins
   *   The AI plugin configurations to apply.
   * @param string|null $parent_menu_item
   *   The parent menu item ID to add the new node under.
   * @param bool $create_redirects
   *   Whether to create URL redirects.
   * @param array $merge_options
   *   Options for merging content.
   * @param array $taxonomy_terms
   *   The taxonomy terms to assign.
   * @param string $extraction_mode
   *   The content extraction mode ('article' or 'full_page').
   * @param string|null $content_selector
   *   Optional CSS selector for content extraction.
   * @param array|null $tags_to_remove
   *   Optional array of HTML tags to remove.
   * @param string $extraction_profile
   *   Optional extraction profile ID.
   *
   * @return array
   *   A render array showing the results.
   */
  public function processMergedUrls(
    array $urls,
    string $content_type,
    array $fields,
    array $ai_plugins,
    ?string $parent_menu_item = NULL,
    bool $create_redirects = FALSE,
    array $merge_options = [],
    array $taxonomy_terms = [],
    string $extraction_mode = ContentMigrationConstants::EXTRACTION_MODE_ARTICLE,
    ?string $content_selector = NULL,
    ?array $tags_to_remove = NULL,
    string $extraction_profile = '',
  ): array {
    try {
      $configuration = $this->buildConfiguration(
        $content_type,
        $fields,
        $ai_plugins,
        $parent_menu_item,
        $create_redirects,
        $taxonomy_terms,
        $extraction_mode,
        $content_selector,
        $tags_to_remove,
        $extraction_profile
      );
      $configuration['merge_options'] = $merge_options;

      $this->urlProcessor->process(['urls' => $urls], $configuration);

      return ['#markup' => $this->t('Merged content imported successfully.')];
    }
    catch (\Exception $e) {
      $this->messenger->addError($this->t('Error importing merged content: @error', [
        '@error' => $e->getMessage(),
      ]));
      return ['#markup' => $this->t('Import failed. See the error message for details.')];
    }
  }

  /**
   * Process a title and create an empty page.
   *
   * @param string $title
   *   The page title.
   * @param string $content_type
   *   The content type to create.
   * @param array $fields
   *   Field mappings.
   * @param array $ai_plugins
   *   AI plugin configurations (unused for title imports).
   * @param string|null $parent_menu_item
   *   Parent menu item ID.
   * @param array $taxonomy_terms
   *   Taxonomy terms to attach.
   *
   * @return array
   *   A render array showing the results.
   */
  public function processTitle(
    string $title,
    string $content_type,
    array $fields,
    array $ai_plugins,
    ?string $parent_menu_item = NULL,
    array $taxonomy_terms = [],
  ): array {
    try {
      $configuration = $this->buildConfiguration(
        $content_type,
        $fields,
        $ai_plugins,
        $parent_menu_item,
        FALSE,
        $taxonomy_terms
      );

      $this->titleProcessor->process(['title' => $title], $configuration);

      return ['#markup' => $this->t('Page created successfully.')];
    }
    catch (\Exception $e) {
      $this->messenger->addError($this->t('Error creating page "@title": @error', [
        '@title' => $title,
        '@error' => $e->getMessage(),
      ]));
      return ['#markup' => $this->t('Page creation failed. See the error message for details.')];
    }
  }

  /**
   * Process content from a PDF file and save to a node.
   *
   * @param \Drupal\file\FileInterface $pdf_file
   *   The PDF file to extract content from.
   * @param string $content_type
   *   The content type to create.
   * @param array $fields
   *   The fields to save the content to.
   * @param array $ai_plugins
   *   The AI plugin configurations to apply.
   * @param string|null $parent_menu_item
   *   The parent menu item ID to add the new node under.
   * @param array $taxonomy_terms
   *   Taxonomy terms to attach.
   *
   * @return array
   *   A render array showing the results.
   */
  public function processPdf(
    FileInterface $pdf_file,
    string $content_type,
    array $fields,
    array $ai_plugins,
    ?string $parent_menu_item = NULL,
    array $taxonomy_terms = [],
  ): array {
    try {
      $configuration = $this->buildConfiguration(
        $content_type,
        $fields,
        $ai_plugins,
        $parent_menu_item,
        FALSE,
        $taxonomy_terms
      );

      $this->pdfProcessor->process(['file' => $pdf_file], $configuration);

      return ['#markup' => $this->t('PDF content extracted successfully.')];
    }
    catch (\Exception $e) {
      $this->messenger->addError($this->t('Error extracting content from PDF: @error', [
        '@error' => $e->getMessage(),
      ]));
      return ['#markup' => $this->t('PDF extraction failed. See the error message for details.')];
    }
  }

  /**
   * Process CSV data to create hierarchical pages with menu structure.
   *
   * @param array $csv_data
   *   The parsed CSV data with page_title, content_type, parent_page_title.
   * @param string|null $parent_menu_item
   *   The parent menu item ID for the root of the hierarchy.
   * @param array $taxonomy_terms
   *   The taxonomy terms to apply to pages.
   * @param array $field_mappings
   *   Field mappings for all content types.
   * @param bool $create_redirects
   *   Whether to create URL redirects for pages with source URLs.
   * @param string $extraction_mode
   *   The content extraction mode ('article' or 'full_page').
   * @param string|null $content_selector
   *   Optional CSS selector for content extraction.
   * @param array|null $tags_to_remove
   *   Optional array of HTML tags to remove.
   * @param string $extraction_profile
   *   Optional extraction profile ID.
   */
  public function processCsv(
    array $csv_data,
    ?string $parent_menu_item,
    array $taxonomy_terms = [],
    array $field_mappings = [],
    bool $create_redirects = FALSE,
    string $extraction_mode = ContentMigrationConstants::EXTRACTION_MODE_ARTICLE,
    ?string $content_selector = NULL,
    ?array $tags_to_remove = NULL,
    string $extraction_profile = '',
  ): void {
    $configuration = [
      'parent_menu_item' => $parent_menu_item,
      'taxonomy_terms' => $taxonomy_terms,
      'field_mappings' => $field_mappings,
      'create_redirects' => $create_redirects,
      'extraction_mode' => $extraction_mode,
      'content_selector' => $content_selector,
      'tags_to_remove' => $tags_to_remove,
      'extraction_profile' => $extraction_profile,
    ];

    $this->csvProcessor->processAll($csv_data, $configuration);
  }

  /**
   * Builds a configuration array from parameters.
   *
   * @param string $content_type
   *   The content type.
   * @param array $fields
   *   The field mappings.
   * @param array $ai_plugins
   *   The AI plugin configurations.
   * @param string|null $parent_menu_item
   *   The parent menu item ID.
   * @param bool $create_redirects
   *   Whether to create redirects.
   * @param array $taxonomy_terms
   *   The taxonomy terms.
   * @param string $extraction_mode
   *   The extraction mode.
   * @param string|null $content_selector
   *   The content selector.
   * @param array|null $tags_to_remove
   *   Tags to remove.
   * @param string $extraction_profile
   *   The extraction profile ID.
   *
   * @return array
   *   The configuration array.
   */
  protected function buildConfiguration(
    string $content_type,
    array $fields = [],
    array $ai_plugins = [],
    ?string $parent_menu_item = NULL,
    bool $create_redirects = FALSE,
    array $taxonomy_terms = [],
    string $extraction_mode = ContentMigrationConstants::EXTRACTION_MODE_ARTICLE,
    ?string $content_selector = NULL,
    ?array $tags_to_remove = NULL,
    string $extraction_profile = '',
  ): array {
    return [
      'content_type' => $content_type,
      'fields' => $fields,
      'ai_plugins' => $ai_plugins,
      'parent_menu_item' => $parent_menu_item,
      'create_redirects' => $create_redirects,
      'taxonomy_terms' => $taxonomy_terms,
      'extraction_mode' => $extraction_mode,
      'content_selector' => $content_selector,
      'tags_to_remove' => $tags_to_remove,
      'extraction_profile' => $extraction_profile,
    ];
  }

}
