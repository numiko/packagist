<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

use Drupal\Component\Plugin\PluginBase;
use Drupal\content_migration\AiMigrationInterface;
use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Exception\AiProcessingException;
use Drupal\content_migration\Exception\ApiConfigurationException;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\field\Entity\FieldConfig;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Base class for AI migration plugins.
 */
abstract class AiMigrationPluginBase extends PluginBase implements AiMigrationInterface, ContainerFactoryPluginInterface {
  use StringTranslationTrait;

  /**
   * Constructs a new AiMigrationPluginBase object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \GuzzleHttp\ClientInterface $httpClient
   *   The HTTP client.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entityFieldManager
   *   The entity field manager.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    protected ClientInterface $httpClient,
    protected ConfigFactoryInterface $configFactory,
    protected EntityFieldManagerInterface $entityFieldManager,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected LoggerInterface $logger,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get(ClientInterface::class),
      $container->get(ConfigFactoryInterface::class),
      $container->get(EntityFieldManagerInterface::class),
      $container->get(EntityTypeManagerInterface::class),
      $container->get('logger.channel.content_migration'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return (string) $this->pluginDefinition['label'];
  }

  /**
   * {@inheritdoc}
   */
  public function getDescription(): string {
    return (string) $this->pluginDefinition['description'];
  }

  /**
   * Makes a request to the Claude API.
   *
   * @param string $prompt
   *   The prompt to send to Claude.
   * @param int $max_tokens
   *   The maximum number of tokens to generate.
   *
   * @return string
   *   The response content from Claude.
   *
   * @throws \Drupal\content_migration\Exception\ApiConfigurationException
   *   Throws an exception if the API is not configured.
   * @throws \Exception
   *   Throws an exception if the API call fails.
   */
  protected function makeClaudeRequest(string $prompt, int $max_tokens = 4096): string {
    $config = $this->configFactory->get(ContentMigrationConstants::CONFIG_KEY);
    $api_key = $config->get('claude_api_key');
    $model = $config->get('claude_api_model') ?: 'claude-3-haiku-20240307';

    if (empty($api_key)) {
      throw ApiConfigurationException::missingApiKey();
    }

    try {
      $response = $this->httpClient->request('POST', 'https://api.anthropic.com/v1/messages', [
        'headers' => [
          'x-api-key' => $api_key,
          'anthropic-version' => '2023-06-01',
          'Content-Type' => 'application/json',
        ],
        'json' => [
          'model' => $model,
          'max_tokens' => $max_tokens,
          'messages' => [
            [
              'role' => 'user',
              'content' => $prompt,
            ],
          ],
        ],
        'timeout' => $config->get('api_timeout') ?: ContentMigrationConstants::DEFAULT_API_TIMEOUT,
      ]);

      $responseBody = (string) $response->getBody();

      $result = json_decode($responseBody, TRUE);

      if (empty($result['content']) || empty($result['content'][0]['text'])) {
        throw AiProcessingException::invalidResponseFormat();
      }

      return $result['content'][0]['text'];
    }
    catch (RequestException $e) {
      $this->logger->error(
        'Error calling Claude API: @error',
        ['@error' => (string) $e->getMessage()]
      );
      throw AiProcessingException::apiCallFailed($e->getMessage());
    }
  }

  /**
   * Get text field options with type information using composite keys.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field options with composite keys in format 'type:field_name'
   *   [
   *     'text_with_summary:field_body' => 'Body (Text with Summary)',
   *     'entity_reference_revisions:field_content' => 'Content (Paragraphs)',
   *     'text_long:field_description' => 'Description (Long Text)'
   *   ]
   */
  protected function getTextFieldOptionsWithType(string $content_type): array {
    $field_options = [];
    $fields = $this->entityFieldManager->getFieldDefinitions('node', $content_type);

    foreach ($fields as $field_name => $field_definition) {
      if ($field_definition instanceof FieldConfig) {
        $field_type = $field_definition->getType();

        if (in_array($field_type, ['text_with_summary', 'text_long', 'text', 'entity_reference_revisions'])) {
          // Create composite key: type:field_name.
          $composite_key = $field_type . ContentMigrationConstants::COMPOSITE_KEY_DELIMITER . $field_name;

          // Create human-readable label with type.
          $type_label = $this->getFieldTypeLabel($field_type);
          $field_label = $field_definition->getLabel() . ' (' . $type_label . ')';

          $field_options[$composite_key] = $field_label;
        }
      }
    }

    return $field_options;
  }

  /**
   * Get text field options (legacy method for backward compatibility).
   *
   * @deprecated Use getTextFieldOptionsWithType() instead.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field labels keyed by field names.
   */
  protected function getTextFieldOptions(string $content_type): array {
    $field_options_with_type = $this->getTextFieldOptionsWithType($content_type);

    // Convert composite keys back to simple field names for backward
    // compatibility.
    $legacy_options = [];
    foreach ($field_options_with_type as $composite_key => $label) {
      $field_info = $this->parseCompositeKey($composite_key);
      // Remove the type suffix from the label.
      $clean_label = preg_replace('/\s*\([^)]+\)\s*$/', '', $label);
      $legacy_options[$field_info['field_name']] = $clean_label;
    }

    return $legacy_options;
  }

  /**
   * Gets a human-readable label for field types.
   *
   * @param string $field_type
   *   The field type machine name.
   *
   * @return string
   *   The human-readable label.
   */
  protected function getFieldTypeLabel(string $field_type): string {
    $labels = [
      'text' => 'Short Text',
      'text_long' => 'Long Text',
      'text_with_summary' => 'Text with Summary',
      'entity_reference_revisions' => 'Paragraphs',
    ];

    return $labels[$field_type] ?? $field_type;
  }

  /**
   * Parses a composite key to extract field type and name.
   *
   * @param string $composite_key
   *   The composite key in format 'type:field_name'.
   *
   * @return array
   *   Array with 'type' and 'field_name' keys.
   *
   * @throws \InvalidArgumentException
   *   If the composite key format is invalid.
   */
  protected function parseCompositeKey(string $composite_key): array {
    $parts = explode(ContentMigrationConstants::COMPOSITE_KEY_DELIMITER, $composite_key, 2);

    if (count($parts) !== 2) {
      throw new \InvalidArgumentException("Invalid composite key format: {$composite_key}");
    }

    return [
      'type' => $parts[0],
      'field_name' => $parts[1],
    ];
  }

  /**
   * Checks if a composite key represents a paragraph field.
   *
   * @param string $composite_key
   *   The composite key to check.
   *
   * @return bool
   *   TRUE if it's a paragraph field.
   */
  protected function isParagraphFieldKey(string $composite_key): bool {
    $parsed = $this->parseCompositeKey($composite_key);
    return $parsed['type'] === 'entity_reference_revisions';
  }

  /**
   * Checks if a composite key represents a text field.
   *
   * @param string $composite_key
   *   The composite key to check.
   *
   * @return bool
   *   TRUE if it's a text field.
   */
  protected function isTextFieldKey(string $composite_key): bool {
    $parsed = $this->parseCompositeKey($composite_key);
    return in_array($parsed['type'], ['text', 'text_long', 'text_with_summary']);
  }

  /**
   * Validates configuration form for composite key fields.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param string $field_key
   *   The form field key to validate.
   * @param array $allowed_types
   *   Array of allowed field types.
   */
  protected function validateCompositeKeyField(FormStateInterface $form_state, string $field_key, array $allowed_types = []): void {
    $field_value = $form_state->getValue($field_key);
    if ($field_value) {
      try {
        $field_info = $this->parseCompositeKey($field_value);

        if (!empty($allowed_types) && !in_array($field_info['type'], $allowed_types)) {
          $form_state->setError(
            $form_state->getCompleteForm()[$field_key],
            $this->t('Field must be one of: @types', ['@types' => implode(', ', $allowed_types)])
          );
        }
      }
      catch (\InvalidArgumentException $e) {
        $form_state->setError(
          $form_state->getCompleteForm()[$field_key],
          $this->t('Invalid field selection format.')
        );
      }
    }
  }

  /**
   * {@inheritDoc}
   */
  public function hasBeenCancelled(?string $content_type): bool {
    return FALSE;
  }

}
