<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

use Drupal\content_migration\Plugin\AiMigration\AiMigrationPluginBase;

/**
 * Base for generating taxonomy classes.
 */
abstract class TaxonomyBase extends AiMigrationPluginBase {

  /**
   * Generates taxonomy term suggestions using AI.
   *
   * @param string $content
   *   The content to analyze.
   * @param string $vocabulary_id
   *   The vocabulary ID.
   * @param int $max_suggestions
   *   Maximum number of suggestions.
   * @param string $style
   *   The suggestion style.
   *
   * @return array
   *   Array of suggested terms.
   */
  protected function generateTaxonomySuggestions(string $content, string $vocabulary_id, int $max_suggestions, string $style): array {
    // Get existing terms in the vocabulary for context.
    $existing_terms = $this->getExistingTerms($vocabulary_id);
    $existing_terms_text = empty($existing_terms) ? 'No existing terms.' : implode(', ', $existing_terms);

    $prompt = $this->buildTaxonomyPrompt($content, $vocabulary_id, $max_suggestions, $style, $existing_terms_text);

    // Make the API call.
    $response = $this->makeClaudeRequest($prompt);

    // Parse the response to extract term suggestions.
    return $this->parseSuggestions($response);
  }

  /**
   * Builds the prompt for taxonomy suggestions.
   *
   * @param string $content
   *   The content to analyze.
   * @param string $vocabulary_id
   *   The vocabulary ID.
   * @param int $max_suggestions
   *   Maximum number of suggestions.
   * @param string $style
   *   The suggestion style.
   * @param string $existing_terms
   *   Existing terms in the vocabulary.
   *
   * @return string
   *   The complete prompt for Claude API.
   */
  protected function buildTaxonomyPrompt(string $content, string $vocabulary_id, int $max_suggestions, string $style, string $existing_terms): string {
    $style_instructions = $this->getStyleInstructions($style);

    return <<<EOT
Analyze the following content and suggest appropriate taxonomy terms for the "{$vocabulary_id}" vocabulary.

Style: {$style_instructions}

Existing terms in this vocabulary: {$existing_terms}

Content to analyze:
{$content}

Requirements:
- Suggest up to {$max_suggestions} relevant terms
- Terms should be {$style_instructions}
- Use UK English spelling
- Consider existing terms but you can suggest new ones
- Return only the term names, one per line
- No explanations or additional text

Example format:
Term 1
Term 2
Term 3
EOT;
  }

  /**
   * Gets style-specific instructions for taxonomy suggestions.
   *
   * @param string $style
   *   The suggestion style.
   *
   * @return string
   *   The style-specific instructions.
   */
  protected function getStyleInstructions(string $style): string {
    switch ($style) {
      case 'keywords':
        return 'specific keywords or short phrases (1-3 words) that describe key concepts';

      case 'topics':
        return 'broader topic areas or subject categories that encompass the main themes';

      case 'categories':
        return 'hierarchical categories that classify the content type or domain';

      case 'tags':
        return 'descriptive tags that help users find and filter content';

      default:
        return 'relevant terms that accurately describe the content';
    }
  }

  /**
   * Gets existing terms in a vocabulary.
   *
   * @param string $vocabulary_id
   *   The vocabulary ID.
   *
   * @return array
   *   Array of existing term names.
   */
  protected function getExistingTerms(string $vocabulary_id): array {
    $term_storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $terms = $term_storage->loadByProperties(['vid' => $vocabulary_id]);

    $term_names = [];
    foreach ($terms as $term) {
      $term_names[] = $term->label();
    }

    // Limit to 50 existing terms for context.
    return array_slice($term_names, 0, 50);
  }

  /**
   * Parses suggestions from the AI response.
   *
   * @param string $response
   *   The AI response.
   *
   * @return array
   *   Array of suggested terms.
   */
  protected function parseSuggestions(string $response): array {
    $lines = explode("\n", trim($response));
    $suggestions = [];

    foreach ($lines as $line) {
      $term = trim($line, '- ');
      $term = trim($term);

      if (!empty($term) && strlen($term) <= 255) {
        $suggestions[] = $term;
      }
    }

    return array_unique($suggestions);
  }

  /**
   * Processes suggestions and creates/finds taxonomy terms.
   *
   * @param array $suggestions
   *   Array of suggested term names.
   * @param string $vocabulary_id
   *   The vocabulary ID.
   * @param bool $auto_create
   *   Whether to auto-create new terms.
   *
   * @return array
   *   Array of term IDs.
   */
  protected function processSuggestions(array $suggestions, string $vocabulary_id, bool $auto_create): array {
    $term_storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $term_ids = [];

    foreach ($suggestions as $term_name) {
      // Try to find existing term.
      $existing_terms = $term_storage->loadByProperties([
        'name' => $term_name,
        'vid' => $vocabulary_id,
      ]);

      if (!empty($existing_terms)) {
        $term = reset($existing_terms);
        $term_ids[] = ['target_id' => $term->id()];
      }
      elseif ($auto_create) {
        // Create new term.
        try {
          $term = $this->entityTypeManager->getStorage('taxonomy_term')->create([
            'name' => $term_name,
            'vid' => $vocabulary_id,
          ]);
          $term->save();
          $term_ids[] = ['target_id' => $term->id()];
        }
        catch (\Exception $e) {
          // Log error but continue with other terms.
          $this->logger->warning(
            'Failed to create taxonomy term "@term" in vocabulary "@vocab": @error',
            [
              '@term' => (string) $term_name,
              '@vocab' => (string) $vocabulary_id,
              '@error' => (string) $e->getMessage(),
            ]
          );
        }
      }
    }

    return $term_ids;
  }

}
