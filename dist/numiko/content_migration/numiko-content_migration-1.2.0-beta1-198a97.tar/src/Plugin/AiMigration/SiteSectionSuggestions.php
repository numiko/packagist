<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\content_migration\Attribute\AiMigration;
use Drupal\field\Entity\FieldConfig;
use Drupal\node\NodeInterface;

/**
 * Plugin for generating taxonomy term suggestions using AI.
 */
#[AiMigration(
  id: 'site_section_settings',
  label: new TranslatableMarkup('Site Section Suggestions'),
  description: new TranslatableMarkup('Generates taxonomy term suggestions for site section based on content analysis.')
)]
class SiteSectionSuggestions extends TaxonomyBase {

  /**
   * {@inheritdoc}
   */
  public function configurationForm(array $form, FormStateInterface $form_state, array $configuration = []): array {
    $content_type = $form_state->getValue('content_type');

    if (!$content_type) {
      return [
        '#markup' => $this->t('Please select a content type first.'),
      ];
    }

    $taxonomy_terms = $this->getTaxonomyTerms();

    if (empty($taxonomy_terms)) {
      return [
        '#markup' => $this->t('No site section terms.'),
      ];
    }

    $form['taxonomy_terms'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Taxonomy Terms'),
      '#options' => $taxonomy_terms,
      '#default_value' => $configuration['taxonomy_terms'] ?? [],
      '#description' => $this->t('Select terms to add.'),
    ];

    $form['auto_create_terms'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Auto-create New Terms'),
      '#default_value' => $configuration['auto_create_terms'] ?? TRUE,
      '#description' => $this->t('Automatically create new taxonomy terms if they do not exist.'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function processContent(string $content, NodeInterface $node, array $configuration): array {
    $taxonomy_terms = $configuration['taxonomy_terms'] ?? [];
    $auto_create_terms = $configuration['auto_create_terms'] ?? TRUE;

    $results = [];
    $fields = $this->entityFieldManager->getFieldDefinitions('node', $node->bundle());
    $field_name = '';
    foreach ($fields as $name => $field_definition) {
      if ($field_definition instanceof FieldConfig) {
        if ($field_definition->getType() === 'entity_reference') {
          $handlerSettings = $field_definition->getSetting('handler_settings');
          foreach ($handlerSettings['target_bundles'] as $bundle) {
            if ($bundle === 'site_section') {
              $field_name = $name;
            }
          }
        }
      }
    }

    if (empty($taxonomy_terms)) {
      try {
        // Generate suggestions for this field.
        $suggestions = $this->generateTaxonomySuggestions($content, 'site_section', 1, 'keywords');

        // Process the suggestions and assign to the field.
        $term_ids = $this->processSuggestions($suggestions, 'site_section', $auto_create_terms);

      }
      catch (\Exception $e) {
        // Log the error but continue with other fields.
        $this->logger->warning(
          'Failed to process taxonomy suggestions for field @field: @error',
          ['@field' => (string) $field_name, '@error' => (string) $e->getMessage()]
        );
      }
    }
    else {
      $term_ids = $taxonomy_terms;
    }

    if (!empty($term_ids)) {
      $node->set($field_name, $term_ids);
      $results[$field_name] = [
        'suggestions' => $suggestions,
        'term_ids' => $term_ids,
      ];
    }
    return $results;
  }

  /**
   * Gets taxonomy field options for the given content type.
   *
   * @return array
   *   An array of field labels keyed by field names.
   */
  protected function getTaxonomyTerms(): array {
    $taxonomy_terms = $this->entityTypeManager->getStorage('taxonomy_term')->loadByProperties(['vid' => 'site_section']);
    return array_map(fn($term) => $term->label(), $taxonomy_terms);
  }

  /**
   * {@inheritDoc}
   */
  #[\Override]
  public function hasBeenCancelled(?string $content_type): bool {
    if (!$content_type) {
      return TRUE;
    }
    $fields = $this->entityFieldManager->getFieldDefinitions('node', $content_type);
    foreach ($fields as $_ => $field_definition) {
      if ($field_definition instanceof FieldConfig) {
        $field_type = $field_definition->getType();

        if ($field_type === 'entity_reference') {
          $handlerSettings = $field_definition->getSetting('handler_settings');
          foreach ($handlerSettings['target_bundles'] as $bundle) {
            if ($bundle === 'site_section') {
              return FALSE;
            }
          }
        }
      }
    }

    return TRUE;
  }

}
