<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\content_migration\Attribute\AiMigration;
use Drupal\content_migration\Exception\AiProcessingException;
use Drupal\content_migration\Plugin\AiMigration\AiMigrationPluginBase;
use Drupal\content_migration\Service\TaxonomyPromptService;
use Drupal\node\NodeInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Plugin for rewriting content using AI.
 */
#[AiMigration(
  id: 'rewrite_content',
  label: new TranslatableMarkup('Rewrite Content'),
  description: new TranslatableMarkup('Rewrites content using AI and tracks changes made.')
)]
class RewriteContent extends AiMigrationPluginBase {

  /**
   * Taxonomy propmt service.
   */
  protected TaxonomyPromptService $taxonomyPrompt;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    $instance = parent::create(
      $container,
      $configuration,
      $plugin_id,
      $plugin_definition,
    );
    $instance->taxonomyPrompt = $container->get(TaxonomyPromptService::class);
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function configurationForm(array $form, FormStateInterface $form_state, array $configuration = []): array {
    $content_type = $form_state->getValue('content_type');

    if (!$content_type) {
      return [
        '#markup' => $this->t('Please select a content type first.'),
      ];
    }

    $field_options = $this->getTextFieldOptionsWithType($content_type);

    // Filter options for changes field (exclude paragraphs)
    $changes_field_options = array_filter($field_options, fn ($key) => !$this->isParagraphFieldKey($key), ARRAY_FILTER_USE_KEY);

    $form['rewrite_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Field for Rewritten Content'),
      '#options' => ['' => $this->t('- Select a field -')] + $field_options,
      '#default_value' => $configuration['rewrite_field'] ?? '',
      '#description' => $this->t('Select the field where the rewritten content will be saved. For paragraph fields, a new "slice_content" paragraph will be created. Leave empty to skip this plugin.'),
    ];

    $form['changes_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Field for Changes Summary'),
      '#options' => ['' => $this->t('- Select a field -')] + $changes_field_options,
      '#default_value' => $configuration['changes_field'] ?? '',
      '#description' => $this->t('Select the field where the summary of changes will be saved. Must be a text field. Leave empty to skip this plugin.'),
    ];

    $form['summary_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Field for Intermediate Summary'),
      '#options' => ['' => $this->t('- Select a field -')] + $field_options,
      '#default_value' => $configuration['summary_field'] ?? '',
      '#description' => $this->t('Optional: Select the field where the intermediate structured summary will be saved. This is the detailed analysis created before rewriting content. Leave empty to skip saving the summary.'),
    ];

    $form['preserve_structure'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Preserve Original Structure'),
      '#default_value' => $configuration['preserve_structure'] ?? TRUE,
      '#description' => $this->t('Maintain the original document structure and hierarchy when rewriting.'),
    ];

    $form['enhance_readability'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enhance Readability'),
      '#default_value' => $configuration['enhance_readability'] ?? TRUE,
      '#description' => $this->t('Improve sentence structure and paragraph flow while preserving meaning.'),
    ];

    $form['preserve_technical_terms'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Preserve Technical Terms'),
      '#default_value' => $configuration['preserve_technical_terms'] ?? TRUE,
      '#description' => $this->t('Keep industry-specific terminology and technical language intact.'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $rewrite_field_key = $form_state->getValue('rewrite_field');
    $changes_field_key = $form_state->getValue('changes_field');
    $summary_field_key = $form_state->getValue('summary_field');

    // Only validate if at least one field is selected (partial configuration)
    if ($rewrite_field_key || $changes_field_key || $summary_field_key) {
      // If user started configuring, require both main fields.
      if (empty($rewrite_field_key)) {
        $form_state->setError(
          $form['rewrite_field'],
          $this->t('Please select a field for rewritten content, or leave both main fields empty to disable this plugin.')
        );
      }

      if (empty($changes_field_key)) {
        $form_state->setError(
          $form['changes_field'],
          $this->t('Please select a field for changes summary, or leave both main fields empty to disable this plugin.')
        );
      }

      // Validate composite key formats and field types if fields are selected.
      if ($rewrite_field_key) {
        try {
          $this->parseCompositeKey($rewrite_field_key);
        }
        catch (\InvalidArgumentException $e) {
          $form_state->setError(
            $form['rewrite_field'],
            $this->t('Invalid field selection format.')
          );
        }
      }

      if ($changes_field_key) {
        try {
          $this->parseCompositeKey($changes_field_key);

          // Validate changes field is not a paragraph field.
          if ($this->isParagraphFieldKey($changes_field_key)) {
            $form_state->setError(
              $form['changes_field'],
              $this->t('Changes field cannot be a paragraph field. Please select a text field.')
            );
          }
        }
        catch (\InvalidArgumentException $e) {
          $form_state->setError(
            $form['changes_field'],
            $this->t('Invalid field selection format.')
          );
        }
      }

      // Validate summary field if selected (optional)
      if ($summary_field_key) {
        try {
          $this->parseCompositeKey($summary_field_key);
        }
        catch (\InvalidArgumentException $e) {
          $form_state->setError(
            $form['summary_field'],
            $this->t('Invalid field selection format.')
          );
        }
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function processContent(string $content, NodeInterface $node, array $configuration): array {
    $rewriteFieldKey = $configuration['rewrite_field'] ?? '';
    $changesFieldKey = $configuration['changes_field'] ?? '';
    $summaryFieldKey = $configuration['summary_field'] ?? '';
    // Get hierarchical prompts from taxonomy selection in plugin configuration.
    $styleGuide = '';
    $taxonomyPrompt = '';

    if (!empty($configuration['taxonomy_term'])) {
      $hierarchical_prompts = $this->taxonomyPrompt->getHierarchicalPrompt((int) $configuration['taxonomy_term']);
      $styleGuide = $hierarchical_prompts['style_guide'] ?? '';
      $taxonomyPrompt = $hierarchical_prompts['audience_prompt'] ?? '';

      // Add the taxonomy prompt to configuration for use in prompt building.
      $configuration['taxonomy_prompt'] = $taxonomyPrompt;
    }

    // Fallback to configuration style guide if no taxonomy selection.
    if (empty($styleGuide) && !empty($configuration['style_guide'])) {
      $styleGuide = $configuration['style_guide'];
    }

    // If no fields configured, skip processing.
    if (empty($rewriteFieldKey) && empty($changesFieldKey)) {
      return [
        'skipped' => TRUE,
        'reason' => 'No fields configured for this plugin',
      ];
    }

    // If partially configured, throw error.
    if (empty($rewriteFieldKey) || empty($changesFieldKey)) {
      throw new AiProcessingException('Both rewrite and changes fields must be configured when using this plugin.');
    }

    // Parse composite keys.
    $rewrite_field_info = $this->parseCompositeKey($rewriteFieldKey);
    $changes_field_info = $this->parseCompositeKey($changesFieldKey);
    $summary_field_info = $summaryFieldKey ? $this->parseCompositeKey($summaryFieldKey) : NULL;

    try {
      $this->logger->info(
        'Starting content rewrite process for node @nid (rewrite: @rewrite_type, changes: @changes_type, summary: @summary_type)',
        [
          '@nid' => (string) $node->id(),
          '@rewrite_type' => (string) ($rewrite_field_info['type'] ?? ''),
          '@changes_type' => (string) ($changes_field_info['type'] ?? ''),
          '@summary_type' => $summary_field_info ? (string) ($summary_field_info['type'] ?? '') : 'none',
        ]
      );

      // ALWAYS use summarization first for consistency.
      $enhancedSummarizePrompt = $this->buildEnhancedSummarizePrompt($content, $configuration);

      // Log the full enhanced summarize prompt being sent to Claude.
      $this->logger->info('RewriteContent: Full enhanced summarize prompt being sent to Claude API:<br/><pre>@prompt</pre>', [
        '@prompt' => (string) $enhancedSummarizePrompt,
      ]);

      $structuredSummary = $this->makeClaudeRequest($enhancedSummarizePrompt);

      if (!$structuredSummary) {
        throw AiProcessingException::summarizeFailed();
      }

      $this->logger->info(
        'Successfully created structured summary for node @nid (length: @length)',
        ['@nid' => (string) $node->id(), '@length' => (string) strlen($structuredSummary)]
      );

      // Save structured summary to configured field if specified.
      if ($summary_field_info) {
        if ($summary_field_info['type'] === 'entity_reference_revisions') {
          $this->setParagraphFieldValue($node, $summary_field_info['field_name'], $structuredSummary);
        }
        else {
          $this->setSummaryTextFieldValue($node, $summary_field_info['field_name'], $structuredSummary);
        }

        $this->logger->info(
          'Saved structured summary to field @field for node @nid',
          ['@field' => (string) ($summary_field_info['field_name'] ?? ''), '@nid' => (string) $node->id()]
        );
      }

      // Then rewrite from the enhanced summary.
      $summarizedRewritePrompt = $this->buildSummarisedRewritePrompt($structuredSummary, $styleGuide, $configuration);

      // Log the full summarized rewrite prompt being sent to Claude.
      $this->logger->info('RewriteContent: Full summarized rewrite prompt being sent to Claude API:<br/><pre>@prompt</pre>', [
        '@prompt' => (string) $summarizedRewritePrompt,
      ]);

      $rewrittenContent = $this->makeClaudeRequest($summarizedRewritePrompt);

      if (!$rewrittenContent) {
        throw AiProcessingException::rewriteFailed('From structured summary.');
      }

      $this->logger->info(
        'Successfully rewrote content for node @nid (length: @length)',
        ['@nid' => (string) $node->id(), '@length' => (string) strlen($rewrittenContent)]
      );
    }
    catch (\Exception $e) {
      $this->logger->info(
        'Content rewrite failed for node @nid: @error',
        ['@nid' => (string) $node->id(), '@error' => (string) $e->getMessage()]
      );
      throw $e;
    }

    // Build the prompt for identifying the changes.
    $prompt = $this->buildRewriteSummariseChangesPrompt($content, $styleGuide, $rewrittenContent);

    // Log the full changes summary prompt being sent to Claude.
    $this->logger->info('RewriteContent: Full changes summary prompt being sent to Claude API:<br/><pre>@prompt</pre>', [
      '@prompt' => (string) $prompt,
    ]);

    // Make the API call.
    $changesSummary = $this->makeClaudeRequest($prompt);

    if (!$rewrittenContent || !$changesSummary) {
      throw AiProcessingException::invalidResponseFormat('Content rewriting returned empty.');
    }

    // Handle different field types for rewritten content.
    if ($rewrite_field_info['type'] === 'entity_reference_revisions') {
      $this->setParagraphFieldValue($node, $rewrite_field_info['field_name'], $rewrittenContent);
    }
    else {
      $this->setTextFieldValue($node, $rewrite_field_info['field_name'], $rewrittenContent);
    }

    // Changes field is always text.
    $this->setTextFieldValue($node, $changes_field_info['field_name'], $changesSummary);

    $result = [
      'rewritten_content' => $rewrittenContent,
      'changes_summary' => $changesSummary,
      'rewrite_field_type' => $rewrite_field_info['type'],
      'rewrite_field_name' => $rewrite_field_info['field_name'],
    ];

    if ($summary_field_info) {
      $result['structured_summary'] = $structuredSummary;
      $result['summary_field_type'] = $summary_field_info['type'];
      $result['summary_field_name'] = $summary_field_info['field_name'];
    }

    return $result;
  }

  /**
   * Builds the enhanced prompt for summarizing content with nuance.
   *
   * @param string $content
   *   The content to summarize.
   * @param array $configuration
   *   The plugin configuration settings.
   *
   * @return string
   *   The complete prompt for Claude API.
   */
  protected function buildEnhancedSummarizePrompt(string $content, array $configuration = []): string {
    // Check if we have a style guide from the global configuration.
    $style_guide_section = '';
    if (!empty($configuration['style_guide'])) {
      $style_guide_section = "\n\n**STYLE GUIDE TO CONSIDER:**\n" . $configuration['style_guide'] . "\n\nWhile analyzing the content, consider how it aligns or differs from this style guide, as this will inform the rewriting process.\n";
    }

    return <<<EOT
I'll provide you with website content that needs to be analyzed and summarized. Create a comprehensive structured summary that captures ALL nuances for content rewriting.{$style_guide_section}

Your summary should include:

1. **CONTENT STRUCTURE**
   - Document the hierarchical structure (headings, sections, subsections)
   - Note any special formatting or emphasis
   - Identify content types (introductions, lists, quotes, calls-to-action, etc.)

2. **KEY MESSAGES & THEMES**
   - Main topics and subtopics
   - Core value propositions or key points
   - Supporting arguments and evidence
   - Any unique selling points or differentiators

3. **TONE & STYLE MARKERS**
   - Current writing tone (formal, casual, technical, friendly, etc.)
   - Specific vocabulary choices that convey expertise or authority
   - Any industry-specific terminology or jargon
   - Emotional appeals or persuasive elements

4. **CONTEXTUAL ELEMENTS**
   - Target audience indicators
   - Purpose/intent of each section
   - Relationships between different content sections
   - Any implied knowledge or assumptions

5. **SPECIFIC DETAILS**
   - Important facts, figures, dates, or statistics
   - Named entities (people, organizations, locations, products)
   - Technical specifications or requirements
   - Contact information or next steps

6. **NARRATIVE ELEMENTS**
   - Most importantly, direct quotes named people, which are enclosed in speech marks, or interviews, must be recorded in the summary with no changes at all
   - Story arcs or case studies
   - Examples, analogies, or metaphors used
   - Before/after scenarios
   - Problem/solution structures

Present this as a detailed structured analysis that preserves the essence and nuance of the original content while organizing it for effective rewriting.

Content to analyze:
{$content}
EOT;
  }

  /**
   * Builds the improved prompt for content rewriting from structured summary.
   *
   * @param string $structuredSummary
   *   The structured summary to rewrite from.
   * @param string $styleGuide
   *   The style guide to follow.
   * @param array $configuration
   *   The plugin configuration settings.
   *
   * @return string
   *   The complete prompt for Claude API.
   */
  protected function buildSummarisedRewritePrompt(string $structuredSummary, string $styleGuide, array $configuration = []): string {
    $preserveStructure = $configuration['preserve_structure'] ?? TRUE;
    $enhanceReadability = $configuration['enhance_readability'] ?? TRUE;
    $preserveTechnicalTerms = $configuration['preserve_technical_terms'] ?? TRUE;

    $additionalInstructions = [];
    if ($preserveStructure) {
      $additionalInstructions[] = '- Maintain the document structure and hierarchy';
    }
    if ($enhanceReadability) {
      $additionalInstructions[] = '- Improve sentence structure and paragraph flow while preserving meaning';
    }
    if ($preserveTechnicalTerms) {
      $additionalInstructions[] = '- Keep industry-specific terminology and technical language intact';
    }

    $additionalInstructionsText = empty($additionalInstructions) ? '' : "\n\n**ADDITIONAL REQUIREMENTS:**\n" . implode("\n", $additionalInstructions);

    // Check if we have a taxonomy prompt for audience targeting.
    $audience_guidance = '';
    if (!empty($configuration['taxonomy_prompt'])) {
      $audience_guidance = "\n\n**AUDIENCE TARGETING:**\n" . $configuration['taxonomy_prompt'] . "\nPlease tailor the content specifically for this target audience while maintaining all requirements above.";
      $this->logger->info('RewriteContent: Using audience targeting in buildSummarisedRewritePrompt. Configuration options - Preserve structure: @preserve_structure, Enhance readability: @enhance_readability, Preserve technical terms: @preserve_technical. Prompt: @prompt', [
        '@preserve_structure' => (string) ($configuration['preserve_structure'] ?? 'default'),
        '@enhance_readability' => (string) ($configuration['enhance_readability'] ?? 'default'),
        '@preserve_technical' => (string) ($configuration['preserve_technical_terms'] ?? 'default'),
        '@prompt' => substr((string) ($configuration['taxonomy_prompt'] ?? ''), 0, 100) . (strlen((string) ($configuration['taxonomy_prompt'] ?? '')) > 100 ? '...' : ''),
      ]);
    }

    return <<<EOT
I'll provide you with a detailed structured summary of content and a style guide. Your task is to create engaging, well-written content that:

1. **PRESERVES ALL NUANCE** from the structured summary
2. **MAINTAINS ORIGINAL INTENT** and key messages
3. **FOLLOWS THE STYLE GUIDE** principles
4. **ENHANCES READABILITY** while keeping all important details

**Style Guide:**
{$styleGuide}

{$audience_guidance}

**Structured Content Summary:**
{$structuredSummary}

**CRITICAL OUTPUT REQUIREMENTS:**
- Your response must contain ONLY the HTML content, nothing else
- Do not include any explanations, comments, or wrapper text
- Do not include any 'back to top' links
- Do not wrap the HTML in code blocks or markdown
- Do not include any text before or after the HTML
- Start immediately with the HTML tags (e.g., <h1>, <p>, etc.)
- Use appropriate HTML tags for structure (headings, paragraphs, lists, etc.)
- Ensure the content flows naturally while following the style guide
- Maintain all key information while improving clarity and engagement
- Use ALL information from the structured summary
- Maintain the document structure and hierarchy
- Preserve all facts, figures, and specific details
- Keep the target audience and purpose in mind
- Retain any industry expertise or authority markers
- Make sure you insert the full text of all direct quotes as recorded in the summary, without rewriting them at all
- Make sure you include all specific details exactly as recorded in the summary, including email addresses and other contact details, and web links
- Maintain logical flow and relationships between sections{$additionalInstructionsText}

Return only the HTML content now:
EOT;
  }

  /**
   * Builds the prompt for getting a list of changes that have been made to the
   * content based on the style guide.
   *
   * @param string $content
   *   The content to rewrite.
   * @param string $styleGuide
   *   The style guide to follow.
   * @param string $rewrittenContent
   *   The rewritten version of the content.
   *
   * @return string
   *   The complete prompt for Claude API.
   */
  protected function buildRewriteSummariseChangesPrompt(string $content, string $styleGuide, string $rewrittenContent): string {
    return <<<EOT
I'll provide you with the original content, the rewritten content and then the style guide. Provide a summary of any changes that may need to be manually made because content is missing from the original content, then provide a list of changes made to each section, and why those changes would have been made based on the style guide.

**CRITICAL OUTPUT REQUIREMENTS:**
- Your response must contain ONLY the HTML content, nothing else
- Do not include any explanations, comments, or wrapper text
- Do not wrap the HTML in code blocks or markdown
- Do not include any text before or after the HTML
- Start immediately with the HTML tags (e.g., <h2>, <p>, <ul>, etc.)
- Use valid HTML markup only

Original content:
{$content}

Rewritten content:
{$rewrittenContent}

Style Guide:
{$styleGuide}

Return only the HTML content summarizing the changes:
EOT;
  }

  /**
   * Sets a text field value.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to update.
   * @param string $field_name
   *   The field name.
   * @param string $content
   *   The content to set.
   */
  protected function setTextFieldValue(NodeInterface $node, string $field_name, string $content): void {
    $node->set($field_name, [
      'value' => $content,
      'format' => 'basic_html',
    ]);
  }

  /**
   * Sets a text field value with plain text format (for summary content).
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to update.
   * @param string $field_name
   *   The field name.
   * @param string $content
   *   The content to set.
   */
  protected function setSummaryTextFieldValue(NodeInterface $node, string $field_name, string $content): void {
    $node->set($field_name, [
      'value' => $content,
      'format' => 'plain_text',
    ]);
  }

  /**
   * Creates a paragraph entity and sets it on the field.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to update.
   * @param string $field_name
   *   The field name.
   * @param string $content
   *   The content to set in the paragraph.
   */
  protected function setParagraphFieldValue(NodeInterface $node, string $field_name, string $content): void {
    // Create a new paragraph entity of type 'slice_content'.
    /** @var \Drupal\paragraphs\ParagraphInterface $paragraph */
    $paragraph = $this->entityTypeManager->getStorage('paragraph')->create([
      'type' => 'slice_content',
      'field_content' => [
        'value' => $content,
        'format' => 'full_html',
      ],
    ]);

    // Save the paragraph.
    $paragraph->save();

    // Set the paragraph reference on the node.
    $node->set($field_name, [
      'target_id' => $paragraph->id(),
      'target_revision_id' => $paragraph->getRevisionId(),
    ]);

    $this->logger->info(
      'Created slice_content paragraph @pid for node @nid field @field',
      [
        '@pid' => (string) $paragraph->id(),
        '@nid' => (string) $node->id(),
        '@field' => (string) $field_name,
      ]
    );
  }

}
