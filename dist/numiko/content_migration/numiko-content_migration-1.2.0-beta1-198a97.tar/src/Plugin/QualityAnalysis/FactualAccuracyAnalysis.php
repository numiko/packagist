<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\QualityAnalysis;

use Drupal\content_migration\Attribute\QualityAnalysis;
use Drupal\content_migration\Plugin\QualityAnalysis\QualityAnalysisPluginBase;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\node\NodeInterface;

/**
 * Compares different content fields within the same page for factual accuracy.
 *
 * This plugin is specifically designed to compare content from different fields
 * on the SAME page/node (e.g., original content field vs rewritten content field,
 * or original content vs paragraph field content). It verifies that factual
 * information has been preserved when content is rewritten, migrated, or
 * restructured within a single page.
 *
 * This plugin does NOT compare content from two different pages.
 */
#[QualityAnalysis(
  id: 'factual_accuracy',
  label: new TranslatableMarkup('Factual Accuracy Check'),
  description: new TranslatableMarkup('Compares content from different fields within the same page to ensure factual details are preserved.'),
  weight: 10
)]
class FactualAccuracyAnalysis extends QualityAnalysisPluginBase {

  /**
   * {@inheritdoc}
   */
  public function isAvailable(array $context = []): bool {
    // This plugin is not available for standard single-field analysis.
    // It requires content from TWO different fields on the same page.
    // Use the compareFieldContent() method instead.
    $this->logger->info('FactualAccuracyAnalysis: Checking if plugin is available...');
    $this->logger->info('FactualAccuracyAnalysis: This plugin compares content from different fields within the same page. It is NOT AVAILABLE for standard single-field analysis.');
    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function analyze(string $content, NodeInterface $node, array $context = []): array {
    // This plugin doesn't analyze a single field - it compares two fields
    // within the same page. Use compareFieldContent() instead.
    return [
      'overall_score' => 'N/A',
      'overall_score_numeric' => 0,
      'scores' => [],
      'summary' => 'This plugin compares content from different fields within the same page. Please use the compareFieldContent() method.',
      'raw_response' => '',
    ];
  }

  /**
   * Compares content from two different fields within the same page.
   *
   * This method compares content from different fields on the same node/page
   * to verify that factual information has been preserved. Common use cases:
   * - Original content field vs rewritten content field
   * - Original content field vs paragraph field content
   * - Body field vs migrated content field
   *
   * IMPORTANT: Both content pieces must be from the SAME page/node. This
   * plugin is not designed to compare content from two different pages.
   *
   * @param string $original_content
   *   Content from the original/source field on this page.
   * @param string $rewritten_content
   *   Content from the new/target field on this page.
   * @param \Drupal\node\NodeInterface $node
   *   The node/page containing both fields being compared.
   * @param array $context
   *   Additional context (optional).
   *
   * @return array
   *   Analysis results including factual differences and accuracy scores.
   */
  public function compareFieldContent(string $original_content, string $rewritten_content, NodeInterface $node, array $context = []): array {
    $this->logger->info('FactualAccuracyAnalysis: Starting field comparison for node @nid (comparing fields within the same page)', [
      '@nid' => $node->id(),
    ]);
    $this->logger->info('FactualAccuracyAnalysis: Original field content length: @orig chars, New field content length: @new chars', [
      '@orig' => strlen($original_content),
      '@new' => strlen($rewritten_content),
    ]);

    // Build the comparison prompt.
    $prompt = $this->buildComparisonPrompt($original_content, $rewritten_content);

    // Make the API call.
    $response = $this->makeClaudeRequest($prompt, 4096);

    // Log the raw response.
    $this->logger->info('FactualAccuracyAnalysis: Raw AI response for node @nid:<br/><pre>@response</pre>', [
      '@nid' => $node->id(),
      '@response' => $response,
    ]);

    // Parse the response.
    $results = $this->parseComparisonResponse($response);

    // Include the raw response for debugging.
    $results['raw_response'] = $response;

    $this->logger->info('FactualAccuracyAnalysis: Comparison completed for node @nid - Overall: @overall', [
      '@nid' => $node->id(),
      '@overall' => $results['overall_score'] ?? 'none',
    ]);

    return $results;
  }

  /**
   * Backwards compatibility wrapper for compareFieldContent().
   *
   * @deprecated Use compareFieldContent() instead for clarity.
   *
   * @param string $original_content
   *   Content from the original/source field.
   * @param string $rewritten_content
   *   Content from the new/target field.
   * @param \Drupal\node\NodeInterface $node
   *   The node containing both fields.
   * @param array $context
   *   Additional context.
   *
   * @return array
   *   Analysis results.
   */
  public function compareContent(string $original_content, string $rewritten_content, NodeInterface $node, array $context = []): array {
    $this->logger->info('FactualAccuracyAnalysis: compareContent() called - delegating to compareFieldContent()');
    return $this->compareFieldContent($original_content, $rewritten_content, $node, $context);
  }

  /**
   * Builds the comparison prompt for field content comparison.
   *
   * @param string $original_content
   *   Content from the original field.
   * @param string $rewritten_content
   *   Content from the new field.
   *
   * @return string
   *   The complete prompt.
   */
  protected function buildComparisonPrompt(string $original_content, string $rewritten_content): string {
    return <<<EOT
I need you to compare content from two different fields within the same page to check for factual accuracy using a side-by-side section comparison approach.

This page has content in multiple fields - an original/source field and a new/target field. The content may have been rewritten, migrated, or restructured between these fields. I need to ensure that all factual information from the original field has been preserved in the new field.

**ORIGINAL FIELD CONTENT:**
{$original_content}

**NEW FIELD CONTENT:**
{$rewritten_content}

**YOUR TASK:**

Please perform a detailed section-by-section factual accuracy check with before/after comparison:

1. Divide the original content into logical sections (paragraphs, topics, or themes)
2. For each section, extract the relevant text from BOTH the original and new fields
3. Identify all factual statements in BOTH versions of each section
4. **CRITICALLY IMPORTANT**: For each section, you MUST check THREE things:
   a) **NEW FACTS**: Identify facts that appear in the NEW field but NOT in the original field
   b) **MISSING FACTS**: Identify facts that appear in the ORIGINAL field but NOT in the new field
   c) **CHANGED FACTS**: Identify facts that appear in both but are stated differently or incorrectly
5. Compare the two versions side-by-side
6. Rate the accuracy of each section individually based on preservation of original facts AND whether new facts were added
7. List ALL discrepancies with clear notes using the four types: NEW, MISSING, CHANGED, INCORRECT

Remember: These are different content fields on the SAME page, not content from two different pages.

**CRITICAL OUTPUT FORMAT:**

You must structure your response EXACTLY as follows:

OVERALL_ACCURACY: [Score as percentage, e.g., "95%"]

SECTION_ANALYSIS:

SECTION 1: [Brief description of what this section covers, e.g., "Introduction and background"]
Original Text: [Extract the relevant text from the original field for this section - keep it concise, around 2-4 sentences or key points]
New Text: [Extract the corresponding text from the new field - keep it concise]
Accuracy Score: [Percentage, e.g., "100%"]
Differences:
[IMPORTANT: You must check for ALL four types of differences:]
[If there are NEW facts in the new field that weren't in the original:]
- [Type: NEW] [Describe the new fact that was added, e.g., "New field adds 'partnership with VSC' which wasn't mentioned in original"]
[If there are MISSING facts from the original that aren't in the new field:]
- [Type: MISSING] [Describe the fact that was removed, e.g., "'resilience and confidence' mentioned in original is omitted from new field"]
[If there are CHANGED facts:]
- [Type: CHANGED] [Describe how the fact changed, e.g., "'500 companies' became 'hundreds of companies' - less precise"]
[If there are INCORRECT facts:]
- [Type: INCORRECT] [Describe the incorrect fact, e.g., "'Dr. Smith' changed to 'Dr. Jones' - wrong person"]
[If no differences in this section, write:]
- No factual differences in this section

SECTION 2: [Brief description]
Original Text: [Relevant text from original]
New Text: [Corresponding text from new field]
Accuracy Score: [Percentage]
Differences:
[Check for NEW, MISSING, CHANGED, and INCORRECT facts]

[Continue for all logical sections found in the content]

OVERALL_SUMMARY:
[Provide a comprehensive summary including:
- Overall assessment of factual preservation across all sections
- Which sections had perfect accuracy and which had issues
- Examples of facts that were accurately transferred
- Details about any NEW facts added to the new field
- Details about any MISSING facts removed from original
- Details about any CHANGED or INCORRECT facts
- Severity of any inaccuracies found
- Recommendations if improvements are needed

Format this section with HTML tags: use <p> for paragraphs, <strong> for emphasis, <ul> and <li> for lists.]

**CRITICAL REQUIREMENTS:**
- Divide content into 3-8 logical sections based on natural paragraph/topic breaks
- Extract representative text from both original and new fields for each section
- Keep extracted text concise but sufficient to show the factual content
- **BE THOROUGH**: You MUST identify facts in BOTH the original AND new fields for each section
- **NEW FACTS**: Explicitly check if the new field introduces facts not in the original
- **MISSING FACTS**: Explicitly check if facts from the original are missing in the new field
- **CHANGED/INCORRECT FACTS**: Check if facts appear in both but differ
- Distinguish between factual changes and stylistic rewording
- Note even minor numerical differences between fields
- Each section should get its own accuracy score considering:
  * Deduct points for MISSING facts (facts lost from original)
  * Deduct points for CHANGED facts (facts made less precise or altered)
  * Deduct points for INCORRECT facts (facts that are wrong)
  * NEW facts should be noted but don't necessarily reduce the score (they're additions, not losses)
- Overall accuracy is the average of section accuracies
- Remember: You are comparing TWO FIELDS on the SAME PAGE, not two separate pages
- Use the exact format shown above with the four difference types: NEW, MISSING, CHANGED, INCORRECT

**EXAMPLE OF PROPER DIFFERENCE DETECTION:**

If Original Text says: "Founded in 1995 by John Smith, serving 500 clients"
And New Text says: "Established in 1995 by John Smith with ISO 9001 certification, serving hundreds of clients"

You should identify:
- [Type: NEW] "ISO 9001 certification" mentioned in new field but not in original
- [Type: MISSING] "500 clients" from original is omitted (replaced with vague "hundreds")
- [Type: CHANGED] "500 clients" became "hundreds of clients" - less precise number

Please provide your section-by-section before/after factual accuracy assessment now:
EOT;
  }

  /**
   * Parses the comparison response with section-based analysis.
   *
   * @param string $response
   *   The API response.
   *
   * @return array
   *   Parsed results with section-based scores.
   */
  protected function parseComparisonResponse(string $response): array {
    $results = [
      'overall_score' => '',
      'overall_score_numeric' => 0,
      'sections' => [],
      'scores' => [],
      'summary' => '',
      'factual_differences' => [],
    ];

    // Extract overall accuracy.
    if (preg_match('/OVERALL_ACCURACY:\s*(.+?)(?:\n|$)/i', $response, $matches)) {
      $results['overall_score'] = trim($matches[1]);
      $results['overall_score_numeric'] = $this->normalizeScore($results['overall_score']);
    }

    // Extract section analysis.
    if (preg_match('/SECTION_ANALYSIS:\s*(.+?)(?=OVERALL_SUMMARY:|$)/is', $response, $matches)) {
      $sections_text = trim($matches[1]);

      // Split into individual sections using SECTION N: as delimiter.
      $section_pattern = '/SECTION\s+(\d+):\s*(.+?)(?=SECTION\s+\d+:|$)/is';
      preg_match_all($section_pattern, $sections_text, $section_matches, PREG_SET_ORDER);

      foreach ($section_matches as $section_match) {
        $section_number = $section_match[1];
        $section_content = trim($section_match[2]);

        $section_data = [
          'number' => $section_number,
          'description' => '',
          'original_text' => '',
          'new_text' => '',
          'accuracy_score' => '',
          'accuracy_score_numeric' => 0,
          'differences' => [],
        ];

        // Extract section description (first line).
        $lines = explode("\n", $section_content);
        if (!empty($lines[0])) {
          $section_data['description'] = trim($lines[0]);
        }

        // Extract original text.
        if (preg_match('/Original\s+Text:\s*(.+?)(?=New\s+Text:|$)/is', $section_content, $orig_match)) {
          $section_data['original_text'] = trim($orig_match[1]);
        }

        // Extract new text.
        if (preg_match('/New\s+Text:\s*(.+?)(?=Accuracy\s+Score:|$)/is', $section_content, $new_match)) {
          $section_data['new_text'] = trim($new_match[1]);
        }

        // Extract accuracy score for this section.
        if (preg_match('/Accuracy\s+Score:\s*(.+?)(?:\n|$)/i', $section_content, $score_match)) {
          $section_data['accuracy_score'] = trim($score_match[1]);
          $section_data['accuracy_score_numeric'] = $this->normalizeScore($section_data['accuracy_score']);
        }

        // Extract differences for this section.
        if (preg_match('/Differences:\s*(.+?)(?=SECTION\s+\d+:|$)/is', $section_content, $diff_match)) {
          $differences_text = trim($diff_match[1]);
          $diff_lines = explode("\n", $differences_text);

          foreach ($diff_lines as $diff_line) {
            $diff_line = trim($diff_line);
            if (empty($diff_line)) {
              continue;
            }

            // Parse format: "- [Type: MISSING/CHANGED/INCORRECT] Description"
            if (preg_match('/^-\s*\[Type:\s*([^\]]+)\]\s*(.+)$/i', $diff_line, $diff_line_match)) {
              $section_data['differences'][] = [
                'type' => trim($diff_line_match[1]),
                'description' => trim($diff_line_match[2]),
              ];

              // Also add to overall factual_differences array for backwards compatibility.
              $results['factual_differences'][] = [
                'type' => trim($diff_line_match[1]),
                'description' => 'Section ' . $section_number . ': ' . trim($diff_line_match[2]),
                'section' => $section_number,
              ];
            }
            elseif (stripos($diff_line, 'No factual differences') !== FALSE) {
              // No differences in this section.
              $section_data['differences'][] = [
                'type' => 'NONE',
                'description' => 'No factual differences in this section',
              ];
            }
          }
        }

        $results['sections'][] = $section_data;

        // Also add to scores array for dashboard compatibility.
        $results['scores']['Section ' . $section_number . ': ' . $section_data['description']] = [
          'score' => $section_data['accuracy_score'],
          'score_numeric' => $section_data['accuracy_score_numeric'],
          'comments' => count($section_data['differences']) . ' items checked',
        ];
      }
    }

    // Extract overall summary.
    if (preg_match('/OVERALL_SUMMARY:\s*(.+)$/is', $response, $matches)) {
      $results['summary'] = trim($matches[1]);
    }

    // Fallback: if parsing failed, use the entire response as summary.
    if (empty($results['overall_score']) && empty($results['sections']) && empty($results['summary'])) {
      $results['summary'] = $response;
    }

    return $results;
  }

}
