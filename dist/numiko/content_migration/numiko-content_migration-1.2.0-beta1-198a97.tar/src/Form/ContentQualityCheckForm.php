<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form;

use Drupal\content_migration\QualityAnalysisPluginManager;
use Drupal\content_migration\Service\ContentQualityService;
use Drupal\content_migration\Service\QualityResultFormatterService;
use Drupal\content_migration\Service\TaxonomyPromptService;
use Drupal\Core\DependencyInjection\AutowireTrait;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Form for checking content quality against style guide.
 */
class ContentQualityCheckForm extends FormBase {
  use AutowireTrait;

  /**
   * Constructs a ContentQualityCheckForm object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\content_migration\Service\ContentQualityService $contentQualityService
   *   The content quality service.
   * @param \Drupal\content_migration\Service\TaxonomyPromptService $taxonomyPromptService
   *   The taxonomy prompt service.
   * @param \Drupal\content_migration\QualityAnalysisPluginManager $qualityAnalysisPluginManager
   *   The quality analysis plugin manager.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   * @param \Drupal\content_migration\Service\QualityResultFormatterService $resultFormatter
   *   The result formatter service.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ContentQualityService $contentQualityService,
    protected TaxonomyPromptService $taxonomyPromptService,
    protected QualityAnalysisPluginManager $qualityAnalysisPluginManager,
    #[Autowire(service: 'logger.channel.content_migration')]
    protected LoggerInterface $logger,
    protected QualityResultFormatterService $resultFormatter,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'content_migration_quality_check_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['#prefix'] = '<div id="quality-check-wrapper">';
    $form['#suffix'] = '</div>';

    // Add inline CSS for quality check display.
    $form['#attached']['html_head'][] = [
      [
        '#tag' => 'style',
        '#value' => '
          .quality-scores-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
          .quality-scores-table th, .quality-scores-table td { padding: 10px; border: 1px solid #ddd; text-align: left; }
          .quality-scores-table th { background-color: #f5f5f5; font-weight: bold; }
          .quality-scores-table tr:nth-child(even) { background-color: #f9f9f9; }
          .score-excellent { color: #28a745; font-weight: bold; }
          .score-good { color: #5cb85c; font-weight: bold; }
          .score-fair { color: #f0ad4e; font-weight: bold; }
          .score-poor { color: #d9534f; font-weight: bold; }
          .quality-overall-score { font-size: 1.2em; margin: 20px 0; padding: 15px; background-color: #e7f3ff; border-left: 4px solid #2196F3; }
          .quality-summary { line-height: 1.6; }
        ',
      ],
      'quality-check-styles',
    ];

    $form['description'] = [
      '#markup' => '<p>' . $this->t('Select a content page to check its quality against the configured style guide.') . '</p>',
    ];

    $form['node_id'] = [
      '#type' => 'entity_autocomplete',
      '#title' => $this->t('Content Page'),
      '#target_type' => 'node',
      '#required' => TRUE,
      '#description' => $this->t('Start typing to search for a content page.'),
      '#ajax' => [
        'callback' => '::updateForm',
        'wrapper' => 'quality-check-wrapper',
      ],
    ];

    // Add optional audience field.
    $config = $this->config('content_migration.settings');
    $audience_vocabulary_id = $config->get('audience_vocabulary');
    $audience_options = [];

    if ($audience_vocabulary_id && $this->taxonomyPromptService->vocabularyHasTermsWithPrompts($audience_vocabulary_id)) {
      $audience_options = $this->taxonomyPromptService->getTermOptions($audience_vocabulary_id);
    }

    if (!empty($audience_options)) {
      $form['audience'] = [
        '#type' => 'select',
        '#title' => $this->t('Target Audience (Optional)'),
        '#options' => $audience_options,
        '#description' => $this->t('Optionally select a target audience to assess content against audience-specific requirements.'),
        '#ajax' => [
          'callback' => '::updateForm',
          'wrapper' => 'quality-check-wrapper',
        ],
      ];
    }

    $node_id = $form_state->getValue('node_id');
    $triggering_element = $form_state->getTriggeringElement();

    // Only show the check button if a node is selected.
    if ($node_id) {
      $form['actions'] = [
        '#type' => 'actions',
        'submit' => [
          '#type' => 'submit',
          '#value' => $this->t('Check'),
          '#ajax' => [
            'callback' => '::checkQuality',
            'wrapper' => 'quality-check-wrapper',
          ],
        ],
      ];
    }

    // Display results if available.
    $results = $form_state->get('quality_results');

    $this->logger->info('ContentQualityCheckForm: Building form - Results available: @available, Keys: @keys', [
      '@available' => $results ? 'yes' : 'no',
      '@keys' => $results ? implode(', ', array_keys($results)) : 'none',
    ]);

    if ($results && !empty($results['assessments'])) {
      $form['results'] = [
        '#type' => 'details',
        '#title' => $this->t('Quality Assessment Results'),
        '#open' => TRUE,
        '#weight' => 100,
      ];

      $form['results']['node_info'] = [
        '#markup' => '<h3>' . $this->t('Content: @title', ['@title' => $results['node_title']]) . '</h3>',
      ];

      // Display each assessment.
      foreach ($results['assessments'] as $assessment_key => $assessment_data) {
        $assessment_results = $assessment_data['results'];
        $assessment_label = $assessment_data['label'];
        $plugin_label = $assessment_data['plugin_label'] ?? '';

        // Build title with both content label and plugin label.
        $title = $assessment_label;
        if (!empty($plugin_label)) {
          $title .= ' - ' . $plugin_label;
        }

        $form['results'][$assessment_key] = [
          '#type' => 'details',
          '#title' => $title,
          '#open' => TRUE,
        ];

        // Show raw response for debugging.
        if (!empty($assessment_results['raw_response'])) {
          $form['results'][$assessment_key]['raw_response'] = [
            '#type' => 'details',
            '#title' => $this->t('Raw AI Response'),
            '#open' => FALSE,
          ];

          $form['results'][$assessment_key]['raw_response']['content'] = [
            '#type' => 'textarea',
            '#title' => $this->t('Full Response from AI'),
            '#value' => $assessment_results['raw_response'],
            '#rows' => 20,
            '#attributes' => ['readonly' => 'readonly'],
          ];
        }

        if (!empty($assessment_results['overall_score'])) {
          $form['results'][$assessment_key]['overall'] = [
            '#markup' => '<div class="quality-overall-score"><strong>' . $this->t('Overall Quality Score:') . '</strong> ' . $assessment_results['overall_score'] . '</div>',
          ];
        }

        // Display section-based analysis if available (for factual accuracy).
        if (!empty($assessment_results['sections'])) {
          $form['results'][$assessment_key]['sections'] = [
            '#type' => 'markup',
            '#markup' => $this->resultFormatter->formatSectionAnalysis($assessment_results['sections']),
          ];
        }
        elseif (!empty($assessment_results['scores'])) {
          // Standard scores display for other plugins.
          $form['results'][$assessment_key]['scores'] = [
            '#type' => 'markup',
            '#markup' => $this->resultFormatter->formatScores($assessment_results['scores']),
          ];
        }

        if (!empty($assessment_results['summary'])) {
          $form['results'][$assessment_key]['summary'] = [
            '#type' => 'details',
            '#title' => $this->t('Detailed Analysis'),
            '#open' => TRUE,
          ];

          $form['results'][$assessment_key]['summary']['content'] = [
            '#markup' => '<div class="quality-summary">' . $assessment_results['summary'] . '</div>',
          ];
        }

        // If no parsed results but we have a raw response, display it.
        if (empty($assessment_results['overall_score']) && empty($assessment_results['scores']) && empty($assessment_results['summary']) && !empty($assessment_results['raw_response'])) {
          $form['results'][$assessment_key]['fallback'] = [
            '#type' => 'details',
            '#title' => $this->t('Assessment Result (Unparsed)'),
            '#open' => TRUE,
          ];

          $form['results'][$assessment_key]['fallback']['content'] = [
            '#markup' => '<div class="quality-fallback"><pre>' . htmlspecialchars($assessment_results['raw_response']) . '</pre></div>',
          ];
        }
      }
    }

    return $form;
  }

  /**
   * Ajax callback to update the form.
   */
  public function updateForm(array &$form, FormStateInterface $form_state): array {
    return $form;
  }

  /**
   * Ajax callback to check quality.
   */
  public function checkQuality(array &$form, FormStateInterface $form_state): array {
    $node_id = $form_state->getValue('node_id');

    $this->logger->info('ContentQualityCheckForm: Check quality requested for node ID: @nid', [
      '@nid' => $node_id ?? 'null',
    ]);

    if (!$node_id) {
      $this->messenger()->addError($this->t('Please select a content page.'));
      return $form;
    }

    try {
      $node = $this->entityTypeManager->getStorage('node')->load($node_id);

      $this->logger->info('ContentQualityCheckForm: Node loaded - ID: @nid, Type: @type, Title: @title', [
        '@nid' => $node ? $node->id() : 'null',
        '@type' => $node ? $node->bundle() : 'null',
        '@title' => $node ? $node->getTitle() : 'null',
      ]);

      if (!$node) {
        $this->messenger()->addError($this->t('Could not load the selected content page.'));
        return $form;
      }

      // Get the content - try original content field first, then fall back to body.
      $config = $this->config('content_migration.settings');
      $content_type = $node->bundle();
      $field_mappings = $config->get('content_type_field_mappings')[$content_type] ?? [];
      $original_content_field = $field_mappings['original_content'] ?? NULL;

      $this->logger->info('ContentQualityCheckForm: Field mappings - Content type: @type, Original content field: @field', [
        '@type' => $content_type,
        '@field' => $original_content_field ?? 'null',
      ]);

      $content = NULL;
      $field_name = NULL;

      // Try to get content from the original content field first.
      if ($original_content_field) {
        // Parse the composite key to get field name.
        if (strpos($original_content_field, ':') !== FALSE) {
          [$field_type, $field_name] = explode(':', $original_content_field, 2);
        }
        else {
          $field_name = $original_content_field;
        }

        $this->logger->info('ContentQualityCheckForm: Checking original content field: @field', [
          '@field' => $field_name,
        ]);

        if ($node->hasField($field_name) && !$node->get($field_name)->isEmpty()) {
          $content = $node->get($field_name)->value;
          $this->logger->info('ContentQualityCheckForm: Using content from original content field: @field', [
            '@field' => $field_name,
          ]);
        }
      }

      // Fall back to body field if original content field is not available or empty.
      if (empty($content) && $node->hasField('body') && !$node->get('body')->isEmpty()) {
        $content = $node->get('body')->value;
        $field_name = 'body';
        $this->logger->info('ContentQualityCheckForm: Using content from body field (original content field was empty or not configured)');
      }

      // Check if there's any paragraph content available.
      $has_paragraph_content = FALSE;
      if (empty($content)) {
        $has_paragraph_content = $this->hasParagraphContent($node);
        $this->logger->info('ContentQualityCheckForm: Paragraph content check result: @result', [
          '@result' => $has_paragraph_content ? 'yes' : 'no',
        ]);
      }

      // If no content in fields and no paragraph content, show an error.
      if (empty($content) && !$has_paragraph_content) {
        $this->messenger()->addError($this->t('The selected content page does not have any content to analyze.'));
        $this->logger->warning('ContentQualityCheckForm: No content found in original content field, body field, or paragraphs on node @nid', [
          '@nid' => $node->id(),
        ]);
        return $form;
      }

      $content_length = !empty($content) ? strlen($content) : 0;

      $this->logger->info('ContentQualityCheckForm: Content retrieved - Length: @length characters', [
        '@length' => $content_length,
      ]);

      // Get the audience term ID if selected.
      $audience_term_id = $form_state->getValue('audience');
      if ($audience_term_id === '') {
        $audience_term_id = NULL;
      }

      $this->logger->info('ContentQualityCheckForm: Audience term ID: @audience', [
        '@audience' => $audience_term_id ?? 'none',
      ]);

      // Prepare results array to hold multiple assessments.
      $all_results = [
        'node_title' => $node->getTitle(),
        'audience_term_id' => $audience_term_id,
        'assessments' => [],
      ];

      // Get quality assessment for original content (if available).
      if (!empty($content)) {
        $this->logger->info('ContentQualityCheckForm: Calling assessContent service for original content...');
        $original_results = $this->contentQualityService->assessContent($content, $node, $audience_term_id);

        $this->logger->info('ContentQualityCheckForm: Original content assessment complete. Plugin count: @count', [
          '@count' => count($original_results),
        ]);

        // Store results from all plugins.
        foreach ($original_results as $plugin_id => $plugin_data) {
          $all_results['assessments']['original_content_' . $plugin_id] = [
            'label' => 'Original Content',
            'plugin_id' => $plugin_id,
            'plugin_label' => $plugin_data['plugin_label'],
            'results' => $plugin_data['results'],
          ];
        }
      }
      else {
        $this->logger->info('ContentQualityCheckForm: No content in original content or body field. Skipping original content assessment.');
      }

      // Check for rewritten content and run factual accuracy comparison (only if we have original content).
      if (!empty($content)) {
        $this->logger->info('ContentQualityCheckForm: ===== CHECKING FOR REWRITTEN CONTENT =====');
        $this->logger->info('ContentQualityCheckForm: Content type: @type', [
          '@type' => $content_type,
        ]);
        $this->logger->info('ContentQualityCheckForm: Field mappings: @mappings', [
          '@mappings' => json_encode($field_mappings),
        ]);

        $rewritten_content = $this->getRewrittenContent($node, $content_type, $field_mappings);

        $this->logger->info('ContentQualityCheckForm: Rewritten content result: @result', [
          '@result' => $rewritten_content ? 'FOUND (' . strlen($rewritten_content) . ' chars)' : 'NOT FOUND',
        ]);

        if (!empty($rewritten_content)) {
          $this->logger->info('ContentQualityCheckForm: ✓ Rewritten content exists. Running factual accuracy comparison...');

          try {
            $comparison_results = $this->contentQualityService->compareContent($content, $rewritten_content, $node, $audience_term_id);

            $all_results['assessments']['factual_accuracy_comparison'] = [
              'label' => 'Factual Accuracy Comparison',
              'plugin_id' => 'factual_accuracy',
              'plugin_label' => 'Factual Accuracy Check',
              'results' => $comparison_results,
            ];

            $this->logger->info('ContentQualityCheckForm: Factual accuracy comparison complete');
          }
          catch (\Exception $e) {
            $this->logger->error('ContentQualityCheckForm: Factual accuracy comparison failed: @error', [
              '@error' => $e->getMessage(),
            ]);
          }

          // Also assess the rewritten content separately with standard plugins.
          $this->logger->info('ContentQualityCheckForm: Assessing rewritten content quality...');
          $rewritten_results = $this->contentQualityService->assessContent($rewritten_content, $node, $audience_term_id);

          // Store results from all plugins.
          foreach ($rewritten_results as $plugin_id => $plugin_data) {
            $all_results['assessments']['rewritten_content_' . $plugin_id] = [
              'label' => 'Rewritten Content',
              'plugin_id' => $plugin_id,
              'plugin_label' => $plugin_data['plugin_label'],
              'results' => $plugin_data['results'],
            ];
          }
        }
        else {
          $this->logger->info('ContentQualityCheckForm: ✗ No rewritten content found. Skipping factual accuracy comparison.');
        }
      }
      else {
        $this->logger->info('ContentQualityCheckForm: ===== SKIPPING REWRITTEN CONTENT CHECK (no original content) =====');
      }

      // Check for paragraph fields with body content.
      $this->logger->info('ContentQualityCheckForm: ===== CHECKING FOR PARAGRAPH CONTENT =====');
      $paragraph_assessments = $this->assessParagraphContent($node, $audience_term_id);
      if (!empty($paragraph_assessments)) {
        $this->logger->info('ContentQualityCheckForm: Found @count paragraph assessments', [
          '@count' => count($paragraph_assessments),
        ]);

        foreach ($paragraph_assessments as $key => $assessment) {
          $all_results['assessments'][$key] = $assessment;
        }

        // If we have original content and paragraph content, run factual accuracy comparison.
        if (!empty($content)) {
          $this->logger->info('ContentQualityCheckForm: Both original content and paragraph content exist. Checking for factual accuracy comparisons...');

          // Get paragraph content for comparison.
          $paragraph_contents = $this->getParagraphContentsForComparison($node);

          foreach ($paragraph_contents as $paragraph_key => $paragraph_data) {
            $this->logger->info('ContentQualityCheckForm: Running factual accuracy comparison between original content and @label', [
              '@label' => $paragraph_data['label'],
            ]);

            try {
              $comparison_results = $this->contentQualityService->compareContent(
                $content,
                $paragraph_data['content'],
                $node,
                $audience_term_id
              );

              $all_results['assessments']['factual_accuracy_original_vs_' . $paragraph_key] = [
                'label' => 'Factual Accuracy: Original vs ' . $paragraph_data['label'],
                'plugin_id' => 'factual_accuracy',
                'plugin_label' => 'Factual Accuracy Check',
                'results' => $comparison_results,
              ];

              $this->logger->info('ContentQualityCheckForm: Factual accuracy comparison complete for @label', [
                '@label' => $paragraph_data['label'],
              ]);
            }
            catch (\Exception $e) {
              $this->logger->error('ContentQualityCheckForm: Factual accuracy comparison failed for @label: @error', [
                '@label' => $paragraph_data['label'],
                '@error' => $e->getMessage(),
              ]);
            }
          }
        }
        else {
          $this->logger->info('ContentQualityCheckForm: No original content available. Skipping factual accuracy comparisons with paragraphs.');
        }
      }
      else {
        $this->logger->info('ContentQualityCheckForm: No paragraph content found.');
      }

      $form_state->set('quality_results', $all_results);

      // Save assessment results to the configured field if available.
      $this->saveAssessmentToField($node, $all_results);

      // Add a success message.
      $this->messenger()->addStatus($this->t('Quality assessment completed successfully.'));

      // Rebuild the form to show results.
      $form_state->setRebuild(TRUE);
    }
    catch (\Exception $e) {
      $this->logger->error('ContentQualityCheckForm: Exception caught - @error', [
        '@error' => $e->getMessage(),
      ]);
      $this->messenger()->addError($this->t('Error checking content quality: @error', ['@error' => $e->getMessage()]));
    }

    // Rebuild the entire form array with the new results.
    $form = $this->buildForm($form, $form_state);
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // This form uses AJAX, so regular submit is not used.
  }

  /**
   * Gets rewritten content from the node if it exists.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to check.
   * @param string $content_type
   *   The content type.
   * @param array $field_mappings
   *   The field mappings configuration.
   *
   * @return string|null
   *   The rewritten content or NULL if not found.
   */
  protected function getRewrittenContent($node, string $content_type, array $field_mappings): ?string {
    $this->logger->info('getRewrittenContent: Starting rewritten content detection for node @nid', [
      '@nid' => $node->id(),
    ]);

    $rewritten_content_field = $field_mappings['rewritten_content'] ?? NULL;

    $this->logger->info('getRewrittenContent: Rewritten content field from mappings: @field', [
      '@field' => $rewritten_content_field ?? 'NULL (not configured)',
    ]);

    if (!$rewritten_content_field) {
      $this->logger->info('getRewrittenContent: No rewritten content field configured for this content type. Returning NULL.');
      return NULL;
    }

    // Parse the composite key to get field name.
    if (strpos($rewritten_content_field, ':') !== FALSE) {
      [$field_type, $field_name] = explode(':', $rewritten_content_field, 2);
      $this->logger->info('getRewrittenContent: Parsed composite field - Type: @type, Name: @name', [
        '@type' => $field_type,
        '@name' => $field_name,
      ]);
    }
    else {
      $field_name = $rewritten_content_field;
      $this->logger->info('getRewrittenContent: Using field name directly: @name', [
        '@name' => $field_name,
      ]);
    }

    $this->logger->info('getRewrittenContent: Checking if node has field "@field"...', [
      '@field' => $field_name,
    ]);

    if (!$node->hasField($field_name)) {
      $this->logger->info('getRewrittenContent: Node does NOT have field "@field". Returning NULL.', [
        '@field' => $field_name,
      ]);
      return NULL;
    }

    $this->logger->info('getRewrittenContent: Node has field "@field". Checking if empty...', [
      '@field' => $field_name,
    ]);

    if ($node->get($field_name)->isEmpty()) {
      $this->logger->info('getRewrittenContent: Field "@field" is EMPTY. Returning NULL.', [
        '@field' => $field_name,
      ]);
      return NULL;
    }

    $content = $node->get($field_name)->value;
    $this->logger->info('getRewrittenContent: ✓ Found rewritten content in field "@field" - Length: @length chars', [
      '@field' => $field_name,
      '@length' => strlen($content),
    ]);

    return $content;
  }

  /**
   * Gets paragraph contents for factual accuracy comparison.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to check.
   *
   * @return array
   *   Array of paragraph content keyed by paragraph identifier.
   *   Each entry contains 'label' and 'content'.
   */
  protected function getParagraphContentsForComparison($node): array {
    $paragraph_contents = [];

    // Get all entity reference revision fields (paragraph fields).
    $field_definitions = $node->getFieldDefinitions();

    foreach ($field_definitions as $field_name => $field_definition) {
      if ($field_definition->getType() === 'entity_reference_revisions') {
        $target_type = $field_definition->getSetting('target_type');

        if ($target_type === 'paragraph' && !$node->get($field_name)->isEmpty()) {
          $paragraphs = $node->get($field_name)->referencedEntities();

          foreach ($paragraphs as $index => $paragraph) {
            // Check if paragraph has a field_content or body field.
            $content_field = NULL;
            if ($paragraph->hasField('field_content') && !$paragraph->get('field_content')->isEmpty()) {
              $content_field = 'field_content';
            }
            elseif ($paragraph->hasField('body') && !$paragraph->get('body')->isEmpty()) {
              $content_field = 'body';
            }

            if ($content_field) {
              $paragraph_content = $paragraph->get($content_field)->value;
              $paragraph_type = $paragraph->bundle();

              if (!empty(trim($paragraph_content))) {
                $key = 'paragraph_' . $field_name . '_' . $index;
                $label = $this->t('Paragraph: @field (@type) #@index', [
                  '@field' => $field_definition->getLabel(),
                  '@type' => $paragraph_type,
                  '@index' => $index + 1,
                ]);

                $paragraph_contents[$key] = [
                  'label' => $label,
                  'content' => $paragraph_content,
                ];
              }
            }
          }
        }
      }
    }

    return $paragraph_contents;
  }

  /**
   * Assesses content in paragraph fields.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to check.
   * @param int|null $audience_term_id
   *   Optional audience term ID.
   *
   * @return array
   *   Array of paragraph assessments.
   */
  protected function assessParagraphContent($node, $audience_term_id = NULL): array {
    $assessments = [];

    // Get all entity reference revision fields (paragraph fields).
    $field_definitions = $node->getFieldDefinitions();

    foreach ($field_definitions as $field_name => $field_definition) {
      if ($field_definition->getType() === 'entity_reference_revisions') {
        $target_type = $field_definition->getSetting('target_type');

        if ($target_type === 'paragraph' && !$node->get($field_name)->isEmpty()) {
          $paragraphs = $node->get($field_name)->referencedEntities();

          foreach ($paragraphs as $index => $paragraph) {
            // Check if paragraph has a field_content or body field.
            $content_field = NULL;
            if ($paragraph->hasField('field_content') && !$paragraph->get('field_content')->isEmpty()) {
              $content_field = 'field_content';
            }
            elseif ($paragraph->hasField('body') && !$paragraph->get('body')->isEmpty()) {
              $content_field = 'body';
            }

            if ($content_field) {
              $paragraph_content = $paragraph->get($content_field)->value;
              $paragraph_type = $paragraph->bundle();

              if (!empty(trim($paragraph_content))) {
                $this->logger->info('ContentQualityCheckForm: Found paragraph content in @field_name[@index], type: @type, length: @length', [
                  '@field_name' => $field_name,
                  '@index' => $index,
                  '@type' => $paragraph_type,
                  '@length' => strlen($paragraph_content),
                ]);

                try {
                  $paragraph_results = $this->contentQualityService->assessContent($paragraph_content, $node, $audience_term_id);

                  $label = $this->t('Paragraph: @field (@type) #@index', [
                    '@field' => $field_definition->getLabel(),
                    '@type' => $paragraph_type,
                    '@index' => $index + 1,
                  ]);

                  // Store results from all plugins.
                  foreach ($paragraph_results as $plugin_id => $plugin_data) {
                    $assessments['paragraph_' . $field_name . '_' . $index . '_' . $plugin_id] = [
                      'label' => $label,
                      'plugin_id' => $plugin_id,
                      'plugin_label' => $plugin_data['plugin_label'],
                      'results' => $plugin_data['results'],
                    ];
                  }

                  $this->logger->info('ContentQualityCheckForm: Paragraph assessment complete for @field_name[@index]', [
                    '@field_name' => $field_name,
                    '@index' => $index,
                  ]);
                }
                catch (\Exception $e) {
                  $this->logger->error('ContentQualityCheckForm: Failed to assess paragraph @field_name[@index]: @error', [
                    '@field_name' => $field_name,
                    '@index' => $index,
                    '@error' => $e->getMessage(),
                  ]);
                }
              }
            }
          }
        }
      }
    }

    return $assessments;
  }

  /**
   * Saves assessment results to the configured quality assessment field.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to save the assessment to.
   * @param array $results
   *   The assessment results array.
   */
  protected function saveAssessmentToField($node, array $results): void {
    $config = $this->config('content_migration.settings');
    $content_type = $node->bundle();
    $field_mappings = $config->get('content_type_field_mappings')[$content_type] ?? [];
    $quality_assessment_field = $field_mappings['quality_assessment'] ?? NULL;

    if (!$quality_assessment_field) {
      $this->logger->info('ContentQualityCheckForm: No quality assessment field configured for content type @type', [
        '@type' => $content_type,
      ]);
      return;
    }

    // Parse the composite key to get field name.
    if (strpos($quality_assessment_field, ':') !== FALSE) {
      [$field_type, $field_name] = explode(':', $quality_assessment_field, 2);
    }
    else {
      $field_name = $quality_assessment_field;
    }

    if (!$node->hasField($field_name)) {
      $this->logger->warning('ContentQualityCheckForm: Field @field does not exist on node @nid', [
        '@field' => $field_name,
        '@nid' => $node->id(),
      ]);
      return;
    }

    // Build JSON structure for assessment results.
    $json_results = $this->resultFormatter->buildJsonResults($node, $results);

    try {
      $node->set($field_name, [
        'value' => json_encode($json_results, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        'format' => 'plain_text',
      ]);
      $node->save();

      $this->logger->info('ContentQualityCheckForm: Saved quality assessment JSON to field @field on node @nid', [
        '@field' => $field_name,
        '@nid' => $node->id(),
      ]);

      $this->messenger()->addStatus($this->t('Assessment results saved to @field field in JSON format.', ['@field' => $field_name]));
    }
    catch (\Exception $e) {
      $this->logger->error('ContentQualityCheckForm: Failed to save assessment to field @field: @error', [
        '@field' => $field_name,
        '@error' => $e->getMessage(),
      ]);
      $this->messenger()->addWarning($this->t('Could not save assessment results to field: @error', ['@error' => $e->getMessage()]));
    }
  }

  /**
   * Checks if a node has any paragraph content.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to check.
   *
   * @return bool
   *   TRUE if the node has paragraph fields with content, FALSE otherwise.
   */
  protected function hasParagraphContent($node): bool {
    // Get all entity reference revision fields (paragraph fields).
    $field_definitions = $node->getFieldDefinitions();

    foreach ($field_definitions as $field_name => $field_definition) {
      if ($field_definition->getType() === 'entity_reference_revisions') {
        $target_type = $field_definition->getSetting('target_type');

        if ($target_type === 'paragraph' && !$node->get($field_name)->isEmpty()) {
          $paragraphs = $node->get($field_name)->referencedEntities();

          foreach ($paragraphs as $paragraph) {
            // Check if paragraph has a field_content or body field with content.
            if ($paragraph->hasField('field_content') && !$paragraph->get('field_content')->isEmpty()) {
              $content = trim($paragraph->get('field_content')->value);
              if (!empty($content)) {
                return TRUE;
              }
            }
            elseif ($paragraph->hasField('body') && !$paragraph->get('body')->isEmpty()) {
              $content = trim($paragraph->get('body')->value);
              if (!empty($content)) {
                return TRUE;
              }
            }
          }
        }
      }
    }

    return FALSE;
  }

}
