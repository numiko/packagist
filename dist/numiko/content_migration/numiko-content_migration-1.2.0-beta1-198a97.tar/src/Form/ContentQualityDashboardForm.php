<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form;

use Drupal\Core\DependencyInjection\AutowireTrait;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Dashboard for viewing content quality assessments across multiple pages.
 */
class ContentQualityDashboardForm extends FormBase {
  use AutowireTrait;

  /**
   * Constructs a ContentQualityDashboardForm object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'content_migration_quality_dashboard_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Attach the quality dashboard library (CSS and JS).
    $form['#attached']['library'][] = 'content_migration/quality_dashboard';

    $form['description'] = [
      '#markup' => '<p>' . $this->t('View and compare content quality assessments across all pages.') . '</p>',
    ];

    // Get all nodes with quality assessment data.
    $assessment_data = $this->loadAllAssessments();

    if (empty($assessment_data)) {
      $form['no_data'] = [
        '#markup' => '<div class="messages messages--warning">' . $this->t('No quality assessment data found. Run the Content Quality Checker on some pages first.') . '</div>',
      ];
      return $form;
    }

    // Display summary statistics.
    $stats = $this->calculateStatistics($assessment_data);
    $form['statistics'] = [
      '#type' => 'markup',
      '#markup' => $this->renderStatistics($stats),
    ];

    // Filter section.
    $form['filters'] = [
      '#type' => 'details',
      '#title' => $this->t('Filters'),
      '#open' => FALSE,
      '#attributes' => ['class' => ['filter-section']],
    ];

    $content_types = $this->getContentTypesWithAssessments($assessment_data);
    $form['filters']['content_type_filter'] = [
      '#type' => 'select',
      '#title' => $this->t('Content Type'),
      '#options' => ['' => $this->t('- All -')] + $content_types,
      '#default_value' => $form_state->getValue('content_type_filter') ?? '',
    ];

    $form['filters']['score_filter'] = [
      '#type' => 'select',
      '#title' => $this->t('Minimum Score'),
      '#options' => [
        '' => $this->t('- All -'),
        '80' => $this->t('80% and above (Excellent)'),
        '60' => $this->t('60% and above (Good)'),
        '40' => $this->t('40% and above (Fair)'),
        '0' => $this->t('Below 40% (Needs Improvement)'),
      ],
      '#default_value' => $form_state->getValue('score_filter') ?? '',
    ];

    $form['filters']['apply'] = [
      '#type' => 'submit',
      '#value' => $this->t('Apply Filters'),
      '#submit' => ['::applyFilters'],
      '#ajax' => [
        'callback' => '::updateDashboard',
        'wrapper' => 'dashboard-wrapper',
      ],
    ];

    $form['dashboard'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'dashboard-wrapper'],
    ];

    // Apply filters.
    $filtered_data = $this->applyFiltersToData(
      $assessment_data,
      $form_state->getValue('content_type_filter'),
      $form_state->getValue('score_filter')
    );

    // Render the dashboard table.
    $form['dashboard']['table'] = [
      '#type' => 'markup',
      '#markup' => $this->renderDashboardTable($filtered_data),
    ];

    return $form;
  }

  /**
   * Ajax callback to update dashboard.
   */
  public function updateDashboard(array &$form, FormStateInterface $form_state) {
    return $form['dashboard'];
  }

  /**
   * Submit handler for applying filters.
   */
  public function applyFilters(array &$form, FormStateInterface $form_state) {
    $form_state->setRebuild(TRUE);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Main submit not used - we use custom submit handlers.
  }

  /**
   * Loads all quality assessment data from nodes.
   *
   * @return array
   *   Array of assessment data keyed by node ID.
   */
  protected function loadAllAssessments(): array {
    $config = $this->config('content_migration.settings');
    $field_mappings = $config->get('content_type_field_mappings') ?? [];

    $assessment_data = [];

    foreach ($field_mappings as $content_type => $mappings) {
      if (empty($mappings['quality_assessment'])) {
        continue;
      }

      // Parse the composite key to get field name.
      $quality_field = $mappings['quality_assessment'];
      if (strpos($quality_field, ':') !== FALSE) {
        [, $field_name] = explode(':', $quality_field, 2);
      }
      else {
        $field_name = $quality_field;
      }

      // Load all nodes of this content type with quality data.
      $query = $this->entityTypeManager->getStorage('node')->getQuery()
        ->condition('type', $content_type)
        ->condition($field_name, '', '<>')
        ->accessCheck(TRUE)
        ->sort('changed', 'DESC');

      $nids = $query->execute();

      if (empty($nids)) {
        continue;
      }

      $nodes = $this->entityTypeManager->getStorage('node')->loadMultiple($nids);

      foreach ($nodes as $node) {
        if (!$node->hasField($field_name) || $node->get($field_name)->isEmpty()) {
          continue;
        }

        $json_data = $node->get($field_name)->value;
        $assessment = json_decode($json_data, TRUE);

        if (json_last_error() === JSON_ERROR_NONE && !empty($assessment)) {
          $assessment_data[$node->id()] = [
            'node' => $node,
            'content_type' => $content_type,
            'assessment' => $assessment,
          ];
        }
      }
    }

    return $assessment_data;
  }

  /**
   * Calculates summary statistics.
   *
   * @param array $assessment_data
   *   The assessment data.
   *
   * @return array
   *   Statistics array.
   */
  protected function calculateStatistics(array $assessment_data): array {
    $stats = [
      'total_pages' => count($assessment_data),
      'total_assessments' => 0,
      'average_score' => 0,
      'excellent_count' => 0,
      'good_count' => 0,
      'fair_count' => 0,
      'poor_count' => 0,
    ];

    $total_score = 0;
    $score_count = 0;

    foreach ($assessment_data as $data) {
      $assessment = $data['assessment'];
      if (!empty($assessment['assessments'])) {
        $stats['total_assessments'] += count($assessment['assessments']);

        foreach ($assessment['assessments'] as $assess) {
          if (!empty($assess['overall_score_numeric'])) {
            $score = $assess['overall_score_numeric'];
            $total_score += $score;
            $score_count++;

            if ($score >= 80) {
              $stats['excellent_count']++;
            }
            elseif ($score >= 60) {
              $stats['good_count']++;
            }
            elseif ($score >= 40) {
              $stats['fair_count']++;
            }
            else {
              $stats['poor_count']++;
            }
          }
        }
      }
    }

    if ($score_count > 0) {
      $stats['average_score'] = round($total_score / $score_count, 1);
    }

    return $stats;
  }

  /**
   * Renders statistics section.
   *
   * @param array $stats
   *   The statistics.
   *
   * @return string
   *   Rendered HTML.
   */
  protected function renderStatistics(array $stats): string {
    $output = '<div class="summary-stats">';
    $output .= '<div class="stat-box">';
    $output .= '<div class="stat-value">' . $stats['total_pages'] . '</div>';
    $output .= '<div class="stat-label">' . $this->t('Pages Assessed') . '</div>';
    $output .= '</div>';

    $output .= '<div class="stat-box">';
    $output .= '<div class="stat-value">' . $stats['total_assessments'] . '</div>';
    $output .= '<div class="stat-label">' . $this->t('Total Assessments') . '</div>';
    $output .= '</div>';

    $output .= '<div class="stat-box">';
    $output .= '<div class="stat-value">' . $stats['average_score'] . '%</div>';
    $output .= '<div class="stat-label">' . $this->t('Average Score') . '</div>';
    $output .= '</div>';

    $output .= '<div class="stat-box">';
    $output .= '<div class="stat-value">' . $stats['excellent_count'] . '</div>';
    $output .= '<div class="stat-label">' . $this->t('Excellent (80%+)') . '</div>';
    $output .= '</div>';
    $output .= '</div>';

    return $output;
  }

  /**
   * Gets content types that have assessments.
   *
   * @param array $assessment_data
   *   The assessment data.
   *
   * @return array
   *   Content type options.
   */
  protected function getContentTypesWithAssessments(array $assessment_data): array {
    $types = [];
    foreach ($assessment_data as $data) {
      $content_type = $data['content_type'];
      $type_entity = $this->entityTypeManager->getStorage('node_type')->load($content_type);
      if ($type_entity) {
        $types[$content_type] = $type_entity->label();
      }
    }
    return $types;
  }

  /**
   * Applies filters to assessment data.
   *
   * @param array $assessment_data
   *   The assessment data.
   * @param string|null $content_type_filter
   *   Content type filter.
   * @param string|null $score_filter
   *   Score filter.
   *
   * @return array
   *   Filtered data.
   */
  protected function applyFiltersToData(array $assessment_data, ?string $content_type_filter, ?string $score_filter): array {
    $filtered = $assessment_data;

    // Filter by content type.
    if (!empty($content_type_filter)) {
      $filtered = array_filter($filtered, function ($data) use ($content_type_filter) {
        return $data['content_type'] === $content_type_filter;
      });
    }

    // Filter by score.
    if ($score_filter !== NULL && $score_filter !== '') {
      $min_score = (float) $score_filter;
      $filtered = array_filter($filtered, function ($data) use ($min_score) {
        $assessment = $data['assessment'];
        if (!empty($assessment['assessments'])) {
          foreach ($assessment['assessments'] as $assess) {
            if (!empty($assess['overall_score_numeric'])) {
              $score = $assess['overall_score_numeric'];
              if ($min_score == 0) {
                // Special case: show only poor scores.
                return $score < 40;
              }
              return $score >= $min_score;
            }
          }
        }
        return FALSE;
      });
    }

    return $filtered;
  }

  /**
   * Renders the dashboard table.
   *
   * @param array $assessment_data
   *   The assessment data.
   *
   * @return string
   *   Rendered HTML table.
   */
  protected function renderDashboardTable(array $assessment_data): string {
    if (empty($assessment_data)) {
      return '<div class="messages messages--warning">' . $this->t('No results match the selected filters.') . '</div>';
    }

    // First, determine all unique plugins and content types used.
    $all_plugins = $this->getAllPluginsUsed($assessment_data);
    $all_content_types = $this->getAllContentTypesUsed($assessment_data);

    $output = '<table class="quality-dashboard-table">';

    // Create a two-row header.
    $output .= '<thead>';

    // First header row - plugin names.
    $output .= '<tr>';
    $output .= '<th rowspan="2">' . $this->t('Page Title') . '</th>';
    $output .= '<th rowspan="2">' . $this->t('Content Type') . '</th>';
    $output .= '<th rowspan="2">' . $this->t('Assessment Date') . '</th>';

    // Each plugin spans the number of content types.
    foreach ($all_plugins as $plugin_id => $plugin_label) {
      $output .= '<th colspan="' . count($all_content_types) . '" class="plugin-header">' . htmlspecialchars($plugin_label) . '</th>';
    }

    $output .= '</tr>';

    // Second header row - content type labels under each plugin.
    $output .= '<tr>';
    foreach ($all_plugins as $plugin_id => $plugin_label) {
      foreach ($all_content_types as $content_type => $content_type_label) {
        $output .= '<th class="content-type-header">' . htmlspecialchars($content_type_label) . '</th>';
      }
    }
    $output .= '</tr>';

    $output .= '</thead>';
    $output .= '<tbody>';

    foreach ($assessment_data as $nid => $data) {
      $node = $data['node'];
      $assessment = $data['assessment'];
      $type_entity = $this->entityTypeManager->getStorage('node_type')->load($data['content_type']);
      $content_type_label = $type_entity ? htmlspecialchars($type_entity->label()) : htmlspecialchars($data['content_type']);

      // Organize assessments into a matrix: [plugin_id][content_type] = score.
      $score_matrix = $this->buildScoreMatrix($assessment['assessments'] ?? [], $all_plugins, $all_content_types);

      $output .= '<tr data-node-id="' . $nid . '">';
      $output .= '<td><a href="' . $node->toUrl()->toString() . '">' . htmlspecialchars($assessment['node_title']) . '</a></td>';
      $output .= '<td>' . $content_type_label . '</td>';
      $output .= '<td>' . htmlspecialchars($assessment['assessment_date']) . '</td>';

      // For each plugin, show scores for each content type.
      $plugin_index = 0;
      foreach ($all_plugins as $plugin_id => $plugin_label) {
        // Build the content for this plugin cell.
        $plugin_content = '<div class="plugin-scores-wrapper">';
        $has_scores = FALSE;

        foreach ($all_content_types as $content_type => $ct_label) {
          if (isset($score_matrix[$plugin_id][$content_type])) {
            $score_data = $score_matrix[$plugin_id][$content_type];
            $score_class = $this->getScoreClass($score_data['score_numeric']);
            $has_scores = TRUE;

            $plugin_content .= '<div class="score-item ' . $score_class . '">';
            $plugin_content .= '<span class="score-value">' . round($score_data['score_numeric'], 1) . '%</span>';
            $plugin_content .= '</div>';
          }
          else {
            $plugin_content .= '<div class="score-item">';
            $plugin_content .= '<span class="score-value">—</span>';
            $plugin_content .= '</div>';
          }
        }

        $plugin_content .= '</div>';

        // Output the merged cell.
        if ($has_scores) {
          $output .= '<td class="clickable-score-cell" data-plugin-id="' . htmlspecialchars($plugin_id) . '" data-node-id="' . $nid . '" colspan="' . count($all_content_types) . '">';
        }
        else {
          $output .= '<td class="score-cell" colspan="' . count($all_content_types) . '">';
        }
        $output .= $plugin_content;
        $output .= '</td>';

        $plugin_index++;
      }

      $output .= '</tr>';

      // Detail rows (hidden by default) - one per plugin.
      foreach ($all_plugins as $plugin_id => $plugin_label) {
        $total_score_columns = count($all_plugins) * count($all_content_types);
        $colspan = 3 + $total_score_columns;
        $output .= '<tr class="detail-row" data-node-id="' . $nid . '" data-plugin-id="' . htmlspecialchars($plugin_id) . '">';
        $output .= '<td colspan="' . $colspan . '">';
        $output .= $this->renderSinglePluginDetailView($assessment, $plugin_id, $plugin_label, $all_content_types);
        $output .= '</td>';
        $output .= '</tr>';
      }
    }

    $output .= '</tbody>';
    $output .= '</table>';

    return $output;
  }

  /**
   * Gets all unique plugins used across all assessments.
   *
   * @param array $assessment_data
   *   The assessment data.
   *
   * @return array
   *   Array of plugin labels keyed by plugin ID.
   */
  protected function getAllPluginsUsed(array $assessment_data): array {
    $plugins = [];

    foreach ($assessment_data as $data) {
      $assessment = $data['assessment'];
      if (!empty($assessment['assessments'])) {
        foreach ($assessment['assessments'] as $assess) {
          if (!empty($assess['plugin_id']) && !empty($assess['plugin_label'])) {
            $plugins[$assess['plugin_id']] = $assess['plugin_label'];
          }
        }
      }
    }

    return $plugins;
  }

  /**
   * Gets all unique content types used across all assessments.
   *
   * @param array $assessment_data
   *   The assessment data.
   *
   * @return array
   *   Array of content type labels keyed by content type.
   */
  protected function getAllContentTypesUsed(array $assessment_data): array {
    $content_types = [];

    foreach ($assessment_data as $data) {
      $assessment = $data['assessment'];
      if (!empty($assessment['assessments'])) {
        foreach ($assessment['assessments'] as $assess) {
          if (!empty($assess['content_type'])) {
            $type = $assess['content_type'];
            // Create a nice label for the content type.
            $content_types[$type] = ucfirst($type);
          }
        }
      }
    }

    // Sort by type (original first, then rewritten, then paragraph).
    $order = ['original' => 1, 'rewritten' => 2, 'paragraph' => 3];
    uksort($content_types, function ($a, $b) use ($order) {
      $order_a = $order[$a] ?? 99;
      $order_b = $order[$b] ?? 99;
      return $order_a <=> $order_b;
    });

    return $content_types;
  }

  /**
   * Builds a score matrix for easy lookup.
   *
   * @param array $assessments
   *   Array of assessments.
   * @param array $all_plugins
   *   All plugins used.
   * @param array $all_content_types
   *   All content types used.
   *
   * @return array
   *   Matrix indexed by [plugin_id][content_type] = score data.
   */
  protected function buildScoreMatrix(array $assessments, array $all_plugins, array $all_content_types): array {
    $matrix = [];

    foreach ($assessments as $assess) {
      $plugin_id = $assess['plugin_id'] ?? 'unknown';
      $content_type = $assess['content_type'] ?? 'original';

      if (!isset($matrix[$plugin_id])) {
        $matrix[$plugin_id] = [];
      }

      // Store the score for this plugin/content_type combination.
      if (!empty($assess['overall_score'])) {
        $matrix[$plugin_id][$content_type] = [
          'score' => $assess['overall_score'],
          'score_numeric' => $assess['overall_score_numeric'] ?? 0,
        ];
      }
    }

    return $matrix;
  }

  /**
   * Renders detail view for a single plugin.
   *
   * @param array $assessment
   *   The assessment data.
   * @param string $plugin_id
   *   The plugin ID.
   * @param string $plugin_label
   *   The plugin label.
   * @param array $all_content_types
   *   All content types.
   *
   * @return string
   *   Rendered HTML.
   */
  protected function renderSinglePluginDetailView(array $assessment, string $plugin_id, string $plugin_label, array $all_content_types): string {
    $output = '<div class="detail-content plugin-comparison-view">';
    $output .= '<h3>' . htmlspecialchars($plugin_label) . ' - Detailed Score Breakdown</h3>';

    if (empty($assessment['assessments'])) {
      $output .= '<p>' . $this->t('No assessment details available.') . '</p>';
      $output .= '</div>';
      return $output;
    }

    // Organize assessments by content type for this plugin.
    $plugin_assessments = [];
    foreach ($assessment['assessments'] as $assess) {
      if (($assess['plugin_id'] ?? '') === $plugin_id) {
        $content_type = $assess['content_type'] ?? 'original';
        $plugin_assessments[$content_type] = $assess;
      }
    }

    if (empty($plugin_assessments)) {
      $output .= '<p>' . $this->t('No assessment details available for this plugin.') . '</p>';
      $output .= '</div>';
      return $output;
    }

    // Special handling for factual accuracy comparison (side-by-side view).
    if ($plugin_id === 'factual_accuracy') {
      foreach ($plugin_assessments as $content_type => $assess) {
        if ($content_type === 'comparison' && !empty($assess['sections'])) {
          $output .= $this->formatFactualAccuracySections($assess['sections']);
          $output .= '</div>';
          return $output;
        }
      }
    }

    // Get all unique areas across all content types for this plugin.
    $all_areas = [];
    foreach ($plugin_assessments as $content_type => $assess) {
      if (!empty($assess['scores'])) {
        foreach (array_keys($assess['scores']) as $area) {
          $all_areas[$area] = TRUE;
        }
      }
    }

    if (empty($all_areas)) {
      $output .= '<p>' . $this->t('No detailed scores available.') . '</p>';
      $output .= '</div>';
      return $output;
    }

    // Create comparison table.
    $output .= '<table class="area-comparison-table">';
    $output .= '<thead><tr>';
    $output .= '<th>' . $this->t('Assessment Area') . '</th>';

    // Column for each content type that exists for this plugin.
    foreach ($all_content_types as $content_type => $ct_label) {
      if (isset($plugin_assessments[$content_type])) {
        $badge_class = 'badge-' . $content_type;
        $output .= '<th><span class="content-type-badge ' . $badge_class . '">' . htmlspecialchars($ct_label) . '</span></th>';
      }
    }

    $output .= '<th>' . $this->t('Change') . '</th>';
    $output .= '</tr></thead>';
    $output .= '<tbody>';

    // Row for each area.
    foreach (array_keys($all_areas) as $area) {
      $output .= '<tr>';
      $output .= '<td><strong>' . htmlspecialchars($area) . '</strong></td>';

      $scores_in_row = [];

      // Score for each content type.
      foreach ($all_content_types as $content_type => $ct_label) {
        if (isset($plugin_assessments[$content_type])) {
          $assess = $plugin_assessments[$content_type];
          if (isset($assess['scores'][$area])) {
            $score_data = $assess['scores'][$area];
            $score_numeric = $score_data['score_numeric'];
            $score_class = $this->getScoreClass($score_numeric);
            $scores_in_row[] = $score_numeric;

            $output .= '<td class="score-cell ' . $score_class . '">';
            $output .= round($score_numeric, 1) . '%';
            if (!empty($score_data['comments'])) {
              $output .= '<br><small class="score-comment">' . htmlspecialchars($score_data['comments']) . '</small>';
            }
            $output .= '</td>';
          }
          else {
            $output .= '<td class="score-cell">—</td>';
          }
        }
      }

      // Calculate change if we have original and rewritten scores.
      if (count($scores_in_row) >= 2) {
        $diff = $scores_in_row[1] - $scores_in_row[0];
        $diff_class = $diff > 0 ? 'score-good' : ($diff < 0 ? 'score-poor' : '');
        $diff_text = $diff > 0 ? '+' . round($diff, 1) : round($diff, 1);
        $highlight_class = abs($diff) > 5 ? 'comparison-highlight' : '';

        $output .= '<td class="score-cell ' . $diff_class . ' ' . $highlight_class . '">';
        $output .= $diff != 0 ? $diff_text . '%' : '—';
        $output .= '</td>';
      }
      else {
        $output .= '<td class="score-cell">—</td>';
      }

      $output .= '</tr>';
    }

    $output .= '</tbody>';
    $output .= '</table>';

    // Add detailed feedback sections if available.
    $has_feedback = FALSE;
    foreach ($plugin_assessments as $content_type => $assess) {
      if (!empty($assess['summary'])) {
        $has_feedback = TRUE;
        break;
      }
    }

    if ($has_feedback) {
      $output .= '<div class="detailed-feedback-section">';
      $output .= '<h4 class="feedback-toggle" style="cursor: pointer; margin-top: 20px; padding: 10px; background-color: #f5f5f5; border-radius: 4px;">';
      $output .= '<span class="toggle-icon">▶</span> ' . $this->t('Detailed Feedback & Analysis');
      $output .= '</h4>';
      $output .= '<div class="feedback-content" style="display: none; margin-top: 10px;">';

      foreach ($plugin_assessments as $content_type => $assess) {
        if (!empty($assess['summary'])) {
          $ct_label = $all_content_types[$content_type] ?? ucfirst($content_type);
          $badge_class = 'badge-' . $content_type;

          $output .= '<div class="feedback-item" style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 4px;">';
          $output .= '<h5><span class="content-type-badge ' . $badge_class . '">' . htmlspecialchars($ct_label) . '</span> Content</h5>';
          $output .= '<div class="assessment-summary" style="line-height: 1.6;">';
          $output .= $assess['summary'];
          $output .= '</div>';
          $output .= '</div>';
        }
      }

      $output .= '</div>'; // End feedback-content
      $output .= '</div>'; // End detailed-feedback-section
    }

    $output .= '</div>';

    return $output;
  }

  /**
   * Renders plugin detail view showing area-by-area scores.
   *
   * @param array $assessment
   *   The assessment data.
   * @param array $all_plugins
   *   All plugins.
   * @param array $all_content_types
   *   All content types.
   *
   * @return string
   *   Rendered HTML.
   */
  protected function renderPluginDetailView(array $assessment, array $all_plugins, array $all_content_types): string {
    $output = '<div class="detail-content plugin-comparison-view">';
    $output .= '<h3>Detailed Score Breakdown by Area</h3>';

    if (empty($assessment['assessments'])) {
      $output .= '<p>' . $this->t('No assessment details available.') . '</p>';
      $output .= '</div>';
      return $output;
    }

    // Organize assessments by plugin and content type for easy lookup.
    $organized = [];
    foreach ($assessment['assessments'] as $assess) {
      $plugin_id = $assess['plugin_id'] ?? 'unknown';
      $content_type = $assess['content_type'] ?? 'original';
      $organized[$plugin_id][$content_type] = $assess;
    }

    // Display each plugin's detailed scores.
    foreach ($all_plugins as $plugin_id => $plugin_label) {
      if (!isset($organized[$plugin_id])) {
        continue;
      }

      $output .= '<div class="plugin-detail-section">';
      $output .= '<h4>' . htmlspecialchars($plugin_label) . '</h4>';

      // Get all unique areas across all content types for this plugin.
      $all_areas = [];
      foreach ($organized[$plugin_id] as $content_type => $assess) {
        if (!empty($assess['scores'])) {
          foreach (array_keys($assess['scores']) as $area) {
            $all_areas[$area] = TRUE;
          }
        }
      }

      if (empty($all_areas)) {
        $output .= '<p>' . $this->t('No detailed scores available.') . '</p>';
        $output .= '</div>';
        continue;
      }

      // Create comparison table.
      $output .= '<table class="area-comparison-table">';
      $output .= '<thead><tr>';
      $output .= '<th>' . $this->t('Assessment Area') . '</th>';

      // Column for each content type.
      foreach ($all_content_types as $content_type => $ct_label) {
        if (isset($organized[$plugin_id][$content_type])) {
          $badge_class = 'badge-' . $content_type;
          $output .= '<th><span class="content-type-badge ' . $badge_class . '">' . htmlspecialchars($ct_label) . '</span></th>';
        }
      }

      $output .= '<th>' . $this->t('Change') . '</th>';
      $output .= '</tr></thead>';
      $output .= '<tbody>';

      // Row for each area.
      foreach (array_keys($all_areas) as $area) {
        $output .= '<tr>';
        $output .= '<td><strong>' . htmlspecialchars($area) . '</strong></td>';

        $scores_in_row = [];

        // Score for each content type.
        foreach ($all_content_types as $content_type => $ct_label) {
          if (isset($organized[$plugin_id][$content_type])) {
            $assess = $organized[$plugin_id][$content_type];
            if (isset($assess['scores'][$area])) {
              $score_data = $assess['scores'][$area];
              $score_numeric = $score_data['score_numeric'];
              $score_class = $this->getScoreClass($score_numeric);
              $scores_in_row[] = $score_numeric;

              $output .= '<td class="score-cell ' . $score_class . '">';
              $output .= round($score_numeric, 1) . '%';
              if (!empty($score_data['comments'])) {
                $output .= '<br><small class="score-comment">' . htmlspecialchars($score_data['comments']) . '</small>';
              }
              $output .= '</td>';
            }
            else {
              $output .= '<td class="score-cell">—</td>';
            }
          }
        }

        // Calculate change if we have original and rewritten scores.
        if (count($scores_in_row) >= 2) {
          $diff = $scores_in_row[1] - $scores_in_row[0];
          $diff_class = $diff > 0 ? 'score-good' : ($diff < 0 ? 'score-poor' : '');
          $diff_text = $diff > 0 ? '+' . round($diff, 1) : round($diff, 1);
          $highlight_class = abs($diff) > 5 ? 'comparison-highlight' : '';

          $output .= '<td class="score-cell ' . $diff_class . ' ' . $highlight_class . '">';
          $output .= $diff != 0 ? $diff_text . '%' : '—';
          $output .= '</td>';
        }
        else {
          $output .= '<td class="score-cell">—</td>';
        }

        $output .= '</tr>';
      }

      $output .= '</tbody>';
      $output .= '</table>';
      $output .= '</div>';
    }

    $output .= '</div>';
    return $output;
  }

  /**
   * Renders the detail view for a specific assessment.
   *
   * @param array $assessment
   *   The assessment data.
   *
   * @return string
   *   Rendered HTML.
   */
  protected function renderDetailView(array $assessment): string {
    $output = '<div class="detail-content">';

    if (empty($assessment['assessments'])) {
      $output .= '<p>' . $this->t('No assessment details available.') . '</p>';
      $output .= '</div>';
      return $output;
    }

    // Group assessments by content type for comparison.
    $grouped = [];
    foreach ($assessment['assessments'] as $assess) {
      $grouped[$assess['content_type']][] = $assess;
    }

    // Display each group.
    foreach ($grouped as $content_type => $assessments) {
      $output .= '<h4>' . ucfirst($content_type) . ' Content Assessment' . (count($assessments) > 1 ? 's' : '') . '</h4>';

      foreach ($assessments as $assess) {
        $output .= '<div class="assessment-detail">';
        $output .= '<h5>' . htmlspecialchars($assess['content_label']) . '</h5>';

        if (!empty($assess['plugin_label'])) {
          $output .= '<p><strong>Plugin:</strong> ' . htmlspecialchars($assess['plugin_label']) . '</p>';
        }

        if (!empty($assess['overall_score'])) {
          $score_class = $this->getScoreClass($assess['overall_score_numeric']);
          $output .= '<p><strong>Overall Score:</strong> <span class="' . $score_class . '">' . htmlspecialchars($assess['overall_score']) . ' (' . $assess['overall_score_numeric'] . '%)</span></p>';
        }

        // Detailed scores table.
        if (!empty($assess['scores'])) {
          $output .= '<div class="detail-scores">';
          $output .= '<h6>Detailed Scores by Area</h6>';
          $output .= '<table>';
          $output .= '<thead><tr><th>Area</th><th>Score</th><th>Comments</th></tr></thead>';
          $output .= '<tbody>';

          foreach ($assess['scores'] as $area => $score_data) {
            $score_class = $this->getScoreClass($score_data['score_numeric']);
            $output .= '<tr>';
            $output .= '<td><strong>' . htmlspecialchars($area) . '</strong></td>';
            $output .= '<td class="' . $score_class . '">' . htmlspecialchars($score_data['score']) . ' (' . $score_data['score_numeric'] . '%)</td>';
            $output .= '<td>' . htmlspecialchars($score_data['comments']) . '</td>';
            $output .= '</tr>';
          }

          $output .= '</tbody>';
          $output .= '</table>';
          $output .= '</div>';
        }

        // Summary.
        if (!empty($assess['summary'])) {
          $output .= '<div class="assessment-summary">';
          $output .= '<h6>Analysis Summary</h6>';
          $output .= '<div>' . $assess['summary'] . '</div>';
          $output .= '</div>';
        }

        $output .= '</div><hr>';
      }
    }

    // Comparison section if both original and rewritten exist.
    if (isset($grouped['original']) && isset($grouped['rewritten'])) {
      $output .= $this->renderComparison($grouped['original'][0], $grouped['rewritten'][0]);
    }

    $output .= '</div>';
    return $output;
  }

  /**
   * Renders a comparison between original and rewritten content.
   *
   * @param array $original
   *   Original assessment.
   * @param array $rewritten
   *   Rewritten assessment.
   *
   * @return string
   *   Rendered HTML.
   */
  protected function renderComparison(array $original, array $rewritten): string {
    $output = '<div class="comparison-section">';
    $output .= '<h4>Original vs Rewritten Comparison</h4>';

    // Overall score comparison.
    if (!empty($original['overall_score_numeric']) && !empty($rewritten['overall_score_numeric'])) {
      $diff = $rewritten['overall_score_numeric'] - $original['overall_score_numeric'];
      $diff_text = $diff > 0 ? '+' . round($diff, 1) : round($diff, 1);
      $diff_class = $diff > 0 ? 'score-good' : ($diff < 0 ? 'score-poor' : '');

      $output .= '<p><strong>Overall Score Change:</strong> ';
      $output .= htmlspecialchars($original['overall_score']) . ' → ' . htmlspecialchars($rewritten['overall_score']);
      $output .= ' <span class="' . $diff_class . '">(' . $diff_text . '%)</span></p>';
    }

    // Area-by-area comparison.
    if (!empty($original['scores']) && !empty($rewritten['scores'])) {
      $output .= '<div class="detail-scores">';
      $output .= '<h6>Score Changes by Area</h6>';
      $output .= '<table>';
      $output .= '<thead><tr><th>Area</th><th>Original</th><th>Rewritten</th><th>Change</th></tr></thead>';
      $output .= '<tbody>';

      $all_areas = array_unique(array_merge(array_keys($original['scores']), array_keys($rewritten['scores'])));

      foreach ($all_areas as $area) {
        $orig_score = $original['scores'][$area]['score_numeric'] ?? 0;
        $rewrite_score = $rewritten['scores'][$area]['score_numeric'] ?? 0;
        $diff = $rewrite_score - $orig_score;
        $diff_text = $diff > 0 ? '+' . round($diff, 1) : round($diff, 1);
        $diff_class = $diff > 0 ? 'score-good' : ($diff < 0 ? 'score-poor' : '');

        $highlight_class = abs($diff) > 5 ? 'comparison-highlight' : '';

        $output .= '<tr class="' . $highlight_class . '">';
        $output .= '<td><strong>' . htmlspecialchars($area) . '</strong></td>';
        $output .= '<td>' . ($orig_score > 0 ? $orig_score . '%' : 'N/A') . '</td>';
        $output .= '<td>' . ($rewrite_score > 0 ? $rewrite_score . '%' : 'N/A') . '</td>';
        $output .= '<td class="' . $diff_class . '">' . ($diff != 0 ? $diff_text . '%' : '—') . '</td>';
        $output .= '</tr>';
      }

      $output .= '</tbody>';
      $output .= '</table>';
      $output .= '</div>';
    }

    $output .= '</div>';
    return $output;
  }

  /**
   * Gets the CSS class for a score.
   *
   * @param float $score
   *   The numeric score (0-100).
   *
   * @return string
   *   The CSS class.
   */
  protected function getScoreClass(float $score): string {
    if ($score >= 80) {
      return 'score-excellent';
    }
    elseif ($score >= 60) {
      return 'score-good';
    }
    elseif ($score >= 40) {
      return 'score-fair';
    }
    else {
      return 'score-poor';
    }
  }

  /**
   * Formats section-based analysis with side-by-side comparison for factual accuracy.
   *
   * @param array $sections
   *   The sections array from factual accuracy analysis.
   *
   * @return string
   *   Formatted HTML with three-column layout.
   */
  protected function formatFactualAccuracySections(array $sections): string {
    $output = '<div class="quality-sections">';
    $output .= '<h4>' . $this->t('Section-by-Section Before/After Comparison:') . '</h4>';

    foreach ($sections as $section) {
      $score_class = $this->getScoreClass($section['accuracy_score_numeric'] ?? 0);

      // Section container.
      $output .= '<div class="section-comparison" style="margin-bottom: 30px; border: 1px solid #ddd; border-radius: 5px; overflow: hidden;">';

      // Section header with score.
      $output .= '<div style="background-color: #f5f5f5; padding: 10px 15px; border-bottom: 2px solid #ddd;">';
      $output .= '<strong style="font-size: 1.1em;">Section ' . htmlspecialchars($section['number']) . ':</strong> ';
      $output .= '<span>' . htmlspecialchars($section['description']) . '</span>';
      $output .= '<span style="float: right;">';
      $output .= '<span style="font-weight: bold; margin-right: 5px;">Accuracy:</span>';
      $output .= '<span class="' . $score_class . '" style="font-weight: bold; font-size: 1.1em;">' . htmlspecialchars($section['accuracy_score']) . '</span>';
      $output .= '</span>';
      $output .= '</div>';

      // Use table for three-column layout (more reliable than CSS Grid in Drupal).
      $output .= '<table style="width: 100%; border-collapse: collapse; table-layout: fixed;">';
      $output .= '<thead>';
      $output .= '<tr>';
      $output .= '<th style="width: 33.33%; padding: 10px; background-color: #fffbf0; border-right: 1px solid #ddd; border-bottom: 2px solid #ddd; color: #856404; font-size: 0.9em; text-transform: uppercase; text-align: left;">Original Field</th>';
      $output .= '<th style="width: 33.33%; padding: 10px; background-color: #f0f8ff; border-right: 1px solid #ddd; border-bottom: 2px solid #ddd; color: #0056b3; font-size: 0.9em; text-transform: uppercase; text-align: left;">New Field</th>';
      $output .= '<th style="width: 33.33%; padding: 10px; background-color: #f9f9f9; border-bottom: 2px solid #ddd; color: #555; font-size: 0.9em; text-transform: uppercase; text-align: left;">Differences</th>';
      $output .= '</tr>';
      $output .= '</thead>';
      $output .= '<tbody>';
      $output .= '<tr>';

      // Column 1: Original Text.
      $output .= '<td style="padding: 15px; background-color: #fffbf0; border-right: 1px solid #ddd; vertical-align: top;">';
      $output .= '<div style="font-size: 0.95em; line-height: 1.5; color: #333;">';
      if (!empty($section['original_text'])) {
        $output .= nl2br(htmlspecialchars($section['original_text']));
      }
      else {
        $output .= '<em style="color: #999;">No text extracted</em>';
      }
      $output .= '</div>';
      $output .= '</td>';

      // Column 2: New Text.
      $output .= '<td style="padding: 15px; background-color: #f0f8ff; border-right: 1px solid #ddd; vertical-align: top;">';
      $output .= '<div style="font-size: 0.95em; line-height: 1.5; color: #333;">';
      if (!empty($section['new_text'])) {
        $output .= nl2br(htmlspecialchars($section['new_text']));
      }
      else {
        $output .= '<em style="color: #999;">No text extracted</em>';
      }
      $output .= '</div>';
      $output .= '</td>';

      // Column 3: Differences.
      $output .= '<td style="padding: 15px; background-color: #f9f9f9; vertical-align: top;">';

      if (!empty($section['differences'])) {
        $output .= '<ul style="margin: 0; padding-left: 20px; font-size: 0.9em; list-style-type: none;">';

        foreach ($section['differences'] as $diff) {
          if ($diff['type'] === 'NONE') {
            $output .= '<li style="color: #28a745; margin-bottom: 8px;">';
            $output .= '✓ <em>' . htmlspecialchars($diff['description']) . '</em>';
            $output .= '</li>';
          }
          else {
            $badge_style = 'display: inline-block; padding: 3px 8px; border-radius: 3px; font-size: 0.75em; font-weight: bold; margin-right: 6px; text-transform: uppercase; white-space: nowrap;';
            $badge_color = match($diff['type']) {
              'NEW' => 'background-color: #007bff; color: #fff;',
              'MISSING' => 'background-color: #ffc107; color: #856404;',
              'CHANGED' => 'background-color: #17a2b8; color: #fff;',
              'INCORRECT' => 'background-color: #dc3545; color: #fff;',
              default => 'background-color: #6c757d; color: #fff;',
            };

            $output .= '<li style="margin-bottom: 10px; line-height: 1.6;">';
            $output .= '<div><span style="' . $badge_style . $badge_color . '">' . htmlspecialchars($diff['type']) . '</span></div>';
            $output .= '<div style="margin-top: 4px; color: #333;">' . htmlspecialchars($diff['description']) . '</div>';
            $output .= '</li>';
          }
        }

        $output .= '</ul>';
      }
      else {
        $output .= '<p style="color: #999; font-style: italic; font-size: 0.9em; margin: 0;">No differences noted</p>';
      }

      $output .= '</td>';

      $output .= '</tr>';
      $output .= '</tbody>';
      $output .= '</table>';
      $output .= '</div>'; // End section-comparison
    }

    $output .= '</div>'; // End quality-sections

    return $output;
  }

}
