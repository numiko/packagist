<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form\Builder;

use Drupal\Core\Form\FormStateInterface;

/**
 * Form builder for URL-based content imports.
 *
 * Builds the form section for importing content from URLs.
 */
class UrlImportFormBuilder extends ImportFormBuilderBase {

  /**
   * {@inheritdoc}
   */
  public function getId(): string {
    return 'url';
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return (string) $this->t('URL Import');
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, array $options = []): array {
    $extractionProfiles = $options['extraction_profiles'] ?? [];

    $form['url_import'] = [
      '#type' => 'details',
      '#title' => $this->t('URL Import Options'),
      '#open' => TRUE,
    ];

    $form['url_import']['urls'] = [
      '#type' => 'textarea',
      '#title' => $this->t('URLs'),
      '#description' => $this->t('Enter one URL per line. Content will be imported from each URL.'),
      '#rows' => 5,
    ];

    $form['url_import']['extraction_mode'] = $this->buildExtractionModeElement();

    $form['url_import']['extraction_profile'] = $this->buildExtractionProfileElement($extractionProfiles);

    $form['url_import']['content_selector'] = $this->buildContentSelectorElement();

    $form['url_import']['tags_to_remove'] = $this->buildTagsToRemoveElement();

    $form['url_import']['create_redirects'] = $this->buildCreateRedirectsElement();

    // Merge options.
    $form['url_import']['merge_options'] = [
      '#type' => 'details',
      '#title' => $this->t('Merge Options'),
      '#description' => $this->t('Options for merging multiple URLs into a single page.'),
      '#open' => FALSE,
    ];

    $form['url_import']['merge_options']['merge_urls'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Merge all URLs into a single page'),
      '#description' => $this->t('If enabled, content from all URLs will be combined into a single node.'),
      '#default_value' => FALSE,
    ];

    $form['url_import']['merge_options']['merged_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Merged Page Title'),
      '#description' => $this->t('Title for the merged page. If empty, the first URL\'s title will be used.'),
      '#states' => [
        'visible' => [
          ':input[name="merge_urls"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['url_import']['merge_options']['content_separator'] = [
      '#type' => 'select',
      '#title' => $this->t('Content Separator'),
      '#options' => [
        'headers' => $this->t('Use Headers (H2 tags)'),
        'dividers' => $this->t('Use Dividers (HR tags)'),
        'none' => $this->t('No Separator'),
      ],
      '#default_value' => 'headers',
      '#states' => [
        'visible' => [
          ':input[name="merge_urls"]' => ['checked' => TRUE],
        ],
      ],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $importType = $form_state->getValue('import_type');

    if ($importType !== 'url') {
      return;
    }

    $urls = $form_state->getValue('urls');
    if (empty($urls)) {
      $form_state->setErrorByName('urls', $this->t('Please enter at least one URL.'));
      return;
    }

    // Validate each URL.
    $urlList = array_filter(array_map('trim', explode("\n", $urls)));
    foreach ($urlList as $url) {
      if (!filter_var($url, FILTER_VALIDATE_URL)) {
        $form_state->setErrorByName('urls', $this->t('Invalid URL: @url', ['@url' => $url]));
      }
    }
  }

}
