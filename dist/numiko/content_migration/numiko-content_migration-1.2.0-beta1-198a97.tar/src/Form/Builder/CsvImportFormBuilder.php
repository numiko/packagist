<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form\Builder;

use Drupal\Core\Form\FormStateInterface;

/**
 * Form builder for CSV-based content imports.
 *
 * Builds the form section for importing hierarchical content from CSV files.
 */
class CsvImportFormBuilder extends ImportFormBuilderBase {

  /**
   * {@inheritdoc}
   */
  public function getId(): string {
    return 'csv';
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return (string) $this->t('CSV Import');
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, array $options = []): array {
    $extractionProfiles = $options['extraction_profiles'] ?? [];

    $form['csv_import'] = [
      '#type' => 'details',
      '#title' => $this->t('CSV Import Options'),
      '#open' => TRUE,
    ];

    $form['csv_import']['csv_file'] = [
      '#type' => 'managed_file',
      '#title' => $this->t('CSV/TSV File'),
      '#description' => $this->t('Upload a CSV or TSV file with columns: page_title, content_type, parent_page_title (optional), source_url (optional).'),
      '#upload_location' => 'private://content_migration/csv',
      '#upload_validators' => [
        'file_validate_extensions' => ['csv tsv txt'],
        'file_validate_size' => [10 * 1024 * 1024],
      ],
      '#required' => FALSE,
    ];

    $form['csv_import']['csv_format_info'] = [
      '#type' => 'details',
      '#title' => $this->t('CSV Format Help'),
      '#open' => FALSE,
    ];

    $form['csv_import']['csv_format_info']['help'] = [
      '#type' => 'markup',
      '#markup' => '<p>' . $this->t('The CSV file should have the following columns:') . '</p>' .
        '<ul>' .
        '<li><strong>page_title</strong>: ' . $this->t('The title for the page (required)') . '</li>' .
        '<li><strong>content_type</strong>: ' . $this->t('The content type machine name (required)') . '</li>' .
        '<li><strong>parent_page_title</strong>: ' . $this->t('Title of the parent page for hierarchy (optional)') . '</li>' .
        '<li><strong>source_url</strong>: ' . $this->t('URL to fetch content from (optional)') . '</li>' .
        '</ul>' .
        '<p>' . $this->t('Note: Parent pages must appear before their children in the CSV.') . '</p>',
    ];

    $form['csv_import']['csv_extraction_mode'] = $this->buildExtractionModeElement();

    $form['csv_import']['csv_extraction_profile'] = $this->buildExtractionProfileElement($extractionProfiles);

    $form['csv_import']['csv_content_selector'] = $this->buildContentSelectorElement();

    $form['csv_import']['csv_tags_to_remove'] = $this->buildTagsToRemoveElement();

    $form['csv_import']['csv_create_redirects'] = $this->buildCreateRedirectsElement();

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $importType = $form_state->getValue('import_type');

    if ($importType !== 'csv') {
      return;
    }

    $csvFile = $form_state->getValue('csv_file');
    if (empty($csvFile)) {
      $form_state->setErrorByName('csv_file', $this->t('Please upload a CSV file.'));
    }
  }

  /**
   * Parses and validates a CSV row.
   *
   * @param array $row
   *   The CSV row data.
   * @param array $header
   *   The CSV header row.
   *
   * @return array|null
   *   The parsed row as an associative array, or NULL if invalid.
   */
  public function parseRow(array $row, array $header): ?array {
    if (count($row) !== count($header)) {
      return NULL;
    }

    $data = array_combine($header, $row);

    // Validate required fields.
    if (empty($data['page_title']) || empty($data['content_type'])) {
      return NULL;
    }

    return $data;
  }

}
