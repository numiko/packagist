<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form\Builder;

use Drupal\Core\Form\FormStateInterface;

/**
 * Form builder for PDF-based content imports.
 *
 * Builds the form section for importing content from PDF files.
 */
class PdfImportFormBuilder extends ImportFormBuilderBase {

  /**
   * {@inheritdoc}
   */
  public function getId(): string {
    return 'pdf';
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return (string) $this->t('PDF Import');
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, array $options = []): array {
    $form['pdf_import'] = [
      '#type' => 'details',
      '#title' => $this->t('PDF Import Options'),
      '#open' => TRUE,
    ];

    $form['pdf_import']['pdf_file'] = [
      '#type' => 'managed_file',
      '#title' => $this->t('PDF File'),
      '#description' => $this->t('Upload a PDF file to extract content from. The content will be extracted using Claude AI.'),
      '#upload_location' => 'private://content_migration/pdfs',
      '#upload_validators' => [
        'file_validate_extensions' => ['pdf'],
        'file_validate_size' => [50 * 1024 * 1024],
      ],
      '#required' => FALSE,
    ];

    $form['pdf_import']['pdf_info'] = [
      '#type' => 'markup',
      '#markup' => '<p class="description">' . $this->t('PDF content will be extracted using Claude AI. This requires a valid Claude API key configured in the module settings.') . '</p>',
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $importType = $form_state->getValue('import_type');

    if ($importType !== 'pdf') {
      return;
    }

    $pdfFile = $form_state->getValue('pdf_file');
    if (empty($pdfFile)) {
      $form_state->setErrorByName('pdf_file', $this->t('Please upload a PDF file.'));
    }
  }

}
