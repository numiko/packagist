<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form\Builder;

use Drupal\Core\Form\FormStateInterface;

/**
 * Form builder for title-based page creation.
 *
 * Builds the form section for creating empty pages from titles.
 */
class TitleImportFormBuilder extends ImportFormBuilderBase {

  /**
   * {@inheritdoc}
   */
  public function getId(): string {
    return 'title';
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return (string) $this->t('Title Import');
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, array $options = []): array {
    $form['title_import'] = [
      '#type' => 'details',
      '#title' => $this->t('Title Import Options'),
      '#open' => TRUE,
    ];

    $form['title_import']['titles'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Page Titles'),
      '#description' => $this->t('Enter one title per line. Empty pages will be created with these titles.'),
      '#rows' => 5,
    ];

    $form['title_import']['title_info'] = [
      '#type' => 'markup',
      '#markup' => '<p class="description">' . $this->t('This creates placeholder pages with only titles. Useful for building site structure before content is ready.') . '</p>',
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $importType = $form_state->getValue('import_type');

    if ($importType !== 'title') {
      return;
    }

    $titles = $form_state->getValue('titles');
    if (empty($titles)) {
      $form_state->setErrorByName('titles', $this->t('Please enter at least one title.'));
    }
  }

}
