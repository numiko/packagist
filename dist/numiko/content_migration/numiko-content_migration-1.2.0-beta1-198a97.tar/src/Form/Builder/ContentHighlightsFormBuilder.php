<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form\Builder;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Form builder for content highlights section of the settings form.
 */
class ContentHighlightsFormBuilder {

  use StringTranslationTrait;

  /**
   * Color options for highlight rules.
   *
   * @var array
   */
  protected const COLOR_OPTIONS = [
    '' => '- Select color -',
    '#ffff00' => 'Yellow',
    '#90EE90' => 'Light Green',
    '#ADD8E6' => 'Light Blue',
    '#FFB6C1' => 'Light Pink',
    '#FFA500' => 'Orange',
    '#E6E6FA' => 'Lavender',
    '#F0E68C' => 'Khaki',
    '#98FB98' => 'Pale Green',
    '#DDA0DD' => 'Plum',
    '#F5DEB3' => 'Wheat',
  ];

  /**
   * Constructs a ContentHighlightsFormBuilder object.
   *
   * @param \Drupal\Core\StringTranslation\TranslationInterface $stringTranslation
   *   The string translation service.
   */
  public function __construct(
    TranslationInterface $stringTranslation,
  ) {
    $this->setStringTranslation($stringTranslation);
  }

  /**
   * Build the content highlights form section.
   *
   * @param array $form
   *   The form array to add the section to.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param mixed $config
   *   The configuration object.
   */
  public function buildForm(array &$form, FormStateInterface $form_state, $config): void {
    $is_ajax = $form_state->getTriggeringElement() !== NULL;

    $form['content_highlights_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Content Highlights'),
      '#open' => $is_ajax,
      '#description' => $this->t('Define CSS selectors to highlight within extracted paragraph content. Matching elements will have a colored background applied.'),
      '#prefix' => '<div id="content-highlights-wrapper">',
      '#suffix' => '</div>',
      '#tree' => TRUE,
    ];

    $highlights = $this->getHighlightsFromState($form_state, $config);
    $form_state->set('content_highlights', $highlights);

    // Sort by weight.
    usort($highlights, fn($a, $b) => ($a['weight'] ?? 0) <=> ($b['weight'] ?? 0));

    $color_options = $this->getTranslatedColorOptions();

    if (empty($highlights)) {
      $form['content_highlights_settings']['no_highlights'] = [
        '#markup' => '<p>' . $this->t('No highlight rules configured yet. Click "Add Highlight Rule" to create one.') . '</p>',
      ];
    }
    else {
      $form['content_highlights_settings']['highlights'] = [
        '#type' => 'table',
        '#header' => [
          $this->t('Order'),
          $this->t('CSS Selector'),
          $this->t('Highlight Color'),
          $this->t('Preview'),
          $this->t('Weight'),
          $this->t('Operations'),
        ],
        '#empty' => $this->t('No highlight rules yet.'),
        '#tableselect' => FALSE,
        '#tabledrag' => [
          [
            'action' => 'order',
            'relationship' => 'sibling',
            'group' => 'highlight-weight',
          ],
        ],
        '#tree' => TRUE,
      ];

      foreach ($highlights as $index => $highlight) {
        $this->buildHighlightRow($form, $index, $highlight, $color_options);
      }
    }

    $form['content_highlights_settings']['add_highlight'] = [
      '#type' => 'submit',
      '#value' => $this->t('Add Highlight Rule'),
      '#submit' => ['::addHighlightSubmit'],
      '#ajax' => [
        'callback' => '::updateContentHighlights',
        'wrapper' => 'content-highlights-wrapper',
      ],
      '#limit_validation_errors' => [],
    ];
  }

  /**
   * Build a single highlight row.
   *
   * @param array $form
   *   The form array.
   * @param int $index
   *   The row index.
   * @param array $highlight
   *   The highlight data.
   * @param array $color_options
   *   The color options.
   */
  protected function buildHighlightRow(array &$form, int $index, array $highlight, array $color_options): void {
    $weight = $highlight['weight'] ?? $index;
    $color = $highlight['color'] ?? '';

    $form['content_highlights_settings']['highlights'][$index] = [
      '#attributes' => ['class' => ['draggable']],
      '#weight' => $weight,
    ];

    $form['content_highlights_settings']['highlights'][$index]['drag'] = [
      '#plain_text' => '',
    ];

    $form['content_highlights_settings']['highlights'][$index]['selector'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Selector'),
      '#title_display' => 'invisible',
      '#default_value' => $highlight['selector'] ?? '',
      '#placeholder' => $this->t('e.g., .snippet, .highlight, .important'),
      '#size' => 30,
    ];

    $form['content_highlights_settings']['highlights'][$index]['color'] = [
      '#type' => 'select',
      '#title' => $this->t('Color'),
      '#title_display' => 'invisible',
      '#options' => $color_options,
      '#default_value' => $color,
    ];

    $form['content_highlights_settings']['highlights'][$index]['preview'] = [
      '#markup' => '<span style="background-color: ' . ($color ?: '#ffffff') . '; padding: 2px 8px; border: 1px solid #ccc;">' . $this->t('Sample') . '</span>',
    ];

    $form['content_highlights_settings']['highlights'][$index]['weight'] = [
      '#type' => 'weight',
      '#title' => $this->t('Weight'),
      '#title_display' => 'invisible',
      '#default_value' => $weight,
      '#delta' => 50,
      '#attributes' => ['class' => ['highlight-weight']],
    ];

    $form['content_highlights_settings']['highlights'][$index]['remove'] = [
      '#type' => 'submit',
      '#value' => $this->t('Remove'),
      '#name' => 'remove_highlight_' . $index,
      '#submit' => ['::removeHighlightSubmit'],
      '#ajax' => [
        'callback' => '::updateContentHighlights',
        'wrapper' => 'content-highlights-wrapper',
      ],
      '#limit_validation_errors' => [],
    ];
  }

  /**
   * Get highlights from form state or config.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param mixed $config
   *   The configuration object.
   *
   * @return array
   *   The highlights array.
   */
  public function getHighlightsFromState(FormStateInterface $form_state, $config): array {
    $highlights = $form_state->get('content_highlights');
    if ($highlights === NULL) {
      $highlights = $config->get('content_highlights') ?: [];
      $form_state->set('content_highlights', $highlights);
    }
    return $highlights;
  }

  /**
   * Process content highlights from form submission.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   Processed content highlights.
   */
  public function processHighlights(FormStateInterface $form_state): array {
    $all_values = $form_state->getValues();
    $form_highlights = $all_values['content_highlights_settings']['highlights'] ?? [];

    $highlights = [];
    foreach ($form_highlights as $key => $highlight) {
      if (is_numeric($key) && !empty($highlight['selector']) && !empty($highlight['color'])) {
        $highlights[] = [
          'selector' => $highlight['selector'],
          'color' => $highlight['color'],
          'weight' => $highlight['weight'] ?? 0,
        ];
      }
    }

    usort($highlights, fn($a, $b) => ($a['weight'] ?? 0) <=> ($b['weight'] ?? 0));

    return $highlights;
  }

  /**
   * Add a highlight rule.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function addHighlight(FormStateInterface $form_state): void {
    $highlights = $form_state->get('content_highlights') ?: [];
    $this->updateHighlightsFromFormState($highlights, $form_state);

    $max_weight = 0;
    foreach ($highlights as $highlight) {
      $max_weight = max($max_weight, ($highlight['weight'] ?? 0) + 1);
    }

    $highlights[] = [
      'selector' => '',
      'color' => '#ffff00',
      'weight' => $max_weight,
    ];

    $form_state->set('content_highlights', $highlights);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Remove a highlight rule.
   *
   * @param int $index
   *   The highlight index to remove.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function removeHighlight(int $index, FormStateInterface $form_state): void {
    $highlights = $form_state->get('content_highlights') ?: [];
    $this->updateHighlightsFromFormState($highlights, $form_state);

    if (isset($highlights[$index])) {
      unset($highlights[$index]);
      $highlights = array_values($highlights);
    }

    $form_state->set('content_highlights', $highlights);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Update highlights array from form state values.
   *
   * @param array $highlights
   *   The highlights array to update.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function updateHighlightsFromFormState(array &$highlights, FormStateInterface $form_state): void {
    $all_values = $form_state->getValues();
    $form_highlights = $all_values['content_highlights_settings']['highlights'] ?? [];

    $new_highlights = [];
    foreach ($form_highlights as $key => $highlight) {
      if (is_numeric($key)) {
        $new_highlights[] = [
          'selector' => $highlight['selector'] ?? '',
          'color' => $highlight['color'] ?? '',
          'weight' => $highlight['weight'] ?? 0,
        ];
      }
    }

    if (!empty($new_highlights)) {
      $highlights = $new_highlights;
    }
  }

  /**
   * Get translated color options.
   *
   * @return array
   *   The translated color options.
   */
  protected function getTranslatedColorOptions(): array {
    $options = [];
    foreach (self::COLOR_OPTIONS as $value => $label) {
      $options[$value] = $this->t($label);
    }
    return $options;
  }

}
