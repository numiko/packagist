<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form\Builder;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Form builder for extraction profiles section of the settings form.
 */
class ExtractionProfilesFormBuilder {

  use StringTranslationTrait;

  /**
   * Constructs an ExtractionProfilesFormBuilder object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\StringTranslation\TranslationInterface $stringTranslation
   *   The string translation service.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    TranslationInterface $stringTranslation,
  ) {
    $this->setStringTranslation($stringTranslation);
  }

  /**
   * Build the extraction profiles form section.
   *
   * @param array $form
   *   The form array to add the section to.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param mixed $config
   *   The configuration object.
   * @param array $allowed_content_types
   *   The list of allowed content type IDs.
   * @param array $content_type_options
   *   The content type options for select fields.
   */
  public function buildForm(array &$form, FormStateInterface $form_state, $config, array $allowed_content_types, array $content_type_options): void {
    $is_ajax = $form_state->getTriggeringElement() !== NULL;

    $form['extraction_profiles_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Extraction Profiles'),
      '#open' => $is_ajax,
      '#description' => $this->t('Define extraction profiles that map CSS selectors to paragraph types. When a profile is selected during import, content matching each selector will be extracted and placed into the corresponding paragraph type.'),
      '#prefix' => '<div id="extraction-profiles-wrapper">',
      '#suffix' => '</div>',
      '#tree' => TRUE,
    ];

    $profiles = $this->getProfilesFromState($form_state, $config);
    $form_state->set('extraction_profiles', $profiles);

    // Store profile IDs in a hidden field for persistence across non-AJAX submits.
    $form['extraction_profiles_settings']['profile_ids'] = [
      '#type' => 'hidden',
      '#value' => implode(',', array_keys($profiles)),
    ];

    $paragraph_type_options = $this->getParagraphTypeOptions();
    $filtered_content_type_options = array_intersect_key($content_type_options, array_flip($allowed_content_types));

    if (empty($profiles)) {
      $form['extraction_profiles_settings']['no_profiles'] = [
        '#markup' => '<p>' . $this->t('No extraction profiles configured yet. Click "Add Profile" to create one.') . '</p>',
      ];
    }
    else {
      $form['extraction_profiles_settings']['profiles'] = [
        '#type' => 'container',
        '#tree' => TRUE,
      ];

      foreach ($profiles as $profile_id => $profile) {
        $this->buildProfileSection($form, $form_state, $profile_id, $profile, $filtered_content_type_options, $paragraph_type_options);
      }
    }

    $form['extraction_profiles_settings']['add_profile'] = [
      '#type' => 'submit',
      '#value' => $this->t('Add Profile'),
      '#submit' => ['::addProfileSubmit'],
      '#ajax' => [
        'callback' => '::updateExtractionProfiles',
        'wrapper' => 'extraction-profiles-wrapper',
      ],
      '#limit_validation_errors' => [],
    ];
  }

  /**
   * Build a single profile section.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param string $profile_id
   *   The profile ID.
   * @param array $profile
   *   The profile data.
   * @param array $content_type_options
   *   The content type options.
   * @param array $paragraph_type_options
   *   The paragraph type options.
   */
  protected function buildProfileSection(array &$form, FormStateInterface $form_state, string $profile_id, array $profile, array $content_type_options, array $paragraph_type_options): void {
    $form['extraction_profiles_settings']['profiles'][$profile_id] = [
      '#type' => 'details',
      '#title' => $profile['label'] ?? $this->t('Profile @id', ['@id' => $profile_id]),
      '#open' => TRUE,
      '#tree' => TRUE,
    ];

    $form['extraction_profiles_settings']['profiles'][$profile_id]['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Profile Name'),
      '#default_value' => $profile['label'] ?? '',
      '#required' => TRUE,
    ];

    $form['extraction_profiles_settings']['profiles'][$profile_id]['content_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Content Type'),
      '#options' => ['' => $this->t('- Select -')] + $content_type_options,
      '#default_value' => $profile['content_type'] ?? '',
      '#required' => TRUE,
      '#description' => $this->t('Select the content type this profile is associated with.'),
      '#ajax' => [
        'callback' => '::updateExtractionProfiles',
        'wrapper' => 'extraction-profiles-wrapper',
      ],
    ];

    $profile_content_type = $this->getProfileContentType($form_state, $profile_id, $profile);
    $target_field_options = $this->getTargetFieldOptions($profile_content_type);

    $form['extraction_profiles_settings']['profiles'][$profile_id]['mappings_header'] = [
      '#markup' => '<h4>' . $this->t('Selector Mappings') . '</h4><p>' . $this->t('Define mappings between CSS selectors and target fields. Drag to reorder. Content matching each selector will be extracted in order and placed into the corresponding field.') . '</p>',
    ];

    $mappings = $this->prepareMappings($profile['mappings'] ?? []);

    $form['extraction_profiles_settings']['profiles'][$profile_id]['mappings'] = [
      '#type' => 'table',
      '#header' => [
        '',
        $this->t('CSS/HTML Selector'),
        $this->t('Target Field'),
        $this->t('Paragraph Type'),
        $this->t('Operations'),
      ],
      '#empty' => $this->t('No mappings yet. Add one below.'),
      '#tableselect' => FALSE,
      '#tabledrag' => [
        [
          'action' => 'order',
          'relationship' => 'sibling',
          'group' => 'mapping-weight-' . $profile_id,
        ],
      ],
      '#tree' => TRUE,
      '#prefix' => '<div id="profile-' . $profile_id . '-mappings-wrapper">',
      '#suffix' => '</div>',
    ];

    foreach ($mappings as $mapping_index => $mapping) {
      $this->buildMappingRow($form, $form_state, $profile_id, $mapping_index, $mapping, $target_field_options, $paragraph_type_options);
    }

    $form['extraction_profiles_settings']['profiles'][$profile_id]['add_mapping'] = [
      '#type' => 'submit',
      '#value' => $this->t('Add Mapping'),
      '#name' => 'add_mapping_' . $profile_id,
      '#submit' => ['::addMappingSubmit'],
      '#ajax' => [
        'callback' => '::updateExtractionProfiles',
        'wrapper' => 'extraction-profiles-wrapper',
      ],
      '#limit_validation_errors' => [],
    ];

    $form['extraction_profiles_settings']['profiles'][$profile_id]['remove_profile'] = [
      '#type' => 'submit',
      '#value' => $this->t('Remove Profile'),
      '#name' => 'remove_profile_' . $profile_id,
      '#submit' => ['::removeProfileSubmit'],
      '#ajax' => [
        'callback' => '::updateExtractionProfiles',
        'wrapper' => 'extraction-profiles-wrapper',
      ],
      '#limit_validation_errors' => [],
      '#attributes' => ['class' => ['button--danger']],
    ];
  }

  /**
   * Build a mapping row within a profile.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param string $profile_id
   *   The profile ID.
   * @param int $mapping_index
   *   The mapping index.
   * @param array $mapping
   *   The mapping data.
   * @param array $target_field_options
   *   The target field options.
   * @param array $paragraph_type_options
   *   The paragraph type options.
   */
  protected function buildMappingRow(array &$form, FormStateInterface $form_state, string $profile_id, int $mapping_index, array $mapping, array $target_field_options, array $paragraph_type_options): void {
    $weight = $mapping['weight'] ?? $mapping_index;
    $mapping_target_field = $this->getMappingTargetField($form_state, $profile_id, $mapping_index, $mapping);
    $is_paragraph_target = str_starts_with($mapping_target_field, 'entity_reference_revisions:');

    $form['extraction_profiles_settings']['profiles'][$profile_id]['mappings'][$mapping_index] = [
      '#attributes' => ['class' => ['draggable']],
      '#weight' => $weight,
    ];

    $form['extraction_profiles_settings']['profiles'][$profile_id]['mappings'][$mapping_index]['drag'] = [
      '#plain_text' => '',
    ];

    $form['extraction_profiles_settings']['profiles'][$profile_id]['mappings'][$mapping_index]['selector'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Selector'),
      '#title_display' => 'invisible',
      '#default_value' => $mapping['selector'] ?? '',
      '#placeholder' => $this->t('e.g., .intro, #main-content'),
      '#size' => 25,
    ];

    $form['extraction_profiles_settings']['profiles'][$profile_id]['mappings'][$mapping_index]['target_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Target Field'),
      '#title_display' => 'invisible',
      '#options' => ['' => $this->t('- Select field -')] + $target_field_options,
      '#default_value' => $mapping['target_field'] ?? '',
      '#ajax' => [
        'callback' => '::updateExtractionProfiles',
        'wrapper' => 'extraction-profiles-wrapper',
      ],
    ];

    $form['extraction_profiles_settings']['profiles'][$profile_id]['mappings'][$mapping_index]['paragraph_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Paragraph Type'),
      '#title_display' => 'invisible',
      '#options' => ['' => $this->t('- N/A -')] + $paragraph_type_options,
      '#default_value' => $is_paragraph_target ? ($mapping['paragraph_type'] ?? '') : '',
      '#disabled' => !$is_paragraph_target,
    ];

    $form['extraction_profiles_settings']['profiles'][$profile_id]['mappings'][$mapping_index]['operations'] = [
      '#type' => 'container',
      'weight' => [
        '#type' => 'hidden',
        '#default_value' => $weight,
        '#attributes' => ['class' => ['mapping-weight-' . $profile_id]],
      ],
      'remove_mapping' => [
        '#type' => 'submit',
        '#value' => $this->t('Remove'),
        '#name' => 'remove_mapping_' . $profile_id . '_' . $mapping_index,
        '#submit' => ['::removeMappingSubmit'],
        '#ajax' => [
          'callback' => '::updateExtractionProfiles',
          'wrapper' => 'extraction-profiles-wrapper',
        ],
        '#limit_validation_errors' => [],
      ],
    ];
  }

  /**
   * Get profiles from form state or config.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param mixed $config
   *   The configuration object.
   *
   * @return array
   *   The profiles array.
   */
  public function getProfilesFromState(FormStateInterface $form_state, $config): array {
    $profiles = $form_state->get('extraction_profiles');
    if ($profiles !== NULL) {
      return $profiles;
    }

    $user_input = $form_state->getUserInput();
    $stored_profile_ids = $user_input['extraction_profiles_settings']['profile_ids'] ?? '';

    if (!empty($stored_profile_ids)) {
      return $this->rebuildProfilesFromUserInput($stored_profile_ids, $user_input);
    }

    return $config->get('extraction_profiles') ?: [];
  }

  /**
   * Rebuild profiles from user input.
   *
   * @param string $stored_profile_ids
   *   Comma-separated profile IDs.
   * @param array $user_input
   *   The user input array.
   *
   * @return array
   *   The rebuilt profiles array.
   */
  protected function rebuildProfilesFromUserInput(string $stored_profile_ids, array $user_input): array {
    $profile_ids = array_filter(explode(',', $stored_profile_ids));
    $profiles = [];
    $input_profiles = $user_input['extraction_profiles_settings']['profiles'] ?? [];

    foreach ($profile_ids as $profile_id) {
      if (isset($input_profiles[$profile_id])) {
        $input_profile = $input_profiles[$profile_id];
        $mappings = $this->extractMappingsFromInput($input_profile['mappings'] ?? []);
        if (empty($mappings)) {
          $mappings = [['selector' => '', 'target_field' => '', 'paragraph_type' => '', 'weight' => 0]];
        }
        usort($mappings, fn($a, $b) => ($a['weight'] ?? 0) <=> ($b['weight'] ?? 0));
        $profiles[$profile_id] = [
          'label' => $input_profile['label'] ?? '',
          'content_type' => $input_profile['content_type'] ?? '',
          'mappings' => $mappings,
        ];
      }
      else {
        $profiles[$profile_id] = [
          'label' => '',
          'content_type' => '',
          'mappings' => [['selector' => '', 'target_field' => '', 'paragraph_type' => '', 'weight' => 0]],
        ];
      }
    }

    return $profiles;
  }

  /**
   * Extract mappings from input array.
   *
   * @param array $input_mappings
   *   The input mappings array.
   *
   * @return array
   *   The extracted mappings.
   */
  protected function extractMappingsFromInput(array $input_mappings): array {
    $mappings = [];
    foreach ($input_mappings as $key => $mapping) {
      if (is_numeric($key)) {
        $weight = $mapping['operations']['weight'] ?? $mapping['weight'] ?? 0;
        $mappings[] = [
          'selector' => $mapping['selector'] ?? '',
          'target_field' => $mapping['target_field'] ?? '',
          'paragraph_type' => $mapping['paragraph_type'] ?? '',
          'weight' => $weight,
        ];
      }
    }
    return $mappings;
  }

  /**
   * Process extraction profiles from form submission.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   Processed extraction profiles.
   */
  public function processProfiles(FormStateInterface $form_state): array {
    $profiles = [];
    $all_values = $form_state->getValues();
    $form_profiles = $all_values['extraction_profiles_settings']['profiles'] ?? [];

    foreach ($form_profiles as $profile_id => $profile_values) {
      $label = $profile_values['label'] ?? '';
      $content_type = $profile_values['content_type'] ?? '';

      $new_mappings = [];
      if (isset($profile_values['mappings'])) {
        foreach ($profile_values['mappings'] as $key => $mapping) {
          if (is_numeric($key) && isset($mapping['selector'])) {
            $target_field = $mapping['target_field'] ?? '';
            if (!empty($mapping['selector']) && !empty($target_field)) {
              $weight = $mapping['operations']['weight'] ?? $mapping['weight'] ?? 0;
              $mapping_data = [
                'selector' => $mapping['selector'],
                'target_field' => $target_field,
                'weight' => $weight,
              ];

              $is_paragraph_field = str_starts_with($target_field, 'entity_reference_revisions:');
              if ($is_paragraph_field && !empty($mapping['paragraph_type'])) {
                $mapping_data['paragraph_type'] = $mapping['paragraph_type'];
              }

              $new_mappings[] = $mapping_data;
            }
          }
        }
      }

      usort($new_mappings, fn($a, $b) => ($a['weight'] ?? 0) <=> ($b['weight'] ?? 0));

      if (!empty($label) && !empty($content_type) && !empty($new_mappings)) {
        $profiles[$profile_id] = [
          'label' => $label,
          'content_type' => $content_type,
          'mappings' => $new_mappings,
        ];
      }
    }

    return $profiles;
  }

  /**
   * Add a new profile.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function addProfile(FormStateInterface $form_state): void {
    $profiles = $form_state->get('extraction_profiles') ?: [];
    $profile_id = 'profile_' . time() . '_' . rand(1000, 9999);

    $profiles[$profile_id] = [
      'label' => (string) $this->t('New Profile'),
      'content_type' => '',
      'mappings' => [
        ['selector' => '', 'target_field' => '', 'paragraph_type' => '', 'weight' => 0],
      ],
    ];

    $form_state->set('extraction_profiles', $profiles);
    $form_state->setRebuild(TRUE);
  }

  /**
   * Remove a profile.
   *
   * @param string $profile_id
   *   The profile ID to remove.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function removeProfile(string $profile_id, FormStateInterface $form_state): void {
    $profiles = $form_state->get('extraction_profiles') ?: [];

    if (isset($profiles[$profile_id])) {
      unset($profiles[$profile_id]);
      $form_state->set('extraction_profiles', $profiles);
    }

    $form_state->setRebuild(TRUE);
  }

  /**
   * Add a mapping to a profile.
   *
   * @param string $profile_id
   *   The profile ID.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function addMapping(string $profile_id, FormStateInterface $form_state): void {
    $profiles = $form_state->get('extraction_profiles') ?: [];
    $this->updateProfilesFromFormState($profiles, $form_state);

    if (isset($profiles[$profile_id])) {
      $max_weight = 0;
      foreach ($profiles[$profile_id]['mappings'] as $mapping) {
        $max_weight = max($max_weight, ($mapping['weight'] ?? 0) + 1);
      }
      $profiles[$profile_id]['mappings'][] = [
        'selector' => '',
        'target_field' => '',
        'paragraph_type' => '',
        'weight' => $max_weight,
      ];
      $form_state->set('extraction_profiles', $profiles);
    }

    $form_state->setRebuild(TRUE);
  }

  /**
   * Remove a mapping from a profile.
   *
   * @param string $profile_id
   *   The profile ID.
   * @param int $mapping_index
   *   The mapping index.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function removeMapping(string $profile_id, int $mapping_index, FormStateInterface $form_state): void {
    $profiles = $form_state->get('extraction_profiles') ?: [];
    $this->updateProfilesFromFormState($profiles, $form_state);

    if (isset($profiles[$profile_id]['mappings'][$mapping_index])) {
      unset($profiles[$profile_id]['mappings'][$mapping_index]);
      $profiles[$profile_id]['mappings'] = array_values($profiles[$profile_id]['mappings']);

      if (empty($profiles[$profile_id]['mappings'])) {
        $profiles[$profile_id]['mappings'][] = [
          'selector' => '',
          'target_field' => '',
          'paragraph_type' => '',
          'weight' => 0,
        ];
      }

      $form_state->set('extraction_profiles', $profiles);
    }

    $form_state->setRebuild(TRUE);
  }

  /**
   * Update profiles array from form state values.
   *
   * @param array $profiles
   *   The profiles array to update.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function updateProfilesFromFormState(array &$profiles, FormStateInterface $form_state): void {
    $all_values = $form_state->getValues();
    $form_profiles = $all_values['extraction_profiles_settings']['profiles'] ?? [];

    foreach ($form_profiles as $profile_id => $profile_values) {
      if (isset($profiles[$profile_id])) {
        $profiles[$profile_id]['label'] = $profile_values['label'] ?? $profiles[$profile_id]['label'];
        $profiles[$profile_id]['content_type'] = $profile_values['content_type'] ?? $profiles[$profile_id]['content_type'] ?? '';

        if (isset($profile_values['mappings'])) {
          $new_mappings = [];
          foreach ($profile_values['mappings'] as $key => $mapping) {
            if (is_numeric($key) && isset($mapping['selector'])) {
              $new_mappings[] = [
                'selector' => $mapping['selector'] ?? '',
                'target_field' => $mapping['target_field'] ?? '',
                'paragraph_type' => $mapping['paragraph_type'] ?? '',
                'weight' => $mapping['weight'] ?? 0,
              ];
            }
          }
          if (!empty($new_mappings)) {
            usort($new_mappings, fn($a, $b) => ($a['weight'] ?? 0) <=> ($b['weight'] ?? 0));
            $profiles[$profile_id]['mappings'] = $new_mappings;
          }
        }
      }
    }
  }

  /**
   * Get paragraph type options.
   *
   * @return array
   *   An array of paragraph type labels keyed by machine names.
   */
  protected function getParagraphTypeOptions(): array {
    $options = [];
    $paragraph_types = $this->entityTypeManager->getStorage('paragraphs_type')->loadMultiple();

    foreach ($paragraph_types as $paragraph_type) {
      $options[$paragraph_type->id()] = $paragraph_type->label();
    }

    return $options;
  }

  /**
   * Get target field options for a content type.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field options.
   */
  protected function getTargetFieldOptions(string $content_type): array {
    if (empty($content_type)) {
      return [];
    }

    $field_options = [];
    $fields = $this->entityTypeManager->getStorage('field_config')->loadByProperties([
      'entity_type' => 'node',
      'bundle' => $content_type,
    ]);

    foreach ($fields as $field) {
      $field_type = $field->getType();
      $field_name = $field->getName();
      $composite_key = $field_type . ':' . $field_name;
      $type_label = $this->getFieldTypeLabel($field_type, $field);
      $field_options[$composite_key] = $field->getLabel() . ' (' . $type_label . ')';
    }

    return $field_options;
  }

  /**
   * Get a user-friendly label for a field type.
   *
   * @param string $field_type
   *   The field type machine name.
   * @param object $field
   *   The field configuration entity.
   *
   * @return string
   *   A user-friendly type label.
   */
  protected function getFieldTypeLabel(string $field_type, $field): string {
    $type_labels = [
      'text_with_summary' => 'Text',
      'text_long' => 'Text',
      'text' => 'Text',
      'string' => 'String',
      'string_long' => 'Text',
      'boolean' => 'Boolean',
      'integer' => 'Integer',
      'decimal' => 'Decimal',
      'float' => 'Float',
      'datetime' => 'Date/Time',
      'daterange' => 'Date Range',
      'email' => 'Email',
      'link' => 'Link',
      'telephone' => 'Phone',
      'image' => 'Image',
      'file' => 'File',
      'list_string' => 'List',
      'list_integer' => 'List',
      'list_float' => 'List',
    ];

    if (isset($type_labels[$field_type])) {
      return $type_labels[$field_type];
    }

    if ($field_type === 'entity_reference') {
      $target_type = $field->getSetting('target_type');
      return ucfirst($target_type) . ' Reference';
    }

    if ($field_type === 'entity_reference_revisions') {
      $target_type = $field->getSetting('target_type');
      if ($target_type === 'paragraph') {
        return 'Paragraph';
      }
      return ucfirst($target_type) . ' Reference';
    }

    return ucfirst(str_replace('_', ' ', $field_type));
  }

  /**
   * Get profile content type from form state.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param string $profile_id
   *   The profile ID.
   * @param array $profile
   *   The profile data.
   *
   * @return string
   *   The content type.
   */
  protected function getProfileContentType(FormStateInterface $form_state, string $profile_id, array $profile): string {
    $profile_content_type = $form_state->getValue(['extraction_profiles_settings', 'profiles', $profile_id, 'content_type']);
    if (!$profile_content_type) {
      $user_input = $form_state->getUserInput();
      $profile_content_type = $user_input['extraction_profiles_settings']['profiles'][$profile_id]['content_type'] ?? ($profile['content_type'] ?? '');
    }
    return $profile_content_type;
  }

  /**
   * Get mapping target field from form state.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param string $profile_id
   *   The profile ID.
   * @param int $mapping_index
   *   The mapping index.
   * @param array $mapping
   *   The mapping data.
   *
   * @return string
   *   The target field.
   */
  protected function getMappingTargetField(FormStateInterface $form_state, string $profile_id, int $mapping_index, array $mapping): string {
    $mapping_target_field = $form_state->getValue([
      'extraction_profiles_settings', 'profiles', $profile_id, 'mappings', $mapping_index, 'target_field',
    ]);
    if (!$mapping_target_field) {
      $user_input = $form_state->getUserInput();
      $mapping_target_field = $user_input['extraction_profiles_settings']['profiles'][$profile_id]['mappings'][$mapping_index]['target_field']
        ?? ($mapping['target_field'] ?? '');
    }
    return $mapping_target_field;
  }

  /**
   * Prepare mappings with default values and sorting.
   *
   * @param array $mappings
   *   The raw mappings array.
   *
   * @return array
   *   The prepared mappings.
   */
  protected function prepareMappings(array $mappings): array {
    if (empty($mappings)) {
      return [['selector' => '', 'target_field' => '', 'paragraph_type' => '', 'weight' => 0]];
    }

    usort($mappings, fn($a, $b) => ($a['weight'] ?? 0) <=> ($b['weight'] ?? 0));

    return $mappings;
  }

}
