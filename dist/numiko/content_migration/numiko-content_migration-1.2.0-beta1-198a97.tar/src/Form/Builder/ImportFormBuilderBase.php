<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form\Builder;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Base class for import form builders.
 *
 * Provides common functionality for building import form sections.
 */
abstract class ImportFormBuilderBase implements ImportFormBuilderInterface {

  use StringTranslationTrait;

  /**
   * Constructs an ImportFormBuilderBase object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   */
  public function __construct(
    protected readonly ConfigFactoryInterface $configFactory,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    // Default implementation does nothing.
    // Subclasses can override to add validation.
  }

  /**
   * Gets the module configuration.
   *
   * @return \Drupal\Core\Config\ImmutableConfig
   *   The configuration object.
   */
  protected function getConfig(): \Drupal\Core\Config\ImmutableConfig {
    return $this->configFactory->get(ContentMigrationConstants::CONFIG_KEY);
  }

  /**
   * Builds the extraction mode options form element.
   *
   * @param string $prefix
   *   The form element prefix for unique IDs.
   *
   * @return array
   *   The form element array.
   */
  protected function buildExtractionModeElement(string $prefix = ''): array {
    return [
      '#type' => 'select',
      '#title' => $this->t('Extraction Mode'),
      '#options' => [
        ContentMigrationConstants::EXTRACTION_MODE_ARTICLE => $this->t('Article Content Only'),
        ContentMigrationConstants::EXTRACTION_MODE_FULL_PAGE => $this->t('Full Page Content'),
      ],
      '#default_value' => ContentMigrationConstants::EXTRACTION_MODE_ARTICLE,
      '#description' => $this->t('Choose how to extract content from the page.'),
    ];
  }

  /**
   * Builds the extraction profile select element.
   *
   * @param array $profiles
   *   The available extraction profiles.
   *
   * @return array
   *   The form element array.
   */
  protected function buildExtractionProfileElement(array $profiles): array {
    $options = ['' => $this->t('- None (use standard extraction) -')];
    foreach ($profiles as $id => $profile) {
      $options[$id] = $profile['label'] ?? $id;
    }

    return [
      '#type' => 'select',
      '#title' => $this->t('Extraction Profile'),
      '#options' => $options,
      '#default_value' => '',
      '#description' => $this->t('Select an extraction profile for advanced content mapping.'),
    ];
  }

  /**
   * Builds the content selector element.
   *
   * @return array
   *   The form element array.
   */
  protected function buildContentSelectorElement(): array {
    return [
      '#type' => 'textfield',
      '#title' => $this->t('Content Selector'),
      '#description' => $this->t('Optional CSS selector to target specific content (e.g., ".main-content", "#article-body").'),
      '#default_value' => '',
    ];
  }

  /**
   * Builds the tags to remove element.
   *
   * @return array
   *   The form element array.
   */
  protected function buildTagsToRemoveElement(): array {
    return [
      '#type' => 'textfield',
      '#title' => $this->t('Tags to Remove'),
      '#description' => $this->t('Comma-separated list of CSS selectors for elements to remove (e.g., "nav, footer, .sidebar").'),
      '#default_value' => '',
    ];
  }

  /**
   * Builds the create redirects checkbox element.
   *
   * @return array
   *   The form element array.
   */
  protected function buildCreateRedirectsElement(): array {
    return [
      '#type' => 'checkbox',
      '#title' => $this->t('Create redirects from source URLs'),
      '#description' => $this->t('If enabled, redirects will be created from the original URLs to the new content.'),
      '#default_value' => FALSE,
    ];
  }

}
