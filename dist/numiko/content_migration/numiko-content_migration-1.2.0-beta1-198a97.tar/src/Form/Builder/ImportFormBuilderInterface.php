<?php

declare(strict_types=1);

namespace Drupal\content_migration\Form\Builder;

use Drupal\Core\Form\FormStateInterface;

/**
 * Interface for import form builders.
 *
 * Each form builder is responsible for building a specific section of the
 * content import form (URL import, PDF import, CSV import, etc.).
 */
interface ImportFormBuilderInterface {

  /**
   * Builds the form elements for this import type.
   *
   * @param array $form
   *   The form array to add elements to.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $options
   *   Additional options for building the form. May include:
   *   - content_types: Available content types.
   *   - extraction_profiles: Available extraction profiles.
   *   - ai_plugins: Available AI plugins.
   *   - taxonomies: Available taxonomy vocabularies.
   *
   * @return array
   *   The modified form array.
   */
  public function buildForm(array $form, FormStateInterface $form_state, array $options = []): array;

  /**
   * Validates the form elements for this import type.
   *
   * @param array &$form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void;

  /**
   * Gets the unique identifier for this form builder.
   *
   * @return string
   *   The builder ID (e.g., 'url', 'pdf', 'csv', 'title').
   */
  public function getId(): string;

  /**
   * Gets the human-readable label for this form builder.
   *
   * @return string
   *   The builder label.
   */
  public function getLabel(): string;

}
