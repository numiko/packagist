<?php

declare(strict_types=1);

namespace Drupal\content_migration\Batch;

use Drupal\content_migration\Import\CsvImportProcessor;
use Drupal\content_migration\Import\PdfImportProcessor;
use Drupal\content_migration\Import\TitleImportProcessor;
use Drupal\content_migration\Import\UrlImportProcessor;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\file\FileInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for processing batch imports.
 *
 * This service is designed to be called from batch callback functions
 * and provides a clean API for processing different import types.
 */
class ImportBatchProcessor {

  use StringTranslationTrait;

  /**
   * Constructs an ImportBatchProcessor object.
   *
   * @param \Drupal\content_migration\Import\UrlImportProcessor $urlProcessor
   *   The URL import processor.
   * @param \Drupal\content_migration\Import\TitleImportProcessor $titleProcessor
   *   The title import processor.
   * @param \Drupal\content_migration\Import\PdfImportProcessor $pdfProcessor
   *   The PDF import processor.
   * @param \Drupal\content_migration\Import\CsvImportProcessor $csvProcessor
   *   The CSV import processor.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    protected readonly UrlImportProcessor $urlProcessor,
    protected readonly TitleImportProcessor $titleProcessor,
    protected readonly PdfImportProcessor $pdfProcessor,
    protected readonly CsvImportProcessor $csvProcessor,
    protected readonly MessengerInterface $messenger,
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * Processes a URL import batch operation.
   *
   * @param string $url
   *   The URL to import.
   * @param array $config
   *   The import configuration.
   * @param array &$context
   *   The batch context array.
   */
  public function processUrlBatch(string $url, array $config, array &$context): void {
    try {
      $node = $this->urlProcessor->process(['url' => $url], $config);

      $context['results']['processed'][] = [
        'type' => 'url',
        'source' => $url,
        'node_id' => $node->id(),
        'title' => $node->getTitle(),
      ];

      $context['message'] = $this->t('Processed: @url', ['@url' => $url]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = [
        'type' => 'url',
        'source' => $url,
        'error' => $e->getMessage(),
      ];

      $this->logger->error('Failed to process URL @url: @error', [
        '@url' => $url,
        '@error' => $e->getMessage(),
      ]);

      $context['message'] = $this->t('Failed: @url', ['@url' => $url]);
    }
  }

  /**
   * Processes merged URLs batch operation.
   *
   * @param array $urls
   *   Array of URLs to merge.
   * @param array $config
   *   The import configuration.
   * @param array &$context
   *   The batch context array.
   */
  public function processMergedUrlsBatch(array $urls, array $config, array &$context): void {
    try {
      $node = $this->urlProcessor->process(['urls' => $urls], $config);

      $context['results']['processed'][] = [
        'type' => 'merged_urls',
        'source' => implode(', ', $urls),
        'node_id' => $node->id(),
        'title' => $node->getTitle(),
      ];

      $context['message'] = $this->t('Processed merged content from @count URLs', [
        '@count' => count($urls),
      ]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = [
        'type' => 'merged_urls',
        'source' => implode(', ', $urls),
        'error' => $e->getMessage(),
      ];

      $this->logger->error('Failed to process merged URLs: @error', [
        '@error' => $e->getMessage(),
      ]);

      $context['message'] = $this->t('Failed to process merged URLs');
    }
  }

  /**
   * Processes a title import batch operation.
   *
   * @param string $title
   *   The page title.
   * @param array $config
   *   The import configuration.
   * @param array &$context
   *   The batch context array.
   */
  public function processTitleBatch(string $title, array $config, array &$context): void {
    try {
      $node = $this->titleProcessor->process(['title' => $title], $config);

      $context['results']['processed'][] = [
        'type' => 'title',
        'source' => $title,
        'node_id' => $node->id(),
        'title' => $node->getTitle(),
      ];

      $context['message'] = $this->t('Created page: @title', ['@title' => $title]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = [
        'type' => 'title',
        'source' => $title,
        'error' => $e->getMessage(),
      ];

      $this->logger->error('Failed to create page "@title": @error', [
        '@title' => $title,
        '@error' => $e->getMessage(),
      ]);

      $context['message'] = $this->t('Failed: @title', ['@title' => $title]);
    }
  }

  /**
   * Processes a PDF import batch operation.
   *
   * @param \Drupal\file\FileInterface $pdfFile
   *   The PDF file to process.
   * @param array $config
   *   The import configuration.
   * @param array &$context
   *   The batch context array.
   */
  public function processPdfBatch(FileInterface $pdfFile, array $config, array &$context): void {
    try {
      $node = $this->pdfProcessor->process(['file' => $pdfFile], $config);

      $context['results']['processed'][] = [
        'type' => 'pdf',
        'source' => $pdfFile->getFilename(),
        'node_id' => $node->id(),
        'title' => $node->getTitle(),
      ];

      $context['message'] = $this->t('Processed PDF: @filename', [
        '@filename' => $pdfFile->getFilename(),
      ]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = [
        'type' => 'pdf',
        'source' => $pdfFile->getFilename(),
        'error' => $e->getMessage(),
      ];

      $this->logger->error('Failed to process PDF "@filename": @error', [
        '@filename' => $pdfFile->getFilename(),
        '@error' => $e->getMessage(),
      ]);

      $context['message'] = $this->t('Failed: @filename', [
        '@filename' => $pdfFile->getFilename(),
      ]);
    }
  }

  /**
   * Processes a CSV row import batch operation.
   *
   * @param array $csvRow
   *   The CSV row data.
   * @param array $config
   *   The import configuration.
   * @param array &$context
   *   The batch context array.
   */
  public function processCsvBatch(array $csvRow, array $config, array &$context): void {
    // Initialize menu link tracking in sandbox.
    if (!isset($context['sandbox']['menu_links'])) {
      $context['sandbox']['menu_links'] = [];
    }
    if (!isset($context['sandbox']['weight_counters'])) {
      $context['sandbox']['weight_counters'] = [];
    }

    $pageTitle = trim($csvRow['page_title'] ?? '');

    try {
      $data = [
        'row' => $csvRow,
        'menu_links' => $context['sandbox']['menu_links'],
        'weight_counters' => $context['sandbox']['weight_counters'],
      ];

      $node = $this->csvProcessor->process($data, $config);

      // Update tracking arrays for next iteration.
      if (isset($data['menu_links'][$pageTitle])) {
        $context['sandbox']['menu_links'][$pageTitle] = $data['menu_links'][$pageTitle];
      }

      $context['results']['processed'][] = [
        'type' => 'csv',
        'source' => $pageTitle,
        'node_id' => $node->id(),
        'title' => $node->getTitle(),
      ];

      $context['message'] = $this->t('Created page: @title', ['@title' => $pageTitle]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = [
        'type' => 'csv',
        'source' => $pageTitle,
        'error' => $e->getMessage(),
      ];

      $this->logger->error('Failed to create CSV page "@title": @error', [
        '@title' => $pageTitle,
        '@error' => $e->getMessage(),
      ]);

      $context['message'] = $this->t('Failed: @title', ['@title' => $pageTitle]);
    }
  }

  /**
   * Batch finished callback.
   *
   * @param bool $success
   *   Whether the batch completed successfully.
   * @param array $results
   *   The batch results.
   * @param array $operations
   *   The remaining operations.
   */
  public static function batchFinished(bool $success, array $results, array $operations): void {
    $messenger = \Drupal::messenger();

    if ($success) {
      $processedCount = count($results['processed'] ?? []);
      $errorCount = count($results['errors'] ?? []);

      if ($processedCount > 0) {
        $messenger->addStatus(t('Successfully processed @count items.', [
          '@count' => $processedCount,
        ]));
      }

      if ($errorCount > 0) {
        $messenger->addWarning(t('@count items failed to process. Check the logs for details.', [
          '@count' => $errorCount,
        ]));
      }
    }
    else {
      $messenger->addError(t('Batch processing encountered errors.'));
    }
  }

}
