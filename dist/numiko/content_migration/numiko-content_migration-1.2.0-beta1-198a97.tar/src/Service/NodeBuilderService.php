<?php

declare(strict_types=1);

namespace Drupal\content_migration\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\ParagraphInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for building and populating nodes with content.
 *
 * This service encapsulates node creation, paragraph handling, and field
 * population logic extracted from ContentImportController.
 */
class NodeBuilderService {

  /**
   * Stores truncation warnings for the current import.
   *
   * @var array
   */
  protected array $truncationWarnings = [];

  /**
   * Constructs a NodeBuilderService object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * Creates a new node of the specified content type.
   *
   * @param string $contentType
   *   The machine name of the content type.
   * @param string $title
   *   The node title.
   * @param int|null $uid
   *   Optional user ID for the node author. Defaults to admin.
   * @param bool $published
   *   Whether the node should be published. Defaults to TRUE.
   *
   * @return \Drupal\node\NodeInterface
   *   The created (unsaved) node entity.
   */
  public function createNode(string $contentType, string $title, ?int $uid = NULL, bool $published = TRUE): NodeInterface {
    $uid = $uid ?? ContentMigrationConstants::DEFAULT_ADMIN_UID;

    /** @var \Drupal\node\NodeInterface $node */
    $node = $this->entityTypeManager->getStorage('node')->create([
      'type' => $contentType,
      'title' => $title,
      'status' => $published ? 1 : 0,
      'uid' => $uid,
    ]);

    return $node;
  }

  /**
   * Creates a paragraph entity with the given content.
   *
   * @param string $type
   *   The paragraph bundle type.
   * @param string $content
   *   The HTML content for the paragraph.
   * @param string|null $format
   *   The text format. Defaults to full_html.
   * @param string $fieldName
   *   The field name for the content. Defaults to 'field_content'.
   *
   * @return \Drupal\paragraphs\ParagraphInterface
   *   The created (unsaved) paragraph entity.
   */
  public function createParagraph(string $type, string $content, ?string $format = NULL, string $fieldName = 'field_content'): ParagraphInterface {
    $format = $format ?? ContentMigrationConstants::DEFAULT_TEXT_FORMAT_FULL;

    /** @var \Drupal\paragraphs\ParagraphInterface $paragraph */
    $paragraph = $this->entityTypeManager->getStorage('paragraph')->create([
      'type' => $type,
      $fieldName => [
        'value' => $content,
        'format' => $format,
      ],
    ]);

    return $paragraph;
  }

  /**
   * Creates and saves a paragraph, returning entity reference data.
   *
   * @param string $type
   *   The paragraph bundle type.
   * @param string $content
   *   The HTML content for the paragraph.
   * @param string|null $format
   *   The text format. Defaults to full_html.
   * @param string $fieldName
   *   The field name for the content. Defaults to 'field_content'.
   *
   * @return array
   *   An array suitable for entity reference fields with target_id and
   *   target_revision_id.
   */
  public function createAndSaveParagraph(string $type, string $content, ?string $format = NULL, string $fieldName = 'field_content'): array {
    $paragraph = $this->createParagraph($type, $content, $format, $fieldName);
    $paragraph->save();

    return [
      'target_id' => $paragraph->id(),
      'target_revision_id' => $paragraph->getRevisionId(),
    ];
  }

  /**
   * Parses a composite field key into its components.
   *
   * Composite keys use the format "field_type:field_name" where:
   * - field_type: text, text_with_summary, paragraph, entity_reference_revisions
   * - field_name: the actual field machine name
   *
   * @param string $compositeKey
   *   The composite key to parse (e.g., "paragraph:field_content").
   *
   * @return array
   *   An associative array with keys:
   *   - 'type': The field type (defaults to 'text' if no delimiter).
   *   - 'name': The field name.
   *   - 'is_paragraph': TRUE if this is a paragraph/entity_reference field.
   */
  public function parseCompositeKey(string $compositeKey): array {
    $parts = explode(ContentMigrationConstants::COMPOSITE_KEY_DELIMITER, $compositeKey, 2);

    if (count($parts) === 2) {
      $type = $parts[0];
      $name = $parts[1];
    }
    else {
      $type = 'text';
      $name = $compositeKey;
    }

    $isParagraph = in_array($type, ['paragraph', 'entity_reference_revisions'], TRUE);

    return [
      'type' => $type,
      'name' => $name,
      'is_paragraph' => $isParagraph,
    ];
  }

  /**
   * Determines if a composite key represents a paragraph field.
   *
   * @param string $compositeKey
   *   The composite key to check.
   *
   * @return bool
   *   TRUE if this is a paragraph field, FALSE otherwise.
   */
  public function isParagraphField(string $compositeKey): bool {
    $parsed = $this->parseCompositeKey($compositeKey);
    return $parsed['is_paragraph'];
  }

  /**
   * Sets a field value on a node based on a composite key.
   *
   * Handles both direct text fields and paragraph reference fields.
   * Automatically strips HTML for plain text fields and truncates content
   * that exceeds field max length.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to set the field on.
   * @param string $compositeKey
   *   The composite key (e.g., "paragraph:field_content" or "text:field_body").
   * @param string $content
   *   The content to set.
   * @param string $paragraphType
   *   The paragraph type to use if creating a paragraph.
   * @param string|null $textFormat
   *   The text format. Uses defaults based on field type if not provided.
   */
  public function setFieldValue(NodeInterface $node, string $compositeKey, string $content, string $paragraphType = ContentMigrationConstants::DEFAULT_PARAGRAPH_TYPE, ?string $textFormat = NULL): void {
    $parsed = $this->parseCompositeKey($compositeKey);
    $fieldName = $parsed['name'];

    if ($parsed['is_paragraph']) {
      $format = $textFormat ?? ContentMigrationConstants::DEFAULT_TEXT_FORMAT_FULL;
      $paragraphRef = $this->createAndSaveParagraph($paragraphType, $content, $format);
      $node->set($fieldName, $paragraphRef);
    }
    else {
      // Check if this is a plain text field that doesn't support HTML.
      $isPlainTextField = $this->isPlainTextField($node, $fieldName);
      $fieldType = $this->getFieldType($node, $fieldName);

      if ($isPlainTextField) {
        // Email fields need special handling to extract from mailto: links.
        if ($fieldType === 'email') {
          $content = $this->extractEmailFromHtml($content);
        }
        else {
          // Strip HTML tags and clean up formatting for plain text fields.
          $content = $this->extractPlainText($content);
        }
      }

      // Check field max length and truncate if necessary.
      $content = $this->truncateToFieldMaxLength($node, $fieldName, $content);

      // Plain text fields don't use format, formatted text fields do.
      if ($isPlainTextField) {
        $node->set($fieldName, $content);
      }
      else {
        $format = $textFormat ?? ContentMigrationConstants::DEFAULT_TEXT_FORMAT_BASIC;
        $node->set($fieldName, [
          'value' => $content,
          'format' => $format,
        ]);
      }
    }
  }

  /**
   * Gets the Drupal field type for a field on a node.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node containing the field.
   * @param string $fieldName
   *   The field name.
   *
   * @return string|null
   *   The field type or NULL if field doesn't exist.
   */
  protected function getFieldType(NodeInterface $node, string $fieldName): ?string {
    if (!$node->hasField($fieldName)) {
      return NULL;
    }

    $fieldDefinition = $node->getFieldDefinition($fieldName);
    if (!$fieldDefinition) {
      return NULL;
    }

    return $fieldDefinition->getType();
  }

  /**
   * Determines if a field is a plain text field (no HTML support).
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node containing the field.
   * @param string $fieldName
   *   The field name.
   *
   * @return bool
   *   TRUE if this is a plain text field, FALSE if it supports formatted text.
   */
  protected function isPlainTextField(NodeInterface $node, string $fieldName): bool {
    $fieldType = $this->getFieldType($node, $fieldName);
    if (!$fieldType) {
      return FALSE;
    }

    // Plain text field types that don't support HTML.
    $plainTextTypes = [
      'string',
      'string_long',
      'telephone',
      'email',
      'link',
      'integer',
      'decimal',
      'float',
    ];

    return in_array($fieldType, $plainTextTypes, TRUE);
  }

  /**
   * Truncates content to fit within a field's maximum length.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node containing the field.
   * @param string $fieldName
   *   The field name.
   * @param string $content
   *   The content to potentially truncate.
   *
   * @return string
   *   The content, truncated if necessary.
   */
  protected function truncateToFieldMaxLength(NodeInterface $node, string $fieldName, string $content): string {
    if (!$node->hasField($fieldName)) {
      return $content;
    }

    $fieldDefinition = $node->getFieldDefinition($fieldName);
    if (!$fieldDefinition) {
      return $content;
    }

    // Get max length from field settings.
    $maxLength = $fieldDefinition->getSetting('max_length');

    // If no max length is set (e.g., text_long fields), return as-is.
    if (empty($maxLength)) {
      return $content;
    }

    $originalLength = mb_strlen($content);
    if ($originalLength <= $maxLength) {
      return $content;
    }

    // Truncate content.
    $truncatedContent = mb_substr($content, 0, $maxLength);

    // Record the truncation warning.
    $this->truncationWarnings[] = [
      'field' => $fieldName,
      'original_length' => $originalLength,
      'max_length' => $maxLength,
      'truncated_by' => $originalLength - $maxLength,
    ];

    $this->logger->warning('Field "@field" content truncated from @original to @max characters.', [
      '@field' => $fieldName,
      '@original' => $originalLength,
      '@max' => $maxLength,
    ]);

    return $truncatedContent;
  }

  /**
   * Gets and clears truncation warnings.
   *
   * @return array
   *   Array of truncation warning records.
   */
  public function getTruncationWarnings(): array {
    $warnings = $this->truncationWarnings;
    $this->truncationWarnings = [];
    return $warnings;
  }

  /**
   * Clears truncation warnings without returning them.
   */
  public function clearTruncationWarnings(): void {
    $this->truncationWarnings = [];
  }

  /**
   * Populates a content field based on field mapping.
   *
   * This is a convenience method that wraps setFieldValue for compatibility
   * with existing code patterns.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to populate.
   * @param string $fieldMapping
   *   The field mapping (e.g., "text:field_body" or "paragraph:field_content").
   * @param string $content
   *   The content to populate.
   */
  public function populateContentField(NodeInterface $node, string $fieldMapping, string $content): void {
    $this->setFieldValue($node, $fieldMapping, $content);
  }

  /**
   * Sets multiple paragraph references on a node field.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to set paragraphs on.
   * @param string $fieldName
   *   The paragraph reference field name.
   * @param array $paragraphReferences
   *   Array of paragraph reference arrays with target_id and target_revision_id.
   */
  public function setParagraphReferences(NodeInterface $node, string $fieldName, array $paragraphReferences): void {
    if (!empty($paragraphReferences)) {
      $node->set($fieldName, $paragraphReferences);
    }
  }

  /**
   * Extracts plain text from HTML, stripping all markup.
   *
   * Used for intro/summary fields that should contain plain text only.
   *
   * @param string $html
   *   The HTML content.
   *
   * @return string
   *   Plain text with all HTML tags removed.
   */
  public function extractPlainText(string $html): string {
    $html = trim($html);
    if (empty($html)) {
      return '';
    }

    // Decode HTML entities.
    $text = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

    // Replace block-level elements with newlines to preserve paragraph breaks.
    $text = preg_replace('/<\/(p|div|br|h[1-6]|li)>/i', "\n", $text);
    $text = preg_replace('/<br\s*\/?>/i', "\n", $text);

    // Strip all remaining HTML tags.
    $text = strip_tags($text);

    // Normalize whitespace: collapse multiple spaces/tabs to single space.
    $text = preg_replace('/[ \t]+/', ' ', $text);

    // Normalize newlines: collapse multiple newlines to max two.
    $text = preg_replace('/\n\s*\n\s*\n+/', "\n\n", $text);

    // Trim each line.
    $lines = explode("\n", $text);
    $lines = array_map('trim', $lines);
    $text = implode("\n", $lines);

    return trim($text);
  }

  /**
   * Extracts an email address from HTML content.
   *
   * Tries multiple strategies:
   * 1. Extract from mailto: link href attribute
   * 2. Look for email pattern in text content
   * 3. Fall back to plain text extraction
   *
   * @param string $html
   *   The HTML content that may contain an email address.
   *
   * @return string
   *   The extracted email address, or empty string if not found.
   */
  public function extractEmailFromHtml(string $html): string {
    $this->logger->info('extractEmailFromHtml - RAW INPUT: @raw', [
      '@raw' => $html,
    ]);

    $html = trim($html);
    if (empty($html)) {
      $this->logger->debug('extractEmailFromHtml - Input is empty after trim');
      return '';
    }

    // Strategy 1: Check for Cloudflare email protection (data-cfemail attribute).
    if (preg_match('/data-cfemail=["\']([a-f0-9]+)["\']/i', $html, $matches)) {
      $encodedEmail = $matches[1];
      $this->logger->info('extractEmailFromHtml - Found Cloudflare protected email: @encoded', [
        '@encoded' => $encodedEmail,
      ]);
      $decodedEmail = $this->decodeCloudflareEmail($encodedEmail);
      if (!empty($decodedEmail) && filter_var($decodedEmail, FILTER_VALIDATE_EMAIL)) {
        $this->logger->info('extractEmailFromHtml - Decoded Cloudflare email: @email', [
          '@email' => $decodedEmail,
        ]);
        return $decodedEmail;
      }
      $this->logger->debug('extractEmailFromHtml - Cloudflare decode failed or invalid email');
    }

    // Strategy 2: Try to extract from mailto: link.
    if (preg_match('/href=["\']mailto:([^"\'?]+)/i', $html, $matches)) {
      $email = trim($matches[1]);
      $this->logger->debug('extractEmailFromHtml - Found mailto link, extracted: @email', [
        '@email' => $email,
      ]);
      if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $this->logger->debug('extractEmailFromHtml - Mailto email is valid, returning: @email', [
          '@email' => $email,
        ]);
        return $email;
      }
      $this->logger->debug('extractEmailFromHtml - Mailto email failed validation');
    }
    else {
      $this->logger->debug('extractEmailFromHtml - No mailto link found in HTML');
    }

    // Strategy 2: Look for email pattern in the content.
    // First strip tags to get text content.
    $text = strip_tags($html);
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $this->logger->info('extractEmailFromHtml - STRIPPED TEXT: @text', [
      '@text' => $text,
    ]);

    // Match email pattern.
    $emailPattern = '/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/';
    if (preg_match($emailPattern, $text, $matches)) {
      $email = trim($matches[0]);
      $this->logger->debug('extractEmailFromHtml - Found email pattern: @email', [
        '@email' => $email,
      ]);
      if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $this->logger->debug('extractEmailFromHtml - Pattern email is valid, returning: @email', [
          '@email' => $email,
        ]);
        return $email;
      }
      $this->logger->debug('extractEmailFromHtml - Pattern email failed validation');
    }
    else {
      $this->logger->debug('extractEmailFromHtml - No email pattern found in stripped text');
    }

    // Strategy 3: Fall back to plain text (may not be a valid email).
    $plainText = $this->extractPlainText($html);
    $this->logger->debug('extractEmailFromHtml - PLAIN TEXT FALLBACK: @plain', [
      '@plain' => $plainText,
    ]);

    // Only return if it looks like an email.
    if (filter_var($plainText, FILTER_VALIDATE_EMAIL)) {
      $this->logger->debug('extractEmailFromHtml - Plain text is valid email, returning: @email', [
        '@email' => $plainText,
      ]);
      return $plainText;
    }

    // Log warning that we couldn't extract a valid email.
    $this->logger->warning('Could not extract valid email from content. RAW: @raw | STRIPPED: @stripped | PLAIN: @plain', [
      '@raw' => mb_substr($html, 0, 500),
      '@stripped' => mb_substr($text, 0, 500),
      '@plain' => $plainText,
    ]);

    return '';
  }

  /**
   * Decodes a Cloudflare-protected email address.
   *
   * Cloudflare email protection encodes emails using a XOR cipher with
   * the first byte as the key. This function reverses that encoding.
   *
   * @param string $encodedString
   *   The hex-encoded email string from data-cfemail attribute.
   *
   * @return string
   *   The decoded email address, or empty string on failure.
   */
  protected function decodeCloudflareEmail(string $encodedString): string {
    if (empty($encodedString) || strlen($encodedString) < 4) {
      return '';
    }

    // First two hex characters are the XOR key.
    $key = hexdec(substr($encodedString, 0, 2));
    $email = '';

    // Iterate through remaining hex pairs.
    for ($i = 2; $i < strlen($encodedString); $i += 2) {
      $hexPair = substr($encodedString, $i, 2);
      if (strlen($hexPair) === 2) {
        $charCode = hexdec($hexPair) ^ $key;
        $email .= chr($charCode);
      }
    }

    return $email;
  }

  /**
   * Adds taxonomy terms to a node.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to add taxonomy terms to.
   * @param array $taxonomyTerms
   *   Array of taxonomy terms organized by vocabulary ID.
   *   Format: ['vocabulary_id' => [term_id1, term_id2, ...], ...].
   */
  public function addTaxonomyTermsToNode(NodeInterface $node, array $taxonomyTerms): void {
    if (empty($taxonomyTerms)) {
      return;
    }

    // Find taxonomy reference fields on the node.
    $fieldDefinitions = $node->getFieldDefinitions();

    foreach ($fieldDefinitions as $fieldName => $fieldDefinition) {
      if ($fieldDefinition->getType() === 'entity_reference' &&
          $fieldDefinition->getSettings()['target_type'] === 'taxonomy_term') {

        $handlerSettings = $fieldDefinition->getSettings()['handler_settings'] ?? [];
        $targetBundles = $handlerSettings['target_bundles'] ?? [];

        // If no target bundles are specified, the field accepts all vocabularies.
        if (empty($targetBundles)) {
          // Collect all terms from all vocabularies for this field.
          $allTerms = [];
          foreach ($taxonomyTerms as $terms) {
            $allTerms = array_merge($allTerms, $terms);
          }
          if (!empty($allTerms)) {
            $node->set($fieldName, array_values($allTerms));
          }
        }
        else {
          // Find terms that match this field's target vocabularies.
          $matchingTerms = [];
          foreach ($targetBundles as $vocabularyId) {
            if (isset($taxonomyTerms[$vocabularyId])) {
              $matchingTerms = array_merge($matchingTerms, $taxonomyTerms[$vocabularyId]);
            }
          }
          if (!empty($matchingTerms)) {
            $node->set($fieldName, array_values($matchingTerms));
          }
        }
      }
    }
  }

}
