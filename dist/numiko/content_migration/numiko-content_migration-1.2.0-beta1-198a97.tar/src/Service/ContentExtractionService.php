<?php

declare(strict_types=1);

namespace Drupal\content_migration\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Exception\ExtractionProfileNotFoundException;
use Drupal\Core\Config\ConfigFactoryInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for orchestrating content extraction from URLs.
 *
 * This service provides a high-level interface for extracting content
 * from URLs using various modes (article, full_page, profile-based).
 */
class ContentExtractionService {

  /**
   * Constructs a ContentExtractionService object.
   *
   * @param \Drupal\content_migration\Service\UrlContentFetcherService $urlContentFetcher
   *   The URL content fetcher service.
   * @param \Drupal\content_migration\Service\HtmlParserService $htmlParser
   *   The HTML parser service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The configuration factory.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    protected readonly UrlContentFetcherService $urlContentFetcher,
    protected readonly HtmlParserService $htmlParser,
    protected readonly ConfigFactoryInterface $configFactory,
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * Extracts content from a URL using the specified mode.
   *
   * @param string $url
   *   The URL to extract content from.
   * @param string $mode
   *   The extraction mode ('article' or 'full_page').
   * @param string|null $contentSelector
   *   Optional CSS selector for content extraction.
   * @param array|null $tagsToRemove
   *   Optional array of selectors to remove.
   *
   * @return array
   *   An array with 'title' and 'content' keys.
   *
   * @throws \Drupal\content_migration\Exception\ContentFetchException
   *   If fetching the URL fails.
   * @throws \Drupal\content_migration\Exception\ContentParseException
   *   If parsing the HTML fails.
   */
  public function extractFromUrl(string $url, string $mode = ContentMigrationConstants::EXTRACTION_MODE_ARTICLE, ?string $contentSelector = NULL, ?array $tagsToRemove = NULL): array {
    // Fetch HTML content from the URL.
    $htmlContent = $this->urlContentFetcher->fetchContent($url);

    // Sanitize and extract content.
    return $this->htmlParser->sanitizeHtml($htmlContent, $mode, $contentSelector, $tagsToRemove);
  }

  /**
   * Extracts content from a URL using an extraction profile.
   *
   * @param string $url
   *   The URL to extract content from.
   * @param string $profileId
   *   The extraction profile ID.
   *
   * @return array
   *   An array containing:
   *   - 'title': The extracted title.
   *   - 'target_field': The target field from the profile.
   *   - 'extractions': Array of extracted content pieces with paragraph_type.
   *
   * @throws \Drupal\content_migration\Exception\ContentFetchException
   *   If fetching the URL fails.
   * @throws \Drupal\content_migration\Exception\ExtractionProfileNotFoundException
   *   If the specified profile is not found.
   */
  public function extractFromUrlWithProfile(string $url, string $profileId): array {
    // Fetch HTML content from the URL.
    $htmlContent = $this->urlContentFetcher->fetchContent($url);

    // Get the profile and extract.
    return $this->extractFromHtmlWithProfile($htmlContent, $profileId);
  }

  /**
   * Extracts content from raw HTML using an extraction profile.
   *
   * @param string $html
   *   The raw HTML content.
   * @param string $profileId
   *   The extraction profile ID.
   *
   * @return array
   *   An array containing:
   *   - 'title': The extracted title.
   *   - 'target_field': The target field from the profile.
   *   - 'extractions': Array of extracted content pieces with paragraph_type.
   *
   * @throws \Drupal\content_migration\Exception\ExtractionProfileNotFoundException
   *   If the specified profile is not found.
   */
  public function extractFromHtmlWithProfile(string $html, string $profileId): array {
    $profile = $this->getExtractionProfile($profileId);

    return $this->htmlParser->extractWithProfile($html, $profile);
  }

  /**
   * Gets an extraction profile by ID.
   *
   * @param string $profileId
   *   The profile ID.
   *
   * @return array
   *   The extraction profile configuration.
   *
   * @throws \Drupal\content_migration\Exception\ExtractionProfileNotFoundException
   *   If the profile is not found.
   */
  public function getExtractionProfile(string $profileId): array {
    $config = $this->configFactory->get(ContentMigrationConstants::CONFIG_KEY);
    $profiles = $config->get('extraction_profiles') ?: [];

    if (!isset($profiles[$profileId])) {
      throw new ExtractionProfileNotFoundException($profileId);
    }

    return $profiles[$profileId];
  }

  /**
   * Gets all available extraction profiles.
   *
   * @return array
   *   An array of extraction profiles keyed by profile ID.
   */
  public function getExtractionProfiles(): array {
    $config = $this->configFactory->get(ContentMigrationConstants::CONFIG_KEY);
    return $config->get('extraction_profiles') ?: [];
  }

  /**
   * Checks if an extraction profile exists.
   *
   * @param string $profileId
   *   The profile ID to check.
   *
   * @return bool
   *   TRUE if the profile exists, FALSE otherwise.
   */
  public function profileExists(string $profileId): bool {
    $profiles = $this->getExtractionProfiles();
    return isset($profiles[$profileId]);
  }

  /**
   * Gets extraction profiles for a specific content type.
   *
   * Returns profiles that are associated with the given content type,
   * plus legacy profiles that have no content_type set (for backwards
   * compatibility).
   *
   * @param string $contentType
   *   The content type machine name.
   *
   * @return array
   *   An array of extraction profiles keyed by profile ID.
   */
  public function getProfilesForContentType(string $contentType): array {
    $allProfiles = $this->getExtractionProfiles();
    $filteredProfiles = [];

    foreach ($allProfiles as $profileId => $profile) {
      // Include profile if:
      // 1. It matches the content type, OR
      // 2. It has no content_type set (legacy profile, backwards compatible).
      $profileContentType = $profile['content_type'] ?? '';
      if (empty($profileContentType) || $profileContentType === $contentType) {
        $filteredProfiles[$profileId] = $profile;
      }
    }

    return $filteredProfiles;
  }

  /**
   * Gets content highlight rules from configuration.
   *
   * @return array
   *   An array of highlight rules.
   */
  public function getContentHighlights(): array {
    $config = $this->configFactory->get(ContentMigrationConstants::CONFIG_KEY);
    return $config->get('content_highlights') ?: [];
  }

  /**
   * Applies content highlights to HTML content.
   *
   * @param string $html
   *   The HTML content to process.
   *
   * @return string
   *   The HTML content with highlights applied.
   */
  public function applyContentHighlights(string $html): string {
    $highlights = $this->getContentHighlights();

    if (empty($highlights)) {
      return $html;
    }

    return $this->htmlParser->applyHighlights($html, $highlights);
  }

  /**
   * Gets field mappings for a content type.
   *
   * @param string $contentType
   *   The content type machine name.
   *
   * @return array
   *   An array of field mappings for the content type.
   */
  public function getFieldMappings(string $contentType): array {
    $config = $this->configFactory->get(ContentMigrationConstants::CONFIG_KEY);
    $allMappings = $config->get('content_type_field_mappings') ?: [];

    return $allMappings[$contentType] ?? [];
  }

  /**
   * Processes extractions and separates field mappings from paragraphs.
   *
   * @param array $extractions
   *   The extractions from profile-based extraction.
   * @param string $contentType
   *   The target content type.
   *
   * @return array
   *   An array with 'field_extractions' and 'paragraph_extractions'.
   */
  public function processExtractions(array $extractions, string $contentType): array {
    $fieldMappings = $this->getFieldMappings($contentType);

    $paragraphExtractions = [];
    $fieldExtractions = [];

    foreach ($extractions as $extraction) {
      $target = $extraction['paragraph_type'];

      // Check if target is a field mapping (e.g., 'field:introduction_content').
      if (str_starts_with($target, 'field:')) {
        $fieldKey = substr($target, 6);
        $fieldExtractions[$fieldKey][] = $extraction['content'];
      }
      else {
        // Regular paragraph type.
        $paragraphExtractions[] = $extraction;
      }
    }

    return [
      'field_extractions' => $fieldExtractions,
      'paragraph_extractions' => $paragraphExtractions,
      'field_mappings' => $fieldMappings,
    ];
  }

}
