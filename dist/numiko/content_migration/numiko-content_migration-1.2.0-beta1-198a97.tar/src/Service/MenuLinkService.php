<?php

declare(strict_types=1);

namespace Drupal\content_migration\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\menu_link_content\MenuLinkContentInterface;
use Drupal\node\NodeInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for creating and managing menu links.
 *
 * This service encapsulates menu link creation logic extracted from
 * ContentImportController.
 */
class MenuLinkService {

  use StringTranslationTrait;

  /**
   * Constructs a MenuLinkService object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    protected readonly MessengerInterface $messenger,
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * Creates a menu link for a node.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to create a menu link for.
   * @param string|null $parentMenuPluginId
   *   The parent menu item plugin ID (e.g., 'menu_link_content:uuid').
   * @param string $menuName
   *   The menu to add the link to. Defaults to 'main'.
   * @param int $weight
   *   The menu link weight for ordering. Defaults to 0.
   * @param bool $expanded
   *   Whether the menu link should be expanded. Defaults to FALSE.
   * @param bool $enabled
   *   Whether the menu link should be enabled. Defaults to TRUE.
   *
   * @return \Drupal\menu_link_content\MenuLinkContentInterface|null
   *   The created menu link entity, or NULL if creation failed.
   */
  public function createMenuLink(
    NodeInterface $node,
    ?string $parentMenuPluginId = NULL,
    string $menuName = ContentMigrationConstants::DEFAULT_MENU_NAME,
    int $weight = 0,
    bool $expanded = FALSE,
    bool $enabled = TRUE,
  ): ?MenuLinkContentInterface {
    try {
      $menuLinkData = [
        'title' => $node->getTitle(),
        'link' => ['uri' => 'entity:node/' . $node->id()],
        'menu_name' => $menuName,
        'weight' => $weight,
        'expanded' => $expanded,
        'enabled' => $enabled,
      ];

      // Only set parent if provided.
      if ($parentMenuPluginId !== NULL) {
        $menuLinkData['parent'] = $parentMenuPluginId;
      }

      /** @var \Drupal\menu_link_content\MenuLinkContentInterface $menuLink */
      $menuLink = $this->entityTypeManager
        ->getStorage('menu_link_content')
        ->create($menuLinkData);
      $menuLink->save();

      $this->messenger->addStatus($this->t('Menu link created for node @title.', [
        '@title' => $node->getTitle(),
      ]));

      return $menuLink;
    }
    catch (\Exception $e) {
      $this->logger->error('Failed to create menu link for node @nid: @error', [
        '@nid' => $node->id(),
        '@error' => $e->getMessage(),
      ]);

      $this->messenger->addWarning($this->t('Failed to create menu link for node @title: @error', [
        '@title' => $node->getTitle(),
        '@error' => $e->getMessage(),
      ]));

      return NULL;
    }
  }

  /**
   * Creates a menu link with hierarchy support for CSV imports.
   *
   * This method is specifically designed for batch imports where menu
   * hierarchy needs to be built incrementally.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to create a menu link for.
   * @param string $pageTitle
   *   The title to use for the menu link.
   * @param string|null $parentMenuPluginId
   *   The parent menu item plugin ID.
   * @param int $weight
   *   The menu link weight.
   * @param string $menuName
   *   The menu name. Defaults to 'main'.
   *
   * @return \Drupal\menu_link_content\MenuLinkContentInterface|null
   *   The created menu link entity, or NULL if creation failed.
   */
  public function createHierarchicalMenuLink(
    NodeInterface $node,
    string $pageTitle,
    ?string $parentMenuPluginId = NULL,
    int $weight = 0,
    string $menuName = ContentMigrationConstants::DEFAULT_MENU_NAME,
  ): ?MenuLinkContentInterface {
    try {
      $menuLinkData = [
        'title' => $pageTitle,
        'link' => ['uri' => 'entity:node/' . $node->id()],
        'menu_name' => $menuName,
        'weight' => $weight,
        'expanded' => TRUE,
        'enabled' => TRUE,
      ];

      if ($parentMenuPluginId !== NULL) {
        $menuLinkData['parent'] = $parentMenuPluginId;
      }

      /** @var \Drupal\menu_link_content\MenuLinkContentInterface $menuLink */
      $menuLink = $this->entityTypeManager
        ->getStorage('menu_link_content')
        ->create($menuLinkData);
      $menuLink->save();

      return $menuLink;
    }
    catch (\Exception $e) {
      $this->logger->error('Failed to create hierarchical menu link for node @nid: @error', [
        '@nid' => $node->id(),
        '@error' => $e->getMessage(),
      ]);

      return NULL;
    }
  }

  /**
   * Gets the plugin ID from a menu link entity.
   *
   * @param \Drupal\menu_link_content\MenuLinkContentInterface $menuLink
   *   The menu link entity.
   *
   * @return string
   *   The plugin ID.
   */
  public function getPluginId(MenuLinkContentInterface $menuLink): string {
    return $menuLink->getPluginId();
  }

}
