<?php

declare(strict_types=1);

namespace Drupal\content_migration\Service;

use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\node\NodeInterface;
use Drupal\redirect\Entity\Redirect;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for creating URL redirects.
 *
 * This service encapsulates redirect creation logic extracted from
 * ContentImportController.
 */
class RedirectService {

  use StringTranslationTrait;

  /**
   * Constructs a RedirectService object.
   *
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $moduleHandler
   *   The module handler.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    protected readonly ModuleHandlerInterface $moduleHandler,
    protected readonly MessengerInterface $messenger,
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * Checks if the redirect module is available.
   *
   * @return bool
   *   TRUE if the redirect module is enabled, FALSE otherwise.
   */
  public function isRedirectModuleEnabled(): bool {
    return $this->moduleHandler->moduleExists('redirect');
  }

  /**
   * Creates a redirect from a source URL to a node.
   *
   * @param string $sourceUrl
   *   The original URL to redirect from.
   * @param \Drupal\node\NodeInterface $node
   *   The node to redirect to.
   * @param int $statusCode
   *   The HTTP status code for the redirect. Defaults to 301.
   *
   * @return bool
   *   TRUE if the redirect was created successfully, FALSE otherwise.
   */
  public function createRedirect(string $sourceUrl, NodeInterface $node, int $statusCode = 301): bool {
    // Check if redirect module is available.
    if (!$this->isRedirectModuleEnabled()) {
      $this->messenger->addWarning($this->t('Redirect module is not enabled. Cannot create redirect for @url', [
        '@url' => $sourceUrl,
      ]));
      return FALSE;
    }

    try {
      // Parse the URL to get just the path.
      $parsedUrl = parse_url($sourceUrl);
      $sourcePath = $parsedUrl['path'] ?? '';

      // Remove leading slash if present.
      $sourcePath = ltrim($sourcePath, '/');

      if (empty($sourcePath)) {
        $this->logger->warning('Cannot create redirect: empty source path from URL @url', [
          '@url' => $sourceUrl,
        ]);
        return FALSE;
      }

      // Check if a redirect already exists for this source.
      if ($this->redirectExists($sourcePath)) {
        $this->logger->info('Redirect already exists for path @path, skipping.', [
          '@path' => $sourcePath,
        ]);
        return FALSE;
      }

      // Create the redirect.
      $redirect = Redirect::create([
        'redirect_source' => $sourcePath,
        'redirect_redirect' => 'internal:/node/' . $node->id(),
        'language' => $node->language()->getId(),
        'status_code' => $statusCode,
      ]);
      $redirect->save();

      $this->messenger->addStatus($this->t('Redirect created from @source to node @title.', [
        '@source' => $sourcePath,
        '@title' => $node->getTitle(),
      ]));

      return TRUE;
    }
    catch (\Exception $e) {
      $this->logger->error('Failed to create redirect from @url: @error', [
        '@url' => $sourceUrl,
        '@error' => $e->getMessage(),
      ]);

      $this->messenger->addWarning($this->t('Failed to create redirect from @url: @error', [
        '@url' => $sourceUrl,
        '@error' => $e->getMessage(),
      ]));

      return FALSE;
    }
  }

  /**
   * Creates redirects for multiple URLs to a single node.
   *
   * @param array $sourceUrls
   *   Array of source URLs to redirect from.
   * @param \Drupal\node\NodeInterface $node
   *   The node to redirect to.
   * @param int $statusCode
   *   The HTTP status code for the redirects. Defaults to 301.
   *
   * @return array
   *   An array with 'success' and 'failed' counts.
   */
  public function createMultipleRedirects(array $sourceUrls, NodeInterface $node, int $statusCode = 301): array {
    $results = [
      'success' => 0,
      'failed' => 0,
    ];

    foreach ($sourceUrls as $url) {
      if ($this->createRedirect($url, $node, $statusCode)) {
        $results['success']++;
      }
      else {
        $results['failed']++;
      }
    }

    return $results;
  }

  /**
   * Checks if a redirect already exists for the given source path.
   *
   * @param string $sourcePath
   *   The source path to check.
   *
   * @return bool
   *   TRUE if a redirect exists, FALSE otherwise.
   */
  protected function redirectExists(string $sourcePath): bool {
    if (!$this->isRedirectModuleEnabled()) {
      return FALSE;
    }

    $redirects = \Drupal::entityTypeManager()
      ->getStorage('redirect')
      ->loadByProperties([
        'redirect_source__path' => $sourcePath,
      ]);

    return !empty($redirects);
  }

}
