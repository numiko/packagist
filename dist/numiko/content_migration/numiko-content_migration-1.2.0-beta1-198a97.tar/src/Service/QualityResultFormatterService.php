<?php

declare(strict_types=1);

namespace Drupal\content_migration\Service;

use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\content_migration\Plugin\QualityAnalysis\QualityAnalysisPluginBase;
use Drupal\node\NodeInterface;

/**
 * Service for formatting quality assessment results.
 */
class QualityResultFormatterService {

  use StringTranslationTrait;

  /**
   * Constructs a QualityResultFormatterService object.
   *
   * @param \Drupal\Core\StringTranslation\TranslationInterface $stringTranslation
   *   The string translation service.
   */
  public function __construct(
    TranslationInterface $stringTranslation,
  ) {
    $this->setStringTranslation($stringTranslation);
  }

  /**
   * Formats section-based analysis with side-by-side comparison.
   *
   * @param array $sections
   *   The sections array from factual accuracy analysis.
   *
   * @return string
   *   Formatted HTML with three-column layout.
   */
  public function formatSectionAnalysis(array $sections): string {
    $output = '<div class="quality-sections">';
    $output .= '<h4>' . $this->t('Section-by-Section Before/After Comparison:') . '</h4>';

    foreach ($sections as $section) {
      $score_class = $this->getScoreClass($section['accuracy_score']);

      // Section container.
      $output .= '<div class="section-comparison" style="margin-bottom: 30px; border: 1px solid #ddd; border-radius: 5px; overflow: hidden;">';

      // Section header with score.
      $output .= '<div style="background-color: #f5f5f5; padding: 10px 15px; border-bottom: 2px solid #ddd;">';
      $output .= '<strong style="font-size: 1.1em;">Section ' . htmlspecialchars($section['number']) . ':</strong> ';
      $output .= '<span>' . htmlspecialchars($section['description']) . '</span>';
      $output .= '<span style="float: right;">';
      $output .= '<span style="font-weight: bold; margin-right: 5px;">Accuracy:</span>';
      $output .= '<span class="' . $score_class . '" style="font-weight: bold; font-size: 1.1em;">' . htmlspecialchars($section['accuracy_score']) . '</span>';
      $output .= '</span>';
      $output .= '</div>';

      // Use table for three-column layout.
      $output .= '<table style="width: 100%; border-collapse: collapse; table-layout: fixed;">';
      $output .= '<thead>';
      $output .= '<tr>';
      $output .= '<th style="width: 33.33%; padding: 10px; background-color: #fffbf0; border-right: 1px solid #ddd; border-bottom: 2px solid #ddd; color: #856404; font-size: 0.9em; text-transform: uppercase; text-align: left;">Original Field</th>';
      $output .= '<th style="width: 33.33%; padding: 10px; background-color: #f0f8ff; border-right: 1px solid #ddd; border-bottom: 2px solid #ddd; color: #0056b3; font-size: 0.9em; text-transform: uppercase; text-align: left;">New Field</th>';
      $output .= '<th style="width: 33.33%; padding: 10px; background-color: #f9f9f9; border-bottom: 2px solid #ddd; color: #555; font-size: 0.9em; text-transform: uppercase; text-align: left;">Differences</th>';
      $output .= '</tr>';
      $output .= '</thead>';
      $output .= '<tbody>';
      $output .= '<tr>';

      // Column 1: Original Text.
      $output .= '<td style="padding: 15px; background-color: #fffbf0; border-right: 1px solid #ddd; vertical-align: top;">';
      $output .= '<div style="font-size: 0.95em; line-height: 1.5; color: #333;">';
      if (!empty($section['original_text'])) {
        $output .= nl2br(htmlspecialchars($section['original_text']));
      }
      else {
        $output .= '<em style="color: #999;">No text extracted</em>';
      }
      $output .= '</div>';
      $output .= '</td>';

      // Column 2: New Text.
      $output .= '<td style="padding: 15px; background-color: #f0f8ff; border-right: 1px solid #ddd; vertical-align: top;">';
      $output .= '<div style="font-size: 0.95em; line-height: 1.5; color: #333;">';
      if (!empty($section['new_text'])) {
        $output .= nl2br(htmlspecialchars($section['new_text']));
      }
      else {
        $output .= '<em style="color: #999;">No text extracted</em>';
      }
      $output .= '</div>';
      $output .= '</td>';

      // Column 3: Differences.
      $output .= '<td style="padding: 15px; background-color: #f9f9f9; vertical-align: top;">';
      $output .= $this->formatDifferences($section['differences'] ?? []);
      $output .= '</td>';

      $output .= '</tr>';
      $output .= '</tbody>';
      $output .= '</table>';
      $output .= '</div>';
    }

    $output .= '</div>';

    return $output;
  }

  /**
   * Formats differences list.
   *
   * @param array $differences
   *   The differences array.
   *
   * @return string
   *   Formatted HTML.
   */
  protected function formatDifferences(array $differences): string {
    if (empty($differences)) {
      return '<p style="color: #999; font-style: italic; font-size: 0.9em; margin: 0;">No differences noted</p>';
    }

    $output = '<ul style="margin: 0; padding-left: 20px; font-size: 0.9em; list-style-type: none;">';

    foreach ($differences as $diff) {
      if ($diff['type'] === 'NONE') {
        $output .= '<li style="color: #28a745; margin-bottom: 8px;">';
        $output .= '✓ <em>' . htmlspecialchars($diff['description']) . '</em>';
        $output .= '</li>';
      }
      else {
        $badge_style = 'display: inline-block; padding: 3px 8px; border-radius: 3px; font-size: 0.75em; font-weight: bold; margin-right: 6px; text-transform: uppercase; white-space: nowrap;';
        $badge_color = $this->getDifferenceBadgeColor($diff['type']);

        $output .= '<li style="margin-bottom: 10px; line-height: 1.6;">';
        $output .= '<div><span style="' . $badge_style . $badge_color . '">' . htmlspecialchars($diff['type']) . '</span></div>';
        $output .= '<div style="margin-top: 4px; color: #333;">' . htmlspecialchars($diff['description']) . '</div>';
        $output .= '</li>';
      }
    }

    $output .= '</ul>';

    return $output;
  }

  /**
   * Gets the badge color style for a difference type.
   *
   * @param string $type
   *   The difference type.
   *
   * @return string
   *   The CSS color style.
   */
  protected function getDifferenceBadgeColor(string $type): string {
    return match($type) {
      'NEW' => 'background-color: #007bff; color: #fff;',
      'MISSING' => 'background-color: #ffc107; color: #856404;',
      'CHANGED' => 'background-color: #17a2b8; color: #fff;',
      'INCORRECT' => 'background-color: #dc3545; color: #fff;',
      default => 'background-color: #6c757d; color: #fff;',
    };
  }

  /**
   * Formats the quality scores for display.
   *
   * @param array $scores
   *   The scores array.
   *
   * @return string
   *   Formatted HTML.
   */
  public function formatScores(array $scores): string {
    $output = '<div class="quality-scores">';
    $output .= '<h4>' . $this->t('Quality Scores by Area:') . '</h4>';
    $output .= '<table class="quality-scores-table">';
    $output .= '<thead><tr><th>' . $this->t('Area') . '</th><th>' . $this->t('Score') . '</th><th>' . $this->t('Comments') . '</th></tr></thead>';
    $output .= '<tbody>';

    foreach ($scores as $area => $data) {
      $score_class = $this->getScoreClass($data['score']);
      $output .= '<tr>';
      $output .= '<td><strong>' . htmlspecialchars($area) . '</strong></td>';
      $output .= '<td class="' . $score_class . '">' . htmlspecialchars($data['score']) . '</td>';
      $output .= '<td>' . htmlspecialchars($data['comments'] ?? '') . '</td>';
      $output .= '</tr>';
    }

    $output .= '</tbody>';
    $output .= '</table>';
    $output .= '</div>';

    return $output;
  }

  /**
   * Gets the CSS class for a score.
   *
   * @param string $score
   *   The score value.
   *
   * @return string
   *   The CSS class.
   */
  public function getScoreClass(string $score): string {
    // Extract numeric value if it's in format like "8/10" or "80%".
    $numeric = 0;
    if (preg_match('/(\d+)\s*\/\s*(\d+)/', $score, $matches)) {
      $numeric = ((int) $matches[1] / (int) $matches[2]) * 100;
    }
    elseif (preg_match('/(\d+)\s*%/', $score, $matches)) {
      $numeric = (int) $matches[1];
    }
    elseif (is_numeric($score)) {
      $numeric = (float) $score;
      // Assume 0-10 scale.
      if ($numeric <= 10) {
        $numeric = $numeric * 10;
      }
    }

    if ($numeric >= 80) {
      return 'score-excellent';
    }
    elseif ($numeric >= 60) {
      return 'score-good';
    }
    elseif ($numeric >= 40) {
      return 'score-fair';
    }
    else {
      return 'score-poor';
    }
  }

  /**
   * Builds a JSON structure for assessment results.
   *
   * This follows the schema defined in QualityAnalysisPluginBase.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node being assessed.
   * @param array $results
   *   The assessment results array from checkQuality().
   *
   * @return array
   *   Structured array ready for JSON encoding.
   */
  public function buildJsonResults(NodeInterface $node, array $results): array {
    $timestamp = time();
    $json_structure = [
      'schema_version' => '1.0',
      'node_id' => (int) $node->id(),
      'node_title' => $node->getTitle(),
      'assessment_timestamp' => $timestamp,
      'assessment_date' => date('Y-m-d H:i:s', $timestamp),
      'assessments' => [],
    ];

    if (!empty($results['assessments'])) {
      foreach ($results['assessments'] as $assessment_key => $assessment_data) {
        $assessment_entry = $this->buildAssessmentEntry($assessment_key, $assessment_data, $results);
        $json_structure['assessments'][] = $assessment_entry;
      }
    }

    return $json_structure;
  }

  /**
   * Builds a single assessment entry for JSON output.
   *
   * @param string $assessment_key
   *   The assessment key.
   * @param array $assessment_data
   *   The assessment data.
   * @param array $results
   *   The full results array for context (e.g., audience_term_id).
   *
   * @return array
   *   The assessment entry.
   */
  protected function buildAssessmentEntry(string $assessment_key, array $assessment_data, array $results): array {
    $assessment_results = $assessment_data['results'];
    $content_label = $assessment_data['label'];
    $content_type = $this->determineContentType($assessment_key);

    // Get plugin information from assessment data.
    $plugin_id = $assessment_data['plugin_id'] ?? 'unknown';
    $plugin_label = $assessment_data['plugin_label'] ?? 'Unknown Plugin';

    // Build assessment entry.
    $assessment_entry = [
      'plugin_id' => $plugin_id,
      'plugin_label' => $plugin_label,
      'content_label' => $content_label,
      'content_type' => $content_type,
    ];

    // Add overall score.
    if (!empty($assessment_results['overall_score'])) {
      $assessment_entry['overall_score'] = $assessment_results['overall_score'];
      $assessment_entry['overall_score_numeric'] = QualityAnalysisPluginBase::normalizeScore($assessment_results['overall_score']);
    }

    // Add detailed scores.
    if (!empty($assessment_results['scores'])) {
      $assessment_entry['scores'] = [];
      foreach ($assessment_results['scores'] as $area => $data) {
        $assessment_entry['scores'][$area] = [
          'score' => $data['score'],
          'score_numeric' => QualityAnalysisPluginBase::normalizeScore($data['score']),
          'comments' => $data['comments'] ?? '',
        ];
      }
    }

    // Add summary.
    if (!empty($assessment_results['summary'])) {
      $assessment_entry['summary'] = $assessment_results['summary'];
    }

    // Add sections array (for factual accuracy plugin with side-by-side comparison).
    if (!empty($assessment_results['sections'])) {
      $assessment_entry['sections'] = $assessment_results['sections'];
    }

    // Add factual differences array (for factual accuracy plugin).
    if (!empty($assessment_results['factual_differences'])) {
      $assessment_entry['factual_differences'] = $assessment_results['factual_differences'];
    }

    // Add raw response if available (useful for debugging).
    if (!empty($assessment_results['raw_response'])) {
      $assessment_entry['raw_response'] = $assessment_results['raw_response'];
    }

    // Add audience term ID if available.
    $assessment_entry['audience_term_id'] = !empty($results['audience_term_id']) ? (int) $results['audience_term_id'] : NULL;

    return $assessment_entry;
  }

  /**
   * Determines content type from assessment key.
   *
   * @param string $assessment_key
   *   The assessment key.
   *
   * @return string
   *   The content type.
   */
  protected function determineContentType(string $assessment_key): string {
    if (str_starts_with($assessment_key, 'paragraph_')) {
      return 'paragraph';
    }
    elseif (str_starts_with($assessment_key, 'rewritten_content_')) {
      return 'rewritten';
    }
    elseif ($assessment_key === 'factual_accuracy_comparison') {
      return 'comparison';
    }
    elseif (str_starts_with($assessment_key, 'original_content_')) {
      return 'original';
    }
    return 'original';
  }

}
