<?php

declare(strict_types=1);

namespace Drupal\content_migration\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Exception\ContentFetchException;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for fetching content from URLs.
 *
 * This service handles HTTP operations only. For HTML parsing and
 * transformation, use HtmlParserService.
 */
class UrlContentFetcherService {

  /**
   * Constructs a UrlContentFetcherService object.
   *
   * @param \GuzzleHttp\ClientInterface $httpClient
   *   The HTTP client.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   * @param \Drupal\content_migration\Service\HtmlParserService $htmlParser
   *   The HTML parser service.
   */
  public function __construct(
    protected readonly ClientInterface $httpClient,
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
    protected readonly HtmlParserService $htmlParser,
  ) {}

  /**
   * Fetches content from a URL.
   *
   * @param string $url
   *   The URL to fetch content from.
   * @param int|null $timeout
   *   Optional timeout in seconds.
   *
   * @return string
   *   The HTML content from the URL.
   *
   * @throws \Drupal\content_migration\Exception\ContentFetchException
   *   Throws an exception if the content cannot be fetched.
   */
  public function fetchContent(string $url, ?int $timeout = NULL): string {
    $timeout = $timeout ?? ContentMigrationConstants::DEFAULT_API_TIMEOUT;

    try {
      $response = $this->httpClient->request('GET', $url, [
        'headers' => [
          'User-Agent' => 'Mozilla/5.0 (compatible; Drupal/10.0; +http://drupal.org/)',
        ],
        'timeout' => $timeout,
      ]);

      $content_type = $response->getHeaderLine('Content-Type');
      if (strpos($content_type, 'text/html') === FALSE && strpos($content_type, 'application/xhtml+xml') === FALSE) {
        throw ContentFetchException::invalidContentType($url, $content_type);
      }

      $body = (string) $response->getBody();
      if (empty($body)) {
        throw ContentFetchException::emptyResponse($url);
      }

      return $body;
    }
    catch (RequestException $e) {
      $this->logger->error(
        'Error fetching URL @url: @error',
        ['@url' => $url, '@error' => $e->getMessage()]
      );
      throw ContentFetchException::httpError($url, $e->getCode() ?: 0, $e);
    }
  }

  /**
   * Sanitizes and extracts the main content from HTML.
   *
   * This is a facade method that delegates to HtmlParserService.
   *
   * @param string $html
   *   The raw HTML content.
   * @param string $mode
   *   The extraction mode: 'article' (default) or 'full_page'.
   * @param string|null $selector
   *   Optional CSS selector to extract specific content.
   * @param array|null $tags_to_remove
   *   Optional array of selectors to remove.
   *
   * @return array
   *   The sanitized HTML content with unnecessary parts removed & the title.
   *
   * @throws \Drupal\content_migration\Exception\ContentParseException
   *   If parsing fails.
   */
  public function sanitizeHtml(string $html, string $mode = ContentMigrationConstants::EXTRACTION_MODE_ARTICLE, ?string $selector = NULL, ?array $tags_to_remove = NULL): array {
    return $this->htmlParser->sanitizeHtml($html, $mode, $selector, $tags_to_remove);
  }

  /**
   * Extract content using an extraction profile.
   *
   * This is a facade method that delegates to HtmlParserService.
   *
   * @param string $html
   *   The raw HTML content.
   * @param array $profile
   *   The extraction profile.
   *
   * @return array
   *   The extraction result.
   */
  public function extractWithProfile(string $html, array $profile): array {
    return $this->htmlParser->extractWithProfile($html, $profile);
  }

  /**
   * Apply highlight styles to content.
   *
   * This is a facade method that delegates to HtmlParserService.
   *
   * @param string $html
   *   The HTML content to process.
   * @param array $highlights
   *   Array of highlight rules.
   *
   * @return string
   *   The HTML content with highlights applied.
   */
  public function applyHighlights(string $html, array $highlights): string {
    return $this->htmlParser->applyHighlights($html, $highlights);
  }

  /**
   * Gets the HTML parser service.
   *
   * @return \Drupal\content_migration\Service\HtmlParserService
   *   The HTML parser service.
   */
  public function getHtmlParser(): HtmlParserService {
    return $this->htmlParser;
  }

}
