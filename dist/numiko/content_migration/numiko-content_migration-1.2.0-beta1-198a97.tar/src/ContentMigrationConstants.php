<?php

declare(strict_types=1);

namespace Drupal\content_migration;

/**
 * Constants for the content migration module.
 *
 * This class centralizes hard-coded values used throughout the module
 * to improve maintainability and provide a single source of truth.
 */
final class ContentMigrationConstants {

  /**
   * Default paragraph type for content slices.
   */
  public const DEFAULT_PARAGRAPH_TYPE = 'slice_content';

  /**
   * Default text format for full HTML content.
   */
  public const DEFAULT_TEXT_FORMAT_FULL = 'full_html';

  /**
   * Default text format for basic HTML content.
   */
  public const DEFAULT_TEXT_FORMAT_BASIC = 'basic_html';

  /**
   * Default menu name for menu links.
   */
  public const DEFAULT_MENU_NAME = 'main';

  /**
   * Default API request timeout in seconds.
   */
  public const DEFAULT_API_TIMEOUT = 600;

  /**
   * Default admin user ID.
   */
  public const DEFAULT_ADMIN_UID = 1;

  /**
   * Field name for paragraph content.
   */
  public const PARAGRAPH_CONTENT_FIELD = 'field_content';

  /**
   * Composite key delimiter.
   */
  public const COMPOSITE_KEY_DELIMITER = ':';

  /**
   * Prefix for paragraph field composite keys.
   */
  public const PARAGRAPH_FIELD_PREFIX = 'paragraph';

  /**
   * Prefix for text field composite keys.
   */
  public const TEXT_FIELD_PREFIX = 'text';

  /**
   * Configuration key for the module settings.
   */
  public const CONFIG_KEY = 'content_migration.settings';

  /**
   * Logger channel name for the module.
   */
  public const LOGGER_CHANNEL = 'content_migration';

  /**
   * Extraction mode for article content.
   */
  public const EXTRACTION_MODE_ARTICLE = 'article';

  /**
   * Extraction mode for full page content.
   */
  public const EXTRACTION_MODE_FULL_PAGE = 'full_page';

}
