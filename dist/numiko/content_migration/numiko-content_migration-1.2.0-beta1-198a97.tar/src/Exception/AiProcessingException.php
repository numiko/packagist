<?php

declare(strict_types=1);

namespace Drupal\content_migration\Exception;

/**
 * Exception thrown when AI processing fails.
 *
 * This exception is thrown when content processing via AI (Claude API)
 * fails due to invalid responses, processing errors, or unexpected formats.
 */
class AiProcessingException extends ContentMigrationException {

  /**
   * Error code for AI processing failures.
   */
  public const ERROR_AI_PROCESSING = 10;

  /**
   * Constructs a new AiProcessingException.
   *
   * @param string $message
   *   The exception message.
   * @param int $code
   *   The exception code.
   * @param \Throwable|null $previous
   *   The previous exception used for exception chaining.
   */
  public function __construct(
    string $message = 'AI processing failed.',
    int $code = self::ERROR_AI_PROCESSING,
    ?\Throwable $previous = NULL,
  ) {
    parent::__construct($message, $code, $previous);
  }

  /**
   * Creates an exception for invalid API response format.
   *
   * @param string $details
   *   Additional details about the invalid format.
   *
   * @return static
   *   A new exception instance.
   */
  public static function invalidResponseFormat(string $details = ''): static {
    $message = 'Invalid response format from Claude API.';
    if ($details) {
      $message .= ' ' . $details;
    }
    return new static($message);
  }

  /**
   * Creates an exception for content rewriting failure.
   *
   * @param string $reason
   *   The reason for the failure.
   *
   * @return static
   *   A new exception instance.
   */
  public static function rewriteFailed(string $reason = ''): static {
    $message = 'Failed to rewrite content.';
    if ($reason) {
      $message .= ' ' . $reason;
    }
    return new static($message);
  }

  /**
   * Creates an exception for content summarization failure.
   *
   * @param string $reason
   *   The reason for the failure.
   *
   * @return static
   *   A new exception instance.
   */
  public static function summarizeFailed(string $reason = ''): static {
    $message = 'Failed to create structured summary of content.';
    if ($reason) {
      $message .= ' ' . $reason;
    }
    return new static($message);
  }

  /**
   * Creates an exception for API call failure.
   *
   * @param string $originalError
   *   The original error message.
   *
   * @return static
   *   A new exception instance.
   */
  public static function apiCallFailed(string $originalError): static {
    return new static("Failed to process content with Claude API: $originalError");
  }

}
