<?php

declare(strict_types=1);

namespace Drupal\content_migration\Exception;

/**
 * Base exception for content migration operations.
 *
 * All content migration specific exceptions should extend this class
 * to allow catching all module-related exceptions with a single catch block.
 */
class ContentMigrationException extends \RuntimeException {

  /**
   * Error code for unknown errors.
   */
  public const ERROR_UNKNOWN = 0;

  /**
   * Error code for content fetching failures.
   */
  public const ERROR_FETCH = 1;

  /**
   * Error code for content parsing failures.
   */
  public const ERROR_PARSE = 2;

  /**
   * Error code for configuration errors.
   */
  public const ERROR_CONFIG = 3;

  /**
   * Error code for extraction profile errors.
   */
  public const ERROR_PROFILE = 4;

}
