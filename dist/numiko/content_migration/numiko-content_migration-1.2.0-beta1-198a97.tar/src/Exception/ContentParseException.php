<?php

declare(strict_types=1);

namespace Drupal\content_migration\Exception;

/**
 * Exception thrown when content parsing fails.
 *
 * This exception is thrown when HTML parsing, DOM manipulation,
 * or content extraction fails due to malformed content or other parsing issues.
 */
class ContentParseException extends ContentMigrationException {

  /**
   * Constructs a new ContentParseException.
   *
   * @param string $message
   *   The exception message.
   * @param int $code
   *   The exception code.
   * @param \Throwable|null $previous
   *   The previous exception used for exception chaining.
   */
  public function __construct(
    string $message = 'Failed to parse content.',
    int $code = self::ERROR_PARSE,
    ?\Throwable $previous = NULL,
  ) {
    parent::__construct($message, $code, $previous);
  }

  /**
   * Creates an exception for invalid HTML.
   *
   * @param string|null $details
   *   Additional details about the parsing failure.
   *
   * @return static
   *   A new exception instance.
   */
  public static function invalidHtml(?string $details = NULL): static {
    $message = 'Failed to parse HTML content.';
    if ($details) {
      $message .= ' ' . $details;
    }
    return new static($message);
  }

  /**
   * Creates an exception for selector not found.
   *
   * @param string $selector
   *   The CSS selector that was not found.
   *
   * @return static
   *   A new exception instance.
   */
  public static function selectorNotFound(string $selector): static {
    $message = sprintf("CSS selector '%s' did not match any content.", $selector);
    return new static($message);
  }

  /**
   * Creates an exception for DOM manipulation failure.
   *
   * @param string $operation
   *   The operation that failed.
   * @param \Throwable|null $previous
   *   The previous exception.
   *
   * @return static
   *   A new exception instance.
   */
  public static function domManipulationFailed(string $operation, ?\Throwable $previous = NULL): static {
    $message = sprintf("DOM manipulation failed: %s", $operation);
    return new static($message, self::ERROR_PARSE, $previous);
  }

}
