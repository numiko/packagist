<?php

declare(strict_types=1);

namespace Drupal\content_migration\Exception;

/**
 * Exception thrown when an extraction profile is not found.
 *
 * This exception is thrown when attempting to use an extraction profile
 * that does not exist in the module configuration.
 */
class ExtractionProfileNotFoundException extends ContentMigrationException {

  /**
   * Constructs a new ExtractionProfileNotFoundException.
   *
   * @param string $profileId
   *   The ID of the profile that was not found.
   * @param int $code
   *   The exception code.
   * @param \Throwable|null $previous
   *   The previous exception used for exception chaining.
   */
  public function __construct(
    string $profileId,
    int $code = self::ERROR_PROFILE,
    ?\Throwable $previous = NULL,
  ) {
    $message = sprintf("Extraction profile '%s' not found.", $profileId);
    parent::__construct($message, $code, $previous);
  }

}
