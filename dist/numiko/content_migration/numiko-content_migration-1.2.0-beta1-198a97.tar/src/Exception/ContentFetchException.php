<?php

declare(strict_types=1);

namespace Drupal\content_migration\Exception;

/**
 * Exception thrown when content fetching fails.
 *
 * This exception is thrown when HTTP requests to fetch content from URLs
 * fail due to network errors, invalid responses, or other HTTP-related issues.
 */
class ContentFetchException extends ContentMigrationException {

  /**
   * The URL that failed to fetch.
   *
   * @var string|null
   */
  protected ?string $url = NULL;

  /**
   * Constructs a new ContentFetchException.
   *
   * @param string $message
   *   The exception message.
   * @param string|null $url
   *   The URL that failed to fetch.
   * @param int $code
   *   The exception code.
   * @param \Throwable|null $previous
   *   The previous exception used for exception chaining.
   */
  public function __construct(
    string $message,
    ?string $url = NULL,
    int $code = self::ERROR_FETCH,
    ?\Throwable $previous = NULL,
  ) {
    $this->url = $url;
    parent::__construct($message, $code, $previous);
  }

  /**
   * Gets the URL that failed to fetch.
   *
   * @return string|null
   *   The URL, or NULL if not set.
   */
  public function getUrl(): ?string {
    return $this->url;
  }

  /**
   * Creates an exception for invalid content type.
   *
   * @param string $url
   *   The URL that was fetched.
   * @param string $contentType
   *   The content type that was received.
   *
   * @return static
   *   A new exception instance.
   */
  public static function invalidContentType(string $url, string $contentType): static {
    $message = sprintf(
      "URL '%s' returned non-HTML content type: %s",
      $url,
      $contentType
    );
    return new static($message, $url);
  }

  /**
   * Creates an exception for empty response.
   *
   * @param string $url
   *   The URL that was fetched.
   *
   * @return static
   *   A new exception instance.
   */
  public static function emptyResponse(string $url): static {
    $message = sprintf("URL '%s' returned empty content.", $url);
    return new static($message, $url);
  }

  /**
   * Creates an exception for HTTP error.
   *
   * @param string $url
   *   The URL that was fetched.
   * @param int $statusCode
   *   The HTTP status code.
   * @param \Throwable|null $previous
   *   The previous exception.
   *
   * @return static
   *   A new exception instance.
   */
  public static function httpError(string $url, int $statusCode, ?\Throwable $previous = NULL): static {
    $message = sprintf(
      "Failed to fetch URL '%s': HTTP %d",
      $url,
      $statusCode
    );
    return new static($message, $url, self::ERROR_FETCH, $previous);
  }

}
