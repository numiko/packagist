<?php

declare(strict_types=1);

namespace Drupal\content_migration\Exception;

/**
 * Exception thrown when API configuration is missing or invalid.
 *
 * This exception is thrown when the Claude API key is not configured
 * or when other required API configuration is missing or invalid.
 */
class ApiConfigurationException extends ContentMigrationException {

  /**
   * Constructs a new ApiConfigurationException.
   *
   * @param string $message
   *   The exception message.
   * @param int $code
   *   The exception code.
   * @param \Throwable|null $previous
   *   The previous exception used for exception chaining.
   */
  public function __construct(
    string $message = 'API configuration is missing or invalid.',
    int $code = self::ERROR_CONFIG,
    ?\Throwable $previous = NULL,
  ) {
    parent::__construct($message, $code, $previous);
  }

  /**
   * Creates an exception for missing API key.
   *
   * @return static
   *   A new exception instance.
   */
  public static function missingApiKey(): static {
    return new static('Claude API key is not configured.');
  }

  /**
   * Creates an exception for missing API model.
   *
   * @return static
   *   A new exception instance.
   */
  public static function missingApiModel(): static {
    return new static('Claude API model is not configured.');
  }

}
