<?php

declare(strict_types=1);

namespace Drupal\content_migration\Exception;

/**
 * Exception thrown when quality analysis fails.
 *
 * This exception is thrown when content quality analysis cannot be performed
 * due to missing configuration, invalid responses, or processing errors.
 */
class QualityAnalysisException extends ContentMigrationException {

  /**
   * Error code for quality analysis failures.
   */
  public const ERROR_QUALITY_ANALYSIS = 20;

  /**
   * Constructs a new QualityAnalysisException.
   *
   * @param string $message
   *   The exception message.
   * @param int $code
   *   The exception code.
   * @param \Throwable|null $previous
   *   The previous exception used for exception chaining.
   */
  public function __construct(
    string $message = 'Quality analysis failed.',
    int $code = self::ERROR_QUALITY_ANALYSIS,
    ?\Throwable $previous = NULL,
  ) {
    parent::__construct($message, $code, $previous);
  }

  /**
   * Creates an exception for missing audience vocabulary.
   *
   * @return static
   *   A new exception instance.
   */
  public static function missingAudienceVocabulary(): static {
    return new static('No audience vocabulary is configured.');
  }

  /**
   * Creates an exception for missing style guide.
   *
   * @return static
   *   A new exception instance.
   */
  public static function missingStyleGuide(): static {
    return new static('No style guide is configured in the audience vocabulary root term.');
  }

  /**
   * Creates an exception for API response decode failure.
   *
   * @param string $error
   *   The JSON decode error message.
   *
   * @return static
   *   A new exception instance.
   */
  public static function responseDecodeFailed(string $error): static {
    return new static("Failed to decode API response: $error");
  }

}
