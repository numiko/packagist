<?php

declare(strict_types=1);

namespace Drupal\content_migration\Access;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Routing\Access\AccessInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Checks access to quality features based on configuration.
 */
class QualityFeaturesAccessCheck implements AccessInterface {

  /**
   * Constructs a QualityFeaturesAccessCheck object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   */
  public function __construct(
    protected ConfigFactoryInterface $configFactory,
  ) {}

  /**
   * Checks access to quality features.
   *
   * @param \Drupal\Core\Session\AccountInterface $account
   *   The user account.
   *
   * @return \Drupal\Core\Access\AccessResultInterface
   *   The access result.
   */
  public function access(AccountInterface $account) {
    $config = $this->configFactory->get('content_migration.settings');
    $features_enabled = $config->get('enable_quality_features') ?? TRUE;

    // Check if quality features are enabled AND user has permission.
    if ($features_enabled && $account->hasPermission('access content migration')) {
      return AccessResult::allowed();
    }

    return AccessResult::forbidden('Quality features are disabled in configuration.');
  }

}
