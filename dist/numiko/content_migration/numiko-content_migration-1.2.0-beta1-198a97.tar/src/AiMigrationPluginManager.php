<?php

declare(strict_types=1);

namespace Drupal\content_migration;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\content_migration\Attribute\AiMigration;

/**
 * Plugin manager for AI migration plugins.
 */
class AiMigrationPluginManager extends DefaultPluginManager {

  /**
   * Constructs a new AiMigrationPluginManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke hooks on.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct(
      'Plugin/AiMigration',
      $namespaces,
      $module_handler,
      AiMigrationInterface::class,
      AiMigration::class
    );

    $this->alterInfo('ai_migration_info');
    $this->setCacheBackend($cache_backend, 'ai_migration_plugins');
  }

  /**
   * Gets all available AI migration plugin definitions.
   *
   * @return array
   *   An array of plugin definitions, keyed by plugin ID.
   */
  public function getAvailablePlugins(): array {
    return $this->getDefinitions();
  }

  /**
   * Gets plugin options for form select elements.
   *
   * @return array
   *   An array of plugin labels keyed by plugin ID.
   */
  public function getPluginOptions(): array {
    $options = [];
    foreach ($this->getDefinitions() as $plugin_id => $definition) {
      $options[$plugin_id] = $definition['label'];
    }
    return $options;
  }

}
