# Content Migration

A Drupal module for AI-powered content import and transformation using the Claude API. Supports importing content from URLs, PDFs, and CSV files with intelligent extraction, rewriting, and quality analysis.

## Features

### Content Import
- **URL Import**: Extract content from web pages with article or full-page extraction modes
- **PDF Import**: Extract text content from PDF documents
- **CSV/TSV Import**: Create hierarchical page structures from spreadsheet data
- **Title Import**: Create placeholder pages from titles only
- **Merged URL Import**: Combine multiple URLs into a single page

### AI-Powered Processing
- **Content Extraction**: Intelligent extraction of main content, ignoring navigation and sidebars
- **Content Rewriting**: Automatic rewriting to match style guides with change tracking
- **Summary Generation**: Create teaser text and meta descriptions
- **Introduction Generation**: Auto-generate introductory paragraphs
- **Taxonomy Suggestions**: AI-powered tag and category recommendations

### Quality Analysis
- **Style Guide Compliance**: Validate content against configured style guides
- **Factual Accuracy**: Compare original vs rewritten content for consistency
- **Quality Dashboard**: View quality metrics across imported pages

### Integration
- **Menu Integration**: Automatically add imported content to site menus
- **URL Redirects**: Create 301 redirects from source URLs (requires Redirect module)
- **Flexible Field Mapping**: Map extracted content to any text or paragraph fields
- **Extraction Profiles**: Create reusable extraction configurations with CSS selector mappings

## Requirements

- Drupal 9.x, 10.x, or 11.x
- PHP 8.1+
- Claude API key from [Anthropic Console](https://console.anthropic.com/)
- Guzzle HTTP client (included with Drupal)

### Optional Dependencies
- **Redirect module**: For creating URL redirects from imported content
- **Menu Link Content**: For menu integration (core module)

## Installation

1. Enable the module:
   ```bash
   drush en content_migration
   ```

2. Configure your Claude API settings at `/admin/config/content/url-import`:
   - Enter your Claude API key
   - Select your preferred Claude model
   - Configure default extraction settings

## Configuration

### API Settings

Navigate to `/admin/config/content/url-import` to configure:

| Setting | Description |
|---------|-------------|
| Claude API Key | Required. Get one from [Anthropic Console](https://console.anthropic.com/) |
| Claude Model | Haiku (faster), Sonnet (balanced), or Opus (highest quality) |
| API Timeout | Request timeout in seconds |
| Default Extraction Mode | Article or Full Page |
| Default Content Selector | CSS selector for content extraction |
| Default Tags to Remove | Elements to strip (e.g., `header, footer, nav`) |
| Default Paragraph Type | Paragraph bundle for imported content |
| Default Text Format | HTML text format for content fields |

### Extraction Profiles

Create custom extraction profiles to map CSS selectors to specific fields:

1. Go to Settings > Extraction Profiles
2. Define CSS selectors for different content areas
3. Map each selector to a target field and paragraph type
4. Set weights for content ordering

### Permissions

| Permission | Description |
|------------|-------------|
| `import content from url` | Access to the import form |
| `administer site configuration` | Access to module settings |

Quality features require enabling in the module configuration.

## Usage

### URL Import

1. Navigate to `/admin/content/content-import`
2. Select **URL** as the import type
3. Choose target audience and content type
4. Enter one or more URLs (one per line)
5. Select extraction mode:

   **Article Mode** (default)
   - Uses php-readability to identify main content
   - Best for news articles and blog posts
   - Automatically removes navigation, sidebars, comments

   **Full Page Mode**
   - Extracts all body content
   - Supports CSS selector for specific content areas
   - Configurable element removal

   **Profile Mode**
   - Uses predefined extraction profiles
   - Granular CSS selector-to-field mappings

6. Map extracted content to fields:
   - Body Content Field
   - Rewritten Content Field
   - Rewrite Changes Field
7. Enable optional features:
   - Generate teaser summaries
   - Add to menu
   - Create URL redirects
8. Click **Import Content**

### PDF Import

1. Select **PDF** as the import type
2. Upload a PDF file
3. Configure content type and field mappings
4. The module extracts text and applies AI processing

### CSV Import

1. Select **CSV** as the import type
2. Upload a CSV or TSV file
3. Define column mappings for:
   - Title
   - URL (for fetching content)
   - Parent page (for hierarchy)
4. Process creates pages with parent-child relationships

### Title Import

1. Select **Title** as the import type
2. Enter page titles (one per line)
3. Creates placeholder pages ready for content

### Quality Check

1. Navigate to `/admin/content/quality-check`
2. Select a page to analyse
3. Choose quality analysis plugins to run
4. Review results with scores and recommendations

## Architecture

### Directory Structure

```
content_migration/
├── src/
│   ├── Attribute/           # PHP 8 plugin attributes
│   ├── Batch/               # Batch processing
│   ├── Controller/          # Route controllers
│   ├── Exception/           # Custom exceptions
│   ├── Form/
│   │   └── Builder/         # Form builder strategies
│   ├── Import/              # Import processor strategies
│   ├── Plugin/
│   │   ├── AiMigration/     # Content transformation plugins
│   │   └── QualityAnalysis/ # Quality analysis plugins
│   └── Service/             # Business logic services
├── tests/src/Unit/          # Unit tests
└── config/schema/           # Configuration schema
```

### Import Processors

The module uses the Strategy pattern for import types:

| Processor | Purpose |
|-----------|---------|
| `UrlImportProcessor` | Web page content extraction |
| `PdfImportProcessor` | PDF document extraction |
| `CsvImportProcessor` | Hierarchical page creation from CSV |
| `TitleImportProcessor` | Empty page creation |

### AI Migration Plugins

Extensible plugins for content transformation:

| Plugin | Purpose |
|--------|---------|
| `RewriteContent` | Rewrite content following style guides |
| `SummaryContent` | Generate teaser/meta summaries |
| `IntroductionContent` | Create introductory paragraphs |
| `TaxonomySuggestions` | Suggest taxonomy terms |
| `SiteSectionSuggestions` | Suggest site section categorisation |

### Quality Analysis Plugins

Plugins for content quality assessment:

| Plugin | Purpose |
|--------|---------|
| `StyleGuideAnalysis` | Validate style guide compliance |
| `FactualAccuracyAnalysis` | Compare original vs rewritten content |

### Core Services

| Service | Purpose |
|---------|---------|
| `UrlContentFetcherService` | HTTP fetching with validation |
| `HtmlParserService` | DOM parsing and sanitisation |
| `ContentExtractionService` | Extraction orchestration |
| `NodeBuilderService` | Node and paragraph creation |
| `MenuLinkService` | Menu link creation |
| `RedirectService` | URL redirect creation |
| `TaxonomyPromptService` | Taxonomy vocabulary management |
| `ContentQualityService` | Quality analysis coordination |

## Development

### Running Tests

```bash
docker-compose exec web ./vendor/bin/phpunit --testsuite unit
```

### Clearing Cache

After modifying services or configuration:

```bash
docker-compose exec web drush cr
```

### Coding Standards

The module follows Drupal and PHP best practices:

- `declare(strict_types=1);` in all PHP files
- Type declarations on all methods
- Constructor dependency injection (no `\Drupal::` static calls)
- Custom exceptions in `src/Exception/`
- PHP 8 attributes for plugin discovery
- PSR-4 autoloading

### Creating Custom Plugins

**AI Migration Plugin:**

```php
<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

use Drupal\content_migration\Attribute\AiMigration;
use Drupal\content_migration\Plugin\AiMigration\AiMigrationPluginBase;

#[AiMigration(
  id: 'my_custom_plugin',
  label: 'My Custom Plugin',
  description: 'Description of what this plugin does',
)]
class MyCustomPlugin extends AiMigrationPluginBase {

  public function process(string $content, array $context): array {
    // Your processing logic
    return ['result' => $processedContent];
  }

}
```

**Quality Analysis Plugin:**

```php
<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\QualityAnalysis;

use Drupal\content_migration\Attribute\QualityAnalysis;
use Drupal\content_migration\Plugin\QualityAnalysis\QualityAnalysisPluginBase;

#[QualityAnalysis(
  id: 'my_quality_check',
  label: 'My Quality Check',
  description: 'Description of this quality check',
)]
class MyQualityCheck extends QualityAnalysisPluginBase {

  public function analyze(string $content, array $context): array {
    // Your analysis logic
    return [
      'score' => 85,
      'issues' => [],
      'recommendations' => [],
    ];
  }

}
```

## Troubleshooting

### Common Issues

**"Claude API key is not configured"**
- Enter a valid API key at `/admin/config/content/url-import`

**"Invalid response format from Claude API"**
- Check API key validity and network connectivity
- Verify Claude API usage limits haven't been exceeded

**"Failed to parse JSON response"**
- Failed responses are logged for debugging
- Consider adjusting extraction settings

**Menu links not created**
- Ensure Menu Link Content module is enabled
- Verify the parent menu item exists

**Redirects not created**
- Install and enable the Redirect module
- Check that the source URL path doesn't already exist

**Field truncation warnings**
- Content exceeded field length limits
- Consider using a longer text field or adjusting extraction

### Logging

Errors are logged to the `content_migration` channel. View logs at `/admin/reports/dblog` or check your logging backend.

## Exception Handling

The module uses a custom exception hierarchy:

| Exception | When Thrown |
|-----------|-------------|
| `ContentMigrationException` | Base exception for all module errors |
| `ApiConfigurationException` | Missing or invalid API configuration |
| `ContentFetchException` | HTTP fetch failures |
| `ContentParseException` | HTML/DOM parsing errors |
| `AiProcessingException` | Claude API processing errors |
| `ExtractionProfileNotFoundException` | Missing extraction profile |
| `QualityAnalysisException` | Quality check failures |

## License

This module is licensed under the GPL v2 or later.

## Support

For issues and feature requests, please use the project's issue queue.
