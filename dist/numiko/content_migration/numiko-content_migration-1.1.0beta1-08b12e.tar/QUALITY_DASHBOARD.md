# Content Quality Dashboard

## Overview

The Content Quality Dashboard provides a comprehensive view of quality assessments across all content pages. It displays assessment results in an interactive, tabulated format with filtering, comparison, and drill-down capabilities.

## Features

### 1. Summary Statistics

At the top of the dashboard, you'll see key metrics:
- **Pages Assessed**: Total number of content pages with quality data
- **Total Assessments**: Combined count of all assessments (including original, rewritten, and paragraph assessments)
- **Average Score**: Overall average quality score across all assessments
- **Excellent Count**: Number of assessments scoring 80% or above

### 2. Filtering Capabilities

Filter the dashboard by:
- **Content Type**: Show only specific content types (e.g., Articles, Pages)
- **Minimum Score**: Filter by quality threshold
  - 80% and above (Excellent)
  - 60% and above (Good)
  - 40% and above (Fair)
  - Below 40% (Needs Improvement)

### 3. Main Dashboard Table

The table displays:
- **Page Title**: Clickable link to the content page
- **Content Type**: The Drupal content type
- **Assessment Date**: When the quality check was performed
- **Assessments**: Count and type badges showing what was assessed
  - Original content badge (blue)
  - Rewritten content badge (green)
  - Paragraph content badge (yellow)
- **Overall Score**: Average score with color coding
  - Green: Excellent (80%+)
  - Light green: Good (60-79%)
  - Orange: Fair (40-59%)
  - Red: Poor (<40%)
- **Actions**: Expand/collapse button for detailed view

### 4. Expandable Detail Views

Click "Show Details" to see:

#### Assessment Details
- Plugin information (which quality analysis plugin was used)
- Overall score with percentage
- Detailed scores by area with comments
- Full analysis summary

#### Area Scores Table
For each assessment area (e.g., Content Structure, Writing Style):
- Score with color coding
- Detailed comments from the analysis

#### Comparison View
When both original and rewritten content exist:
- **Overall Score Change**: Shows improvement or decline
- **Area-by-Area Comparison**: Table comparing scores for each area
  - Highlighted rows show significant changes (>5%)
  - Green indicates improvement
  - Red indicates decline
  - Change percentage displayed

## Access

Navigate to: **Content → Content Quality Dashboard**

Or directly: `/admin/content/quality-dashboard`

**Permission Required**: `import content from url`

## Usage Examples

### Example 1: Identify Pages Needing Improvement

1. Go to Content Quality Dashboard
2. Click "Filters"
3. Select "Below 40%" in the Minimum Score filter
4. Click "Apply Filters"
5. Review the list of pages that need attention

### Example 2: Compare Original vs Rewritten Content

1. Find a page with both "Original" and "Rewritten" badges
2. Click "Show Details"
3. Scroll to the "Original vs Rewritten Comparison" section
4. Review the score changes by area
5. Highlighted rows show the biggest improvements or declines

### Example 3: Review Specific Content Type

1. Click "Filters"
2. Select the content type from the dropdown
3. Click "Apply Filters"
4. See quality metrics for only that content type

## Technical Details

### Data Source

The dashboard reads JSON data from the configured "Quality Assessment Field" for each content type. This field is set in:

**Configuration → Content Migration → Settings → Default Field Mappings**

### Performance

- Only loads nodes that have assessment data
- Filters are applied server-side for efficiency
- Expandable rows load details on-demand
- Sorted by most recently modified first

### Color Coding

| Score Range | Color | Classification |
|-------------|-------|----------------|
| 80-100% | Green | Excellent |
| 60-79% | Light Green | Good |
| 40-59% | Orange | Fair |
| 0-39% | Red | Poor |

## Files

### PHP Classes
- **ContentQualityDashboardForm.php**: Main form controller
  - `loadAllAssessments()`: Loads all quality data from nodes
  - `calculateStatistics()`: Computes summary metrics
  - `renderDashboardTable()`: Generates the main table
  - `renderDetailView()`: Creates expandable detail views
  - `renderComparison()`: Builds comparison tables

### Routing
- **Route**: `content_migration.quality_dashboard`
- **Path**: `/admin/content/quality-dashboard`
- **Permission**: `import content from url`

### Assets
- **CSS**: `css/quality-dashboard.css`
- **JavaScript**: `js/quality-dashboard.js`
- **Library**: `content_migration/quality_dashboard`

## Integration with Quality Checker

The dashboard automatically displays data from:
1. Content Quality Checker tool (single page assessments)
2. Any content with JSON assessment data in the configured field

The JSON format follows the schema defined in `QualityAnalysisPluginBase::getResultsSchema()`.

## Future Enhancements

Potential additions to the dashboard:
- Export to CSV/Excel
- Date range filtering
- Historical trend charts
- Batch re-assessment capability
- Custom report generation
- Email notifications for poor scores
- Plugin-specific filtering
- Audience-based filtering

## Troubleshooting

### No Data Displayed

**Problem**: Dashboard shows "No quality assessment data found"

**Solutions**:
1. Run the Content Quality Checker on some pages first
2. Ensure a Quality Assessment Field is configured in Settings
3. Verify the field contains valid JSON data

### Filters Not Working

**Problem**: Filters don't seem to apply

**Solutions**:
1. Click "Apply Filters" button after making selections
2. Check browser console for JavaScript errors
3. Clear Drupal cache: `drush cr`

### Detail View Not Expanding

**Problem**: Clicking "Show Details" doesn't work

**Solutions**:
1. Check that JavaScript is enabled
2. Clear browser cache
3. Verify the quality_dashboard library is loaded (check page source)

### Incorrect Scores Displayed

**Problem**: Scores don't match individual assessments

**Solutions**:
1. Re-run quality check on the page
2. Verify JSON data format in the field
3. Check for JSON parsing errors in logs

## Related Documentation

- [JSON Schema Documentation](QUALITY_ASSESSMENT_JSON_SCHEMA.md)
- [Quality Analysis Plugin Base](src/Plugin/QualityAnalysisPluginBase.php)
- [Content Quality Checker Form](src/Form/ContentQualityCheckForm.php)
