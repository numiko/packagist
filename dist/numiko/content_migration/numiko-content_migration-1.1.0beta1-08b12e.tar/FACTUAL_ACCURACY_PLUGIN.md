# Factual Accuracy Analysis Plugin

## Overview

The Factual Accuracy Analysis plugin is a quality analysis tool that compares content from different fields **within the same page** to ensure all factual information has been preserved.

**IMPORTANT:** This plugin compares fields on the SAME page (e.g., original content field vs rewritten content field, or original vs paragraph fields). It does NOT compare content from two different pages.

## Purpose

When content is rewritten, migrated, or restructured between different fields on the same page, it's critical that factual information remains accurate. This plugin automatically:

- Identifies all factual statements in the original field
- Verifies each fact appears correctly in the new field
- Detects missing, changed, or incorrect facts between fields
- Provides an overall accuracy score
- Lists specific discrepancies for review

### Common Use Cases

1. **Rewritten Content Field**: Compare original body field vs a rewritten_content field on the same page
2. **Paragraph Migration**: Compare original body field vs content that's been split into paragraph fields
3. **Content Restructuring**: Verify facts are preserved when content is reorganized within the same page
4. **Field Migration**: Ensure facts remain accurate when moving content between custom fields

## How It Works

### Automatic Comparison

The plugin automatically runs factual accuracy comparisons in two scenarios:

#### Scenario 1: Original Field vs Rewritten Content Field
When you run a content quality check on a page that has content in both:
1. Original content field (e.g., the configured "Original Content Field")
2. Rewritten content field (e.g., the configured "Rewritten Content Field")

The plugin compares these two fields **on the same page** to ensure facts are preserved when content was rewritten.

#### Scenario 2: Original Field vs Paragraph Fields
When you run a content quality check on a page that has content in both:
1. Original content field (e.g., body field)
2. Paragraph fields (with field_content or body sub-fields)

The plugin compares the original field against each paragraph field **on the same page** to verify factual accuracy. This is useful when original content has been split into multiple paragraph fields during migration or restructuring.

### Analysis Process

The plugin uses AI to perform a **section-by-section analysis**:

1. **Divide Content**: Splits the original content into logical sections
   - Based on natural paragraph/topic breaks
   - Typically 3-8 sections per piece of content
   - Each section represents a distinct topic or theme

2. **Extract Facts Per Section**: Identifies all factual statements in each section
   - Names, dates, numbers, statistics
   - Events, claims, assertions
   - Proper nouns, organizations
   - Specific details and measurements

3. **Verify Section Accuracy**: Checks each section's facts against the new field
   - Confirms facts are present in corresponding new content
   - Validates facts are correct
   - Identifies any changes or omissions per section

4. **Generate Detailed Report**: Provides section-by-section results
   - Overall accuracy percentage (average of all sections)
   - Per-section accuracy scores
   - List of factual differences organized by section
   - Detailed summary with recommendations

## Section-Based Scoring

The plugin divides content into logical sections and scores each one individually:

### How Sections Are Determined

The AI automatically identifies logical sections based on:
- Paragraph breaks
- Topic changes
- Theme shifts
- Natural content structure

Typically results in **3-8 sections** per piece of content.

### Per-Section Accuracy Score

Each section receives its own accuracy percentage based on:
- **Completeness**: Are all facts from this section present in the new field?
- **Correctness**: Are the facts stated accurately?
- **Precision**: Are numbers, dates, and statistics preserved exactly?
- **Entity Accuracy**: Are names, organizations, and locations correct?

### Section Score Examples

**100% Accuracy**: All facts perfectly preserved
- ✓ All names, dates, numbers match exactly
- ✓ No omissions or changes
- ✓ Context maintained

**80-99% Accuracy**: Minor issues
- ~ Minor precision loss (e.g., "500 users" → "hundreds of users")
- ~ Small details omitted
- ~ Slightly different phrasing that doesn't affect core facts

**60-79% Accuracy**: Moderate issues
- ⚠ Some facts missing
- ⚠ Numbers changed
- ⚠ Context somewhat altered

**Below 60% Accuracy**: Significant issues
- ✗ Multiple facts missing or incorrect
- ✗ Important information lost
- ✗ Factual errors introduced

## Output Format

### Overall Accuracy Score
- Percentage (e.g., "95%")
- Calculated as average of all section scores
- Normalized to 0-100 scale for dashboard display

### Section-by-Section Side-by-Side Comparison

Each section displays a three-column layout showing the before/after comparison:

```
┌─────────────────────────────────────────────────────────────────────┐
│ Section 1: Introduction and Background          Accuracy: 100%      │
├───────────────────┬───────────────────┬─────────────────────────────┤
│ ORIGINAL FIELD    │ NEW FIELD         │ DIFFERENCES                 │
├───────────────────┼───────────────────┼─────────────────────────────┤
│ Our company was   │ We were founded   │ ✓ No factual differences    │
│ founded in 1995   │ in 1995 by John   │   in this section           │
│ by John Smith in  │ Smith in Silicon  │                             │
│ Silicon Valley... │ Valley...         │                             │
└───────────────────┴───────────────────┴─────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ Section 2: Key Features and Benefits            Accuracy: 85%       │
├───────────────────┬───────────────────┬─────────────────────────────┤
│ ORIGINAL FIELD    │ NEW FIELD         │ DIFFERENCES                 │
├───────────────────┼───────────────────┼─────────────────────────────┤
│ Launched in March │ We launched our   │ [MISSING] Specific launch   │
│ 2023, our product │ product in 2023   │ date (March) omitted        │
│ serves 500        │ serving hundreds  │                             │
│ companies...      │ of companies...   │ [CHANGED] "500 companies"   │
│                   │                   │ became "hundreds"           │
└───────────────────┴───────────────────┴─────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│ Section 3: Technical Specifications              Accuracy: 60%      │
├───────────────────┬───────────────────┬─────────────────────────────┤
│ ORIGINAL FIELD    │ NEW FIELD         │ DIFFERENCES                 │
├───────────────────┼───────────────────┼─────────────────────────────┤
│ Developed by      │ Created by        │ [INCORRECT] "Dr. Smith"     │
│ Dr. Smith, our    │ Dr. Jones with    │ changed to "Dr. Jones"      │
│ ISO 9001          │ industry-leading  │                             │
│ certified system  │ technology...     │ [MISSING] ISO 9001          │
│ offers...         │                   │ certification not mentioned │
└───────────────────┴───────────────────┴─────────────────────────────┘
```

**Visual Features:**
- **Left Column (Original Field)**: Shows the original content for this section in a light yellow background
- **Middle Column (New Field)**: Shows the corresponding new content in a light blue background
- **Right Column (Differences)**: Lists all factual differences with color-coded badges in a light gray background
- **Header**: Shows section description and accuracy score prominently

### Factual Difference Types

- **NEW**: Fact present in new field but not in original field (information added)
- **MISSING**: Fact present in original but absent in new field (information removed)
- **CHANGED**: Fact altered (less precise, different number, etc.)
- **INCORRECT**: Fact is wrong or contradicts original

### Overall Summary
Comprehensive narrative including:
- Overall assessment of factual preservation across all sections
- Which sections maintained perfect accuracy
- Which sections had issues and severity
- Examples of well-preserved facts
- Details about any problems found
- Recommendations for improving accuracy

## Usage

### In Content Quality Checker

1. Navigate to **Content → Check Content Quality**
2. Select a page that has both original and rewritten content
3. Click "Check"
4. View results:
   - Standard quality scores for original content
   - Standard quality scores for rewritten content
   - **Factual Accuracy Comparison** section

### In Quality Dashboard

The dashboard displays factual accuracy scores alongside other quality metrics:

```
┌──────────┬────────────────┬───────────────────────┐
│ Page     │ Style Guide    │ Factual Accuracy      │
│          ├────┬───────────┼────┬──────────────────┤
│          │Orig│ Rewritten │Comp│                  │
├──────────┼────┼───────────┼────┼──────────────────┤
│ Article  │85% │ 92%       │95% │ ← Comparison score│
└──────────┴────┴───────────┴────┴──────────────────┘
```

Click the factual accuracy cell to see:
- List of all factual differences
- Scores by category
- Detailed analysis

## Configuration

### Prerequisites

1. **Content Type Field Mappings**:
   - Configure "Original Content Field"
   - Configure "Rewritten Content Field"
   - Navigate to: **Configuration → Content Migration → Settings**

2. **Claude API**:
   - API key must be configured
   - Plugin uses the same API settings as other tools

### Enable/Disable

The plugin is automatically available once the module is enabled. It only runs when both original and rewritten content exist.

## Technical Details

### Important Design Principle

**This plugin compares fields within a single page/node only.** It does not compare content from two different pages. The `compareFieldContent()` method requires:
- Content from field A on page X
- Content from field B on the same page X
- The node object for page X

All comparisons happen within the context of a single node/page.

### Plugin Information
- **Plugin ID**: `factual_accuracy`
- **Plugin Class**: `FactualAccuracyAnalysis`
- **Weight**: 10 (runs after standard quality checks)
- **Primary Method**: `compareFieldContent()` (compares two fields on same page)
- **Deprecated Method**: `compareContent()` (backwards compatibility wrapper)

### API Prompt

The plugin sends content from both fields to Claude AI with instructions to:
- Identify all factual statements in the original field
- Compare the two fields systematically
- Report discrepancies in structured format
- Provide scored assessment of how well facts were preserved between fields
- Emphasize that this is comparing fields within the same page, not different pages

### Data Storage

Results are stored in the JSON assessment format with:
- `content_type`: "comparison"
- `plugin_id`: "factual_accuracy"
- Detailed scores and differences list
- Full summary text

## Use Cases

### 1. Content Rewriting Quality Control

**Scenario**: Marketing team rewrites product descriptions for better engagement

**Benefit**: Ensures technical specifications and features aren't lost or changed

### 2. Legal/Compliance Review

**Scenario**: Updating legal notices or terms of service

**Benefit**: Verifies all required disclosures and facts remain accurate

### 3. Migration Quality Assurance

**Scenario**: Migrating content from old site with AI-assisted rewriting

**Benefit**: Catches factual errors before content goes live

### 4. Editorial Oversight

**Scenario**: Multiple writers rewriting historical content

**Benefit**: Maintains factual integrity across large content updates

## Interpreting Results

### High Accuracy (90-100%)
- All or nearly all facts preserved
- Minor stylistic differences only
- Safe to publish

### Good Accuracy (80-89%)
- Most facts preserved
- Some minor omissions or less-precise statements
- Review differences list
- May be acceptable depending on context

### Fair Accuracy (70-79%)
- Several facts missing or changed
- Review required before publishing
- Consider revising rewritten version

### Poor Accuracy (<70%)
- Significant factual discrepancies
- **Do not publish without review**
- Major revision needed
- May need to restart rewriting process

## Best Practices

1. **Run Early**: Check factual accuracy before final review

2. **Review All Differences**: Even high scores may have critical errors
   - Check if "MISSING" facts are actually important
   - Verify "CHANGED" facts haven't altered meaning
   - Confirm "INCORRECT" facts are truly errors

3. **Consider Context**: Some changes may be intentional
   - "500 users" → "hundreds of users" may be acceptable for readability
   - Removing outdated facts may be intentional

4. **Use With Other Checks**: Factual accuracy is one dimension
   - Content may be factually accurate but poorly written
   - Always review style guide scores too

5. **Document Decisions**: When accepting lower scores
   - Note why certain factual changes are acceptable
   - Keep audit trail for compliance

## Limitations

- **AI-Based**: May occasionally miss subtle factual differences
- **Context-Dependent**: Can't always judge if omissions are intentional
- **Language**: Works best with clear, factual content
- **Comparison Only**: Doesn't verify original facts are correct
- **Format Sensitivity**: Very technical or formatted content may be harder to analyze

## Troubleshooting

### Plugin Not Running

**Problem**: No factual accuracy results appear

**Solutions**:
- Verify both original and rewritten content fields are configured
- Check that both fields have content
- Ensure node has data in both fields
- Clear Drupal cache: `drush cr`

### Low Scores Despite Similar Content

**Problem**: Score is lower than expected

**Possible Causes**:
- Facts were simplified (e.g., "500" → "hundreds")
- Dates or numbers were removed for brevity
- Specific names replaced with generic terms
- Context changed even if core facts remained

**Action**: Review the differences list to understand what changed

### No Differences Listed Despite Low Score

**Problem**: Overall score is low but no differences shown

**Possible Causes**:
- AI response parsing issue
- Check raw response in logs
- May be formatting problem

**Action**: Check Drupal logs for full AI response

## Related Documentation

- [Quality Assessment JSON Schema](QUALITY_ASSESSMENT_JSON_SCHEMA.md)
- [Content Quality Dashboard](QUALITY_DASHBOARD.md)
- [Quality Analysis Plugin Base](src/Plugin/QualityAnalysisPluginBase.php)
