# NEW and MISSING Facts Detection Update

## Date
2025-11-04

## Summary

Updated the Factual Accuracy Analysis plugin to explicitly detect **NEW facts** (facts added to the new field that weren't in the original) and **MISSING facts** (facts in the original field that were removed from the new field). Previously, the AI was sometimes missing these types of differences and reporting "No differences noted" when clear factual changes existed.

## Problem Identified

When comparing original and new field content, the AI was not consistently identifying:
1. **NEW facts**: Information added to the new field that wasn't in the original
2. **MISSING facts**: Information from the original field that was omitted in the new field

### Example Issue

**Original Field:**
> "The VetGDP supports graduates and other vets required to undertake it in developing their clinical and professional capabilities, resilience and confidence."

**New Field:**
> "The VetGDP provides structured support during your crucial first 12 to 18 months as a qualified veterinary surgeon. This programme, developed in partnership with the Veterinary Schools Council (VSC)..."

**Previous Output:**
> "No differences noted" ❌

**Should Have Detected:**
- [NEW] "12 to 18 months" timeframe - added in new field
- [NEW] "partnership with VSC" - added in new field
- [NEW] "qualified veterinary surgeon" - added in new field
- [MISSING] "resilience and confidence" - removed from original
- [MISSING] "other vets" - removed from original
- [MISSING] "required to undertake" - removed from original

## Solution

### 1. Updated AI Prompt Instructions

**File**: `src/Plugin/QualityAnalysis/FactualAccuracyAnalysis.php`

**Method**: `buildComparisonPrompt()`

Added explicit instructions to check for THREE types of differences:

```
4. **CRITICALLY IMPORTANT**: For each section, you MUST check THREE things:
   a) **NEW FACTS**: Identify facts that appear in the NEW field but NOT in the original field
   b) **MISSING FACTS**: Identify facts that appear in the ORIGINAL field but NOT in the new field
   c) **CHANGED FACTS**: Identify facts that appear in both but are stated differently or incorrectly
```

### 2. Clarified Output Format

The prompt now explicitly shows all four difference types:

- **[Type: NEW]** - Fact added to new field that wasn't in original
- **[Type: MISSING]** - Fact from original that's omitted in new field
- **[Type: CHANGED]** - Fact that appears in both but stated differently
- **[Type: INCORRECT]** - Fact that is factually wrong

### 3. Provided Concrete Example

Added an example in the prompt to demonstrate proper difference detection:

```
If Original Text says: "Founded in 1995 by John Smith, serving 500 clients"
And New Text says: "Established in 1995 by John Smith with ISO 9001 certification, serving hundreds of clients"

You should identify:
- [Type: NEW] "ISO 9001 certification" mentioned in new field but not in original
- [Type: MISSING] "500 clients" from original is omitted (replaced with vague "hundreds")
- [Type: CHANGED] "500 clients" became "hundreds of clients" - less precise number
```

### 4. Updated Display Styling

**File**: `src/Form/ContentQualityCheckForm.php`

**Method**: `formatSectionAnalysis()`

Added blue badge styling for NEW facts:

```php
$badge_color = match($diff['type']) {
  'NEW' => 'background-color: #007bff; color: #fff;',
  'MISSING' => 'background-color: #ffc107; color: #856404;',
  'CHANGED' => 'background-color: #17a2b8; color: #fff;',
  'INCORRECT' => 'background-color: #dc3545; color: #fff;',
  default => 'background-color: #6c757d; color: #fff;',
};
```

## Badge Color Scheme

- 🔵 **NEW** - Blue (#007bff) - Informational, shows facts were added
- 🟨 **MISSING** - Yellow (#ffc107) - Warning, shows facts were removed
- 🔵 **CHANGED** - Cyan (#17a2b8) - Info, shows facts were altered
- 🔴 **INCORRECT** - Red (#dc3545) - Error, shows facts are wrong

## Scoring Considerations

The prompt now clarifies how each difference type affects the accuracy score:

- **Deduct points for MISSING facts** - Information lost from original
- **Deduct points for CHANGED facts** - Facts made less precise or altered
- **Deduct points for INCORRECT facts** - Facts that are wrong
- **NEW facts should be noted** - But don't necessarily reduce the score (they're additions, not losses)

This ensures that adding new factual information doesn't penalize the accuracy score, while removing or changing original facts does.

## Example Output

### Before This Update

```
Section 3: VetGDP Program Description    Accuracy: 100%
├─────────────────┬─────────────────┬──────────────────┤
│ ORIGINAL FIELD  │ NEW FIELD       │ DIFFERENCES      │
├─────────────────┼─────────────────┼──────────────────┤
│ The VetGDP      │ The VetGDP      │ No differences   │
│ supports...     │ provides...     │ noted            │
└─────────────────┴─────────────────┴──────────────────┘
```

### After This Update

```
Section 3: VetGDP Program Description    Accuracy: 75%
├─────────────────┬─────────────────┬────────────────────────────────┤
│ ORIGINAL FIELD  │ NEW FIELD       │ DIFFERENCES                    │
├─────────────────┼─────────────────┼────────────────────────────────┤
│ The VetGDP      │ The VetGDP      │ [NEW] "12 to 18 months"        │
│ supports        │ provides        │ timeframe added                │
│ graduates and   │ structured      │                                │
│ other vets in   │ support during  │ [NEW] "partnership with VSC"   │
│ developing      │ your crucial    │ added                          │
│ clinical and    │ first 12 to 18  │                                │
│ professional    │ months as a     │ [MISSING] "resilience and      │
│ capabilities,   │ qualified       │ confidence" omitted            │
│ resilience and  │ veterinary      │                                │
│ confidence...   │ surgeon. This   │ [MISSING] "other vets"         │
│                 │ programme,      │ omitted                        │
│                 │ developed in    │                                │
│                 │ partnership     │ [MISSING] "required to         │
│                 │ with VSC...     │ undertake" omitted             │
└─────────────────┴─────────────────┴────────────────────────────────┘
```

## Benefits

### 1. **More Accurate Detection**
The AI now systematically checks both fields for factual statements, not just looking for changed facts.

### 2. **Clear Visibility of Additions**
Users can now see when new factual information has been added to the new field, which may be intentional and valuable.

### 3. **Clear Visibility of Omissions**
Users can immediately see when facts from the original were removed, allowing them to decide if this was acceptable.

### 4. **Better Decision Making**
With NEW and MISSING facts clearly labeled, content editors can make informed decisions about whether changes are acceptable:
- NEW facts might enhance the content
- MISSING facts might be intentional simplification or problematic omissions

### 5. **More Accurate Scoring**
The accuracy score now properly reflects the preservation of original facts while noting additions separately.

## Files Modified

1. **src/Plugin/QualityAnalysis/FactualAccuracyAnalysis.php**
   - `buildComparisonPrompt()`: Added explicit instructions to check for NEW and MISSING facts
   - Added concrete example of proper difference detection
   - Clarified scoring considerations

2. **src/Form/ContentQualityCheckForm.php**
   - `formatSectionAnalysis()`: Added NEW badge styling with blue color

3. **FACTUAL_ACCURACY_PLUGIN.md**
   - Updated "Factual Difference Types" section to include NEW type

4. **SIDE_BY_SIDE_COMPARISON_UPDATE.md**
   - Updated "Visual Design" section to include NEW badge color

5. **NEW_MISSING_FACTS_UPDATE.md** (this file)

## Testing Recommendations

1. **Test with Added Information**
   - Original: "Founded in 1995"
   - New: "Founded in 1995 with ISO certification"
   - Should detect: [NEW] "ISO certification" added

2. **Test with Removed Information**
   - Original: "Serves 500 companies in 10 countries"
   - New: "Serves hundreds of companies"
   - Should detect: [MISSING] "500" omitted, [MISSING] "10 countries" omitted

3. **Test with Both Added and Removed**
   - Original: "Dr. Smith founded the company in 1995"
   - New: "The company was founded in 1995 with venture capital funding"
   - Should detect: [NEW] "venture capital funding" added, [MISSING] "Dr. Smith" omitted

4. **Test with Complex Sections**
   - Multiple facts in both original and new
   - Mix of preserved, added, and removed facts
   - Verify all differences are caught

## Future Enhancements

1. **Severity Levels**
   - Mark some MISSING facts as "critical" (e.g., regulatory requirements)
   - Mark some NEW facts as "beneficial" (e.g., additional context)

2. **Inline Highlighting**
   - Highlight NEW facts in green within the new text
   - Highlight MISSING facts in yellow within the original text
   - Visually connect what was removed vs what was added

3. **Statistical Summary**
   - Count of NEW facts added per section
   - Count of MISSING facts removed per section
   - Ratio of preserved vs changed facts

4. **User Acceptance**
   - Allow users to mark certain MISSING facts as "acceptable omission"
   - Allow users to mark NEW facts as "beneficial addition"
   - Recalculate accuracy score based on user feedback

## Conclusion

This update significantly improves the factual accuracy comparison by explicitly instructing the AI to check for facts that were added (NEW) or removed (MISSING), not just facts that changed. This provides content editors with a complete picture of how factual content evolved between the original and new fields, enabling better decision-making about content quality.

The three-way detection (NEW, MISSING, CHANGED/INCORRECT) ensures that no factual differences go unnoticed, addressing the original issue where significant differences were being reported as "No differences noted".
