<?php

declare(strict_types=1);

namespace Drupal\content_migration\Attribute;

use Drupal\Component\Plugin\Attribute\Plugin;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines an AI migration plugin attribute.
 *
 * @see \Drupal\content_migration\Plugin\AiMigrationPluginManager
 * @see plugin_api
 */
#[\Attribute(\Attribute::TARGET_CLASS)]
class AiMigration extends Plugin {

  /**
   * Constructs a AiMigration attribute.
   *
   * @param string $id
   *   The plugin ID.
   * @param ?\Drupal\Core\StringTranslation\TranslatableMarkup $label
   *   (optional) The human-readable name of the ai migration.
   * @param ?\Drupal\Core\StringTranslation\TranslatableMarkup $description
   *   (optional) A short description of the ai migration.
   */
  public function __construct(
    public readonly string $id,
    public readonly ?TranslatableMarkup $label = NULL,
    public readonly ?TranslatableMarkup $description = NULL,
  ) {}

}
