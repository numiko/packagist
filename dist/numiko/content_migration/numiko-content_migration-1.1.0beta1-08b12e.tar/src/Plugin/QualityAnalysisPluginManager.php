<?php

namespace Drupal\content_migration\Plugin;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\content_migration\Attribute\QualityAnalysis;

/**
 * Manages quality analysis plugins.
 */
class QualityAnalysisPluginManager extends DefaultPluginManager {

  /**
   * Constructs a QualityAnalysisPluginManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct(
      'Plugin/QualityAnalysis',
      $namespaces,
      $module_handler,
      QualityAnalysisInterface::class,
      QualityAnalysis::class
    );

    $this->alterInfo('quality_analysis_info');
    $this->setCacheBackend($cache_backend, 'quality_analysis_plugins');
  }

  /**
   * Gets all available quality analysis plugins sorted by weight.
   *
   * @param array $context
   *   Optional context to filter plugins.
   *
   * @return array
   *   Array of plugin instances.
   */
  public function getAvailablePlugins(array $context = []): array {
    $plugins = [];
    $definitions = $this->getDefinitions();

    $this->logger('content_migration')->info('QualityAnalysisPluginManager: Starting plugin discovery. Found @count plugin definitions.', [
      '@count' => count($definitions),
    ]);

    // Log all discovered plugin definitions.
    foreach ($definitions as $plugin_id => $definition) {
      $this->logger('content_migration')->info('QualityAnalysisPluginManager: Discovered plugin "@id" - Label: @label, Weight: @weight', [
        '@id' => $plugin_id,
        '@label' => $definition['label'] ?? 'No label',
        '@weight' => $definition['weight'] ?? 0,
      ]);
    }

    // Sort by weight.
    uasort($definitions, function ($a, $b) {
      return ($a['weight'] ?? 0) <=> ($b['weight'] ?? 0);
    });

    $this->logger('content_migration')->info('QualityAnalysisPluginManager: Plugins sorted by weight. Processing availability checks...');

    foreach ($definitions as $plugin_id => $definition) {
      try {
        $this->logger('content_migration')->info('QualityAnalysisPluginManager: Attempting to create instance of "@plugin"', [
          '@plugin' => $plugin_id,
        ]);

        /** @var \Drupal\content_migration\Plugin\QualityAnalysisInterface $plugin */
        $plugin = $this->createInstance($plugin_id);

        $this->logger('content_migration')->info('QualityAnalysisPluginManager: Plugin "@plugin" instantiated successfully. Checking availability...', [
          '@plugin' => $plugin_id,
        ]);

        $is_available = $plugin->isAvailable($context);

        if ($is_available) {
          $plugins[$plugin_id] = $plugin;
          $this->logger('content_migration')->info('QualityAnalysisPluginManager: ✓ Plugin "@plugin" is AVAILABLE and will be used.', [
            '@plugin' => $plugin_id,
          ]);
        }
        else {
          $this->logger('content_migration')->info('QualityAnalysisPluginManager: ✗ Plugin "@plugin" is NOT AVAILABLE (isAvailable returned false). Skipping.', [
            '@plugin' => $plugin_id,
          ]);
        }
      }
      catch (\Exception $e) {
        \Drupal::logger('content_migration')->error('QualityAnalysisPluginManager: ✗ Failed to create quality analysis plugin "@plugin": @error', [
          '@plugin' => $plugin_id,
          '@error' => $e->getMessage(),
        ]);
      }
    }

    $this->logger('content_migration')->info('QualityAnalysisPluginManager: Plugin discovery complete. @available of @total plugins are available: @list', [
      '@available' => count($plugins),
      '@total' => count($definitions),
      '@list' => implode(', ', array_keys($plugins)),
    ]);

    return $plugins;
  }

  /**
   * Gets the logger.
   *
   * @param string $channel
   *   The logger channel.
   *
   * @return \Drupal\Core\Logger\LoggerChannelInterface
   *   The logger.
   */
  protected function logger(string $channel) {
    return \Drupal::logger($channel);
  }

}
