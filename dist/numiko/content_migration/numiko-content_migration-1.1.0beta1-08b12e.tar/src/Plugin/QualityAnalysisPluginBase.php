<?php

namespace Drupal\content_migration\Plugin;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use GuzzleHttp\ClientInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Base class for quality analysis plugins.
 */
abstract class QualityAnalysisPluginBase extends PluginBase implements QualityAnalysisInterface, ContainerFactoryPluginInterface {

  /**
   * The HTTP client.
   *
   * @var \GuzzleHttp\ClientInterface
   */
  protected ClientInterface $httpClient;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected ConfigFactoryInterface $configFactory;

  /**
   * The logger.
   *
   * @var \Drupal\Core\Logger\LoggerChannelInterface
   */
  protected $logger;

  /**
   * Constructs a QualityAnalysisPluginBase object.
   *
   * @param array $configuration
   *   Plugin configuration.
   * @param string $plugin_id
   *   Plugin ID.
   * @param mixed $plugin_definition
   *   Plugin definition.
   * @param \GuzzleHttp\ClientInterface $http_client
   *   The HTTP client.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger factory.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    ClientInterface $http_client,
    ConfigFactoryInterface $config_factory,
    LoggerChannelFactoryInterface $logger_factory
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->httpClient = $http_client;
    $this->configFactory = $config_factory;
    $this->logger = $logger_factory->get('content_migration');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('http_client'),
      $container->get('config.factory'),
      $container->get('logger.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getLabel(): string {
    return $this->pluginDefinition['label'];
  }

  /**
   * {@inheritdoc}
   */
  public function getDescription(): string {
    return $this->pluginDefinition['description'] ?? '';
  }

  /**
   * {@inheritdoc}
   */
  public function getWeight(): int {
    return $this->pluginDefinition['weight'] ?? 0;
  }

  /**
   * {@inheritdoc}
   */
  public function isAvailable(array $context = []): bool {
    // Default: always available.
    return TRUE;
  }

  /**
   * Gets the JSON schema for quality assessment results.
   *
   * This schema defines the structure for storing quality assessment results
   * across multiple content items, allowing for aggregation and comparison.
   *
   * @return array
   *   The JSON schema structure with documentation.
   */
  public static function getResultsSchema(): array {
    return [
      'schema_version' => '1.0',
      'description' => 'Schema for storing content quality assessment results',
      'structure' => [
        'schema_version' => [
          'type' => 'string',
          'description' => 'Version of this schema format',
          'example' => '1.0',
        ],
        'node_id' => [
          'type' => 'integer',
          'description' => 'The node ID being assessed',
          'example' => 123,
        ],
        'node_title' => [
          'type' => 'string',
          'description' => 'The title of the node',
          'example' => 'Example Article',
        ],
        'assessment_timestamp' => [
          'type' => 'integer',
          'description' => 'Unix timestamp when assessment was performed',
          'example' => 1234567890,
        ],
        'assessment_date' => [
          'type' => 'string',
          'description' => 'Human-readable date of assessment',
          'example' => '2024-01-15 10:30:45',
        ],
        'content_type' => [
          'type' => 'string',
          'description' => 'Type of content assessed (original, rewritten, paragraph)',
          'example' => 'original',
        ],
        'assessments' => [
          'type' => 'array',
          'description' => 'Array of assessment results from different plugins',
          'items' => [
            'plugin_id' => [
              'type' => 'string',
              'description' => 'ID of the quality analysis plugin',
              'example' => 'style_guide',
            ],
            'plugin_label' => [
              'type' => 'string',
              'description' => 'Human-readable label of the plugin',
              'example' => 'Style Guide Analysis',
            ],
            'content_label' => [
              'type' => 'string',
              'description' => 'Label identifying which content was assessed',
              'example' => 'Original Content',
            ],
            'overall_score' => [
              'type' => 'string',
              'description' => 'Overall quality score',
              'example' => '8/10',
            ],
            'overall_score_numeric' => [
              'type' => 'float',
              'description' => 'Normalized numeric score (0-100)',
              'example' => 80.0,
            ],
            'scores' => [
              'type' => 'object',
              'description' => 'Detailed scores by area',
              'example' => [
                'Content Structure' => [
                  'score' => '8/10',
                  'score_numeric' => 80.0,
                  'comments' => 'Well organized with clear headings',
                ],
              ],
            ],
            'summary' => [
              'type' => 'string',
              'description' => 'Detailed analysis summary',
              'example' => 'The content demonstrates strong adherence to the style guide...',
            ],
            'audience_term_id' => [
              'type' => 'integer|null',
              'description' => 'Audience term ID if specified',
              'example' => 456,
            ],
          ],
        ],
      ],
    ];
  }

  /**
   * Converts a score string to a numeric value (0-100 scale).
   *
   * @param string $score
   *   The score string (e.g., "8/10", "85%", "4.5/5").
   *
   * @return float
   *   The normalized score on a 0-100 scale.
   */
  public static function normalizeScore(string $score): float {
    $score = trim($score);

    // Handle fraction format (e.g., "8/10", "4.5/5").
    if (preg_match('/^(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/', $score, $matches)) {
      $numerator = (float) $matches[1];
      $denominator = (float) $matches[2];
      if ($denominator > 0) {
        return ($numerator / $denominator) * 100;
      }
    }

    // Handle percentage format (e.g., "85%", "72.5%").
    if (preg_match('/^(\d+(?:\.\d+)?)\s*%$/', $score, $matches)) {
      return (float) $matches[1];
    }

    // Handle plain numeric (assume 0-10 scale if <= 10, otherwise 0-100).
    if (is_numeric($score)) {
      $numeric = (float) $score;
      if ($numeric <= 10) {
        return $numeric * 10;
      }
      return $numeric;
    }

    // Default: return 0 if unparseable.
    return 0.0;
  }

  /**
   * Makes a Claude API request.
   *
   * @param string $prompt
   *   The prompt to send.
   * @param int $max_tokens
   *   The maximum number of tokens.
   *
   * @return string
   *   The response content.
   */
  protected function makeClaudeRequest(string $prompt, int $max_tokens = 4096): string {
    $config = $this->configFactory->get('content_migration.settings');
    $api_key = $config->get('claude_api_key');
    $model = $config->get('claude_api_model') ?: 'claude-3-5-sonnet-20241022';

    if (empty($api_key)) {
      throw new \Exception('Claude API key is not configured. Please set it in the module configuration.');
    }

    try {
      $this->logger->info('@plugin: Making API request with model @model, max_tokens @tokens', [
        '@plugin' => $this->getLabel(),
        '@model' => $model,
        '@tokens' => $max_tokens,
      ]);

      $response = $this->httpClient->request('POST', 'https://api.anthropic.com/v1/messages', [
        'headers' => [
          'x-api-key' => $api_key,
          'anthropic-version' => '2023-06-01',
          'Content-Type' => 'application/json',
        ],
        'json' => [
          'model' => $model,
          'max_tokens' => $max_tokens,
          'messages' => [
            [
              'role' => 'user',
              'content' => $prompt,
            ],
          ],
        ],
        'timeout' => 600,
      ]);

      $response_body = (string) $response->getBody();

      $this->logger->info('@plugin: Received API response body:<br/><pre>@body</pre>', [
        '@plugin' => $this->getLabel(),
        '@body' => substr($response_body, 0, 3000) . (strlen($response_body) > 3000 ? '... [truncated]' : ''),
      ]);

      $response_data = json_decode($response_body, TRUE);

      if (json_last_error() !== JSON_ERROR_NONE) {
        $this->logger->error('@plugin: JSON decode error: @error', [
          '@plugin' => $this->getLabel(),
          '@error' => json_last_error_msg(),
        ]);
        throw new \Exception('Failed to decode API response: ' . json_last_error_msg());
      }

      if (isset($response_data['content'][0]['text'])) {
        $this->logger->info('@plugin: Successfully extracted text from API response', [
          '@plugin' => $this->getLabel(),
        ]);
        return $response_data['content'][0]['text'];
      }

      $this->logger->error('@plugin: Unexpected response format. Response data: @data', [
        '@plugin' => $this->getLabel(),
        '@data' => print_r($response_data, TRUE),
      ]);
      throw new \Exception('Unexpected response format from Claude API.');
    }
    catch (\Exception $e) {
      $this->logger->error('@plugin: API request failed: @error, Trace: @trace', [
        '@plugin' => $this->getLabel(),
        '@error' => $e->getMessage(),
        '@trace' => $e->getTraceAsString(),
      ]);
      throw new \Exception('Failed to analyze content: ' . $e->getMessage());
    }
  }

}
