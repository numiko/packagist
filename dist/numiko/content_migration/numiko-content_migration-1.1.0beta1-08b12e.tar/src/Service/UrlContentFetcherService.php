<?php

namespace Drupal\content_migration\Service;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\RequestException;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use fivefilters\Readability\Configuration;
use fivefilters\Readability\ParseException;
use fivefilters\Readability\Readability;

/**
 * Service for fetching content from URLs.
 */
class UrlContentFetcherService {

  /**
   * Constructs a UrlContentFetcherService object.
   *
   * @param \GuzzleHttp\ClientInterface $httpClient
   *   The HTTP client.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    protected readonly ClientInterface $httpClient,
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * Fetches content from a URL.
   *
   * @param string $url
   *   The URL to fetch content from.
   *
   * @return string
   *   The HTML content from the URL.
   *
   * @throws \Exception
   *   Throws an exception if the content cannot be fetched.
   */
  public function fetchContent($url) {
    try {
      $response = $this->httpClient->request('GET', $url, [
        'headers' => [
          'User-Agent' => 'Mozilla/5.0 (compatible; Drupal/10.0; +http://drupal.org/)',
        ],
        'timeout' => 600,
      ]);

      $content_type = $response->getHeaderLine('Content-Type');
      if (strpos($content_type, 'text/html') === FALSE && strpos($content_type, 'application/xhtml+xml') === FALSE) {
        throw new \Exception("URL does not return HTML content: {$content_type}");
      }

      $body = (string) $response->getBody();
      if (empty($body)) {
        throw new \Exception('Empty response received from URL.');
      }

      return $body;
    }
    catch (RequestException $e) {
      $this->logger->error(
        'Error fetching URL @url: @error',
        ['@url' => (string) $url, '@error' => (string) $e->getMessage()]
      );
      throw new \Exception("Failed to fetch content from URL: " . $e->getMessage());
    }
  }

  /**
   * Sanitizes and extracts the main content from HTML.
   *
   * @param string $html
   *   The raw HTML content.
   *
   * @return array
   *   The sanitized HTML content with unnecessary parts removed & the title.
   */
  public function sanitizeHtml($html) : array {
    $readability = new Readability(new Configuration([
      'StripUnlikelyCandidates' => FALSE,
      'KeepClasses' => TRUE,
    ]));

    try {
      $readability->parse($html);
    }
    catch (ParseException $e) {
      throw new \Exception(sprintf('Error processing text: %s', $e->getMessage()));
    }

    $title = $readability->getTitle();
    // If title contains '|', only use the part before it.
    if (strpos($title, '|') !== FALSE) {
      $title = trim(substr($title, 0, strpos($title, '|')));
    }

    return [
      'title' => $title,
      'content' => $readability->getContent(),
    ];
  }

}
