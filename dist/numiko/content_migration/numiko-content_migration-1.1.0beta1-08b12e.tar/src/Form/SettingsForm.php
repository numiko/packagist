<?php

namespace Drupal\content_migration\Form;

use Drupal\Core\DependencyInjection\AutowireTrait;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\content_migration\Plugin\AiMigrationPluginManager;
use Drupal\content_migration\Service\TaxonomyPromptService;

/**
 * Settings form for Content Moderation URL module.
 */
final class SettingsForm extends ConfigFormBase {
  use AutowireTrait;

  /**
   * Constructs a SettingsForm object.
   *
   * @param \Drupal\content_migration\Service\TaxonomyPromptService $taxonomyPromptService
   *   The taxonomy prompt service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\content_migration\Plugin\AiMigrationPluginManager $aiMigrationPluginManager
   *   The AI migration plugin manager.
   */
  public function __construct(
    protected TaxonomyPromptService $taxonomyPromptService,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected AiMigrationPluginManager $aiMigrationPluginManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['content_migration.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'content_migration_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('content_migration.settings');

    $form['api_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Claude API Settings'),
      '#open' => TRUE,
    ];

    $form['api_settings']['claude_api_key'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Claude API Key'),
      '#description' => $this->t('Enter your Claude API key. You can obtain one from <a href="https://console.anthropic.com/" target="_blank">Anthropic Console</a>.'),
      '#default_value' => $config->get('claude_api_key'),
      '#required' => TRUE,
    ];

    $form['api_settings']['claude_api_model'] = [
      '#type' => 'select',
      '#title' => $this->t('Claude Model'),
      '#description' => $this->t('Select the Claude model to use for content extraction.'),
      '#options' => [
        'claude-3-haiku-20240307' => $this->t('Claude 3 Haiku (Faster, lower cost)'),
        'claude-3-5-haiku-20241022' => $this->t('Claude 3.5 Haiku (Faster, lower cost)'),
        'claude-3-sonnet-20240229' => $this->t('Claude 3 Sonnet (Balanced)'),
        'claude-sonnet-4-20250514' => $this->t('Claude Sonnet 4 (Balanced)'),
        'claude-3-opus-20240229' => $this->t('Claude 3 Opus (Highest quality)'),
        'claude-opus-4-20250514' => $this->t('Claude Opus 4 (Highest quality)'),
      ],
      '#default_value' => $config->get('claude_api_model') ?: 'claude-3-haiku-20240307',
    ];

    $form['content_extraction'] = [
      '#type' => 'details',
      '#title' => $this->t('Content Extraction Settings'),
      '#open' => TRUE,
    ];

    $default_prompt = <<<EOT
I'll provide you with HTML content from a webpage. Please extract the following information:

1. The page title - use the main heading (usually an h1) rather than the HTML title tag if they differ
2. The main body content - extract the main article text, ignoring navigation, headers, footers, sidebars, comments, etc.

Format your response as a JSON object with two fields:
- "title": The page title
- "body": The main body content, preserving paragraphs and basic formatting

Here's the HTML content:

{html_content}

Please respond only with valid JSON following this format:
{
  "title": "The page title goes here",
  "body": "The main content goes here. It may span multiple paragraphs and include basic formatting."
}
EOT;

    $form['content_extraction']['claude_api_prompt'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Extraction Prompt'),
      '#description' => $this->t('The prompt to send to Claude API. Use {html_content} as a placeholder for the HTML content.'),
      '#default_value' => $config->get('claude_api_prompt') ?: $default_prompt,
      '#rows' => 15,
    ];

    $form['content_extraction']['reset_prompt'] = [
      '#type' => 'button',
      '#value' => $this->t('Reset to Default'),
      '#attributes' => [
        'onclick' => 'document.getElementById("edit-claude-api-prompt").value = ' . json_encode($default_prompt) . '; return false;',
      ],
    ];

    $form['feature_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Feature Settings'),
      '#open' => TRUE,
    ];

    $form['feature_settings']['enable_quality_features'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable Content Quality Features'),
      '#default_value' => $config->get('enable_quality_features') ?? TRUE,
      '#description' => $this->t('Enable the content quality checking features including "Check Content Quality" and "Content Quality Dashboard" menu items. When disabled, these features will be hidden from the menu.'),
    ];

    $form['feature_settings']['import_types'] = [
      '#type' => 'details',
      '#title' => $this->t('Enabled Import Types'),
      '#open' => TRUE,
      '#description' => $this->t('Select which import types should be available on the content import form.'),
    ];

    $form['feature_settings']['import_types']['enable_url_import'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable URL Import'),
      '#default_value' => $config->get('enable_url_import') ?? TRUE,
      '#description' => $this->t('Allow importing content from URLs.'),
    ];

    $form['feature_settings']['import_types']['enable_pdf_import'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable PDF Import'),
      '#default_value' => $config->get('enable_pdf_import') ?? TRUE,
      '#description' => $this->t('Allow extracting content from PDF files.'),
    ];

    $form['feature_settings']['import_types']['enable_title_import'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable Title Import'),
      '#default_value' => $config->get('enable_title_import') ?? TRUE,
      '#description' => $this->t('Allow creating empty pages from titles.'),
    ];

    $form['feature_settings']['import_types']['enable_csv_import'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable CSV/TSV Import'),
      '#default_value' => $config->get('enable_csv_import') ?? TRUE,
      '#description' => $this->t('Allow uploading CSV/TSV files with page structure.'),
    ];

    $form['audience_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Audience Targeting Settings'),
      '#open' => TRUE,
    ];

    $form['audience_settings']['audience_vocabulary'] = [
      '#type' => 'select',
      '#title' => $this->t('Audience Vocabulary'),
      '#options' => $this->taxonomyPromptService->getVocabularyOptions(),
      '#default_value' => $config->get('audience_vocabulary') ?: '',
      '#description' => $this->t('Select a taxonomy vocabulary. It should be a hierarchical taxonomy, with the root term containing the global style guide prompt in its description. Its child terms should have the different audience prompts in their descriptions. These terms will be available for selection during content import to tailor the AI processing.'),
    ];

    $form['content_type_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Content Type & Taxonomy Settings'),
      '#open' => TRUE,
      '#description' => $this->t('Configure which content types can be used for migration and their associated taxonomies.'),
    ];

    $form['content_type_settings']['allowed_content_types'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Allowed Content Types'),
      '#options' => $this->getContentTypeOptions(),
      '#default_value' => $config->get('allowed_content_types') ?: [],
      '#description' => $this->t('Select which content types can be created by the migration tool.'),
      '#ajax' => [
        'callback' => '::updateContentTypeSettings',
        'wrapper' => 'content-type-settings-wrapper',
      ],
    ];

    $form['content_type_settings']['content_type_settings_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'content-type-settings-wrapper'],
    ];

    $form['content_type_settings']['content_type_settings_wrapper']['content_type_taxonomies_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'content-type-taxonomies-wrapper'],
    ];

    $this->buildContentTypeTaxonomiesForm($form['content_type_settings']['content_type_settings_wrapper'], $form_state, $config);

    $form['content_type_settings']['content_type_settings_wrapper']['content_type_field_mappings_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'content-type-field-mappings-wrapper'],
    ];

    $this->buildContentTypeFieldMappingsForm($form['content_type_settings']['content_type_settings_wrapper'], $form_state, $config);

    $form['ai_plugin_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('AI Migration Plugin Defaults'),
      '#open' => TRUE,
      '#description' => $this->t('Choose which AI migration plugins should be enabled by default when importing content. Users can still override these settings per import.'),
    ];

    $available_plugins = $this->aiMigrationPluginManager->getDefinitions();
    $default_enabled_plugins = $config->get('default_enabled_ai_plugins') ?: [];

    if (!empty($available_plugins)) {
      $form['ai_plugin_settings']['default_enabled_ai_plugins'] = [
        '#type' => 'checkboxes',
        '#title' => $this->t('Default Enabled Plugins'),
        '#options' => $this->getAiPluginOptions(),
        '#default_value' => $default_enabled_plugins,
        '#description' => $this->t('Select which AI migration plugins should be enabled by default in the content migration form.'),
      ];
    }
    else {
      $form['ai_plugin_settings']['no_plugins'] = [
        '#markup' => '<p>' . $this->t('No AI migration plugins are available.') . '</p>',
      ];
    }

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    $api_key = $form_state->getValue('claude_api_key');
    if (empty($api_key)) {
      $form_state->setErrorByName('claude_api_key', $this->t('Claude API key is required.'));
    }

    $prompt = $form_state->getValue('claude_api_prompt');
    if (strpos($prompt, '{html_content}') === FALSE) {
      $form_state->setErrorByName('claude_api_prompt', $this->t('The prompt must contain the {html_content} placeholder.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    // Process content type taxonomies to filter out empty values.
    $content_type_taxonomies = $form_state->getValue('content_type_taxonomies') ?: [];
    $filtered_content_type_taxonomies = [];

    foreach ($content_type_taxonomies as $content_type => $taxonomies) {
      $filtered_taxonomies = array_filter($taxonomies);
      if (!empty($filtered_taxonomies)) {
        $filtered_content_type_taxonomies[$content_type] = array_keys($filtered_taxonomies);
      }
    }

    $config = $this->config('content_migration.settings');
    $config
      ->set('claude_api_key', $form_state->getValue('claude_api_key'))
      ->set('claude_api_model', $form_state->getValue('claude_api_model'))
      ->set('claude_api_prompt', $form_state->getValue('claude_api_prompt'))
      ->set('enable_quality_features', $form_state->getValue('enable_quality_features'))
      ->set('enable_url_import', $form_state->getValue('enable_url_import'))
      ->set('enable_pdf_import', $form_state->getValue('enable_pdf_import'))
      ->set('enable_title_import', $form_state->getValue('enable_title_import'))
      ->set('enable_csv_import', $form_state->getValue('enable_csv_import'))
      ->set('audience_vocabulary', $form_state->getValue('audience_vocabulary'))
      ->set('allowed_content_types', array_keys(array_filter($form_state->getValue('allowed_content_types') ?: [])))
      ->set('content_type_taxonomies', $filtered_content_type_taxonomies)
      ->set('default_enabled_ai_plugins', array_keys(array_filter($form_state->getValue('default_enabled_ai_plugins') ?: [])))
      ->set('content_type_field_mappings', $this->processFieldMappings($form_state));

    // Remove old content_page_taxonomy setting if it exists.
    $config->clear('content_page_taxonomy');

    $config->save();

    parent::submitForm($form, $form_state);
  }

  /**
   * Get content type options.
   *
   * @return array
   *   An array of content type labels keyed by content type IDs.
   */
  protected function getContentTypeOptions() {
    $content_types = $this->entityTypeManager->getStorage('node_type')->loadMultiple();
    $options = [];

    foreach ($content_types as $content_type) {
      $options[$content_type->id()] = $content_type->label();
    }

    return $options;
  }

  /**
   * Get AI plugin options for form select elements.
   *
   * @return array
   *   An array of plugin labels keyed by plugin IDs.
   */
  protected function getAiPluginOptions() {
    $options = [];
    foreach ($this->aiMigrationPluginManager->getDefinitions() as $plugin_id => $definition) {
      $options[$plugin_id] = $definition['label'];
    }
    return $options;
  }

  /**
   * Build the content type taxonomies configuration form.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param \Drupal\Core\Config\Config $config
   *   The configuration object.
   */
  protected function buildContentTypeTaxonomiesForm(array &$form, FormStateInterface $form_state, $config) {
    $allowed_content_types = $form_state->getValue('allowed_content_types');
    if (empty($allowed_content_types)) {
      $allowed_content_types = $config->get('allowed_content_types') ?: [];
    }

    $content_type_taxonomies = $config->get('content_type_taxonomies') ?: [];

    if (!empty(array_filter($allowed_content_types))) {
      $form['content_type_settings']['content_type_taxonomies_wrapper']['content_type_taxonomies'] = [
        '#type' => 'details',
        '#title' => $this->t('Taxonomy Configuration'),
        '#open' => TRUE,
        '#tree' => TRUE,
      ];

      foreach (array_filter($allowed_content_types) as $content_type_id) {
        $content_type = $this->entityTypeManager->getStorage('node_type')->load($content_type_id);
        if (!$content_type) {
          continue;
        }

        $form['content_type_settings']['content_type_taxonomies_wrapper']['content_type_taxonomies'][$content_type_id] = [
          '#type' => 'checkboxes',
          '#title' => $this->t('Taxonomies for @content_type', ['@content_type' => $content_type->label()]),
          '#options' => $this->taxonomyPromptService->getVocabularyOptions(),
          '#default_value' => $content_type_taxonomies[$content_type_id] ?? [],
          '#description' => $this->t('Select which taxonomy vocabularies should be available for the @content_type content type during import.', ['@content_type' => $content_type->label()]),
        ];
      }
    }
    else {
      $form['content_type_settings']['content_type_taxonomies_wrapper']['#markup'] = $this->t('Please select one or more content types above to configure their taxonomies.');
    }
  }

  /**
   * Ajax callback to update content type taxonomy options.
   */
  public function updateContentTypeTaxonomies(array &$form, FormStateInterface $form_state) {
    return $form['content_type_settings']['content_type_settings_wrapper']['content_type_taxonomies_wrapper'];
  }

  /**
   * Ajax callback to update content type settings (taxonomies and field mappings).
   */
  public function updateContentTypeSettings(array &$form, FormStateInterface $form_state) {
    return $form['content_type_settings']['content_type_settings_wrapper'];
  }

  /**
   * Build the content type field mappings configuration form.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param \Drupal\Core\Config\Config $config
   *   The configuration object.
   */
  protected function buildContentTypeFieldMappingsForm(array &$form, FormStateInterface $form_state, $config): void {
    $allowed_content_types = $form_state->getValue('allowed_content_types');
    if (empty($allowed_content_types)) {
      $allowed_content_types = $config->get('allowed_content_types') ?: [];
    }

    $content_type_field_mappings = $config->get('content_type_field_mappings') ?: [];

    if (!empty(array_filter($allowed_content_types))) {
      $form['content_type_field_mappings_wrapper']['content_type_field_mappings'] = [
        '#type' => 'details',
        '#title' => $this->t('Default Field Mappings'),
        '#open' => TRUE,
        '#description' => $this->t('Configure default fields for different types of AI-generated content. These will be pre-selected in the content migration form but can be overridden per import.'),
        '#tree' => TRUE,
      ];

      foreach (array_filter($allowed_content_types) as $content_type_id) {
        $content_type = $this->entityTypeManager->getStorage('node_type')->load($content_type_id);
        if (!$content_type) {
          continue;
        }

        $text_field_options = $this->getTextFieldOptionsForContentType($content_type_id);
        $all_field_options = $this->getAllFieldOptionsForContentType($content_type_id);

        $form['content_type_field_mappings_wrapper']['content_type_field_mappings'][$content_type_id] = [
          '#type' => 'details',
          '#title' => $content_type->label(),
          '#open' => FALSE,
          '#tree' => TRUE,
        ];

        $current_mappings = $content_type_field_mappings[$content_type_id] ?? [];

        // Original content field (body field)
        $form['content_type_field_mappings_wrapper']['content_type_field_mappings'][$content_type_id]['original_content'] = [
          '#type' => 'select',
          '#title' => $this->t('Original Content Field'),
          '#options' => ['' => $this->t('- Select a field -')] + $all_field_options,
          '#default_value' => $current_mappings['original_content'] ?? '',
          '#description' => $this->t('Default field for storing the original extracted content.'),
        ];

        // Rewritten content field.
        $form['content_type_field_mappings_wrapper']['content_type_field_mappings'][$content_type_id]['rewritten_content'] = [
          '#type' => 'select',
          '#title' => $this->t('Rewritten Content Field'),
          '#options' => ['' => $this->t('- Select a field -')] + $all_field_options,
          '#default_value' => $current_mappings['rewritten_content'] ?? '',
          '#description' => $this->t('Default field for storing AI-rewritten content (RewriteContent plugin).'),
        ];

        // Changes summary field.
        $form['content_type_field_mappings_wrapper']['content_type_field_mappings'][$content_type_id]['changes_summary'] = [
          '#type' => 'select',
          '#title' => $this->t('Changes Summary Field'),
          '#options' => ['' => $this->t('- Select a field -')] + $text_field_options,
          '#default_value' => $current_mappings['changes_summary'] ?? '',
          '#description' => $this->t('Default field for storing a summary of changes made during rewriting (RewriteContent plugin). Must be a text field.'),
        ];

        // Intermediate summary field.
        $form['content_type_field_mappings_wrapper']['content_type_field_mappings'][$content_type_id]['intermediate_summary'] = [
          '#type' => 'select',
          '#title' => $this->t('Intermediate Summary Field'),
          '#options' => ['' => $this->t('- Select a field -')] + $all_field_options,
          '#default_value' => $current_mappings['intermediate_summary'] ?? '',
          '#description' => $this->t('Default field for storing the intermediate structured summary (RewriteContent plugin).'),
        ];

        // Introduction content field.
        $form['content_type_field_mappings_wrapper']['content_type_field_mappings'][$content_type_id]['introduction_content'] = [
          '#type' => 'select',
          '#title' => $this->t('Introduction Content Field'),
          '#options' => ['' => $this->t('- Select a field -')] + $text_field_options,
          '#default_value' => $current_mappings['introduction_content'] ?? '',
          '#description' => $this->t('Default field for storing AI-generated introductions (IntroductionContent plugin).'),
        ];

        // Summary content field.
        $form['content_type_field_mappings_wrapper']['content_type_field_mappings'][$content_type_id]['summary_content'] = [
          '#type' => 'select',
          '#title' => $this->t('Summary Content Field'),
          '#options' => ['' => $this->t('- Select a field -')] + $text_field_options,
          '#default_value' => $current_mappings['summary_content'] ?? '',
          '#description' => $this->t('Default field for storing AI-generated summaries (SummaryContent plugin).'),
        ];

        // Quality assessment field.
        $form['content_type_field_mappings_wrapper']['content_type_field_mappings'][$content_type_id]['quality_assessment'] = [
          '#type' => 'select',
          '#title' => $this->t('Quality Assessment Field'),
          '#options' => ['' => $this->t('- Select a field -')] + $text_field_options,
          '#default_value' => $current_mappings['quality_assessment'] ?? '',
          '#description' => $this->t('Default field for storing content quality assessment results from the Content Quality Checker in JSON format. This data can be used for aggregating scores across multiple pages.'),
        ];
      }
    }
    else {
      $form['content_type_field_mappings_wrapper']['#markup'] = $this->t('Please select one or more content types above to configure their default field mappings.');
    }
  }

  /**
   * Process field mappings from form submission.
   *
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   Processed field mappings.
   */
  protected function processFieldMappings(FormStateInterface $form_state): array {
    $field_mappings = $form_state->getValue('content_type_field_mappings') ?: [];
    $processed_mappings = [];

    foreach ($field_mappings as $content_type => $mappings) {
      $filtered_mappings = [];
      foreach ($mappings as $mapping_type => $field_name) {
        if (!empty($field_name)) {
          $filtered_mappings[$mapping_type] = $field_name;
        }
      }
      if (!empty($filtered_mappings)) {
        $processed_mappings[$content_type] = $filtered_mappings;
      }
    }

    return $processed_mappings;
  }

  /**
   * Get text field options for the given content type.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field labels keyed by field names.
   */
  protected function getTextFieldOptionsForContentType($content_type): array {
    $field_options = [];
    $fields = $this->entityTypeManager->getStorage('field_config')->loadByProperties([
      'entity_type' => 'node',
      'bundle' => $content_type,
    ]);

    foreach ($fields as $field) {
      $field_type = $field->getType();
      if (in_array($field_type, ['text_with_summary', 'text_long', 'text', 'string_long'])) {
        $composite_key = $field_type . ':' . $field->getName();
        $field_options[$composite_key] = $field->getLabel();
      }
    }

    return $field_options;
  }

  /**
   * Get all relevant field options (text and paragraph) for the given content type.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field labels keyed by field names.
   */
  protected function getAllFieldOptionsForContentType($content_type): array {
    $field_options = [];
    $fields = $this->entityTypeManager->getStorage('field_config')->loadByProperties([
      'entity_type' => 'node',
      'bundle' => $content_type,
    ]);

    foreach ($fields as $field) {
      $field_type = $field->getType();
      $field_name = $field->getName();

      if (in_array($field_type, ['text_with_summary', 'text_long', 'text', 'string_long'])) {
        $composite_key = $field_type . ':' . $field_name;
        $field_options[$composite_key] = $field->getLabel() . ' (Text)';
      }
      elseif ($field_type === 'entity_reference_revisions') {
        $target_type = $field->getSetting('target_type');
        if ($target_type === 'paragraph') {
          $composite_key = $field_type . ':' . $field_name;
          $field_options[$composite_key] = $field->getLabel() . ' (Paragraph)';
        }
      }
    }

    return $field_options;
  }

}
