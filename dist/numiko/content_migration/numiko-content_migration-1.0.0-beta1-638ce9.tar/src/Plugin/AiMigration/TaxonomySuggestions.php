<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

use Drupal\content_migration\Plugin\AiMigrationPluginBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\field\Entity\FieldConfig;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Plugin for generating taxonomy term suggestions using AI.
 *
 * @AiMigration(
 *   id = "taxonomy_suggestions",
 *   label = @Translation("Taxonomy Suggestions"),
 *   description = @Translation("Generates taxonomy term suggestions for selected taxonomy fields based on content analysis.")
 * )
 */
class TaxonomySuggestions extends AiMigrationPluginBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = parent::create($container, $configuration, $plugin_id, $plugin_definition);
    $instance->entityTypeManager = $container->get('entity_type.manager');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function configurationForm(array $form, FormStateInterface $form_state, array $configuration = []): array {
    $content_type = $form_state->getValue('content_type');

    if (!$content_type) {
      return [
        '#markup' => $this->t('Please select a content type first.'),
      ];
    }

    $taxonomy_fields = $this->getTaxonomyFieldOptions($content_type);

    if (empty($taxonomy_fields)) {
      return [
        '#markup' => $this->t('No taxonomy fields found for this content type.'),
      ];
    }

    $form['taxonomy_fields'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Taxonomy Fields'),
      '#options' => $taxonomy_fields,
      '#default_value' => $configuration['taxonomy_fields'] ?? [],
      '#description' => $this->t('Select the taxonomy fields to generate suggestions for. Leave all unchecked to skip this plugin.'),
    ];

    $form['max_suggestions'] = [
      '#type' => 'number',
      '#title' => $this->t('Maximum Suggestions per Field'),
      '#default_value' => $configuration['max_suggestions'] ?? 5,
      '#min' => 1,
      '#max' => 20,
      '#description' => $this->t('Maximum number of taxonomy terms to suggest for each field.'),
    ];

    $form['auto_create_terms'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Auto-create New Terms'),
      '#default_value' => $configuration['auto_create_terms'] ?? TRUE,
      '#description' => $this->t('Automatically create new taxonomy terms if they do not exist.'),
    ];

    $form['suggestion_style'] = [
      '#type' => 'select',
      '#title' => $this->t('Suggestion Style'),
      '#options' => [
        'keywords' => $this->t('Keywords (single words or short phrases)'),
        'topics' => $this->t('Topics (broader subject areas)'),
        'categories' => $this->t('Categories (hierarchical classification)'),
        'tags' => $this->t('Tags (descriptive labels)'),
      ],
      '#default_value' => $configuration['suggestion_style'] ?? 'keywords',
      '#description' => $this->t('The style of taxonomy terms to suggest.'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $taxonomy_fields = $form_state->getValue('taxonomy_fields');
    
    // Allow empty selection to disable plugin - no validation needed
    // Users can leave all fields unchecked to skip this plugin
  }

  /**
   * {@inheritdoc}
   */
  public function processContent(string $content, NodeInterface $node, array $configuration): array {
    $taxonomy_fields = array_filter($configuration['taxonomy_fields'] ?? []);
    $max_suggestions = (int) ($configuration['max_suggestions'] ?? 5);
    $auto_create_terms = $configuration['auto_create_terms'] ?? TRUE;
    $suggestion_style = $configuration['suggestion_style'] ?? 'keywords';

    // If no taxonomy fields configured, skip processing
    if (empty($taxonomy_fields)) {
      return [
        'skipped' => TRUE,
        'reason' => 'No taxonomy fields configured for this plugin',
      ];
    }

    $results = [];

    foreach ($taxonomy_fields as $field_name) {
      if (empty($field_name)) {
        continue;
      }

      try {
        // Get the field definition to understand the vocabulary.
        $field_definitions = $this->entityFieldManager->getFieldDefinitions('node', $node->bundle());

        if (!isset($field_definitions[$field_name])) {
          continue;
        }

        $field_definition = $field_definitions[$field_name];
        $vocabulary_id = $field_definition->getSetting('handler_settings')['target_bundles'][0] ?? null;

        if (!$vocabulary_id) {
          continue;
        }

        // Generate suggestions for this field.
        $suggestions = $this->generateTaxonomySuggestions(
          $content,
          $vocabulary_id,
          $max_suggestions,
          $suggestion_style
        );

        // Process the suggestions and assign to the field.
        $term_ids = $this->processSuggestions($suggestions, $vocabulary_id, $auto_create_terms);

        if (!empty($term_ids)) {
          $node->set($field_name, $term_ids);
          $results[$field_name] = [
            'suggestions' => $suggestions,
            'term_ids' => $term_ids,
          ];
        }
      }
      catch (\Exception $e) {
        // Log the error but continue with other fields.
        $this->loggerFactory->get('content_migration')->warning(
          'Failed to process taxonomy suggestions for field @field: @error',
          ['@field' => $field_name, '@error' => $e->getMessage()]
        );
      }
    }

    return $results;
  }

  /**
   * Gets taxonomy field options for the given content type.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field labels keyed by field names.
   */
  protected function getTaxonomyFieldOptions(string $content_type): array {
    $field_options = [];
    $fields = $this->entityFieldManager->getFieldDefinitions('node', $content_type);

    foreach ($fields as $field_name => $field_definition) {
      if ($field_definition instanceof FieldConfig) {
        $field_type = $field_definition->getType();
        if ($field_type === 'entity_reference' &&
            $field_definition->getSetting('target_type') === 'taxonomy_term') {
          $field_options[$field_name] = $field_definition->getLabel();
        }
      }
    }

    return $field_options;
  }

  /**
   * Generates taxonomy term suggestions using AI.
   *
   * @param string $content
   *   The content to analyze.
   * @param string $vocabulary_id
   *   The vocabulary ID.
   * @param int $max_suggestions
   *   Maximum number of suggestions.
   * @param string $style
   *   The suggestion style.
   *
   * @return array
   *   Array of suggested terms.
   */
  protected function generateTaxonomySuggestions(string $content, string $vocabulary_id, int $max_suggestions, string $style): array {
    // Get existing terms in the vocabulary for context.
    $existing_terms = $this->getExistingTerms($vocabulary_id);
    $existing_terms_text = empty($existing_terms) ? 'No existing terms.' : implode(', ', $existing_terms);

    $prompt = $this->buildTaxonomyPrompt($content, $vocabulary_id, $max_suggestions, $style, $existing_terms_text);

    // Make the API call.
    $response = $this->makeClaudeRequest($prompt);

    // Parse the response to extract term suggestions.
    return $this->parseSuggestions($response);
  }

  /**
   * Builds the prompt for taxonomy suggestions.
   *
   * @param string $content
   *   The content to analyze.
   * @param string $vocabulary_id
   *   The vocabulary ID.
   * @param int $max_suggestions
   *   Maximum number of suggestions.
   * @param string $style
   *   The suggestion style.
   * @param string $existing_terms
   *   Existing terms in the vocabulary.
   *
   * @return string
   *   The complete prompt for Claude API.
   */
  protected function buildTaxonomyPrompt(string $content, string $vocabulary_id, int $max_suggestions, string $style, string $existing_terms): string {
    $style_instructions = $this->getStyleInstructions($style);

    return <<<EOT
Analyze the following content and suggest appropriate taxonomy terms for the "{$vocabulary_id}" vocabulary.

Style: {$style_instructions}

Existing terms in this vocabulary: {$existing_terms}

Content to analyze:
{$content}

Requirements:
- Suggest up to {$max_suggestions} relevant terms
- Terms should be {$style_instructions}
- Use UK English spelling
- Consider existing terms but you can suggest new ones
- Return only the term names, one per line
- No explanations or additional text

Example format:
Term 1
Term 2
Term 3
EOT;
  }

  /**
   * Gets style-specific instructions for taxonomy suggestions.
   *
   * @param string $style
   *   The suggestion style.
   *
   * @return string
   *   The style-specific instructions.
   */
  protected function getStyleInstructions(string $style): string {
    switch ($style) {
      case 'keywords':
        return 'specific keywords or short phrases (1-3 words) that describe key concepts';

      case 'topics':
        return 'broader topic areas or subject categories that encompass the main themes';

      case 'categories':
        return 'hierarchical categories that classify the content type or domain';

      case 'tags':
        return 'descriptive tags that help users find and filter content';

      default:
        return 'relevant terms that accurately describe the content';
    }
  }

  /**
   * Gets existing terms in a vocabulary.
   *
   * @param string $vocabulary_id
   *   The vocabulary ID.
   *
   * @return array
   *   Array of existing term names.
   */
  protected function getExistingTerms(string $vocabulary_id): array {
    $term_storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $terms = $term_storage->loadByProperties(['vid' => $vocabulary_id]);

    $term_names = [];
    foreach ($terms as $term) {
      $term_names[] = $term->label();
    }

    return array_slice($term_names, 0, 50); // Limit to 50 existing terms for context.
  }

  /**
   * Parses suggestions from the AI response.
   *
   * @param string $response
   *   The AI response.
   *
   * @return array
   *   Array of suggested terms.
   */
  protected function parseSuggestions(string $response): array {
    $lines = explode("\n", trim($response));
    $suggestions = [];

    foreach ($lines as $line) {
      $term = trim($line, '- ');
      $term = trim($term);

      if (!empty($term) && strlen($term) <= 255) {
        $suggestions[] = $term;
      }
    }

    return array_unique($suggestions);
  }

  /**
   * Processes suggestions and creates/finds taxonomy terms.
   *
   * @param array $suggestions
   *   Array of suggested term names.
   * @param string $vocabulary_id
   *   The vocabulary ID.
   * @param bool $auto_create
   *   Whether to auto-create new terms.
   *
   * @return array
   *   Array of term IDs.
   */
  protected function processSuggestions(array $suggestions, string $vocabulary_id, bool $auto_create): array {
    $term_storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $term_ids = [];

    foreach ($suggestions as $term_name) {
      // Try to find existing term.
      $existing_terms = $term_storage->loadByProperties([
        'name' => $term_name,
        'vid' => $vocabulary_id,
      ]);

      if (!empty($existing_terms)) {
        $term = reset($existing_terms);
        $term_ids[] = ['target_id' => $term->id()];
      }
      elseif ($auto_create) {
        // Create new term.
        try {
          $term = Term::create([
            'name' => $term_name,
            'vid' => $vocabulary_id,
          ]);
          $term->save();
          $term_ids[] = ['target_id' => $term->id()];
        }
        catch (\Exception $e) {
          // Log error but continue with other terms.
          $this->loggerFactory->get('content_migration')->warning(
            'Failed to create taxonomy term "@term" in vocabulary "@vocab": @error',
            [
              '@term' => $term_name,
              '@vocab' => $vocabulary_id,
              '@error' => $e->getMessage(),
            ]
          );
        }
      }
    }

    return $term_ids;
  }

}