<?php

namespace Drupal\content_migration\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\content_migration\Plugin\AiMigrationPluginManager;
use Drupal\content_migration\Service\UrlContentFetcherService;
use Drupal\menu_link_content\Entity\MenuLinkContent;
use Drupal\redirect\Entity\Redirect;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Controller for handling URL content import operations.
 */
class ContentImportController extends ControllerBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The request stack.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * The AI migration plugin manager.
   *
   * @var \Drupal\content_migration\Plugin\AiMigrationPluginManager
   */
  protected $aiMigrationPluginManager;

  /**
   * The URL content fetcher service.
   *
   * @var \Drupal\content_migration\Service\UrlContentFetcherService
   */
  protected $urlContentFetcher;

  /**
   * The module handler.
   *
   * @var \Drupal\Core\Extension\ModuleHandlerInterface
   */
  protected $moduleHandler;

  /**
   * Constructs a ContentImportController object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Symfony\Component\HttpFoundation\RequestStack $request_stack
   *   The request stack.
   * @param \Drupal\content_migration\Plugin\AiMigrationPluginManager $ai_migration_plugin_manager
   *   The AI migration plugin manager.
   * @param \Drupal\content_migration\Service\UrlContentFetcherService $url_content_fetcher
   *   The URL content fetcher service.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
    RequestStack $request_stack,
    AiMigrationPluginManager $ai_migration_plugin_manager,
    UrlContentFetcherService $url_content_fetcher,
    ModuleHandlerInterface $module_handler,
  ) {
    $this->entityTypeManager = $entity_type_manager;
    $this->requestStack = $request_stack;
    $this->aiMigrationPluginManager = $ai_migration_plugin_manager;
    $this->urlContentFetcher = $url_content_fetcher;
    $this->moduleHandler = $module_handler;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('request_stack'),
      $container->get('plugin.manager.ai_migration'),
      $container->get('content_migration.url_fetcher'),
      $container->get('module_handler')
    );
  }

  /**
   * Process content from a URL and save to a node.
   *
   * @param string $url
   *   The URL to import content from.
   * @param string $content_type
   *   The content type to create or update.
   * @param array $fields
   *   The fields to save the content to.
   * @param array $ai_plugins
   *   The AI plugin configurations to apply.
   * @param string|null $parent_menu_item
   *   The parent menu item ID to add the new node under.
   * @param bool $create_redirects
   *   Whether to create URL redirects.
   *
   * @return array
   *   A render array showing the results.
   */
  public function processUrl($url, $content_type, $fields, $ai_plugins, $parent_menu_item = NULL, $create_redirects = FALSE) {
    try {
      // Fetch HTML content from the URL.
      $htmlContent = $this->urlContentFetcher->fetchContent($url);
      $content = $this->urlContentFetcher->sanitizeHtml($htmlContent);

      // Create the node first.
      $node = $this->entityTypeManager->getStorage('node')->create([
        'type' => $content_type,
        'title' => $content['title'],
      ]);

      // Set the base content field.
      if (!empty($fields['body'])) {
        $node->set($fields['body'], [
          'value' => $content['content'],
          'format' => 'basic_html',
        ]);
      }

      // Process content using AI plugins.
      foreach ($ai_plugins as $plugin_id => $plugin_config) {
        if (!empty($plugin_config['enabled'])) {
          try {
            $plugin_instance = $this->aiMigrationPluginManager->createInstance($plugin_id);
            $plugin_instance->processContent($content['content'], $node, $plugin_config);
          }
          catch (\Exception $e) {
            $this->messenger()->addWarning($this->t('Failed to process content with @plugin: @error', [
              '@plugin' => $plugin_id,
              '@error' => $e->getMessage(),
            ]));
          }
        }
      }

      $node->save();

      // Create menu link if parent is specified.
      if (!empty($parent_menu_item)) {
        $this->createMenuLink($node, $parent_menu_item);
      }

      // Create redirect if requested.
      if ($create_redirects) {
        $this->createRedirect($url, $node);
      }

      $this->messenger()->addStatus($this->t('Content successfully imported from @url and saved to node @id.', [
        '@url' => $url,
        '@id' => $node->id(),
      ]));

      return [
        '#markup' => $this->t('Content imported successfully.'),
      ];
    }
    catch (\Exception $e) {
      $this->messenger()->addError($this->t('Error importing content: @error', ['@error' => $e->getMessage()]));
      return [
        '#markup' => $this->t('Import failed. See the error message for details.'),
      ];
    }
  }

  /**
   * Create a menu link for the node as a child of the specified parent.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to create a menu link for.
   * @param string $parent_menu_item
   *   The parent menu item plugin ID.
   */
  protected function createMenuLink($node, $parent_menu_item) {
    try {
      $menu_link = MenuLinkContent::create([
        'title' => $node->getTitle(),
        'link' => ['uri' => 'entity:node/' . $node->id()],
        'menu_name' => 'main',
        'parent' => $parent_menu_item,
        'expanded' => FALSE,
        'enabled' => TRUE,
        'weight' => 0,
      ]);
      $menu_link->save();

      $this->messenger()->addStatus($this->t('Menu link created for node @title under parent menu item.', [
        '@title' => $node->getTitle(),
      ]));
    }
    catch (\Exception $e) {
      $this->messenger()->addWarning($this->t('Failed to create menu link for node @title: @error', [
        '@title' => $node->getTitle(),
        '@error' => $e->getMessage(),
      ]));
    }
  }

  /**
   * Process content from multiple URLs and merge them into a single node.
   *
   * @param array $urls
   *   Array of URLs to import content from.
   * @param string $content_type
   *   The content type to create.
   * @param array $fields
   *   The fields to save the content to.
   * @param array $ai_plugins
   *   The AI plugin configurations to apply.
   * @param string|null $parent_menu_item
   *   The parent menu item ID to add the new node under.
   * @param bool $create_redirects
   *   Whether to create URL redirects.
   * @param array $merge_options
   *   Options for merging content.
   *
   * @return array
   *   A render array showing the results.
   */
  public function processMergedUrls($urls, $content_type, $fields, $ai_plugins, $parent_menu_item = NULL, $create_redirects = FALSE, $merge_options = []) {
    try {
      // Fetch content from all URLs
      $url_contents = [];
      $merged_title = $merge_options['merged_title'] ?? '';
      
      foreach ($urls as $url) {
        try {
          $htmlContent = $this->urlContentFetcher->fetchContent($url);
          $content = $this->urlContentFetcher->sanitizeHtml($htmlContent);
          $url_contents[] = [
            'url' => $url,
            'title' => $content['title'],
            'content' => $content['content'],
          ];
          
          // Use first URL's title if no merged title provided
          if (empty($merged_title)) {
            $merged_title = $content['title'];
          }
        }
        catch (\Exception $e) {
          $this->messenger()->addWarning($this->t('Failed to fetch content from @url: @error', [
            '@url' => $url,
            '@error' => $e->getMessage(),
          ]));
        }
      }
      
      if (empty($url_contents)) {
        throw new \Exception('No content could be fetched from any of the provided URLs.');
      }
      
      // Merge content from all URLs
      $merged_content = $this->mergeUrlContents($url_contents, $merge_options);
      
      // Create the node with merged content
      $node = $this->entityTypeManager->getStorage('node')->create([
        'type' => $content_type,
        'title' => $merged_title,
      ]);

      // Set the base content field with merged content
      if (!empty($fields['body'])) {
        $node->set($fields['body'], [
          'value' => $merged_content,
          'format' => 'basic_html',
        ]);
      }

      // Process merged content using AI plugins
      foreach ($ai_plugins as $plugin_id => $plugin_config) {
        if (!empty($plugin_config['enabled'])) {
          try {
            $plugin_instance = $this->aiMigrationPluginManager->createInstance($plugin_id);
            $plugin_instance->processContent($merged_content, $node, $plugin_config);
          }
          catch (\Exception $e) {
            $this->messenger()->addWarning($this->t('Failed to process merged content with @plugin: @error', [
              '@plugin' => $plugin_id,
              '@error' => $e->getMessage(),
            ]));
          }
        }
      }

      $node->save();

      // Create menu link if parent is specified
      if (!empty($parent_menu_item)) {
        $this->createMenuLink($node, $parent_menu_item);
      }

      // Create redirects for all URLs if requested
      if ($create_redirects) {
        foreach ($urls as $url) {
          $this->createRedirect($url, $node);
        }
      }

      $this->messenger()->addStatus($this->t('Content successfully merged from @count URLs and saved to node @id.', [
        '@count' => count($urls),
        '@id' => $node->id(),
      ]));

      return [
        '#markup' => $this->t('Merged content imported successfully.'),
      ];
    }
    catch (\Exception $e) {
      $this->messenger()->addError($this->t('Error importing merged content: @error', ['@error' => $e->getMessage()]));
      return [
        '#markup' => $this->t('Import failed. See the error message for details.'),
      ];
    }
  }

  /**
   * Merge content from multiple URLs based on merge options.
   *
   * @param array $url_contents
   *   Array of content from URLs.
   * @param array $merge_options
   *   Options for merging content.
   *
   * @return string
   *   The merged content.
   */
  protected function mergeUrlContents($url_contents, $merge_options) {
    $separator = $merge_options['content_separator'] ?? 'headers';
    $include_source_headers = $merge_options['include_source_headers'] ?? TRUE;
    
    $merged_parts = [];
    
    foreach ($url_contents as $index => $url_content) {
      $content_part = '';
      
      // Wrap each page's content in a section to preserve structure
      $content_part .= "<div class=\"merged-page-content\" data-source-url=\"{$url_content['url']}\">\n";
      
      // Add source header if enabled
      if ($include_source_headers && $separator === 'headers') {
        $header_text = $url_content['title'];
        $content_part .= "<h2 class=\"source-page-title\">{$header_text}</h2>\n";
      }
      
      // Add the complete extracted content from this page
      // This includes all headers, paragraphs, lists, and other structure
      $page_content = $this->preservePageStructure($url_content['content']);
      $content_part .= $page_content;
      
      // Close the page content wrapper
      $content_part .= "\n</div>";
      
      // Add separator between content sections
      if ($index < count($url_contents) - 1) {
        switch ($separator) {
          case 'dividers':
            $content_part .= "\n<hr class=\"page-separator\">\n";
            break;
          case 'headers':
            // Headers are added at the beginning of each section
            $content_part .= "\n\n";
            break;
          case 'none':
            // Minimal separator to distinguish pages
            $content_part .= "\n\n";
            break;
        }
      }
      
      $merged_parts[] = $content_part;
    }
    
    return implode('', $merged_parts);
  }

  /**
   * Preserve the complete structure of a page's content.
   *
   * @param string $content
   *   The raw content from a page.
   *
   * @return string
   *   The content with preserved structure.
   */
  protected function preservePageStructure($content) {
    // Ensure the content is properly formatted and structured
    $content = trim($content);
    
    // If content doesn't start with a block-level element, wrap it
    if (!preg_match('/^\s*<(h[1-6]|p|div|section|article|ul|ol|blockquote|table|figure|pre)/i', $content)) {
      $content = "<div class=\"page-content\">\n{$content}\n</div>";
    }
    
    // Ensure proper spacing after headings and before new sections
    $content = preg_replace('/(<\/h[1-6]>)(\s*)(<h[1-6])/i', '$1' . "\n\n" . '$3', $content);
    
    // Ensure proper spacing after paragraphs
    $content = preg_replace('/(<\/p>)(\s*)(<p)/i', '$1' . "\n\n" . '$3', $content);
    
    // Ensure proper spacing around lists
    $content = preg_replace('/(<\/ul>|<\/ol>)(\s*)(<h[1-6]|<p)/i', '$1' . "\n\n" . '$3', $content);
    $content = preg_replace('/(<\/h[1-6]>|<\/p>)(\s*)(<ul|<ol)/i', '$1' . "\n\n" . '$3', $content);
    
    // Ensure proper spacing around blockquotes
    $content = preg_replace('/(<\/blockquote>)(\s*)(<h[1-6]|<p)/i', '$1' . "\n\n" . '$3', $content);
    $content = preg_replace('/(<\/h[1-6]>|<\/p>)(\s*)(<blockquote)/i', '$1' . "\n\n" . '$3', $content);
    
    return $content;
  }

  /**
   * Create a redirect from the original URL to the new node.
   *
   * @param string $source_url
   *   The original URL to redirect from.
   * @param \Drupal\node\NodeInterface $node
   *   The node to redirect to.
   */
  protected function createRedirect($source_url, $node) {
    try {
      // Parse the URL to get just the path.
      $parsed_url = parse_url($source_url);
      $source_path = $parsed_url['path'] ?? '';

      // Remove leading slash if present.
      $source_path = ltrim($source_path, '/');

      if (empty($source_path)) {
        return;
      }

      // Check if redirect module is available.
      if (!$this->moduleHandler->moduleExists('redirect')) {
        $this->messenger()->addWarning($this->t('Redirect module is not enabled. Cannot create redirect for @url', [
          '@url' => $source_url,
        ]));
        return;
      }

      // Create the redirect.
      $redirect = Redirect::create([
        'redirect_source' => $source_path,
        'redirect_redirect' => 'internal:/node/' . $node->id(),
        'language' => $node->language()->getId(),
        'status_code' => 301,
      ]);
      $redirect->save();

      $this->messenger()->addStatus($this->t('Redirect created from @source to node @title.', [
        '@source' => $source_path,
        '@title' => $node->getTitle(),
      ]));
    }
    catch (\Exception $e) {
      $this->messenger()->addWarning($this->t('Failed to create redirect from @url: @error', [
        '@url' => $source_url,
        '@error' => $e->getMessage(),
      ]));
    }
  }

}
