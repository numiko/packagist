<?php

namespace Drupal\content_migration\Form;

use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Menu\MenuLinkManagerInterface;
use Drupal\content_migration\Controller\ContentImportController;
use Drupal\content_migration\Plugin\AiMigrationPluginManager;
use Drupal\content_migration\Service\TaxonomyPromptService;
use Drupal\field\Entity\FieldConfig;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Form for importing content from URLs using Claude API.
 */
class ContentImportForm extends FormBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * The content import controller.
   *
   * @var \Drupal\content_migration\Controller\ContentImportController
   */
  protected $contentImportController;

  /**
   * The menu link manager.
   *
   * @var \Drupal\Core\Menu\MenuLinkManagerInterface
   */
  protected $menuLinkManager;

  /**
   * The AI migration plugin manager.
   *
   * @var \Drupal\content_migration\Plugin\AiMigrationPluginManager
   */
  protected $aiMigrationPluginManager;

  /**
   * The taxonomy prompt service.
   *
   * @var \Drupal\content_migration\Service\TaxonomyPromptService
   */
  protected $taxonomyPromptService;

  /**
   * Constructs a ContentImportForm object.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entity_field_manager
   *   The entity field manager.
   * @param \Drupal\content_migration\Controller\ContentImportController $content_import_controller
   *   The content import controller.
   * @param \Drupal\Core\Menu\MenuLinkManagerInterface $menu_link_manager
   *   The menu link manager.
   * @param \Drupal\content_migration\Plugin\AiMigrationPluginManager $ai_migration_plugin_manager
   *   The AI migration plugin manager.
   * @param \Drupal\content_migration\Service\TaxonomyPromptService $taxonomy_prompt_service
   *   The taxonomy prompt service.
   */
  public function __construct(
    EntityTypeManagerInterface $entity_type_manager,
    EntityFieldManagerInterface $entity_field_manager,
    ContentImportController $content_import_controller,
    MenuLinkManagerInterface $menu_link_manager,
    AiMigrationPluginManager $ai_migration_plugin_manager,
    TaxonomyPromptService $taxonomy_prompt_service,
  ) {
    $this->entityTypeManager = $entity_type_manager;
    $this->entityFieldManager = $entity_field_manager;
    $this->contentImportController = $content_import_controller;
    $this->menuLinkManager = $menu_link_manager;
    $this->aiMigrationPluginManager = $ai_migration_plugin_manager;
    $this->taxonomyPromptService = $taxonomy_prompt_service;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('entity_field.manager'),
      $container->get('content_migration.content_import_controller'),
      $container->get('plugin.manager.menu.link'),
      $container->get('plugin.manager.ai_migration'),
      $container->get('content_migration.taxonomy_prompt_service')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'content_migration_import_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Get content types for selection.
    $content_types = $this->entityTypeManager->getStorage('node_type')->loadMultiple();
    $content_type_options = [];
    foreach ($content_types as $content_type) {
      $content_type_options[$content_type->id()] = $content_type->label();
    }

    $form['url_input'] = [
      '#type' => 'textarea',
      '#title' => $this->t('URLs'),
      '#description' => $this->t('Enter one or more URLs, one per line. Content will be extracted from these URLs.'),
      '#required' => TRUE,
      '#rows' => 5,
    ];

    $form['merge_urls'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Merge multiple URLs into one page'),
      '#description' => $this->t('When enabled, content from all URLs will be merged into a single page instead of creating separate pages for each URL.'),
      '#default_value' => FALSE,
    ];

    $form['merge_options'] = [
      '#type' => 'details',
      '#title' => $this->t('Merge Options'),
      '#open' => FALSE,
      '#states' => [
        'visible' => [
          ':input[name="merge_urls"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['merge_options']['merged_title'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Title for merged page'),
      '#description' => $this->t('Enter a title for the merged page. Leave empty to use the title from the first URL.'),
      '#states' => [
        'visible' => [
          ':input[name="merge_urls"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['merge_options']['include_source_headers'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Include source headers'),
      '#description' => $this->t('Add headings to separate content from different URLs, showing the source URL or page title.'),
      '#default_value' => TRUE,
      '#states' => [
        'visible' => [
          ':input[name="merge_urls"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['merge_options']['content_separator'] = [
      '#type' => 'select',
      '#title' => $this->t('Content separation method'),
      '#description' => $this->t('How to separate content from different URLs.'),
      '#options' => [
        'headers' => $this->t('Use headings with source titles'),
        'dividers' => $this->t('Use horizontal dividers'),
        'none' => $this->t('No separation (continuous content)'),
      ],
      '#default_value' => 'headers',
      '#states' => [
        'visible' => [
          ':input[name="merge_urls"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['content_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Content Type'),
      '#options' => $content_type_options,
      '#required' => TRUE,
      '#ajax' => [
        'callback' => '::updateFieldOptions',
        'wrapper' => 'field-options-wrapper',
      ],
    ];

    // Add menu parent selection field.
    $form['parent_menu_item'] = [
      '#type' => 'select',
      '#title' => $this->t('Parent Menu Item'),
      '#options' => $this->getMainMenuOptions(),
      '#empty_option' => $this->t('- Do not add to menu -'),
      '#description' => $this->t('Select a parent menu item. New nodes will be added as children of this item in the main menu.'),
    ];


    $form['field_options_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'field-options-wrapper'],
    ];

    $content_type = $form_state->getValue('content_type');
    if ($content_type) {
      // Base content field.
      $form['field_options_wrapper']['field_body'] = [
        '#type' => 'select',
        '#title' => $this->t('Field for extracted body content'),
        '#options' => $this->getTextFieldOptions($content_type),
        '#required' => TRUE,
        '#description' => $this->t('Select the field where the extracted body content should be saved.'),
      ];

      // AI plugins configuration.
      $form['field_options_wrapper']['ai_plugins'] = [
        '#type' => 'details',
        '#title' => $this->t('AI Processing Options'),
        '#open' => TRUE,
        '#tree' => TRUE,
      ];

      // Get all available AI plugins.
      $available_plugins = $this->aiMigrationPluginManager->getDefinitions();
      
      foreach ($available_plugins as $plugin_id => $plugin_definition) {
        $plugin_instance = $this->aiMigrationPluginManager->createInstance($plugin_id);
        
        $form['field_options_wrapper']['ai_plugins'][$plugin_id] = [
          '#type' => 'details',
          '#title' => $plugin_instance->getLabel(),
          '#description' => $plugin_instance->getDescription(),
          '#open' => FALSE,
          '#tree' => TRUE,
        ];

        $form['field_options_wrapper']['ai_plugins'][$plugin_id]['enabled'] = [
          '#type' => 'checkbox',
          '#title' => $this->t('Enable @plugin', ['@plugin' => $plugin_instance->getLabel()]),
          '#default_value' => FALSE,
        ];

        // Get the plugin's configuration form.
        $plugin_config = $form_state->getValue(['ai_plugins', $plugin_id, 'config']) ?? [];
        $plugin_form = $plugin_instance->configurationForm([], $form_state, $plugin_config);
        
        if (!empty($plugin_form)) {
          $form['field_options_wrapper']['ai_plugins'][$plugin_id]['config'] = $plugin_form;
          $form['field_options_wrapper']['ai_plugins'][$plugin_id]['config']['#tree'] = TRUE;
          $form['field_options_wrapper']['ai_plugins'][$plugin_id]['config']['#states'] = [
            'visible' => [
              ':input[name="ai_plugins[' . $plugin_id . '][enabled]"]' => ['checked' => TRUE],
            ],
          ];
        }
      }
    }
    else {
      // Default empty field selection until content type is chosen.
      $form['field_options_wrapper']['field_body'] = [
        '#type' => 'select',
        '#title' => $this->t('Field for extracted body content'),
        '#options' => [],
        '#description' => $this->t('Select a content type first.'),
        '#disabled' => TRUE,
      ];

      $form['field_options_wrapper']['ai_plugins'] = [
        '#markup' => $this->t('Please select a content type first to configure AI processing options.'),
      ];
    }

    $form['create_redirects'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Create URL redirects'),
      '#description' => $this->t('Create redirects from the original URLs to the newly created nodes.'),
      '#default_value' => TRUE,
    ];

    $form['actions'] = [
      '#type' => 'actions',
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Import Content'),
    ];

    return $form;
  }

  /**
   * Ajax callback to update the field options based on selected content type.
   */
  public function updateFieldOptions(array &$form, FormStateInterface $form_state) {
    return $form['field_options_wrapper'];
  }


  /**
   * Get text and text long field options for the given content type.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field labels keyed by field names.
   */
  protected function getTextFieldOptions($content_type) {
    $field_options = [];
    $fields = $this->entityFieldManager->getFieldDefinitions('node', $content_type);

    foreach ($fields as $field_name => $field_definition) {
      if ($field_definition instanceof FieldConfig) {
        $field_type = $field_definition->getType();
        // Get fields of type text, text_long, text_with_summary.
        if (in_array($field_type, ['text_with_summary', 'text_long', 'text'])) {
          $field_options[$field_name] = $field_definition->getLabel();
        }
      }
    }

    return $field_options;
  }

  /**
   * Get main menu items as options for the select list.
   *
   * @return array
   *   An array of menu item titles keyed by menu link IDs.
   */
  protected function getMainMenuOptions() {
    $options = [];

    // Load all menu links from the main menu.
    $menu_links = $this->menuLinkManager->loadLinksByRoute('entity.node.canonical', [], 'main');

    // Also get menu links that might not be node-based.
    $all_main_links = $this->entityTypeManager->getStorage('menu_link_content')->loadByProperties(['menu_name' => 'main']);

    foreach ($all_main_links as $menu_link) {
      if ($menu_link->isEnabled()) {
        $title = $menu_link->getTitle();
        $options[$menu_link->getPluginId()] = $title;
      }
    }

    return $options;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    // Validate URLs.
    $urls = explode("\n", trim($form_state->getValue('url_input')));
    $urls = array_map('trim', $urls);
    $urls = array_filter($urls);

    if (empty($urls)) {
      $form_state->setErrorByName('url_input', $this->t('Please enter at least one valid URL.'));
    }

    foreach ($urls as $url) {
      if (!filter_var($url, FILTER_VALIDATE_URL)) {
        $form_state->setErrorByName('url_input', $this->t('@url is not a valid URL.', ['@url' => $url]));
      }
    }

    // Validate merge options
    $merge_urls = $form_state->getValue('merge_urls');
    if ($merge_urls && count($urls) < 2) {
      $form_state->setErrorByName('url_input', $this->t('At least 2 URLs are required for merging content.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $urls = explode("\n", trim($form_state->getValue('url_input')));
    $urls = array_map('trim', $urls);
    $urls = array_filter($urls);

    $content_type = $form_state->getValue('content_type');
    $fields = [
      'body' => $form_state->getValue('field_body'),
    ];
    
    // Get AI plugin configurations.
    $ai_plugins = [];
    $ai_plugin_values = $form_state->getValue('ai_plugins') ?? [];
    
    foreach ($ai_plugin_values as $plugin_id => $plugin_data) {
      if (!empty($plugin_data['enabled'])) {
        $ai_plugins[$plugin_id] = $plugin_data['config'] ?? [];
        $ai_plugins[$plugin_id]['enabled'] = TRUE;
      }
    }
    
    $parent_menu_item = $form_state->getValue('parent_menu_item');
    $create_redirects = $form_state->getValue('create_redirects');
    $merge_urls = $form_state->getValue('merge_urls');

    $batch = [
      'title' => $this->t('Importing content from URLs'),
      'operations' => [],
      'finished' => '\Drupal\content_migration\Form\ContentImportForm::batchFinished',
      'init_message' => $this->t('Starting content import...'),
      'progress_message' => $this->t('Processed @current out of @total.'),
      'error_message' => $this->t('Content import has encountered an error.'),
    ];

    if ($merge_urls) {
      // Single batch operation for merged content
      $merge_options = [
        'merged_title' => $form_state->getValue('merged_title'),
        'include_source_headers' => $form_state->getValue('include_source_headers'),
        'content_separator' => $form_state->getValue('content_separator'),
      ];
      
      $batch['operations'][] = [
        '\Drupal\content_migration\Form\ContentImportForm::processMergedUrlsBatch',
        [$urls, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, $merge_options],
      ];
    } else {
      // Individual batch operations for each URL
      foreach ($urls as $index => $url) {
        $batch['operations'][] = [
          '\Drupal\content_migration\Form\ContentImportForm::processUrlBatch',
          [$url, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects],
        ];
      }
    }

    batch_set($batch);
  }

  /**
   * Batch operation to process a URL.
   */
  public static function processUrlBatch($url, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, &$context) {
    $controller = \Drupal::service('content_migration.content_import_controller');
    try {
      $controller->processUrl($url, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects);
      $context['results'][] = $url;
      $context['message'] = t('Imported content from @url', ['@url' => $url]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = t('Error importing from @url: @error', [
        '@url' => $url,
        '@error' => $e->getMessage(),
      ]);
    }
  }

  /**
   * Batch operation to process multiple URLs as merged content.
   */
  public static function processMergedUrlsBatch($urls, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, $merge_options, &$context) {
    $controller = \Drupal::service('content_migration.content_import_controller');
    try {
      $controller->processMergedUrls($urls, $content_type, $fields, $ai_plugins, $parent_menu_item, $create_redirects, $merge_options);
      $context['results'][] = t('Merged content from @count URLs', ['@count' => count($urls)]);
      $context['message'] = t('Imported merged content from @count URLs', ['@count' => count($urls)]);
    }
    catch (\Exception $e) {
      $context['results']['errors'][] = t('Error importing merged content: @error', [
        '@error' => $e->getMessage(),
      ]);
    }
  }

  /**
   * Batch finished callback.
   */
  public static function batchFinished($success, $results, $operations) {
    $messenger = \Drupal::messenger();

    if ($success) {
      $count = count($results) - (isset($results['errors']) ? 1 : 0);
      $messenger->addStatus(\Drupal::translation()->formatPlural(
        $count,
        'Successfully imported content from 1 URL.',
        'Successfully imported content from @count URLs.'
      ));

      if (isset($results['errors'])) {
        foreach ($results['errors'] as $error) {
          $messenger->addError($error);
        }
      }
    }
    else {
      $messenger->addError(t('An error occurred while importing content.'));
    }
  }

}
