<?php

namespace Drupal\content_migration\Form;

use Drupal\content_migration\Service\TaxonomyPromptService;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Settings form for Content Moderation URL module.
 */
class SettingsForm extends ConfigFormBase {

  /**
   * The taxonomy prompt service.
   *
   * @var \Drupal\content_migration\Service\TaxonomyPromptService
   */
  protected $taxonomyPromptService;

  /**
   * Constructs a SettingsForm object.
   *
   * @param \Drupal\content_migration\Service\TaxonomyPromptService $taxonomy_prompt_service
   *   The taxonomy prompt service.
   */
  public function __construct(TaxonomyPromptService $taxonomy_prompt_service) {
    $this->taxonomyPromptService = $taxonomy_prompt_service;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('content_migration.taxonomy_prompt_service')
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['content_migration.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'content_migration_settings_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('content_migration.settings');

    $form['api_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Claude API Settings'),
      '#open' => TRUE,
    ];

    $form['api_settings']['claude_api_key'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Claude API Key'),
      '#description' => $this->t('Enter your Claude API key. You can obtain one from <a href="https://console.anthropic.com/" target="_blank">Anthropic Console</a>.'),
      '#default_value' => $config->get('claude_api_key'),
      '#required' => TRUE,
    ];

    $form['api_settings']['claude_api_model'] = [
      '#type' => 'select',
      '#title' => $this->t('Claude Model'),
      '#description' => $this->t('Select the Claude model to use for content extraction.'),
      '#options' => [
        'claude-3-haiku-20240307' => $this->t('Claude 3 Haiku (Faster, lower cost)'),
        'claude-3-5-haiku-20241022' => $this->t('Claude 3.5 Haiku (Faster, lower cost)'),
        'claude-3-sonnet-20240229' => $this->t('Claude 3 Sonnet (Balanced)'),
        'claude-sonnet-4-20250514' => $this->t('Claude Sonnet 4 (Balanced)'),
        'claude-3-opus-20240229' => $this->t('Claude 3 Opus (Highest quality)'),
        'claude-opus-4-20250514' => $this->t('Claude Opus 4 (Highest quality)'),
      ],
      '#default_value' => $config->get('claude_api_model') ?: 'claude-3-haiku-20240307',
    ];

    $form['content_extraction'] = [
      '#type' => 'details',
      '#title' => $this->t('Content Extraction Settings'),
      '#open' => TRUE,
    ];

    $default_prompt = <<<EOT
I'll provide you with HTML content from a webpage. Please extract the following information:

1. The page title - use the main heading (usually an h1) rather than the HTML title tag if they differ
2. The main body content - extract the main article text, ignoring navigation, headers, footers, sidebars, comments, etc.

Format your response as a JSON object with two fields:
- "title": The page title
- "body": The main body content, preserving paragraphs and basic formatting

Here's the HTML content:

{html_content}

Please respond only with valid JSON following this format:
{
  "title": "The page title goes here",
  "body": "The main content goes here. It may span multiple paragraphs and include basic formatting."
}
EOT;

    $form['content_extraction']['claude_api_prompt'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Extraction Prompt'),
      '#description' => $this->t('The prompt to send to Claude API. Use {html_content} as a placeholder for the HTML content.'),
      '#default_value' => $config->get('claude_api_prompt') ?: $default_prompt,
      '#rows' => 15,
    ];

    $form['content_extraction']['reset_prompt'] = [
      '#type' => 'button',
      '#value' => $this->t('Reset to Default'),
      '#attributes' => [
        'onclick' => 'document.getElementById("edit-claude-api-prompt").value = ' . json_encode($default_prompt) . '; return false;',
      ],
    ];

    $form['audience_settings'] = [
      '#type' => 'details',
      '#title' => $this->t('Audience Targeting Settings'),
      '#open' => TRUE,
    ];

    $form['audience_settings']['audience_vocabulary'] = [
      '#type' => 'select',
      '#title' => $this->t('Audience Vocabulary'),
      '#options' => $this->taxonomyPromptService->getVocabularyOptions(),
      '#default_value' => $config->get('audience_vocabulary') ?: '',
      '#description' => $this->t('Select a taxonomy vocabulary. It should be a hierarchical taxonomy, with the root term containing the global style guide prompt in its description. Its child terms should have the different audience prompts in their descriptions. These terms will be available for selection during content import to tailor the AI processing.'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $api_key = $form_state->getValue('claude_api_key');
    if (empty($api_key)) {
      $form_state->setErrorByName('claude_api_key', $this->t('Claude API key is required.'));
    }

    $prompt = $form_state->getValue('claude_api_prompt');
    if (strpos($prompt, '{html_content}') === FALSE) {
      $form_state->setErrorByName('claude_api_prompt', $this->t('The prompt must contain the {html_content} placeholder.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('content_migration.settings')
      ->set('claude_api_key', $form_state->getValue('claude_api_key'))
      ->set('claude_api_model', $form_state->getValue('claude_api_model'))
      ->set('claude_api_prompt', $form_state->getValue('claude_api_prompt'))
      ->set('audience_vocabulary', $form_state->getValue('audience_vocabulary'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
