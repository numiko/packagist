<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Import;

use Drupal\content_migration\AiMigrationPluginManager;
use Drupal\content_migration\Import\CsvImportProcessor;
use Drupal\content_migration\Service\ContentExtractionService;
use Drupal\content_migration\Service\HtmlParserService;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\content_migration\Service\RedirectService;
use Drupal\content_migration\Service\UrlAliasService;
use Drupal\content_migration\Service\UrlContentFetcherService;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\menu_link_content\MenuLinkContentInterface;
use Drupal\node\NodeInterface;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the CsvImportProcessor.
 *
 * @coversDefaultClass \Drupal\content_migration\Import\CsvImportProcessor
 * @group content_migration
 */
class CsvImportProcessorTest extends UnitTestCase {

  /**
   * The CSV import processor under test.
   *
   * @var \Drupal\content_migration\Import\CsvImportProcessor
   */
  protected CsvImportProcessor $processor;

  /**
   * Mock node builder service.
   *
   * @var \Drupal\content_migration\Service\NodeBuilderService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $nodeBuilder;

  /**
   * Mock menu link service.
   *
   * @var \Drupal\content_migration\Service\MenuLinkService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $menuLinkService;

  /**
   * Mock redirect service.
   *
   * @var \Drupal\content_migration\Service\RedirectService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $redirectService;

  /**
   * Mock AI migration plugin manager.
   *
   * @var \Drupal\content_migration\AiMigrationPluginManager|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $aiMigrationPluginManager;

  /**
   * Mock messenger.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $messenger;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * Mock URL content fetcher service.
   *
   * @var \Drupal\content_migration\Service\UrlContentFetcherService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $urlContentFetcher;

  /**
   * Mock content extraction service.
   *
   * @var \Drupal\content_migration\Service\ContentExtractionService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $contentExtraction;

  /**
   * Mock HTML parser service.
   *
   * @var \Drupal\content_migration\Service\HtmlParserService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $htmlParser;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->nodeBuilder = $this->createMock(NodeBuilderService::class);
    $this->menuLinkService = $this->createMock(MenuLinkService::class);
    $this->redirectService = $this->createMock(RedirectService::class);
    $this->aiMigrationPluginManager = $this->createMock(AiMigrationPluginManager::class);
    $this->messenger = $this->createMock(MessengerInterface::class);
    $this->logger = $this->createMock(LoggerInterface::class);
    $this->urlContentFetcher = $this->createMock(UrlContentFetcherService::class);
    $this->contentExtraction = $this->createMock(ContentExtractionService::class);
    $this->htmlParser = $this->createMock(HtmlParserService::class);

    $urlAliasService = $this->createMock(UrlAliasService::class);

    $this->processor = new CsvImportProcessor(
      $this->nodeBuilder,
      $this->menuLinkService,
      $this->redirectService,
      $this->aiMigrationPluginManager,
      $this->messenger,
      $this->logger,
      $urlAliasService,
      $this->urlContentFetcher,
      $this->contentExtraction,
      $this->htmlParser
    );

    // Setup string translation.
    $stringTranslation = $this->createMock(TranslationInterface::class);
    $stringTranslation->method('translateString')
      ->willReturnCallback(fn($string) => $string->getUntranslatedString());
    $this->processor->setStringTranslation($stringTranslation);
  }

  /**
   * Tests getId returns correct identifier.
   *
   * @covers ::getId
   */
  public function testGetId(): void {
    $this->assertEquals('csv', $this->processor->getId());
  }

  /**
   * Tests getLabel returns correct label.
   *
   * @covers ::getLabel
   */
  public function testGetLabel(): void {
    $this->assertEquals('CSV Import', $this->processor->getLabel());
  }

  /**
   * Tests validateData returns error for missing row data.
   *
   * @covers ::validateData
   */
  public function testValidateDataMissingRow(): void {
    $errors = $this->processor->validateData([]);
    $this->assertContains('CSV row data is required.', $errors);
  }

  /**
   * Tests validateData returns error for missing page_title.
   *
   * @covers ::validateData
   */
  public function testValidateDataMissingPageTitle(): void {
    $errors = $this->processor->validateData([
      'row' => [
        'content_type' => 'page',
      ],
    ]);
    $this->assertContains('Page title is required in CSV row.', $errors);
  }

  /**
   * Tests validateData returns error for missing content_type.
   *
   * @covers ::validateData
   */
  public function testValidateDataMissingContentType(): void {
    $errors = $this->processor->validateData([
      'row' => [
        'page_title' => 'Test Page',
      ],
    ]);
    $this->assertContains('Content type is required in CSV row.', $errors);
  }

  /**
   * Tests validateData passes with valid data.
   *
   * @covers ::validateData
   */
  public function testValidateDataValid(): void {
    $errors = $this->processor->validateData([
      'row' => [
        'page_title' => 'Test Page',
        'content_type' => 'page',
      ],
    ]);
    $this->assertEmpty($errors);
  }

  /**
   * Tests process creates node with menu link.
   *
   * @covers ::process
   */
  public function testProcessCreatesNodeWithMenuLink(): void {
    $data = [
      'row' => [
        'page_title' => 'Test Page',
        'content_type' => 'page',
        'parent_page_title' => '',
      ],
      'menu_links' => [],
      'weight_counters' => [],
    ];
    $configuration = [];

    $mockNode = $this->createMock(NodeInterface::class);
    $mockMenuLink = $this->createMock(MenuLinkContentInterface::class);

    $this->nodeBuilder->expects($this->once())
      ->method('createNode')
      ->with('page', 'Test Page')
      ->willReturn($mockNode);

    $mockNode->expects($this->once())
      ->method('save');

    $this->menuLinkService->expects($this->once())
      ->method('createHierarchicalMenuLink')
      ->with($mockNode, 'Test Page', NULL, 0)
      ->willReturn($mockMenuLink);

    $result = $this->processor->process($data, $configuration);
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests process fetches content from source_url when provided.
   *
   * @covers ::process
   */
  public function testProcessWithSourceUrl(): void {
    $data = [
      'row' => [
        'page_title' => 'Test Page',
        'content_type' => 'page',
        'source_url' => 'https://example.com/source',
        'parent_page_title' => '',
      ],
      'menu_links' => [],
      'weight_counters' => [],
    ];
    $configuration = [
      'create_redirects' => TRUE,
    ];

    $mockNode = $this->createMock(NodeInterface::class);
    $mockMenuLink = $this->createMock(MenuLinkContentInterface::class);

    $this->nodeBuilder->expects($this->once())
      ->method('createNode')
      ->with('page', 'Test Page')
      ->willReturn($mockNode);

    $this->urlContentFetcher->expects($this->once())
      ->method('fetchContent')
      ->with('https://example.com/source')
      ->willReturn('<html><body>Content</body></html>');

    $this->htmlParser->expects($this->once())
      ->method('sanitizeHtml')
      ->willReturn(['title' => 'Test', 'content' => 'Content']);

    $mockNode->expects($this->once())
      ->method('save');

    $this->redirectService->expects($this->once())
      ->method('createRedirect')
      ->with('https://example.com/source', $mockNode);

    $this->menuLinkService->expects($this->once())
      ->method('createHierarchicalMenuLink')
      ->willReturn($mockMenuLink);

    $result = $this->processor->process($data, $configuration);
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests process handles parent page hierarchy.
   *
   * @covers ::process
   */
  public function testProcessWithParentPage(): void {
    $parentMenuLink = $this->createMock(MenuLinkContentInterface::class);
    $data = [
      'row' => [
        'page_title' => 'Child Page',
        'content_type' => 'page',
        'parent_page_title' => 'Parent Page',
      ],
      'menu_links' => [
        'Parent Page' => $parentMenuLink,
      ],
      'weight_counters' => [],
    ];
    $configuration = [];

    $mockNode = $this->createMock(NodeInterface::class);
    $mockMenuLink = $this->createMock(MenuLinkContentInterface::class);

    $this->nodeBuilder->expects($this->once())
      ->method('createNode')
      ->with('page', 'Child Page')
      ->willReturn($mockNode);

    $mockNode->expects($this->once())
      ->method('save');

    $this->menuLinkService->expects($this->once())
      ->method('getPluginId')
      ->with($parentMenuLink)
      ->willReturn('menu_link_content:parent-uuid');

    $this->menuLinkService->expects($this->once())
      ->method('createHierarchicalMenuLink')
      ->with($mockNode, 'Child Page', 'menu_link_content:parent-uuid', 0)
      ->willReturn($mockMenuLink);

    $result = $this->processor->process($data, $configuration);
    $this->assertSame($mockNode, $result);
  }

}
