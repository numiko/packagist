<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Import;

use Drupal\content_migration\AiMigrationPluginManager;
use Drupal\content_migration\Import\PdfImportProcessor;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\content_migration\Service\RedirectService;
use Drupal\content_migration\Service\UrlAliasService;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\File\FileSystemInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\file\FileInterface;
use Drupal\Tests\UnitTestCase;
use GuzzleHttp\ClientInterface;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the PdfImportProcessor.
 *
 * @coversDefaultClass \Drupal\content_migration\Import\PdfImportProcessor
 * @group content_migration
 */
class PdfImportProcessorTest extends UnitTestCase {

  /**
   * The PDF import processor under test.
   *
   * @var \Drupal\content_migration\Import\PdfImportProcessor
   */
  protected PdfImportProcessor $processor;

  /**
   * Mock node builder service.
   *
   * @var \Drupal\content_migration\Service\NodeBuilderService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $nodeBuilder;

  /**
   * Mock menu link service.
   *
   * @var \Drupal\content_migration\Service\MenuLinkService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $menuLinkService;

  /**
   * Mock redirect service.
   *
   * @var \Drupal\content_migration\Service\RedirectService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $redirectService;

  /**
   * Mock AI migration plugin manager.
   *
   * @var \Drupal\content_migration\AiMigrationPluginManager|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $aiMigrationPluginManager;

  /**
   * Mock messenger.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $messenger;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * Mock config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $configFactory;

  /**
   * Mock HTTP client.
   *
   * @var \GuzzleHttp\ClientInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $httpClient;

  /**
   * Mock file system.
   *
   * @var \Drupal\Core\File\FileSystemInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $fileSystem;

  /**
   * Mock config object.
   *
   * @var \Drupal\Core\Config\ImmutableConfig|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $config;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->nodeBuilder = $this->createMock(NodeBuilderService::class);
    $this->menuLinkService = $this->createMock(MenuLinkService::class);
    $this->redirectService = $this->createMock(RedirectService::class);
    $this->aiMigrationPluginManager = $this->createMock(AiMigrationPluginManager::class);
    $this->messenger = $this->createMock(MessengerInterface::class);
    $this->logger = $this->createMock(LoggerInterface::class);
    $this->configFactory = $this->createMock(ConfigFactoryInterface::class);
    $this->httpClient = $this->createMock(ClientInterface::class);
    $this->fileSystem = $this->createMock(FileSystemInterface::class);
    $this->config = $this->createMock(ImmutableConfig::class);

    $this->configFactory->method('get')
      ->willReturn($this->config);

    $urlAliasService = $this->createMock(UrlAliasService::class);

    $this->processor = new PdfImportProcessor(
      $this->nodeBuilder,
      $this->menuLinkService,
      $this->redirectService,
      $this->aiMigrationPluginManager,
      $this->messenger,
      $this->logger,
      $urlAliasService,
      $this->configFactory,
      $this->httpClient,
      $this->fileSystem
    );

    // Setup string translation.
    $stringTranslation = $this->createMock(TranslationInterface::class);
    $stringTranslation->method('translateString')
      ->willReturnCallback(fn($string) => $string->getUntranslatedString());
    $this->processor->setStringTranslation($stringTranslation);
  }

  /**
   * Tests getId returns correct identifier.
   *
   * @covers ::getId
   */
  public function testGetId(): void {
    $this->assertEquals('pdf', $this->processor->getId());
  }

  /**
   * Tests getLabel returns correct label.
   *
   * @covers ::getLabel
   */
  public function testGetLabel(): void {
    $this->assertEquals('PDF Import', $this->processor->getLabel());
  }

  /**
   * Tests validateData returns error for missing file.
   *
   * @covers ::validateData
   */
  public function testValidateDataMissingFile(): void {
    $errors = $this->processor->validateData([]);
    $this->assertContains('PDF file is required.', $errors);
  }

  /**
   * Tests validateData returns error for invalid file object.
   *
   * @covers ::validateData
   */
  public function testValidateDataInvalidFileObject(): void {
    $errors = $this->processor->validateData([
      'file' => 'not-a-file-object',
    ]);
    $this->assertContains('Invalid file object provided.', $errors);
  }

  /**
   * Tests validateData passes with valid file.
   *
   * @covers ::validateData
   */
  public function testValidateDataValid(): void {
    $mockFile = $this->createMock(FileInterface::class);
    $errors = $this->processor->validateData([
      'file' => $mockFile,
    ]);
    $this->assertEmpty($errors);
  }

}
