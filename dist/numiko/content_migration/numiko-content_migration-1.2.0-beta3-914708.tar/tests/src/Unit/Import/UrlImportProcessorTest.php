<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Import;

use Drupal\content_migration\AiMigrationPluginManager;
use Drupal\content_migration\Import\UrlImportProcessor;
use Drupal\content_migration\Service\ContentExtractionService;
use Drupal\content_migration\Service\HtmlParserService;
use Drupal\content_migration\Service\MenuLinkService;
use Drupal\content_migration\Service\NodeBuilderService;
use Drupal\content_migration\Service\RedirectService;
use Drupal\content_migration\Service\UrlAliasService;
use Drupal\content_migration\Service\UrlContentFetcherService;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\node\NodeInterface;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the UrlImportProcessor.
 *
 * @coversDefaultClass \Drupal\content_migration\Import\UrlImportProcessor
 * @group content_migration
 */
class UrlImportProcessorTest extends UnitTestCase {

  /**
   * The processor under test.
   *
   * @var \Drupal\content_migration\Import\UrlImportProcessor
   */
  protected UrlImportProcessor $processor;

  /**
   * Mock node builder.
   *
   * @var \Drupal\content_migration\Service\NodeBuilderService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $nodeBuilder;

  /**
   * Mock menu link service.
   *
   * @var \Drupal\content_migration\Service\MenuLinkService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $menuLinkService;

  /**
   * Mock redirect service.
   *
   * @var \Drupal\content_migration\Service\RedirectService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $redirectService;

  /**
   * Mock messenger.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $messenger;

  /**
   * Mock URL content fetcher.
   *
   * @var \Drupal\content_migration\Service\UrlContentFetcherService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $urlContentFetcher;

  /**
   * Mock content extraction service.
   *
   * @var \Drupal\content_migration\Service\ContentExtractionService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $contentExtraction;

  /**
   * Mock HTML parser.
   *
   * @var \Drupal\content_migration\Service\HtmlParserService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $htmlParser;

  /**
   * Mock URL alias service.
   *
   * @var \Drupal\content_migration\Service\UrlAliasService|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $urlAliasService;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->nodeBuilder = $this->createMock(NodeBuilderService::class);
    $this->menuLinkService = $this->createMock(MenuLinkService::class);
    $this->redirectService = $this->createMock(RedirectService::class);
    $aiMigrationPluginManager = $this->createMock(AiMigrationPluginManager::class);
    $this->messenger = $this->createMock(MessengerInterface::class);
    $logger = $this->createMock(LoggerInterface::class);
    $this->urlAliasService = $this->createMock(UrlAliasService::class);
    $this->urlContentFetcher = $this->createMock(UrlContentFetcherService::class);
    $this->contentExtraction = $this->createMock(ContentExtractionService::class);
    $this->htmlParser = $this->createMock(HtmlParserService::class);

    $this->processor = new UrlImportProcessor(
      $this->nodeBuilder,
      $this->menuLinkService,
      $this->redirectService,
      $aiMigrationPluginManager,
      $this->messenger,
      $logger,
      $this->urlAliasService,
      $this->urlContentFetcher,
      $this->contentExtraction,
      $this->htmlParser
    );
    $this->processor->setStringTranslation($this->getStringTranslationStub());
  }

  /**
   * Tests getId returns correct identifier.
   *
   * @covers ::getId
   */
  public function testGetId(): void {
    $this->assertEquals('url', $this->processor->getId());
  }

  /**
   * Tests getLabel returns correct label.
   *
   * @covers ::getLabel
   */
  public function testGetLabel(): void {
    $this->assertEquals('URL Import', $this->processor->getLabel());
  }

  /**
   * Tests validateData returns error for missing URL.
   *
   * @covers ::validateData
   */
  public function testValidateDataMissingUrl(): void {
    $errors = $this->processor->validateData([]);
    $this->assertNotEmpty($errors);
    $this->assertContains('URL is required.', $errors);
  }

  /**
   * Tests validateData returns error for invalid URL.
   *
   * @covers ::validateData
   */
  public function testValidateDataInvalidUrl(): void {
    $errors = $this->processor->validateData(['url' => 'not-a-valid-url']);
    $this->assertNotEmpty($errors);
    $this->assertContains('Invalid URL format.', $errors);
  }

  /**
   * Tests validateData returns empty for valid URL.
   *
   * @covers ::validateData
   */
  public function testValidateDataValidUrl(): void {
    $errors = $this->processor->validateData(['url' => 'https://example.com/page']);
    $this->assertEmpty($errors);
  }

  /**
   * Tests validateData validates multiple URLs.
   *
   * @covers ::validateData
   */
  public function testValidateDataMultipleUrls(): void {
    $data = [
      'urls' => [
        'https://example.com/page1',
        'https://example.com/page2',
      ],
    ];
    $errors = $this->processor->validateData($data);
    $this->assertEmpty($errors);
  }

  /**
   * Tests validateData returns error for invalid URL in array.
   *
   * @covers ::validateData
   */
  public function testValidateDataInvalidUrlInArray(): void {
    $data = [
      'urls' => [
        'https://example.com/page1',
        'not-valid',
      ],
    ];
    $errors = $this->processor->validateData($data);
    $this->assertNotEmpty($errors);
  }

  /**
   * Tests process creates node from URL with standard extraction.
   *
   * @covers ::process
   */
  public function testProcessStandardExtraction(): void {
    $url = 'https://example.com/test-page';
    $htmlContent = '<html><head><title>Test Page</title></head><body><p>Content</p></body></html>';
    $data = ['url' => $url];
    $configuration = [
      'content_type' => 'article',
      'fields' => ['body' => 'text_long:field_body'],
    ];

    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn(123);

    $this->urlContentFetcher->expects($this->once())
      ->method('fetchContent')
      ->with($url)
      ->willReturn($htmlContent);

    $this->htmlParser->expects($this->once())
      ->method('sanitizeHtml')
      ->willReturn(['title' => 'Test Page', 'content' => '<p>Content</p>']);

    $this->nodeBuilder->expects($this->once())
      ->method('createNode')
      ->with('article', 'Test Page')
      ->willReturn($mockNode);

    $this->nodeBuilder->expects($this->once())
      ->method('setFieldValue')
      ->with($mockNode, 'text_long:field_body', '<p>Content</p>');

    $this->nodeBuilder->method('getTruncationWarnings')
      ->willReturn([]);

    $mockNode->expects($this->once())
      ->method('save');

    $result = $this->processor->process($data, $configuration);
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests process creates node with redirect when configured.
   *
   * @covers ::process
   */
  public function testProcessWithRedirect(): void {
    $url = 'https://example.com/old-page';
    $htmlContent = '<html><body>Content</body></html>';
    $data = ['url' => $url];
    $configuration = [
      'content_type' => 'page',
      'create_redirects' => TRUE,
    ];

    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn(456);

    $this->urlContentFetcher->method('fetchContent')
      ->willReturn($htmlContent);

    $this->htmlParser->method('sanitizeHtml')
      ->willReturn(['title' => 'Old Page', 'content' => 'Content']);

    $this->nodeBuilder->method('createNode')
      ->willReturn($mockNode);

    $this->nodeBuilder->method('getTruncationWarnings')
      ->willReturn([]);

    $this->redirectService->expects($this->once())
      ->method('createRedirect')
      ->with($url, $mockNode);

    $result = $this->processor->process($data, $configuration);
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests process with profile-based extraction.
   *
   * @covers ::process
   */
  public function testProcessWithProfileExtraction(): void {
    $url = 'https://example.com/profile-page';
    $htmlContent = '<html><body><div class="content">Profile content</div></body></html>';
    $data = ['url' => $url];
    $configuration = [
      'content_type' => 'article',
      'extraction_profile' => 'test_profile',
    ];

    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn(789);

    $this->urlContentFetcher->method('fetchContent')
      ->willReturn($htmlContent);

    $this->contentExtraction->expects($this->once())
      ->method('extractFromHtmlWithProfile')
      ->with($htmlContent, 'test_profile')
      ->willReturn([
        'title' => 'Profile Page',
        'extractions' => [
          ['content' => '<p>Extracted</p>', 'target_field' => 'text:field_body', 'paragraph_type' => ''],
        ],
      ]);

    $this->contentExtraction->method('getExtractionProfile')
      ->willReturn(['label' => 'Test Profile']);

    $this->contentExtraction->method('getContentHighlights')
      ->willReturn([]);

    $this->nodeBuilder->method('createNode')
      ->willReturn($mockNode);

    $this->nodeBuilder->method('parseCompositeKey')
      ->willReturn(['type' => 'text', 'name' => 'field_body', 'is_paragraph' => FALSE]);

    $this->nodeBuilder->method('getTruncationWarnings')
      ->willReturn([]);

    $result = $this->processor->process($data, $configuration);
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests process sets URL alias when base_url_path is configured.
   *
   * @covers ::process
   */
  public function testProcessWithBaseUrlPath(): void {
    $url = 'https://example.com/test-page';
    $htmlContent = '<html><body><p>Content</p></body></html>';
    $data = ['url' => $url];
    $configuration = [
      'content_type' => 'article',
      'fields' => ['body' => 'text_long:field_body'],
      'base_url_path' => 'services',
    ];

    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn(123);

    $this->urlContentFetcher->method('fetchContent')
      ->willReturn($htmlContent);

    $this->htmlParser->method('sanitizeHtml')
      ->willReturn(['title' => 'Test Page', 'content' => '<p>Content</p>']);

    $this->nodeBuilder->method('createNode')
      ->willReturn($mockNode);

    $this->nodeBuilder->method('getTruncationWarnings')
      ->willReturn([]);

    $this->urlAliasService->expects($this->once())
      ->method('setUrlAlias')
      ->with($mockNode, 'services');

    $result = $this->processor->process($data, $configuration);
    $this->assertSame($mockNode, $result);
  }

  /**
   * Tests process does not set URL alias when base_url_path is empty.
   *
   * @covers ::process
   */
  public function testProcessWithoutBaseUrlPath(): void {
    $url = 'https://example.com/test-page';
    $htmlContent = '<html><body><p>Content</p></body></html>';
    $data = ['url' => $url];
    $configuration = [
      'content_type' => 'article',
      'fields' => ['body' => 'text_long:field_body'],
    ];

    $mockNode = $this->createMock(NodeInterface::class);
    $mockNode->method('id')->willReturn(123);

    $this->urlContentFetcher->method('fetchContent')
      ->willReturn($htmlContent);

    $this->htmlParser->method('sanitizeHtml')
      ->willReturn(['title' => 'Test Page', 'content' => '<p>Content</p>']);

    $this->nodeBuilder->method('createNode')
      ->willReturn($mockNode);

    $this->nodeBuilder->method('getTruncationWarnings')
      ->willReturn([]);

    $this->urlAliasService->expects($this->never())
      ->method('setUrlAlias');

    $result = $this->processor->process($data, $configuration);
    $this->assertSame($mockNode, $result);
  }

}
