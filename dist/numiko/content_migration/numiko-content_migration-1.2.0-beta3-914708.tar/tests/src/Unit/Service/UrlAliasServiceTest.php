<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\Service\UrlAliasService;
use Drupal\node\NodeInterface;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the UrlAliasService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\UrlAliasService
 * @group content_migration
 */
class UrlAliasServiceTest extends UnitTestCase {

  /**
   * The service under test.
   *
   * @var \Drupal\content_migration\Service\UrlAliasService
   */
  protected UrlAliasService $service;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->logger = $this->createMock(LoggerInterface::class);
    $this->service = new UrlAliasService($this->logger);
  }

  /**
   * Tests slugify converts titles correctly.
   *
   * @covers ::slugify
   * @dataProvider slugifyDataProvider
   */
  public function testSlugify(string $input, string $expected): void {
    $this->assertEquals($expected, $this->service->slugify($input));
  }

  /**
   * Data provider for testSlugify.
   *
   * @return array
   *   Test cases.
   */
  public static function slugifyDataProvider(): array {
    return [
      'simple title' => ['My Page Title', 'my-page-title'],
      'with special characters' => ['Hello & World!', 'hello-world'],
      'with numbers' => ['Page 123 Test', 'page-123-test'],
      'with consecutive spaces' => ['Title   With   Spaces', 'title-with-spaces'],
      'with leading/trailing spaces' => ['  Trimmed Title  ', 'trimmed-title'],
      'with unicode characters' => ['Café & Résumé', 'caf-r-sum'],
      'already a slug' => ['my-page-title', 'my-page-title'],
      'empty string' => ['', ''],
      'only special chars' => ['!@#$%', ''],
      'with hyphens' => ['My - Page - Title', 'my-page-title'],
    ];
  }

  /**
   * Tests normalisePath removes leading and trailing slashes.
   *
   * @covers ::normalisePath
   * @dataProvider normalisePathDataProvider
   */
  public function testNormalisePath(string $input, string $expected): void {
    $this->assertEquals($expected, $this->service->normalisePath($input));
  }

  /**
   * Data provider for testNormalisePath.
   *
   * @return array
   *   Test cases.
   */
  public static function normalisePathDataProvider(): array {
    return [
      'no slashes' => ['services', 'services'],
      'leading slash' => ['/services', 'services'],
      'trailing slash' => ['services/', 'services'],
      'both slashes' => ['/services/', 'services'],
      'nested path' => ['about/team', 'about/team'],
      'nested with slashes' => ['/about/team/', 'about/team'],
      'whitespace' => ['  services  ', 'services'],
      'empty string' => ['', ''],
      'just slashes' => ['///', ''],
    ];
  }

  /**
   * Tests buildAliasPath constructs correct paths.
   *
   * @covers ::buildAliasPath
   */
  public function testBuildAliasPath(): void {
    $this->assertEquals('/services/web-development', $this->service->buildAliasPath('services', 'Web Development'));
    $this->assertEquals('/about/team/john-doe', $this->service->buildAliasPath('about/team', 'John Doe'));
    $this->assertEquals('/services/web-development', $this->service->buildAliasPath('/services/', 'Web Development'));
  }

  /**
   * Tests buildAliasPath returns empty for empty inputs.
   *
   * @covers ::buildAliasPath
   */
  public function testBuildAliasPathEmpty(): void {
    $this->assertEquals('', $this->service->buildAliasPath('', 'Some Title'));
    $this->assertEquals('', $this->service->buildAliasPath('services', ''));
    $this->assertEquals('', $this->service->buildAliasPath('', ''));
  }

  /**
   * Tests setUrlAlias sets the path on a node.
   *
   * @covers ::setUrlAlias
   */
  public function testSetUrlAlias(): void {
    $node = $this->createMock(NodeInterface::class);
    $node->method('getTitle')->willReturn('My Page Title');

    $node->expects($this->once())
      ->method('set')
      ->with('path', [
        'alias' => '/services/my-page-title',
        'pathauto' => FALSE,
      ]);

    $result = $this->service->setUrlAlias($node, 'services');
    $this->assertTrue($result);
  }

  /**
   * Tests setUrlAlias with nested base path.
   *
   * @covers ::setUrlAlias
   */
  public function testSetUrlAliasNestedBasePath(): void {
    $node = $this->createMock(NodeInterface::class);
    $node->method('getTitle')->willReturn('Contact Us');

    $node->expects($this->once())
      ->method('set')
      ->with('path', [
        'alias' => '/about/team/contact-us',
        'pathauto' => FALSE,
      ]);

    $result = $this->service->setUrlAlias($node, '/about/team/');
    $this->assertTrue($result);
  }

  /**
   * Tests setUrlAlias returns false for empty base path.
   *
   * @covers ::setUrlAlias
   */
  public function testSetUrlAliasEmptyBasePath(): void {
    $node = $this->createMock(NodeInterface::class);
    $node->expects($this->never())->method('set');

    $result = $this->service->setUrlAlias($node, '');
    $this->assertFalse($result);
  }

  /**
   * Tests setUrlAlias returns false for empty title slug.
   *
   * @covers ::setUrlAlias
   */
  public function testSetUrlAliasEmptyTitleSlug(): void {
    $node = $this->createMock(NodeInterface::class);
    $node->method('getTitle')->willReturn('!@#$%');
    $node->expects($this->never())->method('set');

    $this->logger->expects($this->once())
      ->method('warning');

    $result = $this->service->setUrlAlias($node, 'services');
    $this->assertFalse($result);
  }

}
