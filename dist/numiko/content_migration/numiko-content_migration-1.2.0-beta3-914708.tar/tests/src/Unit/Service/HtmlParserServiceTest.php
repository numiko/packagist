<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Service\HtmlParserService;
use Drupal\Tests\UnitTestCase;
use Psr\Log\LoggerInterface;

/**
 * Unit tests for the HtmlParserService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\HtmlParserService
 * @group content_migration
 */
class HtmlParserServiceTest extends UnitTestCase {

  /**
   * The HTML parser service under test.
   *
   * @var \Drupal\content_migration\Service\HtmlParserService
   */
  protected HtmlParserService $htmlParser;

  /**
   * Mock logger.
   *
   * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->logger = $this->createMock(LoggerInterface::class);
    $this->htmlParser = new HtmlParserService($this->logger);
  }

  /**
   * Tests cssToXPath conversion with simple selectors.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathSimpleTag(): void {
    $xpath = $this->htmlParser->cssToXPath('div');
    $this->assertEquals('//div', $xpath);
  }

  /**
   * Tests cssToXPath conversion with class selectors.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathClass(): void {
    $xpath = $this->htmlParser->cssToXPath('.content');
    $this->assertEquals("//*[contains(concat(' ', normalize-space(@class), ' '), ' content ')]", $xpath);
  }

  /**
   * Tests cssToXPath conversion with ID selectors.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathId(): void {
    $xpath = $this->htmlParser->cssToXPath('#main');
    $this->assertEquals("//*[@id='main']", $xpath);
  }

  /**
   * Tests cssToXPath conversion with tag and class.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathTagAndClass(): void {
    $xpath = $this->htmlParser->cssToXPath('div.content');
    $this->assertEquals("//div[contains(concat(' ', normalize-space(@class), ' '), ' content ')]", $xpath);
  }

  /**
   * Tests cssToXPath conversion with tag and ID.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathTagAndId(): void {
    $xpath = $this->htmlParser->cssToXPath('div#main');
    $this->assertEquals("//div[@id='main']", $xpath);
  }

  /**
   * Tests cssToXPath conversion with descendant combinator.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathDescendant(): void {
    $xpath = $this->htmlParser->cssToXPath('div p');
    $this->assertEquals('//div//p', $xpath);
  }

  /**
   * Tests cssToXPath conversion with :nth-child pseudo-selector.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathNthChild(): void {
    $xpath = $this->htmlParser->cssToXPath('.field-item:nth-child(1)');
    $this->assertEquals("//*[contains(concat(' ', normalize-space(@class), ' '), ' field-item ')][1]", $xpath);
  }

  /**
   * Tests cssToXPath conversion with :nth-child in descendant selector.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathDescendantWithNthChild(): void {
    $xpath = $this->htmlParser->cssToXPath('.parent .field-item:nth-child(2)');
    $this->assertEquals("//*[contains(concat(' ', normalize-space(@class), ' '), ' parent ')]//*[contains(concat(' ', normalize-space(@class), ' '), ' field-item ')][2]", $xpath);
  }

  /**
   * Tests cssToXPath conversion with :first-child pseudo-selector.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathFirstChild(): void {
    $xpath = $this->htmlParser->cssToXPath('div:first-child');
    $this->assertEquals("//div[1]", $xpath);
  }

  /**
   * Tests cssToXPath conversion with :last-child pseudo-selector.
   *
   * @covers ::cssToXPath
   */
  public function testCssToXPathLastChild(): void {
    $xpath = $this->htmlParser->cssToXPath('.item:last-child');
    $this->assertEquals("//*[contains(concat(' ', normalize-space(@class), ' '), ' item ')][last()]", $xpath);
  }

  /**
   * Tests extractWithProfile correctly extracts content using :nth-child selector.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfileNthChildSelector(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body>
      <div class="field-name-field-academic-profile">
        <div class="field-item">Blavatnik School of Government</div>
        <div class="field-item">Second item</div>
        <div class="field-item">Third item</div>
      </div>
    </body></html>';

    $profile = [
      'label' => 'Academic Profile',
      'mappings' => [
        [
          'selector' => '.field-name-field-academic-profile .field-item:nth-child(1)',
          'target_field' => 'entity_reference_revisions:field_department',
          'paragraph_type' => 'field:department',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertArrayHasKey('extractions', $result);
    $this->assertCount(1, $result['extractions']);
    $this->assertStringContainsString('Blavatnik School of Government', $result['extractions'][0]['content']);
    $this->assertStringNotContainsString('Second item', $result['extractions'][0]['content']);
  }

  /**
   * Tests extractPlainText removes HTML tags.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextRemovesTags(): void {
    $html = '<p>Hello <strong>World</strong></p>';
    $result = $this->htmlParser->extractPlainText($html);
    $this->assertEquals("Hello World", $result);
  }

  /**
   * Tests extractPlainText preserves paragraph breaks.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextPreservesParagraphs(): void {
    $html = '<p>First paragraph.</p><p>Second paragraph.</p>';
    $result = $this->htmlParser->extractPlainText($html);
    $this->assertStringContainsString("First paragraph.", $result);
    $this->assertStringContainsString("Second paragraph.", $result);
  }

  /**
   * Tests extractPlainText handles empty input.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextEmpty(): void {
    $result = $this->htmlParser->extractPlainText('');
    $this->assertEquals('', $result);
  }

  /**
   * Tests extractPlainText handles whitespace-only input.
   *
   * @covers ::extractPlainText
   */
  public function testExtractPlainTextWhitespace(): void {
    $result = $this->htmlParser->extractPlainText('   ');
    $this->assertEquals('', $result);
  }

  /**
   * Tests sanitizeHtml in article mode.
   *
   * @covers ::sanitizeHtml
   */
  public function testSanitizeHtmlArticleMode(): void {
    $html = '<!DOCTYPE html><html><head><title>Test Page</title></head><body><article><h1>Title</h1><p>Content</p></article></body></html>';
    $result = $this->htmlParser->sanitizeHtml($html, ContentMigrationConstants::EXTRACTION_MODE_ARTICLE);

    $this->assertArrayHasKey('title', $result);
    $this->assertArrayHasKey('content', $result);
  }

  /**
   * Tests sanitizeHtml in full page mode.
   *
   * @covers ::sanitizeHtml
   */
  public function testSanitizeHtmlFullPageMode(): void {
    $html = '<!DOCTYPE html><html><head><title>Test Page</title></head><body><div class="content"><h1>Title</h1><p>Content</p></div></body></html>';
    $result = $this->htmlParser->sanitizeHtml($html, ContentMigrationConstants::EXTRACTION_MODE_FULL_PAGE);

    $this->assertArrayHasKey('title', $result);
    $this->assertArrayHasKey('content', $result);
  }

  /**
   * Tests applyHighlights adds styles to matching elements.
   *
   * @covers ::applyHighlights
   */
  public function testApplyHighlights(): void {
    $html = '<div><p class="highlight-me">Content</p></div>';
    $highlights = [
      [
        'selector' => '.highlight-me',
        'color' => 'yellow',
      ],
    ];

    $result = $this->htmlParser->applyHighlights($html, $highlights);
    $this->assertStringContainsString('background-color: yellow', $result);
  }

  /**
   * Tests applyHighlights with empty highlights array.
   *
   * @covers ::applyHighlights
   */
  public function testApplyHighlightsEmpty(): void {
    $html = '<div><p>Content</p></div>';
    $result = $this->htmlParser->applyHighlights($html, []);
    $this->assertEquals($html, $result);
  }

  /**
   * Tests sanitizeForRichText converts DIV to P.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextConvertsDivToP(): void {
    $html = '<div>Hello world</div>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertEquals('<p>Hello world</p>', $result);
  }

  /**
   * Tests sanitizeForRichText converts SPAN to P.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextConvertsSpanToP(): void {
    $html = '<span>Hello world</span>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertEquals('<p>Hello world</p>', $result);
  }

  /**
   * Tests sanitizeForRichText retains heading tags.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextRetainsHeadings(): void {
    $html = '<h1>Title</h1><h2>Subtitle</h2><h3>Section</h3><p>Content</p>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringContainsString('<h1>Title</h1>', $result);
    $this->assertStringContainsString('<h2>Subtitle</h2>', $result);
    $this->assertStringContainsString('<h3>Section</h3>', $result);
    $this->assertStringContainsString('<p>Content</p>', $result);
  }

  /**
   * Tests sanitizeForRichText strips all attributes except href on links.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextStripsAttributes(): void {
    $html = '<h2 class="title" id="main">Title</h2><p style="color: red;" data-custom="val">Content</p>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertEquals('<h2>Title</h2><p>Content</p>', $result);
  }

  /**
   * Tests sanitizeForRichText retains href on anchor tags.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextRetainsHref(): void {
    $html = '<p><a href="https://example.com" class="link" target="_blank" rel="noopener">Link text</a></p>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringContainsString('href="https://example.com"', $result);
    $this->assertStringNotContainsString('class=', $result);
    $this->assertStringNotContainsString('target=', $result);
    $this->assertStringNotContainsString('rel=', $result);
    $this->assertStringContainsString('Link text', $result);
  }

  /**
   * Tests sanitizeForRichText strips attributes from converted elements.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextStripsAttributesFromConvertedElements(): void {
    $html = '<div class="intro" style="margin: 10px;">Hello</div>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertEquals('<p>Hello</p>', $result);
  }

  /**
   * Tests sanitizeForRichText handles nested DIVs.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextHandlesNestedDivs(): void {
    $html = '<div class="outer"><div class="inner">Nested content</div></div>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringContainsString('Nested content', $result);
    $this->assertStringNotContainsString('<div', $result);
    $this->assertStringNotContainsString('class=', $result);
  }

  /**
   * Tests sanitizeForRichText removes empty paragraphs.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextRemovesEmptyParagraphs(): void {
    $html = '<p>Content</p><p>  </p><p>More content</p>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringContainsString('<p>Content</p>', $result);
    $this->assertStringContainsString('<p>More content</p>', $result);
    // The empty paragraph should be removed.
    $this->assertStringNotContainsString('<p>  </p>', $result);
  }

  /**
   * Tests sanitizeForRichText removes all empty tags, not just paragraphs.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextRemovesAllEmptyTags(): void {
    $html = '<h2></h2><p>Content</p><ul></ul><div></div><strong></strong><p>End</p>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringContainsString('<p>Content</p>', $result);
    $this->assertStringContainsString('<p>End</p>', $result);
    $this->assertStringNotContainsString('<h2></h2>', $result);
    $this->assertStringNotContainsString('<ul></ul>', $result);
    $this->assertStringNotContainsString('<strong></strong>', $result);
  }

  /**
   * Tests sanitizeForRichText removes nested empty tags.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextRemovesNestedEmptyTags(): void {
    // After DIV→P conversion, the outer wrapper becomes empty once the
    // inner empty element is removed.
    $html = '<div><div>  </div></div><p>Keep me</p>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringContainsString('<p>Keep me</p>', $result);
    $this->assertStringNotContainsString('<p><p>', $result);
  }

  /**
   * Tests sanitizeForRichText removes elements containing only &nbsp;.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextRemovesNbspOnlyElements(): void {
    // \xC2\xA0 is the UTF-8 encoding of &nbsp; (U+00A0).
    $html = '<p>' . "\xC2\xA0" . '</p><p>Real content</p><p> ' . "\xC2\xA0" . ' </p>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringContainsString('<p>Real content</p>', $result);
    $this->assertEquals('<p>Real content</p>', $result);
  }

  /**
   * Tests sanitizeForRichText flattens nested P tags from DIV conversion.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextFlattensNestedParagraphs(): void {
    // This simulates the real-world case: nested DIVs all become Ps.
    $html = '<div><div>First</div><div>Second</div></div>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    // Should produce flat P elements, not <p><p>First</p><p>Second</p></p>.
    $this->assertStringNotContainsString('<p><p>', $result);
    $this->assertStringContainsString('<p>First</p>', $result);
    $this->assertStringContainsString('<p>Second</p>', $result);
  }

  /**
   * Tests sanitizeForRichText handles empty input.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextEmptyInput(): void {
    $this->assertEquals('', $this->htmlParser->sanitizeForRichText(''));
    $this->assertEquals('', $this->htmlParser->sanitizeForRichText('   '));
  }

  /**
   * Tests sanitizeForRichText retains lists.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextRetainsLists(): void {
    $html = '<ul class="styled"><li class="item">Item 1</li><li>Item 2</li></ul>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringContainsString('<ul>', $result);
    $this->assertStringContainsString('<li>Item 1</li>', $result);
    $this->assertStringContainsString('<li>Item 2</li>', $result);
    $this->assertStringNotContainsString('class=', $result);
  }

  /**
   * Tests sanitizeForRichText retains inline formatting.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextRetainsInlineFormatting(): void {
    $html = '<p><strong class="bold">Bold</strong> and <em style="color:red">italic</em></p>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringContainsString('<strong>Bold</strong>', $result);
    $this->assertStringContainsString('<em>italic</em>', $result);
    $this->assertStringNotContainsString('class=', $result);
    $this->assertStringNotContainsString('style=', $result);
  }

  /**
   * Tests sanitizeForRichText strips disallowed tags.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextStripsDisallowedTags(): void {
    $html = '<p>Content</p><script>alert("xss")</script><style>.x{}</style><img src="x.jpg"><p>More</p>';
    $result = $this->htmlParser->sanitizeForRichText($html);
    $this->assertStringNotContainsString('<script', $result);
    $this->assertStringNotContainsString('<style', $result);
    $this->assertStringNotContainsString('<img', $result);
    $this->assertStringContainsString('<p>Content</p>', $result);
    $this->assertStringContainsString('<p>More</p>', $result);
  }

  /**
   * Tests isRichTextField identifies rich text field types.
   *
   * @covers ::isRichTextField
   */
  public function testIsRichTextField(): void {
    $this->assertTrue($this->htmlParser->isRichTextField('text_with_summary:field_body'));
    $this->assertTrue($this->htmlParser->isRichTextField('text_long:field_description'));
    $this->assertTrue($this->htmlParser->isRichTextField('text:field_intro'));
    $this->assertFalse($this->htmlParser->isRichTextField('entity_reference_revisions:field_content'));
    $this->assertFalse($this->htmlParser->isRichTextField('string:field_title'));
    $this->assertFalse($this->htmlParser->isRichTextField(''));
    $this->assertFalse($this->htmlParser->isRichTextField('no_colon'));
  }

  /**
   * Tests extractWithProfile applies rich text sanitization for text fields.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfileSanitizesForRichTextField(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body>
      <div class="content"><div class="intro" style="color:red"><a href="https://example.com" class="link">Hello world</a></div><h2 class="subtitle">Heading</h2></div>
    </body></html>';

    $profile = [
      'label' => 'Rich Text Profile',
      'mappings' => [
        [
          'selector' => '.content',
          'target_field' => 'text_with_summary:field_body',
          'paragraph_type' => '',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertNotEmpty($result['extractions']);
    $content = $result['extractions'][0]['content'];
    // DIV and SPAN should be converted to P.
    $this->assertStringNotContainsString('<div', $content);
    $this->assertStringNotContainsString('<span', $content);
    // Headings should be retained.
    $this->assertStringContainsString('<h2>Heading</h2>', $content);
    // Non-href attributes should be stripped.
    $this->assertStringNotContainsString('class=', $content);
    $this->assertStringNotContainsString('style=', $content);
    // href should be retained.
    $this->assertStringContainsString('href="https://example.com"', $content);
    // Content should be preserved.
    $this->assertStringContainsString('Hello world', $content);
  }

  /**
   * Tests extractWithProfile also sanitizes for paragraph (slice) fields.
   *
   * Paragraph content fields are themselves rich text, so content destined
   * for entity_reference_revisions fields should also be sanitized.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfileSanitizesForParagraphField(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body>
      <div class="content"><div class="intro" style="color:red">Hello</div></div>
    </body></html>';

    $profile = [
      'label' => 'Paragraph Profile',
      'mappings' => [
        [
          'selector' => '.content',
          'target_field' => 'entity_reference_revisions:field_content',
          'paragraph_type' => 'slice_content',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertNotEmpty($result['extractions']);
    $content = $result['extractions'][0]['content'];
    // DIVs should be converted to P, attributes stripped.
    $this->assertStringNotContainsString('<div', $content);
    $this->assertStringNotContainsString('style=', $content);
    $this->assertStringContainsString('Hello', $content);
  }

  /**
   * Tests extractWithProfile does NOT sanitize for plain string fields.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfileDoesNotSanitizeForStringField(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body>
      <div class="content"><div class="intro" style="color:red">Hello</div></div>
    </body></html>';

    $profile = [
      'label' => 'String Profile',
      'mappings' => [
        [
          'selector' => '.content',
          'target_field' => 'string:field_subtitle',
          'paragraph_type' => '',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertNotEmpty($result['extractions']);
    $content = $result['extractions'][0]['content'];
    // String fields should NOT be sanitized — left as raw HTML.
    $this->assertStringContainsString('<div', $content);
    $this->assertStringContainsString('style=', $content);
  }

  /**
   * Tests sanitizeForRichText with real-world academic profile content.
   *
   * @covers ::sanitizeForRichText
   */
  public function testSanitizeForRichTextAcademicProfileContent(): void {
    $html = '<div><div>Academic profile</div><div><div><a href="http://www.bsg.ox.ac.uk/people/thomas-hale">Blavatnik School of Government</a></div><div><a href="https://scholar.google.co.uk/citations?user=bTqyBOwAAAAJ&amp;hl=en">Google Scholar</a></div></div></div>';
    $result = $this->htmlParser->sanitizeForRichText($html);

    // All DIVs should be converted to P.
    $this->assertStringNotContainsString('<div', $result);
    // Non-href attributes should be stripped.
    $this->assertStringNotContainsString('class=', $result);
    // href should be retained on links.
    $this->assertStringContainsString('href="http://www.bsg.ox.ac.uk/people/thomas-hale"', $result);
    $this->assertStringContainsString('href="https://scholar.google.co.uk/', $result);
    // Text content should be preserved.
    $this->assertStringContainsString('Academic profile', $result);
    $this->assertStringContainsString('Blavatnik School of Government', $result);
    $this->assertStringContainsString('Google Scholar', $result);
  }

  /**
   * Tests shouldSanitizeForRichText identifies all applicable field types.
   *
   * @covers ::shouldSanitizeForRichText
   */
  public function testShouldSanitizeForRichText(): void {
    // Direct rich text fields.
    $this->assertTrue($this->htmlParser->shouldSanitizeForRichText('text_with_summary:field_body'));
    $this->assertTrue($this->htmlParser->shouldSanitizeForRichText('text_long:field_description'));
    $this->assertTrue($this->htmlParser->shouldSanitizeForRichText('text:field_intro'));
    // Paragraph reference fields (inner content field is rich text).
    $this->assertTrue($this->htmlParser->shouldSanitizeForRichText('entity_reference_revisions:field_content'));
    // Non-rich-text fields should NOT be sanitized.
    $this->assertFalse($this->htmlParser->shouldSanitizeForRichText('string:field_title'));
    $this->assertFalse($this->htmlParser->shouldSanitizeForRichText('email:field_email'));
    $this->assertFalse($this->htmlParser->shouldSanitizeForRichText(''));
    $this->assertFalse($this->htmlParser->shouldSanitizeForRichText('no_colon'));
  }

  /**
   * Tests extractWithProfile with basic profile.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfile(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body><div class="content"><p>Content here</p></div></body></html>';
    $profile = [
      'label' => 'Test Profile',
      'mappings' => [
        [
          'selector' => '.content',
          'target_field' => 'entity_reference_revisions:field_content',
          'paragraph_type' => 'slice_content',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertArrayHasKey('title', $result);
    $this->assertArrayHasKey('extractions', $result);
    $this->assertEquals('Test', $result['title']);
    // Each extraction now has its own target_field.
    $this->assertNotEmpty($result['extractions']);
    $this->assertArrayHasKey('target_field', $result['extractions'][0]);
    $this->assertEquals('entity_reference_revisions:field_content', $result['extractions'][0]['target_field']);
    $this->assertEquals('slice_content', $result['extractions'][0]['paragraph_type']);
  }

  /**
   * Tests extractWithProfile extracts href attribute from a link element.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfileAttributeHref(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body>
      <a href="https://example.com/page" class="main-link">Visit us</a>
    </body></html>';

    $profile = [
      'label' => 'Attribute Profile',
      'mappings' => [
        [
          'selector' => 'a.main-link',
          'target_field' => 'link:field_link',
          'paragraph_type' => '',
          'attribute' => 'href',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertNotEmpty($result['extractions']);
    $this->assertEquals('https://example.com/page', $result['extractions'][0]['content']);
  }

  /**
   * Tests extractWithProfile extracts attribute using a descendant selector.
   *
   * This covers the real-world Twitter URL extraction use case:
   * .field-name-field-twitter a → extract href.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfileAttributeDescendantSelector(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body>
      <div class="field field-name-field-twitter field-type-link-field field-label-hidden">
        <span class="field-item-single"><a href="http://twitter.com/thomasnhale" target="_blank">@thomasnhale</a></span>
      </div>
    </body></html>';

    $profile = [
      'label' => 'Twitter Profile',
      'mappings' => [
        [
          'selector' => '.field-name-field-twitter a',
          'target_field' => 'string:field_twitter',
          'paragraph_type' => '',
          'attribute' => 'href',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertNotEmpty($result['extractions']);
    $this->assertEquals('http://twitter.com/thomasnhale', $result['extractions'][0]['content']);
  }

  /**
   * Tests attribute extraction returns a plain string, not HTML.
   *
   * When an attribute is specified, the result should be just the attribute
   * value with no HTML tags, and rich text sanitization should be skipped.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfileAttributeReturnsPlainString(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body>
      <img src="https://example.com/image.jpg" alt="A photo" class="hero-image">
    </body></html>';

    $profile = [
      'label' => 'Image Profile',
      'mappings' => [
        [
          'selector' => 'img.hero-image',
          'target_field' => 'string:field_image_url',
          'paragraph_type' => '',
          'attribute' => 'src',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertNotEmpty($result['extractions']);
    $content = $result['extractions'][0]['content'];
    $this->assertEquals('https://example.com/image.jpg', $content);
    // Should be a plain string with no HTML tags.
    $this->assertEquals($content, strip_tags($content));
  }

  /**
   * Tests attribute extraction returns empty string for missing attribute.
   *
   * @covers ::extractWithProfile
   */
  public function testExtractWithProfileAttributeMissingReturnsEmpty(): void {
    $html = '<!DOCTYPE html><html><head><title>Test</title></head><body>
      <div class="content">Some text</div>
    </body></html>';

    $profile = [
      'label' => 'Missing Attr Profile',
      'mappings' => [
        [
          'selector' => '.content',
          'target_field' => 'string:field_data',
          'paragraph_type' => '',
          'attribute' => 'data-url',
        ],
      ],
    ];

    $result = $this->htmlParser->extractWithProfile($html, $profile);

    $this->assertNotEmpty($result['extractions']);
    $this->assertEquals('', $result['extractions'][0]['content']);
  }

}
