<?php

declare(strict_types=1);

namespace Drupal\Tests\content_migration\Unit\Service;

use Drupal\content_migration\Service\TaxonomyPromptService;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\taxonomy\TermInterface;
use Drupal\taxonomy\VocabularyInterface;
use Drupal\Tests\UnitTestCase;

/**
 * Unit tests for the TaxonomyPromptService.
 *
 * @coversDefaultClass \Drupal\content_migration\Service\TaxonomyPromptService
 * @group content_migration
 */
class TaxonomyPromptServiceTest extends UnitTestCase {

  /**
   * The service under test.
   *
   * @var \Drupal\content_migration\Service\TaxonomyPromptService
   */
  protected TaxonomyPromptService $service;

  /**
   * Mock entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();

    $this->entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $this->service = new TaxonomyPromptService($this->entityTypeManager);
  }

  /**
   * Tests getVocabularyOptions returns vocabulary list.
   *
   * @covers ::getVocabularyOptions
   */
  public function testGetVocabularyOptions(): void {
    $mockVocab1 = $this->createMock(VocabularyInterface::class);
    $mockVocab1->method('id')->willReturn('tags');
    $mockVocab1->method('label')->willReturn('Tags');

    $mockVocab2 = $this->createMock(VocabularyInterface::class);
    $mockVocab2->method('id')->willReturn('audience');
    $mockVocab2->method('label')->willReturn('Audience');

    $mockStorage = $this->createMock(EntityStorageInterface::class);
    $mockStorage->method('loadMultiple')
      ->willReturn(['tags' => $mockVocab1, 'audience' => $mockVocab2]);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_vocabulary')
      ->willReturn($mockStorage);

    $options = $this->service->getVocabularyOptions();

    $this->assertArrayHasKey('', $options);
    $this->assertEquals('- None -', $options['']);
    $this->assertArrayHasKey('tags', $options);
    $this->assertEquals('Tags', $options['tags']);
    $this->assertArrayHasKey('audience', $options);
    $this->assertEquals('Audience', $options['audience']);
  }

  /**
   * Tests getTermsWithPrompts returns empty array for empty vocabulary ID.
   *
   * @covers ::getTermsWithPrompts
   */
  public function testGetTermsWithPromptsEmptyVocabulary(): void {
    $result = $this->service->getTermsWithPrompts('');
    $this->assertEmpty($result);
  }

  /**
   * Tests getTermPrompt returns null for non-existent term.
   *
   * @covers ::getTermPrompt
   */
  public function testGetTermPromptNonExistent(): void {
    $mockStorage = $this->createMock(EntityStorageInterface::class);
    $mockStorage->method('load')
      ->with(999)
      ->willReturn(NULL);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->getTermPrompt(999);
    $this->assertNull($result);
  }

  /**
   * Tests getTermPrompt returns description for existing term.
   *
   * @covers ::getTermPrompt
   */
  public function testGetTermPromptReturnsDescription(): void {
    $mockTerm = $this->createMock(TermInterface::class);
    $mockTerm->method('getDescription')
      ->willReturn('This is the prompt for the term.');

    $mockStorage = $this->createMock(EntityStorageInterface::class);
    $mockStorage->method('load')
      ->with(42)
      ->willReturn($mockTerm);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->getTermPrompt(42);
    $this->assertEquals('This is the prompt for the term.', $result);
  }

  /**
   * Tests getHierarchicalPrompt returns empty for non-existent term.
   *
   * @covers ::getHierarchicalPrompt
   */
  public function testGetHierarchicalPromptNonExistent(): void {
    $mockStorage = $this->createMock(EntityStorageInterface::class);
    $mockStorage->method('load')
      ->with(999)
      ->willReturn(NULL);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->getHierarchicalPrompt(999);
    $this->assertEquals('', $result['style_guide']);
    $this->assertEquals('', $result['audience_prompt']);
  }

  /**
   * Tests vocabularyHasTermsWithPrompts returns false for empty vocabulary.
   *
   * @covers ::vocabularyHasTermsWithPrompts
   */
  public function testVocabularyHasTermsWithPromptsEmpty(): void {
    // Create a mock with the loadTree method since TermStorageInterface has it.
    $mockStorage = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['loadTree'])
      ->getMock();
    $mockStorage->method('loadTree')
      ->willReturn([]);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->vocabularyHasTermsWithPrompts('empty_vocab');
    $this->assertFalse($result);
  }

  /**
   * Tests getTermOptions returns only child terms with prompts.
   *
   * @covers ::getTermOptions
   */
  public function testGetTermOptions(): void {
    // Create mock terms.
    $rootTerm = $this->createMock(TermInterface::class);
    $rootTerm->method('id')->willReturn(1);
    $rootTerm->method('getName')->willReturn('Root Term');
    $rootTerm->method('getDescription')->willReturn('Root prompt');
    $rootTerm->depth = 0;
    $rootTerm->parents = [0];
    $rootTerm->method('hasField')->willReturn(FALSE);

    $childTerm1 = $this->createMock(TermInterface::class);
    $childTerm1->method('id')->willReturn(2);
    $childTerm1->method('getName')->willReturn('Child Term 1');
    $childTerm1->method('getDescription')->willReturn('Child prompt 1');
    $childTerm1->depth = 1;
    $childTerm1->parents = [1];
    $childTerm1->method('hasField')->willReturn(FALSE);

    $childTerm2 = $this->createMock(TermInterface::class);
    $childTerm2->method('id')->willReturn(3);
    $childTerm2->method('getName')->willReturn('Child Term 2');
    $childTerm2->method('getDescription')->willReturn('Child prompt 2');
    $childTerm2->depth = 1;
    $childTerm2->parents = [1];
    $childTerm2->method('hasField')->willReturn(FALSE);

    $mockStorage = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['loadTree'])
      ->getMock();
    $mockStorage->method('loadTree')
      ->with('audience', 0, NULL, TRUE)
      ->willReturn([$rootTerm, $childTerm1, $childTerm2]);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $options = $this->service->getTermOptions('audience');

    // Should have default option plus 2 child terms (not root).
    $this->assertCount(3, $options);
    $this->assertArrayHasKey('', $options);
    $this->assertEquals('- Select audience -', $options['']);
    $this->assertArrayHasKey(2, $options);
    $this->assertEquals('Child Term 1', $options[2]);
    $this->assertArrayHasKey(3, $options);
    $this->assertEquals('Child Term 2', $options[3]);
    // Root term should not be in options.
    $this->assertArrayNotHasKey(1, $options);
  }

  /**
   * Tests getTermOptions returns only default option for empty vocabulary.
   *
   * @covers ::getTermOptions
   */
  public function testGetTermOptionsEmpty(): void {
    $mockStorage = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['loadTree'])
      ->getMock();
    $mockStorage->method('loadTree')
      ->willReturn([]);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $options = $this->service->getTermOptions('empty_vocab');

    $this->assertCount(1, $options);
    $this->assertArrayHasKey('', $options);
    $this->assertEquals('- Select audience -', $options['']);
  }

  /**
   * Tests getRootTerm returns root term data.
   *
   * @covers ::getRootTerm
   */
  public function testGetRootTerm(): void {
    $rootTerm = $this->createMock(TermInterface::class);
    $rootTerm->method('id')->willReturn(1);
    $rootTerm->method('getName')->willReturn('Style Guide');
    $rootTerm->method('getDescription')->willReturn('This is the default style guide.');
    $rootTerm->depth = 0;
    $rootTerm->parents = [0];
    $rootTerm->method('hasField')->willReturn(FALSE);

    $childTerm = $this->createMock(TermInterface::class);
    $childTerm->method('id')->willReturn(2);
    $childTerm->method('getName')->willReturn('Academic');
    $childTerm->method('getDescription')->willReturn('Academic audience prompt');
    $childTerm->depth = 1;
    $childTerm->parents = [1];
    $childTerm->method('hasField')->willReturn(FALSE);

    $mockStorage = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['loadTree'])
      ->getMock();
    $mockStorage->method('loadTree')
      ->with('audience', 0, NULL, TRUE)
      ->willReturn([$rootTerm, $childTerm]);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->getRootTerm('audience');

    $this->assertNotNull($result);
    $this->assertEquals('Style Guide', $result['name']);
    $this->assertEquals('This is the default style guide.', $result['prompt']);
    $this->assertEquals(0, $result['depth']);
  }

  /**
   * Tests getRootTerm returns null when no root term exists.
   *
   * @covers ::getRootTerm
   */
  public function testGetRootTermNotFound(): void {
    // Only child terms, no root.
    $childTerm = $this->createMock(TermInterface::class);
    $childTerm->method('id')->willReturn(2);
    $childTerm->method('getName')->willReturn('Child Only');
    $childTerm->method('getDescription')->willReturn('Child prompt');
    $childTerm->depth = 1;
    $childTerm->parents = [1];
    $childTerm->method('hasField')->willReturn(FALSE);

    $mockStorage = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['loadTree'])
      ->getMock();
    $mockStorage->method('loadTree')
      ->willReturn([$childTerm]);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->getRootTerm('audience');

    $this->assertNull($result);
  }

  /**
   * Tests getRootTerm returns null for empty vocabulary.
   *
   * @covers ::getRootTerm
   */
  public function testGetRootTermEmptyVocabulary(): void {
    $mockStorage = $this->getMockBuilder(\stdClass::class)
      ->addMethods(['loadTree'])
      ->getMock();
    $mockStorage->method('loadTree')
      ->willReturn([]);

    $this->entityTypeManager->method('getStorage')
      ->with('taxonomy_term')
      ->willReturn($mockStorage);

    $result = $this->service->getRootTerm('empty_vocab');

    $this->assertNull($result);
  }

}
