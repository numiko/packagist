<?php

declare(strict_types=1);

namespace Drupal\content_migration\Service;

use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\node\NodeInterface;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for creating URL aliases on imported nodes.
 *
 * When a base URL path is specified during import, this service generates
 * a URL alias combining the base path with a slugified version of the
 * node title.
 */
class UrlAliasService {

  use StringTranslationTrait;

  /**
   * Constructs a UrlAliasService object.
   *
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * Sets a URL alias on a node based on a base path and the node title.
   *
   * The alias is constructed as: /{base_path}/{slugified-title}
   * This must be called BEFORE the node is saved.
   *
   * @param \Drupal\node\NodeInterface $node
   *   The node to set the alias on.
   * @param string $basePath
   *   The base URL path (e.g., "services" or "about/team").
   *   Leading/trailing slashes are normalised automatically.
   *
   * @return bool
   *   TRUE if the alias was set, FALSE if the base path was empty.
   */
  public function setUrlAlias(NodeInterface $node, string $basePath): bool {
    $basePath = $this->normalisePath($basePath);

    if (empty($basePath)) {
      return FALSE;
    }

    $slug = $this->slugify($node->getTitle());

    if (empty($slug)) {
      $this->logger->warning('Cannot create URL alias: node title produces empty slug for node "@title".', [
        '@title' => $node->getTitle(),
      ]);
      return FALSE;
    }

    $alias = '/' . $basePath . '/' . $slug;

    $node->set('path', [
      'alias' => $alias,
      'pathauto' => FALSE,
    ]);

    $this->logger->info('URL alias "@alias" set for node "@title".', [
      '@alias' => $alias,
      '@title' => $node->getTitle(),
    ]);

    return TRUE;
  }

  /**
   * Normalises a path by trimming whitespace and slashes.
   *
   * @param string $path
   *   The raw path input.
   *
   * @return string
   *   The normalised path without leading/trailing slashes.
   */
  public function normalisePath(string $path): string {
    return trim(trim($path), '/');
  }

  /**
   * Converts a title string into a URL-safe slug.
   *
   * @param string $title
   *   The title to slugify.
   *
   * @return string
   *   The URL-safe slug.
   */
  public function slugify(string $title): string {
    // Convert to lowercase.
    $slug = mb_strtolower($title);

    // Replace non-alphanumeric characters (except hyphens) with hyphens.
    $slug = preg_replace('/[^a-z0-9\-]+/', '-', $slug);

    // Remove consecutive hyphens.
    $slug = preg_replace('/-+/', '-', $slug);

    // Trim hyphens from start and end.
    return trim($slug, '-');
  }

  /**
   * Builds a full alias path from a base path and a slug.
   *
   * Useful for previewing what the alias will be without setting it.
   *
   * @param string $basePath
   *   The base URL path.
   * @param string $title
   *   The node title.
   *
   * @return string
   *   The full alias path, or empty string if inputs are insufficient.
   */
  public function buildAliasPath(string $basePath, string $title): string {
    $basePath = $this->normalisePath($basePath);
    $slug = $this->slugify($title);

    if (empty($basePath) || empty($slug)) {
      return '';
    }

    return '/' . $basePath . '/' . $slug;
  }

}
