<?php

declare(strict_types=1);

namespace Drupal\content_migration\Service;

use Drupal\content_migration\ContentMigrationConstants;
use Drupal\content_migration\Exception\ContentParseException;
use fivefilters\Readability\Configuration;
use fivefilters\Readability\ParseException;
use fivefilters\Readability\Readability;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for parsing and transforming HTML content.
 *
 * This service handles DOM manipulation, CSS-to-XPath conversion,
 * content extraction, and HTML sanitization. It is separated from
 * UrlContentFetcherService which handles HTTP operations.
 */
class HtmlParserService {

  /**
   * Constructs a HtmlParserService object.
   *
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger.
   */
  public function __construct(
    #[Autowire(service: 'logger.channel.content_migration')]
    protected readonly LoggerInterface $logger,
  ) {}

  /**
   * Sanitizes and extracts the main content from HTML.
   *
   * @param string $html
   *   The raw HTML content.
   * @param string $mode
   *   The extraction mode: 'article' (default) or 'full_page'.
   *   - 'article': Uses Readability to extract main article content.
   *   - 'full_page': Extracts all body content, removing only scripts/styles.
   * @param string|null $selector
   *   Optional CSS selector to extract specific content (only used in full_page mode).
   * @param array|null $tags_to_remove
   *   Optional array of selectors to remove during extraction (only used in full_page mode).
   *
   * @return array
   *   The sanitized HTML content with unnecessary parts removed & the title.
   *
   * @throws \Drupal\content_migration\Exception\ContentParseException
   *   If parsing fails.
   */
  public function sanitizeHtml(string $html, string $mode = ContentMigrationConstants::EXTRACTION_MODE_ARTICLE, ?string $selector = NULL, ?array $tags_to_remove = NULL): array {
    if ($mode === ContentMigrationConstants::EXTRACTION_MODE_FULL_PAGE) {
      return $this->extractFullPage($html, $selector, $tags_to_remove);
    }

    // Default: Use Readability for article extraction.
    $readability = new Readability(new Configuration([
      'StripUnlikelyCandidates' => FALSE,
      'KeepClasses' => TRUE,
    ]));

    try {
      $readability->parse($html);
    }
    catch (ParseException $e) {
      throw ContentParseException::invalidHtml($e->getMessage());
    }

    $title = $readability->getTitle();
    // If title contains '|', only use the part before it.
    if (strpos($title, '|') !== FALSE) {
      $title = trim(substr($title, 0, strpos($title, '|')));
    }

    return [
      'title' => $title,
      'content' => $readability->getContent(),
    ];
  }

  /**
   * Extracts full page content, removing specified elements.
   *
   * @param string $html
   *   The raw HTML content.
   * @param string|null $selector
   *   Optional CSS selector to extract specific content.
   * @param array|null $tags_to_remove
   *   Optional array of selectors to remove.
   *
   * @return array
   *   The full page content with specified elements removed & the title.
   */
  protected function extractFullPage(string $html, ?string $selector = NULL, ?array $tags_to_remove = NULL): array {
    $dom = new \DOMDocument();
    // Suppress warnings for malformed HTML.
    @$dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

    // Extract title.
    $titleElements = $dom->getElementsByTagName('title');
    $title = $titleElements->length > 0 ? $titleElements->item(0)->textContent : '';

    // If title contains '|', only use the part before it.
    if (strpos($title, '|') !== FALSE) {
      $title = trim(substr($title, 0, strpos($title, '|')));
    }

    // If selector is provided, extract content from matching elements first.
    $scopedDom = $dom;
    if (!empty($selector)) {
      $scopedDom = $this->extractAndCreateScopedDom($dom, $selector);
    }

    // Use provided tags or default list.
    $tagsToRemove = $tags_to_remove ?? [
      'header',
      'footer',
      'aside',
      'nav',
      'script',
      'style',
      'noscript',
      'iframe',
    ];

    // Remove unwanted elements from the scoped DOM.
    foreach ($tagsToRemove as $removeSelector) {
      $this->removeElementsBySelector($scopedDom, $removeSelector);
    }

    // Get the final content.
    $body = $scopedDom->getElementsByTagName('body')->item(0);
    if ($body) {
      $content = '';
      foreach ($body->childNodes as $node) {
        $content .= $scopedDom->saveHTML($node);
      }
    }
    else {
      $content = $scopedDom->saveHTML();
    }

    return [
      'title' => $title,
      'content' => $this->removeXmlDeclaration($content),
    ];
  }

  /**
   * Remove elements by selector from DOM.
   *
   * @param \DOMDocument $dom
   *   The DOM document.
   * @param string $selector
   *   The selector (tag name, .class, or #id).
   */
  protected function removeElementsBySelector(\DOMDocument $dom, string $selector): void {
    $elementsArray = [];

    if (strpos($selector, '.') === 0) {
      // Class selector.
      $className = substr($selector, 1);
      $xpath = new \DOMXPath($dom);
      $elements = $xpath->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' $className ')]");
      foreach ($elements as $element) {
        $elementsArray[] = $element;
      }
    }
    elseif (strpos($selector, '#') === 0) {
      // ID selector.
      $idName = substr($selector, 1);
      $xpath = new \DOMXPath($dom);
      $elements = $xpath->query("//*[contains(concat(' ', normalize-space(@id), ' '), ' $idName ')]");
      foreach ($elements as $element) {
        $elementsArray[] = $element;
      }
    }
    else {
      // Tag name.
      $elements = $dom->getElementsByTagName($selector);
      foreach ($elements as $element) {
        $elementsArray[] = $element;
      }
    }

    foreach ($elementsArray as $element) {
      if ($element->parentNode) {
        $element->parentNode->removeChild($element);
      }
    }
  }

  /**
   * Extract content by selector and create a new scoped DOM document.
   *
   * @param \DOMDocument $dom
   *   The source DOM document.
   * @param string $selector
   *   The CSS selector.
   *
   * @return \DOMDocument
   *   A new DOM document containing only the selected content.
   */
  protected function extractAndCreateScopedDom(\DOMDocument $dom, string $selector): \DOMDocument {
    $content = $this->extractBySelector($dom, $selector);

    $scopedDom = new \DOMDocument();
    @$scopedDom->loadHTML('<?xml encoding="UTF-8">' . $content, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

    return $scopedDom;
  }

  /**
   * Extract content from DOM using a CSS selector.
   *
   * @param \DOMDocument $dom
   *   The DOM document.
   * @param string $selector
   *   The CSS selector.
   *
   * @return string
   *   The extracted content.
   */
  protected function extractBySelector(\DOMDocument $dom, string $selector): string {
    $content = '';
    $selector = trim($selector);

    if (strpos($selector, '.') === 0) {
      // Class selector.
      $className = substr($selector, 1);
      $xpath = new \DOMXPath($dom);
      $elements = $xpath->query("//*[contains(concat(' ', normalize-space(@class), ' '), ' $className ')]");
      if ($elements->length > 0) {
        foreach ($elements as $element) {
          $content .= $dom->saveHTML($element);
        }
      }
    }
    elseif (strpos($selector, '#') === 0) {
      // ID selector.
      $idName = substr($selector, 1);
      $element = $dom->getElementById($idName);
      if ($element) {
        $content = $dom->saveHTML($element);
      }
    }
    else {
      // Tag name.
      $elements = $dom->getElementsByTagName($selector);
      if ($elements->length > 0) {
        foreach ($elements as $element) {
          $content .= $dom->saveHTML($element);
        }
      }
    }

    // Fallback to body content if no match.
    if (empty($content)) {
      $this->logger->warning('Selector "@selector" did not match any elements. Falling back to full body content.', ['@selector' => $selector]);
      $body = $dom->getElementsByTagName('body')->item(0);
      if ($body) {
        foreach ($body->childNodes as $node) {
          $content .= $dom->saveHTML($node);
        }
      }
    }

    return $content;
  }

  /**
   * Remove XML encoding declaration from HTML content.
   *
   * @param string $content
   *   The HTML content.
   *
   * @return string
   *   The content with XML declaration removed.
   */
  public function removeXmlDeclaration(string $content): string {
    return preg_replace('/<\?xml.+?>/i', '', $content);
  }

  /**
   * Extract content using an extraction profile.
   *
   * @param string $html
   *   The raw HTML content.
   * @param array $profile
   *   The extraction profile containing:
   *   - 'label': The profile label.
   *   - 'target_field': The paragraph reference field to use.
   *   - 'mappings': Array of selector-to-paragraph type mappings.
   *
   * @return array
   *   An array containing:
   *   - 'title': The extracted page title.
   *   - 'extractions': Array of extracted items.
   *   - 'target_field': The target paragraph field from the profile.
   */
  public function extractWithProfile(string $html, array $profile): array {
    $profile_label = $profile['label'] ?? 'Unknown';
    $this->logger->info('Starting extraction with profile "@profile"', ['@profile' => $profile_label]);

    $dom = new \DOMDocument();
    @$dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

    // Extract title.
    $titleElements = $dom->getElementsByTagName('title');
    $title = $titleElements->length > 0 ? $titleElements->item(0)->textContent : '';
    if (strpos($title, '|') !== FALSE) {
      $title = trim(substr($title, 0, strpos($title, '|')));
    }

    $this->logger->info('Extracted page title: "@title"', ['@title' => $title]);

    $extractions = [];
    $mappings = $profile['mappings'] ?? [];
    $xpath = new \DOMXPath($dom);
    $all_elements = [];

    foreach ($mappings as $mapping_index => $mapping) {
      $selector = $mapping['selector'] ?? '';
      $target_field = $mapping['target_field'] ?? '';
      $paragraph_type = $mapping['paragraph_type'] ?? '';
      $attribute = $mapping['attribute'] ?? '';

      // Require selector and target_field.
      if (empty($selector) || empty($target_field)) {
        continue;
      }

      $xpath_expression = $this->cssToXPath($selector);
      $this->logger->info('Processing mapping @index: selector "@selector" -> field "@field"', [
        '@index' => $mapping_index + 1,
        '@selector' => $selector,
        '@field' => $target_field,
      ]);

      if (empty($xpath_expression)) {
        continue;
      }

      $elements = $xpath->query($xpath_expression);
      if ($elements && $elements->length > 0) {
        foreach ($elements as $element_index => $element) {
          $position = $this->getDomPosition($element, $xpath);
          $html_content = $dom->saveHTML($element);

          if (!empty(trim($html_content))) {
            $all_elements[] = [
              'position' => $position,
              'content' => $this->removeXmlDeclaration($html_content),
              'target_field' => $target_field,
              'paragraph_type' => $paragraph_type,
              'selector' => $selector,
              'mapping_index' => $mapping_index,
              'attribute' => $attribute,
              'dom_element' => $element,
            ];
          }
        }
      }
      else {
        $this->logger->warning('Selector "@selector" did not match any elements.', ['@selector' => $selector]);
      }
    }

    // Sort by DOM position.
    usort($all_elements, fn($a, $b) => $a['position'] <=> $b['position']);

    foreach ($all_elements as $element) {
      $content = $element['content'];

      // When an attribute is specified, extract the attribute value as a
      // plain string from the stored DOM element (skipping sanitization).
      if (!empty($element['attribute']) && $element['dom_element'] instanceof \DOMElement) {
        $content = $element['dom_element']->getAttribute($element['attribute']);
      }
      // Sanitize content for rich text destination fields,
      // including paragraph fields whose inner content field is rich text.
      elseif ($this->shouldSanitizeForRichText($element['target_field'])) {
        $content = $this->sanitizeForRichText($content);
      }

      $extractions[] = [
        'content' => $content,
        'target_field' => $element['target_field'],
        'paragraph_type' => $element['paragraph_type'],
        'selector' => $element['selector'],
      ];
    }

    $this->logger->info('Profile extraction complete: Created @count items in DOM order', [
      '@count' => count($extractions),
    ]);

    return [
      'title' => $title,
      'extractions' => $extractions,
    ];
  }

  /**
   * Apply highlight styles to content based on configured rules.
   *
   * @param string $html
   *   The HTML content to process.
   * @param array $highlights
   *   Array of highlight rules, each with 'selector' and 'color' keys.
   *
   * @return string
   *   The HTML content with highlights applied.
   */
  public function applyHighlights(string $html, array $highlights): string {
    if (empty($html) || empty($highlights)) {
      return $html;
    }

    $dom = new \DOMDocument();
    @$dom->loadHTML('<?xml encoding="UTF-8"><div id="highlight-wrapper">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

    $xpath = new \DOMXPath($dom);

    foreach ($highlights as $highlight) {
      $selector = $highlight['selector'] ?? '';
      $color = $highlight['color'] ?? '';

      if (empty($selector) || empty($color)) {
        continue;
      }

      $xpath_expression = $this->cssToXPath($selector);
      if (empty($xpath_expression)) {
        continue;
      }

      $elements = $xpath->query($xpath_expression);
      if ($elements && $elements->length > 0) {
        foreach ($elements as $element) {
          $existing_style = $element->getAttribute('style');
          $highlight_style = 'background-color: ' . $color . ';';
          $new_style = !empty($existing_style)
            ? rtrim($existing_style, ';') . '; ' . $highlight_style
            : $highlight_style;
          $element->setAttribute('style', $new_style);
        }
      }
    }

    $wrapper = $dom->getElementById('highlight-wrapper');
    if ($wrapper) {
      $content = '';
      foreach ($wrapper->childNodes as $child) {
        $content .= $dom->saveHTML($child);
      }
      return $this->removeXmlDeclaration($content);
    }

    return $html;
  }

  /**
   * Convert a CSS selector to an XPath expression.
   *
   * @param string $selector
   *   The CSS selector.
   *
   * @return string
   *   The XPath expression.
   */
  public function cssToXPath(string $selector): string {
    $selector = trim($selector);

    if (empty($selector)) {
      return '';
    }

    // Handle descendant selector with spaces.
    if (strpos($selector, ' ') !== FALSE) {
      $parts = preg_split('/\s+/', $selector);
      $xpath_parts = [];

      foreach ($parts as $index => $part) {
        $part = trim($part);
        if ($part === '>') {
          continue;
        }

        $is_direct_child = ($index > 0 && isset($parts[$index - 1]) && trim($parts[$index - 1]) === '>');
        $prefix = $is_direct_child ? '/' : '//';

        $part_xpath = $this->singleSelectorToXPath($part);
        if (!empty($part_xpath)) {
          $part_xpath = ltrim($part_xpath, '/');
          $xpath_parts[] = $prefix . $part_xpath;
        }
      }

      return implode('', $xpath_parts);
    }

    return $this->singleSelectorToXPath($selector);
  }

  /**
   * Get the position of an element in document order.
   *
   * @param \DOMNode $element
   *   The DOM element.
   * @param \DOMXPath $xpath
   *   The XPath object.
   *
   * @return int
   *   The position of the element in document order.
   */
  protected function getDomPosition(\DOMNode $element, \DOMXPath $xpath): int {
    // Use evaluate() instead of query() to get the numeric result from count().
    $result = $xpath->evaluate('count(preceding::* | ancestor::*)', $element);
    return (int) $result;
  }

  /**
   * Convert a single CSS selector (no spaces) to XPath.
   *
   * @param string $selector
   *   The CSS selector.
   *
   * @return string
   *   The XPath expression.
   */
  protected function singleSelectorToXPath(string $selector): string {
    // Extract :nth-child(n) pseudo-selector if present.
    $nthChildIndex = NULL;
    if (preg_match('/:nth-child\((\d+)\)$/', $selector, $nthMatches)) {
      $nthChildIndex = (int) $nthMatches[1];
      // Remove the :nth-child() part from selector for further processing.
      $selector = preg_replace('/:nth-child\(\d+\)$/', '', $selector);
    }

    // Extract :first-child pseudo-selector if present.
    if (preg_match('/:first-child$/', $selector)) {
      $nthChildIndex = 1;
      $selector = preg_replace('/:first-child$/', '', $selector);
    }

    // Extract :last-child pseudo-selector if present.
    $isLastChild = FALSE;
    if (preg_match('/:last-child$/', $selector)) {
      $isLastChild = TRUE;
      $selector = preg_replace('/:last-child$/', '', $selector);
    }

    $xpath = '';

    // ID selector: #id-name.
    if (strpos($selector, '#') === 0 && strpos($selector, '.') === FALSE) {
      $id = substr($selector, 1);
      $xpath = '//*[@id=\'' . $id . '\']';
    }
    // Class selector: .class-name.
    elseif (strpos($selector, '.') === 0) {
      $classes = explode('.', substr($selector, 1));
      $conditions = [];
      foreach ($classes as $class) {
        if (!empty($class)) {
          $conditions[] = 'contains(concat(\' \', normalize-space(@class), \' \'), \' ' . $class . ' \')';
        }
      }
      $xpath = '//*[' . implode(' and ', $conditions) . ']';
    }
    // Tag with ID: tag#id.
    elseif (preg_match('/^([a-zA-Z][a-zA-Z0-9]*)?#([a-zA-Z0-9_-]+)$/', $selector, $matches)) {
      $tag = $matches[1] ?: '*';
      $id = $matches[2];
      $xpath = '//' . $tag . '[@id=\'' . $id . '\']';
    }
    // Tag with class(es): tag.class.
    elseif (preg_match('/^([a-zA-Z][a-zA-Z0-9]*)\.(.+)$/', $selector, $matches)) {
      $tag = $matches[1];
      $classes = explode('.', $matches[2]);
      $conditions = [];
      foreach ($classes as $class) {
        if (!empty($class)) {
          $conditions[] = 'contains(concat(\' \', normalize-space(@class), \' \'), \' ' . $class . ' \')';
        }
      }
      $xpath = '//' . $tag . '[' . implode(' and ', $conditions) . ']';
    }
    // Plain tag name.
    elseif (preg_match('/^[a-zA-Z][a-zA-Z0-9]*$/', $selector)) {
      $xpath = '//' . $selector;
    }
    else {
      $this->logger->warning('Could not parse CSS selector: @selector', ['@selector' => $selector]);
      return '';
    }

    // Add positional predicate for :nth-child().
    if ($nthChildIndex !== NULL) {
      $xpath .= '[' . $nthChildIndex . ']';
    }

    // Add last() predicate for :last-child.
    if ($isLastChild) {
      $xpath .= '[last()]';
    }

    return $xpath;
  }

  /**
   * Sanitize HTML content for a rich text field.
   *
   * Converts DIV and SPAN elements to P elements, retains heading tags
   * (h1-h6), and removes all attributes from remaining tags. This
   * produces clean HTML suitable for CKEditor/rich text fields.
   *
   * @param string $html
   *   The HTML content to sanitize.
   *
   * @return string
   *   The sanitized HTML content.
   */
  public function sanitizeForRichText(string $html): string {
    if (empty(trim($html))) {
      return '';
    }

    $dom = new \DOMDocument();
    @$dom->loadHTML(
      '<?xml encoding="UTF-8"><div id="rich-text-wrapper">' . $html . '</div>',
      LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
    );

    // Convert DIV and SPAN elements to P elements, working from the
    // innermost elements outward to avoid creating nested <p> tags.
    foreach (['div', 'span'] as $tagName) {
      // Re-collect each iteration since the DOM is being modified.
      // Reverse order so inner elements are processed first.
      $elements = [];
      foreach ($dom->getElementsByTagName($tagName) as $element) {
        if ($element->getAttribute('id') === 'rich-text-wrapper') {
          continue;
        }
        $elements[] = $element;
      }
      $elements = array_reverse($elements);

      foreach ($elements as $element) {
        $replacement = $dom->createElement('p');
        while ($element->firstChild) {
          $replacement->appendChild($element->firstChild);
        }
        $element->parentNode->replaceChild($replacement, $element);
      }
    }

    // Flatten nested <p> tags — <p> cannot validly contain block elements.
    // Unwrap any <p> whose parent is also a <p> by promoting its children.
    $this->flattenNestedBlockElements($dom);

    // Remove attributes from all elements, retaining href on <a> tags.
    $xpath = new \DOMXPath($dom);
    $allElements = $xpath->query('//*');
    foreach ($allElements as $element) {
      if ($element->getAttribute('id') === 'rich-text-wrapper') {
        continue;
      }
      $attributes = [];
      foreach ($element->attributes as $attr) {
        if ($element->nodeName === 'a' && $attr->nodeName === 'href') {
          continue;
        }
        $attributes[] = $attr->nodeName;
      }
      foreach ($attributes as $attrName) {
        $element->removeAttribute($attrName);
      }
    }

    // Remove empty elements (no text content and no meaningful children).
    $this->removeEmptyElements($dom);

    // Strip tags that aren't allowed, keeping headings, p, ul, ol, li, br, a,
    // strong, em, blockquote, table elements.
    $wrapper = $dom->getElementById('rich-text-wrapper');
    if (!$wrapper) {
      return '';
    }

    $content = '';
    foreach ($wrapper->childNodes as $child) {
      $content .= $dom->saveHTML($child);
    }

    $content = $this->removeXmlDeclaration($content);

    // Strip disallowed tags, keeping only rich-text-appropriate ones.
    $allowedTags = '<h1><h2><h3><h4><h5><h6><p><ul><ol><li><br><a><strong><em><b><i><blockquote><table><thead><tbody><tfoot><tr><th><td>';
    $content = strip_tags($content, $allowedTags);

    // Final pass: remove any empty tags (including those containing only
    // whitespace or &nbsp; entities).
    $previous = '';
    while ($previous !== $content) {
      $previous = $content;
      $content = preg_replace('/<(\w+)(?:\s[^>]*)?>[\s\x{00A0}]*<\/\1>/u', '', $content);
    }
    $content = trim($content);

    return $content;
  }

  /**
   * Flattens nested block-level elements in a DOM document.
   *
   * HTML does not allow block elements (p, h1-h6) inside <p> tags.
   * This method unwraps any <p> that contains other block elements by
   * promoting the children to siblings of the parent <p>.
   *
   * @param \DOMDocument $dom
   *   The DOM document to process.
   */
  protected function flattenNestedBlockElements(\DOMDocument $dom): void {
    $blockTags = ['p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'blockquote', 'table'];

    $changed = TRUE;
    while ($changed) {
      $changed = FALSE;
      $xpath = new \DOMXPath($dom);
      $paragraphs = $xpath->query('//p');

      foreach ($paragraphs as $p) {
        $hasBlockChild = FALSE;
        foreach ($p->childNodes as $child) {
          if ($child instanceof \DOMElement && in_array($child->nodeName, $blockTags, TRUE)) {
            $hasBlockChild = TRUE;
            break;
          }
        }

        if ($hasBlockChild) {
          // Promote all children to siblings before the parent <p>.
          $parent = $p->parentNode;
          while ($p->firstChild) {
            $parent->insertBefore($p->firstChild, $p);
          }
          $parent->removeChild($p);
          $changed = TRUE;
          // Restart since the DOM has changed.
          break;
        }
      }
    }
  }

  /**
   * Recursively removes empty elements from a DOM document.
   *
   * An element is considered empty if it contains no meaningful text content
   * (whitespace and &nbsp; are treated as empty). Self-closing tags like
   * <br> are excluded from removal.
   *
   * @param \DOMDocument $dom
   *   The DOM document to clean.
   */
  protected function removeEmptyElements(\DOMDocument $dom): void {
    $xpath = new \DOMXPath($dom);
    // Self-closing / void elements that are never "empty".
    $voidTags = ['br', 'hr', 'img', 'input'];

    $changed = TRUE;
    while ($changed) {
      $changed = FALSE;
      $allElements = $xpath->query('//*');
      $toRemove = [];

      foreach ($allElements as $element) {
        if ($element->getAttribute('id') === 'rich-text-wrapper') {
          continue;
        }
        if (in_array($element->nodeName, $voidTags, TRUE)) {
          continue;
        }
        // Strip regular whitespace and non-breaking spaces (\xC2\xA0 is
        // UTF-8 for &nbsp; / U+00A0).
        $text = str_replace("\xC2\xA0", '', $element->textContent);
        if (trim($text) === '') {
          $toRemove[] = $element;
        }
      }

      foreach ($toRemove as $element) {
        if ($element->parentNode) {
          $element->parentNode->removeChild($element);
          $changed = TRUE;
        }
      }
    }
  }

  /**
   * Checks if a target field type is a rich text field.
   *
   * @param string $targetField
   *   The composite target field key (e.g., 'text_with_summary:field_body').
   *
   * @return bool
   *   TRUE if the field type is a rich text type.
   */
  public function isRichTextField(string $targetField): bool {
    if (empty($targetField) || !str_contains($targetField, ':')) {
      return FALSE;
    }

    $fieldType = explode(':', $targetField, 2)[0];
    return in_array($fieldType, ContentMigrationConstants::RICH_TEXT_FIELD_TYPES, TRUE);
  }

  /**
   * Checks if extracted content should be sanitized for rich text.
   *
   * Returns TRUE for both direct rich text fields (text_with_summary, etc.)
   * and paragraph/entity reference revision fields, since paragraph content
   * fields are themselves rich text fields.
   *
   * @param string $targetField
   *   The composite target field key (e.g., 'text_with_summary:field_body'
   *   or 'entity_reference_revisions:field_content').
   *
   * @return bool
   *   TRUE if the content should be sanitized for rich text.
   */
  public function shouldSanitizeForRichText(string $targetField): bool {
    if (empty($targetField) || !str_contains($targetField, ':')) {
      return FALSE;
    }

    $fieldType = explode(':', $targetField, 2)[0];

    // Direct rich text fields.
    if (in_array($fieldType, ContentMigrationConstants::RICH_TEXT_FIELD_TYPES, TRUE)) {
      return TRUE;
    }

    // Paragraph reference fields — their inner content field is rich text.
    if ($fieldType === 'entity_reference_revisions') {
      return TRUE;
    }

    return FALSE;
  }

  /**
   * Extract plain text from HTML content.
   *
   * @param string $html
   *   The HTML content.
   *
   * @return string
   *   The plain text content.
   */
  public function extractPlainText(string $html): string {
    // Strip tags and decode entities.
    $text = strip_tags($html);
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    // Normalize whitespace.
    $text = preg_replace('/\s+/', ' ', $text);
    return trim($text);
  }

}
