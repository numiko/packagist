<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\content_migration\Attribute\AiMigration;
use Drupal\field\Entity\FieldConfig;
use Drupal\node\NodeInterface;

/**
 * Plugin for generating taxonomy term suggestions using AI.
 */
#[AiMigration(
  id: 'taxonomy_suggestions',
  label: new TranslatableMarkup('Taxonomy Suggestions'),
  description: new TranslatableMarkup('Generates taxonomy term suggestions for selected taxonomy fields based on content analysis.')
)]
class TaxonomySuggestions extends TaxonomyBase {

  /**
   * {@inheritdoc}
   */
  public function configurationForm(array $form, FormStateInterface $form_state, array $configuration = []): array {
    $content_type = $form_state->getValue('content_type');

    if (!$content_type) {
      return [
        '#markup' => $this->t('Please select a content type first.'),
      ];
    }

    $taxonomy_fields = $this->getTaxonomyFieldOptions($content_type);

    if (empty($taxonomy_fields)) {
      return [
        '#markup' => $this->t('No taxonomy fields found for this content type.'),
      ];
    }

    $form['taxonomy_fields'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Taxonomy Fields'),
      '#options' => $taxonomy_fields,
      '#default_value' => $configuration['taxonomy_fields'] ?? [],
      '#description' => $this->t('Select the taxonomy fields to generate suggestions for. Leave all unchecked to skip this plugin.'),
    ];

    $form['max_suggestions'] = [
      '#type' => 'number',
      '#title' => $this->t('Maximum Suggestions per Field'),
      '#default_value' => $configuration['max_suggestions'] ?? 5,
      '#min' => 1,
      '#max' => 20,
      '#description' => $this->t('Maximum number of taxonomy terms to suggest for each field.'),
    ];

    $form['auto_create_terms'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Auto-create New Terms'),
      '#default_value' => $configuration['auto_create_terms'] ?? TRUE,
      '#description' => $this->t('Automatically create new taxonomy terms if they do not exist.'),
    ];

    $form['suggestion_style'] = [
      '#type' => 'select',
      '#title' => $this->t('Suggestion Style'),
      '#options' => [
        'keywords' => $this->t('Keywords (single words or short phrases)'),
        'topics' => $this->t('Topics (broader subject areas)'),
        'categories' => $this->t('Categories (hierarchical classification)'),
        'tags' => $this->t('Tags (descriptive labels)'),
      ],
      '#default_value' => $configuration['suggestion_style'] ?? 'keywords',
      '#description' => $this->t('The style of taxonomy terms to suggest.'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $taxonomy_fields = $form_state->getValue('taxonomy_fields');

    // Allow empty selection to disable plugin - no validation needed
    // Users can leave all fields unchecked to skip this plugin.
  }

  /**
   * {@inheritdoc}
   */
  public function processContent(string $content, NodeInterface $node, array $configuration): array {
    $taxonomy_fields = array_filter($configuration['taxonomy_fields'] ?? []);
    $max_suggestions = (int) ($configuration['max_suggestions'] ?? 5);
    $auto_create_terms = $configuration['auto_create_terms'] ?? TRUE;
    $suggestion_style = $configuration['suggestion_style'] ?? 'keywords';

    // If no taxonomy fields configured, skip processing.
    if (empty($taxonomy_fields)) {
      return [
        'skipped' => TRUE,
        'reason' => 'No taxonomy fields configured for this plugin',
      ];
    }

    $results = [];

    foreach ($taxonomy_fields as $field_name) {
      if (empty($field_name)) {
        continue;
      }

      try {
        // Get the field definition to understand the vocabulary.
        $field_definitions = $this->entityFieldManager->getFieldDefinitions('node', $node->bundle());

        if (!isset($field_definitions[$field_name])) {
          continue;
        }

        $field_definition = $field_definitions[$field_name];
        $vocabulary_id = $field_definition->getSetting('handler_settings')['target_bundles'][0] ?? NULL;

        if (!$vocabulary_id) {
          continue;
        }

        // Generate suggestions for this field.
        $suggestions = $this->generateTaxonomySuggestions(
          $content,
          $vocabulary_id,
          $max_suggestions,
          $suggestion_style
        );

        // Process the suggestions and assign to the field.
        $term_ids = $this->processSuggestions($suggestions, $vocabulary_id, $auto_create_terms);

        if (!empty($term_ids)) {
          $node->set($field_name, $term_ids);
          $results[$field_name] = [
            'suggestions' => $suggestions,
            'term_ids' => $term_ids,
          ];
        }
      }
      catch (\Exception $e) {
        // Log the error but continue with other fields.
        $this->logger->warning(
          'Failed to process taxonomy suggestions for field @field: @error',
          ['@field' => (string) $field_name, '@error' => (string) $e->getMessage()]
        );
      }
    }

    return $results;
  }

  /**
   * Gets taxonomy field options for the given content type.
   *
   * @param string $content_type
   *   The content type ID.
   *
   * @return array
   *   An array of field labels keyed by field names.
   */
  protected function getTaxonomyFieldOptions(string $content_type): array {
    $field_options = [];
    $fields = $this->entityFieldManager->getFieldDefinitions('node', $content_type);

    foreach ($fields as $field_name => $field_definition) {
      if ($field_definition instanceof FieldConfig) {
        $field_type = $field_definition->getType();
        if ($field_type === 'entity_reference' && $field_definition->getSetting('target_type') === 'taxonomy_term') {
          $field_options[$field_name] = $field_definition->getLabel();
        }
      }
    }

    return $field_options;
  }

}
