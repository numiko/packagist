<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

/**
 * Plugin for generating content introductions using AI.
 *
 * @AiMigration(
 *   id = "introduction_content",
 *   label = @Translation("Generate Introduction"),
 *   description = @Translation("Generates an engaging introduction for the page content to help orient readers.")
 * )
 */
class IntroductionContent extends SummariseContentBase {

  /**
   * {@inheritdoc}
   */
  protected function getFieldTitle() {
    return $this->t('Field for Introduction');
  }

  /**
   * {@inheritdoc}
   */
  protected function getFieldDescription() {
    return $this->t('Select the field where the introduction will be saved. Must be a text field. Leave empty to skip this plugin.');
  }

  /**
   * {@inheritdoc}
   */
  protected function getStyleTitle() {
    return $this->t('Introduction Style');
  }

  /**
   * {@inheritdoc}
   */
  protected function getStyleDescription() {
    return $this->t('The style of introduction to generate.');
  }

  /**
   * {@inheritdoc}
   */
  protected function getStyleOptions(): array {
    return [
      'professional' => $this->t('Professional (formal and authoritative)'),
      'welcoming' => $this->t('Welcoming (friendly and inviting)'),
      'contextual' => $this->t('Contextual (sets the scene and background)'),
      'hook' => $this->t('Hook (attention-grabbing opener)'),
      'overview' => $this->t('Overview (roadmap of what follows)'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  protected function getDefaultStyle(): string {
    return 'professional';
  }

  /**
   * {@inheritdoc}
   */
  protected function getDefaultMaxLength(): int {
    return 400;
  }

  /**
   * {@inheritdoc}
   */
  protected function getContentTypeName(): string {
    return 'introduction';
  }

  /**
   * {@inheritdoc}
   */
  protected function getStyleInstructions(string $style): string {
    switch ($style) {
      case 'welcoming':
        return 'be warm and inviting, making readers feel comfortable and encouraging them to continue reading. Use inclusive language and set a friendly tone';

      case 'professional':
        return 'be authoritative and credible, establishing expertise while maintaining clarity. Use formal but accessible language';

      case 'contextual':
        return 'provide essential background information and context that helps readers understand why this content matters and where it fits';

      case 'hook':
        return 'grab attention immediately with compelling facts, questions, or statements that make readers want to learn more';

      case 'overview':
        return 'act as a roadmap, outlining what readers will learn and how the content is organized to help them navigate effectively';

      default:
        return 'provide a clear and engaging opening that orients readers and encourages them to continue';
    }
  }

  /**
   * Builds the prompt for content generation.
   *
   * @param string $content
   *   The content to process.
   * @param int $max_length
   *   The maximum length of the generated content.
   * @param string $style
   *   The style of content to generate.
   * @param array $configuration
   *   The plugin configuration settings.
   *
   * @return string
   *   The complete prompt for Claude API.
   */
  protected function buildContentPrompt(string $content, int $max_length, string $style, array $configuration = []): string {
    $style_instructions = $this->getStyleInstructions($style);
    $content_type = $this->getContentTypeName();
    
    // Check if we have a taxonomy prompt for audience targeting
    $audience_guidance = '';
    if (!empty($configuration['taxonomy_prompt'])) {
      $audience_guidance = "\n**AUDIENCE TARGETING:**\n" . $configuration['taxonomy_prompt'] . "\n";
      \Drupal::logger('content_migration')->info('IntroductionContent: Using audience targeting in buildContentPrompt. Style: @style, Max length: @max_length, Prompt: @prompt', [
        '@style' => $style,
        '@max_length' => $max_length,
        '@prompt' => substr($configuration['taxonomy_prompt'], 0, 100) . (strlen($configuration['taxonomy_prompt']) > 100 ? '...' : ''),
      ]);
    }

    return <<<EOT
Please create an engaging {$content_type} for a webpage based on the following content. The {$content_type} should be under {$max_length} characters and should {$style_instructions}.{$audience_guidance}

Think of this as the opening paragraph or section that appears at the top of the page to orient visitors and encourage them to read the full content below.

Full page content:
{$content}

Requirements:
- Maximum {$max_length} characters
- {$style_instructions}
- Use UK English spelling
- Do not include quotes around the {$content_type}
- Make it engaging and informative
- Focus on welcoming readers and setting expectations
- Should complement, not duplicate, the main content
- Think about what a visitor needs to know first when they land on this page

**CRITICAL OUTPUT REQUIREMENTS:**
- Your response must contain ONLY the {$content_type} text, nothing else
- Do not include any explanations, comments, or wrapper text
- Do not wrap the content in code blocks or markdown
- Do not include any text before or after the {$content_type}
- Start immediately with the {$content_type} content

Please provide only the {$content_type} text, nothing else.
EOT;
  }

  /**
   * {@inheritdoc}
   */
  protected function getTextFormat(): string {
    return 'basic_html';
  }

}