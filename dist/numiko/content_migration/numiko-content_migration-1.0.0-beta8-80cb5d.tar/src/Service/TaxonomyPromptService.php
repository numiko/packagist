<?php

namespace Drupal\content_migration\Service;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\taxonomy\Entity\Term;

/**
 * Service for managing taxonomy terms with associated prompts.
 */
class TaxonomyPromptService {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructs a new TaxonomyPromptService.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * Gets all vocabulary options for the taxonomy dropdown.
   *
   * @return array
   *   An array of vocabulary options keyed by vocabulary ID.
   */
  public function getVocabularyOptions(): array {
    $vocabulary_storage = $this->entityTypeManager->getStorage('taxonomy_vocabulary');
    $vocabularies = $vocabulary_storage->loadMultiple();

    $options = ['' => '- None -'];
    foreach ($vocabularies as $vocabulary) {
      $options[$vocabulary->id()] = $vocabulary->label();
    }

    return $options;
  }

  /**
   * Gets taxonomy terms with their associated prompts for a vocabulary.
   *
   * @param string $vocabulary_id
   *   The vocabulary ID.
   *
   * @return array
   *   An array of terms with their prompts, keyed by term ID.
   */
  public function getTermsWithPrompts(string $vocabulary_id): array {
    if (empty($vocabulary_id)) {
      return [];
    }

    $term_storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $terms = $term_storage->loadTree($vocabulary_id, 0, NULL, TRUE);

    $terms_with_prompts = [];
    foreach ($terms as $term) {
      $description = $term->getDescription();
      if (!empty($description)) {
        $terms_with_prompts[$term->id()] = [
          'name' => $term->getName(),
          'prompt' => $description,
          'depth' => $term->depth,
          'parents' => array_filter($term->parents, function($parent) { return $parent != 0; }),
        ];
      }
    }

    return $terms_with_prompts;
  }

  /**
   * Gets term options for a dropdown.
   *
   * @param string $vocabulary_id
   *   The vocabulary ID.
   *
   * @return array
   *   An array of term options keyed by term ID.
   */
  public function getTermOptions(string $vocabulary_id): array {
    $terms_with_prompts = $this->getTermsWithPrompts($vocabulary_id);
    
    $options = ['' => '- Select audience -'];
    // Only show child terms (depth > 0), not root terms
    foreach ($terms_with_prompts as $tid => $term_data) {
      if ($term_data['depth'] > 0) {
        $options[$tid] = $term_data['name'];
      }
    }

    return $options;
  }

  /**
   * Gets the prompt for a specific taxonomy term.
   *
   * @param int $term_id
   *   The taxonomy term ID.
   *
   * @return string|null
   *   The prompt from the term's description, or NULL if not found.
   */
  public function getTermPrompt(int $term_id): ?string {
    $term = Term::load($term_id);
    if (!$term) {
      return NULL;
    }

    return $term->getDescription();
  }

  /**
   * Gets the root term (default style guide) for a vocabulary.
   *
   * @param string $vocabulary_id
   *   The vocabulary ID.
   *
   * @return array|null
   *   The root term data with prompt, or NULL if not found.
   */
  public function getRootTerm(string $vocabulary_id): ?array {
    $terms_with_prompts = $this->getTermsWithPrompts($vocabulary_id);
    
    foreach ($terms_with_prompts as $tid => $term_data) {
      if ($term_data['depth'] == 0) {
        return $term_data;
      }
    }
    
    return NULL;
  }

  /**
   * Gets the hierarchical prompt (root + audience) for a term.
   *
   * @param int $term_id
   *   The taxonomy term ID.
   *
   * @return array
   *   Array with 'style_guide' and 'audience_prompt' keys.
   */
  public function getHierarchicalPrompt(int $term_id): array {
    $term = Term::load($term_id);
    if (!$term) {
      return ['style_guide' => '', 'audience_prompt' => ''];
    }

    $vocabulary_id = $term->bundle();
    $root_term = $this->getRootTerm($vocabulary_id);
    
    return [
      'style_guide' => $root_term ? $root_term['prompt'] : '',
      'audience_prompt' => $term->getDescription(),
    ];
  }

  /**
   * Checks if a vocabulary has any terms with prompts.
   *
   * @param string $vocabulary_id
   *   The vocabulary ID.
   *
   * @return bool
   *   TRUE if the vocabulary has terms with prompts, FALSE otherwise.
   */
  public function vocabularyHasTermsWithPrompts(string $vocabulary_id): bool {
    $terms_with_prompts = $this->getTermsWithPrompts($vocabulary_id);
    return !empty($terms_with_prompts);
  }

}