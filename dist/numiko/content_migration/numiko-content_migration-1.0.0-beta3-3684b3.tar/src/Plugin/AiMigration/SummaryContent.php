<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin\AiMigration;

/**
 * Plugin for generating content summaries using AI.
 *
 * @AiMigration(
 *   id = "summary_content",
 *   label = @Translation("Generate Summary"),
 *   description = @Translation("Generates a summary of the content for teasers and meta descriptions.")
 * )
 */
class SummaryContent extends SummariseContentBase {

  /**
   * {@inheritdoc}
   */
  protected function getFieldTitle() {
    return $this->t('Field for Summary');
  }

  /**
   * {@inheritdoc}
   */
  protected function getFieldDescription() {
    return $this->t('Select the field where the summary will be saved. Must be a text field. Leave empty to skip this plugin.');
  }

  /**
   * {@inheritdoc}
   */
  protected function getStyleTitle() {
    return $this->t('Summary Style');
  }

  /**
   * {@inheritdoc}
   */
  protected function getStyleDescription() {
    return $this->t('The style of summary to generate.');
  }

  /**
   * {@inheritdoc}
   */
  protected function getStyleOptions(): array {
    return [
      'teaser' => $this->t('Teaser (engaging and descriptive)'),
      'meta' => $this->t('Meta description (SEO focused)'),
      'abstract' => $this->t('Abstract (academic style)'),
      'bullet_points' => $this->t('Key points (bullet format)'),
    ];
  }

  /**
   * {@inheritdoc}
   */
  protected function getDefaultStyle(): string {
    return 'teaser';
  }

  /**
   * {@inheritdoc}
   */
  protected function getDefaultMaxLength(): int {
    return 250;
  }

  /**
   * {@inheritdoc}
   */
  protected function getContentTypeName(): string {
    return 'summary';
  }

  /**
   * {@inheritdoc}
   */
  protected function getStyleInstructions(string $style): string {
    switch ($style) {
      case 'teaser':
        return 'be engaging and encourage reading the full content. Focus on the most interesting aspects';

      case 'meta':
        return 'be optimized for search engines while remaining readable. Include key topics and benefits';

      case 'abstract':
        return 'be objective and factual, highlighting the main points and conclusions';

      case 'bullet_points':
        return 'present the key points in a clear, scannable format using bullet points';

      default:
        return 'clearly communicate the main purpose and key information';
    }
  }

  /**
   * {@inheritdoc}
   */
  protected function getTextFormat(): string {
    return 'plain_text';
  }

}