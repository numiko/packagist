<?php

declare(strict_types=1);

namespace Drupal\content_migration\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Defines an AI migration plugin annotation object.
 *
 * @see \Drupal\content_migration\Plugin\AiMigrationPluginManager
 * @see plugin_api
 *
 * @Annotation
 */
class AiMigration extends Plugin {

  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

  /**
   * The label of the plugin.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $label;

  /**
   * The description of the plugin.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $description;

}