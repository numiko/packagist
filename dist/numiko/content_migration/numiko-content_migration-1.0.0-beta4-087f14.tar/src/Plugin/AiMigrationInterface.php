<?php

declare(strict_types=1);

namespace Drupal\content_migration\Plugin;

use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\node\NodeInterface;

/**
 * Interface for AI migration plugins.
 */
interface AiMigrationInterface extends PluginInspectionInterface {

  /**
   * Gets the plugin label.
   *
   * @return string
   *   The plugin label.
   */
  public function getLabel(): string;

  /**
   * Gets the plugin description.
   *
   * @return string
   *   The plugin description.
   */
  public function getDescription(): string;

  /**
   * Builds the configuration form for this plugin.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param array $configuration
   *   The current plugin configuration.
   *
   * @return array
   *   The form elements for this plugin's configuration.
   */
  public function configurationForm(array $form, FormStateInterface $form_state, array $configuration = []): array;

  /**
   * Processes content using AI and populates node fields.
   *
   * @param string $content
   *   The extracted content from the webpage.
   * @param \Drupal\node\NodeInterface $node
   *   The node to populate with processed content.
   * @param array $configuration
   *   The plugin configuration settings.
   *
   * @return array
   *   An array containing the processed results.
   *
   * @throws \Exception
   *   Throws an exception if processing fails.
   */
  public function processContent(string $content, NodeInterface $node, array $configuration): array;

}