# Migrate Between Drupal 8 Instances

Process and Source plugins for building D8->D8 migrations.

This module was developed for the SMG project, and the smg_migrate module
shows how it can be used.

Example of running complex migration:

```
# Run from docroot
# Reinstall migration module
drush dre smg_migrate -y
```

```
# Run term import separately due to dependency errors
drush migrate-import --group=migrate_smg_term
```

```
# Main migration
drush migrate-import --group=migrate_smg --execute-dependencies
```

```
# 2nd pass - this will populate links - see LinkField that only
# runs on an update.
drush migrate-import --group=migrate_smg --update
```

```
# Menu items
drush migrate-import migrate_menu_link_content
```
