# Recipe Tools

## Recipe Commands

Provides a drush script which will allow browsing and installing of recipes from Numiko packagist  https://numiko.github.io/packagist/#

Until https://www.drupal.org/project/distributions_recipes/issues/3452522 has a resolution the following composer package
is required in order to unpack the dependencies from the recipe composer files.

https://gitlab.ewdev.ca/yonas.legesse/drupal-recipe-unpack

1. Add the git repos under the projects repositories list as follows:
```
    {
        "type": "vcs",
        "url": "https://gitlab.ewdev.ca/yonas.legesse/drupal-recipe-unpack.git"
    }
```

2. Install the package `composer require ewcomposer/unpack:dev-master`

## Usage

1. Install this package `composer require numiko/recipe_tools --dev`
2. Run `drush recipe:install`
3. Select the recipes by pressing the space bar.
4. Press enter to install the recipes

This will install the required composer packages, run the recipe installation, and unpack the dependencies into the projects
composer.json. You can then export the config.

