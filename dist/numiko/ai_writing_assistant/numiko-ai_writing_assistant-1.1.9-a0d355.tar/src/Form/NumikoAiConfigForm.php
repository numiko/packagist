<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\DependencyInjection\AutowireTrait;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\ai\AiProviderPluginManager;
use Drupal\ai_writing_assistant\AiConfigKey;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * This form allows you to configure the prompt and AI service to use.
 */
class NumikoAiConfigForm extends ConfigFormBase {

  use AutowireTrait;

  public const SETTINGS = 'ai_writing_assistant.settings';

  public function __construct(
    ConfigFactoryInterface $cfi,
    #[Autowire(service: 'ai.provider')]
    protected readonly AiProviderPluginManager $ai,
    protected readonly EntityTypeManagerInterface $typeManager,
  ) {
    parent::__construct($cfi);
  }

  /**
   * {@inheritdoc}
   */
  #[\Override]
  public function getFormId() {
    return 'ai_writing_assistant_settings';
  }

  /**
   * {@inheritDoc}
   */
  #[\Override]
  public function getEditableConfigNames() {
    return [self::SETTINGS];
  }

  /**
   * {@inheritDoc}
   */
  #[\Override]
  public function buildForm(array $form, ?FormStateInterface $formState) {
    $chatModels = $this->ai->getSimpleProviderModelOptions('chat');
    $defaultModel = $this->ai->getSimpleDefaultProviderOptions('chat');

    $config = $this->config(self::SETTINGS);

    $form[AiConfigKey::StylePrompt->machine()] = [
      '#type' => 'entity_autocomplete',
      '#target_type' => 'ai_prompt',
      '#title' => AiConfigKey::StylePrompt->human(),
      '#description' => AiConfigKey::StylePrompt->desc(),
      '#default_value' => $this->typeManager->getStorage('ai_prompt')->load($config->get(AiConfigKey::StylePrompt->machine())),
      '#required' => TRUE,
    ];

    $form[AiConfigKey::Model->machine()] = [
      '#type' => 'select',
      '#options' => $chatModels,
      '#disabled' => count($chatModels) == 0,
      '#title' => AiConfigKey::Model->human(),
      '#default_value' => $config->get(AiConfigKey::Model->machine()) ?? $defaultModel,
      '#required' => TRUE,
    ];

    return parent::buildForm($form, $formState);
  }

  /**
   * {@inheritDoc}
   */
  #[\Override]
  public function submitForm(array &$form, FormStateInterface $formState): void {
    $this->config(self::SETTINGS)
      ->set(AiConfigKey::StylePrompt->machine(), $formState->getValue(AiConfigKey::StylePrompt->machine()))
      ->set(AiConfigKey::Model->machine(), $formState->getValue(AiConfigKey::Model->machine()))
      ->save();

    parent::submitForm($form, $formState);
  }

}
