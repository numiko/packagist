<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant\Form;

use Drupal\ai_writing_assistant\AiConfigKey;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityFieldManager;
use Drupal\Core\Entity\EntityTypeBundleInfo;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Allows the Anthropic and Claude Versions to be configured.
 */
class ClaudeConfigForm extends ConfigFormBase {

  /**
   * Entity bundle info.
   *
   * @var \Drupal\Core\Entity\EntityTypeBundleInfo
   */
  protected EntityTypeBundleInfo $bundleInfo;

  /**
   * Entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManager
   */
  protected EntityFieldManager $fieldManager;


  private const SETTINGS = 'ai_writing_assistant.settings';

  private const SETTING_KEYS = [
    AiConfigKey::ClaudeModel,
    AiConfigKey::StylePrompt,
  ];

  /**
   * Form constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $cfi
   *   Usual form config.
   * @param \Drupal\Core\Entity\EntityTypeBundleInfo $bundleInfo
   *   Entity bundle info.
   * @param \Drupal\Core\Entity\EntityFieldManager $fieldManager
   *   Entity field manager.
   */
  public function __construct(ConfigFactoryInterface $cfi, EntityTypeBundleInfo $bundleInfo, EntityFieldManager $fieldManager) {
    parent::__construct($cfi);
    $this->bundleInfo = $bundleInfo;
    $this->fieldManager = $fieldManager;
  }

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.bundle.info'),
      $container->get('entity_field.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ai_writing_assistant_settings';
  }

  /**
   * {@inheritDoc}
   */
  public function getEditableConfigNames() {
    return [self::SETTINGS];
  }

  /**
   * {@inheritDoc}
   */
  public function buildForm(array $form, ?FormStateInterface $formState) {
    $config = $this->config(self::SETTINGS);
    $form[AiConfigKey::ClaudeModel->machine()] = [
      '#type' => 'textfield',
      '#title' => AiConfigKey::ClaudeModel->human(),
      '#description' => AiConfigKey::ClaudeModel->desc(),
      '#default_value' => $config->get(AiConfigKey::ClaudeModel->machine()),
    ];
    $form[AiConfigKey::StylePrompt->machine()] = [
      '#type' => 'textarea',
      '#title' => AiConfigKey::StylePrompt->human(),
      '#description' => AiConfigKey::StylePrompt->desc(),
      '#default_value' => $config->get(AiConfigKey::StylePrompt->machine()),
    ];

    return parent::buildForm($form, $formState);
  }

  /**
   * {@inheritDoc}
   */
  public function validateForm(array &$form, FormStateInterface $formState) {
    foreach (AiConfigKey::GLOBAL_SETTINGS as $key) {
      if ($formState->getValue($key->machine()) === '') {
        $formState->setErrorByName(
          $key->machine(),
          $this->t('@prettyKey is not set, please add a value', ['@prettyKey' => $key->human()])
        );
      }
    };

    parent::validateForm($form, $formState);
  }

  /**
   * {@inheritDoc}
   */
  public function submitForm(array &$form, FormStateInterface $formState): void {
    $config = $this->config(self::SETTINGS);

    foreach (self::SETTING_KEYS as $key) {
      $config->set($key->machine(), $formState->getValue($key->machine()));
    }

    $config->save();

    parent::submitForm($form, $formState);
  }

}
