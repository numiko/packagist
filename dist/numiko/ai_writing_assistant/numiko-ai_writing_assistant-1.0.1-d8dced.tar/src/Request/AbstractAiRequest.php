<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant\Request;

use GuzzleHttp\Client;
use GuzzleHttp\Promise\PromiseInterface;
use Psr\Http\Client\ClientExceptionInterface;
use Psr\Http\Message\ResponseInterface;

/**
 * Boilerplate class for sending data to the AI.
 */
abstract class AbstractAiRequest {

  /**
   * The URL we send requests to.
   *
   * @return string
   *   Request URL
   */
  abstract protected static function getUrl(): string;

  /**
   * Construct HTTP headers.
   *
   * @param RequestOptions $options
   *   Options data.
   *
   * @return array
   *   The headers to send.
   */
  abstract protected static function prepareRequestHeaders(RequestOptions $options): array;

  /**
   * Construct the JSON body.
   *
   * @param string $userText
   *   Text the user typed.
   * @param RequestOptions $options
   *   Options data.
   *
   * @return array
   *   JSON array containing the request body
   */
  abstract protected static function prepareRequestJson(string $userText, RequestOptions $options): array;

  /**
   * Extract the AI's response from a sucessful response.
   *
   * @param \Psr\Http\Message\ResponseInterface $response
   *   The response.
   *
   * @return string
   *   The actual text response extracted from the main response.
   */
  abstract protected static function processSuccessResponse(ResponseInterface $response): string;

  /**
   * Try to catch and deal with errors.
   *
   * @param \Psr\Http\Client\ClientExceptionInterface $exception
   *   The response.
   *
   * @throws \Exception
   */
  abstract protected static function processFailResponse(ClientExceptionInterface $exception): noreturn;

  /**
   * Prepare data to send to the AI.
   *
   * @param \GuzzleHttp\Client $httpClient
   *   The HTTP Client used to make the request.
   * @param string $userText
   *   The (processed) text recived from the client.
   * @param \Drupal\ai_writing_assistant\Request\RequestOptions $options
   *   The AI configuration options.
   *
   * @return \GuzzleHttp\Promise\PromiseInterface
   *   The asynchronous processed response - Await it to get the LLM's response.
   */
  public static function request(Client $httpClient, string $userText, RequestOptions $options): PromiseInterface {
    return $httpClient->requestAsync('POST', static::getUrl(), [
      'headers' => static::prepareRequestHeaders($options),
      // Set a longer timeout as large text can take a while.
      'timeout' => 90,
      'json' => static::prepareRequestJson($userText, $options),
    ])->then(
      fn($success) => static::processSuccessResponse($success),
      fn($fail) => static::processFailResponse($fail)
    );
  }

}
