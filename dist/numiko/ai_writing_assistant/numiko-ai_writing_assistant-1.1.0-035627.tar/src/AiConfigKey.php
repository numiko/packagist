<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant;

use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Enumeration of config keys for Claude.
 */
enum AiConfigKey: string {
  case StylePrompt = 'summary_prompt';
  case Model = 'ai_model';
  case EnableAI = 'enable_ai';
  case UseDefautPrompt = 'use_default_style_guide';
  case LocalStyleGuide = 'local_style_guide';

  /**
   * Settings configured across the site.
   */
  public const GLOBAL_SETTINGS = [AiConfigKey::StylePrompt, AiConfigKey::Model];

  /**
   * Settings that are content type local.
   */
  public const LOCAL_SETTINGS = [
    AiConfigKey::EnableAI,
    AiConfigKey::UseDefautPrompt,
    AiConfigKey::LocalStyleGuide,
  ];

  /**
   * Machine readable name of this config key.
   */
  public function machine(): string {
    return $this->value;
  }

  /**
   * Human readable name of this config key.
   */
  public function human(): TranslatableMarkup {
    return match ($this) {
      AiConfigKey::StylePrompt => new TranslatableMarkup('Style Prompt'),
      AiConfigKey::Model => new TranslatableMarkup('The model to use'),
      AiConfigKey::EnableAI => new TranslatableMarkup('Enable AI Text Rewriting'),
      AiConfigKey::UseDefautPrompt => new TranslatableMarkup('Use the default prompt'),
      AiConfigKey::LocalStyleGuide => new TranslatableMarkup('Node-specific Style Prompt'),
    };
  }

  /**
   * Description of this config key.
   */
  public function desc(): TranslatableMarkup {
    return match ($this) {
      AiConfigKey::StylePrompt => new TranslatableMarkup('The default style guide given to the AI to get it to rewrite the field\'s text in a better tone'),
      AiConfigKey::LocalStyleGuide => new TranslatableMarkup('The default style guide is configurable in the admin settings'),
    };
  }

}
