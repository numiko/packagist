<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant\Request;

use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Exception\ConnectException;
use Psr\Http\Client\ClientExceptionInterface;
use Psr\Http\Message\ResponseInterface;

/**
 * Makes the API call to Claude.
 */
class AnthropicApiRequest extends AbstractAiRequest {

  /**
   * Anthropic API version.
   *
   * @see https://docs.anthropic.com/claude/reference/versions
   */
  private const API_VERSION = '2023-06-01';

  /**
   * {@inheritDoc}
   */
  protected static function getUrl(): string {
    // Messages API endpoint.
    //
    // @see https://docs.anthropic.com/claude/reference/messages_post
    return 'https://api.anthropic.com/v1/messages';
  }

  /**
   * {@inheritDoc}
   */
  protected static function prepareRequestHeaders(RequestOptions $options): array {
    return [
      'anthropic-version' => self::API_VERSION,
      'content-type' => 'application/json',
      'x-api-key' => $options->apiKey,
    ];
  }

  /**
   * {@inheritDoc}
   */
  protected static function prepareRequestJson(string $userText, RequestOptions $options): array {
    return [
      'model' => $options->aiModel,
      'messages' => [
        [
          'role' => 'user',
          'content' => $userText,
        ],
      ],
      'system' => $options->prompt,
      'max_tokens' => 2048,
      'stream' => FALSE,
    ];
  }

  /**
   * {@inheritDoc}
   */
  protected static function processSuccessResponse(ResponseInterface $response): string {
    /** @var Psr\Http\Message\StreamInterface */
    $body = $response->getBody();
    $jsonResponse = json_decode($body->getContents(), TRUE);
    return $jsonResponse['content'][0]['text'];
  }

  /**
   * {@inheritDoc}
   */
  protected static function processFailResponse(ClientExceptionInterface $exception): noreturn {
    if ($exception instanceof ConnectException) {
      $errorMessage = $exception->getMessage();
      throw new \Exception(
        "cURL returned the following error, maybe try extending the timeout: \"$errorMessage\""
      );
    }
    elseif ($exception instanceof ClientException) {
      $response = $exception->getResponse();
      $httpCode = $response->getStatusCode();
      $httpCodePhrase = $response->getReasonPhrase();
      $errorMessage = json_decode($response->getBody()->getContents(), TRUE)['error']['message'];
      throw new \Exception(
        "Claude HTTP call failed with code: $httpCode (\"$httpCodePhrase\") and message: \"$errorMessage\"",
      );
    }
    else {
      $errorMessage = $exception->getMessage();
      throw new \Exception("An unknown error occured $errorMessage");
    }
  }

}
