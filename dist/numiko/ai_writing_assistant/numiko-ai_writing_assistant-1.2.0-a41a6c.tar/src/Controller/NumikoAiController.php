<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant\Controller;

use Drupal\Core\Config\Config;
use Drupal\Core\Controller\ControllerBase;
use Drupal\ai\AiProviderPluginManager;
use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;
use Drupal\ai_writing_assistant\AiConfigKey;
use Drupal\ai_writing_assistant\Form\NumikoAiConfigForm;
use Symfony\Component\DependencyInjection\Attribute\Autowire;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Receives text to summarise and then returns the response from the AI.
 */
class NumikoAiController extends ControllerBase {

  /**
   * This modules config file.
   */
  protected readonly Config $config;

  public function __construct(
    #[Autowire(service: 'ai.provider')]
    protected readonly AiProviderPluginManager $aiProvider,
  ) {
    $this->config = $this->config(NumikoAiConfigForm::SETTINGS);
  }

  /**
   * The main processing class.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   Request from the client.
   *
   * @return \Symfony\Component\HttpFoundation\Response
   *   Response to the client
   */
  public function getData(Request $request): Response {
    $documentContent = json_decode($request->getContent(), TRUE);
    try {
      // Load the chosen provider & model.
      /** @var string */
      $model = $this->config->get(AiConfigKey::Model->machine());
      $model = explode('__', $model);
      if (count($model) !== 2) {
        throw new \Exception('No AI provider or model is configured for this operation.');
      }
      $provider = $this->aiProvider->createInstance($model[0]);
      $provider->setConfiguration($provider->getConfiguration() + ['max_tokens' => 4096]);

      $prompt = $this->getPrompt($documentContent['nodeType']);
      $messages = new ChatInput([new ChatMessage('system', $prompt), new ChatMessage('user', $documentContent['data'])]);
      $message = $provider->chat($messages, $model[1])->getNormalized();

      $response = new JsonResponse(['summary' => $message->getText()]);
    }
    catch (\Exception $error) {
      $response = new Response($error->getMessage(), Response::HTTP_BAD_REQUEST, ['content-type' => 'text/plain']);
    }
    return $response;
  }

  /**
   * Get the (non-secret) API options.
   *
   * @param string $nodeType
   *   The type of node this request is being sent from.
   *
   * @return string
   *   The full prompt.
   *
   * @throws \Exception
   */
  protected function getPrompt(string $nodeType): string {
    if ($nodeType === '') {
      throw new \Exception('Not able to figure out the type of node this page is, please contact an administrator');
    }

    $typeManager = $this->entityTypeManager();
    $aiSettings = $typeManager
      ->getStorage('node_type')
      ->load($nodeType)
      ?->getThirdPartySettings('ai_writing_assistant');

    if (!$aiSettings) {
      throw new \Exception('Node third party settings failed to load');
    }

    $aiPromptStorage = $typeManager->getStorage('ai_prompt');
    if ($aiSettings[AiConfigKey::UseDefautPrompt->machine()] ?? FALSE) {
      $stylePrompt = $aiPromptStorage->load($this->config->get(AiConfigKey::StylePrompt->machine()));
      if (!$stylePrompt) {
        throw new \Exception('The global prompt failed to load.');
      }
    }
    else {
      $stylePrompt = $aiPromptStorage->load($aiSettings[AiConfigKey::LocalStyleGuide->machine()]);
      if (!$stylePrompt) {
        throw new \Exception('The local prompt failed to load.');
      }
    }

    /** @var \Drupal\ai_prompt\Entity\AiPrompt $stylePrompt */
    $styleGuide = $stylePrompt->prompt;
    $mainPrompt = "Provide feedback as a bulleted list on the text below the asterick based on the following writing style guide. Make recommendations to what needs to be changed. Do not comment on anything that matches the writing style. Keep your response to less that 100 words.\r\nWriting Style Guide: $styleGuide *\r\nAlso return the provided text, rewritten to follow the writing style.\r\nProvide inline commentary on why you have changes parts of the text to match the writing style, wrapping your comments with [] brackets.\r\nSeparate the two sections with [[cut]]";
    return $mainPrompt;
  }

}
