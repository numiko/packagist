/**
 * Plan:
 * 1. [X] Click "Check tone" button
 * 2. [X] Show overlay
 * 3. [X] Show initial AI response above editor with buttons for "Edit myself" and "Rewrite with AI"
 *    - [X] Remove overlay after initial response
 * 4. [X] If "Edit myself" is clicked:
 *    - [X] Display Feedback above initial editor (dismissable)
 * 5. [ ] If "Rewrite with AI" is clicked:
 *    - [X] Hide original editor and show split display
 *    - [X] Display original text highlighting changed text on left display
 *    - [ ] Update right editor with rewritten text and accept / reject buttons for each change
 * 6. [ ] If accept is clicked, apply changes to original editor
 */

import { Plugin } from 'ckeditor5/src/core';
import { ButtonView, Dialog, View } from 'ckeditor5/src/ui';
import { diff, diffToChanges } from 'ckeditor5/src/utils';
import { type DialogDefinition } from "@ckeditor/ckeditor5-ui/src/dialog/dialog";
import { type TemplateDefinition } from "@ckeditor/ckeditor5-ui/src/template"
import type Node from "@ckeditor/ckeditor5-engine/src/model/node";
import { cloneDeep } from 'lodash-es';
import DiffValueAi from './diff-value';

// @ts-ignore
import svgIcon from '../icons/sparkle.svg';

function createEditorContainers(editorElement: HTMLElement | null) {
  // Create the container for the editors
  const editorContainer = document.createElement('div');
  editorContainer.className = 'ai-editors-container';

  // Create containers for each new editor
  const leftContainer = document.createElement('div');
  leftContainer.className = 'ai-left';
  const rightContainer = document.createElement('div');
  rightContainer.className = 'ai-right';

  // Assemble the containers
  editorContainer.appendChild(leftContainer);
  editorContainer.appendChild(rightContainer);

  // Add container after the main editor
  editorElement?.parentNode?.insertBefore(editorContainer, editorElement.nextSibling);

  return {
    mainContainer: editorContainer,
    leftContainer,
    rightContainer
  };
}

export default class TextTone extends Plugin {
  /**
   * @inheritdoc
   */
  static get requires() {
    return [Dialog, DiffValueAi];
  }

  /**
   * @inheritdoc
   */
  static get pluginName() {
    return 'TextTone';
  }

  /**
   * @inheritdoc
   */
  init() {
    const editor = this.editor;
    const model = editor.model;

    editor.ui.componentFactory.add('text-tone', locale => {
      const mainButton = new ButtonView(locale);

      const enableClaude = drupalSettings.claude.enableAi ?? false;
      const buttonLabel = enableClaude ? Drupal.t('Change text tone') : Drupal.t('AI currently unavailable');
      mainButton.set({
        label: buttonLabel,
        class: 'button-text-tone-ai',
        icon: svgIcon,
        tooltip: !enableClaude,
        isEnabled: enableClaude,
        withText: enableClaude,
      });

      mainButton.on('execute', async () => {
        // Get the editor element
        const editorElement = editor.ui.getEditableElement();
        if (!editorElement) return;

        // Add the overlay to the editor.
        const overlay = document.createElement('div');
        overlay.className = 'ck-editor__overlay';

        // Create cancel button
        const cancelButton = document.createElement('button');
        cancelButton.className = 'ck-editor__overlay-cancel';
        cancelButton.innerHTML = '×';
        cancelButton.title = 'Cancel';

        // Add loading content
        const loadingContent = document.createElement('div');
        loadingContent.className = 'ck-editor__overlay-content';
        loadingContent.innerHTML = '<span class="magic-text">Applying Magic </span><div class="sparkles"><span>✨</span><span>✨</span><span>✨</span></div>';

        // Add cancel functionality
        cancelButton.addEventListener('click', () => {
          removeOverlay();
          // Abort the fetch request if possible
          controller.abort();
        });

        overlay.appendChild(cancelButton);
        overlay.appendChild(loadingContent);
        editorElement?.parentNode?.insertBefore(overlay, editorElement.nextSibling);

        const removeOverlay = () => {
          const overlayElement = editorElement?.parentNode?.querySelector('.ck-editor__overlay');
          if (overlayElement) {
            overlayElement.remove();
          }
        };

        const jsonToSend = {
          data: editor.getData(),
          nodeType: drupalSettings.claude.nodeType ?? '',
        };

        // Create abort controller for the fetch request
        const controller = new AbortController();

        // First we send the text to the ai as early as possible.
        const ajaxCall = fetch('/numiko_ai/tone', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(jsonToSend),
          signal: controller.signal
        });

        // Get the dialog plugin.
        const dialogue = editor.plugins.get(Dialog);

        // Create objects with common properties that we will merge with any more specific properties.
        const basicDialogProperties: DialogDefinition = {
          isModal: true,
          id: 'text-tone-dialog',
          hasCloseButton: false,
        };
        const basicTemplateProperties: TemplateDefinition = {
          tag: 'div',
          attributes: {
            class: 'ai-template'
          },
        };

        // A closure used to make getting rid of the dialog easy.
        const hideDialogue = () => dialogue.hide();


        const mapListElements = (text: string) => {
          // We do the conversion in a two step process to prevent in word
          // hyphens getting matched.
          const regex = /@([^@]*)/gm;
          const listElements: View[] = [];
          let replacedText = text.replace(/\n- /gm, '@');

          for (const match of replacedText.matchAll(regex)) {
            const innerView = new View(locale);
            innerView.setTemplate({
              ...basicTemplateProperties,
              tag: 'li',
              children: [match[1]],
            });

            listElements.push(innerView);
          }

          const listView = new View(locale);
          listView.setTemplate({
            ...basicTemplateProperties,
            tag: 'ul',
            children: listElements,
          });

          const outerView = new View(locale);
          outerView.setTemplate({
            ...basicTemplateProperties,
            children: [replacedText.replace(regex, '').trim(), listView],
          });

          return outerView;
        }

        const createRenderedView = (textVec: string[]) => {
          // Join everything into a single text and render it as a HTML fragment.
          const joinedTexts = textVec.join('');
          const docFragment = document.createDocumentFragment();
          const doc = document.createElement('div')
          doc.innerHTML = joinedTexts;
          docFragment.appendChild(doc);

          const renderedView = new View(locale);
          renderedView.setTemplate({
            ...basicTemplateProperties,
            children: docFragment.children,
          });

          renderedView.render();
          return renderedView.element?.children[0]?.innerHTML ?? '';
        }

        // New work
        const extractSquareBrackets = (text: string) => {
          const regex = /\s*\[([^\]]+)\]\s*/gm;
          const notes: string[][] = [];

          for (const match of text.matchAll(regex)) {
            notes.push([match[1]]);
          }

          const cleanText = text.replace(regex, '');
          return [cleanText, notes] as const;
        };

        const parseHtmlNode = (html: string) => {
          const nodes = [];
          let currentIndex = 0;

          while (currentIndex < html.length) {
            const tagStart = html.indexOf('<', currentIndex);
            if (tagStart === -1) break;

            const tagEnd = html.indexOf('>', tagStart);
            if (tagEnd === -1) break;

            const openTag = html.slice(tagStart, tagEnd + 1);
            const tagMatch = openTag.match(/<\/?([a-zA-Z0-9]+)/);
            if (!tagMatch) break;

            const tagName = tagMatch[1];
            const closeTagStart = html.indexOf(`</${tagName}>`, tagEnd);
            if (closeTagStart === -1) break;

            const content = html.slice(tagEnd + 1, closeTagStart);
            const closeTag = `</${tagName}>`;

            nodes.push(
              { type: 'openTag', content: openTag },
              { type: 'text', content: content },
              { type: 'closeTag', content: closeTag }
            );

            currentIndex = closeTagStart + closeTag.length;
          }

          return nodes;
        };

        const diffHtml = (oldHtml: string, newHtml: string) => {
          const oldTokens = parseHtmlNode(oldHtml);
          const newTokens = parseHtmlNode(newHtml);
          const result = [];
          let i = 0, j = 0;

          while (i < oldTokens.length || j < newTokens.length) {
            const a = oldTokens[i];
            const b = newTokens[j];

            if (i < oldTokens.length && j < newTokens.length) {
              if (a.type === b.type && a.content === b.content) {
                result.push({ ...a, diffType: 'equal' });
                i++; j++;
              } else if (a.type === b.type && ['openTag', 'closeTag'].includes(a.type)) {
                result.push({ ...a, diffType: 'equal' });
                i++; j++;
              } else if (a.type === 'text' && b.type === 'text') {
                result.push({ ...b, diffType: 'insert' });
                result.push({ ...a, diffType: 'delete' });
                i++; j++;
              } else {
                result.push({ ...b, diffType: 'insert' });
                j++;
              }
            } else if (j < newTokens.length) {
              result.push({ ...newTokens[j], diffType: 'insert' });
              j++;
            } else {
              result.push({ ...oldTokens[i], diffType: 'delete' });
              i++;
            }
          }
          return result;
        };

        const renderDiffHtml = (changes: any[], showType: 'delete' | 'insert') => {
          return changes
            .map(change => {
              const showChange = change.diffType === showType || change.diffType === 'equal';
              if (!showChange) return '';

              if (change.type === 'text') {
                if (change.diffType === showType) {
                  return `<span class="ai-${showType === 'delete' ? 'deleted' : 'inserted'}">${change.content}</span>`;
                } else if (change.diffType === 'equal') {
                  return change.content;
                }
              }

              return change.content;
            })
            .join('');
        };

        const run = (aiText: string) => {
          // Function to check if all changes have been handled
          let updateAcceptAllButton: () => void;

          const newTextFragment = document.createDocumentFragment();
          const newDoc = document.createElement('div')
          newDoc.innerHTML = aiText;
          newTextFragment.appendChild(newDoc);
          const newT = newTextFragment.querySelectorAll('p');

          const baseTextFragment = document.createDocumentFragment();
          const baseDoc = document.createElement('div')
          baseDoc.innerHTML = editor.getData();
          baseTextFragment.appendChild(baseDoc);
          const base = baseTextFragment.querySelectorAll('p');

          // Create container for paragraphs with controls
          const paragraphContainer = document.createElement('div');
          paragraphContainer.className = 'ai-paragraph-container';

          function* paired(baseChildren: NodeListOf<HTMLParagraphElement>, newChildren: NodeListOf<HTMLParagraphElement>) {
            let counter = 0;
            let baseChild = baseChildren.item(0);
            let newChild = newChildren.item(0);
            while (baseChild != null && newChild != null) {
              yield [baseChild, newChild, counter] as [HTMLParagraphElement, HTMLParagraphElement, number];
              counter++;
              baseChild = baseChildren.item(counter);
              newChild = newChildren.item(counter);
            }
          };

          // Create containers for both sides
          const leftContainer = document.querySelector('.ai-left');
          const rightContainer = document.querySelector('.ai-right');

          if (leftContainer && rightContainer) {
            leftContainer.innerHTML = '';
            rightContainer.innerHTML = '';

            // Create arrays to store paragraph elements for height matching
            const leftParagraphs: HTMLElement[] = [];
            const rightParagraphs: HTMLElement[] = [];

            outer: for (const [baseChild, newChild, index] of paired(base, newT)) {
              // Create left paragraph
              const leftParagraph = document.createElement('div');
              leftParagraph.className = 'ai-paragraph-content';
              leftParagraph.innerHTML = baseChild.outerHTML;
              leftContainer.appendChild(leftParagraph);
              leftParagraphs.push(leftParagraph);

              // Create right paragraph wrapper and content
              const paragraphWrapper = document.createElement('div');
              paragraphWrapper.className = 'ai-paragraph-wrapper';

              // Clean the brackets from the new HTML before diffing
              const [cleanNewHtml, notes] = extractSquareBrackets(newChild.outerHTML);
              const changes = diffHtml(baseChild.outerHTML, cleanNewHtml);

              // Add the paragraph content with diffs
              const paragraphContent = document.createElement('div');
              paragraphContent.className = 'ai-paragraph-content';
              paragraphContent.innerHTML = cleanNewHtml;

              // Add notes if they exist
              if (notes.length > 0) {
                // Create a container for the paragraph and its notes
                const contentContainer = document.createElement('div');
                contentContainer.className = 'ai-content-container';

                // Add the paragraph content first
                contentContainer.appendChild(paragraphContent);

                // Add footnotes below
                const notesElement = document.createElement('div');
                notesElement.className = 'ai-paragraph-footnotes';
                notes.forEach((note, index) => {
                  const noteItem = document.createElement('div');
                  noteItem.className = 'ai-footnote-item';
                  noteItem.innerHTML = `<span class="ai-footnote-label">Changes made:</span> ${note[0]}`;
                  notesElement.appendChild(noteItem);
                });
                contentContainer.appendChild(notesElement);

                // Add the content container to the wrapper
                paragraphWrapper.appendChild(contentContainer);
              } else {
                // If no notes, just add the paragraph content directly
                paragraphWrapper.appendChild(paragraphContent);
              }

              // Track changes status
              paragraphWrapper.dataset.status = 'pending';

              // Only add controls if there are changes
              if (changes.length > 0) {
                const controlsWrapper = document.createElement('div');
                controlsWrapper.className = 'ai-paragraph-controls';

                const editButton = document.createElement('button');
                editButton.className = 'ai-edit-button';
                editButton.innerHTML = '✎';
                editButton.title = 'Edit manually';

                const acceptButton = document.createElement('button');
                acceptButton.className = 'ai-accept-button';
                acceptButton.innerHTML = '✓';
                acceptButton.title = 'Accept changes';

                const rejectButton = document.createElement('button');
                rejectButton.className = 'ai-reject-button';
                rejectButton.innerHTML = '✕';
                rejectButton.title = 'Reject changes';

                editButton.addEventListener('click', (event) => {
                  event.preventDefault();
                  // Make the paragraph content editable
                  paragraphContent.contentEditable = 'true';
                  paragraphContent.classList.add('editing');

                  // Hide accept/reject buttons during editing
                  acceptButton.style.display = 'none';
                  rejectButton.style.display = 'none';
                  editButton.style.display = 'none';

                  // Add done and cancel editing buttons
                  const doneButton = document.createElement('button');
                  doneButton.className = 'ai-done-editing';
                  doneButton.innerHTML = '✓';
                  doneButton.title = 'Done editing';

                  const cancelEditButton = document.createElement('button');
                  cancelEditButton.className = 'ai-cancel-editing';
                  cancelEditButton.innerHTML = '✕';
                  cancelEditButton.title = 'Cancel editing';

                  const finishEditing = () => {
                    paragraphContent.contentEditable = 'false';
                    paragraphContent.classList.remove('editing');
                    doneButton.remove();
                    cancelEditButton.remove();
                    acceptButton.style.display = '';
                    rejectButton.style.display = '';
                    editButton.style.display = '';

                  };

                  doneButton.addEventListener('click', (event) => {
                    event.preventDefault();
                    finishEditing();
                  });

                  cancelEditButton.addEventListener('click', (event) => {
                    event.preventDefault();
                    paragraphContent.innerHTML = renderDiffHtml(changes, 'insert'); // Restore content before editing
                    finishEditing();
                  });

                  controlsWrapper.insertBefore(cancelEditButton, editButton);
                  controlsWrapper.insertBefore(doneButton, editButton);
                });

                // Track changes status
                paragraphWrapper.dataset.status = 'pending';

                acceptButton.addEventListener('click', (event) => {
                  event.preventDefault();
                  paragraphWrapper.dataset.status = 'accepted';
                  // Replace the original paragraph with the new one, ensuring no brackets
                  const originalParagraphs = editor.editing.view.getDomRoot()?.querySelectorAll('p');
                  if (originalParagraphs && originalParagraphs[index]) {
                    originalParagraphs[index].innerHTML = cleanNewHtml;
                  }
                  // Remove the controls after accepting
                  controlsWrapper.remove();
                  updateAcceptAllButton();
                });

                rejectButton.addEventListener('click', (event) => {
                  event.preventDefault();
                  paragraphWrapper.dataset.status = 'rejected';
                  // Restore original content
                  paragraphContent.innerHTML = renderDiffHtml(changes, 'delete');
                  // Remove the controls after rejecting
                  controlsWrapper.remove();
                  updateAcceptAllButton();
                });

                controlsWrapper.appendChild(editButton);
                controlsWrapper.appendChild(acceptButton);
                controlsWrapper.appendChild(rejectButton);
                paragraphWrapper.appendChild(controlsWrapper);
              }

              paragraphContainer.appendChild(paragraphWrapper);
              rightParagraphs.push(paragraphWrapper);

              // After both sides are created, match heights
              requestAnimationFrame(() => {
                const leftHeight = leftParagraph.offsetHeight;
                const rightHeight = paragraphWrapper.offsetHeight;
                const maxHeight = Math.max(leftHeight, rightHeight);
                leftParagraph.style.minHeight = `${maxHeight}px`;
                paragraphWrapper.style.minHeight = `${maxHeight}px`;
              });
            }

            // Add final controls to right container
            rightContainer.innerHTML = '';
            rightContainer.appendChild(paragraphContainer);

            // Add final control buttons container
            const finalControls = document.createElement('div');
            finalControls.className = 'ai-final-controls';

            // Declare acceptAllButton at a higher scope
            const acceptAllButton = document.createElement('button');
            acceptAllButton.className = 'ai-accept-all-button';
            acceptAllButton.innerHTML = Drupal.t('Accept All Changes');
            acceptAllButton.disabled = true; // Start disabled

            // Add function to check if all changes have been handled
            updateAcceptAllButton = () => {
              const pendingChanges = paragraphContainer.querySelectorAll('[data-status="pending"]');
              acceptAllButton.disabled = pendingChanges.length > 0;
              acceptAllButton.title = pendingChanges.length > 0 ?
                'Please accept or reject all changes first' :
                'Accept all changes';
            };

            acceptAllButton.addEventListener('click', () => {
              // Get only the paragraph content without controls and notes
              const paragraphs = rightContainer.querySelectorAll('.ai-paragraph-content');
              const cleanContent = Array.from(paragraphs)
                .map(p => p.innerHTML)
                .join('');
              editor.setData(cleanContent);
              // Remove the split view
              const editorContainer = document.querySelector('.ai-editors-container');
              editorContainer?.remove();
              // Show the main CKEditor box
              const mainEditor = document.querySelector('.ck-editor__main');
              const editorContent = mainEditor?.querySelector('.ck-content') as HTMLElement;
              if (editorContent) {
                editorContent.classList.remove('ai-editor-hidden');
              }
            });

            const cancelButton = document.createElement('button');
            cancelButton.className = 'ai-cancel-all-button';
            cancelButton.innerHTML = Drupal.t('Cancel');
            cancelButton.addEventListener('click', () => {
              // Just remove the split view - original content remains unchanged
              const editorContainer = document.querySelector('.ai-editors-container');
              editorContainer?.remove();
              // Show the main CKEditor box
              const mainEditor = document.querySelector('.ck-editor__main');
              const editorContent = mainEditor?.querySelector('.ck-content') as HTMLElement;
              if (editorContent) {
                editorContent.classList.remove('ai-editor-hidden');
              }
            });

            finalControls.appendChild(cancelButton);
            finalControls.appendChild(acceptAllButton);
            rightContainer.appendChild(finalControls);

            // Initial check for Accept All button
            updateAcceptAllButton();
          }
        }

        // End New Work

        // Wait for the AI response
        const response = await ajaxCall;
        if (response.ok) {
          const summaryText: string = (await response.json()).summary;
          // Seperate the two texts.
          let [feedbackText, rewrittenText] = summaryText.split('[[cut]]');
          feedbackText = feedbackText.trim();
          rewrittenText = rewrittenText.trim();

          const summaryView = new View(locale);
          summaryView.setTemplate({
            ...basicTemplateProperties,
            children: [mapListElements(feedbackText)],
          });

          // Create main container
          const divAboveMainEditor = document.createElement('div');
          divAboveMainEditor.className = 'ai-above-main-editor';

          // Create feedback content container
          const feedbackContent = document.createElement('div');
          feedbackContent.className = 'ai-feedback-content';

          // Create close button
          const closeButton = document.createElement('button');
          closeButton.className = 'ai-close-button';
          closeButton.textContent = '×';
          closeButton.addEventListener('click', () => {
            divAboveMainEditor.remove();
          });

          // Create feedback text
          const feedbackTextNode = document.createTextNode(feedbackText);

          // Create action buttons container first
          const actionButtons = document.createElement('div');
          actionButtons.className = 'ai-action-buttons';

          // Add everything to the container
          feedbackContent.appendChild(closeButton);
          feedbackContent.appendChild(feedbackTextNode);
          feedbackContent.appendChild(actionButtons);

          divAboveMainEditor.appendChild(feedbackContent);
          editorElement?.parentNode?.insertBefore(divAboveMainEditor, editorElement);

          // Remove the overlay after showing the feedback text
          removeOverlay();

          // Add the "Edit myself" button to the div
          const editMyselfButton = document.createElement('button');
          editMyselfButton.className = 'ai-action-button';
          editMyselfButton.innerHTML = Drupal.t('I\'ll edit it myself');
          actionButtons.appendChild(editMyselfButton);

          // Add the "Rewrite with AI" button to the div
          const rewriteWithAiButton = document.createElement('button');
          rewriteWithAiButton.className = 'ai-action-button';
          rewriteWithAiButton.innerHTML = Drupal.t('Rewrite with AI');
          actionButtons.appendChild(rewriteWithAiButton);

          // Add event listeners to buttons
          editMyselfButton.addEventListener('click', () => {
            // Remove the buttons
            actionButtons.remove();
          });

          rewriteWithAiButton.addEventListener('click', (event) => {
            event.preventDefault();
            const prevData = editor.getData();

            // Hide the main CKEditor box
            const mainEditor = document.querySelector('.ck-editor__main');
            const editorContent = mainEditor?.querySelector('.ck-content') as HTMLElement;
            if (editorContent) {
              editorContent.classList.add('ai-editor-hidden');
            }

            // Create the editor containers
            const { mainContainer, leftContainer, rightContainer } = createEditorContainers(editorElement);
            leftContainer.innerHTML = prevData;
            rightContainer.innerHTML = rewrittenText;

            run(rewrittenText);

            // Remove just the action buttons instead of the entire feedback container
            actionButtons.remove();
          });
        } else {
          const errorView = new View(locale);
          errorView.setTemplate({
            ...basicTemplateProperties,
            children: [await response.text()],
          });

          dialogue.show({
            ...basicDialogProperties,
            title: Drupal.t('An errror has occured:'),
            content: errorView,
            actionButtons: [{
              label: Drupal.t('Ok'),
              withText: true,
              class: 'button-text-tone-red',
              onExecute: hideDialogue,
            }],
          });

          // Remove the overlay after showing the error dialogue
          removeOverlay();
        }
      });

      // Return the button we've just built so it can be used on the tooltip.
      return mainButton;
    });
  }
}



// Add type defintions for Drupal and drupalSettings.
declare const Drupal: {
  t: (text: string) => string
}

declare const drupalSettings: {
  claude: {
    readonly enableAi?: boolean,
    readonly nodeType?: string,
  }
}
