import { Plugin } from 'ckeditor5/src/core';
import { ButtonView, Dialog, SpinnerView, View } from 'ckeditor5/src/ui';
import { type DialogDefinition } from "@ckeditor/ckeditor5-ui/src/dialog/dialog";
import { type TemplateDefinition } from "@ckeditor/ckeditor5-ui/src/template"
// @ts-ignore
import svgIcon from '../icons/chart-line-solid.svg';

export default class TextTone extends Plugin {
  /**
   * @inheritdoc
   */
  static get requires() {
    return [Dialog];
  }

  /**
   * @inheritdoc
   */
  static get pluginName() {
    return 'TextTone';
  }

  /**
   * @inheritdoc
   */
  init() {
    this.editor.ui.componentFactory.add('text-tone', locale => {
      const mainButton = new ButtonView(locale);

      const enableClaude = drupalSettings.claude.enableAi ?? false;
      const buttonLabel = enableClaude ? Drupal.t('Check the tone') : Drupal.t('Claude is not enabled for this content type');
      mainButton.set({
        label: buttonLabel,
        icon: svgIcon,
        tooltip: true,
        isEnabled: enableClaude,
        withText: true,
      });

      mainButton.on('execute', async () => {

        const jsonToSend = {
          data: this.editor.getData(),
          nodeType: drupalSettings.claude.nodeType ?? '',
        };

        // First we send the text to the ai as early as possible.
        const ajaxCall = fetch('/numiko_ai/tone', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(jsonToSend),
        });

        // Get the dialog plugin.
        const dialogue = this.editor.plugins.get(Dialog);

        // Create objects with common properties that we will merge with any more specific properties.
        const basicDialogProperties: DialogDefinition = {
          isModal: true,
          id: 'text-tone-dialog',
          hasCloseButton: false,
        };
        const basicTemplateProperties: TemplateDefinition = {
          tag: 'div',
          attributes: {
            class: 'ai-template'
          },
        };

        // A closure used to make getting rid of the dialog easy.
        const hideDialogue = () => dialogue.hide();

        const mapListElements = (text: string) => {
          // We do the conversion in a two step process to prevent in word
          // hyphens getting matched.
          const regex = /@([^@]*)/gm;
          const listElements = [];
          let replacedText = text.replace(/\n- /gm, '@');

          for (const match of replacedText.matchAll(regex)) {
            const innerView = new View(locale);
            innerView.setTemplate({
              ...basicTemplateProperties,
              tag: 'li',
              children: [match[1]],
            });

            listElements.push(innerView);
          }

          const listView = new View(locale);
          listView.setTemplate({
            ...basicTemplateProperties,
            tag: 'ul',
            children: listElements,
          });

          const outerView = new View(locale);
          outerView.setTemplate({
            ...basicTemplateProperties,
            children: [replacedText.replace(regex, '').trim(), listView],
          });

          return outerView;
        }

        const mapSquareBracketsToSpan = (text: string) => {
          const regex = /\[([^\]]+)\]/gm;
          const viewNotes = [];

          // Extract the text inside [] to spans, keeping any HTML tags
          for (const match of text.matchAll(regex)) {
            const innerView = new View(locale);
            innerView.setTemplate({
              tag: 'span',
              attributes: {
                id: 'ai-explaination',
              },
              children: [match[1]],
            });
            innerView.render()
            viewNotes.push(innerView.element?.outerHTML);
          }

          // We've extracted the inner [] data so replace them with another character
          const regexText = text.replace(regex, '@');
          const splitText = regexText.split('@');
          const final = splitText[splitText.length - 1];
          const texts = [];

          // Reform the string together
          viewNotes.map((innerText, index) => {
            const otherText = splitText[index];
            texts.push(otherText);
            texts.push(innerText);
          });
          texts.push(final);
          const joinedTexts = texts.join('');
          const docFragment = document.createDocumentFragment();
          const doc = document.createElement('span')
          doc.innerHTML = joinedTexts;
          for (const p of doc.children) {
            (p as HTMLElement).style.whiteSpace = 'normal';
          }
          docFragment.appendChild(doc);

          const renderedView = new View(locale);
          renderedView.setTemplate({
            ...basicTemplateProperties,
            children: docFragment.children,
          });

          const removedText = text.replace(regex, '');

          return [renderedView, removedText];
        };

        // Now show a waiting model with a spinner.
        const spinner = new SpinnerView();
        // TODO: big spinner
        spinner.set({
          isVisible: true
        });

        const waitingView = new View(locale);
        // TODO: centre this div
        waitingView.setTemplate({
          ...basicTemplateProperties,
          children: [spinner],
        });

        dialogue.show({
          ...basicDialogProperties,
          content: waitingView,
          title: Drupal.t('Please wait while we review your copy'),
        });

        // Then we wait till the text has been returned. Then based on the response we show the
        // result to the user.
        const response = await ajaxCall;
        if (response.ok) {
          const summaryText: string = (await response.json()).summary;
          // Seperate the two texts.
          const [feedbackText, rewrittenText] = summaryText.split('[[cut]]');

          const [viewWithNotes, textNoNotes] = mapSquareBracketsToSpan(rewrittenText);

          const rewrittenView = new View(locale);
          rewrittenView.setTemplate({
            ...basicTemplateProperties,
            children: [viewWithNotes],
          });

          const summaryView = new View(locale);
          summaryView.setTemplate({
            ...basicTemplateProperties,
            children: [mapListElements(feedbackText)],
          });

          dialogue.show({
            ...basicDialogProperties,
            title: Drupal.t('The AI returned the following recommendations:'),
            content: [summaryView, rewrittenView],
            actionButtons: [
              {
                label: Drupal.t('I\'ll edit it myself'),
                class: 'button-text-tone-green',
                withText: true,
                onExecute: () => {
                  hideDialogue();
                  dialogue.show({
                    title: Drupal.t('The AI returned the following recommendations:'),
                    id: 'text-tone-dialog',
                    content: summaryView,
                  });
                }
              },
              {
                label: Drupal.t('Ask Claude to rewrite it'),
                class: 'button-text-tone-red',
                withText: true,
                onExecute: () => {
                  hideDialogue();
                  this.editor.setData('<p>' + textNoNotes + '</p>');
                },
              }
            ],
          })
        } else {
          const errorView = new View(locale);
          errorView.setTemplate({
            ...basicTemplateProperties,
            children: [await response.text()],
          });

          dialogue.show({
            ...basicDialogProperties,
            title: Drupal.t('An errror occured:'),
            content: errorView,
            actionButtons: [{
              label: Drupal.t('Ok'),
              withText: true,
              class: 'button-text-tone-red',
              onExecute: hideDialogue,
            }],
          });
        }
      });

      // Return the button we've just built so it can be used on the tooltip.
      return mainButton;
    });
  }
}



// Add type defintions for Drupal and drupalSettings.
declare const Drupal: {
  t: (text: string) => string
}

declare const drupalSettings: {
  claude: {
    readonly enableAi?: boolean,
    readonly nodeType?: string,
  }
}
