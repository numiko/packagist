# Claude AI integration

## New project setup:

### 1. Add the following line to `.env.example` and as a platform environment variable

```
CLAUDE_API_KEY=
```

### 2. Add the following line to `settings.php`

```php
/**
 * Claude AI API key.
 */
$config['ai_writing_assistant.settings']['api_key'] = getenv('CLAUDE_API_KEY');
```
### 3. Install the module

Check the values in `/admin/config/search/numiko_ai` are up to date

### 4. Paste the following into the project README

Paste the following into the project README:
----
### Claude AI integration

To use Claude AI integration set `CLAUDE_API_KEY` in the `.env` file in the root of the project.

The value for this can be found in 1Password under "Claude API Key (used with LRF)".
