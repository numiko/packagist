import { Plugin } from 'ckeditor5/src/core';
import { ButtonView, Dialog, View } from 'ckeditor5/src/ui';
import { type DialogDefinition } from "@ckeditor/ckeditor5-ui/src/dialog/dialog";
import { type TemplateDefinition } from "@ckeditor/ckeditor5-ui/src/template"
import type Node from "@ckeditor/ckeditor5-engine/src/model/node";
import { cloneDeep } from 'lodash-es';
import DiffValueAi from './diff-value';

// @ts-ignore
import svgIcon from '../icons/sparkle.svg';

export default class TextTone extends Plugin {
  /**
   * @inheritdoc
   */
  static get requires() {
    return [Dialog];
  }

  /**
   * @inheritdoc
   */
  static get pluginName() {
    return 'TextTone';
  }

  /**
   * @inheritdoc
   */
  init() {
    const editor = this.editor;
    const model = editor.model;

    editor.ui.componentFactory.add('text-tone', locale => {
      const mainButton = new ButtonView(locale);

      const enableClaude = drupalSettings.claude.enableAi ?? false;
      const buttonLabel = enableClaude ? Drupal.t('Change text tone') : Drupal.t('Claude is not enabled for this content type');
      mainButton.set({
        label: buttonLabel,
        class: 'button-text-tone-ai',
        icon: svgIcon,
        tooltip: !enableClaude,
        isEnabled: enableClaude,
        withText: enableClaude,
      });

      mainButton.on('execute', async () => {

        // Add the overlay to the editor.
        const editorElement = this.editor.ui.getEditableElement();
        const overlay = document.createElement('div');
        overlay.className = 'ck-editor__overlay';
        overlay.innerHTML = '<span class="magic-text"></span><div class="sparkles"><span>✨</span><span>✨</span><span>✨</span></div>';
        editorElement?.parentNode?.insertBefore(overlay, editorElement.nextSibling);

        const removeOverlay = () => {
          const overlayElement = editorElement?.parentNode?.querySelector('.ck-editor__overlay');
          if (overlayElement) {
            overlayElement.remove();
          }
        };

        const jsonToSend = {
          data: this.editor.getData(),
          nodeType: drupalSettings.claude.nodeType ?? '',
        };

        // First we send the text to the ai as early as possible.
        const ajaxCall = fetch('/numiko_ai/tone', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(jsonToSend),
        });

        // Get the dialog plugin.
        const dialogue = this.editor.plugins.get(Dialog);

        // Create objects with common properties that we will merge with any more specific properties.
        const basicDialogProperties: DialogDefinition = {
          isModal: true,
          id: 'text-tone-dialog',
          hasCloseButton: false,
        };
        const basicTemplateProperties: TemplateDefinition = {
          tag: 'div',
          attributes: {
            class: 'ai-template'
          },
        };

        // A closure used to make getting rid of the dialog easy.
        const hideDialogue = () => dialogue.hide();

        const diffAi = (base: string, newText: string) => {
          // This returns raw text changes, we need node data to get data from a range.
          // Maybe we should render both into a view and compare per range.
          const doc = cloneDeep(this.editor.model.document);
          const baseChildren = doc.getRoot()!!.getChildren();
          editor.setData(newText);
          const newChildren = model.document.getRoot()!!.getChildren();
          function* paired(baseChildren: IterableIterator<Node>, newChildren: IterableIterator<Node>) {
            let baseChild = baseChildren.next();
            let newChild = newChildren.next();
            while (!(baseChild.done || newChild.done)) {
              yield [baseChild, newChild];

              baseChild = baseChildren.next();
              newChild = newChildren.next();
            }
          };
          for (const [baseChildResult, newChildResult] of paired(baseChildren, newChildren)) {
            const recurseInto = (element: Node) => {
              if (element.is('$text')) {
                return element;
              } else if (element.is('element')) {
                for (const child of element.getChildren()) {
                  return recurseInto(child);
                }
              } else {
                return null;
              }
            };

            const baseChild = recurseInto(baseChildResult.value);
            const newChild = recurseInto(newChildResult.value);

            if (!baseChild || !newChild) {
              continue;
            }

            const changes = diffToChanges(diff(baseChild.data, newChild.data), newChild.data);
            changes.forEach(change => {
              const pos = model.createPositionAt(newChild, change.index);
              let endPos = null;
              if (change.type == 'insert') {
                endPos = model.createPositionAt(newChild, change.index + change.values.length);
              } else /* if (change.type == 'delete') */ {
                endPos = model.createPositionAt(newChild, change.index + change.howMany);
              }
              const range = model.createRange(pos, endPos);
              model.change(writer => writer.setAttribute('diffValue', change.type, range));
            });
          }
        }

        const mapListElements = (text: string) => {
          // We do the conversion in a two step process to prevent in word
          // hyphens getting matched.
          const regex = /@([^@]*)/gm;
          const listElements = [];
          let replacedText = text.replace(/\n- /gm, '@');

          for (const match of replacedText.matchAll(regex)) {
            const innerView = new View(locale);
            innerView.setTemplate({
              ...basicTemplateProperties,
              tag: 'li',
              children: [match[1]],
            });

            listElements.push(innerView);
          }

          const listView = new View(locale);
          listView.setTemplate({
            ...basicTemplateProperties,
            tag: 'ul',
            children: listElements,
          });

          const outerView = new View(locale);
          outerView.setTemplate({
            ...basicTemplateProperties,
            children: [replacedText.replace(regex, '').trim(), listView],
          });

          return outerView;
        }

        const createRenderedView = (textVec: string[]) => {
          // Join everything into a single text and render it as a HTML fragment.
          const joinedTexts = textVec.join('');
          const docFragment = document.createDocumentFragment();
          const doc = document.createElement('div')
          doc.innerHTML = joinedTexts;
          docFragment.appendChild(doc);

          const renderedView = new View(locale);
          renderedView.setTemplate({
            ...basicTemplateProperties,
            children: docFragment.children,
          });

          renderedView.render();
          return renderedView.element?.children[0]?.innerHTML ?? '';
        }

        const mapSquareBracketsToSpan = (text: string) => {
          const regex = /\[([^\]]+)\]/gm;
          const viewNotes = [];

          // Extract the text inside [] to spans, keeping any HTML tags.
          for (const match of text.matchAll(regex)) {
            const innerView = new View(locale);
            innerView.setTemplate({
              tag: 'span',
              attributes: {
                class: 'ai-explaination',
              },
              children: [match[1]],
            });
            innerView.render()
            viewNotes.push(innerView.element?.outerHTML);
          }

          // We've extracted the inner [] data so replace them with another character.
          const regexText = text.replace(regex, '@');
          const splitText = regexText.split('@');
          const final = splitText[splitText.length - 1];
          const textsWithNotes = [];

          // Reform the string together.
          viewNotes.map((innerText, index) => {
            const otherText = splitText[index];
            textsWithNotes.push(otherText);
            textsWithNotes.push(innerText);
          });
          textsWithNotes.push(final);

          // Create the text with and without notes
          const textWithNotesView = createRenderedView(textsWithNotes);
          const textNoNotesView = createRenderedView(splitText);

          return [textWithNotesView, textNoNotesView];
        };

        // Wait for the AI response
        const response = await ajaxCall;
        if (response.ok) {
          const summaryText: string = (await response.json()).summary;
          // Seperate the two texts.
          let [feedbackText, rewrittenText] = summaryText.split('[[cut]]');
          feedbackText = feedbackText.trim();
          rewrittenText = rewrittenText.trim();

          const summaryView = new View(locale);
          summaryView.setTemplate({
            ...basicTemplateProperties,
            children: [mapListElements(feedbackText)],
          });

          dialogue.show({
            ...basicDialogProperties,
            title: Drupal.t('The AI returned the following recommendations:'),
            content: [summaryView],
            actionButtons: [
              {
                label: Drupal.t('I\'ll edit it myself'),
                class: 'button-text-tone-green',
                withText: true,
                onExecute: () => {
                  hideDialogue();
                  removeOverlay();
                  dialogue.show({
                    title: Drupal.t('The AI returned the following recommendations:'),
                    id: 'text-tone-dialog',
                    content: summaryView,
                  });
                }
              },
              {
                label: Drupal.t('Rewrite with AI'),
                class: 'button-text-tone-red',
                withText: true,
                onExecute: () => {
                  hideDialogue();

                  const [HTMLWithNotes, HTMLNoNotes] = mapSquareBracketsToSpan(rewrittenText);
                  //diffAi(prevData, HTMLNoNotes);
                  editor.setData(HTMLWithNotes);

                  removeOverlay();
                },
              }
            ],
          })
        } else {
          const errorView = new View(locale);
          errorView.setTemplate({
            ...basicTemplateProperties,
            children: [await response.text()],
          });

          dialogue.show({
            ...basicDialogProperties,
            title: Drupal.t('An errror has occured:'),
            content: errorView,
            actionButtons: [{
              label: Drupal.t('Ok'),
              withText: true,
              class: 'button-text-tone-red',
              onExecute: hideDialogue,
            }],
          });

          // Remove the overlay after showing the error dialogue
          removeOverlay();
        }
      });

      // Return the button we've just built so it can be used on the tooltip.
      return mainButton;
    });
  }
}



// Add type defintions for Drupal and drupalSettings.
declare const Drupal: {
  t: (text: string) => string
}

declare const drupalSettings: {
  claude: {
    readonly enableAi?: boolean,
    readonly nodeType?: string,
  }
}
