<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant\Controller;

use Drupal\ai_writing_assistant\AiConfigKey;
use Drupal\ai_writing_assistant\Request\AnthropicApiRequest;
use Drupal\ai_writing_assistant\Request\RequestOptions;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use GuzzleHttp\Client;
use Psr\Log\LoggerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Receives text to summarise and then returns the response from the AI.
 */
class NumikoAIController implements ContainerInjectionInterface {
  /**
   * This modules config file.
   *
   * @var \Drupal\Core\Config\ImmutableConfig
   */
  protected ImmutableConfig $config;

  /**
   * The logger.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected LoggerInterface $logger;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * And the HTTP Client.
   *
   * @var \GuzzleHttp\Client
   */
  protected Client $httpClient;

  public function __construct(
    ConfigFactoryInterface $bigConfig,
    LoggerChannelFactoryInterface $bigLogger,
    EntityTypeManagerInterface $entityTypeManager,
    Client $http
  ) {
    $this->config = $bigConfig->get('ai_writing_assistant.settings');
    $this->logger = $bigLogger->get('numiko_ai');
    $this->entityTypeManager = $entityTypeManager;
    $this->httpClient = $http;
  }

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('config.factory'),
      $container->get('logger.factory'),
      $container->get('entity_type.manager'),
      $container->get('http_client')
    );
  }

  /**
   * The main processing class.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   Request from the client.
   *
   * @return \Psr\Http\Message\ResponseInterface
   *   Response to the client
   */
  public function getData(Request $request): Response {
    $makeErrRequest = fn(\Exception $error) => new Response($error->getMessage(), Response::HTTP_BAD_REQUEST, ['content-type' => 'text/plain']);
    $documentContent = json_decode($request->getContent(), TRUE);

    try {
      $options = $this->getConfigOptions($documentContent['nodeType']);
    }
    catch (\Exception $error) {
      return $makeErrRequest($error);
    }

    return AnthropicApiRequest::request($this->httpClient, $documentContent['data'], $options)
      ->then(
          fn($summary) => new JsonResponse(['summary' => $summary]),
          fn($error) => $makeErrRequest($error)
        )
      ->wait();
  }

  /**
   * Get the (non-secret) API options.
   *
   * @param string $nodeType
   *   The type of node this request is being sent from.
   *
   * @return \Drupal\ai_writing_assistant\Request\RequestOptions
   *   Config options.
   *
   * @throws \Exception
   */
  protected function getConfigOptions(string $nodeType): RequestOptions {
    if ($nodeType === '') {
      // @todo Should we do this or just use the default prompt?
      throw new \Exception('Not able to figure out the type of node this page is, please contact an administrator');
    }

    $aiSettings = $this->entityTypeManager
      ->getStorage('node_type')
      ->load($nodeType)
      ->getThirdPartySettings('ai_writing_assistant');

    $styleGuide = ($aiSettings[AiConfigKey::UseDefautPrompt->machine()] ?? FALSE) ?
      $this->getConfigElseThrow(AiConfigKey::StylePrompt) :
      $aiSettings[AiConfigKey::LocalStyleGuide->machine()];

    $mainPrompt = "Provide feedback as a bulleted list on the text below the asterick based on the following writing style guide. Make recommendations to what needs to be changed. Do not comment on anything that matches the writing style. Keep your response to less that 100 words.\r\nWriting Style Guide: $styleGuide *\r\nAlso return the provided text, rewritten to follow the writing style.\r\nProvide inline commentary on why you have changes parts of the text to match the writing style, wrapping your comments with [] brackets.\r\nSeparate the two sections with [[cut]]";

    return new RequestOptions(
      $this->getConfigElseThrow(AiConfigKey::ClaudeModel),
      $mainPrompt,
      $this->getConfigElseThrow(AiConfigKey::ApiKey),
    );
  }

  /**
   * Throw if a config value is empty. Otherwise return it.
   *
   * @param \Drupal\ai_writing_assistant\AiConfigKey $key
   *   The key to get from.
   *
   * @return string
   *   The config value
   *
   * @throws \Exception
   */
  private function getConfigElseThrow(AiConfigKey $key): string {
    $configValue = $this->config->get($key->machine());
    if ($configValue && $configValue != '') {
      return $configValue;
    }
    else {
      $prettyKey = (string) $key->human();
      throw new \Exception("$prettyKey is empty");
    }
  }

}
