/**
 * Plan:
 * 1. [X] Click "Check tone" button
 * 2. [X] Show overlay
 * 3. [X] Show initial AI response above editor with buttons for "Edit myself" and "Rewrite with AI"
 *    - [X] Remove overlay after initial response
 * 4. [X] If "Edit myself" is clicked:
 *    - [X] Display Feedback above initial editor (dismissable)
 * 5. [ ] If "Rewrite with AI" is clicked:
 *    - [X] Hide original editor and show split display
 *    - [X] Display original text highlighting changed text on left display
 *    - [ ] Update right editor with rewritten text and accept / reject buttons for each change
 * 6. [ ] If accept is clicked, apply changes to original editor
 */

import { Plugin } from 'ckeditor5/src/core';
import { ButtonView, Dialog, View } from 'ckeditor5/src/ui';
import { diff, diffToChanges } from 'ckeditor5/src/utils';
import { type DialogDefinition } from "@ckeditor/ckeditor5-ui/src/dialog/dialog";
import { type TemplateDefinition } from "@ckeditor/ckeditor5-ui/src/template"
import type Node from "@ckeditor/ckeditor5-engine/src/model/node";
import { cloneDeep } from 'lodash-es';
import DiffValueAi from './diff-value';

// @ts-ignore
import svgIcon from '../icons/sparkle.svg';

function createEditorContainers(editorElement: HTMLElement | null) {
    // Create the container for the editors
    const editorContainer = document.createElement('div');
    editorContainer.className = 'ai-editors-container';

    // Create containers for each new editor
    const leftContainer = document.createElement('div');
    leftContainer.className = 'ai-left';
    const rightContainer = document.createElement('div');
    rightContainer.className = 'ai-right';

    // Assemble the containers
    editorContainer.appendChild(leftContainer);
    editorContainer.appendChild(rightContainer);

    // Add container after the main editor
    editorElement?.parentNode?.insertBefore(editorContainer, editorElement.nextSibling);

    return {
        mainContainer: editorContainer,
        leftContainer,
        rightContainer
    };
}

export default class TextTone extends Plugin {
  /**
   * @inheritdoc
   */
  static get requires() {
    return [Dialog, DiffValueAi];
  }

  /**
   * @inheritdoc
   */
  static get pluginName() {
    return 'TextTone';
  }

  /**
   * @inheritdoc
   */
  init() {
    const editor = this.editor;
    const model = editor.model;

    editor.ui.componentFactory.add('text-tone', locale => {
      const mainButton = new ButtonView(locale);

      const enableClaude = drupalSettings.claude.enableAi ?? false;
      const buttonLabel = enableClaude ? Drupal.t('Change text tone') : Drupal.t('AI currently unavailable');
      mainButton.set({
        label: buttonLabel,
        class: 'button-text-tone-ai',
        icon: svgIcon,
        tooltip: !enableClaude,
        isEnabled: enableClaude,
        withText: enableClaude,
      });

      mainButton.on('execute', async () => {
        // Get the editor element
        const editorElement = editor.ui.getEditableElement();
        if (!editorElement) return;

        // Add the overlay to the editor.
        const overlay = document.createElement('div');
        overlay.className = 'ck-editor__overlay';
        overlay.innerHTML = '<span class="magic-text">Applying Magic </span><div class="sparkles"><span>✨</span><span>✨</span><span>✨</span></div>';
        editorElement?.parentNode?.insertBefore(overlay, editorElement.nextSibling);

        const removeOverlay = () => {
          const overlayElement = editorElement?.parentNode?.querySelector('.ck-editor__overlay');
          if (overlayElement) {
            overlayElement.remove();
          }
        };

        const jsonToSend = {
          data: editor.getData(),
          nodeType: drupalSettings.claude.nodeType ?? '',
        };

        // First we send the text to the ai as early as possible.
        const ajaxCall = fetch('/numiko_ai/tone', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(jsonToSend),
        });

        // Get the dialog plugin.
        const dialogue = editor.plugins.get(Dialog);

        // Create objects with common properties that we will merge with any more specific properties.
        const basicDialogProperties: DialogDefinition = {
          isModal: true,
          id: 'text-tone-dialog',
          hasCloseButton: false,
        };
        const basicTemplateProperties: TemplateDefinition = {
          tag: 'div',
          attributes: {
            class: 'ai-template'
          },
        };

        // A closure used to make getting rid of the dialog easy.
        const hideDialogue = () => dialogue.hide();

        const diffAi = (base: string, newText: string) => {
          // This returns raw text changes, we need node data to get data from a range.
          // Maybe we should render both into a view and compare per range.
          const doc = cloneDeep(this.editor.model.document);
          const baseChildren = doc.getRoot()!!.getChildren();
          editor.setData(newText);
          const newChildren = model.document.getRoot()!!.getChildren();
          function* paired(baseChildren: IterableIterator<Node>, newChildren: IterableIterator<Node>) {
            let baseChild = baseChildren.next();
            let newChild = newChildren.next();
            while (!(baseChild.done || newChild.done)) {
              yield [baseChild, newChild];

              baseChild = baseChildren.next();
              newChild = newChildren.next();
            }
          };
          for (const [baseChildResult, newChildResult] of paired(baseChildren, newChildren)) {
            const recurseInto = (element: Node) => {
              if (element.is('$text')) {
                return element;
              } else if (element.is('element')) {
                for (const child of element.getChildren()) {
                  return recurseInto(child);
                }
              } else {
                return null;
              }
            };

            const baseChild = recurseInto(baseChildResult.value);
            const newChild = recurseInto(newChildResult.value);

            if (!baseChild || !newChild) {
              continue;
            }

            const changes = diffToChanges(diff(baseChild.data, newChild.data), newChild.data);
            changes.forEach(change => {
              const pos = model.createPositionAt(newChild, change.index);
              let endPos = null;
              if (change.type == 'insert') {
                endPos = model.createPositionAt(newChild, change.index + change.values.length);
              } else /* if (change.type == 'delete') */ {
                endPos = model.createPositionAt(newChild, change.index + change.howMany);
              }
              const range = model.createRange(pos, endPos);
              model.change(writer => writer.setAttribute('diffValue', change.type, range));
            });
          }
        }

        const mapListElements = (text: string) => {
          // We do the conversion in a two step process to prevent in word
          // hyphens getting matched.
          const regex = /@([^@]*)/gm;
          const listElements: View[] = [];
          let replacedText = text.replace(/\n- /gm, '@');

          for (const match of replacedText.matchAll(regex)) {
            const innerView = new View(locale);
            innerView.setTemplate({
              ...basicTemplateProperties,
              tag: 'li',
              children: [match[1]],
            });

            listElements.push(innerView);
          }

          const listView = new View(locale);
          listView.setTemplate({
            ...basicTemplateProperties,
            tag: 'ul',
            children: listElements,
          });

          const outerView = new View(locale);
          outerView.setTemplate({
            ...basicTemplateProperties,
            children: [replacedText.replace(regex, '').trim(), listView],
          });

          return outerView;
        }

        const createRenderedView = (textVec: string[]) => {
          // Join everything into a single text and render it as a HTML fragment.
          const joinedTexts = textVec.join('');
          const docFragment = document.createDocumentFragment();
          const doc = document.createElement('div')
          doc.innerHTML = joinedTexts;
          docFragment.appendChild(doc);

          const renderedView = new View(locale);
          renderedView.setTemplate({
            ...basicTemplateProperties,
            children: docFragment.children,
          });

          renderedView.render();
          return renderedView.element?.children[0]?.innerHTML ?? '';
        }

        const mapSquareBracketsToSpan = (text: string) => {
          const regex = /\[([^\]]+)\]/gm;
          const viewNotes: string[] = [];

          // Extract the text inside [] to spans, keeping any HTML tags.
          for (const match of text.matchAll(regex)) {
            const innerView = new View(locale);
            innerView.setTemplate({
              tag: 'span',
              attributes: {
                class: 'ai-explaination',
              },
              children: [match[1]],
            });
            innerView.render()
            viewNotes.push(innerView.element?.outerHTML ?? '');
          }

          // We've extracted the inner [] data so replace them with another character.
          const regexText = text.replace(regex, '@');
          const splitText = regexText.split('@');
          const final = splitText[splitText.length - 1];
          const textsWithNotes: string[] = [];

          // Reform the string together.
          viewNotes.map((innerText, index) => {
            const otherText = splitText[index];
            textsWithNotes.push(otherText);
            textsWithNotes.push(innerText);
          });
          textsWithNotes.push(final);

          // Create the text with and without notes
          const textWithNotesView = createRenderedView(textsWithNotes);
          const textNoNotesView = createRenderedView(splitText);

          return [textWithNotesView, textNoNotesView];
        };

        // Wait for the AI response
        const response = await ajaxCall;
        if (response.ok) {
          const summaryText: string = (await response.json()).summary;
          // Seperate the two texts.
          let [feedbackText, rewrittenText] = summaryText.split('[[cut]]');
          feedbackText = feedbackText.trim();
          rewrittenText = rewrittenText.trim();

          const summaryView = new View(locale);
          summaryView.setTemplate({
            ...basicTemplateProperties,
            children: [mapListElements(feedbackText)],
          });

          // Create main container
          const divAboveMainEditor = document.createElement('div');
          divAboveMainEditor.className = 'ai-above-main-editor';

          // Create feedback content container
          const feedbackContent = document.createElement('div');
          feedbackContent.className = 'ai-feedback-content';

          // Create close button
          const closeButton = document.createElement('button');
          closeButton.className = 'ai-close-button';
          closeButton.textContent = '×';
          closeButton.addEventListener('click', () => {
            divAboveMainEditor.remove();
          });

          // Create feedback text
          const feedbackTextNode = document.createTextNode('Feedback: ' + feedbackText);

          // Create action buttons container first
          const actionButtons = document.createElement('div');
          actionButtons.className = 'ai-action-buttons';

          // Add everything to the container
          feedbackContent.appendChild(closeButton);
          feedbackContent.appendChild(feedbackTextNode);
          feedbackContent.appendChild(actionButtons);

          divAboveMainEditor.appendChild(feedbackContent);
          editorElement?.parentNode?.insertBefore(divAboveMainEditor, editorElement);

          // Remove the overlay after showing the feedback text
          removeOverlay();

          // Add the "Edit myself" button to the div
          const editMyselfButton = document.createElement('button');
          editMyselfButton.className = 'ai-action-button';
          editMyselfButton.innerHTML = Drupal.t('I\'ll edit it myself');
          actionButtons.appendChild(editMyselfButton);

          // Add the "Rewrite with AI" button to the div
          const rewriteWithAiButton = document.createElement('button');
          rewriteWithAiButton.className = 'ai-action-button';
          rewriteWithAiButton.innerHTML = Drupal.t('Rewrite with AI');
          actionButtons.appendChild(rewriteWithAiButton);

          // Add event listeners to buttons
          editMyselfButton.addEventListener('click', () => {
            // Remove the buttons
            actionButtons.remove();
          });

          rewriteWithAiButton.addEventListener('click', (event) => {
            event.preventDefault();
            const prevData = editor.getData();

            // Create the editor containers
            const { mainContainer, leftContainer, rightContainer } = createEditorContainers(editorElement);
            leftContainer.innerHTML = prevData;
            rightContainer.innerHTML = rewrittenText;

            // Add cancel button to right container
            const cancelButton = document.createElement('button');
            cancelButton.className = 'ai-cancel-button';
            cancelButton.innerHTML = Drupal.t('Cancel');
            rightContainer.appendChild(cancelButton);

            // Add cancel button event listener
            cancelButton.addEventListener('click', (event) => {
              event.preventDefault();
              // Restore original editor content
              editor.setData(prevData);
              // Remove the split view container
              mainContainer.remove();
            });

            const [HTMLWithNotes, HTMLNoNotes] = mapSquareBracketsToSpan(rewrittenText);
            diffAi(prevData, HTMLNoNotes);
            editor.setData(HTMLWithNotes);

            // Remove the feedback container since we're showing the split view
            divAboveMainEditor.remove();
          });

          // dialogue.show({
          //   ...basicDialogProperties,
          //   title: Drupal.t('The AI returned the following recommendations:'),
          //   content: [summaryView],
          //   actionButtons: [
          //     {
          //       label: Drupal.t('I\'ll edit it myself'),
          //       class: 'button-text-tone-green',
          //       withText: true,
          //       onExecute: () => {
          //         hideDialogue();
          //         removeOverlay();
          //         dialogue.show({
          //           title: Drupal.t('The AI returned the following recommendations:'),
          //           id: 'text-tone-dialog',
          //           content: summaryView,
          //         });
          //       }
          //     },
          //     {
          //       label: Drupal.t('Rewrite with AI'),
          //       class: 'button-text-tone-red',
          //       withText: true,
          //       onExecute: () => {
          //         const prevData = this.editor.getData();
          //         hideDialogue();
          //         // Create the editor containers
          //         const { mainContainer, leftContainer, rightContainer } = createEditorContainers(editorElement);
          //         leftContainer.innerHTML = prevData;
          //         rightContainer.innerHTML = rewrittenText;

          //         const [HTMLWithNotes, HTMLNoNotes] = mapSquareBracketsToSpan(rewrittenText);
          //         diffAi(prevData, HTMLNoNotes);
          //         editor.setData(HTMLWithNotes);

          //         removeOverlay();
          //       },
          //     }
          //   ],
          // })
        } else {
          const errorView = new View(locale);
          errorView.setTemplate({
            ...basicTemplateProperties,
            children: [await response.text()],
          });

          dialogue.show({
            ...basicDialogProperties,
            title: Drupal.t('An errror has occured:'),
            content: errorView,
            actionButtons: [{
              label: Drupal.t('Ok'),
              withText: true,
              class: 'button-text-tone-red',
              onExecute: hideDialogue,
            }],
          });

          // Remove the overlay after showing the error dialogue
          removeOverlay();
        }
      });

      // Return the button we've just built so it can be used on the tooltip.
      return mainButton;
    });
  }
}



// Add type defintions for Drupal and drupalSettings.
declare const Drupal: {
  t: (text: string) => string
}

declare const drupalSettings: {
  claude: {
    readonly enableAi?: boolean,
    readonly nodeType?: string,
  }
}
