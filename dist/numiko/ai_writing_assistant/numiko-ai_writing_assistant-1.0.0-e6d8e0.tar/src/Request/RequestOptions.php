<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant\Request;

/**
 * Contains various options the request will need.
 */
class RequestOptions {

  public function __construct(
    public string $aiModel,
    public string $prompt,
    public string $apiKey
  ) {}

}
