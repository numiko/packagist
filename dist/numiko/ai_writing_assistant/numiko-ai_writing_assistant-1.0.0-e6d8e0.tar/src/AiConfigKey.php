<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant;

use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Enumeration of config keys for Claude.
 */
enum AiConfigKey: string {
  case ClaudeModel = 'claude_model';
  case StylePrompt = 'summary_prompt';
  case ApiKey = 'api_key';
  case EnableAI = 'enable_ai';
  case UseDefautPrompt = 'use_default_style_guide';
  case LocalStyleGuide = 'local_style_guide';

  public const GLOBAL_SETTINGS = [
    AiConfigKey::ClaudeModel,
    AiConfigKey::StylePrompt,
  ];

  public const LOCAL_SETTINGS = [
    AiConfigKey::EnableAI,
    AiConfigKey::UseDefautPrompt,
    AiConfigKey::LocalStyleGuide,
  ];

  /**
   * Machine readable name of this config key.
   */
  public function machine(): string {
    return $this->value;
  }

  /**
   * Human readable name of this config key.
   */
  public function human(): TranslatableMarkup {
    return match ($this) {
      AiConfigKey::ClaudeModel => t('AI Model'),
      AiConfigKey::StylePrompt => t('Style Prompt'),
      AiConfigKey::ApiKey => t('Anthropic API key'),
      AiConfigKey::EnableAI => t('Enable AI Text Rewriting'),
      AiConfigKey::UseDefautPrompt => t('Use the default prompt'),
      AiConfigKey::LocalStyleGuide => t('Node-specific Style Prompt'),
    };
  }

  /**
   * Description of this config key.
   */
  public function desc(): TranslatableMarkup {
    return match ($this) {
      AiConfigKey::ClaudeModel => t('AI Model, see here: https://docs.anthropic.com/claude/docs/models-overview'),
      AiConfigKey::StylePrompt => t('The default style guide given to the AI to get it to rewrite the field\'s text in a better tone'),
      AiConfigKey::ApiKey => t('This site\'s access key for the AI API'),
      AiConfigKey::LocalStyleGuide => t('The default style guide is configurable in the admin settings'),
    };
  }

}
