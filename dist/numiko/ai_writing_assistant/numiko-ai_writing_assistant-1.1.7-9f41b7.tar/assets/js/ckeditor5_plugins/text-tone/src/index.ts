import TextTone from './text-tone'

/**
 * @private
 */
export default {
  TextTone
};
