<?php

declare(strict_types=1);

namespace Drupal\ai_writing_assistant\Form;

use Drupal\ai\AiProviderPluginManager;
use Drupal\ai_writing_assistant\AiConfigKey;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Allows the Anthropic and Claude Versions to be configured.
 */
class NumikoAiConfigForm extends ConfigFormBase {

  private const SETTINGS = 'ai_writing_assistant.settings';

  private const SETTING_KEYS = [AiConfigKey::StylePrompt];

  public function __construct(
    ConfigFactoryInterface $cfi,
    protected readonly AiProviderPluginManager $ai,
  ) {
    parent::__construct($cfi);
  }

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('ai.provider')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ai_writing_assistant_settings';
  }

  /**
   * {@inheritDoc}
   */
  public function getEditableConfigNames() {
    return [self::SETTINGS];
  }

  /**
   * {@inheritDoc}
   */
  public function buildForm(array $form, ?FormStateInterface $formState) {
    $chatModels = $this->ai->getSimpleProviderModelOptions('chat');
    $defaultModel = $this->ai->getSimpleDefaultProviderOptions('chat');

    $config = $this->config(self::SETTINGS);

    $form[AiConfigKey::StylePrompt->machine()] = [
      '#type' => 'textarea',
      '#title' => AiConfigKey::StylePrompt->human(),
      '#description' => AiConfigKey::StylePrompt->desc(),
      '#default_value' => $config->get(AiConfigKey::StylePrompt->machine()),
      '#required' => TRUE,
    ];

    $form[AiConfigKey::Model->machine()] = [
      '#type' => 'select',
      '#options' => $chatModels,
      '#disabled' => count($chatModels) == 0,
      '#title' => AiConfigKey::Model->human(),
      '#default_value' => $config->get(AiConfigKey::Model->machine()) ?? $defaultModel,
      '#required' => TRUE,
    ];

    return parent::buildForm($form, $formState);
  }

  /**
   * {@inheritDoc}
   */
  public function submitForm(array &$form, FormStateInterface $formState): void {
    $this->config(self::SETTINGS)
      ->set(AiConfigKey::StylePrompt->machine(), $formState->getValue(AiConfigKey::StylePrompt->machine()))
      ->set(AiConfigKey::Model->machine(), $formState->getValue(AiConfigKey::Model->machine()))
      ->save();

    parent::submitForm($form, $formState);
  }

}
