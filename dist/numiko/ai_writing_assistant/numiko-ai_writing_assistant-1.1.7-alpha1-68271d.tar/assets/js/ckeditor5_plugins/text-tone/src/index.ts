import DiffValue from './diff-value';
import TextTone from './text-tone'

/**
 * @private
 */
export default {
  TextTone,
  DiffValue
};
