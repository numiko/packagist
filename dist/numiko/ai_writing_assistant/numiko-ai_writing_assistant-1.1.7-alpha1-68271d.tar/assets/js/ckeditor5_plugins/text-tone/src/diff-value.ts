import { Plugin } from '@ckeditor/ckeditor5-core';

export default class DiffValue extends Plugin {
  /**
   * @inheritDoc
   */
  static get requires() {
    return [];
  }

  /**
   * @inheritdoc
   */
  static get pluginName() {
    return 'DiffValue';
  }

  /**
  * @inheritdoc
  */
  init() {
    const editor = this.editor;
    const model = editor.model;

    // Schema.
    model.schema.extend('$text', {
      allowAttributes: 'diffValue'
    });

    // editingDowncast for editing pipeline
    editor.conversion
      .for('downcast')
      .attributeToElement({
        model: 'diffValue',
        view: {
          name: 'span',
          classes: 'ai-explaination'
        }
      });

    editor.conversion
      .for('upcast')
      .elementToAttribute({
        view: {
          name: 'span',
          classes: 'ai-explaination'
        },
        model: 'diffValue',
      });
  }


}
