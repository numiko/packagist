<?php

namespace Drupal\styleguide_media_modal\MediaModal;

use Drupal\Core\Image\ImageFactory;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\styleguide_media_modal\MediaModal\MediaModalInterface;

/**
 * Implementation of media modal for image media.
 */
class ImageMediaModal implements MediaModalInterface {

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * @var \Drupal\Core\Image\ImageFactory
   */
  protected $imageFactory;

  /**
   * @var string
   */
  protected $modalImageStyle;

  /**
   * Image constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   * @param \Drupal\Core\Image\ImageFactory $imageFactory
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager, ImageFactory $imageFactory) {
    $this->entityTypeManager = $entityTypeManager;
    $this->imageFactory = $imageFactory;
    $this->modalImageStyle = 'uncropped_medium';
  }

  /**
   * {@inheritdoc}
   */
  public function buildModalData(EntityInterface $entity) {
    $modalData = [
      "type" => $entity->bundle(),
      "id" => $entity->id(),
    ];

    $builder = $this->entityTypeManager->getViewBuilder('media');

    if ($entity->hasField('name')) {
      $modalData['title'] = $builder->viewField($entity->get('name'));
    }

    if ($entity->hasField('field_image') && !$entity->get('field_image')->isEmpty()) {
      $fileUri = $entity->get('field_image')->first()->entity->getFileUri();
      if ($fileUri) {
        $modalData['image_src'] = $this->entityTypeManager
          ->getStorage('image_style')
          ->load($this->modalImageStyle)
          ->buildUrl($fileUri);
        $modalData['image_alt'] = $entity->get('field_image')
          ->first()
          ->getValue()['alt'];
        $dimensions = $this->getMediaDimensions($fileUri);
        $modalData['image_width'] = $dimensions['width'];
        $modalData['image_height'] = $dimensions['height'];
        $modalData['image_aspect_ratio'] = $dimensions['aspect_ratio'];
      }
    }

    if ($entity->hasField('field_caption')) {
      $modalData['caption'] = $builder->viewField($entity->get('field_caption'));
    }

    return $modalData;
  }

  /**
   * Get dimensions of image once processed by image style.
   *
   * @param string $fileUri
   *   URI of file to get dimensions of.
   * @return array
   */
  protected function getMediaDimensions(string $fileUri) {
    $imageStyle = $this->entityTypeManager
      ->getStorage('image_style')
      ->load($this->modalImageStyle);

    $buildUri = $imageStyle->buildUri($fileUri);
    // Preload image style for display in the modal.
    //
    // The data we need won't be available if the derivative image hasn't been
    // generated yet. See this commit and accompanying ticket:
    // https://bitbucket.org/numiko/ravensbourne-university/commits/e4b67be1ead6c90e1cd5a15be9e89828167d9ab5
    if (!file_exists($buildUri)) {
      $imageStyle->createDerivative($fileUri, $buildUri);
    }

    $imageFactory = $this->imageFactory->get($buildUri);
    $imageHeight = $imageFactory->getToolkit()->getHeight();
    $imageWidth = $imageFactory->getToolkit()->getWidth();

    return [
      "height" => $imageHeight,
      "width" => $imageWidth,
      "aspect_ratio" => $imageHeight / $imageWidth * 100 . "%",
    ];
  }

}
