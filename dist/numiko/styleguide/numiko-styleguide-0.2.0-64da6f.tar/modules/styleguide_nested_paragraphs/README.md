# Styleguide Nested Paragraphs

## Install

* Install the module as usual
* Go to "Manage display" and change the nested paragraph formatter to use "Styleguide Nested Paragraph View"

## Usage

The items within the nested paragraph now contain the render arrays keyed by field ID using a short name syntax, by removing the 'field_' prefix.

In order to avoid the render array we filter the array for just the numbered elements, the result being that you could not render `{{ content.field_items }}` these would need to be looped through.

`{% for i, item in content.field_items %}`

Where item would contain all fields listed in the manage display for the paragraph type, e.g. `{{ item.title }}`.