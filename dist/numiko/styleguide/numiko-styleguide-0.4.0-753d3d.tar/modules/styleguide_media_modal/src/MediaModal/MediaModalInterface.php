<?php

namespace Drupal\styleguide_media_modal\MediaModal;

use Drupal\Core\Entity\EntityInterface;

/**
 * Interface for handling media modal data.
 */
interface MediaModalInterface {

  /**
   * Build the modal data from the given entity.
   */
  public function buildModalData(EntityInterface $entity);

}
