# Visible Trim #

This is a field formatter for plain text fields which adds tags around a given length of string, so that the overflow can be visually hidden.