<?php

declare(strict_types=1);

namespace Drupal\media_linkit\Plugin\Filter;

use Drupal\Component\Utility\Html;
use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\filter\Attribute\Filter;
use Drupal\filter\FilterProcessResult;
use Drupal\filter\Plugin\FilterBase;
use Drupal\filter\Plugin\FilterInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a Linkit filter.
 *
 * Note this must run before any Xss::filter() calls and after the linkit call, because that strips
 * disallowed protocols. That effectively means this must run before the
 * \Drupal\filter\Plugin\Filter\FilterHtml filter. Hence the very low weight.
 */
#[Filter(
  id: "media_file_linkit",
  title: new TranslatableMarkup("Media File Linkit filter"),
  type: FilterInterface::TYPE_TRANSFORM_REVERSIBLE,
  description: new TranslatableMarkup("Update media file links to link to the embedded file."),
  weight: -10,
  settings: [
    "media_bundle" => NULL,
    "file_field" => NULL,
    "file_size" => NULL,
    "file_mime" => NULL,
  ],
)]
class MediaFileLinkitFilter extends FilterBase implements ContainerFactoryPluginInterface {

  /**
   * Constructs a LinkitFilter object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityRepositoryInterface $entityRepository
   *   The entity repository service.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    protected readonly EntityRepositoryInterface $entityRepository,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity.repository'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function process($text, $langcode): FilterProcessResult {
    $result = new FilterProcessResult($text);

    if (strpos($text, 'data-entity-type') !== FALSE && strpos($text, 'data-entity-uuid') !== FALSE) {
      $dom = Html::load($text);
      $xpath = new \DOMXPath($dom);

      foreach ($xpath->query('//a[@data-entity-type and @data-entity-uuid]') as $element) {
        /** @var \DOMElement $element */
        try {
          // Load the appropriate translation of the linked entity.
          $entity_type = $element->getAttribute('data-entity-type');

          if ($entity_type !== 'media') {
            continue;
          }

          $uuid = $element->getAttribute('data-entity-uuid');
          $entity = $this->entityRepository->loadEntityByUuid($entity_type, $uuid);
          if ($entity) {
            $entity = $this->entityRepository->getTranslationFromContext($entity, $langcode);
            if ($entity->bundle() !== $this->settings['media_bundle']) {
              continue;
            }
            if ($value = $this->getMediaValueFromToken($entity, 'file_field')) {
              $element->setAttribute('href', $value);
              $element->setAttribute('class', 'link-type-media-file');
              if ($value = $this->getMediaValueFromToken($entity, 'file_size')) {
                if (preg_match('/[0-9]+/', $value)) {
                  $element->setAttribute('data-file-size', $value);
                }
              }
              if ($value = $this->getMediaValueFromToken($entity, 'file_mime')) {
                $mimeType = explode('/', $value);
                $element->setAttribute('data-file-mime', array_pop($mimeType));
              }
            }
          }
        }
        catch (\Exception $e) {
          watchdog_exception('media_file_linkit_filter', $e);
        }
      }

      $result->setProcessedText(Html::serialize($dom));
    }

    return $result;
  }

  /**
   * Resolves a media token setting to its rendered value.
   */
  protected function getMediaValueFromToken($entity, string $setting): string {
    $tokenOptions = ['clear' => TRUE];
    $tokenData = ['media' => $entity];
    return \Drupal::token()->replace($this->settings[$setting], $tokenData, $tokenOptions);
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state): array {
    $options = [];
    $bundles = \Drupal::service('entity_type.bundle.info')->getBundleInfo('media');
    foreach ($bundles as $id => $bundle) {
      $options[$id] = $bundle['label'];
    }

    $form['media_bundle'] = [
      '#type' => 'select',
      '#title' => 'Select the bundle to use with',
      '#options' => $options,
      '#default_value' => $this->settings['media_bundle'],
    ];

    $form['file_field'] = [
      '#type' => 'textfield',
      '#title' => $this->t('File to link to'),
      '#default_value' => $this->settings['file_field'],
      '#element_validate' => ['token_element_validate'],
      '#after_build' => ['token_element_validate'],
      '#token_types' => ['media'],
    ];

    $form['file_size'] = [
      '#type' => 'textfield',
      '#title' => $this->t('File size details'),
      '#default_value' => $this->settings['file_size'],
      '#element_validate' => ['token_element_validate'],
      '#after_build' => ['token_element_validate'],
      '#token_types' => ['media'],
    ];

    $form['file_mime'] = [
      '#type' => 'textfield',
      '#title' => $this->t('File mime details'),
      '#default_value' => $this->settings['file_mime'],
      '#element_validate' => ['token_element_validate'],
      '#after_build' => ['token_element_validate'],
      '#token_types' => ['media'],
    ];

    $form['token_help'] = [
      '#theme' => 'token_tree_link',
      '#token_types' => ['media'],
    ];

    return $form;
  }

}
