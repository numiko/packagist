# Person Content Type Recipe

This recipe installs the necessary configuration to add an Person Content Type.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/content-person-recipe`
