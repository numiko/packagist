<?php

namespace Numiko\PetImporter;

use Numiko\PetImporter\Parsers\XmlParser;
use Numiko\PetImporter\Transformers\CanLiveWithChildrenTransformer;
use Numiko\PetImporter\Transformers\CanLiveWithOtherPetsTransformer;
use Numiko\PetImporter\Transformers\HorseSuitabilityTransformer;
use Numiko\PetImporter\Transformers\HorseHeightTransformer;
use Numiko\PetImporter\Transformers\StringToHtmlTransformer;
use Numiko\PetImporter\Transformers\AgeBracketTransformer;
use Numiko\PetImporter\Transformers\ImageIdToPathTransformer;
use Numiko\PetImporter\Validators\AllImagesExistValidator;
use Psr\Log\LoggerInterface;

/**
 * Class: PetParser
 *
 * This class is responsible for transforming the pet XML into a friendlier array
 * which we can then use to import into Drupal via a migration
 *
 * This class isn't as abstracted perhaps it could be, the massive list of
 * dependencies passed to the constructor and the large PetParser::import method
 * are a reflection of this.
 *
 * Since we are transforming data from one structured format to another, I felt
 * it's important for the code to vaguely reflect the structure of the data format
 * so when debugging, anyone shouldn't need to go hunting for where the data
 * is fetched.
 *
 * @author Dan Bentley
 */
class PetParser
{
    /**
     * __construct
     *
     * @param CanLiveWithChildrenTransformer $canLiveWithChildrenTransformer
     * @param CanLiveWithOtherPetsTransformer $canLiveWithOtherPetsTransformer
     * @param HorseSuitabilityTransformer $horseSuitabilityTransformer
     * @param HorseHeightTransformer $horseHeightTransformer
     * @param StringToHtmlTransformer $stringToHtmlTransformer
     * @param AgeBracketTransformer $ageBracketTransformer
     * @param ImageIdToPathTransformer $imageIdToPathTransformer
     * @param AllImagesExistValidator $allImagesExistValidator
     * @param XmlParser $xmlParser
     * @param LoggerInterface $logger
     */
    public function __construct(
        CanLiveWithChildrenTransformer $canLiveWithChildrenTransformer,
        CanLiveWithOtherPetsTransformer $canLiveWithOtherPetsTransformer,
        HorseSuitabilityTransformer $horseSuitabilityTransformer,
        HorseHeightTransformer $horseHeightTransformer,
        StringToHtmlTransformer $stringToHtmlTransformer,
        AgeBracketTransformer $ageBracketTransformer,
        ImageIdToPathTransformer $imageIdToPathTransformer,
        AllImagesExistValidator $allImagesExistValidator,
        XmlParser $xmlParser,
        LoggerInterface $logger
    ) {
        $this->canLiveWithChildrenTransformer = $canLiveWithChildrenTransformer;
        $this->canLiveWithOtherPetsTransformer = $canLiveWithOtherPetsTransformer;
        $this->horseSuitabilityTransformer = $horseSuitabilityTransformer;
        $this->horseHeightTransformer = $horseHeightTransformer;
        $this->stringToHtmlTransformer = $stringToHtmlTransformer;
        $this->ageBracketTransformer = $ageBracketTransformer;
        $this->imageIdToPathTransformer = $imageIdToPathTransformer;

        $this->allImagesExistValidator = $allImagesExistValidator;

        $this->xmlParser = $xmlParser;

        $this->logger = $logger;
    }

    /**
     * validate
     *
     * Check whether the pet data is valid
     *
     * @param array $petData
     * @return bool
     */
    private function validate(array $petData): bool
    {
        if (!$this->allImagesExistValidator->validate($petData)) {
            $this->logger->warning($petData['animalref'] . ' failed AllImagesExistValidator');

            return false;
        }

        $this->logger->info($petData['animalref'] . ' passed validation');

        return true;
    }

    /**
     * import
     *
     * Perform the import on pet XML to transform it into an array.
     *
     * Pet data that fails the Import::validate will not be included
     * with the returned array.
     *
     * @param string $xml
     * @return array
     */
    public function parse(string $xml): array
    {
        $this->xmlParser->loadXmlString($xml);

        $data = [
            'data' => [],
        ];

        $this->logger->debug('Starting import');

        foreach ($this->xmlParser->parserByXPath('animal') as $petParser) {
            $petData = $this->parsePet($petParser);

            if ($this->validate($petData)) {
                $data['data'][] = $petData;
            }
        }

        $this->logger->debug('Finished import');

        return $data;
    }

    /**
     * parsePet
     *
     * Transform the pet data into an array.
     *
     * Since we are transforming data from one structured format to another, I felt
     * it's important for the code to vaguely reflect the structure of the data format
     * so when debugging, anyone shouldn't need to go hunting for where the data
     * is fetched.
     *
     * @param XmlParser $petParser
     */
    private function parsePet(XmlParser $petParser): array
    {
        $petData = [
            'animalref' => $petParser->findIntegerByXPath('animalref'),
            'sponsored' => $petParser->findBooleanByXPath('sponsor', [
                'Y' => true,
                'N' => false,
            ]),
            'visit_number' => $petParser->findIntegerByXPath('visit_number'),
            'species' => $petParser->findStringByXPath('species'),
            'name' => $petParser->findStringByXPath('name'),
            'sex' => $petParser->findStringByXPath('sex'),
            'breed' => $petParser->findStringByXPath('breed'),
            'crossbreed' => $petParser->findStringByXPath('crossbreed'),
            'location' => $petParser->findStringByXPath('location'),
            'reserved' => $petParser->findBooleanByXPath('reserved', [
                'Y' => true,
                'N' => false,
            ]),
            'video_url' => $petParser->findStringByXPath('videourl'),
            'colours' => $petParser->findStringsByXPath('colours/colour'),
        ];

        $imagePaths = array_map(function ($imageId) {
            return $this->imageIdToPathTransformer->transform($imageId);
        }, $petParser->findStringsByXPath('images/image_id'));

        $petData['images'] = [
            'featured_image_url' => $imagePaths[0],
            'gallery_urls' => array_slice($imagePaths, 1),
        ];

        $years = $petParser->findIntegerByXPath('age_year');
        $months = $petParser->findIntegerByXPath('age_month');
        $petData['age'] = [
            'years' => $years,
            'months' => $months,
            'bracket' => $this->ageBracketTransformer->transform($years, $months),
        ];

        $webText = $petParser->findStringByXPath('web_text');
        $petData['description'] = $this->stringToHtmlTransformer->transform($webText);

        $petData['horse_height'] = $petParser->findFloatByXPath('size');
        $petData['horse_height_hands'] = $this->horseHeightTransformer->transform($petData['horse_height']);

        foreach ($petParser->parserByXPath('questions') as $questionParser) {
            $canLiveWith = [];

            $canLiveWithChildren = $questionParser->findStringByXPath(
                'question/question_text[text()="Can this pet live with children?"]/following-sibling::answer'
            );
            $transformedCanLiveWithChildren = $this->canLiveWithChildrenTransformer->transform($canLiveWithChildren);
            $canLiveWith = array_merge($transformedCanLiveWithChildren, $canLiveWith);

            $canLiveWithOtherPets = $questionParser->findStringByXPath(
                'question/question_text[text()="Can this pet live with other pets?"]/following-sibling::answer'
            );
            $transformedCanLiveWithOtherPets = $this->canLiveWithOtherPetsTransformer->transform($canLiveWithOtherPets);
            $canLiveWith = array_merge($transformedCanLiveWithOtherPets, $canLiveWith);

            $petData['can_live_with'] = $canLiveWith;

            $horseSuitability = $questionParser->findStringByXPath(
                'question/question_text[text()="Can this horse be ridden or is it suitable as a companion?"]/following-sibling::answer'
            );
            $petData['horse_suitability'] = $this->horseSuitabilityTransformer->transform($horseSuitability);
        }

        return $petData;
    }
}
