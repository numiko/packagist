<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Transformers;

/**
 * Class: CanLiveWithOtherPetsTransformer
 *
 * Map a string value to a range of values.
 *
 * e.g
 *
 * "Cat & dog" => ["Cat", "Dog",]
 *
 * @see AbstractStringToArrayTransformer
 *
 * @author Dan Bentley
 */
class CanLiveWithOtherPetsTransformer extends AbstractStringToArrayTransformer
{
    public const VALUES = [
        'cats' => ['Cats'],
        'dogs' => ['Dogs'],
        'cats and dogs' => [
            'Cats',
            'Dogs',
        ],
    ];
}
