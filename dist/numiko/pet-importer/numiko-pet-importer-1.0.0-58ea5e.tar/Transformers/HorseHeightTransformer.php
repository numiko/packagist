<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Transformers;

/**
 * Class: HorseHeightTransformer
 *
 * Transform horse height into a string value
 *
 * @author Dan Bentley
 */
class HorseHeightTransformer implements TransformerInterface
{
    public const VALUES = [
        0 => 'Up to 12hh',
        12 => '15hh and over',
    ];

    /**
     * transform
     *
     * @param ?float $heightInHands
     * @return horse height bracket
     */
    public function transform(?float $heightInHands=null): string
    {
        if ($heightInHands === null) {
            return '';
        }

        $ages = array_keys(self::VALUES);
        $initial = current($ages);

        $key = array_reduce($ages, function ($previousAge, $age) use ($heightInHands) {
            return ($heightInHands > $age) ? $age : $previousAge;
        }, $initial);

        return self::VALUES[$key];
    }
}
