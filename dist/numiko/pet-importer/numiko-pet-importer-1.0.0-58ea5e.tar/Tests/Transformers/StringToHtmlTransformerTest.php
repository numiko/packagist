<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests\Transformers;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\Transformers\StringToHtmlTransformer;

class StringToHtmlTransformerTest extends TestCase
{
    public function setUp(): void
    {
        $this->transformer = new StringToHtmlTransformer();
    }

    /**
     *
     * @testWith ["<p>string</p>", "string"]
     *           ["<p>Many words</p>", "Many words"]
     *           ["<p>Lots</p><p>of</p><p>linebreaks</p>", "Lots\nof\nlinebreaks\n"]
     *           ["", ""]
     *           ["", null]
     */
    public function test($expected, $stringToTransform)
    {
        $this->assertEquals($expected, $this->transformer->transform($stringToTransform));
    }
}
