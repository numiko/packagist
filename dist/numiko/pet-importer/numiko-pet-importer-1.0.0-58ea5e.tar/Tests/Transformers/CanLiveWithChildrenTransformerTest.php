<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests\Transformers;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\Transformers\CanLiveWithChildrenTransformer;

class CanLiveWithChildrenTransformerTest extends TestCase
{
    public function setUp(): void
    {
        $this->transformer = new CanLiveWithChildrenTransformer();
    }


    /**
     *
     * @testWith [["School age children"], "School Age"]
     *           [["School age children"], "School age"]
     *           [["School age children"], "school Age"]
     *           [["School age children"], "school age"]
     *           [["All age children"], "Any age"]
     *           [["All age children"], "any age"]
     *           [["All age children"], "Any Age"]
     *           [[], "Invalid answer"]
     *           [[], ""]
     *           [[], null]
     */
    public function testExpected($expected, $answer)
    {
        $this->assertEquals($expected, $this->transformer->transform($answer));
    }
}
