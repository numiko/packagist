<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests\Validators;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\Validators\AllImagesExistValidator;

class AllImagesExistValidatorTest extends TestCase
{
    public function setUp(): void
    {
        $this->validator = new AllImagesExistValidator();

        file_put_contents('/tmp/a', '');
    }

    public function tearDown(): void
    {
        unlink('/tmp/a');
    }

    /**
     *
     * @testWith [true, { "images": { "featured_image_url": "/tmp/a", "gallery_urls": ["/tmp/a"] } }]
     *           [false, { "images": { "featured_image_url": "/tmp/b", "gallery_urls": ["/tmp/a"] } }]
     *           [false, { "images": { "featured_image_url": "/tmp/a", "gallery_urls": ["/tmp/b"] } }]
     *           [false, { "images": { "featured_image_url": "/tmp/b", "gallery_urls": ["/tmp/b"] } }]
     *           [false, { "images": { "featured_image_url": "/tmp/b", "gallery_urls": ["/tmp/b"] } }]
     *           [false, { "images": { "featured_image_url": "", "gallery_urls": ["/tmp/a"] } }]
     *           [false, { "images": { "featured_image_url": "/tmp/a", "gallery_urls": [""] } }]
     *           [false, { "images": { "featured_image_url": "/tmp/a" } }]
     *           [false, { "images": { "gallery_urls": [""] } }]
     */
    public function testExpected($expected, $petData)
    {
        $this->assertEquals($expected, $this->validator->validate($petData));
    }
}
