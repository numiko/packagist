<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\PetParser;
use Numiko\PetImporter\Transformers\CanLiveWithChildrenTransformer;
use Numiko\PetImporter\Transformers\CanLiveWithOtherPetsTransformer;
use Numiko\PetImporter\Transformers\HorseSuitabilityTransformer;
use Numiko\PetImporter\Transformers\HorseHeightTransformer;
use Numiko\PetImporter\Transformers\StringToHtmlTransformer;
use Numiko\PetImporter\Transformers\AgeBracketTransformer;
use Numiko\PetImporter\Transformers\ImageIdToPathTransformer;
use Numiko\PetImporter\Validators\AllImagesExistValidator;
use Numiko\PetImporter\Parsers\XmlParser;
use Psr\Log\Test\TestLogger;
use Psr\Log\LogLevel;


class PetParserLoggingTest extends TestCase
{
    public const XML = <<<XML
<?xml version="1.0"?>
<export_file export_date="16102019" animal_records="501">
  <animal>
    <animalref>119627</animalref>
    <images>
      <image_id>96928</image_id>
      <image_id>96929</image_id>
      <image_id>96930</image_id>
    </images>
  </animal>
</export_file>
XML;

    public function setUp(): void
    {
        $this->logger = new TestLogger();

        $this->petParser = new PetParser(
            new CanLiveWithChildrenTransformer(),
            new CanLiveWithOtherPetsTransformer(),
            new HorseSuitabilityTransformer(),
            new HorseHeightTransformer(),
            new StringToHtmlTransformer(),
            new AgeBracketTransformer(),
            new ImageIdToPathTransformer('/tmp/'),
            new AllImagesExistValidator(),
            new XmlParser(simplexml_load_string(self::XML)),
            $this->logger
        );

        $data = $this->petParser->parse(self::XML);
    }

    public function testStartingImportLog()
    {
        $this->assertTrue($this->logger->hasRecordThatContains('Starting import', LogLevel::DEBUG));
    }

    public function testValidationFailedLog()
    {
        $this->assertTrue($this->logger->hasRecordThatContains('119627 failed AllImagesExistValidator', LogLevel::WARNING));
    }

    public function testFinishImportLog()
    {
        $this->assertTrue($this->logger->hasRecordThatContains('Finished import', LogLevel::DEBUG));
    }
}
