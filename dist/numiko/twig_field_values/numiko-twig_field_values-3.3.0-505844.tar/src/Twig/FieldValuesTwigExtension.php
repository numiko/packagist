<?php

namespace Drupal\twig_field_values\Twig;

use Twig\TwigFilter;
use Twig\TwigFunction;
use Drupal\Core\Render\Markup;
use Twig\Extension\AbstractExtension;
use Drupal\Core\Template\TwigExtension;

/**
 * Useful Twig filters.
 *
 * These filters extend field output functionality include check for
 * field population, display and comparison.
 */
class FieldValuesTwigExtension extends AbstractExtension {

  /**
   * Core twig extension.
   *
   * @var Drupal\Core\Template\TwigExtension
   */
  private $coreTwigExtension;

  /**
   * {@inheritDoc}
   */
  public function __construct(TwigExtension $coreTwigExtension) {
    $this->coreTwigExtension = $coreTwigExtension;
  }

  /**
   * {@inheritDoc}
   */
  public function getName() {
    return 'val';
  }

  /**
   * Get a list of filters.
   */
  public function getFilters() {
    return [
      new TwigFilter('field_display_value', [$this, 'fieldDisplayValueFilter']),
      new TwigFilter('field_comparison_value', [
        $this,
        'fieldComparisonValueFilter',
      ]),
      new TwigFilter('bool_value', [$this, 'boolValueFilter']),
      new TwigFilter('array_value', [$this, 'arrayValueFilter']),
      new TwigFilter('without_all_fields', [$this, 'withoutAllFieldsFilter']),
      // Deprecated filters (field & field_value).
      new TwigFilter('field', [$this, 'fieldDisplayValueFilter']),
      new TwigFilter('field_value', [$this, 'fieldComparisonValueFilter']),
    ];
  }

  /**
   * Get a list of twig simple functions.
   */
  public function getFunctions() {
    return [
      new TwigFunction('has_value', [$this, 'hasValueFunction']),
      new TwigFunction('has_value_any', [$this, 'hasValueAnyFunction']),
      new TwigFunction('has_value_all', [$this, 'hasValueAllFunction']),
      // Deprecated function - use has_value_any.
      new TwigFunction('any_has_value', [$this, 'hasValueAnyFunction']),
    ];
  }

  /**
   * Return true if the field is not empty.
   *
   * @param array|string $field
   *   The field render array.
   *
   * @return bool
   *   Return whether field render array has a value.
   */
  public function hasValueFunction($field) {
    return (bool) $this->fieldComparisonValueFilter($field);
  }

  /**
   * Return true if ANY of the array of fields is not empty.
   *
   * @param array $fields
   *   An array of field render arrays.
   *
   * @return bool
   *   Return whether ANY of the field render arrays has a value.
   */
  public function hasValueAnyFunction(array $fields) {
    return (bool) array_filter($fields, [$this, 'hasValueFunction']);
  }

  /**
   * Return true if ALL of the array of fields are not empty.
   *
   * @param array $fields
   *   An array of field render arrays.
   *
   * @return bool
   *   Return whether ALL of the field render arrays have a value.
   */
  public function hasValueAllFunction(array $fields) {
    // Check if every field in the array has a value.
    foreach ($fields as $field) {
      if (!$this->hasValueFunction($field)) {
        return FALSE;
      }
    }
    return TRUE;
  }

  /**
   * Get field value ready for display (without HTML comments).
   *
   * Strip tags to get rid of twig debugging comments and trim to get rid of
   * extra space caused by same debugging.
   *
   * Returns as Markup object to avoid double-escaping found when filters are
   * applied after render in template (like field_x|render|striptags|trim).
   *
   * @param string $field
   *   A field render array.
   *
   * @return \Drupal\Component\Render\MarkupInterface|mixed|string
   *   The field value ready for displaying.
   */
  public function fieldDisplayValueFilter($field) {
    $rendered = $this->coreTwigExtension->renderVar($field);
    if ($rendered instanceof Markup) {
      $treatedMarkup = Markup::create(trim($this->stripHtmlComments((string) $rendered)));
      return $treatedMarkup;
    }
    else {
      return $rendered;
    }
  }

  /**
   * Return the given string with html comments stripped out.
   *
   * @param string $content
   *   Any string.
   *
   * @return string
   *   The string with HTML comments stripped out.
   */
  protected function stripHtmlComments(string $content) {
    return preg_replace('/<!--(.|\s)*?-->/', '', $content);
  }

  /**
   * Return the given string with all tags stripped out.
   *
   * @param string $content
   *   Any string.
   *
   * @return string
   *   The string with HTML tags stripped out.
   */
  protected function stripHtmlTags(string $content) {
    return trim(strip_tags((string) $content));
  }

  /**
   * Get field raw value ready for comparison.
   *
   * Get the raw value of a field. It will be auto-escaped as normal, so should
   * not be used to user-facing content. It is intended for getting values for
   * comparisons.
   *
   * @param array|string $field
   *   A field render array.
   *
   * @return \Drupal\Component\Render\MarkupInterface|mixed|string
   *   The field value ready for use in a comparison.
   */
  public function fieldComparisonValueFilter($field) {
    $rendered = $this->fieldDisplayValueFilter($field);
    if (is_object($rendered)) {
      return (string) $rendered;
    }
    else {
      return $rendered;
    }
  }

  /**
   * Use when a boolean value is expected e.g. for comparisons.
   *
   * @param array|string $field
   *   A field render array.
   *
   * @return \Drupal\Component\Render\MarkupInterface|mixed|string
   *   The boolean value from the field.
   */
  public function boolValueFilter($field) {
    $rendered = $this->fieldDisplayValueFilter($field);
    if ($rendered instanceof Markup) {
      $renderedString = (string) $rendered;
    }
    else {
      $renderedString = $rendered;
    }
    // Strip any remaining HTML tags for boolean comparison.
    $renderedString = $this->stripHtmlTags($renderedString);

    // Deal with standard boolean formatters.
    if (in_array($renderedString, ['True', 'Yes', 'On', 'Enabled'])) {
      return TRUE;
    }
    elseif (in_array($renderedString, ['False', 'No', 'Off', 'Disabled'])) {
      return FALSE;
    }
    else {
      return (bool) $renderedString;
    }

  }

  /**
   * Strips HTML comments from a multi-value field.
   *
   * Returns individual items from a multi-value field as a simple array with
   * HTML comments stripped out.
   *
   * @param array $renderArray
   *   Field render array.
   *
   * @return array
   *   An array of field value strings with the HTML comments stripped out.
   */
  public function arrayValueFilter(array $renderArray) {
    $arrayItems = [];
    foreach ($renderArray as $key => $item) {
      if (is_numeric($key)) {
        if (isset($item['#markup'])) {
          $arrayItems[$key] = trim($this->stripHtmlComments($item['#markup']));
        }
      }
    }
    return $arrayItems;
  }

  /**
   * Strips all fields from a render array.
   *
   * Remove any fields (prefixed with "field_") or the body field.
   *
   * @param array $renderArray
   *   The render array of the content.
   *
   * @return array
   *   The render array with all field_ prefixed fields removed.
   */
  public function withoutAllFieldsFilter(array $renderArray): array {
    return array_filter($renderArray, fn($key) => substr($key, 0, 5) !== 'field' && $key !== 'body', ARRAY_FILTER_USE_KEY);
  }

}
