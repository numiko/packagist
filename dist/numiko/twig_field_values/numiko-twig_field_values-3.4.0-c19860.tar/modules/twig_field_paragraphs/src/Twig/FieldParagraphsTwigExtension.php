<?php

namespace Drupal\twig_field_paragraphs\Twig;

use Drupal\entity_reference_revisions\EntityReferenceRevisionsFieldItemList;
use Twig\TwigFilter;
use Twig\Extension\AbstractExtension;

/**
 * Useful Twig filters for dealing with paragraphs.
 *
 * These filters add the ability to check for a paragraph type being present on
 * a paragraph field.
 */
class FieldParagraphsTwigExtension extends AbstractExtension {

  /**
   * {@inheritDoc}
   */
  public function getName() {
    return 'paragraphs';
  }

  /**
   * Get a list of twig simple functions.
   */
  public function getFilters() {
    return [
      new TwigFilter('has_paragraph_type', [$this, 'hasParagraphTypeFilter']),
    ];
  }

  /**
   * Return true if the paragraph field contains the paragraph type.
   *
   * @param array|string $field
   *   The field render array.
   * @param string $paragraphType
   *   The paragraph type.
   *
   * @return bool
   *   Return whether field render array has a value.
   */
  public function hasParagraphTypeFilter($field, string $paragraphType): bool {
    if (!$this->hasParagraphItems($field)) {
      return FALSE;
    }
    return (!empty(array_filter($field['#items']->referencedEntities(), fn($entity) => ($entity->getEntityTypeId() === 'paragraph' && $entity->bundle() === $paragraphType))));
  }

  /**
   * Check if the field has paragraph items.
   */
  protected function hasParagraphItems($field) : bool {
    return ($field
      && is_array($field)
      && !empty($field['#items'])
      && ($field['#items'] instanceof EntityReferenceRevisionsFieldItemList)
      && !$field['#items']->isEmpty());
  }

}
