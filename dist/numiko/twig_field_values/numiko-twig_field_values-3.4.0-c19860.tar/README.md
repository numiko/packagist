# Twig Field Values

Useful twig filters and functions reduce chains of filters in templates, long conditionals and ensure no double encoding. Works nicely with twig debugging so there are no trailing spaces or comments where we don't want them.

## Filters

### field_display_value

Designed to strip debugging comments and trim extra space. Pass a field straight to it.

`content.field_content|field_display_value` is equivalent to `field_content|render|striptags|trim`

### field_comparison_value

Get the value of a field, minus debugging comments. Uses the field filter internally, but converts to a string. Therefore this should only be used in comparisons and not output as `{{ content.field_content|field_comparison_value }}` as Drupal's auto-escaping will kick in, potentially double-encoding any entities.

### bool_value

Returns a boolean. Use for checkbox fields in comparisons.

### array_value

Returns individual items from a multi-value field as a simple array.

### without_all_fields

Returns the render array removing any elements that represent fields, equivalent to `{{ content | without(field_..., field_...)}}`.
This avoids the need to update and remember to check every `{{ content | without(field_..., field_...)}}` every time you add a new field.

## Functions

### has_value(field)

Equivalent to `field_content|render|striptags|trim is not empty` but is neater and takes care of Twig debugging.

### has_value_any(fields)

Pass an array of fields, true will be returned if ANY of them is not empty.

`{% if has_value_any([content.field_telephone, content.field_email] ) %}`

### has_value_all(fields)

Pass an array of fields, true will be returned if ALL of them are not empty.

`{% if has_value_all([content.field_telephone, content.field_email] ) %}`

## Deprecated filters

### field

Now replaced with `field_display_value`.

### field_value

Now replaced with `field_comparison_value`.

## Deprecated functions

### any_has_value

Now replaced with `has_value_any`.

## Sub-modules

### Twig Field Paragraphs

Additional twig functions for checking paragraphs.

See readme for more detail.



