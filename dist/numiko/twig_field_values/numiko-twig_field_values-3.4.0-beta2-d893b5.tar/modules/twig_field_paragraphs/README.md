# Twig Field Paragraphs

Useful twig filters and functions for working with paragraphs.

## Filters

### has_paragraph_type

Designed to check within a paragraph field for the existence of a specific paragraph type.

`content.field_slices|has_paragraph_type('slice_type')`
