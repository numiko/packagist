# Feedback Form

Embed a feedback webform as a block in a page that displays a feedback question allowing a webform to be displayed via ajax (with nojs fallback).

## Setup

1. Create the webform
2. Add the webform as a block into a hidden region.
3. Add the feedback form block and set the webform block id in the config.

## Javascript

The following javascript should be added into the theme.

```
const feedbackButtons = document.querySelectorAll('[data-js-feedback-form-option]');
feedbackButtons.forEach((feedback) => {
  feedback.addEventListener('click', function (e) {
    e.preventDefault();
    this.classList.add('-active');
    if (this.classList.contains('js-feedback-yes')) {
      var value = this.getAttribute('data-confirm');
      document.querySelector('[data-js-feedback-form-options]').style.display = 'none';
      document.querySelector('[data-js-feedback-form-result]').innerHTML = '<div class="text-6xl text-color-purple-mid-dark text-center font-bold md:text-8xl"><span>' + value + '</span></div>';
    }
  });
});

// Hide the form options when submitting. Needs to use Drupal Behaviours as the form is added through ajax.
window.Drupal.behaviors.feedbackForm = {
  attach: function (context, settings) {
    const submitButton = context.querySelector('.c-feedback .js-form-submit');
    if (submitButton) {
      submitButton.addEventListener('click', function (e) {
        document.querySelector('[data-js-feedback-form-options]').style.display = 'none';
      });
    }
  }
};

```