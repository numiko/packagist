<?php

namespace Drupal\feedback_form\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\AppendCommand;
use Symfony\Component\HttpFoundation\RedirectResponse;

class FeedbackWebformController extends ControllerBase {

  /**
   * Render the feedback form webform as a block.
   */
  public function webformAjaxAction($block_id, $webform_id) {
    $response = new AjaxResponse();
    $blockStorage = \Drupal::entityTypeManager()->getStorage('block');
    $block = $blockStorage->load($block_id);
    if ($block) {
      $blockView = \Drupal::entityTypeManager()->getViewBuilder('block')->view($block);
      $response->addCommand(new AppendCommand('.js-feedback-result', $blockView));
    }
    return $response;
  }

  /**
   * Render the feedback form webform as a block.
   */
  public function webformNojsAction($block_id, $webform_id) {
    $webform = \Drupal::entityTypeManager()->getStorage('webform')->load($webform_id);
    if ($webform) {
      return new RedirectResponse($webform->toUrl()->toString());
    }
  }

}
