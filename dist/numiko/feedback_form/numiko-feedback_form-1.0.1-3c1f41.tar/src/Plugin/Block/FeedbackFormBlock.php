<?php

namespace Drupal\feedback_form\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Cache\Cache;

/**
 * Provides a 'Feedback Form' block.
 *
 * @Block(
 *   id = "feedback_form",
 *   admin_label = @Translation("Feedback Form"),
 *   category = @Translation("Forms")
 * )
 */
class FeedbackFormBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'feedback_question' => $this->t("Was this article helpful?"),
      'feedback_block' => "feedbackform_webform",
      'feedback_webform' => "feedback_webform",
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $form['feedback_question'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Feedback question'),
      '#default_value' => $this->configuration['feedback_question'],
      '#description' => $this->t("Question to display on the feedback form for initial feedback"),
    ];
    $form['feedback_block'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Feedback block'),
      '#default_value' => $this->configuration['feedback_block'],
      '#description' => $this->t("Block to show on ajax submission"),
    ];
    $form['feedback_webform'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Feedback webform'),
      '#default_value' => $this->configuration['feedback_webform'],
      '#description' => $this->t("Webform to show on a nojs submission"),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['feedback_question'] = $form_state->getValue('feedback_question');
    $this->configuration['feedback_block'] = $form_state->getValue('feedback_block');
    $this->configuration['feedback_webform'] = $form_state->getValue('feedback_webform');
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    return [
      '#theme' => 'feedback_form',
      '#question' => $this->configuration['feedback_question'],
      '#block' => (isset($this->configuration['feedback_block'])) ? $this->configuration['feedback_block'] : NULL,
      '#webform' => (isset($this->configuration['feedback_webform'])) ? $this->configuration['feedback_webform'] : NULL,
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts() {
    return Cache::mergeContexts(parent::getCacheContexts(), array('url.path'));
  }

}
