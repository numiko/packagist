<?php

namespace Drupal\adestra_webform\Plugin\WebformHandler;

use Drupal\adestra\Client\AdestraContact;
use Drupal\adestra\Client\AdestraCoreTable;
use Drupal\adestra\Client\AdestraList;
use Drupal\adestra\Client\AdestraCampaign;
use Drupal\adestra\Exception\AdestraNoContactFoundException;
use Drupal\webform\Annotation\WebformHandler;
use Drupal\webform\WebformSubmissionInterface;
use Drupal\webform\Plugin\WebformHandlerBase;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\webform\WebformSubmissionConditionsValidatorInterface;
use Drupal\webform\WebformTokenManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Component\Serialization\Json;

/**
 * Webform submission remote post handler to JustGiving.
 *
 * @WebformHandler(
 *   id = "adestra_contact",
 *   label = @Translation("Adestra Contact"),
 *   category = @Translation("External"),
 *   description = @Translation("Subscribe users to an Adestra mailing list."),
 *   cardinality = \Drupal\webform\Plugin\WebformHandlerInterface::CARDINALITY_UNLIMITED,
 *   results = \Drupal\webform\Plugin\WebformHandlerInterface::RESULTS_PROCESSED,
 *   submission = \Drupal\webform\Plugin\WebformHandlerInterface::SUBMISSION_OPTIONAL,
 * )
 */
class AdestraContactWebformHandler extends WebformHandlerBase {

  /**
   * The token manager.
   *
   * @var \Drupal\webform\WebformTokenManagerInterface
   */
  protected $tokenManager;

  /**
   * The adestra contact.
   *
   * @var \Drupal\adestra\Client\AdestraContact
   */
  protected $adestraContact;

  /**
   * The adestra core table.
   *
   * @var \Drupal\adestra\Client\AdestraCoreTable
   */
  protected $adestraCoreTable;

  /**
   * The adestra list.
   *
   * @var \Drupal\adestra\Client\AdestraList
   */
  protected $adestraList;

  /**
   * The adestra list.
   *
   * @var \Drupal\adestra\Client\AdestraCampaign
   */
  protected $adestraCampaign;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = parent::create($container, $configuration, $plugin_id, $plugin_definition);
    $instance->tokenManager = $container->get('webform.token_manager');
    $instance->adestraContact = $container->get('adestra.contact');
    $instance->adestraCoreTable = $container->get('adestra.core_table');
    $instance->adestraList = $container->get('adestra.list');
    $instance->adestraCampaign = $container->get('adestra.campaign');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $formState) {
    $form = parent::buildConfigurationForm($form, $formState);
    $elements = $this->getWebform()->getElementsInitializedFlattenedAndHasValue();

    $form['subscribe_config'] = [
      '#type' => 'details',
      '#open' => TRUE,
      '#title' => "Subscription process",
      '#description' => $this->t('Configure the subscription process.'),
      '#access' => TRUE,
    ];

    $form['subscribe_config']['contact_create'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Create a contact if it does not already exist'),
      '#description' => $this->t("If a user doesn't already exist then create them first"),
      '#default_value' => $this->configuration['contact_create'],
    ];

    $form['subscribe_config']['contact_update'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Update a contact if it does already exist'),
      '#description' => $this->t("If a user exists then update their data"),
      '#default_value' => $this->configuration['contact_update'],
    ];

    $coreTableData = $this->adestraCoreTable->get();
    if ($coreTableData) {
      foreach ($coreTableData['table_columns'] as $column) {
        $coreTableFieldOptions[$column['name']] = ucfirst(str_replace('_', ' ', $column['name']));
      }
    }

    $dataFields = $this->configuration['data_fields'];
    $form['subscribe_config']['data_fields'] = $this->getElementsMappingFields($elements, $dataFields, $coreTableFieldOptions, "User data fields to send to Adestra");

    $form['subscribe_contact'] = [
      '#type' => 'details',
      '#title' => "Subscribe contact to a list",
      '#description' => $this->t('Post data when submission is <b>completed</b> to subscribe contact.'),
      '#access' => TRUE,
    ];
    if ($this->configuration['list_id']) {
      $form['subscribe_contact']['#open'] = TRUE;
    }

    $form['subscribe_contact']['list_subscribe'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Subscribe the user to the selected list'),
      '#description' => $this->t("If a list is selected and this is ticked then subscribe the user to the list"),
      '#default_value' => $this->configuration['list_subscribe'],
    ];

    $form['subscribe_contact']['list_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('List ID'),
      '#description' => $this->t('The token to the webform submission field that contains list ID or list ID itself (number)'),
      '#required' => FALSE,
      '#default_value' => $this->configuration['list_id'],
    ];

    $form['subscribe_contact']['list_unsubscribe'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Unsubscribe the user from any lists not selected'),
      '#description' => $this->t("If a list is not selected then unsubscribe the user from the list"),
      '#default_value' => $this->configuration['list_unsubscribe'],
    ];

    $form['subscribe_contact']['list_field'] = [
      '#type' => 'textfield',
      '#title' => $this->t('List Field'),
      '#description' => $this->t('If populating the list options add the field ID.'),
      '#required' => FALSE,
      '#default_value' => $this->configuration['list_field'],
      '#states' => [
        'visible' => [
          ':input[name="settings[list_unsubscribe]"]' => ['checked' => TRUE],
        ],
      ],
    ];

    if ($this->configuration['list_id']) {
      $list = \Drupal::service('adestra.list')->get($this->configuration['list_id']);
      if ($list) {
        $form['subscribe_contact']['list'] = [
          '#markup' => t("<div><p><b>List name:</b> @name (@id)</p></div>", [
            '@id' => $list['id'],
            '@name' => $list['name'],
          ]),
        ];
      }
    }

    $form['subscribe_contact']['find'] = [
      '#markup' => "<a href=\"/admin/adestra/list/all\"
          class=\"use-ajax\"
          data-dialog-type=\"modal\"
          data-dialog-options=\"{&quot;width&quot;:500,&quot;height&quot;:800}\">
            Retrieve list of lists (can be slow to load)
        </a>",
    ];

    $form['send_campaign'] = [
      '#type' => 'details',
      '#title' => "Send campaign email to contact",
      '#description' => $this->t('Send selected campaign email to contact when submission is <b>completed</b>.'),
      '#access' => TRUE,
    ];
    if ($this->configuration['campaign_id']) {
      $form['send_campaign']['#open'] = TRUE;
    }

    $form['send_campaign']['campaign_id'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Campaign ID'),
      '#empty_option' => "Do not send",
      '#description' => $this->t('The token to the webform submission field that contains campaign ID or campaign itself (number)'),
      '#required' => FALSE,
      '#default_value' => $this->configuration['campaign_id'],
    ];

    if ($this->configuration['campaign_id']) {
      $campaign = \Drupal::service('adestra.campaign')->get($this->configuration['campaign_id']);
      if ($campaign) {
        $form['send_campaign']['campaign'] = [
          '#markup' => t("<div><p><b>Campaign name:</b> @name (@id)</p></div>", [
            '@id' => $campaign['id'],
            '@name' => $campaign['name'],
          ]),
        ];
      }
    }

    $form['send_campaign']['find'] = [
      '#markup' => "<a href=\"/admin/adestra/campaign/all\"
          class=\"use-ajax\"
          data-dialog-type=\"modal\"
          data-dialog-options=\"{&quot;width&quot;:500,&quot;height&quot;:800}\">
            Retrieve list of campaigns (can be slow to load)
        </a>",
    ];

    $form['send_campaign']['launch_reference'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Launch Reference'),
      '#description' => $this->t('A reference for the launch - if used it will be suffixed with the week number for reporting purposes'),
      '#default_value' => $this->configuration['launch_reference'],
    ];

    $campaignFields = $this->configuration['campaign_fields'];
    $form['send_campaign']['campaign_fields'] = $this->getElementsMappingFields($elements, $campaignFields, $coreTableFieldOptions, "Campaign Transaction data fields to send to Adestra");

    return $this->setSettingsParents($form);
  }

  /**
   * Get element mapping fields.
   *
   * Get a field for each webform elements to allow fields to be mapped to
   * an adestra field.
   */
  protected function getElementsMappingFields($elements, $fieldData, $options, $title) {
    $fields = [
      '#type' => 'details',
      '#title' => $title,
      '#description' => $this->t('Select the fields you wish to map to fields in Adestra'),
    ];
    foreach ($elements as $elementKey => $element) {
      if ($element['#webform_composite'] === TRUE && isset($element['#webform_composite_elements'])) {
        foreach ($element['#webform_composite_elements'] as $compositeElementKey => $compositeElement) {
          $compositeElementKey = "{$elementKey}__{$compositeElementKey}";
          $fields[$compositeElementKey] = [
            '#type' => 'webform_select_other',
            '#empty_option' => "Do not send",
            '#title' => $element['#title'] . ': ' . $compositeElement['#title'],
            '#options' => $options,
            '#description' => "Select an Adestra field to map the value of '{$compositeElementKey}' to.",
            '#default_value' => (isset($fieldData[$compositeElementKey])) ? $fieldData[$compositeElementKey] : '',
          ];
        }
      }
      else {
        $fields[$elementKey] = [
          '#type' => 'webform_select_other',
          '#empty_option' => "Do not send",
          '#title' => $element['#title'],
          '#options' => $options,
          '#description' => "Select an Adestra field to map the value of '{$elementKey}' to.",
          '#default_value' => (isset($fieldData[$elementKey])) ? $fieldData[$elementKey] : '',
        ];
      }
    }
    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    $config = parent::defaultConfiguration();
    $config['contact_create'] = TRUE;
    $config['contact_update'] = FALSE;
    $config['list_subscribe'] = FALSE;
    $config['list_unsubscribe'] = FALSE;
    $config['list_id'] = '';
    $config['list_field'] = '';
    $config['data_fields'] = '';
    $config['campaign_id'] = '';
    $config['launch_reference'] = '';
    $config['campaign_fields'] = '';
    return $config;
  }

  /**
   * {@inheritdoc}
   */
  public function getSummary() {
    $settings['list_id'] = $this->configuration['list_id'];
    $settings['campaign_id'] = $this->configuration['campaign_id'];

    return [
      '#settings' => $settings,
    ] + parent::getSummary();
  }

  /**
   * {@inheritdoc}
   */
  public function validateConfigurationForm(array &$form, FormStateInterface $formState) {
    $this->validateAdestraConfigurationForm($form, $formState);
    parent::validateConfigurationForm($form, $formState);
  }

  /**
   * Additional Adestra configuration validation.
   */
  protected function validateAdestraConfigurationForm(array &$form, FormStateInterface $formState) {
    $values = $formState->getValues();

    $values['data_fields'] = $values['subscribe_config']['data_fields'];
    unset($values['subscribe_config']['data_fields']);

    $adestraFields = array_flip($values['data_fields']);
    if (empty($adestraFields['email'])) {
      $formState->setErrorByName('data_fields', $this->t('Please select which field should be used to identify email.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $formState) {
    parent::submitConfigurationForm($form, $formState);

    $values = $formState->getValues();

    foreach ($this->configuration as $name => $value) {
      if (isset($values[$name])) {
        $this->configuration[$name] = $values[$name];
      }
    }
    $this->configuration['data_fields'] = array_filter($values['subscribe_config']['data_fields']);
    $this->configuration['campaign_fields'] = array_filter($values['send_campaign']['campaign_fields']);
  }

  /**
   * {@inheritdoc}
   */
  public function postSave(WebformSubmissionInterface $webformSubmission, $update = TRUE) {
    try {
      $state = $webformSubmission->getWebform()->getSetting('results_disabled') ? WebformSubmissionInterface::STATE_COMPLETED : $webformSubmission->getState();
      $this->remotePost($state, $webformSubmission);
    }
    catch (AdestraNoContactFoundException $e) {
      $context['@message'] = $e->getMessage();
      $this->loggerFactory->get('adestra_webform')->notice('Unable to find / create adestra contact: @message.', $context);
    }
  }

  /**
   * {@inheritdoc}
   */
  protected function remotePost($state, WebformSubmissionInterface $webformSubmission) {
    // Create an Adestra contact and subscribe.
    $userData = $this->getUserData($webformSubmission);
    $contactId = $this->getContact($userData);
    if ($this->configuration['list_id'] && $this->configuration['list_subscribe']) {
      $listIds = explode(',', $this->substituteConfigurationFieldValueFromToken($webformSubmission, 'list_id'));
      foreach ($listIds as $listId) {
        $this->subscribeUser($listId, $contactId);
      }
    }

    if ($this->configuration['list_field'] && $this->configuration['list_unsubscribe']) {
      $listIds = $this->getUnsubscribeLists($webformSubmission, $this->configuration['list_field']);
      foreach ($listIds as $listId => $name) {
        $this->unSubscribeUser($listId, $contactId);
      }
    }

    if ($this->configuration['campaign_id']) {
      $transactionData = $this->getTransactionData($webformSubmission);
      $campaignId = $this->substituteConfigurationFieldValueFromToken($webformSubmission, 'campaign_id');
      $this->sendCampaignToContact($campaignId, $contactId, $transactionData);
    }
  }

  /**
   * Get the user data from the data fields.
   */
  protected function getUserData(WebformSubmissionInterface $webformSubmission) {
    $userData = [];
    foreach ($this->configuration['data_fields'] as $submissionField => $adestraField) {
      $userData[$adestraField] = $this->getElementData($webformSubmission, $submissionField);
    }
    return $userData;
  }

  /**
   * Get the transaction data from the data fields.
   */
  protected function getTransactionData(WebformSubmissionInterface $webformSubmission) {
    $transactionData = [];
    foreach ($this->configuration['campaign_fields'] as $submissionField => $adestraField) {
      $transactionData[$adestraField] = $this->getElementData($webformSubmission, $submissionField);
    }
    return $transactionData;
  }

  /**
   * Get the element value.
   */
  protected function getElementData(WebformSubmissionInterface $webformSubmission, $field) {
    if (strpos($field, '__')) {
      [$parentField, $compositeField] = explode('__', $field);
      $result = $webformSubmission->getElementData($parentField);
      return (isset($result[$compositeField])) ? $result[$compositeField] : NULL;
    }
    return $webformSubmission->getElementData($field);
  }

  /**
   * Use the user data to subscribe the user (and create / update details).
   */
  protected function getContact($userData) {
    // Check if the user exists within Adestra.
    $adestraContact = $this->adestraContact->search(['email' => $userData['email']]);
    $adestraContactId = (isset($adestraContact['id'])) ? $adestraContact['id'] : NULL;
    if ($adestraContactId) {
      if ($this->configuration['contact_update']) {
        // Update the users data.
        $this->adestraContact->update($adestraContactId, $userData);
      }
    }
    elseif ($this->configuration['contact_create']) {
      // Create a new Adestra user.
      $adestraContactId = $this->adestraContact->create($userData);
      if (!$adestraContactId) {
        throw new AdestraNoContactFoundException("Contact not found and could not be created");
      }
    }
    else {
      throw new AdestraNoContactFoundException("Contact not found and not set to create");
    }
    if (!$adestraContactId) {
      throw new AdestraNoContactFoundException("Contact not found and not created");
    }
    return $adestraContactId;
  }

  /**
   * Subscribe the user to the list ID.
   */
  protected function subscribeUser($listId, $contactId) {
    // Subscribe the user to the list.
    $this->adestraContact->subscribe($contactId, $listId);
  }

  /**
   * Unsubscribe the user from the list ID.
   */
  protected function unSubscribeUser($listId, $contactId) {
    // Unsubscribe the user from the list.
    $this->adestraContact->unsubscribe($contactId, $listId);
  }

  /**
   * Send the campaign to the contact.
   */
  protected function sendCampaignToContact($campaignId, $contactId, $transactionData) {
    // Send the campaign to a single contact.
    $options = [];
    if ($this->configuration['launch_reference']) {
      $options['launch_reference'] = $this->configuration['launch_reference'] . date(' W Y');
    }
    $this->adestraCampaign->sendSingle($campaignId, $contactId, $transactionData, $options);
  }

  /**
   * Get a configuration value and substitute from tokens.
   */
  protected function substituteConfigurationFieldValueFromToken(WebformSubmissionInterface $webformSubmission, $field) {
    if (!empty($this->configuration[$field])) {
      return $this->tokenManager->replaceNoRenderContext(
        $this->configuration[$field],
        $webformSubmission
      );
    }
  }

  /**
   * Get the lists to unsubscribe a user to.
   */
  protected function getUnsubscribeLists(WebformSubmissionInterface $webformSubmission, $element) {
    $elements = $webformSubmission->getWebform()->getElementsDecoded();
    $listIdOptions = $elements[$element]['#options'];
    $selectedOption = $webformSubmission->getElementData($element);
    return array_diff_key($listIdOptions, array_flip((array) $selectedOption));
  }

}
