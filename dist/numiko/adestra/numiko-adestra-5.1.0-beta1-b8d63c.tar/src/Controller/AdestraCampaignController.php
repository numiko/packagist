<?php

namespace Drupal\adestra\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\adestra\Client\AdestraCampaign;

/**
 * Provides route responses for webform.
 */
class AdestraCampaignController extends ControllerBase implements ContainerInjectionInterface {

  public function __construct(protected AdestraCampaign $adestraCampaign) {}

  /**
   * Get a list of lists.
   */
  public function all() {
    return [
      '#theme' => 'item_list',
      '#items' => $this->getCampaignOptions(),
    ];
  }

  /**
   * Get the list options.
   */
  private function getCampaignOptions($listId = NULL) {
    $options = [];
    $i = 1;
    $maxNumberOfResultsPages = 6;
    do {
      $resultsFound = FALSE;
      $campaignsData = $this->adestraCampaign->getLaunched($listId);
      if (!empty($campaignsData)) {
        $resultsFound = TRUE;
        foreach ($campaignsData as $campaign) {
          $options[$campaign['id']] = "{$campaign['name']} ({$campaign['id']})";
        }
      }
      if ($i > $maxNumberOfResultsPages) {
        break;
      }
      $i++;
    } while ($resultsFound);

    natcasesort($options);

    return $options;
  }

}
