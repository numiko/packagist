<?php

namespace Drupal\adestra\Client;

/**
 * Functions for creating and subscribing adestra contacts.
 */
class AdestraWorkspace {

  /**
   * Instantiate an Adestra Workspace.
   */
  public function __construct(protected readonly AdestraClient $adestraClient) {}

  /**
   * Find all workspaces.
   */
  public function all() {
    $response = $this->adestraClient->request('workspace.all');
    $value = $response->val->me['array'];
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    else {
      // Return array of results.
      return array_map($this->adestraClient->xmlRpcValueToArray(...), $value);
    }
  }

}
