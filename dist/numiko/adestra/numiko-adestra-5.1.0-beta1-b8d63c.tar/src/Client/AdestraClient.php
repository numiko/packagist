<?php

namespace Drupal\adestra\Client;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\adestra\Map\XmlRpcValueMap;
use PhpXmlRpc\Client;
use PhpXmlRpc\Request;
use PhpXmlRpc\Value;

/**
 * Handle remote calls to the messagefocus API.
 */
class AdestraClient {

  protected ?Client $xmlrpc = NULL;

  /**
   * Create an instance of an AdestraClient.
   */
  public function __construct(
    protected readonly XmlRpcValueMap $xmlRpcValueMap,
    protected readonly ConfigFactoryInterface $config,
  ) {}

  /**
   * Get the core table id.
   */
  public function getTableId() {
    return ($this->config->get('adestra.settings')->get('table_id')) ?: "";
  }

  /**
   * Send an XmlRpc request.
   */
  public function request($endpoint, $params = []) {
    $options = $this->arrayToValues($params);
    $msg = new Request($endpoint, $options);
    if (!$this->xmlrpc) {
      $this->initClient();
    }
    return $this->xmlrpc->send($msg);
  }

  /**
   * Convert the XmlRpcValue to a data array.
   */
  public function xmlRpcValueToArray(Value $value): array {
    return $this->xmlRpcValueMap->valueToArray($value);
  }

  /**
   * Initialise the XmlRpc client.
   */
  protected function initClient(): void {
    $config = $this->config->get('adestra.settings');
    $account = ($config->get('account')) ?: "";
    $username = ($config->get('username')) ?: "";
    $password = ($config->get('password')) ?: "";
    $xmlrpc = new Client("http://{$account}.{$username}:{$password}@app.adestra.com/api/xmlrpc");
    $debug = ($config->get('debug')) ?: FALSE;
    $xmlrpc->setDebug($debug);
    $this->xmlrpc = $xmlrpc;
  }

  /**
   * Convert the params to values ready to send.
   */
  protected function arrayToValues(array $array = []): array {
    $values = [];
    foreach ($array as $key => $value) {
      if (is_array($value)) {
        $value = $this->arrayToValues($value);
        $values[$key] = new Value($value, $this->isAssociative($value) ? 'struct' : 'array');
      }
      if (is_numeric($value)) {
        $values[$key] = new Value($value, 'int');
      }
      if (is_string($value)) {
        $values[$key] = new Value($value, 'string');
      }
      if (is_bool($value)) {
        $values[$key] = new Value($value, 'boolean');
      }
    }
    return $values;
  }

  /**
   * Is the parameter an associative array.
   */
  protected function isAssociative(array $arr): bool {
    if (!is_array($arr)) {
      return FALSE;
    }
    return !isset($arr[0]);
  }

}
