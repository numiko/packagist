<?php

namespace Drupal\adestra\Client;

/**
 * Functions for creating and subscribing adestra contacts.
 */
class AdestraCoreTable {

  /**
   * Instantiate an Adestra Factory.
   */
  public function __construct(protected readonly AdestraClient $adestraClient) {}

  /**
   * Retrieve a core table item.
   */
  public function get() {
    $response = $this->adestraClient->request('coreTable.get', ['table_id' => $this->adestraClient->getTableId()]);
    $value = $response->val;
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    else {
      $data = $this->adestraClient->xmlRpcValueToArray($value);
      return $data;
    }
  }

}
