<?php

namespace Drupal\adestra\Client;

/**
 * Functions for creating and subscribing adestra contacts.
 */
class AdestraCampaign {

  /**
   * Instantiate an Adestra Contact.
   */
  public function __construct(protected readonly AdestraClient $adestraClient) {}

  /**
   * Send a campaign to the given contact id.
   */
  public function sendSingle($campaignId, $contactId, $transactionData, $options): bool {
    // campaign.sendSingle(campaign_id,
    // contact_id,
    // transaction_data,
    // send_single_options)
    $response = $this->adestraClient->request('campaign.sendSingle', [
      'campaign_id' => $campaignId,
      'contact_id' => $contactId,
      'transaction_data' => $transactionData,
      'send_single_options' => $options,
    ]);
    $result = NULL;
    if (isset($response->val) && isset($response->val->me)) {
      $values = array_values($response->val->me);
      $result = array_shift($values);
    }
    return $result == 1;
  }

  /**
   * Retrieve a list of campaigns.
   */
  public function all() {
    $response = $this->adestraClient->request('campaign.all');
    $value = $response->val;
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    else {
      $data = $this->adestraClient->xmlRpcValueToArray($value);
      return $data;
    }
  }

  /**
   * Retrieve a single campaigns.
   */
  public function get($campaignId) {
    $response = $this->adestraClient->request('campaign.get', [
      'campaign_id' => $campaignId,
    ]);
    $value = $response->val;
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    else {
      $data = $this->adestraClient->xmlRpcValueToArray($value);
      return $data;
    }
  }

  /**
   * Retrieve a list of campaigns.
   */
  public function getLaunched($listId = NULL) {
    $searchArgs = [
      'launched' => 1,
    ];
    if ($listId) {
      $searchArgs['list_id'] = $listId;
    }
    return $this->search($searchArgs);
  }

  /**
   * Use the campaign search.
   */
  public function search($searchArgs = []) {
    $response = $this->adestraClient->request('campaign.search', [
      'search_args' => $searchArgs,
    ]);
    $value = $response->val;
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    else {
      $data = $this->adestraClient->xmlRpcValueToArray($value);
      return $data;
    }
  }

}
