<?php

declare(strict_types=1);

namespace Drupal\adestra_webform\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hooks for webform Adestra integration.
 */
final class ThemeHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'webform_handler_adestra_contact_summary' => [
        'variables' => [
          'settings' => NULL,
          'handler' => NULL,
        ],
      ],
    ];
  }

}
