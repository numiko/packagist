<?php

namespace Drupal\adestra\Client;

use Drupal\adestra\Client\AdestraClient;

/**
 * Functions for creating and subscribing adestra contacts.
 */
class AdestraList {

  protected $adestraClient;

  /**
   * Instantiate an Adestra List.
   */
  public function __construct(AdestraClient $adestra_client) {
    $this->adestraClient = $adestra_client;
  }

  /**
   * Find all lists related to the current core table.
   */
  public function all($paging = []) {
    $searchArgs = [
      'table_id' => $this->adestraClient->getTableId(),
    ];
    $response = $this->adestraClient->request('list.search', [
      'search_args' => $searchArgs,
      'paging_args' => $paging,
    ]);
    $value = $response->val->me['array'];
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    else {
      // Return array of results.
      return array_map([$this->adestraClient, 'xmlRpcValueToArray'], $value);
    }
  }

  /**
   * Retrieve a single campaigns.
   */
  public function get($listId) {
    $response = $this->adestraClient->request('list.get', [
      'list_id' => $listId,
    ]);
    $value = $response->val;
    if (empty($value)) {
      // Nothing found.
      return NULL;
    }
    else {
      $data = $this->adestraClient->xmlRpcValueToArray($value);
      return $data;
    }
  }

}
