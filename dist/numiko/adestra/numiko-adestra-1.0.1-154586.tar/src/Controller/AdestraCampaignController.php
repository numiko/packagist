<?php

namespace Drupal\adestra\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\adestra\Client\AdestraCampaign;

/**
 * Provides route responses for webform.
 */
class AdestraCampaignController extends ControllerBase implements ContainerInjectionInterface {

  /**
   * The adestra campaign.
   *
   * @var \Drupal\adestra\Client\AdestraCampaign
   */
  protected $adestraCampaign;

  /**
   * Constructs a AdestraListController object.
   */
  public function __construct(AdestraCampaign $adestra_campaign) {
    $this->adestraCampaign = $adestra_campaign;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('adestra.campaign')
    );
  }

  /**
   * Get a list of lists.
   */
  public function all() {
    return [
      '#theme' => 'item_list',
      '#items' => $this->getCampaignOptions(),
    ];
  }

  /**
   * Get the list options.
   */
  private function getCampaignOptions($listId = NULL) {
    $options = [];
    $i = 1;
    $maxNumberOfResultsPages = 6;
    do {
      $resultsFound = FALSE;
      $campaignsData = $this->adestraCampaign->getLaunched($listId);
      if (!empty($campaignsData)) {
        $resultsFound = TRUE;
        foreach ($campaignsData as $campaign) {
          $options[$campaign['id']] = "{$campaign['name']} ({$campaign['id']})";
        }
      }
      if ($i > $maxNumberOfResultsPages) {
        break;
      }
      $i++;
    } while ($resultsFound);

    natcasesort($options);

    return $options;
  }

}
