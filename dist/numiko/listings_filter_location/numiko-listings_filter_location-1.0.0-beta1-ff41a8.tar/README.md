# Listings Filter Location

This module extends the Listings Filter module with location-based filtering capabilities.

## Requirements

- Drupal 9 or 10
- Listings Filter module
- Search API module
- Search API Location module

## Installation

1. Install the module via Composer or by placing it in the modules/custom directory.
2. Enable the module through the Drupal UI or using Drush: `drush en listings_filter_location`.

## Usage

### URL Parameters

The module accepts the following URL parameters to filter results:

- `lat` - Latitude (required for location filtering)
- `lng` - Longitude (required for location filtering)
- `distance` - Distance in kilometers (optional, defaults to 10km)
- `sort_by_distance` - Boolean to sort results by distance (optional, defaults to TRUE)
- `location_field` - The field to use for location (optional, defaults to 'field_location')

### Example Usage

```
/listing-page?lat=51.5074&lng=-0.1278&distance=5&sort_by_distance=1
```

In order to allow this to work currently we require the passing of a lat/lng value pair, this
could be achieved by passing it in from the query params on the page, by updating the vue code
in `useQueryBuilder` inside `pageQuery`:

```
    let params = new URLSearchParams(document.location.search);
    if (params.get('lat')) {
      pageQueryParams.append('lat', params.get('lat'));
    }
    if (params.get('lng')) {
      pageQueryParams.append('lng', params.get('lng'));
    }
    if (params.get('distance')) {
      pageQueryParams.append('distance', params.get('distance'));
    }
```

## Integration Notes

1. Make sure your content type has a location field (e.g., Geofield) indexed in Search API.
2. Configure your Views and Search API indexes to include the location field.
3. The search_api_location module must be properly configured with the right field mappings.

## Troubleshooting

- If location filtering is not working, check that your Search API backend supports geospatial queries.
- For Solr backends, ensure the Solr server has geospatial capabilities enabled.
- Check Search API index configuration to ensure location fields are properly indexed.