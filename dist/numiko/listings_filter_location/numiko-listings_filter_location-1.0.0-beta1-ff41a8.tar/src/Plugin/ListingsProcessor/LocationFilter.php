<?php

declare(strict_types=1);

namespace Drupal\listings_filter_location\Plugin\ListingsProcessor;

use Psr\Log\LoggerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\SubformStateInterface;
use Drupal\search_api\Query\QueryInterface;
use Drupal\search_api_location\LocationUtility;
use Drupal\listings_filter\ListingsProcessorBase;
use Symfony\Component\HttpFoundation\RequestStack;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides location-based filtering for listings.
 *
 * @ListingsProcessor(
 *   id = "location_filter",
 *   name = @Translation("Location Filter"),
 *   description = @Translation("Adds location-based filtering to listings."),
 *   stages = {
 *     "alter_query" = 0,
 *     "preprocess_listing_query_settings" = 0
 *   }
 * )
 */
class LocationFilter extends ListingsProcessorBase implements ContainerFactoryPluginInterface {

  use StringTranslationTrait;

  /**
   * The current request.
   *
   * @var \Symfony\Component\HttpFoundation\Request
   */
  protected $request;

  /**
   * The logger instance.
   *
   * @var \Psr\Log\LoggerInterface
   */
  protected $logger;

  /**
   * Constructs a LocationFilter object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Symfony\Component\HttpFoundation\RequestStack $request_stack
   *   The request stack.
   * @param \Psr\Log\LoggerInterface $logger
   *   The logger service.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    RequestStack $request_stack,
    LoggerInterface $logger
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->request = $request_stack->getCurrentRequest();
    $this->logger = $logger;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('request_stack'),
      $container->get('logger.channel.listings_filter_location')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function alterQuery(QueryInterface &$query, array $settings = []): void {
    // Check if we have location parameters.
    if (empty($settings['location']['lat']) || empty($settings['location']['lng'])) {
      return;
    }

    try {
      $lat = (float) $settings['location']['lat'];
      $lng = (float) $settings['location']['lng'];
      $distance = (float) ($settings['location']['distance'] ?? $this->configuration['default_distance']);
      $field = $settings['location']['field'] ?? $this->configuration['location_field'];

      // Verify the field exists in the index.
      $index = $query->getIndex();
      if (!$index->getField($field)) {
        $this->logger->warning('Location field @field not found in index @index', [
          '@field' => $field,
          '@index' => $index->id(),
        ]);
        return;
      }

      // Get the backend used by this index to determine how to add location filter.
      $backend = $index->getServerInstance()->getBackend();
      $backend_id = $backend->getPluginId();

      // Add location filter to the search query.
      if ($backend_id === 'search_api_solr') {
        // Use Solr-specific distance filter.
        $this->addSolrLocationFilter($query, $field, $lat, $lng, $distance);
      }
      else {
        // Use generic location filter.
        $this->addGenericLocationFilter($query, $field, $lat, $lng, $distance);
      }

      // Add distance sort if requested.
      if (!empty($settings['location']['sort'])) {
        $this->addDistanceSort($query, $field, $lat, $lng, $backend_id);
      }
    }
    catch (\Exception $e) {
      $this->logger->error('Error adding location filter: @message', ['@message' => $e->getMessage()]);
    }
  }

  /**
   * Adds a Solr-specific location filter to the query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The Search API query to alter.
   * @param string $field
   *   The location field name.
   * @param float $lat
   *   The latitude.
   * @param float $lng
   *   The longitude.
   * @param float $distance
   *   The distance in kilometers.
   */
  protected function addSolrLocationFilter(QueryInterface $query, string $field, float $lat, float $lng, float $distance): void {
    // Utilise search_api_solr module handling of distance filtering.
    $location_options[] = [
      'field' => $field,
      'lat' => $lat,
      'lon' => $lng,
      'radius' => $distance,
    ];
    $query->setOption('search_api_location', $location_options);
  }

  /**
   * Adds a generic location filter to the query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The Search API query to alter.
   * @param string $field
   *   The location field name.
   * @param float $lat
   *   The latitude.
   * @param float $lng
   *   The longitude.
   * @param float $distance
   *   The distance in kilometers.
   */
  protected function addGenericLocationFilter(QueryInterface $query, string $field, float $lat, float $lng, float $distance): void {
    // For database or other backends, we use the generic location filter.
    $operator = 'location';

    // We need to check if search_api_location provides the right filter operator.
    if (!LocationUtility::locationFilterOperatorAvailable($query, $operator)) {
      $this->logger->warning('Location filter operator not available for this query.');
      return;
    }

    // Create a location object that will be properly handled by the operator
    // This format is compatible with search_api_location module
    $location = [
      'lat' => $lat,
      'lon' => $lng,
      'radius' => $distance,
    ];

    // Use the LocationUtility to add the location filter
    LocationUtility::addLocationFilter($query, $field, $location, $operator);

    $this->logger->info('Added generic location filter for field @field with radius @radius', [
      '@field' => $field,
      '@radius' => $distance,
    ]);
  }

  /**
   * Adds a distance-based sort to the query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The Search API query to alter.
   * @param string $field
   *   The location field name.
   * @param float $lat
   *   The latitude.
   * @param float $lng
   *   The longitude.
   * @param string $backend_id
   *   The backend ID.
   */
  protected function addDistanceSort(QueryInterface $query, string $field, float $lat, float $lng, string $backend_id): void {
    // Add the appropriate sort based on the backend.
    if ($backend_id === 'search_api_solr') {
      // For solr we rely on search_api_solr native addition of a field value
      // suffixed with '__distance' for the query.
      $query->sort($field . '__distance');
    }
    else {
      // For non-Solr backends, we rely on search_api_location for distance sorting
      // Create a location object compatible with search_api_location
      $location = [
        'lat' => $lat,
        'lon' => $lng,
      ];

      // Use LocationUtility to add the sort
      if (method_exists(LocationUtility::class, 'addLocationSort')) {
        LocationUtility::addLocationSort($query, $field, $location);

        $this->logger->info('Added generic location sort for field @field', [
          '@field' => $field,
        ]);
      }
      else {
        // Fallback if the method doesn't exist
        $query->sort($field, 'ASC');
        $this->logger->warning('Falling back to basic field sort for location field @field', [
          '@field' => $field,
        ]);
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function preprocessListingQuerySettings(array &$settings): void {
    // Extract location parameters from the request.
    if ($this->request->query->has('lat') && $this->request->query->has('lng')) {
      $settings['location'] = [
        'lat' => (float) $this->request->query->get('lat'),
        'lng' => (float) $this->request->query->get('lng'),
        'distance' => (float) $this->request->query->get('distance', $this->configuration['default_distance']),
        'sort' => (bool) $this->request->query->get('sort_by_distance', $this->configuration['distance_sort']),
        'field' => $this->request->query->get('location_field', $this->configuration['location_field']),
      ];


      $this->logger->info('Location filter added with parameters: @params', [
        '@params' => print_r($settings['location'], TRUE),
      ]);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $subform, SubformStateInterface $processorFormState): array {
    $subform['location_field'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Location field'),
      '#description' => $this->t('The field in the Search API index that contains location data.'),
      '#default_value' => $this->configuration['location_field'] ?? 'field_location',
      '#required' => TRUE,
    ];

    $subform['default_distance'] = [
      '#type' => 'number',
      '#title' => $this->t('Default distance (km)'),
      '#description' => $this->t('The default distance in kilometers to use when filtering by location.'),
      '#default_value' => $this->configuration['default_distance'] ?? 10,
      '#min' => 0.1,
      '#step' => 0.1,
      '#required' => TRUE,
    ];

    $subform['distance_sort'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Sort by distance'),
      '#description' => $this->t('Use the distance to sort the results.'),
      '#default_value' => $this->configuration['distance_sort'] ?? FALSE,
    ];

    return $subform;
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state) {
    $this->configuration['location_field'] = $form_state->getValue('location_field');
    $this->configuration['default_distance'] = $form_state->getValue('default_distance');
    $this->configuration['distance_sort'] = $form_state->getValue('distance_sort');
  }

}