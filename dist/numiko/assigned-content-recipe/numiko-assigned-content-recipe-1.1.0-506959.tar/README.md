# Assigned Content Field Recipe

A Drupal recipe that adds assignees and due date fields to all content types with a content dashboard for viewing assigned content.

## Overview

This recipe extends Drupal sites with content assignment capabilities by:

- Adding `field_assignees` (entity reference to users) to all node types
- Adding `field_due_date` (datetime field) to all node types  
- Creating an "Assigned Content" dashboard view at `/admin/content/dashboard`
- Grouping assignment fields under a "Workflow" sidebar in edit forms

## Features

- **Multi-user assignments**: Content can be assigned to multiple users
- **Due date tracking**: Set and track content due dates
- **Content moderation integration**: Works with Drupal's content moderation workflow
- **Dashboard view**: Filterable list showing assigned content with moderation states
- **User-specific filtering**: Dashboard defaults to show current user's assignments

## Requirements

- Drupal core modules: `node`, `user`, `field`, `field_group`
- `numiko/assigned_content` module (^1.0)
- Content moderation workflow configured

## Installation

This is a Drupal recipe. Install via recipe-tools

## What Gets Added

### Fields
- `field_assignees`: Multi-value entity reference field targeting users
- `field_due_date`: Single-value datetime field (date only)

### Configuration
- Fields excluded from `homepage` and `listing` content types
- Fields grouped under "Workflow" sidebar in edit forms
- Fields hidden from default view displays
- "Assigned Content" view accessible at `/admin/content/dashboard`

### Permissions
Users need "view own unpublished content" permission to access the dashboard.

## Usage

1. Edit any content and assign users via the "Assignees" field
2. Set due dates using the "Due date" field  
3. Access the dashboard at `/admin/content/dashboard` to view assigned content
4. Filter by title, content type, moderation state, or language
5. Content is sorted by due date (earliest first)