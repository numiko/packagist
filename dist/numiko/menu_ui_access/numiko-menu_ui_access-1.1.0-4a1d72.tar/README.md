# Menu UI Access Module

## Description
The Menu UI Access module provides additional functionality for managing menu access permissions in the user interface.

## Features
- Allows content editors to be granted access to add / edit content pages to menus without requiring administer menu access.
- Supports granular control over menu access permissions for different user roles.
