# Content Dashboards

This module encompasses sub-modules to facilitate various content dashboards used frequently across sites.