# Expired Content

The content notifications module suggests it handles this, though currently there is a bug when in use with workflows that prevents it populating the field.

See https://www.drupal.org/project/content_notify/issues/3160951 and add the patch.

However once patched it will work for new / updated data, therefore allowing an email to be added to the settings and/or a dashboard view to be configured to show “expired content” (this dashboard is configured by installing this module).
