# Rich Text List Recipe

This recipe installs the necessary configuration to add a Rich Text List Slice.

## Installation

Apply the recipe from the `docroot` folder.

`drush recipes/contrib/rich-text-list-recipe`
