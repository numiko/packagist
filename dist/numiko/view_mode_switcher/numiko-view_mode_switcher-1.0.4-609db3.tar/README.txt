# View Mode Switcher

## Overview
Adds the functionality to create an extra view mode.