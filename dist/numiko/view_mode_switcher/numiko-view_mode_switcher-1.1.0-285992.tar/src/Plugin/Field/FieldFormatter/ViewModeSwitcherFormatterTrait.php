<?php

namespace Drupal\view_mode_switcher\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Implementation of the 'view_mode_switcher' formatter in a trait.
 */
trait ViewModeSwitcherFormatterTrait {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings(): array {
    return [
      'teaser_count' => 0,
      'view_mode_switch' => 'default',
      'view_mode_expression' => '==',
    ] + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state): array {
    $elements = parent::settingsForm($form, $form_state);

    $elements['teaser_count'] = [
      '#title' => $this->t('Number of teasers'),
      '#type' => 'number',
      '#min' => 0,
      '#default_value' => $this->getSetting('teaser_count'),
      '#description' => $this->t('When to switch view modes'),
    ];

    /** @var string $targetType */
    $targetType = $this->getFieldSetting('target_type');
    $elements['view_mode_switch'] = [
      '#type' => 'select',
      '#options' => $this->entityDisplayRepository->getViewModeOptions($targetType),
      '#title' => $this->t('View mode switch'),
      '#description' => $this->t('The view mode to switch to'),
      '#default_value' => $this->getSetting('view_mode_switch'),
      '#required' => TRUE,
    ];

    $elements['view_mode_expression'] = [
      '#type' => 'select',
      '#options' => [
        '==' => $this->t('== (Equal)'),
        '!=' => $this->t('!= (Not equal)'),
        '<' => $this->t('< (Less than)'),
        '>' => $this->t('> (Greater than)'),
        '<=' => $this->t('<= (Less than or equal to)'),
        '>=' => $this->t('>= (Greater than or equal to)'),
      ],
      '#title' => $this->t('Expression selector'),
      '#description' => $this->t('Expression selector'),
      '#default_value' => $this->getSetting('view_mode_expression'),
      '#required' => TRUE,
    ];

    return $elements;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $operator = match ($this->getSetting('view_mode_expression')) {
      '==' => $this->t('equal to'),
      '!=' => $this->t('not equal to'),
      '<' => $this->t('less than'),
      '>' => $this->t('greater than'),
      '<=' => $this->t('less than or equal to'),
      '>=' => $this->t('greater than or equal to'),
      default => $this->t('invalid operator to')
    };

    /** @var string $targetType */
    $targetType = $this->getFieldSetting('target_type');
    $viewModes = $this->entityDisplayRepository->getViewModeOptions($targetType);
    $viewModeSwitch = $viewModes[$this->getSetting('view_mode_switch')];
    $viewMode = $viewModes[$this->getSetting('view_mode')];

    return [
      $this->t('When entity count is %operator @count show %viewmode1.', [
        '%operator' => $operator,
        '@count' => $this->getSetting('teaser_count'),
        '%viewmode1' => $viewModeSwitch,
      ]),
      $this->t('Otherwise show %viewmode2.', ['%viewmode2' => $viewMode]),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $itemsValue = $items->getValue();

    if (is_array($itemsValue) && !empty($itemsValue)) {
      $defaultViewMode = $this->getSetting('view_mode');
      $newViewMode = $this->getSetting('view_mode_switch');
      $expression = $this->getSetting('view_mode_expression');
      $teaserCount = $this->getSetting('teaser_count');
      $this->setSetting('view_mode', $defaultViewMode);

      $count = count($itemsValue);
      $switchViewMode = match ($expression) {
        '==' => $count == $teaserCount,
        '!=' => $count != $teaserCount,
        '<' => $count < $teaserCount,
        '>' => $count > $teaserCount,
        '>=' => $count >= $teaserCount,
        '<=' => $count <= $teaserCount,
        default => FALSE
      };

      if ($switchViewMode) {
        $this->setSetting('view_mode', $newViewMode);
      }
    }

    return parent::viewElements($items, $langcode);
  }

}
