<?php

namespace Drupal\view_mode_switcher\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\Attribute\FieldFormatter;
use Drupal\Core\Field\Plugin\Field\FieldFormatter\EntityReferenceEntityFormatter;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Plugin implementation of the 'view_mode_switcher' formatter.
 */
#[FieldFormatter(
  id: 'view_mode_switcher',
  label: new TranslatableMarkup('Rendered entity with view mode switcher'),
  description: new TranslatableMarkup(
    'Entity reference formatter that changes a view mode based upon whether one or multiple items exist in that entity reference field.'
  ),
  field_types: ['entity_reference'],
)]
class ViewModeSwitcherFormatter extends EntityReferenceEntityFormatter {
  use ViewModeSwitcherFormatterTrait;

}
