<?php

namespace Drupal\view_mode_switcher\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\Attribute\FieldFormatter;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\entity_reference_revisions\Plugin\Field\FieldFormatter\EntityReferenceRevisionsEntityFormatter;

/**
 * Plugin implementation of the 'entity_reference_revisions_view_mode_switcher' formatter.
 */
#[FieldFormatter(
  id: 'entity_reference_revisions_view_mode_switcher',
  label: new TranslatableMarkup('Rendered entity with view mode switcher'),
  description: new TranslatableMarkup(
    'Entity reference formatter that changes a view mode based upon whether one or multiple items exist in that entity reference field.'
  ),
  field_types: ['entity_reference_revisions'],
)]
class EntityReferenceRevisionsViewModeSwitcherFormatter extends EntityReferenceRevisionsEntityFormatter {
  use ViewModeSwitcherFormatterTrait;

}
