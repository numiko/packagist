# Call to Action Slice Recipe

This recipe installs call to action config.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-call-to-action-recipe
