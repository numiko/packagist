<?php

namespace Drupal\slice;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining Slice entities.
 *
 * @ingroup slice
 */
interface SliceInterface extends ContentEntityInterface, EntityChangedInterface, EntityOwnerInterface {
  // Add get/set methods for your configuration properties here.
  /**
   * Gets the Slice type.
   *
   * @return string
   *   The Slice type.
   */
  public function getType();

  /**
   * Gets the Slice name.
   *
   * @return string
   *   Name of the Slice.
   */
  public function getName();

  /**
   * Sets the Slice name.
   *
   * @param string $name
   *   The Slice name.
   *
   * @return \Drupal\slice\SliceInterface
   *   The called Slice entity.
   */
  public function setName($name);

  /**
   * Gets the Slice creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Slice.
   */
  public function getCreatedTime();

  /**
   * Sets the Slice creation timestamp.
   *
   * @param int $timestamp
   *   The Slice creation timestamp.
   *
   * @return \Drupal\slice\SliceInterface
   *   The called Slice entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Returns the Slice published status indicator.
   *
   * Unpublished Slice are only visible to restricted users.
   *
   * @return bool
   *   TRUE if the Slice is published.
   */
  public function isPublished();

  /**
   * Sets the published status of a Slice.
   *
   * @param bool $published
   *   TRUE to set this Slice to published, FALSE to set it to unpublished.
   *
   * @return \Drupal\slice\SliceInterface
   *   The called Slice entity.
   */
  public function setPublished($published);

}
