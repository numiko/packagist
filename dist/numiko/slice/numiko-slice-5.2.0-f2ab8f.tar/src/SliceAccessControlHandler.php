<?php

namespace Drupal\slice;

use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Access controller for the Slice entity.
 *
 * @see \Drupal\slice\Entity\Slice.
 */
class SliceAccessControlHandler extends EntityAccessControlHandler {
  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\slice\SliceInterface $entity */
    switch ($operation) {
      case 'view':
        if (!$entity->isPublished()) {
          return AccessResult::allowedIfHasPermission($account, 'view unpublished slice entities');
        }
        return AccessResult::allowedIfHasPermission($account, 'view published slice entities');

      case 'update':
        return AccessResult::allowedIfHasPermission($account, 'edit slice entities');

      case 'delete':
        return AccessResult::allowedIfHasPermission($account, 'delete slice entities');
    }

    // Unknown operation, no opinion.
    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'add slice entities');
  }

}
