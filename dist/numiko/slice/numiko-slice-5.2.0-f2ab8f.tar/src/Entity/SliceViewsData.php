<?php

namespace Drupal\slice\Entity;

use Drupal\views\EntityViewsData;

/**
 * Provides Views data for Slice entities.
 */
class SliceViewsData extends EntityViewsData {
  /**
   * {@inheritdoc}
   */
  public function getViewsData() {
    $data = parent::getViewsData();

    $data['slice']['table']['base'] = array(
      'field' => 'id',
      'title' => $this->t('Slice'),
      'help' => $this->t('The Slice ID.'),
    );

    return $data;
  }

}
