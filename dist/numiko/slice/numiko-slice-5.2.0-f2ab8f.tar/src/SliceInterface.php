<?php

namespace Drupal\slice;

use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\paragraphs\ParagraphInterface;

/**
 * Provides an interface for defining Slice entities.
 *
 * @ingroup slice
 */
interface SliceInterface extends ParagraphInterface, EntityChangedInterface {
  // Add get/set methods for your configuration properties here.
  /**
   * Gets the Slice type.
   *
   * @return string
   *   The Slice type.
   */
  public function getType();

  /**
   * Gets the Slice name.
   *
   * @return string
   *   Name of the Slice.
   */
  public function getName();

  /**
   * Sets the Slice name.
   *
   * @param string $name
   *   The Slice name.
   *
   * @return \Drupal\slice\SliceInterface
   *   The called Slice entity.
   */
  public function setName($name);

  /**
   * Gets the Slice creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Slice.
   */
  public function getCreatedTime();

  /**
   * Sets the Slice creation timestamp.
   *
   * @param int $timestamp
   *   The Slice creation timestamp.
   *
   * @return \Drupal\slice\SliceInterface
   *   The called Slice entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Returns the Slice published status indicator.
   *
   * Unpublished Slice are only visible to restricted users.
   *
   * @return bool
   *   TRUE if the Slice is published.
   */
  public function isPublished();

}
