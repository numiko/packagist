<?php

namespace Drupal\slice\Form;

use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Form\FormStateInterface;
use Drupal\field\Entity\FieldConfig;
use Drupal\slice\Entity\SliceType;

/**
 * Class SliceTypeForm.
 *
 * @package Drupal\slice\Form
 */
class SliceTypeForm extends EntityForm {
  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);

    $slice_type = $this->entity;
    $form['label'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Label'),
      '#maxlength' => 255,
      '#default_value' => $slice_type->label(),
      '#description' => $this->t("Label for the Slice type."),
      '#required' => TRUE,
    );

    $form['classes'] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Classes'),
      '#maxlength' => 255,
      '#default_value' => $slice_type->classes(),
      '#description' => $this->t("Classes to add to the slice container."),
      '#required' => FALSE,
    );

    $form['id'] = array(
      '#type' => 'machine_name',
      '#default_value' => $slice_type->id(),
      '#machine_name' => array(
        'exists' => '\Drupal\slice\Entity\SliceType::load',
      ),
      '#disabled' => !$slice_type->isNew(),
    );

    $options = array(
      'name' => 'Slice Title',
      'id' => 'Slice ID',
    );

    $fields = \Drupal::service('entity_field.manager')->getFieldDefinitions('slice', $slice_type->id());

    foreach ($fields as $field) {
      if ($field instanceof FieldConfig) {
        $options[$field->get('field_name')] = $field->label();
      }
    }

    $form['adminlabelfield'] = array(
      '#type' => 'select',
      '#title' => $this->t('Admin Label Field'),
      '#options' => $options,
      '#default_value' => ($slice_type->adminlabelfield()) ?: SliceType::DEFAULT_ADMIN_LABEL_FIELD,
      '#description' => $this->t("The field to use for labelling the slice on the edit form."),
      '#required' => TRUE,
    );

    /* You will need additional form elements for your custom properties. */

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $slice_type = $this->entity;
    $status = $slice_type->save();

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()->addMessage($this->t('Created the %label Slice type.', [
          '%label' => $slice_type->label(),
        ]));
        break;

      default:
        $this->messenger()->addMessage($this->t('Saved the %label Slice type.', [
          '%label' => $slice_type->label(),
        ]));
    }
    $form_state->setRedirectUrl($slice_type->toUrl('collection'));
  }

}
