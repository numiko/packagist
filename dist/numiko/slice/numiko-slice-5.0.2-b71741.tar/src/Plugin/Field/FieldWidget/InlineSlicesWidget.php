<?php

namespace Drupal\slice\Plugin\Field\FieldWidget;

use Drupal\paragraphs\Plugin\Field\FieldWidget\InlineParagraphsWidget;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\slice\Factory\SliceAdminLabelFactory;

/**
 * Plugin implementation of the 'entity_reference paragraphs' widget.
 *
 * We hide add / remove buttons when translating to avoid accidental loss of
 * data because these actions effect all languages.
 *
 * @FieldWidget(
 *   id = "entity_reference_slices",
 *   label = @Translation("Slices"),
 *   description = @Translation("An slices inline form widget."),
 *   field_types = {
 *     "entity_reference_revisions"
 *   }
 * )
 */
class InlineSlicesWidget extends InlineParagraphsWidget {

  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {

    $element = parent::formElement($items, $delta, $element, $form, $form_state);

    if ($items->get($delta)->get('entity')) {
      $revision_entity = $items->get($delta)->get('entity');
      if ($revision_entity->getTarget()) {
        if ($revision_entity->getTarget()->getValue()->getEntityTypeId() == 'slice') {
          $slice = $revision_entity->getTarget()->getValue();
          $label = SliceAdminLabelFactory::generate($slice);
          $type = strip_tags(str_replace('Type: ', '', $element['top']['paragraph_type_title']['info']['#markup']));
          $element['top']['paragraph_type_title']['info']['#markup'] = $type;
          $element['top']['paragraph_summary']['fields_info']['#summary']['content'][] = $label;
        }
      }
    }

    unset($element['subform']['name']['widget']['#description']);

    return $element;

  }

  public function formMultipleElements(FieldItemListInterface $items, array &$form, FormStateInterface $form_state) {

    $elements = parent::formMultipleElements($items, $form, $form_state);

    $elements['#attached']['library'][] = 'slice/drupal.slice_widget';

    $elements['#title'] = t('Active Slices');

    if ($this->getSetting('add_mode') == 'select' && $elements['add_more']['add_more_button']) {
      $elements['add_more']['#prefix'] = '<div class="add-more-buttons">';
      $elements['add_more']['#suffix'] = '</div>';
      $elements['add_more']['add_more_select']['#title'] = t('@title available:', array('@title' => 'Slices'));
      $elements['add_more']['add_more_button']['#value'] = t('Add @title', $elements['add_more']['add_more_button']['#value']->getArguments());
      unset($elements['add_more']['add_more_button']['#suffix']);
    }

    return $elements;

  }

}