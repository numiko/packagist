<?php

namespace Drupal\slice;

use Drupal\Core\Url;
use Drupal\Core\Link;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;

/**
 * Defines a class to build a listing of Slice entities.
 *
 * @ingroup slice
 */
class SliceListBuilder extends EntityListBuilder {
  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['id'] = $this->t('Slice ID');
    $header['name'] = $this->t('Name');
    $header['type'] = $this->t('Slice type');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var $entity \Drupal\slice\Entity\Slice */
    $row['id'] = $entity->id();
    $row['name'] = Link::fromTextAndUrl(
      $entity->label(),
      new Url(
        'entity.slice.edit_form', array(
          'slice' => $entity->id(),
        )
      )
    );
    $bundle_info = \Drupal::service("entity_type.bundle.info")->getAllBundleInfo();
    $row['type'] = $bundle_info[$entity->getEntityTypeId()][$entity->bundle()]['label'];
    return $row + parent::buildRow($entity);
  }

}
