<?php

declare(strict_types=1);

namespace Drupal\inner_html_paragraph_remover\Hook;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\filter\Entity\FilterFormat;

/**
 * Hook to remove the paragraph tag.
 */
final class RemoveParagraphHook {
  use StringTranslationTrait;

  /**
   * Formats to remove paragraphs on.
   *
   * @var string[]
   */
  private const array FORMATS_TO_REMOVE_PARAGRAPH_TAGS = ['inline_html'];

  public function __construct(TranslationInterface $stringTranslation) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * This hook exists to prevent the re-addition of paragraph tags.
   *
   * By default the HTML filter will add in paragraph tags if the source editing
   * button is enabled, and (quite rightly) will not allow you to remove these.
   *
   * CKEditor wraps itself in `<p>` tags with no way to change this behaviour.
   * So, remove the `<p>`s in the paragraph filter.
   *
   * @param \Drupal\filter\Entity\FilterFormat $filter
   *   Filter format entity.
   */
  #[Hook('filter_format_presave')]
  public function filterPresave(FilterFormat $filter): void {
    if (in_array($filter->getOriginalId(), self::FORMATS_TO_REMOVE_PARAGRAPH_TAGS)) {
      $filterConfig = $filter->filters('filter_html');
      $config = $filterConfig->getConfiguration();
      $config['settings']['allowed_html'] = str_replace('<p>', '', $config['settings']['allowed_html']);
      $filter->setFilterConfig('filter_html', $config);
    }
  }

  /**
   * Add a line of text so users can see `<p>` tags are removed.
   */
  #[Hook('form_filter_format_form_alter')]
  public function formFilterFormatFormAlter(array &$form, FormStateInterface $formState, string $formId): void {
    /** @var ?\Drupal\editor\Entity\Editor $editor */
    $editor = $formState->get('editor');
    if (!$editor) {
      return;
    }
    if (in_array($editor->getOriginalId(), self::FORMATS_TO_REMOVE_PARAGRAPH_TAGS)) {
      $filter_allowed_html = &$form['filters']['settings']['filter_html']['allowed_html'];
      $filter_allowed_html['#description'] .= '<br /><strong>' . $this->t('NOTE: paragraph tags are getting removed from this list as well on save.') . '</strong>';
    }
  }

}
