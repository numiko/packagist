# Facets "All Links" #

Add a "links" facet widget with an All option, this can either be specified in full or as a token.

> **_NOTE:_**  the basic functionality of this module is now deprecated as the same functionality is available in the facets module, this module is now only necessary for the more advanced token functionality.