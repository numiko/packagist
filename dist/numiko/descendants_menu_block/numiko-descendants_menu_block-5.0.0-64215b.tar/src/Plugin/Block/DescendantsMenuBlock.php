<?php

namespace Drupal\descendants_menu_block\Plugin\Block;

use Drupal\Core\Block\Attribute\Block;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Menu\MenuLinkManagerInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\descendants_menu_block\Plugin\Derivative\DescendantsMenuBlock as DescendantsMenuBlockDeriver;
use Drupal\node\NodeInterface;
use Drupal\system\Plugin\Block\SystemMenuBlock;
use Symfony\Contracts\Service\Attribute\Required;

/**
 * Provides a 'DescendantsMenuBlock' block.
 */
#[Block(
  id: 'descendants_menu_block',
  admin_label: new TranslatableMarkup('Descendants menu block'),
  category: new TranslatableMarkup('Descendants menu'),
  deriver: DescendantsMenuBlockDeriver::class
)]
class DescendantsMenuBlock extends SystemMenuBlock {

  /**
   * The menu link manager.
   */
  protected MenuLinkManagerInterface $menuLinkManager;

  /**
   * The current route match.
   */
  protected RouteMatchInterface $routeMatch;

  /**
   * Add the menu link manager and route matcher.
   */
  #[Required]
  public function getAdditionalServices(RouteMatchInterface $routeMatch, MenuLinkManagerInterface $menuLinkManager): void {
    $this->menuLinkManager = $menuLinkManager;
    $this->routeMatch = $routeMatch;
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->configuration;
    $defaults = array_merge(parent::defaultConfiguration(), $this->defaultConfiguration());

    $form = parent::blockForm($form, $form_state);

    // Default "Expand all menu links" to true.
    $form['menu_levels']['expand_all_items']['#default_value'] = $config['expand_all_items'] ?? $defaults['expand_all_items'];
    $form['menu_levels']['expand_all_items']['#description'] .= ' ' . $this->t('This must be checked to display descendant links.');

    $form['descendants'] = [
      '#type' => 'details',
      '#title' => $this->t('Descendants options'),
      '#open' => FALSE,
      '#process' => [[self::class, 'processBlockFieldSets']],
    ];

    $form['descendants']['use_current_page'] = [
      '#type' => 'checkbox',
      '#title' => '<strong>' . $this->t('Descendants of current page') . '</strong>',
      '#description' => $this->t('Sets fixed parent to the current page and displays child links to the maximum set in "Menu levels".'),
      '#default_value' => $config['use_current_page'] ?? $defaults['use_current_page'],
      '#weight' => '10',
    ];

    return $form;
  }

  /**
   * Form API callback: Processes the elements in field sets.
   *
   * Adjusts the #parents of field sets to save its children at the top level.
   */
  public static function processBlockFieldSets(array &$element, FormStateInterface $form_state, array &$complete_form): array {
    array_pop($element['#parents']);
    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state): void {
    parent::blockSubmit($form, $form_state);
    $this->configuration['use_current_page'] = $form_state->getValue('use_current_page');
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    if ($this->configuration['use_current_page']) {
      $node = $this->routeMatch->getParameter('node');
      if ($node instanceof NodeInterface) {
        $parent_plugin_id = $this->getParentPluginId($node->id());
        // If we are unable to find node in the menu then we will not show the
        // menu block.
        if (!$parent_plugin_id) {
          return [];
        }
        $this->configuration['parent'] = $parent_plugin_id;
        $this->setConfigurationValue('parent', $this->configuration['parent']);
      }
    }

    /* Modified MenuBlock::build() from the menu_block module. */
    $menu_name = $this->getDerivativeId();
    $parameters = $this->menuTree->getCurrentRouteMenuTreeParameters($menu_name);

    // Adjust the menu tree parameters based on the block's configuration.
    $level = $this->configuration['level'];
    $depth = $this->configuration['depth'];
    $expand = $this->configuration['expand_all_items'];

    $parameters->setMinDepth($level);

    // When the depth is configured to zero, there is no depth limit. When depth
    // is non-zero, it indicates the number of levels that must be displayed.
    // Hence this is a relative depth that we must convert to an actual
    // (absolute) depth, that may never exceed the maximum depth.
    if ($depth > 0) {
      $parameters->setMaxDepth(min($level + $depth - 1, $this->menuTree->maxDepth()));
    }

    // If expandedParents is empty, the whole menu tree is built.
    if ($expand) {
      $parameters->expandedParents = [];
    }

    // When a fixed parent item is set, root the menu tree at the given ID.
    if ($parent_plugin_id) {
      // Clone the parameters so we can fall back to using them if we're
      // following the active menu item and the current page is part of the
      // active menu trail.
      $fixed_parameters = clone $parameters;
      $fixed_parameters->setRoot($parent_plugin_id);
      $tree = $this->menuTree->load($menu_name, $fixed_parameters);

      // Check if the tree contains links.
      if (empty($tree)) {
        // If the starting level is 1, we always want the child links to appear,
        // but the requested tree may be empty if the tree does not contain the
        // active trail. We're accessing the configuration directly since the
        // $level variable may have changed by this point.
        if ($this->configuration['level'] === 1 || $this->configuration['level'] === '1') {
          // Change the request to expand all children and limit the depth to
          // the immediate children of the root.
          $fixed_parameters->expandedParents = [];
          $fixed_parameters->setMinDepth(1);
          $fixed_parameters->setMaxDepth(1);
          // Re-load the tree.
          $tree = $this->menuTree->load($menu_name, $fixed_parameters);
        }
      }
    }

    // Load the tree if we haven't already.
    if (!isset($tree)) {
      $tree = $this->menuTree->load($menu_name, $parameters);
    }
    $manipulators = [
      ['callable' => 'menu.default_tree_manipulators:checkAccess'],
      ['callable' => 'menu.default_tree_manipulators:generateIndexAndSort'],
    ];
    $tree = $this->menuTree->transform($tree, $manipulators);
    $build = $this->menuTree->build($tree);

    if (!empty($build['#theme'])) {
      // Add the configuration for use in menu_block_theme_suggestions_menu().
      $build['#menu_block_configuration'] = $this->configuration;
      // Remove the menu name-based suggestion so we can control its precedence
      // better in menu_block_theme_suggestions_menu().
      $build['#theme'] = 'menu';
    }

    $build['#contextual_links']['menu'] = [
      'route_parameters' => ['menu' => $menu_name],
    ];

    /* End modified MenuBlock::build() from menu_block module. */
    return $build;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'expand_all_items' => TRUE,
      'use_current_page' => 1,
      'level' => 1,
      'depth' => 0,
    ];
  }

  /**
   * {@inheritdoc}
   */
  private function getParentPluginId(int $nid): ?string {
    $links = $this->menuLinkManager->loadLinksByRoute('entity.node.canonical', ['node' => $nid]);
    // Return the first result that matches parent in config.
    foreach ($links as $link) {
      $definition = $link->getPluginDefinition();
      if ($this->configuration['id'] == ($this->configuration['provider'] . ':' . $definition['menu_name'])) {
        return $link->getPluginId();
      }
    }
    return NULL;
  }

}
