<?php

namespace Drupal\descendants_menu_block\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Routing\RouteMatchInterface;

/**
 * Hook implementations for descendants_menu_block.
 */
class DescendantsMenuBlockHooks {

  /**
   * Implements hook_help().
   */
  #[Hook('help')]
  public function help(string $route_name, RouteMatchInterface $route_match): ?string {
    switch ($route_name) {
      // Main module help for the descendants_menu_block module.
      case 'help.page.descendants_menu_block':
        $text = file_get_contents(dirname(__FILE__) . "/README.md");
        if (!\Drupal::moduleHandler()->moduleExists('markdown')) {
          return '<pre>' . $text . '</pre>';
        }
        else {
          // Use the Markdown filter to render the README.
          $filter_manager = \Drupal::service('plugin.manager.filter');
          $settings = \Drupal::configFactory()->get('markdown.settings')->getRawData();
          $config = [
            'settings' => $settings,
          ];
          $filter = $filter_manager->createInstance('markdown', $config);
          return $filter->process($text, 'en');
        }
    }
    return NULL;
  }

}
