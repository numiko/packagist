# NumiAdmin Theme

## What is it?

An admin theme with Numiko enhancements based upon the Drupal 8 Seven theme included in Core.
