# Taxonomy Slice

This module takes any taxonomy fields on a paragraph containing a view display field and populates any contextual filters with the values selected.

## Usage

* Create a paragraph type with a view display field
* Make selectable views with contextual filters
* Add taxonomy fields
* Optionally add a field to the paragraph of type "List (integer)" to allow the number of columns and teasers show to be controlled
* Set config `taxonomy_slice.settings.set_columns` to false if you do not want set grid columns, but do add a field to allow number of teasers to be chosen

## Limitations

Ensure the views used have at least as many contextual filters added as there are taxonomy fields on the paragraph type, as these will be populated with the values of the taxonomy fields.
