<?php

namespace Drupal\taxonomy_slice\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for the Taxonomy Slice module.
 */
class TaxonomySliceHooks {

  /**
   * Implements hook_preprocess_paragraph().
   *
   * Preprocess the paragraph to map arguments to the view on a taxonomy slice.
   */
  #[Hook('preprocess_paragraph')]
  public function preprocessParagraph(&$variables) {
    \Drupal::service('slice.taxonomy')->mapArgumentsToView($variables['paragraph']);
  }

}
