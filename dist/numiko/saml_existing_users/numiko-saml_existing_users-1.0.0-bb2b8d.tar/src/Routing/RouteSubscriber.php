<?php

/**
 * @file
 *
 * Contains \Drupal\saml_existing_users\Routing\RouteSubscriber.
 *
 * Disable forgot password to avoid issues with SSO.
 */

namespace Drupal\saml_existing_users\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Listens to the dynamic route events and restrict access to user.pass route.
 */
class RouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   */
  public function alterRoutes(RouteCollection $collection) {
    if ($route = $collection->get('user.pass')) {
      $route->setRequirement('_access', 'FALSE');
    }
  }

}
