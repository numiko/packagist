<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the teaser list slice displays on a page.
 *
 * @group slices
 */
class TeaserListSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a teaser list slice to a node.
   */
  public function testTeaserListSliceDisplay() {
    $items = [
      [
        'target_id' => $this->createPublishedNode([
          'title' => 'Test page one',
          'field_teaser_summary' => 'Test page one summary',
          'field_image' => $this->getSampleImageMedia([], 'teaser_list_slice_image_one.jpg')->id()
        ])->id()
      ],
      [
        'target_id' => $this->createPublishedNode([
          'title' => 'Test page two',
          'field_teaser_summary' => 'Test page two summary',
          'field_image' => $this->getSampleImageMedia([], 'teaser_list_slice_image_two.jpg')->id()
        ])->id()
      ],
      [
        'target_id' => $this->createPublishedNode([
          'title' => 'Test page three',
          'field_teaser_summary' => 'Test page three summary',
          'field_image' => $this->getSampleImageMedia([], 'teaser_list_slice_image_three.jpg')->id()
        ])->id()
      ],
    ];

    $paragraphs[] = $this->createParagraph('slice_teaser_list', [
      'field_title' => 'Teaser list slice title',
      'field_content_items' => $items,
    ]);

    $node = $this->createPublishedNode([
      'field_slices' => $paragraphs,
      'field_teaser_summary' => 'Page summary',
    ]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);

    $assertSession->pageTextContains('Teaser list slice title');
    $assertSession->pageTextContains('Test page one');
    $assertSession->pageTextContains('Test page one summary');
    $assertSession->responseContains('teaser_list_slice_image_one.jpg');
    $assertSession->pageTextContains('Test page two');
    $assertSession->pageTextContains('Test page two summary');
    $assertSession->responseContains('teaser_list_slice_image_two.jpg');
    $assertSession->pageTextContains('Test page three');
    $assertSession->pageTextContains('Test page three summary');
    $assertSession->responseContains('teaser_list_slice_image_three.jpg');
  }

}
