# Teaser Text only Slice Recipe

This recipe installs teaser text only slice config.

Not Composed / Not added to the satis.json.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-teaser-list-slice
