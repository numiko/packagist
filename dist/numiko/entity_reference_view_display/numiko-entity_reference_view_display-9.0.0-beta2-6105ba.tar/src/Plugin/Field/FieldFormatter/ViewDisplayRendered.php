<?php

namespace Drupal\entity_reference_view_display\Plugin\Field\FieldFormatter;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FormatterBase;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\views\Entity\View;
use Drupal\entity_reference_view_display\Plugin\Field\FieldType\ViewDisplayReferenceItem;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Field\Attribute\FieldFormatter;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Plugin implementation of the 'view_display_rendered' formatter.
 */
#[FieldFormatter(
  id: "view_display_rendered",
  label: new TranslatableMarkup("View Display Rendered"),
  field_types: [
    "view_display_reference_item",
  ]
)]
class ViewDisplayRendered extends FormatterBase {

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  public function __construct($plugin_id, $plugin_definition, FieldDefinitionInterface $field_definition, array $settings, $label, $view_mode, array $third_party_settings, EntityTypeManagerInterface $entityTypeManager) {
    parent::__construct(
      $plugin_id,
      $plugin_definition,
      $field_definition,
      $settings,
      $label,
      $view_mode,
      $third_party_settings
    );
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $plugin_id,
      $plugin_definition,
      $configuration['field_definition'],
      $configuration['settings'],
      $configuration['label'],
      $configuration['view_mode'],
      $configuration['third_party_settings'],
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $elements = [];

    foreach ($items as $delta => $item) {
      if ($item->_loaded == FALSE) {
        continue;
      }

      if ($item->entity instanceof View) {
        // kint($item);
        $executable = $item->entity->getExecutable();
        $executable->setDisplay($item->display_id);

        $elements[$delta] = [
          'content' => $executable->buildRenderable(),
        ];
      }
      else {
        $elements[$delta] = ['#markup' => t('This is not a view')];
      }
    }

    return $elements;
  }

  /**
   * {@inheritdoc}
   *
   * Loads the entities referenced in that field across all the entities being
   * viewed.
   */
  public function prepareView(array $entities_items) {
    // Collect entity IDs to load. For performance, we want to use a single
    // "multiple entity load" to load all the entities for the multiple
    // "entity reference item lists" being displayed.
    $ids = [];
    foreach ($entities_items as $items) {
      foreach ($items as $item) {
        $item->_loaded = FALSE;
        $this->populateItemViewAndDisplayId($item);
        $ids[] = $item->view_id;
      }
    }
    if ($ids) {
      $target_entities = $this->entityTypeManager
        ->getStorage('view')
        ->loadMultiple($ids);
    }

    // For each item, pre-populate the loaded entity in $item->entity, and set
    // the 'loaded' flag.
    foreach ($entities_items as $items) {
      foreach ($items as $item) {
        if (isset($target_entities[$item->view_id])) {
          $item->entity = $target_entities[$item->view_id];
          $item->_loaded = TRUE;
        }
      }
    }
  }

  /**
   * Add the view id & display id by exploding the target id.
   */
  protected function populateItemViewAndDisplayId($item) {
    $target_id = $item->target_id;
    $target = explode(ViewDisplayReferenceItem::VIEW_DISPLAY_SEPERATOR, $target_id);
    $item->view_id = $target[0];
    $item->display_id = $target[1];
  }

}
