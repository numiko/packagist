# Event Sponsor Paragraph Type Recipe

This recipe installs the necessary configuration to add an Event Sponsor Slice.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-event-sponsor-recipe`
