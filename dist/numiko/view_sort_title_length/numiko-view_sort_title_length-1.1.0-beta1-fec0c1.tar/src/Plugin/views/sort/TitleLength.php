<?php

namespace Drupal\view_sort_title_length\Plugin\views\sort;

use Drupal\views\Plugin\views\sort\Standard;

/**
 * Handle a title length sort.
 *
 * @ViewsSort("title_length")
 */
class TitleLength extends Standard {

  public function query() {
    $this->query->addOrderBy(NULL, 'LENGTH(title)', $this->options['order'], 'title_length');
  }

}
