<?php

namespace Drupal\view_sort_title_length\Plugin\EntityReferenceSelection;

use Drupal\Component\Utility\Xss;
use Drupal\views\Render\ViewsRenderPipelineMarkup;
use Drupal\views\Plugin\EntityReferenceSelection\ViewsSelection;

/**
 * Plugin implementation of the 'selection' entity_reference.
 *
 * @EntityReferenceSelection(
 *   id = "views_ungrouped",
 *   label = @Translation("Views: Filter by an entity reference view without grouping results"),
 *   group = "views_ungrouped",
 *   weight = 0
 * )
 */
class ViewsSelectionWithoutGrouping extends ViewsSelection {

  /**
   * Strips all admin and anchor tags from a result list.
   *
   * These results are usually displayed in an autocomplete field, which is
   * surrounded by anchor tags. Most tags are allowed inside anchor tags, except
   * for other anchor tags.
   *
   * The change from this and the original views selection is that it
   * removes the unexpected feature of the function, i.e. it no longer groups
   * the results by bundle without warning.
   *
   * This is useful if you wish to sort the results using the view query, but
   * can only be used alongside the custom entity matcher also included in this
   * module.
   *
   * @param array $results
   *   The result list.
   *
   * @return array
   *   The provided result list with anchor tags removed.
   */
  protected function stripAdminAndAnchorTagsFromResults(array $results) {
    $allowed_tags = Xss::getAdminTagList();
    if (($key = array_search('a', $allowed_tags)) !== FALSE) {
      unset($allowed_tags[$key]);
    }

    $stripped_results = [];
    foreach ($results as $id => $row) {
      $stripped_results[$id] = ViewsRenderPipelineMarkup::create(
        Xss::filter($this->renderer->renderPlain($row), $allowed_tags)
      );
    }

    return $stripped_results;
  }

}
