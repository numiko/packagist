<?php

namespace Drupal\view_sort_title_length;

use Drupal\Component\Utility\Html;
use Drupal\Component\Utility\Tags;
use Drupal\Core\Entity\EntityAutocompleteMatcher;

/**
 * Override the default entity autocomplete matcher for entities not grouped.
 *
 * In order to allow an autocomplete field to use an entity reference and
 * preserve the sort order of the view we need to use an alternative views
 * selection plugin and override the matcher.
 */
class UngroupedEntityAutocompleteMatcher extends EntityAutocompleteMatcher {

  /**
   * {@inheritdoc}
   */
  public function getMatches($target_type, $selection_handler, $selection_settings, $string = '') {
    $matches = [];

    // This matcher only exists to handle the ungrouped view selection plugin
    // if that is not in use then revert to the default autocomplete matcher.
    if ($selection_handler !== 'views_ungrouped') {
      return parent::getMatches($target_type, $selection_handler, $selection_settings, $string);
    }

    $options = $selection_settings + [
      'target_type' => $target_type,
      'handler' => $selection_handler,
    ];
    $handler = $this->selectionManager->getInstance($options);

    if (isset($string)) {
      // Get an array of matching entities.
      $match_operator = !empty($selection_settings['match_operator']) ? $selection_settings['match_operator'] : 'CONTAINS';
      $match_limit = isset($selection_settings['match_limit']) ? (int) $selection_settings['match_limit'] : 10;
      $entity_values = $handler->getReferenceableEntities($string, $match_operator, $match_limit);

      // Loop through the entities and convert them into autocomplete output.
      foreach ($entity_values as $entity_id => $label) {
        $key = "$label ($entity_id)";
        // Strip things like starting/trailing white spaces, line breaks and
        // tags.
        $key = preg_replace('/\s\s+/', ' ', str_replace("\n", '', trim(Html::decodeEntities(strip_tags($key)))));
        // Names containing commas or quotes must be wrapped in quotes.
        $key = Tags::encode($key);
        $matches[] = ['value' => $key, 'label' => $label];
      }
    }

    return $matches;
  }

}
