<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that teaser text only slice displays on a page.
 *
 * @group slices
 */
class TeaserTextOnlySliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a teaser text only slice to a node.
   */
  public function testTextOnlyTeaserSliceDisplay() {
    $items = [
      [
        'target_id' => $this->createPublishedNode([
          'type' => 'page',
          'title' => 'Test page one',
          'field_image' => $this->getSampleImageMedia([], 'sample_page_image_one.jpg')->id(),
          'field_teaser_summary' => 'Test page one summary'
        ])->id()
      ],
      [
        'target_id' => $this->createPublishedNode([
          'type' => 'page',
          'title' => 'Test page two',
          'field_image' => $this->getSampleImageMedia([], 'sample_article_image_two.jpg')->id(),
          'field_teaser_summary' => 'Test page two summary'
        ])->id()
      ],
      [
        'target_id' => $this->createPublishedNode([
          'type' => 'page',
          'title' => 'Test page study three',
          'field_image' => $this->getSampleImageMedia([], 'sample_case_study_image_three.jpg')->id(),
          'field_teaser_summary' => 'Test page three summary'
        ])->id()
      ],
    ];

    $paragraphs[] = $this->createParagraph('slice_teaser_text_only', [
      'field_title' => 'Teaser text only slice title',
      'field_content_items' => $items,
    ]);

    $node = $this->createPublishedNode([
      'title' => 'Page title',
      'field_slices' => $paragraphs
    ]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);

    $assertSession->pageTextContains('Teaser text only slice title');
    $assertSession->pageTextContains('Teaser text only slice introduction');
    $assertSession->pageTextContains('Test page one');
    $assertSession->responseNotContains('sample_page_image_one.jpg');
    $assertSession->pageTextContains('Test page two');
    $assertSession->responseNotContains('sample_page_image_two.jpg');
    $assertSession->pageTextContains('Test page three');
    $assertSession->responseNotContains('sample_page_image_three.jpg');
  }

  /**
   * Test adding a teaser text only slice has a minimum of two items.
   */
  public function testTeaserTextOnlySliceCannotBeReduced() {
    $items = [
      ['target_id' => $this->createPublishedNode(['title' => 'Test page one'])->id()],
      ['target_id' => $this->createPublishedNode(['title' => 'Test page two'])->id()],
      ['target_id' => $this->createPublishedNode(['title' => 'Test page three'])->id()],
    ];

    $paragraphs[] = $this->createParagraph('slice_teaser_text_only', [
      'field_title' => 'Teaser slice title',
      'field_content_items' => $items,
    ]);

    $node = $this->createPublishedNode([
      'title' => 'Page title',
      'field_hero_title' => 'Page title',
      'field_slices' => $paragraphs,
    ]);
    $assertSession = $this->assertSession();

    // Login as editor.
    $this->createUserWithPersonaAndLogin(['editor']);

    $this->visitCheckCode('node/' . $node->id() . '/edit', Response::HTTP_OK);

    $this->submitForm([
      "field_slices[0][subform][field_content_items][1][target_id]" => "",
      "field_slices[0][subform][field_content_items][2][target_id]" => "",
    ], 'Save');
    $assertSession->statusCodeEquals(Response::HTTP_OK);

    $assertSession->responseContains('Content items field requires a minimum of 2 items');
  }

}
