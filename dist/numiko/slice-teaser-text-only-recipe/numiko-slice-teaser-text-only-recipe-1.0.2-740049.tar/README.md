# Teaser Text only Slice Recipe

This recipe installs teaser text only slice config.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-teaser-text-only-recipe
