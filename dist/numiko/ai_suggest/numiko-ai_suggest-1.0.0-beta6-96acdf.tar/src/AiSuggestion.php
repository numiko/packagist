<?php

namespace Drupal\ai_suggest;

use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;
use Drupal\ai\AiProviderPluginManager;
use Drupal\Core\State\StateInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for generating AI suggestions.
 */
class AiSuggestion {

  /**
   * The AI provider manager.
   *
   * @var \Drupal\ai\AiProviderPluginManager
   */
  protected AiProviderPluginManager $aiProviderManager;
  
  /**
   * The state service.
   *
   * @var \Drupal\Core\State\StateInterface
   */
  protected $state;
  
  /**
   * The logger channel factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;
  
  /**
   * Tracks the number of regeneration attempts for character limit compliance.
   *
   * @var int
   */

  /**
   * Constructs a new AiSuggestion service.
   *
   * @param \Drupal\ai\AiProviderPluginManager $aiProviderManager
   *   The AI provider manager.
   * @param \Drupal\Core\State\StateInterface $state
   *   The state service.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $logger_factory
   *   The logger channel factory.
   */
  public function __construct(
    #[Autowire(service: 'ai.provider')]
    AiProviderPluginManager $aiProviderManager,
    #[Autowire(service: 'state')]
    StateInterface $state,
    #[Autowire(service: 'logger.factory')]
    LoggerChannelFactoryInterface $logger_factory
  ) {
    $this->aiProviderManager = $aiProviderManager;
    $this->state = $state;
    $this->loggerFactory = $logger_factory;
  }

  /**
   * Generates a suggestion from form state values.
   *
   * @param string $prompt
   *   The prompt text to send to the AI.
   * @param string $textContent
   *   The text content to analyze.
   * @param int $characterLimit
   *   Optional character limit for the AI response. 0 means unlimited.
   *
   * @return string
   *   The generated suggestion.
   */
  public function getTextSuggestion(string $prompt, string $textContent, int $characterLimit = 0) : string {
    $suggestion = '';

    $sets = $this->aiProviderManager->getDefaultProviderForOperationType('chat');
    $model = $sets['model_id'];
    $provider = $this->aiProviderManager->createInstance($sets['provider_id']);
    
    // If debugging is enabled, log the start of the suggestion generation
    if ($this->state->get('ai_suggest.debug_mode', FALSE)) {
      $this->loggerFactory->get('ai_suggest')->notice('Starting AI suggestion generation with character limit: @limit', [
        '@limit' => $characterLimit ? $characterLimit : 'unlimited',
      ]);
    }
    
    // Set max tokens
    $maxTokens = 4096;
    $provider->setConfiguration($provider->getConfiguration() + ['max_tokens' => $maxTokens]);

    // Modify the prompt to include character limit instruction if needed
    $systemPrompt = $prompt;
    if ($characterLimit > 0) {
      $systemPrompt = $prompt . "Your response must be under " . $characterLimit . " characters. Be concise and prioritize the most important information. Aim for clarity and brevity without sacrificing essential content.";
    }

    $messages = new ChatInput([
      new ChatMessage('system', $systemPrompt),
      new ChatMessage('user', $textContent),
    ]);

    
      $message = $provider->chat($messages, $model)->getNormalized();
      $suggestion = $message->getText();

      if (!$suggestion) {
        throw new \Exception("No response received");
      }
      
      // If the response exceeds the character limit, regenerate with more specific instructions
      if ($characterLimit > 0 && mb_strlen($suggestion) > $characterLimit) {
        $lenght = mb_strlen($suggestion);
        
        if ($this->state->get('ai_suggest.debug_mode', FALSE)) {
          $this->loggerFactory->get('ai_suggest')->notice('Response exceeds character limit. Length: @length, Limit: @limit.', [
            '@length' => $lenght,
            '@limit' => $characterLimit,
          ]);
        }
        
      }

    return $suggestion;
  }

/**
   * Generates AI suggestions for taxonomy term selection based on text content.
   *
   * @param string $textContent
   *   The text content to analyze.
   * @param array $options
   *   Array of available taxonomy terms to choose from.
   *
   * @return array
   *   Array of suggested taxonomy terms.
   */
  public function getOptionsSuggestion(string $textContent, array $options = []) : array {
    if ($this->state->get('ai_suggest.debug_mode', FALSE)) {
      $this->loggerFactory->get('ai_suggest')->notice('Starting AI taxonomy term suggestion for @count terms', [
        '@count' => count($options),
      ]);
    }
    
    $sets = $this->aiProviderManager->getDefaultProviderForOperationType('chat');
    $provider = $this->aiProviderManager->createInstance($sets['provider_id']);
    $provider->setConfiguration($provider->getConfiguration() + ['max_tokens' => 4096]);

    $optionsPrompt = 'You are a text classification assistant. Your task is to categorize the provided text by selecting all relevant taxonomy terms from the list below.

      Instructions:
      - Only select taxonomy terms from the list provided.
      - Do not include any terms that are not in the list.
      - Return the selected taxonomy terms as a comma-separated list, **without any spaces**, additional text, or explanations.
      - If no taxonomy terms are relevant, return an empty string.
      - Do not include any formatting characters like brackets or quotes.

      Taxonomy terms:
      [' . implode(', ', $options) . ']

      Example response:
      taxonomy1,taxonomy2,taxonomy3';

    $messages = new ChatInput([
      new ChatMessage('system', $optionsPrompt),
      new ChatMessage('user', $textContent),
    ]);

    $model = $sets['model_id'];

    try {
      $message = $provider->chat($messages, $model)->getNormalized();
      $response = $message->getText();

      if (!$response) {
        throw new \Exception("No response received");
      }
      
      $terms = array_map('trim', explode(',', $response));
      
      if ($this->state->get('ai_suggest.debug_mode', FALSE)) {
        $this->loggerFactory->get('ai_suggest')->notice('AI suggested @count taxonomy terms: @terms', [
          '@count' => count($terms),
          '@terms' => implode(', ', $terms),
        ]);
      }

      return $terms;
    }
    catch (\Exception $e) {
      if ($this->state->get('ai_suggest.debug_mode', FALSE)) {
        $this->loggerFactory->get('ai_suggest')->error('AI taxonomy term suggestion failed: @error', [
          '@error' => $e->getMessage(),
        ]);
      }
      return [];
    }
  }

}