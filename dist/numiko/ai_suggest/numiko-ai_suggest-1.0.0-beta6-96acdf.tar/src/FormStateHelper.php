<?php

namespace Drupal\ai_suggest;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Helper class for form state operations.
 *
 * Specifically allowing the current content to be pulled from the form state.
 */
class FormStateHelper {

  protected EntityTypeManagerInterface $entityTypeManager;
  protected RendererInterface $renderer;

  public function __construct(
    #[Autowire(service: 'entity_type.manager')]
    EntityTypeManagerInterface $entityTypeManager,
    #[Autowire(service: 'renderer')]
    RendererInterface $renderer
  ) {
    $this->entityTypeManager = $entityTypeManager;
    $this->renderer = $renderer;
  }

/**
   * Gets text content from form state.
   *
   * @param \Drupal\Core\Form\FormStateInterface $formState
   *   The form state to extract content from.
   *
   * @return string
   *   The extracted text content.
   */
  public function getTextContentFromFormState(FormStateInterface $formState) {
    // Extract text from form user input.
    $values = $formState->getUserInput();
    $fullTextContent = $this->extractTextFromFields($values);

    // Extract text from field storage for paragraphs.
    $storage = $formState->getStorage();
    $fullTextContent .= $this->extractTextFromParagraphs($storage);

    return $fullTextContent;
  }

  /**
   * Extracts text content from form field values.
   *
   * @param array $values
   *   Array of form values to process.
   *
   * @return string
   *   Concatenated text content from fields.
   */
  protected function extractTextFromFields(array $values) : string {
    $textContent = '';
    foreach ($values as $field => $value) {
      if ((!in_array($field, ['title', 'body']) && !(substr($field, 0, 5) === 'field')) || !is_array($value)) {
        continue;
      }
      foreach ($value as $fieldValue) {
        if (is_array($fieldValue) && isset($fieldValue['value']) && !is_array($fieldValue['value'])) {
          if (!empty($fieldValue['value'])) {
            $textContent .= strip_tags($fieldValue['value']) . "\n";
          }
        }
      }
    }
    return $textContent;
  }

  /**
   * Extracts text content from paragraph fields.
   *
   * Render the paragraph in its current state, and extract the plain text.
   *
   * @param array $storage
   *   Array of paragraph field storage data.
   *
   * @return string
   *   Concatenated text content from paragraphs.
   */
  protected function extractTextFromParagraphs(array $storage) : string {
    $textContent = '';
    foreach ($storage['field_storage']['#parents']['#fields'] as $value) {
      if (is_array($value) && isset($value['paragraphs'])) {
        for ($i = 0; $i < $value['real_item_count']; $i ++) {
          $render_array = $this->entityTypeManager->getViewBuilder('paragraph')->view($value['paragraphs'][$i]['entity'], 'default');
          $textContent .= preg_replace('/\s+/', ' ', strip_tags($this->renderer->render($render_array)));
        }
      }
    }
    return $textContent;
  }

}
