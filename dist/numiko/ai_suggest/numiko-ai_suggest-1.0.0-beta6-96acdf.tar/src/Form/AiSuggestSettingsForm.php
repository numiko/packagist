<?php

namespace Drupal\ai_suggest\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\State\StateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Configure AI Suggest settings.
 */
class AiSuggestSettingsForm extends FormBase {
  use StringTranslationTrait;

  /**
   * The state service.
   *
   * @var \Drupal\Core\State\StateInterface
   */
  protected $state;
  
  /**
   * The messenger service.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface
   */
  protected $messenger;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = new static();
    $instance->state = $container->get('state');
    $instance->messenger = $container->get('messenger');
    $instance->setStringTranslation($container->get('string_translation'));
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ai_suggest_settings';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['regeneration'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Character Limit Settings'),
      '#collapsible' => FALSE,
    ];

    $form['regeneration']['info'] = [
      '#markup' => $this->t('<p>When a character limit is set, AI Suggest will make up to 2 additional attempts to generate a response within the limit if needed.</p><p>If still unsuccessful, it will truncate the response as a last resort.</p>'),
    ];

    $form['debug'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Debugging'),
      '#collapsible' => FALSE,
    ];

    $form['debug']['debug_mode'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable debug mode'),
      '#description' => $this->t('When enabled, AI Suggest will log detailed information about the generation process, including character limits and regeneration attempts.'),
      '#default_value' => $this->state->get('ai_suggest.debug_mode', FALSE),
    ];

    $form['actions'] = [
      '#type' => 'actions',
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save configuration'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->state->set('ai_suggest.debug_mode', $form_state->getValue('debug_mode'));
    $this->messenger->addStatus($this->t('The configuration options have been saved.'));
  }

}