<?php

namespace Drupal\ai_suggest;


class AiSuggestionsWidget {
  /**
   * The widget label.
   */
  const WIDGET_LABEL = 'Use AI to suggest';

  /**
   * The widget description.
   */
  const WIDGET_DESCRIPTION = '';

  /**
   * The loading message shown while generating suggestions.
   */
  const LOADING_MESSAGE = 'Reticulating splines...';
}
