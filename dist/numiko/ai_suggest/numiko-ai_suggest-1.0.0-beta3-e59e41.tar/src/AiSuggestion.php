<?php

namespace Drupal\ai_suggest;

use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;
use Drupal\ai\AiProviderPluginManager;
use Symfony\Component\DependencyInjection\Attribute\Autowire;

/**
 * Service for generating AI suggestions.
 */
class AiSuggestion {

  protected AiProviderPluginManager $aiProviderManager;

  public function __construct(
    #[Autowire(service: 'ai.provider')]
    AiProviderPluginManager $aiProviderManager
  ) {
    $this->aiProviderManager = $aiProviderManager;
  }

  /**
   * Generates a suggestion from form state values.
   *
   * @param \Drupal\Core\Form\FormStateInterface $formState
   *   The form state containing values to summarize.
   *
   * @return string
   *   The generated summary.
   */
  public function getTextSuggestion(string $prompt, string $textContent) : string {
    $suggestion = '';

    $sets = $this->aiProviderManager->getDefaultProviderForOperationType('chat');
    $model = $sets['model_id'];
    $provider = $this->aiProviderManager->createInstance($sets['provider_id']);
    $provider->setConfiguration($provider->getConfiguration() + ['max_tokens' => 4096]);

    $messages = new ChatInput([
      new ChatMessage('system', $prompt),
      new ChatMessage('user', $textContent),
    ]);

    try {
      $message = $provider->chat($messages, $model)->getNormalized();
      $suggestion = $message->getText();

      if (!$suggestion) {
        throw new \Exception("No response received");
      }
    }
    catch (\Exception $e) {
      $suggestion = '';
    }

    return $suggestion;
  }

/**
   * Generates AI suggestions for taxonomy term selection based on text content.
   *
   * @param string $textContent
   *   The text content to analyze.
   * @param array $options
   *   Array of available taxonomy terms to choose from.
   *
   * @return array
   *   Array of suggested taxonomy terms.
   */
  public function getOptionsSuggestion(string $textContent, array $options = []) : array {
    $sets = $this->aiProviderManager->getDefaultProviderForOperationType('chat');
    $provider = $this->aiProviderManager->createInstance($sets['provider_id']);
    $provider->setConfiguration($provider->getConfiguration() + ['max_tokens' => 4096]);

    $optionsPrompt = 'You are a text classification assistant. Your task is to categorize the provided text by selecting all relevant taxonomy terms from the list below.

      Instructions:
      - Only select taxonomy terms from the list provided.
      - Do not include any terms that are not in the list.
      - Return the selected taxonomy terms as a comma-separated list, **without any spaces**, additional text, or explanations.
      - If no taxonomy terms are relevant, return an empty string.
      - Do not include any formatting characters like brackets or quotes.

      Taxonomy terms:
      [' . implode(', ', $options) . ']

      Example response:
      taxonomy1,taxonomy2,taxonomy3';

    $messages = new ChatInput([
      new ChatMessage('system', $optionsPrompt),
      new ChatMessage('user', $textContent),
    ]);

    $model = $sets['model_id'];

    try {
      $message = $provider->chat($messages, $model)->getNormalized();
      $response = $message->getText();

      if (!$response) {
        throw new \Exception("No response received");
      }

      return array_map('trim', explode(',', $response));
    }
    catch (\Exception $e) {
      return [];
    }
  }

}
