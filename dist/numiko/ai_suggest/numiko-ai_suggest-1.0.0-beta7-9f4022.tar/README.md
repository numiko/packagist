# AI Suggestion

Add a "Use to AI to suggest" button to various field types, this will collect all of the content on the page and send alongside a prompt stored in config.

## Usage

1. Install the AI module, and configure a chat provider and the key module.
2. Setup an AI prompt (Structure >> AI Prompt).
3. Change the field widget to use the field widget with AI suggestion (this will the allow selection of a prompt - where required).
4. On the node edit form the field will now show a "Use to AI to suggest" button.
