<?php

namespace Drupal\ai_suggest\Plugin\Field\FieldWidget;

use Drupal\ai_prompt\Entity\AiPrompt;
use Drupal\Core\Form\FormStateInterface;
use Drupal\ai_suggest\AiSuggestionsWidget;
use Drupal\Core\Field\Attribute\FieldWidget;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\text\Plugin\Field\FieldWidget\TextareaWidget;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Plugin implementation of the 'text_ai_suggestion' widget.
 */
#[FieldWidget(
  id: 'text_ai_suggestion',
  label: new TranslatableMarkup('Text area (with AI Suggestion)'),
  field_types: ['text_long', 'string_long'],
)]
class AiSuggestTextareaWidget extends TextareaWidget {

  /**
   * The entity type manager.
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  #[\Override]
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    $instance = parent::create(
      $container,
      $configuration,
      $plugin_id,
      $plugin_definition
    );
    $instance->entityTypeManager = $container->get('entity_type.manager');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  #[\Override]
  public static function defaultSettings() {
    return [
      'prompt' => '',
    ] + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  #[\Override]
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $element = parent::settingsForm($form, $form_state);

    $element['rows']['#description'] = $this->t('Text editors may override this setting.');

    $entities = $this->entityTypeManager->getStorage('ai_prompt')->loadByProperties(['status' => TRUE]);
    $options = [];
    foreach ($entities as $entity) {
      $options[$entity->id()] = $entity->label();
    }

    $element['prompt'] = [
      '#type' => 'select',
      '#required' => TRUE,
      '#title' => $this->t('Select the prompt'),
      '#default_value' => $this->getSetting('prompt'),
      '#options' => $options,
    ];
    return $element;
  }

  /**
   * {@inheritdoc}
   */
  #[\Override]
  public function settingsSummary() {
    $summary = parent::settingsSummary();

    $prompt = $this->getSetting('prompt');
    if (!empty($prompt)) {
      $entity = $this->entityTypeManager->getStorage('ai_prompt')->load($prompt);
      if ($entity) {
        $summary[] = $this->t('Prompt: @prompt', ['@prompt' => $entity->label()]);
      }
    }

    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  #[\Override]
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $formState) {
    $element = parent::formElement($items, $delta, $element, $form, $formState);

    $fieldName = $items->getName();
    $fieldWrapper = 'ai-suggest-wrapper-' . $fieldName . '-' . $delta;
    $suggestButtonName = 'ai_suggest_' . $fieldName . '-' . $delta;

    $element['#prefix'] = '<div id="' . $fieldWrapper . '">';
    $element['#suffix'] = '</div>';

    $triggeringElement = $formState->getTriggeringElement();
    if ($triggeringElement && $triggeringElement['#name'] === $suggestButtonName) {
      $prompt = AiPrompt::load($this->getSetting('prompt'));
      $textContent = \Drupal::service('ai_suggest.form_state_helper')->getTextContentFromFormState($formState);
      $suggestResponse = \Drupal::service('ai_suggest.suggestion')->getTextSuggestion($prompt->prompt, $textContent);
      $element['#value'] = $suggestResponse;
    }

    $element['ai_suggest'] = [
      '#type' => 'button',
      '#value' => $this->t(AiSuggestionsWidget::WIDGET_LABEL),
      '#description' => $this->t(AiSuggestionsWidget::WIDGET_DESCRIPTION),
      '#name' => $suggestButtonName,
      '#weight' => 100,
      '#limit_validation_errors' => [],
      '#ajax' => [
        'callback' => [get_called_class(), 'ajaxAiSuggestCallback'],
        'event' => 'click',
        'wrapper' => $fieldWrapper,
        'progress' => [
          'type' => 'throbber',
          'message' => $this->t(AiSuggestionsWidget::LOADING_MESSAGE),
        ],
      ],
    ];

    return $element;
  }

  /**
   * AJAX callback to handle AI suggestion.
   */
  public static function ajaxAiSuggestCallback(array &$form, FormStateInterface $formState) {
    $triggeringElement = $formState->getTriggeringElement();
    $fieldName = $triggeringElement['#parents'][0];
    return $form[$fieldName];
  }

}
