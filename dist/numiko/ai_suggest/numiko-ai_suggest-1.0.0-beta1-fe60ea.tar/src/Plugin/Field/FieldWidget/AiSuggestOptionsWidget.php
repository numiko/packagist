<?php

namespace Drupal\ai_suggest\Plugin\Field\FieldWidget;

use Drupal\ai_suggest\AiSuggestionsWidget;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Field\Attribute\FieldWidget;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Field\Plugin\Field\FieldWidget\OptionsButtonsWidget;

/**
 * Plugin implementation of the 'options_ai_suggestion' widget.
 */
#[FieldWidget(
  id: 'options_ai_suggestion',
  label: new TranslatableMarkup('Check boxes/radio buttons (with AI Suggestion)'),
  field_types: [
    'boolean',
    'entity_reference',
    'list_integer',
    'list_float',
    'list_string',
  ],
  multiple_values: TRUE,
)]
class AiSuggestOptionsWidget extends OptionsButtonsWidget {

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $formState) {
    $element = parent::formElement($items, $delta, $element, $form, $formState);

    $fieldName = $items->getName();
    $fieldWrapper = 'ai-suggest-wrapper-' . $fieldName . '-' . $delta;
    $suggestButtonName = 'ai_suggest_' . $fieldName . '-' . $delta;

    $element['#prefix'] = '<div id="' . $fieldWrapper . '">';
    $element['#suffix'] = '</div>';

    $triggeringElement = $formState->getTriggeringElement();
    if ($triggeringElement && $triggeringElement['#name'] === $suggestButtonName) {
      $textContent = \Drupal::service('ai_suggest.form_state_helper')->getTextContentFromFormState($formState);
      $options = [];
      foreach ($element['#options'] as $id => $option) {
        $options[$id] = (string)$option;
      }
      $suggestResponse = \Drupal::service('ai_suggest.suggestion')->getOptionsSuggestion($textContent, $options);
      $element['#default_value'] = array_keys(array_intersect($options, $suggestResponse));
    }

    $element['ai_suggest'] = [
      '#type' => 'button',
      '#value' => $this->t(AiSuggestionsWidget::WIDGET_LABEL),
      '#description' => $this->t(AiSuggestionsWidget::WIDGET_DESCRIPTION),
      '#name' => $suggestButtonName,
      '#weight' => 100,
      '#limit_validation_errors' => [],
      '#ajax' => [
        'callback' => [get_called_class(), 'ajaxAiSuggestCallback'],
        'event' => 'click',
        'wrapper' => $fieldWrapper,
        'progress' => [
          'type' => 'throbber',
          'message' => $this->t(AiSuggestionsWidget::LOADING_MESSAGE),
        ],
      ],
    ];

    return $element;
  }

  /**
   * AJAX callback to handle AI suggestion.
   *
   * Due to an ongoing issue around the default_value not affecting a
   * checkboxes list field we update the individual checkboxes states from the
   * default_value within the callback.
   *
   * @see https://www.drupal.org/project/drupal/issues/1100170
   */
  public static function ajaxAiSuggestCallback(array &$form, FormStateInterface $formState) {
    $triggeringElement = $formState->getTriggeringElement();
    $fieldName = $triggeringElement['#parents'][0];
    foreach ($form[$fieldName]['widget']['#default_value'] as $key) {
      $form[$fieldName]['widget'][$key]['#checked'] = TRUE;
    }
    return $form[$fieldName];
  }

}
