<?php

namespace Drupal\routes_access_test\Controller;

/**
 * Router for test routes.
 */
class RatController {

  function main() { }
  function access() { }
  function custom() { }

}
