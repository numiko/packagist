<?php

namespace Drupal\personas\Hook;

use Drupal\Component\Utility\DeprecationHelper;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\personas\Batch\Processor;
use Drupal\personas\PersonaInterface;
use Drupal\personas\PersonaUtility;
use Drupal\user\RoleInterface;
use Drupal\user\UserInterface;

/**
 * Entity hook implementations for personas.
 */
final class EntityHooks {

  /**
   * Ignore these roles since the user module handles them specially.
   */
  protected const array SKIP_ROLES = [
    RoleInterface::ANONYMOUS_ID,
    RoleInterface::AUTHENTICATED_ID,
  ];

  public function __construct(private Processor $batchProcessor) {}

  /**
   * Implements hook_persona_update().
   *
   * Adds and removes user roles for all users with the updated persona.
   */
  #[Hook('persona_update')]
  public function personaUpdate(PersonaInterface $persona): void {
    $current_roles = $persona->getRoles();
    /** @var \Drupal\personas\PersonaInterface $original */
    $original = DeprecationHelper::backwardsCompatibleCall(\Drupal::VERSION, '11.2.0', fn() => $persona->getOriginal(), fn() => $persona->original);
    $original_roles = $original->getRoles();
    $add_roles = array_diff($current_roles, $original_roles, self::SKIP_ROLES);
    $remove_roles = array_diff($original_roles, $current_roles, self::SKIP_ROLES);
    // If there are no roles to update, return and do nothing.
    if (empty($add_roles) && empty($remove_roles)) {
      return;
    }
    $this->batchProcessor->process($persona);
  }

  /**
   * Implements hook_user_presave().
   *
   * Updates the user roles to save for a user based on the user's persona(s).
   */
  #[Hook('user_presave')]
  public function userPresave(UserInterface $user): void {
    // Gets a list of roles from the set personas.
    $persona_roles = PersonaUtility::rolesFromUserPersonas($user);
    // Gets a list of roles currently on the user.
    $user_roles = $user->getRoles();
    // Compiles lists of roles to add and to remove from the user.
    $add_roles = array_diff($persona_roles, $user_roles, self::SKIP_ROLES);
    $remove_roles = array_diff($user_roles, $persona_roles, self::SKIP_ROLES);
    // Do add the roles that are part of the personas but not yet on the user.
    array_walk($add_roles, fn ($role) => $user->addRole($role));
    // Do remove the roles not specified by any persona on the user.
    array_walk($remove_roles, fn($role) => $user->removeRole($role));
  }

}
