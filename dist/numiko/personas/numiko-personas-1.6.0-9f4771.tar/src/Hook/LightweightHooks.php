<?php

namespace Drupal\personas\Hook;

use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Lightweight hook implementations for personas.
 */
final class LightweightHooks {
  use StringTranslationTrait;

  public function __construct(TranslationInterface $stringTranslation) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Implements hook_help().
   */
  #[Hook('help')]
  public function help(string $route_name, RouteMatchInterface $route_match): ?string {
    switch ($route_name) {
      // Main module help for the personas module.
      case 'help.page.personas':
        $output = '';
        $output .= '<h3>' . $this->t('About') . '</h3>';
        $output .= '<p>' . $this->t('Personas provides an abstraction on top of Drupal&#039;s role system. It promotes best practices and simplifies permissions management.') . '</p>';
        return $output;

      default:
        return NULL;
    }
  }

  /**
   * Implements hook_entity_base_field_info().
   *
   * Attaches a field to the user entity on which to store personas.
   */
  #[Hook('entity_base_field_info')]
  public function entityBaseFieldInfo(EntityTypeInterface $entity_type): ?array {
    if ($entity_type->id() != 'user') {
      return NULL;
    }
    $fields = [];
    $fields['personas'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel($this->t('Personas'))
      ->setCardinality(BaseFieldDefinition::CARDINALITY_UNLIMITED)
      ->setDescription($this->t('The personas the user has.'))
      ->setSetting('target_type', 'persona')
      ->setDisplayConfigurable('view', TRUE);
    return $fields;
  }

}
