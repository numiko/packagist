<?php

namespace Drupal\personas;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\user\UserInterface;

/**
 * Provides utility functions for personas.
 */
class PersonaUtility implements PersonaUtilityInterface {

  public function __construct(protected EntityTypeManagerInterface $entityTypeManager) {}

  /**
   * {@inheritDoc}
   */
  public function getAllPersonaLabels(array $filter_roles = []): array {
    return array_map(static fn ($persona) => $persona->label(), $this->getAllPersonas($filter_roles));
  }

  /**
   * {@inheritDoc}
   */
  public function getAllPersonas(array $filter_roles = []): array {
    $personas = $this->entityTypeManager->getStorage('persona')->loadMultiple();

    if (!empty($filter_roles)) {
      $personas = array_filter($personas, function ($persona) use ($filter_roles) {
        $match = array_intersect($persona->getRoles(), array_flip($filter_roles));
        return count($filter_roles) == count($match);
      });
    }
    return $personas;
  }

  /**
   * {@inheritdoc}
   */
  public static function fromUser(UserInterface $user): array {
    return $user->get('personas')->referencedEntities();
  }

  /**
   * {@inheritdoc}
   */
  public static function rolesFromUserPersonas(UserInterface $user): array {
    $personas = PersonaUtility::fromUser($user);
    /** @var \Drupal\personas\PersonaInterface[] $personas */
    return array_values(array_reduce($personas, function ($roles, $persona) {
      $roles = array_merge($roles, $persona->getRoles());
      return $roles;
    }, []));
  }

  /**
   * {@inheritdoc}
   */
  public static function hasPersona(UserInterface $user, $persona): bool {
    $personas = static::fromUser($user);
    return in_array($persona, static::personaNames($personas));
  }

  /**
   * {@inheritDoc}
   */
  public static function personaNames($personas): array {
    return array_map(static fn ($persona) => $persona->id(), $personas);
  }

}
