<?php

namespace Drupal\personas\Plugin\Condition;

use Drupal\Component\Utility\Html;
use Drupal\Core\Condition\Attribute\Condition;
use Drupal\Core\Condition\ConditionPluginBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\Context\EntityContextDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\personas\PersonaUtilityInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'Persona' condition.
 */
#[Condition(
  id: 'persona',
  label: new TranslatableMarkup('Persona'),
  context_definitions: [
    'user' => new EntityContextDefinition(
      data_type: 'entity:user',
      label: new TranslatableMarkup('User')
    ),
  ])
]
class UserPersona extends ConditionPluginBase implements ContainerFactoryPluginInterface {

  /**
   * Constructs a UserPersona condition plugin.
   *
   * @param \Drupal\personas\PersonaUtilityInterface $personaUtility
   *   Persona helper function.
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param array $plugin_definition
   *   The plugin implementation definition.
   */
  public function __construct(
    protected PersonaUtilityInterface $personaUtility,
    array $configuration,
    $plugin_id,
    array $plugin_definition,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    $instance = new static(
      $container->get(PersonaUtilityInterface::class),
      $configuration,
      $plugin_id,
      $plugin_definition
    );
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form['personas'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('When the user has the following personas'),
      '#default_value' => $this->configuration['personas'],
      '#options' => array_map(fn ($name) => Html::escape((string) $name), $this->personaUtility->getAllPersonaLabels()),
      '#description' => $this->t('If you select no personas, the condition will evaluate to TRUE for all users.'),
    ];
    return parent::buildConfigurationForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'personas' => [],
    ] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function submitConfigurationForm(array &$form, FormStateInterface $form_state): void {
    $this->configuration['personas'] = array_filter($form_state->getValue('personas'));
    parent::submitConfigurationForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function summary(): TranslatableMarkup {
    $names = $this->personaUtility->getAllPersonaLabels();
    // Use the persona labels. They will be sanitized below.
    $personas = array_intersect_key($names, $this->configuration['personas']);
    if (count($personas) > 1) {
      $personas = implode(', ', $personas);
    }
    else {
      $personas = reset($personas);
    }
    if (!empty($this->configuration['negate'])) {
      return $this->t('The user is not a member of @personas', ['@personas' => $personas]);
    }
    else {
      return $this->t('The user is a member of @personas', ['@personas' => $personas]);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function evaluate(): bool {
    if (empty($this->configuration['personas']) && !$this->isNegated()) {
      return TRUE;
    }
    $user = $this->getContextValue('user');

    $wanted = array_keys($this->configuration['personas']);
    $have = $this->personaUtility->personaNames($this->personaUtility->fromUser($user));
    $intersection = array_intersect($wanted, $have);

    $has_required_personas = count($intersection) > 0;

    return $has_required_personas;
  }

}
