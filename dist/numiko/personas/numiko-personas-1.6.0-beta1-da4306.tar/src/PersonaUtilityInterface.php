<?php

namespace Drupal\personas;

use Drupal\user\UserInterface;

/**
 * Provides utility functions for personas.
 */
interface PersonaUtilityInterface {

  /**
   * Retrieves an array of persona names matching specified conditions.
   *
   * @param string[] $filter_roles
   *   (optional) List of user_role ids that should be present in the returned
   *   persona names.
   *
   * @return array<\Drupal\Core\StringTranslation\TranslatableMarkup|string|null>
   *   An associative array of persona names matching the filter criteria, keyed
   *   by its persona type id.
   */
  public function getAllPersonaLabels(array $filter_roles = []): array;

  /**
   * Retrieves an array of personas matching specified conditions.
   *
   * @param string[] $filter_roles
   *   (optional) List of user_role ids that should be present in the returned
   *   personas.
   *
   * @return \Drupal\personas\PersonaInterface[]
   *   A list of personas matching the filter criteria.
   */
  public function getAllPersonas(array $filter_roles = []): array;

  /**
   * Extracts personas from a user entity.
   *
   * @param \Drupal\user\UserInterface $user
   *   The user from which to extract personas.
   *
   * @return \Drupal\personas\PersonaInterface[]
   *   The extracted personas.
   */
  public static function fromUser(UserInterface $user): array;

  /**
   * Extracts roles from a user's personas.
   *
   * @param \Drupal\user\UserInterface $user
   *   The user from which to extract roles based on its personas.
   *
   * @return array
   *   An associative array of user_roles keyed by their ids.
   */
  public static function rolesFromUserPersonas(UserInterface $user): array;

  /**
   * Determines whether a given user has a given persona.
   *
   * @param \Drupal\user\UserInterface $user
   *   The user with which to compare.
   *
   * @param string $persona
   *   The id of the persona to check.
   *
   * @return bool
   *   Whether the given user has the specified persona.
   */
  public static function hasPersona(UserInterface $user, $persona): bool;

  /**
   * Returns a list of persona ids from a list of persona entities.
   *
   * @param \Drupal\personas\PersonaInterface[] $personas
   *   The list of personas from which to get IDs.
   *
   * @return string[]
   *   The list of persona IDs.
   */
  public static function personaNames($personas): array;

}
