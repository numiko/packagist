<?php

namespace Drupal\personas\Hook;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\personas\PersonaUtilityInterface;
use Drupal\user\UserInterface;

/**
 * Form hook implementations for personas.
 */
final class FormHooks {
  use StringTranslationTrait;

  public function __construct(
    private AccountInterface $currentUser,
    private PersonaUtilityInterface $personaUtility,
    TranslationInterface $stringTranslation,
  ) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Implements hook_form_user_form_alter().
   *
   * Adds a form element for saving user personas and disables access to the
   * roles element.
   */
  #[Hook('form_user_form_alter')]
  public function formUserFormAlter(array &$form, FormStateInterface $form_state): void {
    $account = $form_state->getFormObject()->getEntity();
    $personas = $this->personaUtility->getAllPersonaLabels();
    $current = $account->get('personas')->getValue();
    if (!empty($current)) {
      $current = array_column($current, 'target_id');
    }
    $userCanAssignAllPersonas = $this->currentUser->hasPermission('assign personas');
    if (!$userCanAssignAllPersonas) {
      foreach ($personas as $pid => $persona) {
        if (!$this->currentUser->hasPermission(sprintf('assign %s persona', $pid))) {
          unset($personas[$pid]);
        }
      }
    }
    $form['account']['personas'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Personas'),
      '#default_value' => $current,
      '#options' => $personas,
      '#access' => !empty($personas),
    ];
    $form['account']['roles']['#access'] = FALSE;
    $form['#entity_builders'][] = [FormHooks::class, 'userBuilder'];
  }

  /**
   * Maps form values to the user entity.
   *
   * @param string $entity_type
   *   The entity type id of the given entity.
   * @param \Drupal\user\UserInterface $user
   *   The user entity on which to attach form values.
   * @param array $form
   *   The current form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current form state.
   */
  public static function userBuilder($entity_type, UserInterface $user, array &$form, FormStateInterface $form_state): void {
    $value = array_values(array_filter($form_state->getValue('personas')));
    $user->set('personas', $value);
  }

}
