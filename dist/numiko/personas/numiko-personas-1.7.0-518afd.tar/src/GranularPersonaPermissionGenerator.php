<?php

namespace Drupal\personas;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * The PermissionGenerator class.
 */
class GranularPersonaPermissionGenerator {
  use StringTranslationTrait;

  /**
   * Construct a new permission generator.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager service.
   * @param \Drupal\Core\StringTranslation\TranslationInterface $stringTranslation
   *   Translation interface for the t function.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    TranslationInterface $stringTranslation,
  ) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Returns an array of permissions to assign specific personas.
   *
   * @return array
   *   An array of permissions in the correct format for permission_callbacks.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function assignmentPermissions() {
    $permissions = [];
    foreach ($this->entityTypeManager->getStorage('persona')->loadMultiple() as $pid => $persona) {
      $permissions[sprintf('assign %s persona', $pid)] = [
        'title' => $this->t('Assign %persona persona', ['%persona' => $persona->label()]),
      ];
    }
    return $permissions;
  }

}
