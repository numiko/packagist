<?php

namespace Drupal\personas;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a listing of Persona entities.
 */
class PersonaListBuilder extends ConfigEntityListBuilder {

  /**
   * The user role entity storage.
   *
   * @var \Drupal\Core\Entity\EntityStorageInterface
   */
  protected EntityStorageInterface $roleStorage;

  /**
   * {@inheritdoc}
   */
  public static function createInstance(ContainerInterface $container, EntityTypeInterface $entity_type) {
    $instance = parent::createInstance($container, $entity_type);
    $instance->roleStorage = $container->get('entity_type.manager')->getStorage('user_role');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['label'] = $this->t('Persona');
    $header['roles'] = $this->t('Roles');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['label'] = $entity->label();
    $role_labels = [];
    foreach ($entity->getRoles() as $role_id) {
      $role = $this->roleStorage->load($role_id);
      if ($role) {
        $role_labels[] = $role->label();
      }
    }
    $row['roles'] = implode(', ', $role_labels);
    return $row + parent::buildRow($entity);
  }

}
