<?php

namespace Drupal\personas\Batch;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Url;
use Drupal\personas\PersonaInterface;

class Processor {

  /**
   * The number of users to process per batch operation.
   */
  const BATCH_SIZE = 20;

  /**
   * The persona that was updated and triggering this batch process.
   */
  protected PersonaInterface $persona;

  /**
   * The maximum number of users to process per batch operation.
   *
   * @var int<1, max> batchSize
   */
  protected int $batchSize;

  public function __construct(protected EntityTypeManagerInterface $entityTypeManager) {
    $this->setBatchSize(static::BATCH_SIZE);
  }

  /**
   * Sets the batch size, must be postive.
   */
  public function setBatchSize(int $size): void {
    if ($size <= 0) {
      throw new \Exception('Batch size must be positive.');
    }
    $this->batchSize = $size;
  }

  public function process(PersonaInterface $persona): void {
    $this->persona = $persona;
    $batch = $this->getBatch();
    batch_set($batch);
    if (function_exists('drush_backend_batch_process')) {
      drush_backend_batch_process();
    }
    else {
      $redirect = batch_process(Url::fromRoute('entity.persona.collection'));
      if ($redirect) {
        $redirect->send();
      }
    }
  }

  public static function processBatch($uids, &$context) {
    $entity_type_manager = \Drupal::getContainer()->get('entity_type.manager');
    $user_storage = $entity_type_manager->getStorage('user');
    $users = $user_storage->loadMultiple($uids);
    foreach ($users as $user) {
      $user->save();
    }
  }

  /**
   * Get an assembled batch.
   */
  protected function getBatch(): array {
    $operations = [];
    $uids = $this->getUids();

    $operations = array_reduce(
      array_chunk($uids, $this->batchSize),
      function (array $ops, $chunk) {
        $ops[] = [
          [static::class, 'processBatch'],
          [$chunk],
        ];
        return $ops;
      },
      []
    );

    return [
      'operations' => $operations,
    ];
  }

  /**
   * Gets a list of UUIDs.
   *
   * @return list<string>
   *   List of UUIDs.
   */
  protected function getUids(): array {
    $result = $this->entityTypeManager->getStorage('user')
      ->getQuery()
      ->accessCheck(TRUE)
      ->condition('personas', $this->persona->id(), 'CONTAINS')
      ->execute();
    return array_values($result);
  }

}
