<?php

namespace Drupal\domain_site_alert;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;
use Drupal\site_alerts\AlertAccessControlHandler;

/**
 * Access controller for the Alert entity restricted by the current activate domain.
 *
 * @see \Drupal\site_alerts\Entity\Alert.
 */
class DomainAlertAccessControlHandler extends AlertAccessControlHandler {

  /**
   * {@inheritdoc}
   *
   * Override the AlertAccessControlHandler to check domain access.
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\site_alerts\Entity\AlertInterface $entity */
    switch ($operation) {
      case 'view':

        if ($entity->hasField('field_domain_access') && !$entity->get('field_domain_access')->isEmpty()) {
          $currentDomain = \Drupal::service('domain.negotiator')->getActiveDomain();
          foreach ($entity->get('field_domain_access')->referencedEntities() as $domain) {
            if ($domain->id() === $currentDomain->id()) {
              return AccessResult::allowed();
            }
          }
          // Forbidden if the domain is not active.
          return AccessResult::forbidden();
        }

        if ($entity->isPublished()) {
          return AccessResult::allowed();
        }
        break;
    }

    return parent::checkAccess($entity, $operation, $account);
  }

}
