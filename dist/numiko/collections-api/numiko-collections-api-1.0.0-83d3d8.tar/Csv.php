<?php

namespace Numiko\CollectionsApi;

use function GuzzleHttp\Psr7\str;

/**
 * Class Csv.
 */
class Csv {

  const MEDIA_URL = 'https://media.britishmuseum.org/media';

  const HEADERS = "Image,Object type,Museum number,Title,Denomination,Escapement,Description,Producer name,School/style,State,Authority,Ethnic name (made by),Ethnic name (assoc),Culture,Date,Production place,Find spot,Materials,Ware,Type series,Technique,Dimensions,Inscription,Curators Comments,Bib references,Location,Exhibition history,Condition,Subjects,Assoc name,Assoc place,Assoc events,Assoc titles,Acq name (acq),Acq name (finding),Acq name (excavator),Acq name (previous),Acq date,Acq notes (acq),Acq notes (exc),Dept,BM/Big number,Reg number,Add ids,Cat no,Banknote serial number,Joined objects";

  /**
   * The elastic search client.
   *
   * @var \Elasticsearch\Client
   */
  protected $client;

  /**
   * The records to write to the csv.
   *
   * @var array
   */
  protected $recordsToWrite = [];

  /**
   * The csv input.
   *
   * @var resource
   */
  protected $csv;

  /**
   * Api constructor.
   */
  function __construct(\Elasticsearch\Client $client) {
    $this->client = $client;
    $this->csv = fopen('php://output',"w");
  }

  /**
   * Generate the csv.
   *
   * @param array $params
   *
   * @return false|string
   */
  public function generate(array $params) {
    try {
      $response = $this->client->search($params);
      fwrite($this->csv, self::HEADERS);
      fwrite($this->csv, PHP_EOL);
      while (isset($response['hits']['hits']) && count($response['hits']['hits']) > 0) {
        $this->processRecords($response);
        $this->writeFile();
        $response = $this->client->scroll([
          "scroll_id" => $response['_scroll_id'],
          "scroll" => "1m"
        ]);
      }
    }
    catch (\Exception $exception) {
    }

    return stream_get_contents($this->csv);
  }

  /**
   * Process each record.
   *
   * @param $response
   */
  private function processRecords($response) {
    foreach($response['hits']['hits'] as $key => $records) {
      $this->recordsToWrite[] = str_replace("\r\n\r\n", "\r\n", str_replace('${base_url}', self::MEDIA_URL, $records['_source']['xtemplate']['csv']));
    }
  }

  /**
   * Write to the csv.
   */
  private function writeFile() {
    foreach ($this->recordsToWrite as $record) {
      fwrite($this->csv, $record);
    }
    $this->recordsToWrite = [];
  }

}