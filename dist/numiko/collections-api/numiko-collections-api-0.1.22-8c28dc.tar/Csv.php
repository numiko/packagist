<?php

namespace Numiko\CollectionsApi;

/**
 * Class Csv.
 */
class Csv {

  const MEDIA_URL = 'https://51.11.16.222/media';

  const HEADERS = "Image,Object Type,Title,Denomination,Escapement,Description,Producer Name,School/style,State,Authority,Ethnic name (made by),Ethnic name (assoc),Cultures/periods,Date,Production place,Findspot,Materials,Ware,Type series,Technique,Dimensions,Inscription,Curator’s comments,Bibliographic references,Location,Exhibition history,Condition,Subjects,Associated names,Associated places,Associated events,Associated titles,Acquisition name (acquisition),Acquisition name (funding),Acquisition name (excavator),Acquisition name (previous),Acquisition date,Acquisition notes (acquisition),Acquisition notes (excavation),Department,BM/Big number ,Registration number,Additional IDs,C&M catalogue number,Banknote serial number,Joined objects";

  /**
   * The elastic search client.
   *
   * @var \Elasticsearch\Client
   */
  protected $client;

  /**
   * The records to write to the csv.
   *
   * @var array
   */
  protected $recordsToWrite = [];

  /**
   * The csv input.
   *
   * @var resource
   */
  protected $csv;

  /**
   * Api constructor.
   */
  function __construct(\Elasticsearch\Client $client) {
    $this->client = $client;
    $this->csv = fopen('php://output',"w");
  }

  /**
   * Generate the csv.
   *
   * @param array $params
   *
   * @return false|string
   */
  public function generate(array $params) {
    try {
      $response = $this->client->search($params);
      fwrite($this->csv, self::HEADERS);
      fwrite($this->csv, PHP_EOL);
      while (isset($response['hits']['hits']) && count($response['hits']['hits']) > 0) {
        $this->processRecords($response);
        $this->writeFile();
        $response = $this->client->scroll([
          "scroll_id" => $response['_scroll_id'],
          "scroll" => "1m"
        ]);
      }
    }
    catch (\Exception $exception) {
    }

    return stream_get_contents($this->csv);
  }

  /**
   * Process each record.
   *
   * @param $response
   */
  private function processRecords($response) {
    foreach($response['hits']['hits'] as $key => $records) {
      $this->recordsToWrite[] = str_replace('${base_url}', self::MEDIA_URL, $records['_source']['xtemplate']['csv']);
    }
  }

  /**
   * Write to the csv.
   */
  private function writeFile() {
    foreach ($this->recordsToWrite as $record) {
      fwrite($this->csv, $record);
    }
    $this->recordsToWrite = [];
  }

}