<?php

namespace Numiko\CollectionsApi;

use Elasticsearch\ClientBuilder;

/**
 * Class Api.
 */
class Api {

  const TIMEOUT = 10;

  /**
   * The facet field mappings.
   *
   * @var array
   */
  const AGGREGATIONS = [
    'agent' => 'all_agents.summary.title.keyword',
    'place' => 'all_places.@hierarchy.summary.title.keyword',
    'object' => 'name.@hierarchy.summary.title.keyword',
    'ethnic_name' => 'all_ethnicities.@hierarchy.summary.title.keyword',
    'material_culture' => 'creation.peoples.culture.@hierarchy.summary.title.keyword',
    'material' => 'material.@hierarchy.summary.title.keyword',
    'technique' => 'technique.@hierarchy.summary.title.keyword',
    'ware' => 'ware.@hierarchy.summary.title.keyword',
    'denomination' => 'denomination.currency.value.keyword',
    'subject' => 'subject.@hierarchy.summary.title.keyword',
    'escapement' => 'component.@hierarchy.summary.title.keyword',
    'school_style' => 'classification.style.@hierarchy.summary.title.keyword',
    'title' => 'title.value.keyword',
  ];

  /**
   * The sort field mappings.
   *
   * @var array
   */
  const SORTS = [
    'museum_number' => 'identifier.registration_number.keyword',
    'object_name' => 'name.@sort',
    'material' => 'material.@sort',
    'denomination' => 'denomination.@sort',
    'date' => 'creation.date.from',
    'production_place' => 'creation.place.@sort',
    'findspot' => 'cumulation.place.@sort',
  ];

  /**
   * The authority term field mappings.
   *
   * These are used to find related objects.
   *
   * @var array
   */
  const AUTHORITY = [
    'agent' => 'all_agents.summary.title.keyword',
    'place' => 'all_places.summary.title.keyword',
    'state' => 'all_places.summary.title.keyword',
    'ethnic_name' => 'all_ethnicities.summary.title.keyword',
    'material_culture' => 'creation.peoples.@admin.id',
    'material' => 'material.@admin.id',
    'technique' => 'technique.@admin.id',
    'ware' => 'ware.@admin.id',
    'subject' => 'subject.@admin.id',
    'conservation' => 'procedure.conservation.@admin.id',
    'publication' => 'citation.@admin.id',
    'inscription.subj' => 'inscription.subject.@admin.id',
    'type_series' => 'parent.@admin.id',
    'object' => 'name.value.keyword',
    'escapement' => 'component.id',
    'den.currency' => 'denomination.currency.id',
    'school/style' => 'classification.@reference.@admin.id',
    'condition' => 'procedure.condition.@admin.id'
  ];

  /**
   * The autocomplete field mappings.
   *
   * @var array
   */
  const AUTOCOMPLETE = [
    'agent' => 'all_agents.summary._combined',
    'place' => 'all_places.@hierarchy.summary._combined',
    'object' => 'name.@hierarchy.summary._combined',
    'ethnic_name' => 'all_places.@hierarchy.summary._combined',
    'material_culture' => 'creation.peoples.culture.@hierarchy.summary._combined',
    'material' => 'material.@hierarchy.summary._combined',
    'technique' => 'technique.@hierarchy.summary._combined',
    'ware' => 'ware.@hierarchy.summary._combined',
    'denomination' => 'denomination.currency.value_combined',
    'subject' => 'subject.@hierarchy.summary._combined',
    'escapement' => 'component.@hierarchy.summary._combined',
    'school_style' => 'classification.style.@hierarchy.summary._combined',
    'title' => 'title.value_combined',
  ];

  const TERMS = [
    'technique' => 'TECHNIQUE',
    'subhect' => 'SUBJECT',
    'material' => 'MATERIAL',
    'material_culture' => 'MATERIAL CULTURE',
    'object' => 'OBJECT',
    'escapement' => 'ESCAPEMENT',
    'ware' => 'WARE',
    'denomination' => 'Den.Currency',
    'ethnic_name' => 'ETHNIC NAME',
    'school_style' => 'SCHOOL/STYLE',
    'subject' => 'SUBJECT',
  ];

  /**
   * The Elastics search endpoint.
   *
   * @var string
   */
  const DEV_ENDPOINT = [
    'scheme' => 'https',
    'host' => 'search-staging.britishmuseum.org',
    'path' => '/es',
    'port' => '',
  ];

  const LIVE_ENDPOINT = 'https://search.britishmuseum.org:443/es';

  /**
   * The Media location.
   *
   * @var string
   */
  const DEV_MEDIA_URL = 'https://media-staging.britishmuseum.org/';

  const LIVE_MEDIA_URL = 'https://media.britishmuseum.org/media/';

  /**
   * How many results to return per page.
   *
   * @var int
   */
  const PAGINATION_SIZE = 100;

  /**
   * How many facets to return.
   *
   * @var int
   */
  const FACET_SIZE = 100;

  /**
   * The active facets built from url params.
   *
   * @var array
   */
  protected $activeFacets = [];

  /**
   * The elastic search client.
   *
   * @var \Elasticsearch\Client
   */
  protected $client;

  /**
   * Override of the url params.
   *
   * @var array
   */
  protected $params = [];


  protected $media_url;

  /**
   * Api constructor.
   *
   * SSL verify fails.
   */
  public function __construct() {
    $endpoint = self::LIVE_ENDPOINT;
    $this->media_url = self::LIVE_MEDIA_URL;
    if (isset($_ENV['COL_ENDPOINT']) and $_ENV['COL_ENDPOINT'] == 'dev') {
      $endpoint = self::DEV_ENDPOINT;
      $this->media_url = self::DEV_MEDIA_URL;
    }
    $this->client = ClientBuilder::create()
      ->setHosts(['host' => $endpoint])
      ->setSSLVerification(FALSE)
      ->build();
  }

  /**
   * Returns the elastic search response.
   *
   * @return array
   *   The response from ES.
   */
  public function search() {

    $params = [
      'index' => 'ciim',
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => self::PAGINATION_SIZE,
        'query' => [
          'bool' => [
            'must' => [
              [
                'term' => [
                  '@datatype.base' => 'object',
                ],
              ],
              [
                'term' => [
                  '@admin.web' => 'true',
                ],
              ],
            ],
          ],
        ],
        'aggregations' => [
          'total_results' => [
            'value_count' => [
              'field' => '_id',
            ],
          ],
        ],
        '_source' => [
          'include' => [
            'name',
            'identifier',
            '@template.brief',
            'multimedia',
          ],
        ],
      ],
    ];

    // Create the elastic search aggregations query. Loop through all the mapped
    // facets, which will return the facets and the items within each facet.
    foreach (self::AGGREGATIONS as $aggregation => $field) {
      $params['body']['aggregations'][$aggregation] = [
        'terms' => [
          'field' => $field . '.keyword',
          'size' => self::FACET_SIZE,
        ],
      ];

      // Returns the total number of items for each facet. We are limiting
      // facets to the top 100 but want to display the overall total.
      $params['body']['aggregations'][$aggregation . '_total'] = [
        'cardinality' => [
          'field' => $field . '.keyword',
        ],
      ];
    }

    // Pagination query taking the page param from the url.
    $this->getPagination($params);

    // Replace the included fields if the param exists.
    if ($fields = $this->extractUrlParams('fields')) {
      $params['body']['_source']['include'] = $fields;
    }

    // Create queries to limit the results.
    $this->buildFacetQuery($params);
    $this->buildKeywordQuery($params);
    $this->buildMuseumNumberQuery($params);
    $this->buildImageOnlyQuery($params);
    $this->buildDisplayOnlyQuery($params);
    $this->buildDateQuery($params);
    $this->buildSortQuery($params);

    try {
      $response = $this->client->search($params);
      return $response;
    } catch (\Exception $exception) {
      return ['error' => 'Sorry, something went wrong please try your search again.'];
    }

    return [];
  }

  /**
   * Autocomplete for facets.
   *
   * Create a query which will search aggregations.
   *
   * @return array
   *   The response from ES.
   */
  public function facet() {
    $params = [
      'index' => 'ciim',
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => 0,
        'track_total_hits' => TRUE,
        'query' => [
          'bool' => [
            'must' => [
              [
                'term' => [
                  '@datatype.base' => 'object',
                ],
              ],
              [
                'term' => [
                  '@admin.web' => 'true',
                ],
              ],
            ],
          ],
        ],
      ],
    ];

    $facet = $this->extractUrlParams('facet');

    $query = str_replace('&', '', $this->extractUrlParams('query'));
    $terms = explode(' ', $query);
    // Get the aggregation we are searching and the keyword query string.
    // Build an ES query which will search the aggregation using the keyword.
    if ($facet == 'all') {
      $facets = ['people_organisations', 'object', 'places'];
      $params['body']['aggregations'] = [];
      foreach (self::AGGREGATIONS as $aggregation => $facet) {
        $params['body']['aggregations'][$aggregation] = [
          'filter' => [
            'bool' => [
              'must' => [],
            ],
          ],
          'aggregations' => [
            'filtered' => [
              'terms' => [
                'field' => self::AUTOCOMPLETE[$aggregation],
                "size" => self::FACET_SIZE,
              ],
            ],
          ],
        ];
        foreach ($terms as $term) {
          if (!empty($term)) {
            $params['body']['aggregations'][$aggregation]['filter']['bool']['must'][] = [
              'match' => [
                $facet . '.auto' => mb_strtolower($term),
              ],
            ];
          }
        }
        $params['body']['aggregations'][$aggregation]['aggregations']['filtered']['terms']['include'] = $this->buildAutocompleteTerms($terms);
      }
    }
    else {
      $params['body']['aggregations'] = [
        $facet => [
          'filter' => [
            'bool' => [
              'must' => [],
            ],
          ],
          'aggregations' => [
            'filtered' => [
              'terms' => [
                'field' => self::AUTOCOMPLETE[$facet],
                'size' => self::FACET_SIZE,
              ],
            ],
          ],
        ],
      ];

      foreach ($terms as $term) {
        if (!empty($term)) {
          $params['body']['aggregations'][$facet]['filter']['bool']['must'][] = [
            'match' => [
              self::AGGREGATIONS[$facet] . '.auto' => mb_strtolower($term),
            ],
          ];
        }
      }

      $params['body']['aggregations'][$facet]['aggregations']['filtered']['terms']['include'] = $this->buildAutocompleteTerms($terms);
    }

    // The suggestions that are returned need to be applicable to the current
    // result set. So we add all other queries that are applied.
    $this->buildFacetQuery($params);
    $this->buildKeywordQuery($params);
    $this->buildMuseumNumberQuery($params);
    $this->buildImageOnlyQuery($params);
    $this->buildDisplayOnlyQuery($params);
    $this->buildDateQuery($params);

    try {
      $response = $this->client->search($params);
      return $response;
    } catch (\Exception $exception) {
    }

    return [];
  }

  /**
   * Get a single object record.
   *
   * @param int|bool $id
   *   The object id.
   *
   * @return array
   *   The response from ES.
   */
  public function object($id = FALSE) {
    if (!$id) {
      $id = $this->extractUrlParams('id');
    }
    if ($id) {
      $params = [
        'index' => 'ciim',
        'client' => [
          'timeout' => self::TIMEOUT,
          'connect_timeout' => self::TIMEOUT,
        ],
        'body' => [
          'query' => [
            'bool' => [
              'must' => [
                [
                  'term' => [
                    '@datatype.base' => 'object',
                  ],
                ],
                [
                  'term' => [
                    '@admin.web' => 'true',
                  ],
                ],
                [
                  'term' => [
                    'identifier.unique_object_id.keyword' => $id,
                  ],
                ],
              ],
            ],
          ],
          '_source' => [
            'include' => [
              "identifier.prn",
              "multimedia",
              "@template.full",
              "@template.brief"
            ],
          ],
        ],
      ];

      try {
        $response = $this->client->search($params);
        return $response;
      } catch (\Exception $exception) {
      }
    }

    return [];
  }

  /**
   * Gets an image record.
   *
   * Images are within object data so we need to search objects for the image.
   *
   * @param int|bool $id
   *   The image id.
   *
   * @return array
   *   The response from ES.
   */
  public function image($id = FALSE) {
    if (!$id) {
      $id = $this->extractUrlParams('id');
    }
    if ($id) {
      $params = [
        'index' => 'ciim',
        'client' => [
          'timeout' => self::TIMEOUT,
          'connect_timeout' => self::TIMEOUT,
        ],
        'body' => [
          'query' => [
            'bool' => [
              'must' => [
                [
                  'match' => [
                    'multimedia.@admin.id' => $id,
                  ],
                ],
              ],
            ],
          ],
          '_source' => [
            'include' => [
              "identifier.unique_object_id",
              "identifier.prn",
              "multimedia",
            ],
          ],
        ],
      ];

      try {
        $response = $this->client->search($params);
        return $this->filteredImage($response, $id);
      } catch (\Exception $exception) {
      }
    }

    return [];
  }

  /**
   * Gets a term record.
   *
   * @param int|bool $id
   *   The term id.
   *
   * @return array
   *   The response from ES.
   */
  public function term($id = FALSE) {
    if (!$id) {
      $id = $this->extractUrlParams('id');
    }
    if ($id) {
      $params = [
        'client' => [
          'timeout' => self::TIMEOUT,
          'connect_timeout' => self::TIMEOUT,
        ],
        'body' => [
          [
            'index' => 'ciim',
          ],
          [
            'query' => [
              'bool' => [
                'must' => [
                  [
                    'match' => [
                      '@admin.uid' => 'mip-' . strtolower($id),
                    ],
                  ],
                ],
              ],
            ],
          ],
          [
            'index' => 'ciim',
          ],
          [
            'size' => 500,
            'query' => [
              'bool' => [
                'must' => [
                  [
                    'term' => [
                      'parent.@admin.id' => strtolower($id),
                    ],
                  ],
                ],
                'must_not' => [
                  [
                    'term' => [
                      '@datatype.base' => 'object',
                    ],
                  ],
                ],
              ],
            ],
            'sort' => [
              'summary.title.keyword' => [
                'order' => 'asc',
              ],
            ]
          ],
        ],
      ];

      try {
        $response = $this->client->msearch($params);
        return $response;
      } catch (\Exception $exception) {
      }
    }

    return [];
  }

  /**
   * Performs a search by term.
   *
   * Used to display search results on the authority pages.
   *
   * @return array
   *   The response from ES.
   */
  public function searchTerm($term = FALSE) {
    if (!$term) {
      $term = $this->extractUrlParams('id');
    }
    if ($term) {
      // Retrieve the term.
      $term_object = $this->term($term);

      if ($term_object['responses'][0] && !empty($term_object['responses'][0]['hits']['hits'])) {
        $term_object = $term_object['responses'][0]['hits']['hits'][0];
        $term_name = $term_object['_source']['summary']['title'];
        $term_type = $term_object['_source']['@datatype']['base'];
        if ($term_object['_source']['@datatype']['base'] == 'term') {
          $term_type = mb_strtolower($term_object['_source']['scheme']['value']);
        }

        if ($field = self::AUTHORITY[str_replace(" ", "_", $term_type)]) {
          $params = [
            'index' => 'ciim',
            'client' => [
              'timeout' => self::TIMEOUT,
              'connect_timeout' => self::TIMEOUT,
            ],
            'size' => 100,
            'body' => [
              'query' => [
                'bool' => [
                  'must' => [
                    [
                      'bool' => [
                        'minimum_should_match' => 1,
                        'should' => [
                          [
                            'term' => [
                              $field => [
                                'value' => strtoupper($term),
                              ],
                            ],
                          ],
                          [
                            'term' => [
                              $field => [
                                'value' => strtolower($term)
                              ],
                            ],
                          ],
                          [
                            'term' => [
                              $field => [
                                'value' => $term
                              ],
                            ],
                          ],
                        ]
                      ],
                    ],
                    [
                      'term' => [
                        '@datatype.base' => 'object',
                      ],
                    ],
                  ],
                ]
              ],
              'aggregations' => [
                'total_results' => [
                  'value_count' => [
                    'field' => '_id',
                  ],
                ],
              ],
              'sort' => [
                'name.@sort' => [
                  'order' => 'asc',
                ],
                '_score' => [
                  'order' => 'desc',
                ],
              ],
            ],
          ];

          // These fields need to be queried differently as they do not have
          // ids.
          if (in_array($field, [
            'all_agents.summary.title.keyword',
            'all_places.summary.title.keyword',
            'all_ethnicities.summary.title.keyword',
            'name.value.keyword',
          ])) {
            unset($params['body']['query']['bool']);
            $params['body']['query']['bool']['must'] = [
              [
                'match' => [
                  $field => [
                    'query' => $term_name,
                  ],
                ],
              ],
              [
                'term' => [
                  '@datatype.base' => 'object',
                ],
              ],
            ];
          }

          // Add the pagination.
          $this->getPagination($params);

          try {
            $response = $this->client->search($params);
            return $response;
          } catch (\Exception $exception) {
          }
        }
      }
    }

    return [];
  }

  /**
   * Gets a group record.
   *
   * @param int|bool $id
   *   The group id.
   *
   * @return array
   *   The response from ES.
   */
  public function group($id = FALSE) {
    if (!$id) {
      $id = $this->extractUrlParams('id');
    }
    if ($id) {
      $params = [
        'index' => 'ciim',
        'client' => [
          'timeout' => self::TIMEOUT,
          'connect_timeout' => self::TIMEOUT,
        ],
        'body' => [
          'query' => [
            'bool' => [
              'must' => [
                [
                  'term' => [
                    '@datatype.base' => 'group',
                  ],
                ],
                [
                  'term' => [
                    '@admin.uid' => 'mip-' . strtolower($id),
                  ],
                ],
              ],
            ],
          ],
        ],
      ];
      try {
        $response = $this->client->search($params);
        return $response;
      } catch (\Exception $exception) {
      }
    }

    return [];
  }

  /**
   * Performs a search to get the joined objects.
   *
   * Used to display joined objects on the group pages.
   *
   * @return array
   *   The response from ES.
   */
  public function joinedObjects($group = FALSE) {
    if (!$group) {
      $group = $this->extractUrlParams('id');
    }
    if ($group) {
      $params = [
        'index' => 'ciim',
        'client' => [
          'timeout' => self::TIMEOUT,
          'connect_timeout' => self::TIMEOUT,
        ],
        'size' => 100,
        'body' => [
          'query' => [
            'bool' => [
              'must' => [
                [
                  'term' => [
                    'group.@admin.id' => [
                      'value' => $group,
                    ],
                  ],
                ],
                [
                  'term' => [
                    '@datatype.base' => 'object',
                  ],
                ],
              ],
            ],
          ],
          'aggregations' => [
            'total_results' => [
              'value_count' => [
                'field' => '_id',
              ],
            ],
          ],
          'sort' => [
            'name.@sort' => [
              'order' => 'asc',
            ],
            '_score' => [
              'order' => 'desc',
            ],
          ],
        ],
      ];

      // Add the pagination.
      $this->getPagination($params);

      try {
        $response = $this->client->search($params);
        return $response;
      } catch (\Exception $exception) {
      }
    }

    return [];
  }

  /**
   * Fetch one or more objects by the object id.
   *
   * @param array $ids
   *   The ids.
   *
   * @return array
   *   The response.
   */
  public function fetchObjects(array $ids) {
    $params = [
      'index' => 'ciim',
    ];

    foreach ($ids as $id) {
      $params['body']['ids'][] = 'mip-' . strtolower($id);
    }

    try {
      $response = $this->client->mget($params);
      return $response;
    } catch (\Exception $exception) {
    }

    return [];
  }

  /**
   * Generate a csv download from the current result set.
   *
   * @return array|false|string
   */
  public function download() {
    $output = [];
    $params = [
      'index' => 'ciim',
      'scroll' => "1m",
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => self::PAGINATION_SIZE,
        'query' => [
          'bool' => [
            'must' => [
              [
                'term' => [
                  '@datatype.base' => 'object',
                ],
              ],
              [
                'term' => [
                  '@admin.web' => 'true',
                ],
              ],
            ],
          ],
        ],
      ],
    ];

    // Create queries to limit the results.
    $this->buildFacetQuery($params);
    $this->buildKeywordQuery($params);
    $this->buildMuseumNumberQuery($params);
    $this->buildImageOnlyQuery($params);
    $this->buildDisplayOnlyQuery($params);
    $this->buildDateQuery($params);
    $this->buildSortQuery($params);

    try {
      $csv = new Csv($this->client);
      $output = $csv->generate($params);
    } catch (\Exception $exception) {
    }

    return $output;
  }


  /**
   * Get the collection embed slice results.
   *
   * @return array
   *   The return response.
   */
  public function collectionEmbedSearch() {

    $params = [
      'index' => 'ciim',
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => 50,
        'query' => [
          'bool' => [
            'must' => [
              [
                'term' => [
                  '@datatype.base' => 'object',
                ],
              ],
              [
                'term' => [
                  '@admin.web' => 'true',
                ],
              ],
            ],
          ],
        ],
        'aggregations' => [
          'total_results' => [
            'value_count' => [
              'field' => '_id',
            ],
          ],
        ],
        '_source' => [
          'include' => [
            'name',
            'identifier',
            '@template.brief',
            'multimedia'
          ],
        ],
      ],
    ];

    // Pagination query taking the page param from the url.
    $this->getPagination($params, 50);

    // Create queries to limit the results.
    $this->buildFacetQuery($params);
    $this->buildKeywordQuery($params);
    $this->buildMuseumNumberQuery($params);
    $this->buildImageOnlyQuery($params);
    $this->buildDisplayOnlyQuery($params);
    $this->buildDateQuery($params);
    $this->buildSortQuery($params);

    try {
      $response = $this->client->search($params);
      return $response;
    } catch (\Exception $exception) {
      return ['error' => 'Sorry, something went wrong please try your search again.'];
    }

    return [];
  }

  /**
   * Gets the image information to download the image.
   *
   * @return array|bool
   */
  function imageDownload() {
    $return = [];
    $id = $this->extractUrlParams('id');
    $image = $this->image($id);
    if (!empty($image)) {
      $return['aid'] = $image["@admin"]["id"];
      $return['path'] = $this->media_url . $image['@processed']['mid']['location'];
      if (isset($image['@processed']['huge'])) {
        $return['path'] = $this->media_url . $image['@processed']['huge']['location'];
      }
      if (isset($image['@processed']['max'])) {
        $return['path'] = $this->media_url . $image['@processed']['max']['location'];
      }
      $return['file_ext'] = pathinfo($return['path'],PATHINFO_EXTENSION);

      return $return;
    }
    return FALSE;
  }

  /**
   * Override of the GET params in extractUrlParams().
   *
   * @param array $params
   *   The params to set.
   */
  public function setUrlParams(array $params) {
    $this->params = $params;
  }

  /**
   * Extracts url params from $_GET.
   *
   * We want to only get certain params from the url to stop anyone passing in
   * additional params to build up a large ES query.
   *
   * @param string $key
   *   The facet name.
   *
   * @return bool|mixed
   *   Params if any are set.
   */
  private function extractUrlParams($key) {
    if (!empty($this->params) && isset($this->params[$key])) {
      return $this->params[$key];
    }

    if (isset($_GET[$key])) {
      return $_GET[$key];
    }
    return FALSE;
  }

  /**
   * Set the active facets.
   *
   * @param string $key
   *   The facet name.
   * @param mixed $values
   *   The active values.
   */
  private function setActiveFacets($key, $values) {
    if (is_array($values)) {
      $this->activeFacets[$key] = $values;
    }
    else {
      $this->activeFacets[$key] = [$values];
    }
  }

  /**
   * Set the current sort.
   *
   * @param array $params
   *   The request body.
   */
  private function buildSortQuery(array &$params) {
    // Create the sort query but taking the sort param from the url.
    if (!$sort = $this->extractUrlParams('sort')) {
      $sort = 'object_name__asc';
    }
    $sort_plus_direction = explode('__', $sort);
    if ($mapping = self::SORTS[$sort_plus_direction[0]]) {
      $params['body']['sort'] = [
        $mapping => [
          'order' => $sort_plus_direction[1],
        ],
        '_score' => [
          'order' => 'desc',
        ],
      ];
    }
  }

  /**
   * Builds the query to search on facet terms.
   *
   * Loop through all active facets and create an elastic search query.
   *
   * @param array $params
   *   The request body.
   */
  private function buildFacetQuery(array &$params) {

    foreach (self::AGGREGATIONS as $aggregation => $field) {
      if ($facets = $this->extractUrlParams($aggregation)) {
        $this->setActiveFacets($aggregation, $facets);
      }
    }

    if (!empty($this->activeFacets)) {
      $params['body']['query']['bool']['filter']['bool']['must'] = [];
      foreach ($this->activeFacets as $category => $facets) {
        foreach ($facets as $value) {
          $params['body']['query']['bool']['filter']['bool']['must'][]['match'] = [
            self::AGGREGATIONS[$category] . '.keyword' => [
              'query' => $value,
              'operator' => 'AND',
            ],
          ];
        }
      }
    }
  }

  /**
   * Builds the query to search on keyword.
   *
   * @param array $params
   *   The request body.
   */
  private function buildKeywordQuery(array &$params) {
    if ($keywords = $this->extractUrlParams('keyword')) {
      // Ensure its always an array.
      if (!is_array($keywords)) {
        $keywords = [$keywords];
      }
      foreach ($keywords as $keyword) {
        if ($this->isPhraseSearch($keyword)) {
          $params['body']['track_total_hits'] = TRUE;
          $params['body']['query']['bool']['must'][]['match_phrase'] = [
            '_generic_all_std' => [
              'query' => $keyword,
            ],
          ];
        }
        else {
          $params['body']['query']['bool']['must'][]['match'] = [
            '_generic_all_std' => [
              'query' => $keyword,
              'operator' => 'AND',
            ],
          ];
        }
      }
    }
  }

  /**
   * Builds the query to search on image only.
   *
   * @param array $params
   *   The request body.
   */
  private function buildImageOnlyQuery(array &$params) {
    if ($image_only = $this->extractUrlParams('image')) {
      if ($image_only == 'true') {
        $params['body']['query']['bool']['filter']['bool']['must'][] = [
          'exists' => [
            'field' => 'multimedia',
          ],
        ];
      }
    }
  }

  /**
   * Builds the query to search on objects that are on display.
   *
   * @param array $params
   *   The request body.
   */
  private function buildDisplayOnlyQuery(array &$params) {
    if ($display_only = $this->extractUrlParams('display')) {
      if ($display_only == 'true') {
        $params['body']['query']['bool']['filter']['bool']['must'][] = [
          'term' => [
            'location.availability' => 'On display',
          ],
        ];
      }
    }
  }

  /**
   * Builds the query to search on date ranges.
   *
   * @param array $params
   *   The request body.
   */
  private function buildDateQuery(array &$params) {
    $dateFrom = $this->extractUrlParams('dateFrom');
    $eraFrom = $this->extractUrlParams('eraFrom');
    $dateTo = $this->extractUrlParams('dateTo');
    $eraTo = $this->extractUrlParams('eraTo');
    if ($dateFrom !== FALSE && $eraFrom) {
      $params['body']['query']['bool']['filter']['bool']['should'][] = [
        [
          'range' => [
            'creation.date.from' => [
              'gte' => $eraFrom == 'bc' ? '-' . $dateFrom : $dateFrom,
            ],
          ],
        ],
        [
          'range' => [
            'creation.date.to' => [
              'gte' => $eraFrom == 'bc' ? '-' . $dateFrom : $dateFrom,
            ],
          ],
        ],
      ];
      $params['body']['query']['bool']['filter']['bool']['minimum_should_match'] = 1;
    }
    if ($dateTo !== FALSE && $eraTo) {
      $params['body']['query']['bool']['filter']['bool']['should'][] = [
        [
          'range' => [
            'creation.date.from' => [
              'lte' => $eraTo == 'bc' ? '-' . $dateTo : $dateTo,
            ],
          ],
        ],
        [
          'range' => [
            'creation.date.to' => [
              'lte' => $eraTo == 'bc' ? '-' . $dateTo : $dateTo,
            ],
          ],
        ],
      ];
      $params['body']['query']['bool']['filter']['bool']['minimum_should_match'] = 1;
    }

    if (($dateFrom !== FALSE && $eraFrom) && ($dateTo !== FALSE && $eraTo)) {
      unset($params['body']['query']['bool']['filter']['bool']['minimum_should_match']);
      unset($params['body']['query']['bool']['filter']['bool']['should']);
      $params['body']['query']['bool']['filter']['bool']['must'][] = [
        'range' => [
          'creation.date.from' => [
            'lte' => $eraTo == 'bc' ? '-' . $dateTo : $dateTo,
          ],
        ],
      ];

      $params['body']['query']['bool']['filter']['bool']['must'][] = [
        'range' => [
          'creation.date.to' => [
            'gte' => $eraFrom == 'bc' ? '-' . $dateFrom : $dateFrom,
          ],
        ],
      ];

    }
  }

  /**
   * Builds the query to search on the museum number.
   *
   * @param array $params
   *   The request body.
   */
  private function buildMuseumNumberQuery(array &$params) {
    if ($museum_number = $this->extractUrlParams('museum_number')) {
      // Ensure its always an array.
      if (!is_array($museum_number)) {
        $museum_number = [$museum_number];
      }
      foreach ($museum_number as $id) {
        $params['body']['query']['bool']['must'][] = [
          [
            "bool" => [
              "should" => [
                [
                  'term' => [
                    'identifier.registration_number' => $id,
                  ],
                ],
                [
                  'term' => [
                    'identifier.big_number' => $id,
                  ],
                ],
                [
                  'term' => [
                    'identifier.registration_number' => strtolower($id),
                  ],
                ],
                [
                  'term' => [
                    'identifier.big_number' => strtolower($id),
                  ],
                ],
                [
                  'term' => [
                    'identifier.registration_number' => strtoupper($id),
                  ],
                ],
                [
                  'term' => [
                    'identifier.big_number' => strtoupper($id),
                  ],
                ],
                [
                  'term' => [
                    'identifier.registration_number' => ucfirst($id),
                  ],
                ],
                [
                  'term' => [
                    'identifier.big_number' => ucfirst($id),
                  ],
                ],
              ],
            ],
          ],
        ];
      }
    }
  }

  /**
   * Checks if the keyword query is surrounded by "quotes".
   *
   * @param string $keyword
   *   The keyword.
   *
   * @return false|int
   *   True of false.
   */
  private function isPhraseSearch($keyword) {
    return preg_match('/^(["\']).*\1$/m', $keyword);
  }

  /**
   * Gets the new object id from the old id, used for redirects.
   *
   * @param string $old_id
   *   The old id.
   *
   * @return array
   *   The identifiers.
   */
  public function getNewId($old_id) {
    $params = [
      'index' => 'ciim',
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => 1,
        'query' => [
          'match' => [
            'identifier.codex_id' => $old_id,
          ],
        ],
        '_source' => ['identifier.unique_object_id'],
      ],
    ];

    try {
      $response = $this->client->search($params);
      return $response;
    } catch (\Exception $exception) {
    }

    return [];
  }

  public function getNewTermId($old_id, $type = FALSE) {
    $params = [
      'index' => 'ciim',
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => 1,
        'query' => [
          'bool' => [
            'must' => [
              [
                'match' => [
                  'identifier.codex_id' => $old_id,
                ],
              ],
            ],
            'must_not' => [
              [
                'term' => [
                  '@datatype.base' => 'object',
                ],
              ],
            ],
          ],
        ],
        '_source' => ['@admin.id'],
      ],
    ];

    if ($type) {
      $params['body']['query']['bool']['must'][] = [
        'term' => [
          '@datatype.base' => $type,
        ],
      ];
    }

    try {
      $response = $this->client->search($params);
      return $response;
    } catch (\Exception $exception) {
    }

    return [];
  }

  /**
   * Builds the query for the autocomplete.
   *
   * @param array $terms
   *   The terms to search for.
   *
   * @return string
   *   The query string.
   */
  private function buildAutocompleteTerms(array $terms) {
    $include = [];
    foreach ($terms as $term) {
      if (!empty($term)) {
        $include[] = "(.*_" . preg_quote(mb_strtolower($term)) . ".*)";
      }
    }
    return implode("", $include);
  }

  /**
   * Get the image from the image array based on the id.
   *
   * @param array $results
   *   The results to filter.
   * @param string $image_id
   *   The image id to return.
   *
   * @return array|mixed
   *   The image.
   */
  private function filteredImage(array $results, $image_id) {
    if (isset($results['hits']['hits']) && !empty($results['hits']['hits'])) {
      foreach ($results['hits']['hits'][0]['_source']['multimedia'] as $image) {
        if ($image['@admin']['id'] == $image_id) {
          $image['objectId'] = $this->getKeyedValue($results["hits"]["hits"][0]["_source"]["identifier"], "unique_object_id");
          $image['prnNumber'] = $this->getKeyedValue($results["hits"]["hits"][0]["_source"]["identifier"], "prn");
          return $image;
        }
      }
    }
    return [];
  }

  /**
   * Gets a keyed value from an array
   *
   * @param array $array
   * @param string $key
   *
   * @return string
   */
  private function getKeyedValue(array $array, $key) {
    foreach ($array as $k => $value) {
      if (isset($value[$key])) {
        return $value[$key];
      }
    }
    return '';
  }

  /**
   * Get the unique object id.
   *
   * @param array $identifiers
   *   The identifiers to check.
   *
   * @return string
   *   The id.
   */
  public function getUniqueObjectId(array $identifiers) {
    foreach ($identifiers as $identifier) {
      if (isset($identifier['unique_object_id'])) {
        return $identifier['unique_object_id'];
      }
    }
    return '';
  }

  public function getGenericTerms($term) {
    $params = [
      'index' => 'ciim',
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => 1000,
        'query' => [
          'bool' => [
            'must' => [
              [
                'term' => [
                  '@datatype.base' => 'term',
                ],
              ],
              [
                'term' => [
                  'scheme.name.value.keyword' => self::TERMS[$term],
                ],
              ],
            ],
            'must_not' => [
              [
                'exists' => [
                  'field' => 'parent.@admin.id',
                ]
              ]
            ]
          ],
        ],
        '_source' => [
          'summary.title',
          '@admin.id'
        ],
        'sort' => [
          'summary.title.keyword' => [
            'order' => 'asc',
          ],
        ]
      ],
    ];

    try {
      $response = $this->client->search($params);
      return $response;
    } catch (\Exception $exception) {
      return ['error' => 'Sorry, something went wrong please try your search again.'];
    }

    return [];
  }

  public function getPlaceTerms() {
    $params = [
      'index' => 'ciim',
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => 10000,
        'query' => [
          'bool' => [
            'must' => [
              [
                'term' => [
                  '@datatype.base' => 'place',
                ],
              ],
            ],
            'must_not' => [
              [
                'exists' => [
                  'field' => 'parent.@admin.id',
                ]
              ]
            ]
          ],
        ],
        '_source' => [
          'summary.title',
          '@admin.id'
        ],
        'sort' => [
          'summary.title.keyword' => [
            'order' => 'asc',
          ],
        ]
      ],
    ];

    try {
      $response = $this->client->search($params);
      return $response;
    } catch (\Exception $exception) {
      return ['error' => 'Sorry, something went wrong please try your search again.'];
    }

    return [];
  }

  public function getAgentTerms($scheme) {
    $params = [
      'index' => 'ciim',
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => 500,
        'query' => [
          'bool' => [
            'must' => [
              [
                'term' => [
                  '@datatype.base' => 'term',
                ],
              ],
              [
                'term' => [
                  'scheme.value.keyword' => $scheme
                ]
              ]
            ],
          ],
        ],
        '_source' => [
          'summary.title',
          '@admin.id'
        ],
        'sort' => [
          'summary.title.keyword' => [
            'order' => 'asc',
          ],
        ]
      ],
    ];
    try {
      $response = $this->client->search($params);
      return $response;
    } catch (\Exception $exception) {
      return ['error' => 'Sorry, something went wrong please try your search again.'];
    }

    return [];
  }

  public function getPeopleByField($field, $id) {
    $params = [
      'index' => 'ciim',
      'client' => [
        'timeout' => self::TIMEOUT,
        'connect_timeout' => self::TIMEOUT,
      ],
      'body' => [
        'size' => 5000,
        'query' => [
          'bool' => [
            'must' => [
              [
                'term' => [
                  '@datatype.base' => 'agent',
                ],
              ],
              [
                'term' => [
                  $field . '.@admin.id' => strtoupper($id),
                ]
              ]
            ],
          ],
        ],
        '_source' => [
          'summary.title',
          '@admin.id'
        ],
        'sort' => [
          'summary.title.keyword' => [
            'order' => 'asc',
          ],
        ]
      ],
    ];
    try {
      $response = $this->client->search($params);
      return $response;
    } catch (\Exception $exception) {
      return ['error' => 'Sorry, something went wrong please try your search again.'];
    }

    return [];
  }

  private function getPagination(array &$params, $size = self::PAGINATION_SIZE) {
    if ($pagination = $this->extractUrlParams('page')) {
      $from = (($pagination + 1) * $size) - $size;
      if ($from > 0) {
        $params['body']['from'] = $from;
      }
    }
  }

}