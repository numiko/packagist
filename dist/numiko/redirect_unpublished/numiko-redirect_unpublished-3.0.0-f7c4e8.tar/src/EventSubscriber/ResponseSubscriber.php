<?php

declare(strict_types=1);

namespace Drupal\redirect_unpublished\EventSubscriber;

use Drupal\Core\Routing\TrustedRedirectResponse;
use Drupal\node\NodeInterface;
use Drupal\redirect\Entity\Redirect;
use Drupal\redirect\RedirectRepository;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Event\ResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Redirects requests for unpublished nodes that would otherwise 403.
 */
final class ResponseSubscriber implements EventSubscriberInterface {

  public function __construct(
    private readonly RedirectRepository $redirectRepository,
  ) {}

  /**
   * Redirects a 403 response if the unpublished node has a matching redirect.
   *
   * If this request is a 403, but there is a redirect for the current node
   * then redirect to it.
   *
   * @param \Symfony\Component\HttpKernel\Event\ResponseEvent $event
   *   The response event.
   */
  public function alterResponse(ResponseEvent $event): void {
    if ($event->getResponse()->getStatusCode() !== Response::HTTP_FORBIDDEN) {
      return;
    }

    $request = $event->getRequest();
    $node = $request->attributes->get('node');
    if (!$node instanceof NodeInterface || $node->isPublished()) {
      return;
    }

    $redirect = $this->redirectRepository->findMatchingRedirect(
      substr($request->getPathInfo(), 1),
      [],
      $node->language()->getId()
    );
    if ($redirect) {
      $this->setResponse($event, $redirect);
    }
  }

  /**
   * Sets the response to a redirect.
   *
   * Built in the same manner as the redirect module's
   * RedirectRequestSubscriber does.
   *
   * @param \Symfony\Component\HttpKernel\Event\ResponseEvent $event
   *   The response event.
   * @param \Drupal\redirect\Entity\Redirect $redirect
   *   The matched redirect entity.
   */
  private function setResponse(ResponseEvent $event, Redirect $redirect): void {
    $url = $redirect->getRedirectUrl();
    $headers = [
      'X-Redirect-ID' => $redirect->id(),
    ];
    $response = new TrustedRedirectResponse(
      $url->setAbsolute()->toString(),
      $redirect->getStatusCode(),
      $headers
    );
    // See FinishResponseSubscriber::setExpiresNoCache().
    // This header will be ignored by newer clients and the cache will be
    // controlled by the Cache-Control header instead. But this is necessary
    // as PageCache expects an expiry.
    $response->setExpires(
      \DateTime::createFromFormat('j-M-Y H:i:s T', '19-Nov-1978 05:00:00 UTC')
    );
    $response->addCacheableDependency($redirect);
    $event->setResponse($response);
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      KernelEvents::RESPONSE => 'alterResponse',
    ];
  }

}
