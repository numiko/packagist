# Redirect Unpublished

Allow redirects from unpublished nodes.

Usually Drupal will 403 on an unpublished node before processing any redirect.

This looks for any redirects when an unpublished node is hit.
