<?php

namespace Drupal\media_gallery;

use Drupal\media\MediaInterface;

/**
 * Interface for a media gallery data bundle.
 */
interface MediaGalleryDataBundleInterface {

  /**
   * Get all variables to be added to the variables array.
   */
  public function getVariables(MediaInterface $media): array;

  /**
   * From the media entity get the media data dependant upon populated fields.
   */
  public function getModalData(MediaInterface $media): array;

}
