# Twig Media Gallery

Adds a twig filter to get the image data and url for media entities

```
{% set gallery_info = media | media_gallery_image_style_data('uncropped') %}

{{ gallery_info.image_width }}
```

This data includes media gallery module data - see the README of the parent module for a full list.
