<?php

namespace Drupal\media_gallery;

use Drupal\media\MediaInterface;

/**
 * Base class for getting gallery data.
 */
class MediaGalleryDataBundleBase implements MediaGalleryDataBundleInterface {

  /**
   * {@inheritDoc}
   */
  public function getVariables(MediaInterface $media): array {
    return [
      'modal_json' => json_encode($this->getModalData($media)),
    ];
  }

  /**
   * {@inheritDoc}
   */
  public function getModalData(MediaInterface $media): array {
    $data = [
      "media_type" => $media->bundle(),
      "media_id" => $media->id(),
    ];

    if ($media->hasField('name')) {
      $data['media_title'] = $media->name->value;
    }

    if ($media->hasField('field_caption') && !$media->get('field_caption')->isEmpty()) {
      $data['media_caption'] = $media->field_caption->value;
    }
    return $data;
  }

}
