<?php

namespace Drupal\media_gallery\Plugin\media_gallery_data;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\media\MediaInterface;
use Drupal\image\Entity\ImageStyle;
use Drupal\media_gallery\MediaGalleryDataBundleBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Get the image gallery data.
 *
 * @MediaGalleryDataBundle(
 *   id = "image",
 *   label = @Translation("Image"),
 * )
 */
class Image extends MediaGalleryDataBundleBase implements ContainerFactoryPluginInterface {

  /**
   * The module configuration.
   *
   * @var \Drupal\Core\Config\ImmutableConfig
   */
  protected $config;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = new static($configuration, $plugin_id, $plugin_definition);
    $instance->config = $container->get('config.factory')->get('media_gallery.settings');
    return $instance;
  }

  /**
   * {@inheritDoc}
   */
  public function getVariables(MediaInterface $media): array {
    $variables = parent::getVariables($media);

    if ($media->hasField('field_image') && !$media->get('field_image')->isEmpty()) {
      $file = $media->get('field_image')->first()->entity;
      if ($file) {
        $image_dimensions = \Drupal::service('media_gallery.transform.media_file')->getDimensions($file);
        if ($image_dimensions) {
          $variables['image_width'] = $image_dimensions["width"];
          $variables['image_height'] = $image_dimensions["height"];
          $variables['image_aspect_ratio'] = $image_dimensions["aspect_ratio"];
        }
      }
    }

    return $variables;
  }

  /**
   * {@inheritDoc}
   */
  public function getModalData(MediaInterface $media): array {
    $data = parent::getModalData($media);

    $imageStyleId = $this->config->get('image_style');

    if ($media->hasField('field_image') && !$media->get('field_image')->isEmpty()) {
      $file = $media->get('field_image')->first()->entity->getFileUri();
      if ($file) {
        $data['media_image_src'] = ImageStyle::load($imageStyleId)->buildUrl($file);
        $data['media_image_alt'] = $media->get('field_image')->first()->getValue()['alt'];
      }
    }

    return $data;
  }

}
