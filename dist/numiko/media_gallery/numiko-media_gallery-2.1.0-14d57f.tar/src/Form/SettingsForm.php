<?php

namespace Drupal\media_gallery\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\TypedConfigManagerInterface;
use Drupal\Core\DependencyInjection\AutowireTrait;
use Drupal\Core\Entity\EntityDisplayRepositoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Configure settings for media gallery.
 */
class SettingsForm extends ConfigFormBase {
  use AutowireTrait;

  /**
   * Config settings.
   */
  protected const string SETTINGS = 'media_gallery.settings';

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'media_gallery_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [static::SETTINGS];
  }

  /**
   * Class constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   Config factory service.
   * @param \Drupal\Core\Config\TypedConfigManagerInterface $typedConfigManager
   *   The typed config manager.
   * @param \Drupal\Core\StringTranslation\TranslationInterface $stringTranslation
   *   The translation service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityDisplayRepositoryInterface $entityDisplayRepository
   *   Entity display repository service.
   */
  public function __construct(
    ConfigFactoryInterface $configFactory,
    TypedConfigManagerInterface $typedConfigManager,
    TranslationInterface $stringTranslation,
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    protected readonly EntityDisplayRepositoryInterface $entityDisplayRepository,
  ) {
    parent::__construct($configFactory, $typedConfigManager);
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config(static::SETTINGS);

    $imageStyles = [];
    $imageStyleEntities = $this->entityTypeManager->getStorage('image_style')->loadMultiple();

    foreach ($imageStyleEntities as $imageStyle) {
      $imageStyles[$imageStyle->id()] = $imageStyle->label();
    }

    $form['view_modes'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('View modes to use for media gallery'),
      '#description' => $this->t('The view modes selected will have additional modal_json and image variables available to the template.'),
      '#options' => $this->entityDisplayRepository->getViewModeOptions('media'),
      '#default_value' => $config->get('view_modes'),
    ];

    $form['image_style'] = [
      '#type' => 'select',
      '#title' => $this->t('Image styles'),
      '#description' => $this->t('Selected image style will be applied to gallery image'),
      '#options' => $imageStyles,
      '#default_value' => $config->get('image_style'),
    ];

    $form['core_video_image_style'] = [
      '#type' => 'select',
      '#title' => $this->t('Core video image styles'),
      '#description' => $this->t('Selected image style will be applied to gallery core video'),
      '#options' => $imageStyles,
      '#default_value' => $config->get('core_video_image_style'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $config = $this->config(static::SETTINGS);

    $config->set('image_style', $form_state->getValue('image_style'));
    $config->set('core_video_image_style', $form_state->getValue('core_video_image_style'));

    // Set the submitted configuration setting.
    $this->configFactory->getEditable(static::SETTINGS)->set('view_modes', array_keys(array_filter($form_state->getValue('view_modes'))))->save();

    parent::submitForm($form, $form_state);
  }

}
