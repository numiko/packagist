<?php

namespace Drupal\media_gallery;

use Drupal\Component\Plugin\Exception\PluginNotFoundException;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\media\MediaInterface;
use Drupal\media_gallery\Attribute\MediaGalleryDataBundle;

/**
 * Fetch the media gallery data for the given bundle.
 */
class MediaGalleryDataManager extends DefaultPluginManager {

  /**
   * Constructs a new MediaGalleryDataManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke the alter hook with.
   */
  public function __construct(
    \Traversable $namespaces,
    CacheBackendInterface $cache_backend,
    ModuleHandlerInterface $module_handler,
  ) {
    parent::__construct(
      'Plugin/media_gallery_data',
      $namespaces,
      $module_handler,
      MediaGalleryDataBundleInterface::class,
      MediaGalleryDataBundle::class
    );

    $this->alterInfo('media_gallery_data_bundle_plugins');
    $this->setCacheBackend($cache_backend, 'media_gallery_data_bundle_plugins');
  }

  /**
   * From the media item get the plugin and extract the gallery variables.
   *
   * @param \Drupal\media\MediaInterface $media
   *   The media item for the gallery.
   */
  public function getVariables(MediaInterface $media): array {
    $bundle = $media->bundle();
    try {
      return parent::createInstance($bundle)->getVariables($media);
    }
    catch (PluginNotFoundException $e) {
      return [];
    }
  }

  /**
   * From the media item get the correct plugin and extract the gallery data.
   *
   * @param \Drupal\media\MediaInterface $media
   *   The media item for the gallery.
   */
  public function getModalData(MediaInterface $media): array {
    $bundle = $media->bundle();
    try {
      return parent::createInstance($bundle)->getModalData($media);
    }
    catch (PluginNotFoundException $e) {
      return [];
    }
  }

}
