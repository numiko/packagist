<?php

namespace Drupal\media_gallery\Plugin\media_gallery_data;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\media\MediaInterface;
use Drupal\media_gallery\Attribute\MediaGalleryDataBundle;
use Drupal\media_gallery\MediaGalleryDataBundleBase;
use Drupal\media_video_id\ExternalVideoProviderDataRetriever;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Get the core video gallery data.
 */
#[MediaGalleryDataBundle(
  id: 'core_video',
  label: new TranslatableMarkup('Core Video')
)]
class CoreVideo extends MediaGalleryDataBundleBase {

  /**
   * Extracts infomation about youtube/vimeo videos.
   */
  protected ExternalVideoProviderDataRetriever $dataProvider;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    $instance = parent::create($container, $configuration, $plugin_id, $plugin_definition);
    $instance->dataProvider = $container->get(ExternalVideoProviderDataRetriever::class);
    return $instance;
  }

  /**
   * {@inheritDoc}
   */
  public function getVariables(MediaInterface $media): array {
    $variables = parent::getVariables($media);

    if ($media->hasField('field_image') && !$media->get('field_image')->isEmpty()) {
      $file = $media->get('field_image')->first()->entity;
      if ($file) {
        $image_dimensions = $this->mediaTransform->getDimensions($file);
        $variables['image_width'] = $image_dimensions['width'];
        $variables['image_height'] = $image_dimensions['height'];
        $variables['image_aspect_ratio'] = $image_dimensions['aspect_ratio'];

      }
    }
    else {
      // If no bespoke image has been set then assume it is going to use
      // standard video dimensions.
      $variables['image_width'] = 1600;
      $variables['image_height'] = 900;
      $variables['image_aspect_ratio'] = '16:9';
    }

    return $variables;
  }

  /**
   * {@inheritDoc}
   */
  public function getModalData(MediaInterface $media): array {
    $data = parent::getModalData($media);

    $coreVideoImageStyleId = $this->getModuleConfig('core_video_image_style');

    // Some video bundles have an image field as well.
    if ($media->hasField('field_image') && !$media->get('field_image')->isEmpty()) {
      $file = $media->get('field_image')->first()->entity->getFileUri();
      if ($file) {
        $data['media_image_src'] = $this->loadImageStyle($coreVideoImageStyleId)->buildUrl($file);
        $data['media_image_alt'] = $media->get('field_image')->first()->getValue()['alt'];
      }
    }

    // Video related data - YouTube / Vimeo.
    if ($media->hasField('field_media_oembed_video')  && !$media->get('field_media_oembed_video')->isEmpty()) {
      $video_url = $media->get('field_media_oembed_video')->value;
      $video_host = parse_url($video_url, PHP_URL_HOST);
      match ($video_host) {
        'www.youtube.com', 'youtu.be' => $this->parseYoutube($video_url, $data),
        'vimeo.com' => $this->parseVimeo($video_url, $data),
        default => NULL,
      };

      return $data;
    }
  }

  /**
   * Deal with youtube urls.
   */
  private function parseYoutube(string $url, array &$data): void {
    $data['media_video_type'] = 'youtube';
    $data['media_video_id'] = $this->dataProvider->getYoutubeId($url) ?? '';
  }

  /**
   * Deal with vimeo urls.
   */
  private function parseVimeo(string $url, array &$data): void {
    $data['media_video_type'] = 'vimeo';
    $data['media_video_id'] = $this->dataProvider->getVimeoId($url) ?? '';
  }

}
