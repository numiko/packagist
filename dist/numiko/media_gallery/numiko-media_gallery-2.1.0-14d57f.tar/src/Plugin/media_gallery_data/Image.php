<?php

namespace Drupal\media_gallery\Plugin\media_gallery_data;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\media\MediaInterface;
use Drupal\media_gallery\Attribute\MediaGalleryDataBundle;
use Drupal\media_gallery\MediaGalleryDataBundleBase;

/**
 * Get the image gallery data.
 */
#[MediaGalleryDataBundle(
  id: 'image',
  label: new TranslatableMarkup('Image')
)]
class Image extends MediaGalleryDataBundleBase {

  /**
   * {@inheritDoc}
   */
  public function getVariables(MediaInterface $media): array {
    $variables = parent::getVariables($media);

    if ($media->hasField('field_image') && !$media->get('field_image')->isEmpty()) {
      $file = $media->get('field_image')->first()->entity;
      if ($file) {
        $image_dimensions = $this->mediaTransform->getDimensions($file);
        $variables['image_width'] = $image_dimensions['width'];
        $variables['image_height'] = $image_dimensions['height'];
        $variables['image_aspect_ratio'] = $image_dimensions['aspect_ratio'];
      }
    }

    return $variables;
  }

  /**
   * {@inheritDoc}
   */
  public function getModalData(MediaInterface $media): array {
    $data = parent::getModalData($media);

    $imageStyleId = $this->getModuleConfig('image_style');
    if ($media->hasField('field_image') && !$media->get('field_image')->isEmpty()) {
      $file = $media->get('field_image')->first()->entity->getFileUri();
      if ($file) {
        $data['media_image_src'] = $this->loadImageStyle($imageStyleId)->buildUrl($file);
        $data['media_image_alt'] = $media->get('field_image')->first()->getValue()['alt'];
      }
    }

    return $data;
  }

}
