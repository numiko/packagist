<?php

namespace Drupal\media_gallery\Transform;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Image\ImageFactory;
use Drupal\breakpoint\BreakpointManagerInterface;
use Drupal\file\FileInterface;

/**
 * Transform a media gallery file.
 */
class MediaGalleryFile {

  const float DEFAULT_ASPECT_RATIO = 56.25;

  /**
   * Creates a new MediaGalleryFile instance.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Image\ImageFactory $imageFactory
   *   The image factory.
   * @param \Drupal\breakpoint\BreakpointManagerInterface $breakpointManager
   *   The breakpoint manager.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory we extract the media settings from.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ImageFactory $imageFactory,
    protected BreakpointManagerInterface $breakpointManager,
    protected ConfigFactoryInterface $configFactory,
    // Uncomment when 11.3 is released:
    // protected \Drupal\responsive_image\ResponsiveImageBuilder $responsiveImageBuilder,
  ) {}

  /**
   * Get dimensions of image file once processed by image style.
   *
   * @return array{width: ?int, height: ?int, aspect_ratio: float} $dimensions
   *   Image dimensions and aspect ratio.
   */
  public function getDimensions(FileInterface $file): array {
    $config = $this->configFactory->get('media_gallery.settings');
    $imageStyle = $this->entityTypeManager->getStorage('image_style')->load($config->get('image_style'));

    $fileUri = $file->getFileUri();

    $buildUri = $imageStyle->buildUri($fileUri);

    // Preload image style for display in the modal.
    //
    // The data we need won't be available if the derivative image hasn't been
    // generated yet. See this commit and accompanying ticket:
    // https://bitbucket.org/numiko/ravensbourne-university/commits/e4b67be1ead6c90e1cd5a15be9e89828167d9ab5
    if (!file_exists($buildUri)) {
      $imageStyle->createDerivative($fileUri, $buildUri);
    }

    $imageFactory = $this->imageFactory->get($buildUri);
    $dimensions['width'] = $imageFactory->getToolkit()->getWidth();
    $dimensions['height'] = $imageFactory->getToolkit()->getHeight();

    // Calculate an aspect ratio based on the largest of height or width.
    $dimensions['aspect_ratio'] = self::DEFAULT_ASPECT_RATIO;
    if ($dimensions['width'] && $dimensions['height']) {
      $dimensions['aspect_ratio'] = $this->getAspectRatioAsPercentage($dimensions['width'], $dimensions['height']);
    }

    return $dimensions;
  }

  /**
   * Get the attributes for an image file.
   *
   * @param \Drupal\file\FileInterface $file
   *   The image file.
   * @param string $responsiveImageStyle
   *   The responsive image style.
   *
   * @return array{height: ?int, sources?: non-empty-list<\Drupal\Core\Template\Attribute>, src: string, uri: ?string, width: ?int} $attributes
   *   Return the image src url, width, height & srcset values.
   */
  public function getResponsiveImageAttributes(FileInterface $file, string $responsiveImageStyle): array {
    $imageStyle = $this->entityTypeManager->getStorage('responsive_image_style')->load($responsiveImageStyle);
    $fallbackImageStyle = $this->entityTypeManager->getStorage('image_style')->load($imageStyle->getFallbackImageStyle());
    $fileUri = $file->getFileUri();

    $buildUri = $fallbackImageStyle->buildUri($fileUri);
    if (!file_exists($buildUri)) {
      $fallbackImageStyle->createDerivative($fileUri, $buildUri);
    }

    $imageFactory = $this->imageFactory->get($fileUri);

    $attributes = [];
    $attributes['uri'] = $fileUri;
    $attributes['src'] = $fallbackImageStyle->buildUrl($fileUri);
    $attributes['width'] = $imageFactory->getToolkit()->getWidth();
    $attributes['height'] = $imageFactory->getToolkit()->getHeight();
    $breakpoints = array_reverse($this->breakpointManager->getBreakpointsByGroup($imageStyle->getBreakpointGroup()));
    foreach ($imageStyle->getKeyedImageStyleMappings() as $breakpoint_id => $multipliers) {
      if (isset($breakpoints[$breakpoint_id])) {
        $attributes['sources'][] = _responsive_image_build_source_attributes($attributes, $breakpoints[$breakpoint_id], $multipliers);
        // After 11.3:
        // $attributes['sources'][] = $this->responsiveImageBuilder->buildSourceAttributes($attributes, $breakpoints[$breakpoint_id], $multipliers);
      }
    }

    return $attributes;
  }

  /**
   * Get the aspect ratio as a percentage.
   *
   * This is calculated by taking the larger of the two and diving by the
   * smaller and dividing 100 by the result.
   *
   * For example on a 16:9 ratio it would be:
   *
   * 100 / (16 / 9) = 56.25
   */
  private static function getAspectRatioAsPercentage(int|float $width, int|float $height): float {
    if ($width >= $height) {
      return round(100 / ($width / $height), 2);
    }
    return round(100 / ($height / $width), 2);
  }

}
