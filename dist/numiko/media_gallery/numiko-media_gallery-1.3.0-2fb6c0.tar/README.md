# Media Gallery

When a 'gallery' view mode is used this module will preprocess it and add additional data.

## Installation

To install the module via composer use:

```
composer install numiko/media_gallery
```

## Usage

This module uses a preprocessor on media to add four additional variables:

- `{{ image_width }}`
- `{{ image_height }}`
- `{{ image_aspect_ratio }}`
- `{{ modal_json }}` (a JSON encoded object with details about the media entity)

### JSON data (modal_json)

This data contains a JSON encoded object which contains some of the following attributes (dependent on media type):

- media_type - core_video / image / etc
- media_id - the media ID
- media_title - the name of the media
- media_image_src - the source of the file using the `uncropped_huge` image style
- media_image_alt - the image alt text
- media_video_type - youtube / vimeo
- media_caption - the caption from `field_caption` on the media

## Extending

The gallery data is obtained using a plugin for each media type, natively this supports *image* and *core_video*.

In order to add a new media type add a new *media_gallery_data* plugin, this should implement `MediaGalleryDataBundleInterface` but most of the key functionality is obtained by extending `MediaGalleryDataBundleBase`.

Look at the native *media_gallery_data* plugins (`Plugin/media_gallery_data/CoreVideo` / `Plugin/media_gallery_data/Image`) to see how these plugins are setup.

Find details on the methods to implement and what should be included in `MediaGalleryDataBundleInterface`.

## Paragraphs

Occasionally there is a need for the gallery to make use of paragraphs (for example to add additional text data / independant captions). This can be achieved using a theme / module preprocess hook, and running the methods above.

Example code:
```
/**
 * Preprocess gallery item paragraph and add JSON data for the modal output.
 */
function paragraph_gallery_preprocess_paragraph(array &$variables) {
  $paragraph = $variables['elements']['#paragraph'];
  if ($paragraph->bundle() === 'gallery_item') {
    $media = $paragraph->get('field_media')->entity;
    $plugin_variables = \Drupal::service('plugin.manager.media_gallery_data')->getVariables($media);
    foreach ($plugin_variables as $variable_id => $variable_value) {
      $variables[$variable_id] = $variable_value;
    }
    $data = json_decode($variables['modal_json'], TRUE);
    // As the caption is on the media bubble it up to the paragraph template.
    if (!empty($data['media_caption'])) {
      $variables['media_caption'] = $data['media_caption'];
    }
    if (!$paragraph->get('field_description')->isEmpty()) {
      $data['description'] = $paragraph->get('field_description')->getString();
    }
    $variables['modal_json'] = json_encode($data);
  }
}
```