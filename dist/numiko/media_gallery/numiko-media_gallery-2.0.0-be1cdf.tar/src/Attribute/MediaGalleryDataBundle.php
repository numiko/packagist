<?php

namespace Drupal\media_gallery\Attribute;

use Drupal\Component\Plugin\Attribute\Plugin;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines a media gallery data bundle annotation object.
 *
 * @see \Drupal\media_gallery\MediaGalleryDataManager
 */
#[\Attribute(\Attribute::TARGET_CLASS)]
class MediaGalleryDataBundle extends Plugin {

  /**
   * Constructs a MediaGalleryDataBundle attribute.
   *
   * @param string $id
   *   Plugin id.
   * @param \Drupal\Core\StringTranslation\TranslatableMarkup $label
   *   The administrative label of the media gallery data bundle.
   */
  public function __construct(
    public readonly string $id,
    public readonly TranslatableMarkup $label,
  ) {}

}
