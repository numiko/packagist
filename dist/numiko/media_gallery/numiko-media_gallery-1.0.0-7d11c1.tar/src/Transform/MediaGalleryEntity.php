<?php

namespace Drupal\media_gallery\Transform;

use Drupal\Core\Render\Renderer;
use Drupal\media\MediaInterface;
use Drupal\image\Entity\ImageStyle;

/**
 * Transform a media gallery entity.
 */
class MediaGalleryEntity {

  /**
   * Get a data array from a media gallery entity.
   */
  public function getData(MediaInterface $media) {
    $data = [
      "media_type" => $media->bundle(),
      "media_id" => $media->id(),
    ];

    if ($media->hasField('name')) {
      $data['media_title'] = $media->name->value;
    }

    // Image related data.
    if ($media->hasField('field_image') && !$media->get('field_image')->isEmpty()) {
      $file = $media->get('field_image')->first()->entity->getFileUri();
      if ($file) {
        $data['media_image_src'] = ImageStyle::load('uncropped_huge')->buildUrl($file);
        $data['media_imge_alt'] = $media->get('field_image')->first()->getValue()['alt'];
      }
    }

    // Video related data - YouTube / Vimeo.
    if ($media->hasField('field_media_oembed_video')  && !$media->get('field_media_oembed_video')->isEmpty()) {
      $video_url = $media->get('field_media_oembed_video')->value;
      $video_host = parse_url($video_url, PHP_URL_HOST);
      switch ($video_host) {
        case 'www.youtube.com':
          parse_str(parse_url($video_url, PHP_URL_QUERY), $my_array_of_vars);
          $data['media_video_type'] = "youtube";
          $data['media_video_id'] = $my_array_of_vars['v'];
          break;

        case 'youtu.be':
          $data['media_video_type'] = "youtube";
          $data['media_video_id'] = basename($video_url);
          break;

        case 'vimeo.com':
          $data['media_video_type'] = "vimeo";
          $data['media_video_id'] = basename($video_url);
          break;

      }
    }

    if ($media->hasField('field_caption') && !$media->get('field_caption')->isEmpty()) {
      $data['media_caption'] = $media->field_caption->value;
    }

    return $data;
  }

}
