<?php

namespace Drupal\media_gallery;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\image\ImageStyleInterface;
use Drupal\media\MediaInterface;
use Drupal\media_gallery\Transform\MediaGalleryFile;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Base class for getting gallery data.
 *
 * Provides the following properties for free:
 * * The config factory.
 * * The entity type manager.
 * * A media gallery transform manager.
 */
abstract class MediaGalleryDataBundleBase extends PluginBase implements MediaGalleryDataBundleInterface, ContainerFactoryPluginInterface {

  /**
   * Constructs a \Drupal\media_gallery\MediaGalleryDataBundleBase object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The factory for configuration objects.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\media_gallery\Transform\MediaGalleryFile $mediaTransform
   *   Media gallery transformer.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    protected ConfigFactoryInterface $configFactory,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected MediaGalleryFile $mediaTransform,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    $instance = new static(
      $configuration, $plugin_id, $plugin_definition,
      $container->get(ConfigFactoryInterface::class),
      $container->get(EntityTypeManagerInterface::class),
      $container->get(MediaGalleryFile::class)
    );
    return $instance;
  }

  /**
   * {@inheritDoc}
   */
  public function getVariables(MediaInterface $media): array {
    return [
      'modal_json' => json_encode($this->getModalData($media)),
    ];
  }

  /**
   * {@inheritDoc}
   */
  public function getModalData(MediaInterface $media): array {
    $data = [
      "media_type" => $media->bundle(),
      "media_id" => $media->id(),
    ];

    if ($media->hasField('name')) {
      $data['media_title'] = $media->name->value;
    }

    if ($media->hasField('field_caption') && !$media->get('field_caption')->isEmpty()) {
      $data['media_caption'] = $media->field_caption->value;
    }
    return $data;
  }

  /**
   * Helper to load an image style.
   */
  protected function loadImageStyle(string $imageStyleId): ImageStyleInterface {
    return $this->entityTypeManager->getStorage('image_style')->load($imageStyleId);
  }

  /**
   * Helper to get a config entry from this module's config.
   */
  protected function getModuleConfig(string $config): string {
    return $this->configFactory->get('media_gallery.settings')->get($config);
  }

}
