<?php

namespace Drupal\twig_media_gallery\Twig;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\EntityReferenceFieldItemListInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\File\FileUrlGeneratorInterface;
use Drupal\file\FileInterface;
use Drupal\media\MediaInterface;
use Drupal\media_gallery\MediaGalleryDataManager;
use Symfony\Component\DependencyInjection\Attribute\AutowireServiceClosure;
use Twig\Extension\AbstractExtension;
use Twig\TwigFilter;

/**
 * Twig extension for handling media gallery data.
 */
class TwigExtension extends AbstractExtension {

  /**
   * Construct a twig media gallery.
   *
   * We try to use service closures to avoid instantiating heavy classes.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Closure(): \Drupal\media_gallery\MediaGalleryDataManager $mediaGalleryDataManagerClosure
   *   The media gallery data manager.
   * @param \Closure(): \Drupal\Core\File\FileUrlGeneratorInterface $fileUrlGeneratorClosure
   *   File URL generator.
   */
  public function __construct(
    protected readonly EntityTypeManagerInterface $entityTypeManager,
    #[AutowireServiceClosure(MediaGalleryDataManager::class)]
    protected readonly \Closure $mediaGalleryDataManagerClosure,
    #[AutowireServiceClosure(FileUrlGeneratorInterface::class)]
    protected readonly \Closure $fileUrlGeneratorClosure,
  ) {}

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function getFilters() {
    return [new TwigFilter('media_gallery_image_style_data', $this->mediaEntityImageStyleData(...))];
  }

  /**
   * {@inheritdoc}
   */
  public function getName(): string {
    return 'twig_media_gallery';
  }

  /**
   * Builds an image style variant data attributes from a media entity.
   *
   * Pass in the media field list and the image style.
   * @code
   *   {% set gallery_info = node.field_media|media_gallery_image_style_data('16_9') %}
   *   {{ gallery_info.image_width }}
   * @endcode
   *
   * @param \Drupal\Core\Field\FieldItemListInterface|array|null $item
   *   The render array or field item list referencing the media item.
   * @param ?string $style
   *   (Optional) Image style.
   *
   * @return ?array
   *   An array of media data including the url to represent the image style.
   */
  public function mediaEntityImageStyleData(FieldItemListInterface|array|null $item = NULL, ?string $style = NULL): ?array {
    $data = [];
    if (is_array($item) && !empty($item['#items'])) {
      $item = $item['#items'];
    }
    if (!$item || !is_object($item) || !($item instanceof EntityReferenceFieldItemListInterface)) {
      return NULL;
    }
    $entity = current($item->referencedEntities());
    if ($entity) {
      $fileUrl = NULL;
      if ($entity instanceof MediaInterface) {
        $data = ($this->mediaGalleryDataManagerClosure)()->getVariables($entity);
        $source = $entity->getSource();
        $fid = $source->getSourceFieldValue($entity);
        $file = $this->entityTypeManager->getStorage('file')->load($fid);
        if ($file) {
          $fileUrl = $file->getFileUri();
        }
      }
      elseif ($entity instanceof FileInterface) {
        $fileUrl = $entity->getFileUri();
      }
      if ($fileUrl) {
        $data['url'] = $this->imageStyle($fileUrl, $style);
      }
      return $data;
    }
    return NULL;
  }

  /**
   * Returns the URL of this image derivative for an original image path or URI.
   *
   * @param string $path
   *   The path or URI to the original image.
   * @param string $style
   *   The image style.
   *
   * @return string
   *   The absolute URL where a style image can be downloaded, suitable for use
   *   in an <img> tag. Requesting the URL will cause the image to be created.
   */
  public function imageStyle(string $path, string $style): ?string {
    $image_style = $this->entityTypeManager->getStorage('image_style')->load('style');
    if ($image_style) {
      return ($this->fileUrlGeneratorClosure)()->transformRelative($image_style->buildUrl($path));
    }
    return NULL;
  }

}
