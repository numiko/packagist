<?php

namespace Drupal\media_gallery\Hook;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\media_gallery\MediaGalleryDataManager;
use Symfony\Component\DependencyInjection\Attribute\AutowireServiceClosure;

/**
 * Hook implementations for media_gallery.
 */
final class MediaGalleryHooks {

  /**
   * Constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   Config factory.
   * @param \Closure(): \Drupal\media_gallery\MediaGalleryDataManager $mediaGalleryDataManagerClosure
   *   The media gallery data manager. We try not to instantiate it if it isn't
   *   needed.
   */
  public function __construct(
    protected readonly ConfigFactoryInterface $configFactory,
    #[AutowireServiceClosure(MediaGalleryDataManager::class)]
    protected readonly \Closure $mediaGalleryDataManagerClosure,
  ) {}

  /**
   * Implements hook_preprocess_HOOK for media.
   *
   * Preprocess media in the gallery view mode.
   */
  #[Hook('preprocess_media')]
  public function preprocessMedia(array &$variables): void {
    $media = $variables['elements']['#media'];
    $view_modes = $this->configFactory->get('media_gallery.settings')->get('view_modes');
    if (in_array($variables['view_mode'], $view_modes)) {
      $plugin_variables = ($this->mediaGalleryDataManagerClosure)()->getVariables($media);
      foreach ($plugin_variables as $variable_id => $variable_value) {
        $variables[$variable_id] = $variable_value;
      }
    }
  }

}
