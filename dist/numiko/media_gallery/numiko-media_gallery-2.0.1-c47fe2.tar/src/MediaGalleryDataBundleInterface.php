<?php

namespace Drupal\media_gallery;

use Drupal\media\MediaInterface;

/**
 * Interface for a media gallery data bundle.
 */
interface MediaGalleryDataBundleInterface {

  /**
   * Get all template variables to be added to the template variables array.
   *
   * Return an array of template variables which will be added by preprocessing
   * the media entity, this will natively include the results
   * from `getModalData()` as a JSON encoded array under `modal_json` if you
   * are extending MediaGalleryDataBundleBase and call parent::getVariables(),
   * the method should add `image_width` and `image_height` at a minimum.
   *
   * @return array
   *   Template variables to be added via a template_preprocess method.
   */
  public function getVariables(MediaInterface $media): array;

  /**
   * From the media entity get the media data dependant upon populated fields.
   *
   * This should return an array of all or a subset of the elements listed
   * below, dependant on media type:
   *  - media_type *
   *  - media_id *
   *  - media_title *
   *  - media_caption *
   *  - media_image_src
   *  - media_image_alt
   *  - media_video_type
   *  - media_video_id
   * (Those marked with an * populated automatically if you extend
   * MediaGalleryDataBundleBase class and call parent::getModalData).
   *
   * @return array
   *   Data to be added as a JSON encoded array for use by the modal.
   */
  public function getModalData(MediaInterface $media): array;

}
