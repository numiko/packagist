<?php

namespace Drupal\media_gallery;

use Drupal\media\MediaInterface;

/**
 * Interface for a media gallery data bundle.
 */
interface MediaGalleryDataBundleInterface {

  /**
   * From the media entity get the media data dependant upon populated fields.
   */
  public function getData(MediaInterface $media): array;

}
