<?php

namespace Drupal\media_gallery\Transform;

use Drupal\media\MediaInterface;

/**
 * Transform a media gallery entity.
 *
 * @deprecated in media_gallery:1.3.0 and is removed from media_gallery:2.0.0.
 *   Use \Drupal\media_gallery\MediaGalleryDataManager::getData().
 *
 * @see MediaGalleryDataManager::getData
 */
class MediaGalleryEntity {

  /**
   * Get a data array from a media gallery entity.
   */
  public function getData(MediaInterface $media) {
    return \Drupal::service('plugin.manager.media_gallery_data')->getData($media);
  }

}
