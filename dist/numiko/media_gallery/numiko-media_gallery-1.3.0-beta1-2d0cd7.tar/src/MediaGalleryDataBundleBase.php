<?php

namespace Drupal\media_gallery;

use Drupal\media\MediaInterface;

/**
 * Get the core video gallery data.
 *
 */
class MediaGalleryDataBundleBase implements MediaGalleryDataBundleInterface {

  /**
   * {@inheritDoc}
   */
  public function getData(MediaInterface $media): array {
    $data = [
      "media_type" => $media->bundle(),
      "media_id" => $media->id(),
    ];

    if ($media->hasField('name')) {
      $data['media_title'] = $media->name->value;
    }

    if ($media->hasField('field_caption') && !$media->get('field_caption')->isEmpty()) {
      $data['media_caption'] = $media->field_caption->value;
    }
    return $data;
  }

}
