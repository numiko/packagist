<?php

namespace Drupal\media_gallery\Plugin\media_gallery_data;

use Drupal\media\MediaInterface;
use Drupal\image\Entity\ImageStyle;
use Drupal\media_gallery\MediaGalleryDataBundleBase;

/**
 * Get the image gallery data.
 *
 * @MediaGalleryDataBundle(
 *   id = "image",
 *   label = @Translation("Image"),
 * )
 */
class Image extends MediaGalleryDataBundleBase {

  const HUGE_IMAGE_STYLE = 'uncropped_huge';

  /**
   * {@inheritDoc}
   */
  public function getData(MediaInterface $media): array {
    $data = parent::getData($media);

    if ($media->hasField('field_image') && !$media->get('field_image')->isEmpty()) {
      $file = $media->get('field_image')->first()->entity->getFileUri();
      if ($file) {
        $data['media_image_src'] = ImageStyle::load(self::HUGE_IMAGE_STYLE)->buildUrl($file);
        $data['media_imge_alt'] = $media->get('field_image')->first()->getValue()['alt'];
      }
    }

    return $data;
  }

}
