<?php

namespace Drupal\twig_media_gallery\Twig;

use Twig\TwigFilter;
use Drupal\file\Entity\File;
use Drupal\file\FileInterface;
use Drupal\media\MediaInterface;
use Drupal\image\Entity\ImageStyle;
use Twig\Extension\AbstractExtension;
use Drupal\Core\Field\EntityReferenceFieldItemListInterface;

/**
 * Twig extension for handling media gallery data.
 *
 * Dependency injection is not used for performance reason.
 */
class TwigExtension extends AbstractExtension {

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function getFilters() {
    $filters = [
      new TwigFilter('media_gallery_image_style_data', [
        $this,
        'mediaEntityImageStyleData',
      ]),
    ];
    return $filters;
  }

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return 'twig_media_gallery';
  }

  /**
   * Builds an image style variant data attributes from a media entity.
   *
   * Pass in the media field list and the image style.
   * @code
   *   {% set gallery_info = node.field_media|media_gallery_image_style_data('16_9') %}
   *   {{ gallery_info.image_width }}
   * @endcode
   *
   * @param Drupal\Core\Field\FieldItemListInterface|array $item
   *   The render array or field item list referencing the media item.
   * @param string $style
   *   (Optional) Image style.
   *
   * @return array|null
   *   An array of media data including the url to represent the image style.
   */
  public function mediaEntityImageStyleData($item = NULL, $style = NULL) : array {
    $data = [];
    if (is_array($item) && !empty($item['#items'])) {
      $item = $item['#items'];
    }
    if (!$item || !is_object($item) || !($item instanceof EntityReferenceFieldItemListInterface)) {
      return NULL;
    }
    $entity = current($item->referencedEntities());
    if ($entity) {
      if ($entity instanceof MediaInterface) {
        $data = \Drupal::service('plugin.manager.media_gallery_data')->getVariables($entity);
        $source = $entity->getSource();
        $fid = $source->getSourceFieldValue($entity);
        $file = File::load($fid);
        if ($file) {
          $fileUrl = $file->getFileUri();
        }
      }
      elseif ($entity instanceof FileInterface) {
        $fileUrl = $entity->getFileUri();
      }
      if ($fileUrl) {
        $data['url'] = $this->imageStyle($fileUrl, $style);
      }
      return $data;
    }
  }

  /**
   * Returns the URL of this image derivative for an original image path or URI.
   *
   * @param string $path
   *   The path or URI to the original image.
   * @param string $style
   *   The image style.
   *
   * @return string
   *   The absolute URL where a style image can be downloaded, suitable for use
   *   in an <img> tag. Requesting the URL will cause the image to be created.
   */
  public function imageStyle($path, $style) {
    /** @var \Drupal\Image\ImageStyleInterface $image_style */
    if ($image_style = ImageStyle::load($style)) {
      return \Drupal::service('file_url_generator')->transformRelative($image_style->buildUrl($path));
    }
  }

}
