# Media Gallery

When a 'gallery' view mode is used this module will preprocess it and add additional data.

## Installation

To install the module via composer use:

```
composer install numiko/media_gallery
```

## Usage

This module uses a preprocessor on media to add four additional variables:

- `{{ image_width }}`
- `{{ image_height }}`
- `{{ image_aspect_ratio }}`
- `{{ modal_json }}` (a JSON encoded object with details about the media entity)

### JSON data (modal_json)

This data contains a JSON encoded object which contains some of the following attributes (dependent on media type):

- media_type - core_video / image / etc
- media_id - the media ID
- media_title - the name of the media
- media_image_src - the source of the file using the `uncropped_huge` image style
- media_image_alt - the image alt text
- media_video_type - youtube / vimeo
- media_caption - the caption from `field_caption` on the media
