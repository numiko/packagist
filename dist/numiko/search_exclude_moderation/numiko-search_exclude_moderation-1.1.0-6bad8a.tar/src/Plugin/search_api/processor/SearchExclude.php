<?php

namespace Drupal\search_exclude_moderation\Plugin\search_api\processor;

use Drupal\node\NodeInterface;
use Drupal\search_api\IndexInterface;
use Drupal\search_api\Processor\ProcessorPluginBase;

/**
 * Class SearchExclude.
 *
 * @package Drupal\search_exclude_moderation\Plugin\search_api\processor
 *
 * @SearchApiProcessor(
 *   id = "search_exclude",
 *   label = @Translation("Exclude from search"),
 *   description = @Translation("Exclude specific nodes. Provided by search_exclude_moderation"),
 *   stages = {
 *     "alter_items" = 0
 *   }
 * )
 */
class SearchExclude extends ProcessorPluginBase {

  /**
   * {@inheritdoc}
   */
  public static function supportsIndex(IndexInterface $index) {
    foreach ($index->getDatasources() as $datasource) {
      if ($datasource->getEntityTypeId() === 'node') {
        return TRUE;
      }
    }

    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function alterIndexedItems(array &$items) {
    /** @var \Drupal\search_api\Item\ItemInterface $item */
    foreach ($items as $item_id => $item) {
      $object = $item->getOriginalObject()->getValue();
      if ($object instanceof NodeInterface) {
        if ($object->get('moderation_state')->value === 'published_excluded') {
          unset($items[$item_id]);
        }
      }
    }
  }

}
