<?php

namespace Drupal\search_exclude_moderation;

use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\node\NodeInterface;

/**
 * SearchEngineExclude class.
 */
class SearchEngineExclude {

  /**
   * SearchEngineExclude constructor.
   *
   * @param \Drupal\Core\Routing\RouteMatchInterface $currentRoute
   *   The current route data.
   */
  public function __construct(protected RouteMatchInterface $currentRoute) {}

  /**
   * Adds no index meta to page head if node is excluded.
   *
   * @param $variables
   *   HTML variables.
   */
  public function addNoIndexMetaToExcludedNode(array &$variables): void {
    $node = $this->currentRoute->getParameter('node');
    if (!$node instanceof NodeInterface) {
      return;
    }

    if ($this->currentRoute->getRouteName() !== 'entity.node.canonical') {
      return;
    }

    if ($node->get('moderation_state')->value !== 'published_excluded') {
      return;
    }

    $tag = [
      '#tag' => 'meta',
      '#attributes' => [
        'name' => 'robots',
        'content' => 'noindex',
      ],
    ];

    $variables['page']['#attached']['html_head'][] = [$tag, 'robots'];
  }

}
