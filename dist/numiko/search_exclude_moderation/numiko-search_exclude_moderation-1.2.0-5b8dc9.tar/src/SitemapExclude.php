<?php

namespace Drupal\search_exclude_moderation;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\NodeStorageInterface;

/**
 * SitemapExclude class.
 */
class SitemapExclude {

  /**
   * The node storage.
   *
   * @var \Drupal\node\NodeStorageInterface
   */
  protected NodeStorageInterface $nodeStorage;

  /**
   * SitemapExclude constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   Entity type manager.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager) {
    $this->nodeStorage = $entityTypeManager->getStorage('node');
  }

  /**
   * Remove links of excluded nodes from sitemaps.
   *
   * Alter the generated link data before the sitemap is saved.
   * If a node has moderation state published_excluded, its link is unset.
   *
   * @param array $links
   *   Array of links in sitemap.
   */
  public function removeExcludedLinks(array &$links): void {
    $nids = [];
    foreach ($links as $key => $link) {
      if (!isset($link['meta']['entity_info']['entity_type']) || $link['meta']['entity_info']['entity_type'] !== 'node') {
        continue;
      }
      if (!isset($link['meta']['entity_info']['id'])) {
        continue;
      }

      // Allow for a url generator to pre-add the moderation state.
      // If it has not been added then we will loadMultiple for all nodes added.
      if (isset($link['meta']['entity_info']['moderation_state'])) {
        if ($link['meta']['entity_info']['moderation_state'] === 'published_excluded') {
          unset($links[$key]);
        }
      }
      else {
        $nids[$link['meta']['entity_info']['id']] = $key;
      }
    }
    foreach ($this->nodeStorage->loadMultiple(array_keys($nids)) as $node) {
      if ($node->get('moderation_state')->value === 'published_excluded') {
        unset($links[$nids[$node->id()]]);
      }
    }
  }

}
