## Search Exclude Moderation

This module uses a moderation state `published_excluded` to exclude a node from search, sitemap and adds a robots
nofollow metatag to the node page.

### Setup

A new moderation state & transition needs to be setup.

1. Create a new workflow state with the machine name `published_excluded`.
2. Create a new transition with the machine name `published_excluded`.
3. Update existing transitions to include `published_excluded.`

### Tests

Example tests are included to check for robots metatag on the page and check that the node is correctly included/excluded
in the sitemap.

The tests should be copied to each project.
