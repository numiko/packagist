<?php

namespace Drupal\Tests\search_exclude_moderation\Functional;

use Drupal\integration_tests\IntegrationTestBase;

/**
 * Test the search exclude functionality.
 *
 * @group search_exclude_moderation
 */
class SearchExcludeModerationTest extends IntegrationTestBase {

  /**
   * Test that robots txt meta is present on the page.
   */
  public function testRobotsMeta() {
    $node = $this->createPublishedNode(['type' => 'page']);

    $this->visit('/node/' . $node->id());
    $this->assertSession()->responseNotContains('<meta name="robots" content="noindex" />');

    $node->set('moderation_state', 'published_excluded')->save();
    $this->visit('/node/' . $node->id());
    $this->assertSession()->responseContains('<meta name="robots" content="noindex" />');
  }

  /**
   * Test that node is excluded from sitemap when moderation state is published_excluded.
   */
  public function testSiteMapExclude() {
    $sitemapGenerator = \Drupal::service('simple_sitemap.generator');
    $node = $this->createPublishedNode(['type' => 'page']);
    $sitemapGenerator->generate('backend');
    $this->drupalGet('sitemap.xml');

    $this->assertSession()->responseContains(
      \Drupal::service('path_alias.manager')->getAliasByPath('/node/' . $node->id())
    );

    $node->set('moderation_state', 'published_excluded')->save();

    $sitemapGenerator->rebuildQueue();
    $sitemapGenerator->generate('backend');

    $this->drupalGet('sitemap.xml');
    $this->assertSession()->responseNotContains(
      \Drupal::service('path_alias.manager')->getAliasByPath('/node/' . $node->id())
    );

    // Set back to published, check its in the sitemap again.
    $node->set('moderation_state', 'published')->save();
    $sitemapGenerator->rebuildQueue();
    $sitemapGenerator->generate('backend');

    $this->drupalGet('sitemap.xml');
    $this->assertSession()->responseContains(
      \Drupal::service('path_alias.manager')->getAliasByPath('/node/' . $node->id())
    );
  }

}
