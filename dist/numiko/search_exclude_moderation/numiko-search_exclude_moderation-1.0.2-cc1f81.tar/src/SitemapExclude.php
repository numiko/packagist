<?php

namespace Drupal\search_exclude_moderation;

use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * SitemapExclude class.
 */
class SitemapExclude {

  /**
   * @var \Drupal\node\NodeStorageInterface
   */
  protected $nodeStorage;

  /**
   * SitemapExclude constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager) {
    $this->nodeStorage = $entityTypeManager->getStorage('node');
  }

  /**
   * Remove links of excluded nodes from sitemaps.
   *
   * Alter the generated link data before the sitemap is saved.
   * If a node has moderation state published_excluded, its link is unset.
   *
   * @param array $links
   *   Array of links in sitemap.
   */
  public function removeExcludedLinks(&$links) {
    foreach ($links as $key => $link) {
      if (!isset($link['meta']['entity_info']['entity_type']) || $link['meta']['entity_info']['entity_type'] !== 'node') {
        continue;
      }
      if (!isset($link['meta']['entity_info']['id'])) {
        continue;
      }

      $node = $this->nodeStorage->load($link['meta']['entity_info']['id']);
      if ($node->get('moderation_state')->value == 'published_excluded') {
        unset($links[$key]);
      }
    }
  }

}
