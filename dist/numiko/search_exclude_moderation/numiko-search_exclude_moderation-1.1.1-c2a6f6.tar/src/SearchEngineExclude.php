<?php

namespace Drupal\search_exclude_moderation;

use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\node\NodeInterface;

/**
 * SearchEngineExclude class.
 */
class SearchEngineExclude {

  /**
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  protected $currentRoute;

  /**
   * SearchEngineExclude constructor.
   *
   * @param \Drupal\Core\Routing\RouteMatchInterface $current_route
   */
  public function __construct(RouteMatchInterface $current_route) {
    $this->currentRoute = $current_route;
  }

  /**
   * Adds no index meta to page head if node is excluded.
   *
   * @param $variables
   *   HTML variables.
   */
  public function addNoIndexMetaToExcludedNode(&$variables) {
    $node = $this->currentRoute->getParameter('node');
    if (!$node instanceof NodeInterface) {
      return;
    }

    if ($this->currentRoute->getRouteName() !== 'entity.node.canonical') {
      return;
    }

    if ($node->get('moderation_state')->value !== 'published_excluded') {
      return;
    }

    $tag = [
      '#tag' => 'meta',
      '#attributes' => [
        'name' => 'robots',
        'content' => 'noindex',
      ],
    ];

    $variables['page']['#attached']['html_head'][] = [$tag, 'robots'];
  }
}
