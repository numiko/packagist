<?php

namespace Drupal\listings_filter_pinecone\Plugin\ListingQuery;

use Drupal\openai\Utility\StringHelper;
use Drupal\search_api\Query\QueryInterface;
use Drupal\listings_filter\ListingQueryBase;
use Drupal\search_api\Query\ResultSetInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Listing query service for pulling together listing results from pinecone.
 *
 * @ListingQuery(
 *   id = "listings_filter_query_pinecone",
 *   backend = "search_api_pinecone",
 *   label = @Translation("Pinecone support")
 * )
 */
class PineconeListingQuery extends ListingQueryBase {

  /**
   * The constant representing the OpenAI embedding model.
   *
   * @var string
   */
  const EMBEDDING_MODEL = 'text-embedding-ada-002';

  /**
   * The default maximum results.
   */
  const DEFAULT_TOPK = 100;

  /**
   * Open AI client.
   *
   * @var OpenAI\Client
   */
  protected $openAiClient;

  /**
   * Drupal messenger.
   *
   * @var Drupal\Core\Messenger\Messenger
   */
  protected $messenger;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('renderer'),
      $container->get('facets.manager'),
      $container->get('entity_display.repository')
    );
    $instance->openAiClient = $container->get('openai.client');
    $instance->messenger = $container->get('messenger');
    return $instance;
  }

  /**
   * Performs a Search API search and returns the resulting data.
   *
   * Results include the entities with their rendered markup,
   * the total count & the facets.
   *
   * Possible query parameters:
   *   page - used for pagination
   *   fulltext - used for fulltext keyword search
   *   language - used to add a language condition to the query
   *   filter-group - used to create filter groups
   *    `filter-group[rock-group][conjunction]=OR` accepts AND, OR conjunction.
   *   filter - used to create query conditions.
   *     `?filter[janis-filter][path]=field_first_name
   *       &filter[janis-filter][operator]=IN
   *       &filter[janis-filter][value]=Janis
   *   If using filter-group add a filter to the group with `memberOf`
   *       &filter[janis-filter][memberOf]=rock-group`
   *   count - to return only a count `count=1`
   *
   * @param array $settings
   *   The listing paragraph settings.
   * @param array|null $requestOptions
   *   The request options being passed to the get results method
   *   (commonly derived from the query parameters).
   *
   * @return array
   *   The results for the listing.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\search_api\SearchApiException|\Drupal\facets\Exception\InvalidProcessorException
   */
  public function getResults(array $settings, ?array $requestOptions = []) : array {
    $this->requestOptions = $requestOptions;

    $data = [
      'items' => [],
      'meta' => [
        'count' => 0,
        'facets' => [],
      ],
    ];

    // Pinecone requires a fulltext search to be able to encode embeddings.
    if (!isset($requestOptions['fulltext'])) {
      return $data;
    }

    // The cache ID is a combination of the fulltext search, the search index,
    // and the listing and paragraph ID's.
    $cid = implode(':', [
      $settings['search_index'],
      $settings['listing_id'],
      $settings['paragraph_id'],
      md5($requestOptions['fulltext']),
    ]);

    $cacheResults = \Drupal::cache()->get($cid);
    if ($cacheResults) {
      $results = $cacheResults->data;
    }
    else {
      $this->searchIndex = $this->loadSearchIndex($settings['search_index']);
      $query = $this->getBaseQuery($settings);
      $query->addTag('listings_filter');
      $query->setSearchId(strtr('listings_filter_facets:!index', ['!index' => $this->searchIndex->id()]));
      $results = $query->execute();
      $this->runPreprocessResultsProcessors($results, $settings);
      \Drupal::cache()->set($cid, $results);
    }

    $this->paginateResults($results, $settings['items_per_page'], $settings['result_count']);

    $data['meta']['count'] = $results->getResultCount();

    if (!$this->isCount()) {
      $items = $this->processResults($results, $settings['display_mode']);
      $data['items'] = $items;
    }

    $this->runPreprocessResponseDataProcessors($data, $settings);

    return $data;
  }

  /**
   * The pinecone base query.
   *
   * @param array $settings
   *   The listing settings.
   *
   * @return \Drupal\search_api\Query\QueryInterface
   *   The search API query.
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  protected function getBaseQuery(array $settings): QueryInterface {
    $query = $this->searchIndex->query();
    $this->setFulltextFields($query);
    $this->setLanguage($query);
    $this->setPreFilters($query, $settings['filters']);

    $query->setOption('top_k', $settings['result_count'] ?? self::DEFAULT_TOPK);

    $query->setOption('include_metadata', TRUE);
    $query->setOption('include_values', FALSE);
    $query->setOption('filters', []);

    $backend = $this->searchIndex->getServerInstance()->getBackend();
    $namespace = $backend->getNamespace($this->searchIndex);
    $query->setOption('namespace', $namespace);

    $fullText = $query->getOriginalKeys();
    $query->setOption('query_embedding', $this->getQueryEmbedding($fullText));

    $this->runAlterQueryProcessors($query, $settings);

    return $query;
  }

  /**
   * Calculates the embedding for a given query text.
   *
   * @param string $fullText
   *   The query text to calculate the embedding for.
   *
   * @return mixed|null
   *   Calculated embedding for the query text, or NULL if an error occurred.
   */
  protected function getQueryEmbedding($fullText) {
    if (!$fullText) {
      return NULL;
    }

    $fullTextQuery = StringHelper::prepareText($fullText, [], 1024);

    try {
      $response = $this->openAiClient->embeddings()->create([
        'model' => self::EMBEDDING_MODEL,
        'input' => $fullTextQuery,
      ])->toArray();
      $queryEmbedding = $response['data'][0]['embedding'] ?? NULL;
      if (!$queryEmbedding) {
        $this->messenger->addError("Unexpected embedding response: {$queryEmbedding}");
        return NULL;
      }
    }
    catch (\Exception $exception) {
      $this->messenger->addError("Query embedding exception: {$exception->getMessage()}");
      return NULL;
    }
    return $queryEmbedding;
  }

  /**
   * Set the range on the search query.
   *
   * @param \Drupal\search_api\Query\ResultSetInterface $resultSet
   *   The result set.
   * @param int $itemsPerPage
   *   The number of items per page.
   * @param string|null $limitResultCount
   *   Hard limit on the number of results to return.
   */
  protected function paginateResults(ResultSetInterface $resultSet, int $itemsPerPage, ?string $limitResultCount) {
    $resultItems = $resultSet->getResultItems();
    if (!empty($limitResultCount)) {
      $resultItems = array_slice($resultItems, 0, $limitResultCount);
    }
    else {
      $page = (!empty($this->requestOptions['page'])) ? (int) $this->requestOptions['page'] : 0;
      $resultItems = array_slice($resultItems, ($page * $itemsPerPage), $itemsPerPage);
    }
    $resultSet->setResultItems($resultItems);
  }

}
