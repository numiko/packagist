<?php

declare(strict_types=1);

namespace Drupal\purge_entity\Plugin\Purge\Processor;

use Drupal\purge\Plugin\Purge\Processor\ProcessorBase;
use Drupal\purge\Plugin\Purge\Processor\ProcessorInterface;

/**
 * Entity update processor.
 *
 * @PurgeProcessor(
 *   id = "entity_update",
 *   label = @Translation("Entity Update processor"),
 *   description = @Translation("Processes the queue every time an entity is updated."),
 *   enable_by_default = true,
 *   configform = "",
 * )
 */
class EntityUpdateProcessor extends ProcessorBase implements ProcessorInterface {}
