<?php

declare(strict_types=1);

namespace Drupal\purge_entity;

use Drupal\purge\Plugin\Purge\Invalidation\InvalidationsServiceInterface;
use Drupal\purge\Plugin\Purge\Processor\ProcessorsServiceInterface;
use Drupal\purge\Plugin\Purge\Purger\PurgersServiceInterface;

/**
 * Provides a service for instant purging of urls.
 */
class InstantPurge {

  /**
   * Constructs a InstantPurge object.
   *
   * @param \Drupal\purge\Plugin\Purge\Invalidation\InvalidationsServiceInterface $purgeInvalidationFactory
   *   The purge invalidation factory service.
   * @param \Drupal\purge\Plugin\Purge\Purger\PurgersServiceInterface $purgersService
   *   The purgers service.
   * @param \Drupal\purge\Plugin\Purge\Processor\ProcessorsServiceInterface $processorsService
   *   The processors service.
   */
  public function __construct(
    protected readonly InvalidationsServiceInterface $purgeInvalidationFactory,
    protected readonly PurgersServiceInterface $purgersService,
    protected readonly ProcessorsServiceInterface $processorsService,
  ) {}

  /**
   * Purges a url instantly using available purger.
   *
   * @param string $url
   *   The url to purge.
   *
   * @return bool
   *   TRUE if purge was successful, FALSE otherwise.
   */
  public function purgeUrl(string $url): bool {
    $processor = $this->processorsService->get('entity_update');
    if (!$processor) {
      return FALSE;
    }

    $invalidations = [
      $this->purgeInvalidationFactory->get('url', $url),
    ];

    try {
      $this->purgersService->invalidate($processor, $invalidations);
      return TRUE;
    }
    catch (\Exception $e) {
      return FALSE;
    }
  }

}
