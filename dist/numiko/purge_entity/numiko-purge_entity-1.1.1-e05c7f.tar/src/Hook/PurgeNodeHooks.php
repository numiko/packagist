<?php

declare(strict_types=1);

namespace Drupal\purge_entity\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\node\NodeInterface;
use Drupal\purge_entity\InstantPurge;
use Symfony\Component\HttpFoundation\RequestStack;
use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * Node hook implementations for purge_entity.
 */
final class PurgeNodeHooks {

  public function __construct(
    protected readonly InstantPurge $instantPurge,
    protected readonly ConfigFactoryInterface $config,
    protected readonly RequestStack $request,
  ) {}

  /**
   * Implements hook_node_presave().
   *
   * When a node is updated then submit the absolute URL to be purged.
   *
   * Carry this out before anything is changed to ensure we are clearing out the
   * existing url.
   *
   * For entities we are only interested in default revisions
   * (e.g. publish or archive states) any other state change
   * would not require a purge. For example saving a node in draft would not
   * have any impact on the cached version.
   */
  #[Hook('node_presave')]
  public function nodePresave(NodeInterface $entity): void {
    $moderation_state = $entity->get('moderation_state')->value;
    if (!$entity->isDefaultRevision()) {
      return;
    }
    // Check if the node is new or not.
    // If it is new, we don't want to purge the URL yet.
    // We also check if the moderation state is not 'draft' to avoid purging
    // when the node is in draft state.
    if (!$entity->isNew() && $moderation_state !== 'draft') {
      $url = $this->getUrlPath($entity);
      if ($url) {
        $this->instantPurge->purgeUrl($url);
      }
    }
  }

  /**
   * Implements hook_node_predelete().
   *
   * Any delete action on a node should immediately clear it from the
   * cache, this happens before the entities are all deleted so use the
   * predelete hook instead.
   */
  #[Hook('node_predelete')]
  public function nodePredelete(NodeInterface $entity): void {
    $url = $this->getUrlPath($entity);
    if ($url) {
      $this->instantPurge->purgeUrl($url);
    }
  }

  /**
   * Get the url path for a node.
   *
   * Use the base URL instead of the node URL for homepage.
   */
  private function getUrlPath(NodeInterface $entity): string {
    $front_page = $this->config->get('system.site')->get('page.front');
    $node_path = '/node/' . $entity->id();
    $url = $entity->toUrl()->setAbsolute()->toString();

    if ($front_page === $node_path) {
      $url = $this->request->getCurrentRequest()->getSchemeAndHttpHost();
    }

    return $url;
  }

}
