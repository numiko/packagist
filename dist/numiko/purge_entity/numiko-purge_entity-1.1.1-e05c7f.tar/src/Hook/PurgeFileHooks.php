<?php

declare(strict_types=1);

namespace Drupal\purge_entity\Hook;

use Drupal\Core\File\FileUrlGeneratorInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\file\FileInterface;
use Drupal\purge_entity\InstantPurge;

/**
 * File hook implementations for purge_entity.
 */
final class PurgeFileHooks {

  public function __construct(
    protected readonly InstantPurge $instantPurge,
    protected readonly FileUrlGeneratorInterface $urlGenerator,
  ) {}

  /**
   * When a file is updated then submit the absolute URL to be purged.
   *
   * For entities we are only interested in default revisions
   * (e.g. publish or archive states) any other state change
   * would not require a purge. For example saving a file in draft would not
   * have any impact on the cached version.
   */
  #[Hook('file_update')]
  public function fileUpdate(FileInterface $entity): void {
    if (!$entity->isDefaultRevision()) {
      return;
    }
    $url = $this->urlGenerator->generateAbsoluteString($entity->getFileUri());
    if ($url) {
      $this->instantPurge->purgeUrl($url);
    }
  }

  /**
   * Any delete action on a file should immediately clear it from the cache.
   */
  #[Hook('file_delete')]
  public function fileDelete(FileInterface $entity): void {
    $url = $this->urlGenerator->generateAbsoluteString($entity->getFileUri());
    if ($url) {
      $this->instantPurge->purgeUrl($url);
    }
  }

}
