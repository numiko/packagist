# Purge Entity

Allows an entity to be purged instantly when it is updated or deleted.
