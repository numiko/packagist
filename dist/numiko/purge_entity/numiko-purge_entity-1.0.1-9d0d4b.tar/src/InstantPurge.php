<?php

namespace Drupal\purge_entity;

use Exception;
use Drupal\purge\Plugin\Purge\Purger\PurgersServiceInterface;
use Drupal\purge\Plugin\Purge\Processor\ProcessorsServiceInterface;
use Drupal\purge\Plugin\Purge\Invalidation\InvalidationsServiceInterface;

/**
 * Provides a service for instant purging of urls.
 */
class InstantPurge {

  /**
   * Constructs a InstantPurge object.
   *
   * @param \Drupal\purge\Plugin\Purge\Invalidation\InvalidationsServiceInterface $purge_invalidation_factory
   *   The purge invalidation factory service.
   * @param \Drupal\purge\Plugin\Purge\Purger\PurgersServiceInterface $purgers_service
   *   The purgers service.
   * @param \Drupal\purge\Plugin\Purge\Processor\ProcessorsServiceInterface $processors_service
   *   The processors service.
   */
  public function __construct(
    protected InvalidationsServiceInterface $purgeInvalidationFactory,
    protected PurgersServiceInterface $purgersService,
    protected ProcessorsServiceInterface $processorsService
  ) {}

  /**
   * Purges a url instantly using available purger.
   *
   * @param string $url
   *   The url to purge.
   *
   * @return bool
   *   TRUE if purge was successful, FALSE otherwise.
   */
  public function purgeUrl(string $url) : bool {
    $processor = $this->processorsService->get('entity_update');
    if (!$processor) {
      return FALSE;
    }

    $invalidations = [
      $this->purgeInvalidationFactory->get('url', $url),
    ];

    try {
      $this->purgersService->invalidate($processor, $invalidations);
      return TRUE;
    }
    catch (Exception $e) {
      return FALSE;
    }
  }
}
