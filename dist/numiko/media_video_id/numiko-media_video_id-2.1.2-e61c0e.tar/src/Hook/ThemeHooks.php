<?php

namespace Drupal\media_video_id\Hook;

use Drupal\Core\File\FileUrlGeneratorInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\media\MediaInterface;
use Drupal\media_video_id\ExternalVideoProviderDataRetriever;
use Symfony\Component\DependencyInjection\Attribute\AutowireServiceClosure;

/**
 * Preprocess implementations for media_video_id.
 */
class ThemeHooks {

  /**
   * Construct this hook class.
   *
   * @param \Drupal\media_video_id\ExternalVideoProviderDataRetriever $videoDataRetriever
   *   This has no depenencies so inject it directly.
   * @param \Closure(): \Drupal\Core\File\FileUrlGeneratorInterface $fileUrlGeneratorClosure
   *   File URL generator. This is a heavy class so use a service closure.
   */
  public function __construct(
    protected readonly ExternalVideoProviderDataRetriever $videoDataRetriever,
    #[AutowireServiceClosure(FileUrlGeneratorInterface::class)]
    protected readonly \Closure $fileUrlGeneratorClosure,
  ) {}

  /**
   * Implements hook_preprocess_HOOK for media.
   */
  #[Hook('preprocess_media')]
  public function preprocessVideo(array &$variables): void {
    /** @var \Drupal\media\MediaInterface $media */
    $media = $variables['elements']['#media'];
    $supported_bundles = ['core_video', 'tiktok', 'instagram'];
    $videoURL = NULL;

    if ($media->bundle() === 'instagram' && $media->hasField('field_video_file_url') && !$media->get('field_video_file_url')->isEmpty()) {
      $videoURL = $media->get('field_video_file_url')->uri;
    }
    elseif (!in_array($media->bundle(), $supported_bundles)) {
      return;
    }
    elseif ($media->hasField('field_media_oembed_video') && !$media->get('field_media_oembed_video')->isEmpty()) {
      $videoURL = $media->get('field_media_oembed_video')->value;
    }
    else {
      return;
    }

    if ($videoURL) {
      $this->setVideoVariables($variables, $media, $videoURL);
    }
  }

  /**
   * Sets the thumbnail, provider, and videoID template variables.
   *
   * @param array $variables
   *   The preprocess variables array.
   * @param \Drupal\media\MediaInterface $media
   *   The media entity.
   * @param string $videoURL
   *   The video URL.
   */
  private function setVideoVariables(array &$variables, MediaInterface $media, string $videoURL): void {
    $thumbnailUri = $this->getThumbnailUri($media);
    if ($thumbnailUri) {
      $variables['thumbnail'] = ($this->fileUrlGeneratorClosure)()->generateAbsoluteString($thumbnailUri);
    }
    $variables['provider'] = $this->videoDataRetriever->getProvider($videoURL);
    $variables['videoID'] = $this->videoDataRetriever->getExternalProviderVideoId($videoURL);
  }

  /**
   * Retrieves the thumbnail URI from the stored thumbnail field, with fallback.
   *
   * @param \Drupal\media\MediaInterface $media
   *   The media entity.
   *
   * @return string|null
   *   The thumbnail URI, or NULL if not available.
   */
  private function getThumbnailUri(MediaInterface $media): ?string {
    if (!$media->get('thumbnail')->isEmpty()) {
      $thumbnailFile = $media->get('thumbnail')->entity;
      if ($thumbnailFile) {
        $storedUri = $thumbnailFile->getFileUri();
        // Normalise the URI scheme to match thumbnails_directory.
        $config = $media->getSource()->getConfiguration();
        if (!empty($config['thumbnails_directory'])) {
          $configScheme = parse_url($config['thumbnails_directory'], PHP_URL_SCHEME);
          $storedScheme = parse_url($storedUri, PHP_URL_SCHEME);
          if ($configScheme && $storedScheme && $configScheme !== $storedScheme) {
            $storedUri = $configScheme . '://' . substr($storedUri, strlen($storedScheme) + 3);
          }
        }
        return $storedUri;
      }
    }
    // Fallback: re-derive via the source plugin (downloads if needed).
    return $media->getSource()->getMetadata($media, 'thumbnail_uri');
  }

}
