<?php

namespace Drupal\media_video_id\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\media\OEmbed\Provider;
use GuzzleHttp\ClientInterface;
use Symfony\Component\HttpFoundation\Response;

/**
 * Oembed hook implementations for media_video_id.
 */
class OembedHooks {

  public function __construct(protected readonly ClientInterface $client) {}

  /**
   * Implements hook_oembed_resource_data_alter().
   *
   * Alters the information provided by the oEmbed resource url.
   *
   * @param array $data
   *   Data provided by the oEmbed resource.
   * @param string $url
   *   The oEmbed resource URL.
   */
  #[Hook('oembed_resource_data_alter')]
  public function oembedResourceDataAlter(array &$data, string $url): void {
    if (strpos($url, 'youtube.com/oembed') !== FALSE) {
      // Get the maximum resolution thumbnail from YouTube.
      $maxResThumbnail = str_replace('hqdefault', 'maxresdefault', $data['thumbnail_url']);
      $response = $this->client->request('GET', $maxResThumbnail, ['http_errors' => FALSE]);
      if ($response->getStatusCode() === Response::HTTP_OK) {
        $data['thumbnail_url'] = $maxResThumbnail;
      }

    }
  }

  /**
   * Implements hook_oembed_resource_url_alter().
   *
   * Load a larger thumbnail from vimeo. The max size available is 1280.
   */
  #[Hook('oembed_resource_url_alter')]
  public function oembedResourceUrlAlter(array &$parsed_url, Provider $provider): void {
    if ($provider->getName() === 'Vimeo') {
      $parsed_url['query']['width'] = 1280;
    }
  }

}
