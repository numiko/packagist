# Media Video ID

Refine the core media of drupal to be in line with our standard requirements including the output of a video ID (youtube or vimeo).

## Installation

To install the module via composer use:

```
composer install numiko/media_video_id
```

Important note: In order to make use of the YouTube thumbnail functionality you will also need the patch mentioned in more detail in the provider specific section.

## Usage

This module uses a preprocessor on media to add three additional variables:

- `{{ provider }}` (youtube / vimeo / tiktok / instagram)
- `{{ videoID }}` (the ID or shortcode of the video)
- `{{ thumbnail }}` (the url of the locally stored thumbnail — only applicable for YouTube and Vimeo; TikTok and Instagram render their own native UI)

We can then use this in the `media--core-video.html.twig` type templates, or in provider-specific templates such as `media--tiktok.html.twig` and `media--instagram.html.twig`.

Here is an example:

```
<div {{ attributes.addClass(classes) }} data-js-video-embed data-media-wrapper-class="figure-media-video">
    {# Dynamic iframe - embedded via JS #}
    <div data-js-video-placeholder></div>

    {# Cover image & play button #}
    <div data-js-video-overlay>
        <img data-src="{{ thumbnail }}" alt="" class="lazyload | absolute top-0 left-0 w-full h-full object-cover">

        {# Play button #}
        <div class="absolute top-0 left-0 w-full h-full flex items-center justify-center">
            <button class="c-icon-button c-icon-button--large c-icon-button--no-border | after:content-[''] after:absolute after:top-0 after:left-0 after:w-full after:h-full" data-js-video-id="{{ videoID }}" data-js-video-provider="{{ provider }}">
            <span class="sr-only">Play video</span>
            <svg class="c-icon c-icon--medium | ml-1 pointer-events-none" role="presentation" focusable="false">
                <use xlink:href="#sprite-icon-play"></use>
            </svg>
            </button>
        </div>
    </div>
</div>
```

## Provider specific

### Youtube

For a youtube video to work the url can be taken from either the share or the address bar of that video.

Additionally as standard the core video youtube provider uses the hqdefault poster image, this is not of high enough quality for most use cases, therefore this module provides an override for the _Oembed Content_ display to switch to the maxresdefault poster image (after verifying that that image is available).

For this to work you will need to add the following core patch:

```
"[3042423] Add a hook to modify oEmbed resource data": "https://www.drupal.org/files/issues/2022-01-05/3042423-52.patch"
```

See https://www.drupal.org/project/drupal/issues/3042423 for more information.

### Tiktok

Create a `Tiktok` media type with `video` as the media source. This is the recommended approach as TikTok embeds behave differently from YouTube and Vimeo — they require a separate Twig template and the `@numiko/video` JS package does not support TikTok. Keeping TikTok in its own media type also prevents it from being available in places that should only allow YouTube and Vimeo.

To make TikTok available as an oEmbed provider, add `TikTok` to the `video` oEmbed provider bucket, and explicitly restrict the `core_video` media type's allowed providers to `YouTube` and `Vimeo` so enabling TikTok globally does not affect it.

### Instagram

Create an `Instagram` media type using `remote_video_file` as the media source, not `oembed:video`. Instagram's oEmbed API requires a Meta developer app and access token (public access was removed in October 2020), so using `oembed:video` would cause media saves to fail. The `remote_video_file` source stores the URL without making any oEmbed requests.

**Do not add Instagram to the oEmbed provider bucket.**

Editors paste the Instagram post or reel URL into the URL field. The module reads from `field_video_file_url` for the `instagram` bundle and extracts the shortcode from both post (`/p/{shortcode}/`) and reel (`/reel/{shortcode}/`) URL formats, exposing it as `{{ videoID }}` in your Twig template.

Embedding is handled via Instagram's blockquote embed approach in the template. As this loads a third-party script (`embed.js`) from Meta, it counts as third-party tracking under GDPR and must only be loaded after the user has accepted cookies. This is best handled via Google Tag Manager's consent mode.
