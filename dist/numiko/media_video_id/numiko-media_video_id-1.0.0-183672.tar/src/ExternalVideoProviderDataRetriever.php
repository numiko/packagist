<?php

namespace Drupal\media_video_id;

/**
 * Retrieves data from external video providers.
 *
 * @package Drupal\booker_media
 */
class ExternalVideoProviderDataRetriever {

  /**
   * Return the provider identifier.
   *
   * @return string|null
   *   Provider id.
   */
  public function getProvider(string $videoURL): ?string {
    if (filter_var($videoURL, FILTER_VALIDATE_URL)) {
      return strpos($videoURL, 'vimeo') ? 'vimeo' : 'youtube';
    }
    return NULL;
  }

  /**
   * Retrieves external video providers id from video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve id from.
   *
   * @return string|null
   *   Video id.
   */
  public function getExternalProviderVideoId(string $videoURL) {
    $videoID = NULL;

    if (filter_var($videoURL, FILTER_VALIDATE_URL)) {
      $provider = $this->getProvider($videoURL);
      if ($provider == 'youtube') {
        $videoID = $this->getYoutubeId($videoURL);
      }
      else {
        $videoID = $this->getVimeoId($videoURL);
      }
    }

    return $videoID;
  }

  /**
   * Retrieves id from youtube video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve youtube id from.
   *
   * @return string
   *   The video ID from a YouTube url.
   */
  public function getYoutubeId(string $videoURL) {
    if (strpos($videoURL, 'v=') !== FALSE) {
      $idPositionInBrowserURL = strpos($videoURL, 'v=');
      return substr($videoURL, $idPositionInBrowserURL + 2, 11);
    }
    elseif (strpos($videoURL, 'youtu.be') !== FALSE) {
      $idPositionInShare = strpos($videoURL, 'youtu.be');
      return substr($videoURL, $idPositionInShare + 9, 11);
    }
  }

  /**
   * Retrieves id from vimeo video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve youtube id from.
   *
   * @return string
   *   The video ID from a vimeo URL.
   */
  public function getVimeoId($videoURL) {
    $json = @file_get_contents('https://vimeo.com/api/oembed.json?url=' . $videoURL);
    if ($json) {
      $data = json_decode($json);

      if ($data->video_id) {
        return $data->video_id;
      }
    }
  }

}
