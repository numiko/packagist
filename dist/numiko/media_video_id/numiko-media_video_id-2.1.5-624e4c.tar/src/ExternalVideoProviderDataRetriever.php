<?php

namespace Drupal\media_video_id;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\GuzzleException;

/**
 * Retrieves data from external video providers.
 */
class ExternalVideoProviderDataRetriever {

  /**
   * Construct the data retriever.
   *
   * @param \GuzzleHttp\ClientInterface $httpClient
   *   Drupal's HTTP client, so outbound requests honour
   *   $settings['http_client_config'] (proxy, timeouts, TLS).
   */
  public function __construct(protected readonly ClientInterface $httpClient) {}

  /**
   * Return the provider identifier.
   *
   * @return ?string
   *   Provider id.
   */
  public function getProvider(string $videoURL): ?string {
    if (filter_var($videoURL, FILTER_VALIDATE_URL)) {
      if (strpos($videoURL, 'tiktok') !== FALSE) {
        return 'tiktok';
      }
      elseif (strpos($videoURL, 'instagram') !== FALSE) {
        return 'instagram';
      }
      elseif (strpos($videoURL, 'vimeo') !== FALSE) {
        return 'vimeo';
      }
      else {
        return 'youtube';
      }
    }
    return NULL;
  }

  /**
   * Retrieves external video providers id from video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve id from.
   *
   * @return ?string
   *   Video id.
   */
  public function getExternalProviderVideoId(string $videoURL): ?string {
    $videoID = NULL;

    if (filter_var($videoURL, FILTER_VALIDATE_URL)) {
      $provider = $this->getProvider($videoURL);
      $videoID = match ($provider) {
        'youtube' => $this->getYoutubeId($videoURL),
        'vimeo' => $this->getVimeoId($videoURL),
        'tiktok' => $this->getTikTokId($videoURL),
        'instagram' => $this->getInstagramId($videoURL),
        default => NULL,
      };

    }

    return $videoID;
  }

  /**
   * Retrieves id from youtube video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve youtube id from.
   *
   * @return ?string
   *   The video ID from a YouTube url.
   */
  public function getYoutubeId(string $videoURL): ?string {
    $videoID = NULL;
    if (strpos($videoURL, 'v=') !== FALSE) {
      $idPositionInBrowserURL = strpos($videoURL, 'v=');
      $videoID = substr($videoURL, $idPositionInBrowserURL + 2, 11);
    }
    elseif (strpos($videoURL, 'youtu.be') !== FALSE) {
      $idPositionInShare = strpos($videoURL, 'youtu.be');
      $videoID = substr($videoURL, $idPositionInShare + 9, 11);
    }
    elseif (strpos($videoURL, '/shorts/') !== FALSE) {
      // Handle YouTube Shorts URL.
      $idPositionInShorts = strpos($videoURL, '/shorts/');
      $videoID = substr($videoURL, $idPositionInShorts + 8, 11);
    }
    return $videoID;
  }

  /**
   * Retrieves id from vimeo video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve vimeo id from.
   *
   * @return ?string
   *   The video ID from a vimeo URL.
   */
  public function getVimeoId(string $videoURL): ?string {
    try {
      $response = $this->httpClient->request('GET', 'https://vimeo.com/api/oembed.json', [
        'query' => ['url' => $videoURL],
        'http_errors' => FALSE,
        'timeout' => 5,
      ]);
    }
    catch (GuzzleException) {
      return NULL;
    }

    if ($response->getStatusCode() !== 200) {
      return NULL;
    }

    $data = json_decode((string) $response->getBody());

    return $data->video_id ?? NULL;
  }

  /**
   * Retrieves id from TikTok video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve TikTok id from.
   *
   * @return string|null
   *   The video ID from a TikTok URL.
   */
  public function getTikTokId(string $videoURL) {
    // TikTok URLs format: https://www.tiktok.com/@username/video/7225994415477624091
    if (preg_match('#/video/(\d+)#', $videoURL, $matches)) {
      return $matches[1];
    }
    return NULL;
  }

  /**
   * Retrieves shortcode from an Instagram URL.
   *
   * @param string $videoURL
   *   URL of the Instagram post or reel.
   *
   * @return string|null
   *   The shortcode from an Instagram URL.
   */
  public function getInstagramId(string $videoURL): ?string {
    // Matches /p/{shortcode}/ and /reel/{shortcode}/
    // Instagram shortcodes are Base64url encoded. Base64url replaces + with -
    // and / with _ giving the alphabet A-Z, a-z, 0-9, -, _ which maps to [A-Za-z0-9_-].
    if (preg_match('#instagram\.com/(?:p|reel)/([A-Za-z0-9_-]+)#', $videoURL, $matches)) {
      return $matches[1];
    }
    return NULL;
  }

}
