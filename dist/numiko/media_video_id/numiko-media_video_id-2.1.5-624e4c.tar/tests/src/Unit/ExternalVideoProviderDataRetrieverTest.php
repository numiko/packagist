<?php

namespace Drupal\Tests\media_video_id\Unit;

use Drupal\Tests\UnitTestCase;
use Drupal\media_video_id\ExternalVideoProviderDataRetriever;
use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\Psr7\Request;
use GuzzleHttp\Psr7\Response;
use PHPUnit\Framework\Attributes\CoversClass;

/**
 * Testing the parsing of video url's.
 */
#[CoversClass(ExternalVideoProviderDataRetriever::class)]
class ExternalVideoProviderDataRetrieverTest extends UnitTestCase {

  /**
   * The data retriever.
   */
  protected ExternalVideoProviderDataRetriever $dataRetreiver;

  /**
   * Create new ExternalVideoProviderDataRetriever object.
   */
  public function setUp(): void {
    parent::setUp();
    $this->dataRetreiver = new ExternalVideoProviderDataRetriever($this->createMock(ClientInterface::class));
  }

  /**
   * Creates a data retriever whose HTTP client returns the given response.
   */
  protected function createRetrieverWithResponse(Response $response): ExternalVideoProviderDataRetriever {
    $client = $this->createMock(ClientInterface::class);
    $client->method('request')->willReturn($response);
    return new ExternalVideoProviderDataRetriever($client);
  }

  public function testYoutubeVideoId(): void {
    $videoUrl = "https://www.youtube.com/watch?v=_KSxRj9YhG8";
    $expectedId = "_KSxRj9YhG8";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testYoutubeShareVideoId(): void {
    $videoUrl = "https://youtu.be/_KSxRj9YhG8";
    $expectedId = "_KSxRj9YhG8";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testYoutubeShortsVideoId(): void {
    $videoUrl = "https://youtube.com/shorts/xbF7yxKVPNc";
    $expectedId = "xbF7yxKVPNc";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testVimeoVideoId(): void {
    $videoUrl = "https://vimeo.com/392793169";
    $expectedId = "392793169";

    $response = new Response(200, [], (string) json_encode(['video_id' => 392793169]));
    $retriever = $this->createRetrieverWithResponse($response);

    $actualId = $retriever->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testVimeoVideoIdErrorResponse(): void {
    $response = new Response(404, [], 'Not Found');
    $retriever = $this->createRetrieverWithResponse($response);

    $this->assertNull($retriever->getVimeoId("https://vimeo.com/392793169"));
  }

  public function testVimeoVideoIdConnectionFailure(): void {
    $client = $this->createMock(ClientInterface::class);
    $client->method('request')->willThrowException(
      new ConnectException('Connection refused', new Request('GET', 'https://vimeo.com/api/oembed.json'))
    );
    $retriever = new ExternalVideoProviderDataRetriever($client);

    $this->assertNull($retriever->getVimeoId("https://vimeo.com/392793169"));
  }

  public function testTikTokVideoId(): void {
    $videoUrl = "https://www.tiktok.com/@username/video/1234567890123456789";
    $expectedId = "1234567890123456789";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testYoutubeVideoProvider(): void {
    $videoUrl = "https://www.youtube.com/watch?v=_KSxRj9YhG8";
    $expectedProvider = "youtube";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  public function testYoutubeShareVideoProvider(): void {
    $videoUrl = "https://youtu.be/_KSxRj9YhG8";
    $expectedProvider = "youtube";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  public function testYoutubeShortsVideoProvider(): void {
    $videoUrl = "https://youtube.com/shorts/xbF7yxKVPNc";
    $expectedProvider = "youtube";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  public function testVimeoVideoProvider(): void {
    $videoUrl = "https://vimeo.com/392793169";
    $expectedProvider = "vimeo";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  public function testTikTokVideoProvider(): void {
    $videoUrl = "https://www.tiktok.com/@username/video/7225994415477624091";
    $expectedProvider = "tiktok";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  public function testInstagramPostVideoId(): void {
    $videoUrl = "https://www.instagram.com/p/ABC123def45/";
    $expectedId = "ABC123def45";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testInstagramReelVideoId(): void {
    $videoUrl = "https://www.instagram.com/reel/ABC123def45/";
    $expectedId = "ABC123def45";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testInstagramVideoProvider(): void {
    $videoUrl = "https://www.instagram.com/p/ABC123def45/";
    $expectedProvider = "instagram";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

}
