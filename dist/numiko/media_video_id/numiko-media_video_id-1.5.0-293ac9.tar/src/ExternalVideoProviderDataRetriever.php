<?php

namespace Drupal\media_video_id;

/**
 * Retrieves data from external video providers.
 */
class ExternalVideoProviderDataRetriever {

  /**
   * Return the provider identifier.
   *
   * @return ?string
   *   Provider id.
   */
  public function getProvider(string $videoURL): ?string {
    if (filter_var($videoURL, FILTER_VALIDATE_URL)) {
      if (strpos($videoURL, 'tiktok') !== FALSE) {
        return 'tiktok';
      }
      elseif (strpos($videoURL, 'vimeo') !== FALSE) {
        return 'vimeo';
      }
      else {
        return 'youtube';
      }
    }
    return NULL;
  }

  /**
   * Retrieves external video providers id from video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve id from.
   *
   * @return ?string
   *   Video id.
   */
  public function getExternalProviderVideoId(string $videoURL): ?string {
    $videoID = NULL;

    if (filter_var($videoURL, FILTER_VALIDATE_URL)) {
      $provider = $this->getProvider($videoURL);
      $videoID = match ($provider) {
        'youtube' => $this->getYoutubeId($videoURL),
        'vimeo' => $this->getVimeoId($videoURL),
        'tiktok' => $this->getTikTokId($videoURL),
        default => NULL,
      };

    }

    return $videoID;
  }

  /**
   * Retrieves id from youtube video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve youtube id from.
   *
   * @return ?string
   *   The video ID from a YouTube url.
   */
  public function getYoutubeId(string $videoURL): ?string {
    $videoID = NULL;
    if (strpos($videoURL, 'v=') !== FALSE) {
      $idPositionInBrowserURL = strpos($videoURL, 'v=');
      $videoID = substr($videoURL, $idPositionInBrowserURL + 2, 11);
    }
    elseif (strpos($videoURL, 'youtu.be') !== FALSE) {
      $idPositionInShare = strpos($videoURL, 'youtu.be');
      $videoID = substr($videoURL, $idPositionInShare + 9, 11);
    }
    elseif (strpos($videoURL, '/shorts/') !== FALSE) {
      // Handle YouTube Shorts URL.
      $idPositionInShorts = strpos($videoURL, '/shorts/');
      $videoID = substr($videoURL, $idPositionInShorts + 8, 11);
    }
    return $videoID;
  }

  /**
   * Retrieves id from vimeo video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve vimeo id from.
   *
   * @return ?string
   *   The video ID from a vimeo URL.
   */
  public function getVimeoId(string $videoURL): ?string {
    $json = @file_get_contents('https://vimeo.com/api/oembed.json?url=' . $videoURL);
    if ($json) {
      $data = json_decode($json);

      if ($data->video_id) {
        return $data->video_id;
      }

      return NULL;
    }
    return NULL;
  }

  /**
   * Retrieves id from TikTok video url.
   *
   * @param string $videoURL
   *   URL of video to retrieve TikTok id from.
   *
   * @return string|null
   *   The video ID from a TikTok URL.
   */
  public function getTikTokId(string $videoURL) {
    // TikTok URLs format: https://www.tiktok.com/@username/video/7225994415477624091
    if (preg_match('/\/video\/(\d+)/', $videoURL, $matches)) {
      return $matches[1];
    }
    return NULL;
  }

}
