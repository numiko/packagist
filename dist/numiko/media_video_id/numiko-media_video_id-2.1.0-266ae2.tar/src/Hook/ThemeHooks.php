<?php

namespace Drupal\media_video_id\Hook;

use Drupal\Core\File\FileUrlGeneratorInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\media_video_id\ExternalVideoProviderDataRetriever;
use Symfony\Component\DependencyInjection\Attribute\AutowireServiceClosure;

/**
 * Preprocess implementations for media_video_id.
 */
class ThemeHooks {

  /**
   * Construct this hook class.
   *
   * @param \Drupal\media_video_id\ExternalVideoProviderDataRetriever $videoDataRetriever
   *   This has no depenencies so inject it directly.
   * @param \Closure(): \Drupal\Core\File\FileUrlGeneratorInterface $fileUrlGeneratorClosure
   *   File URL generator. This is a heavy class so use a service closure.
   */
  public function __construct(
    protected readonly ExternalVideoProviderDataRetriever $videoDataRetriever,
    #[AutowireServiceClosure(FileUrlGeneratorInterface::class)]
    protected readonly \Closure $fileUrlGeneratorClosure,
  ) {}

  /**
   * Implements hook_preprocess_HOOK for media.
   */
  #[Hook('preprocess_media')]
  public function preprocessVideo(array &$variables): void {
    /** @var \Drupal\media\MediaInterface $media */
    $media = $variables['elements']['#media'];
    $supported_bundles = ['core_video', 'tiktok', 'instagram'];

    if (in_array($media->bundle(), $supported_bundles)) {
      if ($media->hasField('field_media_oembed_video') && !$media->get('field_media_oembed_video')->isEmpty()) {
        $videoURL = $media->get('field_media_oembed_video')->value;
        // Read the thumbnail URI from the stored field rather than calling
        // getMetadata(), which triggers a scanDirectory() on the file system.
        $thumbnailUri = NULL;
        if (!$media->get('thumbnail')->isEmpty()) {
          $thumbnailFile = $media->get('thumbnail')->entity;
          if ($thumbnailFile) {
            $storedUri = $thumbnailFile->getFileUri();
            // Normalise the URI scheme to match thumbnails_directory.
            $config = $media->getSource()->getConfiguration();
            if (!empty($config['thumbnails_directory'])) {
              $configScheme = parse_url($config['thumbnails_directory'], PHP_URL_SCHEME);
              $storedScheme = parse_url($storedUri, PHP_URL_SCHEME);
              if ($configScheme && $storedScheme && $configScheme !== $storedScheme) {
                $storedUri = $configScheme . '://' . substr($storedUri, strlen($storedScheme) + 3);
              }
            }
            $thumbnailUri = $storedUri;
          }
        }
        // Fallback: re-derive via the source plugin (downloads if needed).
        if (!$thumbnailUri) {
          $thumbnailUri = $media->getSource()->getMetadata($media, 'thumbnail_uri');
        }
        if ($thumbnailUri) {
          $variables['thumbnail'] = ($this->fileUrlGeneratorClosure)()->generateAbsoluteString($thumbnailUri);
        }
        if ($videoURL) {
          $variables['provider'] = $this->videoDataRetriever->getProvider($videoURL);
          $variables['videoID'] = $this->videoDataRetriever->getExternalProviderVideoId($videoURL);
        }
      }
    }
  }

}
