<?php

namespace Drupal\media_video_id\Hook;

use Drupal\Core\File\FileUrlGeneratorInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\media_video_id\ExternalVideoProviderDataRetriever;
use Symfony\Component\DependencyInjection\Attribute\AutowireServiceClosure;

/**
 * Preprocess implementations for media_video_id.
 */
class ThemeHooks {

  /**
   * Construct this hook class.
   *
   * @param \Drupal\media_video_id\ExternalVideoProviderDataRetriever $videoDataRetriever
   *   This has no depenencies so inject it directly.
   * @param \Closure(): \Drupal\Core\File\FileUrlGeneratorInterface $fileUrlGeneratorClosure
   *   File URL generator. This is a heavy class so use a service closure.
   */
  public function __construct(
    protected readonly ExternalVideoProviderDataRetriever $videoDataRetriever,
    #[AutowireServiceClosure(FileUrlGeneratorInterface::class)]
    protected readonly \Closure $fileUrlGeneratorClosure,
  ) {}

  /**
   * Implements hook_preprocess_HOOK for media.
   */
  #[Hook('preprocess_media')]
  public function preprocessCoreVideo(array &$variables): void {
    /** @var \Drupal\media\MediaInterface $media */
    $media = $variables['elements']['#media'];
    if ($media->bundle() === 'core_video') {
      if ($media->hasField('field_media_oembed_video') && !$media->get('field_media_oembed_video')->isEmpty()) {
        $videoURL = $media->get('field_media_oembed_video')->value;
        $thumbnailUri = $media->getSource()->getMetadata($media, 'thumbnail_uri');
        if ($thumbnailUri) {
          $variables['thumbnail'] = ($this->fileUrlGeneratorClosure)()->generateAbsoluteString($thumbnailUri);
        }
        if ($videoURL) {
          $variables['provider'] = $this->videoDataRetriever->getProvider($videoURL);
          $variables['videoID'] = $this->videoDataRetriever->getExternalProviderVideoId($videoURL);
        }
      }
    }
  }

}
