<?php

namespace Drupal\Tests\media_video_id\Unit;

use Drupal\Tests\UnitTestCase;
use Drupal\media_video_id\ExternalVideoProviderDataRetriever;
use PHPUnit\Framework\Attributes\CoversClass;

/**
 * Testing the parsing of video url's.
 */
#[CoversClass(ExternalVideoProviderDataRetriever::class)]
class ExternalVideoProviderDataRetrieverTest extends UnitTestCase {

  /**
   * The data retriever.
   */
  protected ExternalVideoProviderDataRetriever $dataRetreiver;

  /**
   * Create new ExternalVideoProviderDataRetriever object.
   */
  public function setUp(): void {
    parent::setUp();
    $this->dataRetreiver = new ExternalVideoProviderDataRetriever();
  }

  public function testYoutubeVideoId(): void {
    $videoUrl = "https://www.youtube.com/watch?v=_KSxRj9YhG8";
    $expectedId = "_KSxRj9YhG8";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testYoutubeShareVideoId(): void {
    $videoUrl = "https://youtu.be/_KSxRj9YhG8";
    $expectedId = "_KSxRj9YhG8";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testYoutubeShortsVideoId(): void {
    $videoUrl = "https://youtube.com/shorts/xbF7yxKVPNc";
    $expectedId = "xbF7yxKVPNc";
    $actualId = $this->dataRetreiver->getExternalProviderVideoId($videoUrl);
    $this->assertEquals($expectedId, $actualId);
  }

  public function testYoutubeVideoProvider(): void {
    $videoUrl = "https://www.youtube.com/watch?v=_KSxRj9YhG8";
    $expectedProvider = "youtube";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  public function testYoutubeShareVideoProvider(): void {
    $videoUrl = "https://youtu.be/_KSxRj9YhG8";
    $expectedProvider = "youtube";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  public function testYoutubeShortsVideoProvider(): void {
    $videoUrl = "https://youtube.com/shorts/xbF7yxKVPNc";
    $expectedProvider = "youtube";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

  public function testVimeoVideoProvider(): void {
    $videoUrl = "https://vimeo.com/392793169";
    $expectedProvider = "vimeo";
    $actualProvider = $this->dataRetreiver->getProvider($videoUrl);
    $this->assertEquals($expectedProvider, $actualProvider);
  }

}
