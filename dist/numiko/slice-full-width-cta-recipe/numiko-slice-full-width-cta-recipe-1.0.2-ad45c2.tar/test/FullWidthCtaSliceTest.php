<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the Full Width CTA slice displays on a page.
 *
 * @group slices
 */
class FullWidthCtaSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a Full Width CTA slice to a node with layout set to display image.
   */
  public function testFullWidthCtaSliceDisplay() {
    $paragraphs[] = $this->createParagraph('slice_full_width_cta', [
      'field_title' => 'Full Width CTA slice title',
      'field_summary' => 'Full Width CTA slice summary',
      'field_media' => $this->getSampleImageMedia([], 'sample_image_slice.jpg')->id(),
      'field_link' => [
        'uri' => 'https://www.google.com',
        'title' => 'CTA button',
      ],
    ]);
    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();
    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);

    $assertSession->pageTextContains('Full Width CTA slice title');
    $assertSession->pageTextContains('Full Width CTA slice summary');
    $assertSession->responseContains('sample_image_slice.jpg');
    $assertSession->responseContains('https://www.google.com');
    $assertSession->pageTextContains('CTA button');
  }

}
