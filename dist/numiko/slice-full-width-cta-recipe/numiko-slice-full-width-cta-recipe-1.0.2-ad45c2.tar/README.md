# Full Width CTA Slice Recipe

This recipe installs full width cta slice config.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-full-width-cta-recipe
