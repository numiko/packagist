# Full Width CTA Slice Recipe

This recipe installs full width cta slice config.

Not Composed / Not added to the satis.json.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/full-width-cta-slice
