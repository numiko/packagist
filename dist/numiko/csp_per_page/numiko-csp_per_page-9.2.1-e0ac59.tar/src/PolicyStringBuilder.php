<?php

namespace Drupal\csp_per_page;

use Drupal\Core\Config\ImmutableConfig;

/**
 * Generate the CSP policy string.
 */
class PolicyStringBuilder {

  public function __construct(protected readonly NonceManager $nonceManager) {}

  /**
   * Build the CSP policy from the individual parts.
   *
   * @param \Drupal\Core\Config\ImmutableConfig $config
   *   The module config from which to build the CSP.
   *
   *   This can be the main module config, or separate config that overrides
   *   the module's main config. It must contain the strict_policy_* keys.
   *
   * @return string
   */
  public function build(ImmutableConfig $config): string {
    $policy = [];
    $parts = [
      'default-src' => 'strict_policy_default',
      'script-src' => 'strict_policy_script',
      'img-src' => 'strict_policy_img',
      'style-src' => 'strict_policy_style',
      'font-src' => 'strict_policy_font',
    ];
    foreach ($parts as $directive => $configForDirective) {
      $policyPart = $config->get($configForDirective);

      if ($directive == 'script-src') {
        foreach ($this->nonceManager->getGeneratedNonces() as $label => $nonceValue) {
          $policyPart .= " 'nonce-{$nonceValue}'";
        }
      }
      $policy[] = $directive . ' ' . $policyPart;
    }

    $policy[] = $config->get('strict_policy_additional');

    return implode('; ', $policy);
  }

}
