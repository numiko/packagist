<?php

namespace Drupal\csp_per_page;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Path\PathMatcherInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\path_alias\AliasManagerInterface;
use function substr;

class CspForCurrentPage {

  /**
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  private $routeMatch;

  /**
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  private $config;

  /**
   * @var \Drupal\Core\Path\PathMatcherInterface
   */
  private $pathMatcher;

  /**
   * @var \Drupal\Core\Path\CurrentPathStack
   */
  private $currentPath;

  /**
   * @var \Drupal\Core\Path\AliasManagerInterface
   */
  private $aliasManager;

  /**
   * @var \Drupal\csp_per_page\NonceManager
   */
  private $nonceManager;

  /**
   * ResponseCspSubscriber constructor.
   *
   * @param \Drupal\Core\Routing\RouteMatchInterface $routeMatch
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config
   * @param \Drupal\Core\Path\PathMatcherInterface $pathMatcher
   * @param \Drupal\Core\Path\CurrentPathStack $currentPath
   * @param \Drupal\Core\Path\AliasManagerInterface $aliasManager
   */
  public function __construct(RouteMatchInterface $routeMatch, ConfigFactoryInterface $config, PathMatcherInterface $pathMatcher, CurrentPathStack $currentPath, AliasManagerInterface $aliasManager, NonceManager $nonceManager) {
    $this->routeMatch = $routeMatch;
    $this->config = $config;
    $this->pathMatcher = $pathMatcher;
    $this->currentPath = $currentPath;
    $this->aliasManager = $aliasManager;
    $this->nonceManager = $nonceManager;
  }

  /**
   * Find the CSP for the current page.
   *
   * @return string|null
   */
  public function findCspForPage(): ?string {
    $moduleConfig = $this->config->get('csp_per_page.settings');

    // Check if we're on a node type that should use the default strict CSP.
    if ($moduleConfig->get('strict_types') &&
      $this->isCurrentPageAStrictNodeType($moduleConfig->get('strict_types'))) {
      return $this->buildPolicyString($moduleConfig);
    }

    $currentAlias = $this->aliasManager->getAliasByPath(
      $this->currentPath->getPath()
    );

    // Check if we're on a path that should use the default strict CSP.
    if ($moduleConfig->get('strict_paths') &&
      $this->isCurrentPageOnAStrictPath(
        $moduleConfig->get('strict_paths'),
        $currentAlias
      )) {
      return $this->buildPolicyString($moduleConfig);
    }

    // Check if we're on a path that should use a custom CSP.
    if ($moduleConfig->get('custom_csp_paths') &&
      $this->isCurrentPageOnACustomCspPath(
        $moduleConfig->get('custom_csp_paths'),
        $currentAlias
      )
    ) {
      $overrideConfig = $this->config->get(
        'csp_per_page.custom.' . $this->convertPathToConfigName($currentAlias)
      );
      if ($moduleConfig) {
        return $this->buildPolicyString($overrideConfig);
      }
    }

    return NULL;
  }

  /**
   * Check if the node type of the current page should have a strict CSP.
   *
   * @param array $strictTypes
   *
   * @return bool
   */
  protected function isCurrentPageAStrictNodeType(array $strictTypes): bool {
    $node = $this->routeMatch->getParameter('node');

    if ($node) {
      return in_array($node->getType(), $strictTypes);
    }
    return FALSE;
  }

  /**
   * Check if the path of the current page should have a strict CSP.
   *
   * @param string $strictPaths
   *
   * @return bool
   */
  protected function isCurrentPageOnAStrictPath(
    string $strictPaths,
    string $currentAlias
  ): bool {
    return $this->pathMatcher->matchPath(
      $currentAlias,
      $strictPaths
    );
  }

  protected function isCurrentPageOnACustomCspPath(
    string $customPaths,
    string $currentAlias
  ) {
    return $this->pathMatcher->matchPath(
      $currentAlias,
      $customPaths
    );
  }

  protected function convertPathToConfigName($path) {
    if (substr($path, 0, 1) === '/') {
      $path = substr($path, 1);
    }
    return preg_replace('/[^a-z0-9_]/', '_', $path);
  }

  /**
   * Build the CSP policy from the individual parts.
   *
   * @param \Drupal\Core\Config\ImmutableConfig $config
   *   The module config from which to build the CSP.
   *
   *   This can be the main module config, or separate config that overrides
   *   the module's main config. It must contain the strict_policy_* keys.
   *
   * @return string
   */
  protected function buildPolicyString(ImmutableConfig $config): string {
    $policy = [];
    $parts = [
      'default-src' => 'strict_policy_default',
      'script-src' => 'strict_policy_script',
      'img-src' => 'strict_policy_img',
      'style-src' => 'strict_policy_style',
      'font-src' => 'strict_policy_font',
    ];
    foreach ($parts as $directive => $configForDirective) {
      $policyPart = $config->get($configForDirective);

      if ($directive == 'script-src') {
        foreach ($this->nonceManager->getGeneratedNonces() as $label => $nonceValue) {
          $policyPart .= " 'nonce-{$nonceValue}'";
        }
      }
      $policy[] = $directive . ' ' . $policyPart;
    }

    $policy[] = $config->get('strict_policy_additional');

    return implode('; ', $policy);
  }

}
