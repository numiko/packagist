<?php

namespace Drupal\csp_per_page;

/**
 * Generate nonce values to be used in the CSP.
 *
 * Use generateNonce() in your code to obtain nonces. The module will then
 * add them to the CSP.
 */
class NonceManager {

  /**
   * @var array
   */
  protected $generatedNonces = [];

  /**
   * Obtain a random nonce.
   *
   * @param string $label
   *   Arbitrary label.
   *
   * @return string
   *   The nonce value.
   */
  public function generateNonce($label) {
    $nonce = base64_encode(uniqid());
    $this->generatedNonces[$label] = $nonce;
    return $nonce;
  }

  /**
   * @return array
   */
  public function getGeneratedNonces() {
    return $this->generatedNonces;
  }

}
