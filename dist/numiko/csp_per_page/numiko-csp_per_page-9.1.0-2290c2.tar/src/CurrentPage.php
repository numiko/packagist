<?php

namespace Drupal\csp_per_page;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Path\PathMatcherInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\path_alias\AliasManagerInterface;

class CurrentPage {

  /**
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  private $routeMatch;

  /**
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  private $config;

  /**
   * @var \Drupal\Core\Path\PathMatcherInterface
   */
  private $pathMatcher;

  /**
   * @var \Drupal\Core\Path\CurrentPathStack
   */
  private $currentPath;

  /**
   * @var \Drupal\Core\Path\AliasManagerInterface
   */
  private $aliasManager;

  /**
   * @var \Drupal\csp_per_page\PolicyStringBuilder
   */
  private $policyStringBuilder;

  /**
   * ResponseCspSubscriber constructor.
   *
   * @param \Drupal\Core\Routing\RouteMatchInterface $routeMatch
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config
   * @param \Drupal\Core\Path\PathMatcherInterface $pathMatcher
   * @param \Drupal\Core\Path\CurrentPathStack $currentPath
   * @param \Drupal\Core\Path\AliasManagerInterface $aliasManager
   * @param \Drupal\csp_per_page\PolicyStringBuilder $policyStringBuilder
   */
  public function __construct(RouteMatchInterface $routeMatch, ConfigFactoryInterface $config, PathMatcherInterface $pathMatcher, CurrentPathStack $currentPath, AliasManagerInterface $aliasManager, PolicyStringBuilder $policyStringBuilder) {
    $this->routeMatch = $routeMatch;
    $this->config = $config;
    $this->pathMatcher = $pathMatcher;
    $this->currentPath = $currentPath;
    $this->aliasManager = $aliasManager;
    $this->policyStringBuilder = $policyStringBuilder;
  }

  /**
   * Find the CSP for the current page.
   *
   * @return string|null
   */
  public function findCspForPage(): ?string {
    $moduleConfig = $this->config->get('csp_per_page.settings');

    // Check if we're on a node type that should use the default strict CSP.
    if ($moduleConfig->get('strict_types') &&
      $this->isCurrentPageAStrictNodeType($moduleConfig->get('strict_types'))) {
      return $this->policyStringBuilder->build($moduleConfig);
    }

    $currentAlias = $this->aliasManager->getAliasByPath(
      $this->currentPath->getPath()
    );

    // Check if we're on a path that should use the default strict CSP.
    if ($moduleConfig->get('strict_paths') &&
      $this->isCurrentPageOnAStrictPath(
        $moduleConfig->get('strict_paths'),
        $currentAlias
      )) {
      return $this->policyStringBuilder->build($moduleConfig);
    }

    // Check if we're on a path that should use a custom CSP.
    if ($moduleConfig->get('custom_csp_paths') &&
      $this->isCurrentPageOnACustomCspPath(
        $moduleConfig->get('custom_csp_paths'),
        $currentAlias
      )
    ) {
      $overrideConfig = $this->config->get(
        'csp_per_page.custom.' . $this->convertPathToConfigName($currentAlias)
      );
      if ($moduleConfig) {
        return $this->policyStringBuilder->build($overrideConfig);
      }
    }

    return NULL;
  }

  /**
   * Check if the node type of the current page should have a strict CSP.
   *
   * @param array $strictTypes
   *
   * @return bool
   */
  protected function isCurrentPageAStrictNodeType(array $strictTypes): bool {
    if ($this->routeMatch->getRouteName() === 'entity.node.edit_form') {
      return FALSE;
    }

    $node = $this->routeMatch->getParameter('node');

    if ($node) {
      return in_array($node->getType(), $strictTypes);
    }
    return FALSE;
  }

  /**
   * Check if the path of the current page should have a strict CSP.
   *
   * @param string $strictPaths
   *
   * @return bool
   */
  protected function isCurrentPageOnAStrictPath(
    string $strictPaths,
    string $currentAlias
  ): bool {
    return $this->pathMatcher->matchPath(
      $currentAlias,
      $strictPaths
    );
  }

  /**
   * Check if the path of the current page has a custom CSP.
   *
   * @param string $customPaths
   * @param string $currentAlias
   *
   * @return bool
   */
  protected function isCurrentPageOnACustomCspPath(
    string $customPaths,
    string $currentAlias
  ) {
    return $this->pathMatcher->matchPath(
      $currentAlias,
      $customPaths
    );
  }

  /**
   * Convert current path to string suitable for a config name.
   *
   * @param $path
   *
   * @return string
   */
  protected function convertPathToConfigName($path) {
    if (substr($path, 0, 1) === '/') {
      $path = substr($path, 1);
    }
    return preg_replace('/[^a-z0-9_]/', '_', $path);
  }

}
