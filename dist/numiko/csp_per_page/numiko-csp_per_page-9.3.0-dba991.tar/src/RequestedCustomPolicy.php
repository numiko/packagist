<?php

namespace Drupal\csp_per_page;

/**
 * Allows code executed during rendering to request a specific custom CSP.
 * Some custom CSPs are needed based on what was actually rendered instead
 * Call requestPolicy() during preprocessing with the name of a
 * csp_per_page.custom.<name> config object; the module will use it to build
 * this response's CSP.
 */
class RequestedCustomPolicy {

  /**
   * @var string|null
   */
  protected $name;

  /**
   * Request that a named custom CSP be used for the current response.
   *
   * @param string $name
   *   The suffix of a csp_per_page.custom.<name> config object.
   */
  public function requestPolicy($name) {
    $this->name = $name;
  }

  /**
   * @return string|null
   */
  public function getRequestedPolicy() {
    return $this->name;
  }

}
