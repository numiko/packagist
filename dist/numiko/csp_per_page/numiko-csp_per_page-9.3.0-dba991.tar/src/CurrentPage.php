<?php

namespace Drupal\csp_per_page;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\Core\Path\PathMatcherInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\path_alias\AliasManagerInterface;

/**
 * Build the csp directive for this page, if it exists.
 */
class CurrentPage {

  public function __construct(
    protected readonly RouteMatchInterface $routeMatch,
    protected readonly ConfigFactoryInterface $config,
    protected readonly PathMatcherInterface $pathMatcher,
    protected readonly CurrentPathStack $currentPath,
    protected readonly AliasManagerInterface $aliasManager,
    protected readonly PolicyStringBuilder $policyStringBuilder,
    protected readonly RequestedCustomPolicy $requestedCustomPolicy,
  ) {}

  /**
   * Find the CSP for the current page.
   *
   * @return ?string
   */
  public function findCspForPage(): ?string {
    $moduleConfig = $this->config->get('csp_per_page.settings');

    // Check if we're on a node type that should use the default strict CSP.
    $strictTypes = $moduleConfig->get('strict_types');
    if ($strictTypes && $this->isCurrentPageStrictNodeType($strictTypes)) {
      return $this->policyStringBuilder->build($moduleConfig);
    }

    $currentAlias = $this->aliasManager->getAliasByPath(
      $this->currentPath->getPath()
    );

    // Check if we're on a path that should use the default strict CSP.
    $strictPaths = $moduleConfig->get('strict_paths');
    if ($strictPaths && $this->isCurrentPageOnStrictPath($strictPaths, $currentAlias)) {
      return $this->policyStringBuilder->build($moduleConfig);
    }

    // Check if rendering the page requested a specific custom CSP - used
    // when a custom CSP is needed based on what was rendered rather than
    // the page's node type or URL alias (e.g. a paragraph that can appear
    // on any content type via a shared slices field). Checked after the
    // strict node type/path checks above so those always take priority.
    if ($requestedPolicy = $this->requestedCustomPolicy->getRequestedPolicy()) {
      $overrideConfig = $this->config->get('csp_per_page.custom.' . $requestedPolicy);
      return $this->policyStringBuilder->build($overrideConfig);
    }

    // Check if we're on a path that should use a custom CSP.
    $customCspPaths = $moduleConfig->get('custom_csp_paths');
    if ($customCspPaths && $this->isCurrentPageOnCustomCspPath($customCspPaths, $currentAlias)) {
      $overrideConfig = $this->config->get(
        'csp_per_page.custom.' . $this->convertPathToConfigName($currentAlias)
      );
      return $this->policyStringBuilder->build($overrideConfig);
    }

    return NULL;
  }

  /**
   * Check if the node type of the current page should have a strict CSP.
   *
   * @param array $strictTypes
   *
   * @return bool
   */
  protected function isCurrentPageStrictNodeType(array $strictTypes): bool {
    if ($this->routeMatch->getRouteName() === 'entity.node.edit_form') {
      return FALSE;
    }

    /** @var ?\Drupal\node\NodeInterface $node */
    $node = $this->routeMatch->getParameter('node');

    if ($node) {
      return in_array($node->getType(), $strictTypes);
    }
    return FALSE;
  }

  /**
   * Check if the path of the current page should have a strict CSP.
   *
   * @param string $strictPaths
   *
   * @return bool
   */
  protected function isCurrentPageOnStrictPath(string $strictPaths, string $currentAlias): bool {
    return $this->pathMatcher->matchPath($currentAlias, $strictPaths);
  }

  /**
   * Check if the path of the current page has a custom CSP.
   *
   * @param string $customPaths
   * @param string $currentAlias
   *
   * @return bool
   */
  protected function isCurrentPageOnCustomCspPath(string $customPaths, string $currentAlias) {
    return $this->pathMatcher->matchPath($currentAlias, $customPaths);
  }

  /**
   * Convert current path to string suitable for a config name.
   *
   * @param string $path
   *
   * @return string
   */
  protected function convertPathToConfigName(string $path): string {
    if (substr($path, 0, 1) === '/') {
      $path = substr($path, 1);
    }
    return preg_replace('/[^a-z0-9_]/', '_', $path);
  }

}
