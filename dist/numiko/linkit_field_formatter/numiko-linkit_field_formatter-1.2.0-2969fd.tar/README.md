# Linkit Field Formatter

Within Drupal 9 linkit only functions within the wysiwyg, this is useful but the
linkit field formatter allowed us to lookup more than just nodes in a linkit
link field.

Most of this functionality is restored by an ongoing patch:
https://www.drupal.org/project/linkit/issues/2712951#comment-14620016

However this still would not allow the use of a separate url and title field
formatter, this module exists to add that functionality.
