<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the testimonial slice displays on a page.
 *
 * @group slices
 */
class TestimonialSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a testimonial slice to a node.
   */
  public function testTestimonialSliceDisplay() {

    $paragraphs[] = $this->createParagraph('slice_testimonial', [
      'field_title' => 'Test Testimonial Title',
      'field_statement' => 'Test Testimonial Statement',
      'field_content' => 'Test Testimonial Quote',
      'field_attribution' => 'John Doe, Netrunner',
      'field_media' => $this->getSampleImageMedia([], 'sample_image_testimonial_slice.jpg')->id(),
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $assertSession->pageTextNotContains('Test Testimonial Title');
    $assertSession->pageTextContains('Test Testimonial Statement');
    $assertSession->pageTextContains('Test Testimonial Quote');
    $assertSession->pageTextContains('John Doe, Netrunner');
    $assertSession->responseContains('sample_image_testimonial_slice.jpg');
  }

}
