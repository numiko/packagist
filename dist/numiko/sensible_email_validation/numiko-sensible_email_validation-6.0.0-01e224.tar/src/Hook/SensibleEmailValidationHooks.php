<?php

declare(strict_types=1);

namespace Drupal\sensible_email_validation\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Hook implementations for the sensible_email_validation module.
 */
class SensibleEmailValidationHooks {

  use StringTranslationTrait;

  public function __construct(TranslationInterface $string_translation) {
    $this->stringTranslation = $string_translation;
  }

  /**
   * Implements hook_help().
   */
  #[Hook('help')]
  public function help(string $route_name, RouteMatchInterface $route_match): ?string {
    switch ($route_name) {
      // Main module help for the sensible_email_validation module.
      case 'help.page.sensible_email_validation':
        $output = '';
        $output .= '<h3>' . $this->t('About') . '</h3>';
        $output .= '<p>' . $this->t('Disallow domains without TLDs in email addresses') . '</p>';
        return $output;

      default:
        return NULL;
    }
  }

}
