<?php

declare(strict_types=1);

namespace Drupal\Tests\sensible_email_validation\Unit;

use Drupal\sensible_email_validation\SensibleEmailValidator;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\Attributes\CoversClass;
use PHPUnit\Framework\Attributes\Group;

#[CoversClass(SensibleEmailValidator::class)]
#[Group('sensible_email_validation')]
class SensibleEmailValidatorTest extends UnitTestCase {

  private SensibleEmailValidator $validator;

  protected function setUp(): void {
    parent::setUp();
    $this->validator = new SensibleEmailValidator();
  }

  /**
   * Test that SensibleEmailValidator doesn't interfere with normal valid addresses
   */
  public function testAddressWithTld(): void {
    $this->assertTrue($this->validator->isValid('test100@numiko.net'));
  }

  public function testAddressWithoutTld(): void {
    $this->assertFalse($this->validator->isValid('test100@numiko'));
  }

  /**
   * Test that SensibleEmailValidator passes failure result straight back from
   * default validator class.
   */
  public function testEmptyAddress(): void {
    $this->assertFalse($this->validator->isValid(''));
  }

}
