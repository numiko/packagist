<?php


namespace Drupal\sensible_email_validation;

use Egulias\EmailValidator\EmailLexer;
use Egulias\EmailValidator\EmailParser;
use Egulias\EmailValidator\Exception\InvalidEmail;
use Egulias\EmailValidator\Validation\EmailValidation;

class TLDValidation implements EmailValidation{
  /**
   * @var EmailParser|null
   */
  private $parser;

  /**
   * @var array
   */
  private $warnings = [];

  /**
   * @var InvalidEmail|null
   */
  private $error;

  /**
   * {@inheritdoc}
   */
  public function isValid($email, EmailLexer $emailLexer) {
    $this->parser = new EmailParser($emailLexer);
    try {
      $parts = $this->parser->parse((string) $email);
      if (isset($parts['domain'])) {
        if (strpos($parts['domain'], '.') !== FALSE) {
          $this->warnings = $this->parser->getWarnings();
          return TRUE;
        }
      }
      throw new NoTLD();

    }
    catch (InvalidEmail $invalid) {
      $this->error = $invalid;
      return FALSE;
    }
  }

  public function getError() {
    return $this->error;
  }

  public function getWarnings() {
    return $this->warnings;
  }

}
