<?php

namespace Drupal\sensible_email_validation;

use Egulias\EmailValidator\Exception\InvalidEmail;

class NoTLD extends InvalidEmail {
  const CODE = 222;
  const REASON = "No top-level domain";
}
