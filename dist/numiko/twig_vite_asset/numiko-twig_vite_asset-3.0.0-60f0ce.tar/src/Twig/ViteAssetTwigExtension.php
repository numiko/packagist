<?php

namespace Drupal\twig_vite_asset\Twig;

use Drupal\Core\Logger\LoggerChannelInterface;
use Drupal\Core\Theme\ThemeManagerInterface;
use Twig\TwigFunction;
use Twig\Extension\AbstractExtension;
use Drupal\Core\Template\TwigExtension;


/**
 * Vite Assets twig extension class.
 */
class ViteAssetTwigExtension extends AbstractExtension {

  /**
   * Core twig extension.
   *
   * @var \Drupal\Core\Template\TwigExtension
   */
  private TwigExtension $coreTwigExtension;

  /**
   * Core theme manager.
   *
   * @var \Drupal\Core\Theme\ThemeManagerInterface
   */
  private ThemeManagerInterface $themeManager;

  /**
   * @var \Drupal\Core\Logger\LoggerChannelInterface
   */
  private LoggerChannelInterface $logger;

  /**
   * {@inheritDoc}
   */
  public function __construct(TwigExtension $core_twig_extension, ThemeManagerInterface $theme_manager, LoggerChannelInterface $logger) {
    $this->coreTwigExtension = $core_twig_extension;
    $this->logger = $logger;
    $this->themeManager = $theme_manager;
  }

  /**
   * Get vite asset function.
   */
  public function getFunctions() {
    return [
      new TwigFunction('vite_asset', [$this, 'getViteAsset']),
    ];
  }

  /**
   * Return vite asset URL if mapping exists in manifest.
   *
   * @param string $sourceUrl
   *   The asset source URL.
   *
   * @return string $viteAssetUrl
   *   The asset URL relative to site document root.
   *   If a mapping is not found, source URL is returned.
   */
  public function getViteAsset(string $sourceUrl) {
    $theme = $this->themeManager->getActiveTheme();
    $activeThemeManifestUrl = DRUPAL_ROOT . '/' . $theme->getPath() . '/dist/' . '/.vite/manifest.json';
    $assetFileUrl = $this->getAssetFileUrl($sourceUrl, $activeThemeManifestUrl);
    if ($assetFileUrl) {
      return '/' . $theme->getPath() . '/dist/' . $assetFileUrl;
    }

    foreach ($theme->getBaseThemeExtensions() as $parent) {
      $parenthemeManifestUrl = DRUPAL_ROOT . '/' . $parent->getPath() . '/dist/' . '/.vite/manifest.json';
      $assetFileUrl = $this->getAssetFileUrl($sourceUrl, $parenthemeManifestUrl);
      if ($assetFileUrl) {
        return '/' . $parent->getPath() . '/dist/' . $assetFileUrl;
      }
    }

    $this->logger->error(
        '@sourceUrl could not be mapped to a vite asset.',
        ['@sourceUrl' => $sourceUrl]
      );
    return $sourceUrl;
  }

  /**
   * Return the file URL from the manifest.
   *
   * @param string $sourceUrl
   *   The asset source URL.
   *
   * @param string $manifestUrl
   *   The manifest URL.
   */
  protected function getAssetFileUrl(string $sourceUrl, string $manifestUrl) {
    if (!file_exists($manifestUrl)) {
      return NULL;
    }
    $manifest = file_get_contents($manifestUrl);
    $manifestArr = json_decode($manifest, true);
    if (!is_array($manifestArr)) {
      return NULL;
    }
    if (!array_key_exists($sourceUrl, $manifestArr)) {
      return NULL;
    }

    return $manifestArr[$sourceUrl]['file'];
  }

}