# Twig Vite Asset

Provides a twig function to get the Vite asset from a given source URL.

This module expects both the mapped Vite asset and Vite manifest.json file to exist at:
`{current_theme_path}/dist/`

For example:
`docroot/themes/custom/numiko/dist/manifest.json`
`docroot/themes/custom/numiko/dist/cafcass-logo.d3caf6d2.png`

## Functions

### vite_asset(sourceUrl)

Returns the Vite asset mapped to the given source URL if the mapping exists in the manifest.json.
If a mapping is not found, the sourceUrl is returned.
