<?php

namespace Drupal\twig_vite_asset\Twig;

use Drupal\Core\Logger\LoggerChannelInterface;
use Drupal\Core\Theme\ThemeManagerInterface;
use Twig\TwigFunction;
use Twig\Extension\AbstractExtension;
use Drupal\Core\Template\TwigExtension;


/**
 * Vite Assets twig extension class.
 */
class ViteAssetTwigExtension extends AbstractExtension {

  /**
   * Core twig extension.
   *
   * @var \Drupal\Core\Template\TwigExtension
   */
  private TwigExtension $coreTwigExtension;

  /**
   * Active theme path dist folder.
   *
   * @var string
   */
  private string $themeDistPath;

  /**
   * Vite manifest URL build from theme path.
   *
   * @var string
   */
  private string $manifestUrl;

  /**
   * @var \Drupal\Core\Logger\LoggerChannelInterface
   */
  private LoggerChannelInterface $logger;

  /**
   * {@inheritDoc}
   */
  public function __construct(TwigExtension $core_twig_extension, ThemeManagerInterface $theme_manager, LoggerChannelInterface $logger) {
    $this->coreTwigExtension = $core_twig_extension;
    $this->logger = $logger;
    $this->themeDistPath = '/' . $theme_manager->getActiveTheme()->getPath() . '/dist/';
    $this->manifestUrl = DRUPAL_ROOT . $this->themeDistPath . 'manifest.json';
  }

  /**
   * Get vite asset function.
   */
  public function getFunctions() {
    return [
      new TwigFunction('vite_asset', [$this, 'getViteAsset']),
    ];
  }

  /**
   * Return vite asset URL if mapping exists in manifest.
   *
   * @param string $sourceUrl
   *   The asset source URL.
   *
   * @return string $viteAssetUrl
   *   The asset URL relative to site document root.
   *   If a mapping is not found, source URL is returned.
   */
  public function getViteAsset(string $sourceUrl) {
    if (!file_exists($this->manifestUrl)) {
      $this->logger->error(
        '@sourceUrl could not be mapped to a vite asset. Vite manifest file not found.',
      ['@sourceUrl' => $sourceUrl]
      );
      return $sourceUrl;
    }
    $manifest = file_get_contents($this->manifestUrl);
    $manifestArr = json_decode($manifest, true);
    if (!is_array($manifestArr)) {
      $this->logger->error(
        '@sourceUrl could not be mapped to a vite asset. Vite manifest file format invalid.',
        ['@sourceUrl' => $sourceUrl]
      );
      return $sourceUrl;
    }
    if (!array_key_exists($sourceUrl, $manifestArr)) {
      $this->logger->error(
        '@sourceUrl could not be mapped to a vite asset. No vite asset mapping found in manifest.',
        ['@sourceUrl' => $sourceUrl]
      );
      return $sourceUrl;
    }

    return $this->themeDistPath . $manifestArr[$sourceUrl]['file'];
  }

}
