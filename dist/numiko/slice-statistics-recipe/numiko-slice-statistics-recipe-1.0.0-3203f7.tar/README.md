# Statistics Slice Recipe

This recipe installs statistic slice config.

## Installation

Install using the recipe drush command:
`drush recipe:install`

Manual installation: 
Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-statistics-slice`
