# Paragraphs Category Modal #

A module to enhance the paragraphs modal widget by categorising paragraph types using a colon prefix, 
e.g.

`Content: Accordion`

would be put in a field group of "Content" and the slice name of "Accordion".

This will affect all modal fields, and can be further customised by overriding the `paragraphs-add-dialog.html.twig` template.