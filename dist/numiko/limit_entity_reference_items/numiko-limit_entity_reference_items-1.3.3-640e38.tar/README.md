# Limit Entity Reference Items

Allows an entity reference / entity reference revision field to have limits set
on both upper and lower limits on a per instance basis.

This should be used carefully and in a considered manner, but will ultimately allow
an entity reference field to have unlimited cardinality but for one instance to have
a minimum and maximum number set differently in different locations.

## Usage

Enable the module as you would for any drupal module.

When adding an entity reference / entity reference revision field on the field
config form you will be shown two additional fields Minimum and Maximum items,
set the value applicable in each field.

Note: This will not override a required field status, so if a field is not required
and a minimum is set this will only apply if more than one item has been added.
