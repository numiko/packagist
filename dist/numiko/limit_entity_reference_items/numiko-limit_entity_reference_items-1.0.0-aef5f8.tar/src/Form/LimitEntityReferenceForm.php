<?php

namespace Drupal\limit_entity_reference_items\Form;

use Drupal\Core\Form\FormStateInterface;

/**
 * Verifies a minimum number of items in a field in a paragraph.
 */
class LimitEntityReferenceForm {

  /**
   * Validate entity reference fields that have limits.
   */
  public static function validateLimit(array &$form, FormStateInterface $form_state) {
    $trigger = $form_state->getTriggeringElement();
    if (!empty($trigger['#limit_validation_errors']) && in_array($form['#parents'], $trigger['#limit_validation_errors'])) {
      return;
    }
    $minimum = $form['#minimum_items'];
    $maximum = $form['#maximum_items'];
    if (!$minimum && !$maximum) {
      return;
    }
    $count = 0;
    if ($form_state->hasValue($form['#parents'])) {
      $count = count(array_filter($form_state->getValue($form['#parents']), function ($value) {
        return (is_array($value) && !empty($value['target_id']));
      }));
    }
    // If there are no values then this would be handled
    // by "required" validation.
    if (!$count) {
      return;
    }
    if ($minimum && $count < $minimum) {
      $form_state->setErrorByName(implode('][', $form['#parents']), t('@name field requires a minimum of @minimum items.', ['@name' => $form['#title'], '@minimum' => $minimum]));
    }
    if ($maximum && $count > $maximum) {
      $form_state->setErrorByName(implode('][', $form['#parents']), t('@name field requires a minimum of @minimum items.', ['@name' => $form['#title'], '@minimum' => $minimum]));
    }
  }

}
