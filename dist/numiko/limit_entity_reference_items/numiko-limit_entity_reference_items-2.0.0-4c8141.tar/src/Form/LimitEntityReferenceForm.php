<?php

namespace Drupal\limit_entity_reference_items\Form;

use Drupal\Core\Form\FormStateInterface;

/**
 * Verifies a minimum number of items in a field in a paragraph.
 */
class LimitEntityReferenceForm {

  /**
   * Validate entity reference fields that have limits.
   */
  public static function validateLimit(array &$form, FormStateInterface $form_state) {
    $trigger = $form_state->getTriggeringElement();
    if (!empty($trigger['#limit_validation_errors']) && in_array($form['#parents'], $trigger['#limit_validation_errors'])) {
      return;
    }
    $minimum = $form['#minimum_items'];
    $maximum = $form['#maximum_items'];
    if (!$minimum && !$maximum) {
      return;
    }
    $count = 0;
    if ($form_state->hasValue($form['#parents'])) {
      $values = $form_state->getValue($form['#parents']);
      // Check the inline entity reference if it is a node which has an extra
      // layer of nesting.
      $values = $values['entities'] ?? $values;
      $count = count(
        array_filter(
          $values,
          fn ($value) => is_array($value) && self::filterAdminValues($value)
        )
      );
    }
    // If there are no values then this would be handled
    // by "required" validation.
    if (!$count) {
      return;
    }
    if ($minimum && $count < $minimum) {
      $form_state->setErrorByName(implode('][', $form['#parents']), t('@name field requires a minimum of @minimum items.', ['@name' => $form['#title'], '@minimum' => $minimum]));
    }
    if ($maximum && $count > $maximum) {
      $form_state->setErrorByName(implode('][', $form['#parents']), t('@name field requires a maximum of @maximum items.', ['@name' => $form['#title'], '@maximum' => $maximum]));
    }
  }

  /**
   * Does the form value carry 'data'.
   *
   * @param array $value
   *
   * @return bool
   */
  private static function filterAdminValues(array $value): bool {
    // The array has a target id or subform then it is likely something we want
    // to keep.
    if (!(empty($value['target_id']) && empty($value['subform']))) {
      return TRUE;
    }
    if (empty($value['actions'])) {
      // If we reach here neither target_id, subform or actions exist so we
      // don't want to keep it.
      return FALSE;
    };

    foreach ($value['actions'] as $key => $_) {
      // If collapse_all key exists in actions then its probably an admin
      // element.
      if (str_contains($key, 'collapse_all')) {
        return FALSE;
      }
    }

    // Here actions does exist and nothing is collapse all so we keep it.
    return TRUE;
  }

}
