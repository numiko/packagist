<?php

namespace Drupal\limit_entity_reference_items\Hook;

use Drupal\Core\Field\FieldConfigBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Hook implementations for limit_entity_reference_items.
 */
final class LimitEntityReferenceItemsHooks {
  use StringTranslationTrait;

  public function __construct(TranslationInterface $stringTranslation) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Define what field types we want to modify.
   *
   * @return array
   *   Array of modifiable field types.
   */
  private static function fieldTypes(): array {
    return ['entity_reference', 'entity_reference_revisions'];
  }

  /**
   * Implements hook_field_widget_complete_form_alter().
   */
  #[Hook('field_widget_complete_form_alter')]
  public function fieldWidgetCompleteFormAlter(array &$field_widget_complete_form, FormStateInterface $form_state, array $context): void {
    /** @var \Drupal\Core\Field\FieldDefinitionInterface $field_definition */
    $field_definition = $context['items']->getFieldDefinition();
    // We can't use the protected isDefaultValueWidget() method.
    $is_default_value_widget = (bool) $form_state->get('default_value_widget');
    if (in_array($field_definition->getType(), self::fieldTypes()) && !$is_default_value_widget) {
      if ($field_definition instanceof FieldConfigBase) {
        // Read configuration if available.  This is possible for bundle fields
        // or base fields overridden using a BaseFieldOverride.
        $field_configuration = $field_definition->getConfig($field_definition->getTargetBundle());
        $minimum_setting = $field_configuration->getThirdPartySetting('limit_entity_reference_items', 'minimum_items');
        $maximum_setting = $field_configuration->getThirdPartySetting('limit_entity_reference_items', 'maximum_items');
      }
      else {
        // Base fields don't support third party settings so use an ordinary
        // setting.  That's the way it would work anyway if allowed formats gets
        // into core.
        $minimum_setting = $field_definition->getSetting('minimum_items');
        $maximum_setting = $field_definition->getSetting('maximum_items');
      }
      // Hide the add button if the maximum number of items is reached.
      if (!empty($maximum_setting) && is_numeric($maximum_setting) && !empty($field_widget_complete_form)) {
        // Count number of integer arrays for paragraph item count.
        $item_indicies = array_filter(array_keys($field_widget_complete_form['widget']), 'is_int');
        $real_item_count = count($item_indicies);
        $reached_max_number_of_items = $real_item_count >= $maximum_setting;

        // See if we need to hide the add more buttons.
        $remove_button_pressed = $form_state->getTriggeringElement() && strpos($form_state->getTriggeringElement()['#name'], 'remove');
        $hide_add_buttons = $reached_max_number_of_items && !$remove_button_pressed;
        if ($hide_add_buttons) {
          if ($this->traversingArrayKeyExists(['widget', 'add_more'], $field_widget_complete_form)) {
            $field_widget_complete_form['widget']['add_more']['#access'] = FALSE;
          }

          foreach ($item_indicies as $item_index) {
            if ($this->traversingArrayKeyExists(['top', 'actions', 'dropdown_actions', 'duplicate_button'], $field_widget_complete_form['widget'][$item_index])) {
              $field_widget_complete_form['widget'][$item_index]['top']['actions']['dropdown_actions']['duplicate_button']['#access'] = FALSE;
            }
          }
        }
      }
      if (!empty($minimum_setting) && is_numeric($minimum_setting) || !empty($maximum_setting) && is_numeric($maximum_setting)) {
        $field_widget_complete_form['widget']['#minimum_items'] = $minimum_setting ?? 0;
        $field_widget_complete_form['widget']['#maximum_items'] = $maximum_setting;
        $field_widget_complete_form['widget']['#element_validate'][] = [
          LimitEntityReferenceItemsHooks::class,
          'validateLimit',
        ];
      }
    }
  }

  /**
   * A version of array_key_exists that traverses nested arrays.
   *
   * Parameters are deliberately like array_key_exists.
   *
   * @param list<string|int> $keys
   *   An array of keys.
   * @param array $array
   *   Nested array with keys to check.
   *
   * @return bool
   */
  protected static function traversingArrayKeyExists(array $keys, array $array): bool {
    // No keys - we've reached the target and can confirm this path of keys
    // exists.
    if (empty($keys)) {
      return TRUE;
    }

    // Otherwise we pop the next key from the beginning.
    $nextKey = array_shift($keys);
    if (array_key_exists($nextKey, $array)) {
      // Call this function with the top level of nesting removed.
      return static::traversingArrayKeyExists($keys, $array[$nextKey]);
    }
    else {
      return FALSE;
    }
  }

  /**
   * Validate entity reference fields that have limits.
   */
  public static function validateLimit(array &$form, FormStateInterface $form_state): void {
    $trigger = $form_state->getTriggeringElement();
    if (!empty($trigger['#limit_validation_errors']) && in_array($form['#parents'], $trigger['#limit_validation_errors'])) {
      return;
    }
    $minimum = $form['#minimum_items'];
    $maximum = $form['#maximum_items'];
    if (!$minimum && !$maximum) {
      return;
    }
    $count = 0;
    if ($form_state->hasValue($form['#parents'])) {
      $values = $form_state->getValue($form['#parents']);
      // Check the inline entity reference if it is a node which has an extra
      // layer of nesting.
      $values = $values['entities'] ?? $values;
      $count = count(
        array_filter($values, fn ($value) => is_array($value) && self::filterAdminValues($value))
      );
    }
    // If there are no values then this would be handled
    // by "required" validation.
    if (!$count) {
      return;
    }
    if ($minimum && $count < $minimum) {
      $form_state->setErrorByName(
        implode('][', $form['#parents']),
        t('@name field requires a minimum of @minimum items.',
        ['@name' => $form['#title'], '@minimum' => $minimum]));
    }
    if ($maximum && $count > $maximum) {
      $form_state->setErrorByName(
        implode('][', $form['#parents']),
        t('@name field requires a maximum of @maximum items.', ['@name' => $form['#title'], '@maximum' => $maximum])
      );
    }
  }

  /**
   * Does the form value carry 'data'.
   *
   * @param array $value
   *
   * @return bool
   */
  private static function filterAdminValues(array $value): bool {
    // The array has a target id or subform then it is likely something we want
    // to keep.
    if (!(empty($value['target_id']) && empty($value['subform']))) {
      return TRUE;
    }
    if (empty($value['actions'])) {
      // If we reach here neither target_id, subform or actions exist so we
      // don't want to keep it.
      return FALSE;
    }

    foreach ($value['actions'] as $key => $_) {
      // If collapse_all key exists in actions then its probably an admin
      // element.
      if (str_contains($key, 'collapse_all')) {
        return FALSE;
      }
    }

    // Here actions does exist and nothing is collapse all so we keep it.
    return TRUE;
  }

  /**
   * Implements hook_form_FORM_ID_form_alter().
   */
  #[Hook('form_field_config_edit_form_alter')]
  public function formFieldConfigEditFormAlter(array &$form, FormStateInterface $form_state): void {
    /** @var \Drupal\Core\Field\FieldConfigInterface $field */
    $field = $form_state->getFormObject()->getEntity();

    if (in_array($field->getType(), self::fieldTypes())) {
      $settings = $field->getThirdPartySettings('limit_entity_reference_items');
      $form['third_party_settings']['limit_entity_reference_items']['minimum_items'] = [
        '#type' => 'number',
        '#title' => $this->t('Minimum number of entity reference items'),
        '#default_value' => !empty($settings['minimum_items']) ? $settings['minimum_items'] : [],
        '#description' => $this->t('Limit the number of entity reference items to a minimum'),
      ];
      $form['third_party_settings']['limit_entity_reference_items']['maximum_items'] = [
        '#type' => 'number',
        '#title' => $this->t('Maximum number of entity reference items'),
        '#default_value' => !empty($settings['maximum_items']) ? $settings['maximum_items'] : [],
        '#description' => $this->t('Limit the number of entity reference items to a maximum'),
      ];

      array_unshift($form['actions']['submit']['#submit'], [LimitEntityReferenceItemsHooks::class, 'submit']);
    }
  }

  /**
   * Submit callback for Limit Entity Reference Items field config form.
   *
   * Remove the third party settings for limit entity reference items if
   * the fields are empty, this ensures this module is only a dependency if
   * used.
   *
   * @see limit_entity_reference_items_form_field_config_edit_form_alter
   */
  public static function submit($form, FormStateInterface $form_state): void {
    $settings = $form_state->getValue('third_party_settings');
    if (isset($settings['limit_entity_reference_items'])) {
      $settings['limit_entity_reference_items'] = array_filter($settings['limit_entity_reference_items']);
      if (empty($settings['limit_entity_reference_items'])) {
        unset($settings['limit_entity_reference_items']);
      }
      $form_state->setValue('third_party_settings', $settings);
    }
  }

}
