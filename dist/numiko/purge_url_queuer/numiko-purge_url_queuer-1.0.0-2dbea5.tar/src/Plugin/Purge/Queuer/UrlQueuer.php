<?php

namespace Drupal\purge_url_queuer\Plugin\Purge\Queuer;

use Drupal\purge\Plugin\Purge\Queuer\QueuerInterface;
use Drupal\purge\Plugin\Purge\Queuer\QueuerBase;

/**
 * Queues URLs to be purged.
 *
 * @PurgeQueuer(
 *   id = "url_queuer",
 *   label = @Translation("URL Queuer"),
 *   description = @Translation("Queues URLs to be purged."),
 *   enable_by_default = true,
 * )
 */

class UrlQueuer extends QueuerBase implements QueuerInterface {}
