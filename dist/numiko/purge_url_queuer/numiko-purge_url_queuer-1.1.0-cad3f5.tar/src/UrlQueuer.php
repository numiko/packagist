<?php

namespace Drupal\purge_url_queuer;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\File\FileUrlGenerator;
use Drupal\Core\Url;
use Drupal\purge\Plugin\Purge\Invalidation\InvalidationsServiceInterface;
use Drupal\purge\Plugin\Purge\Queue\QueueServiceInterface;
use Drupal\purge\Plugin\Purge\Queuer\QueuersServiceInterface;

/**
 * UrlQueuer class.
 */
class UrlQueuer {

  /**
   * @var \Drupal\purge\Plugin\Purge\Invalidation\InvalidationsServiceInterface
   */
  protected $purgeInvalidationFactory;

  /**
   * @var \Drupal\purge\Plugin\Purge\Queuer\QueuersServiceInterface
   */
  protected $queuersService;

  /**
   * @var \Drupal\purge\Plugin\Purge\Queue\QueueServiceInterface
   */
  protected $queueService;

  /**
   * @var \Drupal\Core\File\FileUrlGenerator
   */
  protected $fileUrlGenerator;

  /**
   * Constructor.
   *
   * @param \Drupal\purge\Plugin\Purge\Invalidation\InvalidationsServiceInterface $purgeInvalidationFactory
   *   The invalidation service.
   * @param \Drupal\purge\Plugin\Purge\Queuer\QueuersServiceInterface $queuersService
   *   The queuers service.
   * @param \Drupal\purge\Plugin\Purge\Queue\QueueServiceInterface $queueService
   *   The queue service.
   * @param \Drupal\Core\File\FileUrlGenerator $fileUrlGenerator
   *   The file url generator.
   */
  public function __construct(InvalidationsServiceInterface $purgeInvalidationFactory, QueuersServiceInterface $queuersService, QueueServiceInterface $queueService, FileUrlGenerator $fileUrlGenerator) {
    $this->purgeInvalidationFactory = $purgeInvalidationFactory;
    $this->queuersService = $queuersService;
    $this->queueService = $queueService;
    $this->fileUrlGenerator = $fileUrlGenerator;
  }

  /**
   * Add node URL to the queue.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity to add.
   *
   * @return void
   */
  public function queueNode(EntityInterface $entity) {
    $url = Url::fromRoute('entity.node.canonical', ['node' => $entity->id()], ['absolute' => TRUE])->toString();
    $queuer = $this->queuersService->get('url_queuer');
    $invalidations = [
      $this->purgeInvalidationFactory->get('url', $url),
    ];

    $this->queueService->add($queuer, $invalidations);
  }

  /**
   * Add file URL to the queue.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity to add.
   *
   * @return void
   */
  public function queueFile(EntityInterface $entity) {
    $url = $this->fileUrlGenerator->generateAbsoluteString($entity->getFileUri());
    $queuer = $this->queuersService->get('url_queuer');
    $invalidations = [
      $this->purgeInvalidationFactory->get('url', $url),
    ];

    $this->queueService->add($queuer, $invalidations);
  }

}
