<?php

namespace Drupal\listings_filter\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Listings paragraph entities.
 */
interface ListingsParagraphInterface extends ConfigEntityInterface {

  /**
   * Get the paragraph type ID to reference.
   *
   * @return string
   *   The paragraph type ID to reference.
   */
  public function getParagraphTypeId();

  /**
   * Set the paragraph type ID to reference.
   *
   * @param string $paragraphTypeId
   *   The paragraph type ID to reference.
   */
  public function setParagraphTypeId(string $paragraphTypeId);

  /**
   * Get the Listings paragraph prefilter fields.
   *
   * @return array
   *   The prefilter field mappings.
   */
  public function getPrefilterFields();

  /**
   * Set the Listings paragraph prefilter fields.
   *
   * @param array $prefilterFields
   *   The Listings paragraph prefilter field mappings.
   */
  public function setPrefilterFields(array $prefilterFields);

  /**
   * Get the Listings paragraph facets field.
   *
   * @return string
   *   The field ID of the field referencing the facets.
   */
  public function getFacetsField();

  /**
   * Set the Listings paragraph facets field.
   *
   * @param string $facetsField
   *   The Listings paragraph facets field.
   */
  public function setFacetsField(string $facetsField);

  /**
   * Get the Listings paragraph pinned items field.
   *
   * @return string
   *   The field ID of the field referencing the items to pin.
   */
  public function getPinnedItemsField();

  /**
   * Set the Listings paragraph pinned items field.
   *
   * @param string $pinnedItemsField
   *   The Listings paragraph pinned items field.
   */
  public function setPinnedItemsField(string $pinnedItemsField);

  /**
   * Get the Listings paragraph items per page field.
   *
   * @return string
   *   The Listings paragraph items per page field.
   */
  public function getItemsPerPageField();

  /**
   * Set the Listings paragraph items per page field.
   *
   * @param string $itemsPerPageField
   *   The Listings paragraph items per page field.
   */
  public function setItemsPerPageField(string $itemsPerPageField);

  /**
   * Get the Listings paragraph items per page value.
   *
   * @return int
   *   The Listings paragraph items per page value.
   */
  public function getItemsPerPageValue();

  /**
   * Set the Listings paragraph items per page value.
   *
   * @param int $itemsPerPageValue
   *   The Listings paragraph items per page value.
   */
  public function setItemsPerPageValue(int $itemsPerPageValue);

  /**
   * Get the Listings paragraph result count field.
   *
   * @return string
   *   The Listings paragraph result count field.
   */
  public function getResultCountField();

  /**
   * Set the Listings paragraph result count field.
   *
   * @param string $resultCountField
   *   The Listings paragraph result count field.
   */
  public function setResultCountField(string $resultCountField);

  /**
   * Get the Listings paragraph result count value.
   *
   * @return int
   *   The Listings paragraph result count value.
   */
  public function getResultCountValue();

  /**
   * Set the Listings paragraph result count value.
   *
   * @param int $resultCountValue
   *   The Listings paragraph result count value.
   */
  public function setResultCountValue(int $resultCountValue);

  /**
   * Get the Listings paragraph prefilter values.
   *
   * @return array
   *   The Listings paragraph prefilter values.
   */
  public function getPrefilterValues();

  /**
   * Set the Listings paragraph prefilter values.
   *
   * @param array $prefilterValues
   *   The Listings paragraph prefilter values.
   */
  public function setPrefilterValues(array $prefilterValues);

  /**
   * Get the Listings paragraph sort values.
   *
   * @return array
   *   The Listings paragraph sort values.
   */
  public function getSortValues();

  /**
   * Set the Listings paragraph sort values.
   *
   * @param array $sortValues
   *   The Listings paragraph sort values.
   */
  public function setSortValues(array $sortValues);

  /**
   * Get the Listings paragraph user sort values.
   *
   * @return array
   *   The Listings paragraph user sort values.
   */
  public function getUserSortValues();

  /**
   * Set the Listings paragraph user sorts field.
   *
   * @param array $userSortsValues
   *   The Listings paragraph user sort values.
   */
  public function setUserSortValues(array $userSortsValues);

  /**
   * Get whether the Listings paragraph has a keyword search.
   *
   * @return bool
   *   Whether the Listings paragraph has a keyword search.
   */
  public function getHasKeyword();

  /**
   * Set whether the Listings paragraph has a keyword search.
   *
   * @param bool $hasKeyword
   *   Whether the Listings paragraph has a keyword search.
   */
  public function setHasKeyword(bool $hasKeyword);

  /**
   * Get the display mode used to render the markup.
   *
   * @return string
   *   The listing display mode.
   */
  public function getDisplayMode();

  /**
   * Set the display mode.
   *
   * @param string|null $displayMode
   *   The listing display mode.
   */
  public function setDisplayMode(?string $displayMode);

  /**
   * Get the display mode used to render the promoted markup.
   *
   * @return string
   *   The listing display mode.
   */
  public function getPromotedDisplayMode();

  /**
   * Set the promoted display mode.
   *
   * @param string|null $displayMode
   *   The listing display mode.
   */
  public function setPromotedDisplayMode(?string $displayMode);

  /**
   * Get the promoted content field.
   *
   * @return string
   *   The field.
   */
  public function getPromotedContentField();

  /**
   * Set the promoted content field.
   *
   * @param string|null $field
   *   The field.
   */
  public function setPromotedContentField(?string $field);


}
