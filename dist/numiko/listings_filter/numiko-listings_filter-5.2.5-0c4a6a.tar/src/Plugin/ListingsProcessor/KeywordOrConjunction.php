<?php

declare(strict_types=1);

namespace Drupal\listings_filter\Plugin\ListingsProcessor;

use Drupal\Core\Form\SubformStateInterface;
use Drupal\listings_filter\ListingsProcessorBase;
use Drupal\search_api\Query\QueryInterface;

/**
 * Switches multi-term fulltext searches to OR conjunction.
 *
 * The default Terms parse mode uses AND, which causes queries like
 * "Norfolk FLO" to miss the Norfolk area page. The page body contains
 * "FLOs" (plural), which the Porter stemmer keeps as "flos" — the M=0
 * guard prevents stripping the trailing s from a 3-letter stem — so it
 * never matches the query token "flo". OR conjunction fixes this while
 * relevance scoring still ranks documents matching more terms above those
 * matching fewer.
 *
 * @ListingsProcessor(
 *   id = "keyword_or_conjunction",
 *   name = @Translation("OR Conjunction"),
 *   description = @Translation("Switches multi-term fulltext searches from AND to OR so documents matching any keyword appear in results."),
 *   stages = {
 *     "alter_query" = 0,
 *   }
 * )
 */
class KeywordOrConjunction extends ListingsProcessorBase {

  /**
   * {@inheritdoc}
   */
  public function alterQuery(QueryInterface &$query, array $settings = []): void {
    $originalKeys = $query->getOriginalKeys();
    if (!$originalKeys) {
      return;
    }

    $query->getParseMode()->setConjunction('OR');
    // Keys are parsed at assignment time, so re-parse after changing conjunction.
    $query->keys($originalKeys);
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $subform, SubformStateInterface $processorFormState): array {
    return [];
  }

}
