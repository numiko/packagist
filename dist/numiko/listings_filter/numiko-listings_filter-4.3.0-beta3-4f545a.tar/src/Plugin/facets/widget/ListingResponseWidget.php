<?php

namespace Drupal\listings_filter\Plugin\facets\widget;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\facets\FacetInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\facets\Result\ResultInterface;
use Drupal\facets\Widget\WidgetPluginBase;

/**
 * A simple widget class that returns for inclusion in Listing Filters.
 *
 * @FacetsWidget(
 *   id = "listings_filter",
 *   label = @Translation("Listing Filter JSON"),
 *   description = @Translation("A widget that builds an array with results. Used only for integrating into Listing Filters."),
 * )
 */
class ListingResponseWidget extends WidgetPluginBase {

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return parent::defaultConfiguration() + ['show_additional_field_data' => []];
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state, FacetInterface $facet) {
    $form = parent::buildConfigurationForm($form, $form_state, $facet);

    $dataDefinition = $facet->getDataDefinition()->toArray();
    if (isset($dataDefinition['type']) && $dataDefinition['type'] === 'field_item:entity_reference') {
      $form['show_additional_field_data'] = [
        '#type' => 'details',
        '#open' => TRUE,
        '#title' => 'Additional field data to include in facet result',
        '#description' => 'Check the fields that should be returned alongside the facet result label',
      ];

      $config = $this->getConfiguration();
      $bundleFields = $this->getBundleFields($dataDefinition['settings']['target_type'], reset($dataDefinition['settings']['handler_settings']['target_bundles']));
      foreach ($bundleFields as $fieldConfig) {
        $form['show_additional_field_data'][$fieldConfig->getName()] = [
          '#type' => 'checkbox',
          '#title' => $fieldConfig->label(),
          '#default_value' => (!empty($config['show_additional_field_data'][$fieldConfig->getName()])),
        ];
      }
    }

    return $form;
  }

  /**
   * Retrieve the bundle specific fields.
   *
   * This is identified as those that are not derived from BaseFieldDefinition.
   */
  protected function getBundleFields($entityTypeId, $bundle) {
    $fields = \Drupal::service('entity_field.manager')->getFieldDefinitions($entityTypeId, $bundle);
    return array_filter($fields, function ($fieldDefinition) {
      return !($fieldDefinition instanceof BaseFieldDefinition);
    });
  }

  /**
   * {@inheritdoc}
   */
  public function build(FacetInterface $facet) {
    $build = [
      'id' => $facet->id(),
      'label' => $facet->getName(),
      'path' => $facet->getUrlAlias(),
      'terms' => [],
    ];

    $configuration = $facet->getWidget();
    $this->showNumbers = empty($configuration['show_numbers']) ? FALSE : (bool) $configuration['show_numbers'];
    foreach ($facet->getResults() as $result) {
      $build['terms'][] = $this->generateValues($result);
    }
    return $build;
  }

  /**
   * Generates the value and the url.
   *
   * @param \Drupal\facets\Result\ResultInterface $result
   *   The result to extract the values.
   *
   * @return array
   *   The values.
   */
  protected function generateValues(ResultInterface $result) {
    $values = [
      'value' => $result->getRawValue(),
      'label' => $result->getDisplayValue(),
      'active' => $result->isActive(),
    ];

    if ($this->configuration['show_numbers']) {
      $values['count'] = (int) $result->getCount();
    }

    if (!empty($this->configuration['show_additional_field_data'])) {
      $values += $this->getAdditionalFieldData($result);
    }

    return $values;
  }

  /**
   * Fetch additional field data for the facet result entity.
   */
  protected function getAdditionalFieldData(ResultInterface $result) {
    $entity = $this->getFacetEntity($result);
    if (!$entity) {
      return [];
    }
    $values = [];
    foreach (array_keys(array_filter($this->configuration['show_additional_field_data'])) as $fieldName) {
      $values[$fieldName] = ($entity->hasField($fieldName) && !$entity->get($fieldName)->isEmpty()) ? $entity->get($fieldName)->getString() : '';
    }
    return $values;
  }

  /**
   * Derive the entity from the facet raw value (ID) based on the target_type.
   */
  protected function getFacetEntity(ResultInterface $result) {
    $settings = $result->getFacet()->getDataDefinition()->getSettings();
    if (!isset($settings['target_type'])) {
      return NULL;
    }
    return \Drupal::entityTypeManager()->getStorage($settings['target_type'])->load($result->getRawValue());
  }

}
