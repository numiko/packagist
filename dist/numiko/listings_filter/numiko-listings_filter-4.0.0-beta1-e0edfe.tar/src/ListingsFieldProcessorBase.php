<?php

namespace Drupal\listings_filter;

use Drupal\Component\Plugin\PluginBase;

/**
 * The base class for the listing field processor.
 */
abstract class ListingsFieldProcessorBase extends PluginBase implements ListingsFieldProcessorInterface {

  public function verifyPluginConfiguration() {
    return $this;
  }

  public function getId() {
    return $this->pluginDefinition['id'];
  }

  public function getName() {
    return $this->pluginDefinition['name'];
  }

  public function getDescription() {
    return $this->pluginDefinition['description'];
  }

}
