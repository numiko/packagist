<?php

namespace Drupal\listings_filter_autocomplete\EventSubscriber;

use Drupal\listings_filter_autocomplete\Plugin\ListingsProcessor\Autocomplete;
use Drupal\search_api\Event\ProcessingResultsEvent;
use Drupal\search_api\Event\QueryPreExecuteEvent;
use Drupal\search_api\Event\SearchApiEvents;
use Drupal\search_api\ParseMode\ParseModePluginManager;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Adjusts the listing's queries when they are run for suggestions.
 *
 * The Autocomplete processor tags these queries, so a listing's own searches
 * are never affected.
 *
 * @see \Drupal\listings_filter_autocomplete\Plugin\ListingsProcessor\Autocomplete::alterQuery()
 */
class AutocompleteSubscriber implements EventSubscriberInterface {

  /**
   * Tags the search run again for typos, so it is not retried itself.
   */
  const RETRY_TAG = 'listings_filter_autocomplete_typos';

  /**
   * Constructs an AutocompleteSubscriber.
   *
   * @param \Drupal\search_api\ParseMode\ParseModePluginManager $parseModeManager
   *   The Search API parse mode manager.
   */
  public function __construct(
    protected ParseModePluginManager $parseModeManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      SearchApiEvents::QUERY_PRE_EXECUTE => 'skipFacets',
      SearchApiEvents::PROCESSING_RESULTS => 'allowForTypos',
    ];
  }

  /**
   * Skips the listing's facet query, as suggestions show no facets.
   */
  public function skipFacets(QueryPreExecuteEvent $event): void {
    $query = $event->getQuery();
    if ($query->hasTag(Autocomplete::TAG) && $query->hasTag('listings_filter_facets')) {
      $query->abort();
    }
  }

  /**
   * Runs a search that found nothing again, allowing for typos.
   */
  public function allowForTypos(ProcessingResultsEvent $event): void {
    $results = $event->getResults();
    $query = $results->getQuery();
    if (!$query->getOption(Autocomplete::TYPOS_OPTION)
      || $results->getResultCount() > 0
      || $query->hasTag('listings_filter_facets')
      || $query->hasTag('listings_filter_promoted_items')
      || $query->hasTag(self::RETRY_TAG)) {
      return;
    }

    $keys = $query->getOriginalKeys();
    if (!is_string($keys) || trim($keys) === '') {
      return;
    }

    // Solr allows a typo in each word, still matching every word so the
    // suggestions stay close. Backends without typo matching match any word.
    if ($this->parseModeManager->hasDefinition('fuzzy_terms')) {
      $parseMode = $this->parseModeManager->createInstance('fuzzy_terms');
    }
    else {
      $parseMode = $this->parseModeManager->createInstance('terms');
      $parseMode->setConjunction('OR');
    }

    // The query as built by the listing, with its fields, filters and range.
    $retry = clone $query->getOriginalQuery();
    $retry->setParseMode($parseMode);
    $retry->keys($keys);
    $retry->addTag(self::RETRY_TAG);
    $retryResults = $retry->execute();

    $results->setResultItems($retryResults->getResultItems());
    $results->setResultCount($retryResults->getResultCount());
  }

}
