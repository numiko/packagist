<?php

namespace Drupal\listings_filter_autocomplete\Controller;

use Drupal\Core\Cache\CacheableJsonResponse;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Http\Exception\CacheableBadRequestHttpException;
use Drupal\Core\Http\Exception\CacheableNotFoundHttpException;
use Drupal\listings_filter\ContentListing;
use Drupal\listings_filter\ListingQueryManager;
use Drupal\listings_filter\ListingsProcessorInterface;
use Drupal\listings_filter_autocomplete\Plugin\ListingsProcessor\Autocomplete;
use Drupal\paragraphs\ParagraphInterface;
use Drupal\search_api\SearchApiException;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

/**
 * Provides the content a placed listing suggests for what was typed.
 *
 * Runs the listing's own query, so suggestions keep to its prefilters, with
 * the Autocomplete processor's settings: only the chosen fields are matched,
 * at most the chosen number is returned, and each is shown as a link. The
 * response has the listing API's shape, without facets.
 */
class Suggestions implements ContainerInjectionInterface {

  /**
   * Constructs a Suggestions controller.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\listings_filter\ContentListing $contentListing
   *   The service that builds listing settings.
   * @param \Drupal\listings_filter\ListingQueryManager $listingQueryManager
   *   The listing query manager.
   */
  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected ContentListing $contentListing,
    protected ListingQueryManager $listingQueryManager,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('listings_filter.settings'),
      $container->get('plugin.manager.listing_query'),
    );
  }

  /**
   * Get the suggestions for the `fulltext` query parameter.
   *
   * @param \Drupal\paragraphs\ParagraphInterface $paragraph
   *   The placed listing.
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The request.
   *
   * @return \Drupal\Core\Cache\CacheableJsonResponse
   *   The suggestions, as `items`, and their total, as `meta.count`.
   */
  public function get(ParagraphInterface $paragraph, Request $request): CacheableJsonResponse {
    $cacheability = (new CacheableMetadata())
      ->addCacheContexts(['url.query_args:fulltext'])
      ->addCacheableDependency($paragraph);

    $listings = $this->entityTypeManager
      ->getStorage('listings_paragraph')
      ->loadByProperties(['paragraph_type_id' => $paragraph->bundle()]);
    $listing = reset($listings);
    if ($listing) {
      $cacheability->addCacheableDependency($listing);
    }

    $processor = $listing ? ($listing->getProcessors()['listings_autocomplete'] ?? NULL) : NULL;
    if (!$processor) {
      throw new CacheableNotFoundHttpException($cacheability, 'This listing does not suggest content.');
    }
    $config = ($processor['settings'] ?? []) + Autocomplete::DEFAULTS;

    $data = ['items' => [], 'meta' => ['count' => 0]];

    // The frontend waits for this many characters too; a broader search
    // would only be slower.
    $keyword = trim((string) $request->query->get('fulltext', ''));
    if (mb_strlen($keyword) >= $config['min_chars']) {
      $settings = $this->contentListing->buildListingQuerySettings($listing, $paragraph);
      $settings[Autocomplete::SUGGESTIONS] = TRUE;
      $settings['display_mode'] = 'search_suggestion';
      $settings['promoted_display_mode'] = 'search_suggestion';
      $settings['result_count'] = (string) $config['count'];
      $settings['facets'] = [];
      // Processors deciding which content is found still apply. Those adding
      // to the response, such as alternatives when nothing is found, are for
      // the listing itself.
      unset($settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_RESPONSE_DATA]);

      $index = $this->entityTypeManager->getStorage('search_api_index')->load($settings['search_index']);
      $listingQuery = $this->listingQueryManager->getListingQuery($index->getServerInstance()->getBackendId());
      $cacheability = $cacheability->merge($listingQuery->getCacheDependencies($settings));

      try {
        $results = $listingQuery->getResults($settings, ['fulltext' => $keyword]);
      }
      catch (SearchApiException $exception) {
        throw new CacheableBadRequestHttpException($cacheability, $exception->getMessage());
      }
      $data = [
        'items' => $results['items'],
        'meta' => ['count' => $results['meta']['count']],
      ];
    }

    $response = new CacheableJsonResponse($data);
    $response->addCacheableDependency($cacheability);
    return $response;
  }

}
