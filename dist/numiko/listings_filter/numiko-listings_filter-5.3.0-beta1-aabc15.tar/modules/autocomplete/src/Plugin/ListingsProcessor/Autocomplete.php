<?php

namespace Drupal\listings_filter_autocomplete\Plugin\ListingsProcessor;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\SubformStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\Url;
use Drupal\listings_filter\Entity\ListingsParagraphInterface;
use Drupal\listings_filter\ListingsProcessorBase;
use Drupal\search_api\Query\QueryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Suggests a listing's content under its keyword search as the visitor types.
 *
 * Suggestions are the listing's own content, so they keep to its prefilters,
 * including those editors choose where it is placed. They are requested from
 * the listing's suggestions endpoint, which runs the listing's query matching
 * only the chosen fields and showing each item as a link.
 *
 * @see \Drupal\listings_filter_autocomplete\Controller\Suggestions
 * @see \Drupal\listings_filter_autocomplete\EventSubscriber\AutocompleteSubscriber
 *
 * @ListingsProcessor(
 *   id = "listings_autocomplete",
 *   name = @Translation("Autocomplete"),
 *   description = @Translation("Suggests content from this listing under its keyword search as the visitor types. Needs the keyword search."),
 *   stages = {
 *     "preprocess_listing_query_settings" = 0,
 *     "alter_query" = 0,
 *   }
 * )
 */
class Autocomplete extends ListingsProcessorBase implements ContainerFactoryPluginInterface {

  use StringTranslationTrait;

  /**
   * Settings used until the listing is configured.
   */
  const DEFAULTS = [
    'fields' => [],
    'count' => 8,
    'min_chars' => 3,
    'on_select' => 'page',
    'typos' => FALSE,
  ];

  /**
   * The listing settings key marking a request for suggestions.
   */
  const SUGGESTIONS = 'listings_autocomplete_suggestions';

  /**
   * Tags the queries run for suggestions.
   */
  const TAG = 'listings_filter_autocomplete';

  /**
   * The query option asking for typos to be allowed for.
   */
  const TYPOS_OPTION = 'listings_filter_autocomplete_typos';

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configFactory;

  /**
   * Constructs an Autocomplete processor.
   *
   * @param array $configuration
   *   The plugin configuration, which carries the listing paragraph.
   * @param string $plugin_id
   *   The plugin ID.
   * @param mixed $plugin_definition
   *   The plugin definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, EntityTypeManagerInterface $entityTypeManager, ConfigFactoryInterface $configFactory) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->entityTypeManager = $entityTypeManager;
    $this->configFactory = $configFactory;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('config.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $subform, SubformStateInterface $processorFormState): array {
    $settings = $this->configuration + self::DEFAULTS;
    $listing = $processorFormState->getCompleteFormState()->getFormObject()->getEntity();
    $index = $this->entityTypeManager->getStorage('search_api_index')->load($this->getIndexId($listing));

    $options = [];
    foreach ($index ? $index->getFulltextFields() : [] as $fieldId) {
      $field = $index->getField($fieldId);
      // Several fields can share a label, such as a title indexed twice.
      $args = ['@label' => $field->getLabel(), '@id' => $fieldId];
      // Solr's custom text types, such as "solr_text_custom:edge", say how
      // much of a word must be typed to match.
      $hint = match (substr(strrchr($field->getType(), ':') ?: '', 1)) {
        'edge' => $this->t('matches the start of words'),
        'edgestring' => $this->t('matches the start of the text'),
        'ngram' => $this->t('matches any part of words'),
        'ngramstring' => $this->t('matches any part of the text'),
        'phonetic' => $this->t('matches words that sound alike'),
        default => NULL,
      };
      $options[$fieldId] = $hint
        ? $this->t('@label (@id) - @hint', $args + ['@hint' => $hint])
        : $this->t('@label (@id)', $args);
    }

    $form['#element_validate'] = [[static::class, 'validateSettings']];
    $form['fields'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Fields to match'),
      '#description' => $this->t('Suggestions are content from this listing whose chosen fields contain what was typed. Short fields such as the title give the closest matches. Only fields that match the start of words find a word while it is still being typed.'),
      '#options' => $options,
      '#default_value' => array_intersect($settings['fields'], array_keys($options)),
    ];

    $missing = array_diff($settings['fields'], array_keys($options));
    if ($missing) {
      $form['fields']['#description'] = $this->t('These chosen fields are no longer in the search index and are ignored: %fields.', [
        '%fields' => implode(', ', $missing),
      ]);
    }

    $form['count'] = [
      '#type' => 'number',
      '#title' => $this->t('Number of suggestions'),
      '#description' => $this->t('Between 1 and 20.'),
      '#min' => 1,
      '#max' => 20,
      '#default_value' => $settings['count'],
    ];
    $form['min_chars'] = [
      '#type' => 'number',
      '#title' => $this->t('Characters typed before suggestions appear'),
      '#description' => $this->t('Between 2 and 5. Search indexes usually ignore single characters.'),
      '#min' => 2,
      '#max' => 5,
      '#default_value' => $settings['min_chars'],
    ];
    $form['on_select'] = [
      '#type' => 'radios',
      '#title' => $this->t('When a suggestion is chosen'),
      '#options' => [
        'page' => $this->t('Go to that content'),
        'search' => $this->t('Search for its title'),
      ],
      '#default_value' => $settings['on_select'],
    ];
    $form['typos'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Allow for typos'),
      '#description' => $this->t('When nothing matches exactly, suggest close matches instead, such as "climate" for "climte".'),
      '#default_value' => $settings['typos'],
    ];

    return $form;
  }

  /**
   * Stores the ticked fields as a list, and checks autocomplete can work.
   */
  public static function validateSettings(array &$element, FormStateInterface $form_state): void {
    $fields = array_values(array_filter($element['fields']['#value'] ?? []));
    $form_state->setValueForElement($element['fields'], $fields);

    if (!$form_state->getValue(['processors', 'listings_autocomplete', 'status'])) {
      return;
    }
    if (!$form_state->getValue('has_keyword')) {
      $form_state->setError($element, t('Autocomplete needs the keyword search: tick "Provide a keyword search", or turn off the Autocomplete processor.'));
    }
    if (!$fields) {
      $form_state->setError($element['fields'], t('Autocomplete needs at least one field to match.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function preprocessListingQuerySettings(array &$settings): void {
    $config = $this->configuration + self::DEFAULTS;
    $paragraph = $this->configuration['paragraph'] ?? NULL;
    // Only a placed listing has an endpoint to ask.
    if (!$paragraph || $paragraph->isNew() || !$config['fields']) {
      return;
    }

    $settings['autocomplete'] = [
      // Collecting the URL's cache metadata, rather than letting it bubble,
      // keeps it out of the listing API's JSON response.
      'endpoint' => Url::fromRoute('listings_filter_autocomplete.suggestions', [
        'paragraph' => $paragraph->id(),
      ])->toString(TRUE)->getGeneratedUrl(),
      'min_chars' => (int) $config['min_chars'],
      'on_select' => $config['on_select'],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function alterQuery(QueryInterface &$query, array $settings = []): void {
    // The listing's own searches are left alone.
    if (empty($settings[self::SUGGESTIONS])) {
      return;
    }

    $config = $this->configuration + self::DEFAULTS;
    // Fields since removed from the index are skipped; if none are left,
    // every field is matched rather than nothing.
    $fields = array_values(array_intersect($config['fields'], $query->getIndex()->getFulltextFields()));
    if ($fields) {
      $query->setFulltextFields($fields);
    }

    $query->addTag(self::TAG);
    if ($config['typos']) {
      $query->setOption(self::TYPOS_OPTION, TRUE);
    }
  }

  /**
   * Get the search index a listing uses.
   *
   * @param \Drupal\listings_filter\Entity\ListingsParagraphInterface $listing
   *   The listing being configured.
   *
   * @return string
   *   The index ID: the listing's override, if it has one, or the default.
   */
  protected function getIndexId(ListingsParagraphInterface $listing): string {
    return $listing->getProcessors()['override_index']['settings']['search_index']
      ?? $this->configFactory->get('listings_filter.settings')->get('index')
      ?? '';
  }

}
