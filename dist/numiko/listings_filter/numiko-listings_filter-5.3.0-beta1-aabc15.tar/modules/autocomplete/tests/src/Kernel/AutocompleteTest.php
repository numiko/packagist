<?php

namespace Drupal\Tests\listings_filter_autocomplete\Kernel;

use Drupal\Component\Serialization\Json;
use Drupal\node\Entity\Node;
use Drupal\node\NodeInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\paragraphs\ParagraphInterface;

/**
 * Test the Autocomplete processor and the suggestions it provides.
 *
 * @group listings_filter
 */
class AutocompleteTest extends ListingsFilterAutocompleteKernelTestBase {

  /**
   * A placed search listing.
   *
   * @var \Drupal\paragraphs\ParagraphInterface
   */
  protected ParagraphInterface $placedListing;

  /**
   * A page about bananas.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected NodeInterface $page;

  /**
   * An article about bananas.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected NodeInterface $article;

  /**
   * A page mentioning bananas only in its summary.
   *
   * @var \Drupal\node\NodeInterface
   */
  protected NodeInterface $mention;

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();
    \Drupal::service('theme_installer')->install(['stark']);
    $this->config('system.theme')->set('default', 'stark')->save();

    $this->placedListing = Paragraph::create(['type' => 'listing_slice']);
    $this->placedListing->save();

    // Lower case throughout, as the database backend in CI may match
    // case-sensitively.
    $this->page = Node::create(['type' => 'page', 'title' => 'banana bread', 'status' => TRUE]);
    $this->page->save();
    $this->article = Node::create(['type' => 'article', 'title' => 'banana split', 'status' => TRUE]);
    $this->article->save();
    $this->mention = Node::create([
      'type' => 'page',
      'title' => 'cherry pie',
      'field_summary' => 'better than banana',
      'status' => TRUE,
    ]);
    $this->mention->save();
    $this->indexItems('search_index');
  }

  /**
   * Render the placed search listing.
   *
   * @return array
   *   The render array, after rendering, so its attachments have bubbled.
   */
  protected function renderPlacedListing(): array {
    $build = $this->container->get('entity_type.manager')
      ->getViewBuilder('paragraph')
      ->view($this->placedListing);
    // Rendered directly, so the attachments and cache tags stay on $build.
    $this->container->get('renderer')->renderRoot($build);
    return $build;
  }

  /**
   * Get the frontend settings of the placed search listing.
   *
   * @return array
   *   The listing's drupalSettings.
   */
  protected function getListingSettings(): array {
    return $this->renderPlacedListing()['#attached']['drupalSettings']['listing'][$this->placedListing->id()];
  }

  /**
   * Get the decoded suggestions of the placed listing.
   *
   * @param string $keyword
   *   The keyword typed.
   *
   * @return array
   *   The response data, with `items` and `meta`.
   */
  protected function getSuggestions(string $keyword = 'banana'): array {
    $response = $this->callSuggestions($this->placedListing, ['fulltext' => $keyword]);
    $this->assertSame(200, $response->getStatusCode());
    return Json::decode($response->getContent());
  }

  /**
   * Get the IDs of the content suggested.
   *
   * @param string $keyword
   *   The keyword typed.
   *
   * @return string[]
   *   UUIDs of the suggested nodes.
   */
  protected function getSuggestedIds(string $keyword = 'banana'): array {
    return array_column($this->getSuggestions($keyword)['items'], 'id');
  }

  /**
   * Test that the settings reach the frontend.
   */
  public function testSettingsReachTheFrontend(): void {
    $this->enableAutocomplete(['min_chars' => 4, 'on_select' => 'search']);

    $this->assertSame([
      'endpoint' => '/api/listing/' . $this->placedListing->id() . '/suggestions',
      'min_chars' => 4,
      'on_select' => 'search',
    ], $this->getListingSettings()['autocomplete']);
  }

  /**
   * Test that a listing without the processor has no autocomplete.
   */
  public function testListingWithoutProcessorHasNoAutocomplete(): void {
    $this->assertArrayNotHasKey('autocomplete', $this->getListingSettings());
    $this->assertSame(404, $this->callSuggestions($this->placedListing, ['fulltext' => 'banana'])->getStatusCode());
  }

  /**
   * Test that changing the listing updates pages already rendered.
   */
  public function testRenderedListingDependsOnTheListingSettings(): void {
    $this->assertContains(
      'config:listings_filter.listings_paragraph.search_listing',
      $this->renderPlacedListing()['#cache']['tags']
    );
  }

  /**
   * Test that each suggestion is a link to its content.
   */
  public function testSuggestionsAreLinks(): void {
    $this->enableAutocomplete();

    $markup = array_column($this->getSuggestions()['items'], 'markup', 'id');
    $this->assertSame(1, preg_match('#^<a href="([^"]+)">(.*)</a>$#s', trim($markup[$this->page->uuid()]), $link));
    $this->assertSame($this->page->toUrl()->toString(), $link[1]);
    $this->assertSame('banana bread', trim(strip_tags($link[2])));
  }

  /**
   * Test that suggestions keep to the content the listing shows.
   */
  public function testSuggestionsKeepToTheListingsPrefilters(): void {
    $this->enableAutocomplete();
    $this->searchListing
      ->set('prefilter_values', ['type' => ['value' => ['article'], 'op' => 'IN']])
      ->save();

    $this->assertSame([$this->article->uuid()], $this->getSuggestedIds());
  }

  /**
   * Test that only the chosen fields are matched.
   */
  public function testOnlyChosenFieldsAreMatched(): void {
    $this->enableAutocomplete();
    $this->assertNotContains($this->mention->uuid(), $this->getSuggestedIds());

    $this->enableAutocomplete(['fields' => ['title', 'field_summary']]);
    $this->assertContains($this->mention->uuid(), $this->getSuggestedIds());
  }

  /**
   * Test that the listing's own search still matches every field.
   */
  public function testListingsOwnSearchIsUnchanged(): void {
    $this->enableAutocomplete();

    $response = $this->callListingFilterApi($this->placedListing, ['fulltext' => 'banana']);
    $this->assertUuidExistsInResponse($this->mention->uuid(), $response);
  }

  /**
   * Test that the number of suggestions is limited.
   */
  public function testNumberOfSuggestionsIsLimited(): void {
    $this->enableAutocomplete(['count' => 1]);

    $this->assertCount(1, $this->getSuggestions()['items']);
  }

  /**
   * Test that nothing is suggested until enough has been typed.
   */
  public function testShortKeywordSuggestsNothing(): void {
    $this->enableAutocomplete(['min_chars' => 4]);
    $this->assertSame([], $this->getSuggestedIds('pie'));

    $this->enableAutocomplete(['min_chars' => 3]);
    $this->assertSame([$this->mention->uuid()], $this->getSuggestedIds('pie'));
  }

  /**
   * Test that an unpublished listing suggests nothing.
   */
  public function testUnpublishedListingIsNotAvailable(): void {
    $this->enableAutocomplete();
    $this->placedListing->setUnpublished()->save();

    $this->assertSame(403, $this->callSuggestions($this->placedListing, ['fulltext' => 'banana'])->getStatusCode());
  }

  /**
   * Test that a search finding nothing is retried when typos are allowed.
   *
   * The database backend used here has no typo matching, so the retry
   * matches any word; Solr also allows for typos.
   */
  public function testTyposRetryWhenNothingMatches(): void {
    $this->enableAutocomplete();
    $this->assertSame([], $this->getSuggestedIds('banana zzzz'));

    $this->enableAutocomplete(['typos' => TRUE]);
    $this->assertEqualsCanonicalizing(
      [$this->page->uuid(), $this->article->uuid()],
      $this->getSuggestedIds('banana zzzz')
    );
  }

  /**
   * Test that cached suggestions vary by keyword and follow the listing.
   */
  public function testCacheVariesByKeyword(): void {
    $this->enableAutocomplete();
    $response = $this->callSuggestions($this->placedListing, ['fulltext' => 'banana']);
    $cacheability = $response->getCacheableMetadata();

    $this->assertContains('url.query_args:fulltext', $cacheability->getCacheContexts());
    $this->assertContains('config:listings_filter.listings_paragraph.search_listing', $cacheability->getCacheTags());
    $this->assertContains('paragraph:' . $this->placedListing->id(), $cacheability->getCacheTags());
  }

}
