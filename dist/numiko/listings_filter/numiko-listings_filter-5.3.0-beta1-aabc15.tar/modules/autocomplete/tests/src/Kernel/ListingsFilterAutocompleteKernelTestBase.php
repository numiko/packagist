<?php

namespace Drupal\Tests\listings_filter_autocomplete\Kernel;

use Drupal\Component\Utility\UrlHelper;
use Drupal\Tests\listings_filter\Kernel\ListingsFilterKernelTestBase;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\listings_filter\Entity\ListingsParagraphInterface;
use Drupal\paragraphs\ParagraphInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Base class for listings filter autocomplete kernel tests.
 *
 * Sets up a listing with a keyword search over titles and summaries, for
 * pages and articles.
 */
abstract class ListingsFilterAutocompleteKernelTestBase extends ListingsFilterKernelTestBase {

  /**
   * Modules to enable for this test.
   *
   * @var string[]
   */
  protected static $modules = [
    'listings_filter_autocomplete',
  ];

  /**
   * The listing with the keyword search.
   *
   * @var \Drupal\listings_filter\Entity\ListingsParagraphInterface
   */
  protected ListingsParagraphInterface $searchListing;

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();

    $this->createNodeType('article');
    FieldStorageConfig::create([
      'field_name' => 'field_summary',
      'entity_type' => 'node',
      'type' => 'string',
    ])->save();
    foreach (['page', 'article'] as $bundle) {
      FieldConfig::create([
        'field_name' => 'field_summary',
        'entity_type' => 'node',
        'bundle' => $bundle,
      ])->save();
    }

    $index = $this->container->get('entity_type.manager')->getStorage('search_api_index')->load('search_index');
    $index->addField($this->createSearchIndexField($index, 'title', 'text'));
    $index->addField($this->createSearchIndexField($index, 'field_summary', 'text'));
    $index->addField($this->createSearchIndexField($index, 'type', 'string'));
    $index->save();

    $this->searchListing = $this->createListingsParagraphEntity([
      'id' => 'search_listing',
      'label' => 'Search listing',
      'paragraph_type_id' => 'listing_slice',
      'has_keyword' => TRUE,
    ]);
  }

  /**
   * Turn on autocomplete for the search listing.
   *
   * @param array $settings
   *   Overrides for the Autocomplete processor settings.
   */
  protected function enableAutocomplete(array $settings = []): void {
    $this->searchListing
      ->setProcessors([
        'listings_autocomplete' => [
          'status' => 1,
          'settings' => $settings + [
            'fields' => ['title'],
            'count' => 8,
            'min_chars' => 3,
            'on_select' => 'page',
            'typos' => FALSE,
          ],
        ],
      ])
      ->save();
  }

  /**
   * Request a placed listing's suggestions.
   *
   * @param \Drupal\paragraphs\ParagraphInterface $paragraph
   *   The placed listing.
   * @param array $params
   *   Query parameters, such as `fulltext`.
   *
   * @return \Symfony\Component\HttpFoundation\Response
   *   The response.
   */
  protected function callSuggestions(ParagraphInterface $paragraph, array $params = []): Response {
    $request = Request::create('/api/listing/' . $paragraph->id() . '/suggestions?' . UrlHelper::buildQuery($params));
    return $this->container->get('http_kernel')->handle($request);
  }

}
