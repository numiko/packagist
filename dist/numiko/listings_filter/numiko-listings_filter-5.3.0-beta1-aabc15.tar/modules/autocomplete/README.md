# Listings Filter Autocomplete

Suggests a listing's content under its keyword search as the visitor types.

Suggestions are the listing's own content, so they keep to its prefilter values and to the prefilter fields editors set where it is placed, such as a category. An article listing only suggests articles.

## Setup

On the edit form of a listing with **Provide a keyword search** ticked, enable the **Autocomplete** processor and choose:

- **Fields to match**: the search index text fields compared with what was typed. Short fields such as the title give the closest matches. Fields that match the start of words, such as Solr's `Fulltext "edge"` type, find a word while it is still being typed; others only match whole words, so include at least one of the first kind;
- **Number of suggestions**: 1 to 20;
- **Characters typed before suggestions appear**: 2 to 5;
- **When a suggestion is chosen**: go to that content, or search for its title;
- **Allow for typos**: when nothing matches exactly, suggest close matches instead, such as "climate" for "climte".

The form refuses to save the processor without the keyword search or without a field to match. Listing edit forms need the **Administer site configuration** permission, so only site builders can change these settings.

## Suggestions endpoint

```
GET /api/listing/{paragraph}/suggestions?fulltext=<keyword>
```

Runs the placed listing's own query with the processor's settings, returning the listing API's shape: `items`, each rendered in the **Search suggestion** display mode, and `meta.count`. Facets are not built. Processors deciding which content is found still apply; those adding to the response, such as alternatives when nothing is found, do not.

- A listing without the Autocomplete processor answers "not found".
- A paragraph the visitor cannot view, such as one on an unpublished page, answers "access denied".
- A keyword shorter than the processor's minimum returns nothing, without searching.
- With **Allow for typos**, a search finding nothing is run again. On Solr this uses the `fuzzy_terms` parse mode, so every word must still match, each allowing a typo. Other backends without typo matching match any word instead.

Responses vary by `fulltext` and are cleared when the listing's settings or the placed paragraph change. Pages showing a listing are cleared when the listing's settings change.

## Frontend

The processor adds this to the listing's `drupalSettings.listing[paragraph_id]`:

```json
"autocomplete": {
  "endpoint": "/api/listing/40/suggestions",
  "min_chars": 3,
  "on_select": "page"
}
```

The frontend adds `?fulltext=<keyword>` to the endpoint and reads each item's link text and address from its markup. Without these settings the keyword search behaves as before.

## Search suggestion display mode

The module provides a **Search suggestion** node view mode and a template rendering just a link, `node--search-suggestion.html.twig`. Copy the template into the theme to change how suggestions look, keeping a single link with the title as its text.

Enable the view mode for each content type that can be suggested, with no fields shown. Without its own display a content type falls back to its default display, which builds every field for a suggestion that only shows the title.

## Keeping CMS changes through deployments

The settings are stored in the listing's config, under `processors.listings_autocomplete`. To let site builders change them on a live site without the next deployment undoing it, ignore that key on import with config_ignore's advanced mode:

```yaml
mode: advanced
ignored_config_entities:
  create:
    import: {  }
    export: {  }
  update:
    import:
      - 'listings_filter.listings_paragraph.*:processors.listings_autocomplete'
    export: {  }
  delete:
    import:
      - 'listings_filter.listings_paragraph.*:processors.listings_autocomplete'
    export: {  }
```

Ignoring only **update** and **delete** on import means:

- the first deployment turning autocomplete on for a listing still does so, as does a deployment of a new listing with it on;
- after that, changes made on the site are kept, as is autocomplete turned on there;
- `drush cex` still exports local changes.

Two limits to be aware of:

- A listing's disabled processors are removed from its config. So if autocomplete is turned off on a site while it is still on in code, the next deployment turns it back on. Turn it off in code as well.
- config_ignore is not applied by `drush config:import --partial`, so a partial import overwrites the settings. `drush config:import` and `drush deploy` apply it.

The simple mode pattern `listings_filter.listings_paragraph.*:processors.listings_autocomplete` is not enough: it also ignores creating the key, so autocomplete would never be deployed to an existing listing, and it stops local changes being exported.
