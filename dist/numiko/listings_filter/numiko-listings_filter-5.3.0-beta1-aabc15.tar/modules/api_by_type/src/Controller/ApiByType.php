<?php

declare(strict_types=1);

namespace Drupal\listings_filter_api_by_type\Controller;

use Drupal\Core\Cache\CacheableJsonResponse;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Http\Exception\CacheableBadRequestHttpException;
use Drupal\Core\Http\Exception\CacheableNotFoundHttpException;
use Drupal\listings_filter\ContentListing;
use Drupal\listings_filter\Entity\ListingsParagraph;
use Drupal\listings_filter\ListingQueryManager;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\search_api\SearchApiException;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

/**
 * The listing API endpoint, resolved by listings_paragraph machine name.
 *
 * Accepts the machine name of a listings_paragraph config entity in place of a
 * paragraph instance ID. A transient paragraph is created so that the existing
 * ContentListing service can be used without modification.
 *
 * Per-instance state (e.g. custom facet selection) is not available via this
 * route; the default values for the paragraph type are used instead.
 *
 * Usage: /api/listing/type/{machine_name}
 * e.g.   /api/listing/type/article_filter
 *
 * Ported from SMG's listings_filter_whats_on module, with the cache contexts
 * widened to match the standard listings_filter API endpoint.
 */
class ApiByType extends ControllerBase {

  public function __construct(
    protected ContentListing $contentListing,
    protected ListingQueryManager $listingQueryManager,
    protected Request $request,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    return new static(
      $container->get('listings_filter.settings'),
      $container->get('plugin.manager.listing_query'),
      $container->get('request_stack')->getCurrentRequest(),
    );
  }

  /**
   * Runs a listing query for a paragraph type's defaults and returns JSON.
   *
   * Where the standard listing endpoint uses a real paragraph instance, this
   * endpoint creates a transient in-memory paragraph from the
   * listings_paragraph config entity's machine name, and uses it to resolve
   * the listing with its default facets and filters.
   *
   * Query parameters are carried over from the default listings_filter API.
   *
   * @param \Drupal\listings_filter\Entity\ListingsParagraph $listings_paragraph
   *   The listings_paragraph config entity, resolved from the machine name.
   *
   * @see \Drupal\listings_filter\Controller\Api
   */
  public function get(ListingsParagraph $listings_paragraph): CacheableJsonResponse {
    $cacheability = $this->getCacheDependencies();

    // Exposure is opt-in per listing type (or globally via the expose_all
    // development override). Unexposed listings 404 rather than 403 so the
    // route does not reveal which listing machine names exist.
    $moduleSettings = $this->config('listings_filter_api_by_type.settings');
    $cacheability->addCacheableDependency($moduleSettings);
    $cacheability->addCacheableDependency($listings_paragraph);
    $exposed = $listings_paragraph->getThirdPartySetting('listings_filter_api_by_type', 'expose_endpoint', FALSE)
      || $moduleSettings->get('expose_all');
    if (!$exposed) {
      throw new CacheableNotFoundHttpException($cacheability, 'Not found.');
    }

    $allowedBundles = $this->config('listings_filter.settings')->get('paragraph_types');
    if (!in_array($listings_paragraph->getParagraphTypeId(), $allowedBundles)) {
      throw new CacheableBadRequestHttpException($cacheability, 'The listing filter settings were not found.');
    }

    // Create a transient paragraph so the existing service can be used without
    // modification. Default field values (facets etc.) are applied by Drupal
    // on create. The paragraph is never saved.
    $paragraph = Paragraph::create(['type' => $listings_paragraph->getParagraphTypeId()]);

    $settings = $this->contentListing->buildListingQuerySettings($listings_paragraph, $paragraph);
    if (empty($settings)) {
      throw new CacheableBadRequestHttpException($cacheability, 'The listing filter settings were not found.');
    }

    // Use the machine name as paragraph_id so callers can identify the source.
    $settings['paragraph_id'] = $listings_paragraph->id();

    /** @var \Drupal\search_api\IndexInterface $index */
    $index = $this->entityTypeManager()->getStorage('search_api_index')->load($settings['search_index']);
    $listingQuery = $this->listingQueryManager->getListingQuery($index->getServerInstance()->getBackendId());
    $cacheability = $cacheability->merge($listingQuery->getCacheDependencies($settings));

    try {
      $data = $listingQuery->getResults($settings, $this->request->query->all());
    }
    catch (SearchApiException $exception) {
      throw new CacheableBadRequestHttpException($cacheability, $exception->getMessage());
    }

    $response = new CacheableJsonResponse($data);
    $response->addCacheableDependency($cacheability);
    return $response;
  }

  /**
   * Gets the base cache metadata: one context per supported query parameter.
   *
   * Matches the standard listings_filter API endpoint's contexts.
   */
  private function getCacheDependencies(): CacheableMetadata {
    $metadata = new CacheableMetadata();
    $metadata->addCacheContexts([
      'url.query_args:page',
      'url.query_args:filter',
      'url.query_args:filter-group',
      'url.query_args:sort',
      'url.query_args:fulltext',
      'url.query_args:language',
      'url.query_args:count',
      'url.query_args:display_mode',
    ]);
    return $metadata;
  }

}
