# Listings Filter API by Type

Extends `listings_filter` with a second listing API endpoint optionally resolved by listing type's **machine name** rather than a placed paragraph ID:

```
GET /api/listing/type/{listings_paragraph machine name}
```

A transient (never saved) paragraph of the listing's paragraph type is created per request, so the type's **default field values** apply. Per-instance editorial choices on placed paragraphs are not, and cannot be, reflected here. All standard `listings_filter` query parameters work (`page`, `fulltext`, `filter[...]`, `sort[...]`, `count`, `display_mode`).

## Why

- **External consumers** (e.g. museum displays) get a stable URL that does not depend on an ID which could change when content is rebuilt.
- **Developers** can query and test a listing type before any paragraph has been placed - no need to create content or hunt for IDs to work on the API.

## Exposure is opt-in

By default *no* listing is exposed, and the endpoint returns 404, indistinguishable from a nonexistent machine name.

Two ways to expose:

1. **Per listing** (for external consumers): tick *"Use default settings to provide a stable endpoint for this listing"* on the listing type's edit form at `/admin/structure/listings_paragraph`. This is stored as a third-party setting on the `listings_paragraph` config entity.
2. **Everything at once** (for development): set `expose_all` in `listings_filter_api_by_type.settings`, e.g. in `settings.local.php`:

   ```php
   // Expose all listing types on /api/listing/type/{machine_name}.
   if (PHP_SAPI !== 'cli') {
     $config['listings_filter_api_by_type.settings']['expose_all'] = TRUE;
   }
   ```

**Note:** The CLI guard in the example above allows *phpunit* to test, locally, that unexposed listings do indeed return a 404, under normal conditions. Without it, the opt-in test fails unconditionally, and loses all meaning.
