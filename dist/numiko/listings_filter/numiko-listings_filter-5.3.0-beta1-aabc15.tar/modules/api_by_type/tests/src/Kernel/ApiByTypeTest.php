<?php

namespace Drupal\Tests\listings_filter_api_by_type\Kernel;

use Drupal\Component\Serialization\Json;
use Drupal\Tests\listings_filter\Kernel\ListingsFilterKernelTestBase;
use Drupal\listings_filter\Entity\ListingsParagraph;
use Drupal\node\Entity\Node;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test the by-type listing API endpoint.
 *
 * @group listings_filter
 */
class ApiByTypeTest extends ListingsFilterKernelTestBase {

  /**
   * Modules to enable for this test.
   *
   * @var string[]
   */
  protected static $modules = [
    'listings_filter_api_by_type',
  ];

  /**
   * The listing these tests resolve by machine name.
   *
   * @var \Drupal\listings_filter\Entity\ListingsParagraph
   */
  protected ListingsParagraph $listing;

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();
    $this->installConfig(['listings_filter_api_by_type']);

    $this->listing = $this->createListingsParagraphEntity([
      'id' => 'by_type_listing',
      'label' => 'By type listing',
      'paragraph_type_id' => 'listing_slice',
    ]);
  }

  /**
   * Test exposure is opt-in: a listing 404s until the flag is set.
   */
  public function testExposureIsOptIn(): void {
    $response = $this->callListingFilterApiByType('by_type_listing');
    $this->assertEquals(Response::HTTP_NOT_FOUND, $response->getStatusCode());
  }

  /**
   * Test an exposed listing resolves from its machine name alone.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testResolvesExposedListingByMachineName(): void {
    $this->exposeListing();

    $node = Node::create([
      'title' => 'Indexed page',
      'type' => 'page',
      'status' => TRUE,
    ]);
    $node->save();
    $this->indexItems('search_index');

    $response = $this->callListingFilterApiByType('by_type_listing');
    $this->assertEquals(Response::HTTP_OK, $response->getStatusCode());
    $this->assertUuidExistsInResponse($node->uuid(), $response);

    $data = Json::decode($response->getContent());
    $this->assertArrayHasKey('facets', $data['meta']);
  }

  /**
   * Test the expose_all development override exposes unflagged listings.
   */
  public function testExposeAllOverride(): void {
    $this->config('listings_filter_api_by_type.settings')
      ->set('expose_all', TRUE)
      ->save();

    $response = $this->callListingFilterApiByType('by_type_listing');
    $this->assertEquals(Response::HTTP_OK, $response->getStatusCode());
  }

  /**
   * Test an unknown machine name 404s, indistinguishable from unexposed.
   */
  public function testUnknownMachineNameNotFound(): void {
    $response = $this->callListingFilterApiByType('not_a_real_listing');
    $this->assertEquals(Response::HTTP_NOT_FOUND, $response->getStatusCode());
  }

  /**
   * Sets the exposure flag on the test listing.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function exposeListing(): void {
    $this->listing
      ->setThirdPartySetting('listings_filter_api_by_type', 'expose_endpoint', TRUE)
      ->save();
  }

}
