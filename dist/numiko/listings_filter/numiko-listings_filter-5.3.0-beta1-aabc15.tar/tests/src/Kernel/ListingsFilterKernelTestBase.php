<?php

namespace Drupal\Tests\listings_filter\Kernel;

use Drupal\Core\Datetime\DateFormatInterface;
use Drupal\Core\Datetime\Entity\DateFormat;
use Drupal\KernelTests\KernelTestBase;
use Drupal\Tests\listings_filter\Traits\ListingsFilterApiTrait;
use Drupal\Tests\paragraphs\FunctionalJavascript\ParagraphsTestBaseTrait;
use Drupal\facets\Entity\Facet;
use Drupal\facets\FacetInterface;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\field\FieldConfigInterface;
use Drupal\listings_filter\Entity\ListingsParagraph;
use Drupal\listings_filter\Entity\ListingsParagraphInterface;
use Drupal\node\Entity\NodeType;
use Drupal\node\NodeTypeInterface;
use Drupal\search_api\Entity\Index;
use Drupal\search_api\Entity\Server;
use Drupal\search_api\IndexInterface;
use Drupal\search_api\Item\Field;
use Drupal\search_api\Item\FieldInterface;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\taxonomy\VocabularyInterface;
use Drupal\user\Entity\User;
use Drupal\user\UserInterface;

/**
 * Base class for listings filter kernel tests.
 *
 * Provides the module list, schema installation and fixture helpers shared by
 * the listings filter tests and those of its submodules.
 */
abstract class ListingsFilterKernelTestBase extends KernelTestBase {

  use ListingsFilterApiTrait, ParagraphsTestBaseTrait;

  /**
   * Modules to enable for this test.
   *
   * @var string[]
   */
  protected static $modules = [
    'node',
    'user',
    'datetime',
    'system',
    'field',
    'entity_reference_revisions',
    'search_api',
    'search_api_db',
    'search_api_test',
    'facets',
    'paragraphs',
    'file',
    'path_alias',
    'listings_filter',
    'taxonomy',
    'filter',
    'text',
    'listings_filter_test_processors',
  ];

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();
    $this->installSchema('system', ['sequences']);
    $this->installSchema('node', ['node_access']);
    $this->installSchema('search_api', ['search_api_item']);

    $this->installEntitySchema('user');
    $this->installEntitySchema('node');
    $this->installEntitySchema('paragraph');
    $this->installEntitySchema('path_alias');
    $this->installEntitySchema('listings_paragraph');
    $this->installEntitySchema('facets_facet');
    $this->installEntitySchema('date_format');
    $this->installEntitySchema('taxonomy_term');
    $this->installEntitySchema('search_api_task');

    $this->installConfig([
      'filter',
      'field',
      'listings_filter',
      'search_api',
    ]);

    // Context error given if a user does not exist in the DB.
    $this->createAnonymousUser();
    // Error thrown when rendering teasers if no date format set.
    $this->createDateFormat();

    // Create tags vocab.
    $this->createVocabulary('tags');
    // Create a new content type.
    $this->createNodeType('page');
    // Add a tags field to node.
    $this->createEntityReferenceField('node', 'page', 'field_tags', 'taxonomy_term', ['tags' => 'tags']);
    // Add paragraphs field to node type.
    $this->addParagraphsField('page', 'field_paragraphs', 'node');

    // Create a new paragraph slice for the listing.
    $this->addParagraphsType('listing_slice');
    // Add tags field to listing slice.
    $this->createEntityReferenceField('paragraph', 'listing_slice', 'field_tags', 'taxonomy_term', ['tags' => 'tags']);
    // Add promoted field to listing slice.
    $this->createEntityReferenceField('paragraph', 'listing_slice', 'field_promoted', 'node', ['page' => 'page']);
    // Add facets field to listing slice.
    $this->createEntityReferenceField('paragraph', 'listing_slice', 'field_facets', 'facets_facet', []);

    // Create search server and index.
    $index = $this->createSearchIndex();
    // Add fields to the search index.
    $index->addField($this->createSearchIndexField($index, 'created', 'date'));
    $index->addField($this->createSearchIndexField($index, 'field_tags', 'integer'));
    $index->addField($this->createSearchIndexField($index, 'uuid', 'string'));
    $index->save();

    // Create facets.
    $this->createFacet('tags', 'field_tags');

    // Add the new slice as a slice in the listing settings and the new index.
    \Drupal::configFactory()
      ->getEditable('listings_filter.settings')
      ->set('paragraph_types', ['listing_slice'])
      ->set('index', 'search_index')
      ->save();
  }

  /**
   * Creates an anonymous user.
   *
   * @return \Drupal\user\UserInterface
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function createAnonymousUser(): UserInterface {
    $user = User::create([
      'name' => 'anonymous',
      'uid' => 0,
    ]);
    $user->save();

    return $user;
  }

  /**
   * Creates a date format.
   *
   * @return \Drupal\Core\Datetime\DateFormatInterface
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function createDateFormat(): DateFormatInterface {
    $dateFormat = DateFormat::create([
      'id' => 'fallback',
      'label' => 'Fallback',
      'pattern' => 'Y-m-d',
    ]);
    $dateFormat->save();

    return $dateFormat;
  }

  /**
   * Creates a vocabulary.
   *
   * @param string $id
   *   The vid.
   *
   * @return \Drupal\taxonomy\VocabularyInterface
   *   The vocabulary.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function createVocabulary(string $id): VocabularyInterface {
    $vocabulary = Vocabulary::create([
      'name' => $id,
      'vid' => $id,
    ]);
    $vocabulary->save();

    return $vocabulary;
  }

  /**
   * Creates a node content type.
   *
   * @param string $id
   *   The id of the content type.
   *
   * @return \Drupal\node\NodeTypeInterface
   *   The created content type.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function createNodeType(string $id): NodeTypeInterface {
    $nodeType = NodeType::create([
      'type' => $id,
      'name' => $id,
    ]);
    $nodeType->save();

    return $nodeType;
  }

  /**
   * Creates an entity reference field.
   *
   * @param string $entityType
   *   The entity type.
   * @param string $bundle
   *   The bundle.
   * @param string $fieldName
   *   The field name.
   * @param string $targetType
   *   The target type.
   * @param array $targetBundles
   *   The target bundles.
   *
   * @return \Drupal\field\FieldConfigInterface
   *   The created field.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function createEntityReferenceField(string $entityType, string $bundle, string $fieldName, string $targetType, array $targetBundles): FieldConfigInterface {
    $fieldStorage = FieldStorageConfig::create([
      'field_name' => $fieldName,
      'entity_type' => $entityType,
      'type' => 'entity_reference',
      'cardinality' => '-1',
      'settings' => [
        'target_type' => $targetType,
      ],
    ]);
    $fieldStorage->save();

    $field = FieldConfig::create([
      'field_storage' => $fieldStorage,
      'entity_type' => $entityType,
      'bundle' => $bundle,
      'settings' => [
        'handler' => 'default',
        'handler_settings' => [
          'target_bundles' => $targetBundles,
        ],
      ],
    ]);
    $field->save();

    return $field;
  }

  /**
   * Creates a search server and index.
   *
   * @return \Drupal\search_api\IndexInterface
   *   The created index.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function createSearchIndex(): IndexInterface {
    $server = Server::create([
      'id' => 'server',
      'name' => 'Server',
      'status' => TRUE,
      'backend' => 'search_api_db',
      'backend_config' => [
        'database' => 'default:default',
      ],
    ]);
    $server->save();

    $index = Index::create([
      'id' => 'search_index',
      'name' => 'Index',
      'status' => TRUE,
      'datasource_settings' => [
        'entity:node' => [],
      ],
      'server' => 'server',
      'tracker_settings' => [
        'default' => [],
      ],
    ]);
    $index->setServer($server);
    $index->save();

    return $index;
  }

  /**
   * Creates a field on the search index.
   *
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index.
   * @param string $fieldName
   *   The field name.
   * @param string $type
   *   The field type.
   *
   * @return \Drupal\search_api\Item\FieldInterface
   *   The new field.
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  protected function createSearchIndexField(IndexInterface $index, string $fieldName, string $type): FieldInterface {
    $field = new Field($index, $fieldName);
    $field->setType($type);
    $field->setPropertyPath($fieldName);
    $field->setDatasourceId('entity:node');
    $field->setLabel('Facet ' . $fieldName);
    return $field;
  }

  /**
   * Creates a facet.
   *
   * @param string $id
   *   The facet id.
   * @param string $field
   *   The field.
   *
   * @return \Drupal\facets\FacetInterface
   *   The created facet.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function createFacet(string $id, string $field): FacetInterface {
    $facet = Facet::create([
      'id' => $id,
      'name' => $id,
      'facet_source_id' => 'listing_filter_search_api_facets:search_index',
      'field_identifier' => $field,
      'url_alias' => $id,
      'empty_behavior' => ['behavior' => 'none'],
    ]);
    $facet->addProcessor([
      'processor_id' => 'url_processor_handler',
      'settings' => [],
      'weights' => ['pre_query' => -10, 'build' => -10],
    ]);
    $facet->setWidget('listings_filter');
    $facet->save();

    $source = $facet->getFacetSourceConfig();
    $source->setUrlProcessor('listings_filter');
    $source->save();

    return $facet;
  }

  /**
   * Creates a ListingsParagraph entity.
   *
   * @param array $values
   *   The values to add.
   *
   * @return \Drupal\listings_filter\Entity\ListingsParagraphInterface
   *   The created ListingsParagraph entity.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  protected function createListingsParagraphEntity(array $values = []): ListingsParagraphInterface {
    $values += [
      'prefilter_fields' => [],
      'display_mode' => 'teaser',
    ];

    $listingSlice = ListingsParagraph::create($values);
    $listingSlice->save();

    return $listingSlice;
  }

  /**
   * Indexes all items on the specified index.
   *
   * @param string $index_id
   *   The ID of the index on which items should be indexed.
   *
   * @return int
   *   The number of successfully indexed items.
   */
  protected function indexItems(string $index_id): int {
    /** @var \Drupal\search_api\IndexInterface $index */
    $index = Index::load($index_id);
    return $index->indexItems();
  }

}
