<?php

namespace Drupal\listings_filter;

use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Class ParagraphFormAmends.
 *
 * Method used to restrict listing paragraph
 * facet options in the paragraph node form.
 *
 *
 * @package Drupal\listings_filter
 */
class ParagraphFormAmends {

  const JSON_API_INDEX = 'site';
  const JSON_API_CONTENT_DATASOURCE = 'entity:node';
  const JSON_API_FACET_SOURCE_ID = 'jsonapi_search_api_facets:site';

  /**
   * The Entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * The Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The listings_filter service.
   *
   * @var \Drupal\listings_filter\ContentListing
   */
  protected $contentListing;

  /**
   * ParagraphFormAmends constructor.
   *
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entity_field_manager
   *   The Entity field manager.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The Entity type manager.
   * @param \Drupal\listings_filter\ContentListing $content_listing
   *   The listings_filter service.
   */
  public function __construct(EntityFieldManagerInterface $entity_field_manager,
                              EntityTypeManagerInterface $entity_type_manager,
                              ContentListing $content_listing) {
    $this->entityFieldManager = $entity_field_manager;
    $this->entityTypeManager = $entity_type_manager;
    $this->contentListing = $content_listing;
  }

  /**
   * Set field_facets options on listing paragraph slice form.
   *
   * Restricts options to the facets that could filter
   * content types that could appear in the results.
   * For example, the news content type, could not be filtered
   * by event type because it doesn't have the field defined.
   * Therefore the event type facet is removed as an option
   * from a news listing paragraph slice form.
   *
   * @param $element
   *   Paragraph form element.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function setFacetOptions(&$element) {
    $listingParagraph = $this->contentListing->getListingParagraphFromSliceType($element['#paragraph_type']);
    if (!isset($listingParagraph)) {
      return;
    }

    // Check that listing paragraph can have facets added.
    $facetField = $listingParagraph->getFacetsField();
    if (!isset($facetField)) {
      return;
    }

    // Get content types of any potential result.
    // Either any prefilter types, or any indexed types.
    $availableEntityTypes = $this->getResultsPotentialContentTypes($listingParagraph);

    // Build facet options.
    $availableFacets = ['_none' => '- None -'];
    foreach ($availableEntityTypes as $entityType) {
      $facetsAvailable = $this->getFacetsRelevantToContentType($entityType);
      if (isset($facetsAvailable)) {
        $availableFacets = array_merge($availableFacets, $facetsAvailable);
      }
    }

    // Set select options.
    $element['subform']['field_facets']['widget']['#options'] = $availableFacets;
  }

  /**
   * Get results' potential content types.
   *
   * Calculate potential content types of
   * results. Taking into account content
   * type prefilters and search_api content
   * data source.
   *
   * @param $listingParagraph
   *   Listing paragraph for which to calculate content types.
   *
   * @return array
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  protected function getResultsPotentialContentTypes($listingParagraph) {
    $entityTypePrefilters = $this->contentListing->getListingParagraphContentTypePrefilters($listingParagraph);
    // If content type prefilters are set, return them.
    // Otherwise load all content types indexed on the datasource.
    if (empty($entityTypePrefilters)) {
      $site = $this->entityTypeManager->getStorage('search_api_index')->load(self::JSON_API_INDEX);
      $siteContentBundleSettings = $site->get('datasource_settings')[self::JSON_API_CONTENT_DATASOURCE]['bundles'];
      // If default is set, exclude selected from all content types.
      // Otherwise include selected content types.
      if ($siteContentBundleSettings['default']) {
        $datasourceContentTypes = $site->getDatasource(self::JSON_API_CONTENT_DATASOURCE)->getEntityTypeBundleInfo()->getBundleInfo('node');
        foreach ($siteContentBundleSettings['selected'] as $selection) {
          if (isset($datasourceContentTypes[$selection])) {
            unset($datasourceContentTypes[$selection]);
          }
        }
        return array_keys($datasourceContentTypes);
      }
      else {
        return $siteContentBundleSettings['selected'];
      }
    }
    else {
      return $entityTypePrefilters;
    }
  }

  /**
   * Get facets relevant to content type.
   *
   * @param $contentType
   *   Content type.
   *
   * @return array
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  protected function getFacetsRelevantToContentType($contentType) {
    $jsonApiFacets = $this->entityTypeManager->getStorage('facets_facet')->loadByProperties(['facet_source_id' => self::JSON_API_FACET_SOURCE_ID]);
    $availableFacets = [];
    foreach ($jsonApiFacets as $jsonApiFacet) {
      $searchApiFieldIdentifier = $jsonApiFacet->toArray()['field_identifier'];
      $site = $this->entityTypeManager->getStorage('search_api_index')->load(self::JSON_API_INDEX);
      $fieldsSettings = $site->get('field_settings')[$searchApiFieldIdentifier];
      $fieldName = $fieldsSettings['property_path'];
      $fieldDefinitions = $this->entityFieldManager->getFieldDefinitions('node', $contentType);
      if (isset($fieldDefinitions[$fieldName])) {
        $availableFacets[$jsonApiFacet->id()] = $jsonApiFacet->label();
      }
    }
    return $availableFacets;
  }

}
