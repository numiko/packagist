<?php

namespace Drupal\listings_filter\Form;

use Drupal\Core\Entity\EntityForm;
use Drupal\search_api\Entity\Index;
use Drupal\Core\Form\FormStateInterface;
use Drupal\paragraphs\Entity\ParagraphsType;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\listings_filter\ListingsFieldProcessorManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class ListingsParagraphForm.
 */
class ListingsParagraphForm extends EntityForm {

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * The listings field processor manager.
   *
   * @var \Drupal\listings_filter\ListingsFieldProcessorManager
   */
  protected $listingsFieldProcessorManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->setEntityFieldManager($container->get('entity_field.manager'));
    $instance->setListingsFieldProcessorManager($container->get('plugin.manager.listings_field_processor'));
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);

    $listingsParagraph = $this->entity;
    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Label'),
      '#maxlength' => 255,
      '#default_value' => $listingsParagraph->label(),
      '#description' => $this->t("Label for the Listings paragraph."),
      '#required' => TRUE,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $listingsParagraph->id(),
      '#machine_name' => [
        'exists' => '\Drupal\listings_filter\Entity\ListingsParagraph::load',
      ],
      '#disabled' => !$listingsParagraph->isNew(),
    ];

    $listingParagraphTypes = ParagraphsType::loadMultiple(array_values(self::config('listings_filter.settings')->get('paragraph_types')));
    $options = array_map(function ($paragraph) {
      return $paragraph->label();
    }, $listingParagraphTypes);

    $form['paragraph_type_id'] = [
      '#type' => 'select',
      '#options' => $options,
      '#title' => $this->t('Paragraph type to map to'),
      '#description' => $this->t("If your paragraph type isn't showing then edit the listing paragraph settings."),
      '#default_value' => $listingsParagraph->getParagraphTypeId(),
      '#required' => TRUE,
      '#disabled' => ($listingsParagraph->getParagraphTypeId() && ParagraphsType::load($listingsParagraph->getParagraphTypeId())) ? TRUE : FALSE,
    ];

    // If the paragraph is new there is nothing more to do in the create stage.
    if ($listingsParagraph->isNew()) {
      return $form;
    }

    $fieldList = [];
    $bundleFields = $this->entityFieldManager->getFieldDefinitions('paragraph', $listingsParagraph->getParagraphTypeId());
    foreach ($bundleFields as $fieldName => $fieldDefinition) {
      if (!empty($fieldDefinition->getTargetBundle())) {
        $fieldList[$fieldName] = $fieldDefinition->getLabel();
      }
    }

    $searchApiFields = [];
    $indexes = Index::loadMultiple();

    foreach ($indexes as $index_id => $index) {
      $searchApiFields += array_map(function ($fieldDefinition) {
        return $fieldDefinition->getFieldIdentifier();
      }, $index->getFields());
    }

    $fieldsInUse = [];

    $form['facets_field'] = [
      '#type' => 'select',
      '#title' => 'Facets field',
      '#description' => 'Select the field that will hold the selected facets',
      '#empty_option' => '- Select paragraph field -',
      '#options' => $fieldList,
      '#default_value' => $listingsParagraph->getFacetsField(),
      '#required' => FALSE,
    ];
    $fieldsInUse[] = $listingsParagraph->getFacetsField();

    $form['pinned_items_field'] = [
      '#type' => 'select',
      '#title' => 'Pinned items field',
      '#description' => 'Select the field that will hold the pinned items',
      '#empty_option' => '- Select paragraph field -',
      '#options' => $fieldList,
      '#default_value' => $listingsParagraph->getPinnedItemsField(),
      '#required' => FALSE,
    ];
    $fieldsInUse[] = $listingsParagraph->getPinnedItemsField();

    $form['items_per_page_field'] = [
      '#type' => 'select',
      '#title' => "Items per page field",
      '#description' => "Select the field that will hold the items per page value",
      '#empty_option' => '- Select paragraph field -',
      '#options' => $fieldList,
      '#default_value' => $listingsParagraph->getItemsPerPageField(),
      '#required' => FALSE,
    ];
    $fieldsInUse[] = $listingsParagraph->getItemsPerPageField();

    $form['items_per_page_value'] = [
      '#type' => 'number',
      '#title' => "Items per page value",
      '#description' => "Or define the number of items to show per page",
      '#default_value' => $listingsParagraph->getItemsPerPageValue(),
      '#required' => FALSE,
    ];

    $form['result_count_field'] = [
      '#type' => 'select',
      '#title' => "Result count field",
      '#description' => "Select the field that will hold the limit to the number of results",
      '#empty_option' => '- Select paragraph field -',
      '#options' => $fieldList,
      '#default_value' => $listingsParagraph->getResultCountField(),
      '#required' => FALSE,
    ];
    $fieldsInUse[] = $listingsParagraph->getResultCountField();

    $form['result_count_value'] = [
      '#type' => 'number',
      '#title' => "Result count value",
      '#description' => "Or define the maximum number of results",
      '#default_value' => $listingsParagraph->getResultCountValue(),
      '#required' => FALSE,
    ];

    $form['has_keyword'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Provide a keyword search'),
      '#default_value' => $listingsParagraph->getHasKeyword(),
    ];

    /*
     * There are two methods of prefiltering:
     *
     * Using a defined prefilter field, which can then be selected by the CMS
     * user when setting up the paragraph on the content [prefilter_fields].
     *
     * Actually predefining the value on the listing paragraph configuration,
     * which CANNOT be altered by the CMS user (e.g. predefining content types
     * to return) [prefilter_values].
     */

    $processor_options = $this->listingsFieldProcessorManager->getProcessorOptions();

    $form['prefilter_fields'] = [
      '#type' => 'table',
      '#caption' => "Prefilter Fields",
      '#header' => [
        'Field label',
        'Field name',
        'Search Field',
        'Processor',
        '',
      ],
    ];

    $i = 0;
    foreach ($fieldList as $fieldName => $fieldLabel) {
      if (!in_array($fieldName, $fieldsInUse)) {
        $form['prefilter_fields'][$i]['label'] = [
          '#markup' => "<strong>{$fieldLabel}</strong>",
        ];
        $form['prefilter_fields'][$i]['name'] = [
          '#markup' => "{$fieldName}",
        ];
        $form['prefilter_fields'][$i]['search_key'] = [
          '#type' => 'select',
          '#empty_option' => '- Select search API field -',
          '#options' => $searchApiFields,
          '#default_value' => (isset($listingsParagraph->getPrefilterFields()[$fieldName]['search_key'])) ? $listingsParagraph->getPrefilterFields()[$fieldName]['search_key'] : NULL,
          '#required' => FALSE,
        ];
        $form['prefilter_fields'][$i]['processor'] = [
          '#type' => 'select',
          '#options' => $processor_options,
          '#default_value' => (isset($listingsParagraph->getPrefilterFields()[$fieldName]['processor'])) ? $listingsParagraph->getPrefilterFields()[$fieldName]['processor'] : NULL,
        ];
        $form['prefilter_fields'][$i]['field_name'] = [
          '#type' => 'hidden',
          '#default_value' => $fieldName,
        ];
        $i++;
      }
    }

    $prefilterValues = $this->flattenPrefilterValueArray($listingsParagraph->getPrefilterValues());

    if (!$form_state->get('prefilter_num')) {
      $form_state->set('prefilter_num', count($prefilterValues));
    }

    $form['prefilter_values'] = [
      '#type' => 'table',
      '#caption' => 'Add prefilter values',
      '#header' => ['Search field key', 'Prefilter value', 'Prefilter key'],
    ];

    for ($i = 0; $i < $form_state->get('prefilter_num'); $i++) {
      $form['prefilter_values'][$i]['search_key'] = [
        '#type' => 'select',
        '#title' => "Search field key",
        '#empty_option' => '- Select search field key -',
        '#options' => $searchApiFields,
        '#default_value' => (!empty($prefilterValues[$i]) && !empty($prefilterValues[$i]['search_key'])) ? $prefilterValues[$i]['search_key'] : '',
        '#required' => FALSE,
      ];
      $form['prefilter_values'][$i]['value'] = [
        '#type' => 'textfield',
        '#title' => "Value",
        '#default_value' => (!empty($prefilterValues[$i]) && !empty($prefilterValues[$i]['value'])) ? $prefilterValues[$i]['value'] : '',
        '#required' => FALSE,
      ];
      $default_key = !empty($prefilterValues[$i]) ? '' : 'target_id';
      $form['prefilter_values'][$i]['key'] = [
        '#type' => 'textfield',
        '#title' => "Value key",
        '#default_value' => (!empty($prefilterValues[$i]) && !empty($prefilterValues[$i]['key'])) ? $prefilterValues[$i]['key'] : $default_key,
        '#required' => FALSE,
      ];
    }

    // Button to add more rows.
    $form['add_prefilter'] = [
      '#type' => 'submit',
      '#attributes' => [
        'class' => [
          'button-action',
        ],
      ],
      '#value' => $this->t('Add prefilter value'),
    ];

    $sortValues = $listingsParagraph->getSortValues();

    if (!$form_state->get('sort_num')) {
      $form_state->set('sort_num', count($sortValues));
    }

    $form['sort_values'] = [
      '#type' => 'table',
      '#caption' => 'Add default sorts',
      '#header' => ['Search field key', 'Sort direction', 'Weight'],
    ];

    $sortSearchApiFields = array_merge($searchApiFields, ['search_api_relevance' => 'relevance']);
    for ($i = 0; $i < $form_state->get('sort_num'); $i++) {
      $form['sort_values'][$i]['search_key'] = [
        '#type' => 'select',
        '#title' => 'Search field key',
        '#empty_option' => '- Select search field key -',
        '#options' => $sortSearchApiFields,
        '#default_value' => (!empty($sortValues[$i]) && !empty($sortValues[$i]['search_key'])) ? $sortValues[$i]['search_key'] : '',
        '#required' => FALSE,
      ];
      $form['sort_values'][$i]['direction'] = [
        '#type' => 'select',
        '#title' => 'Sort direction',
        '#options' => [
          'asc' => 'Ascending',
          'desc' => 'Descending',
        ],
        '#default_value' => (!empty($sortValues[$i]) && !empty($sortValues[$i]['direction'])) ? $sortValues[$i]['direction'] : 'asc',
        '#required' => TRUE,
      ];
      $form['sort_values'][$i]['weighting'] = [
        '#type' => 'select',
        '#title' => 'Weight',
        '#options' => $this->getWeightingOptions($form_state->get('sort_num')),
        '#default_value' => (!empty($sortValues[$i]) && !empty($sortValues[$i]['weighting'])) ? $sortValues[$i]['weighting'] : 0,
        '#required' => TRUE,
      ];
    }

    // Button to add more rows.
    $form['add_sort'] = [
      '#type' => 'submit',
      '#attributes' => [
        'class' => [
          'button-action',
        ],
      ],
      '#value' => $this->t('Add default sort'),
    ];

    $userSortValues = $listingsParagraph->getUserSortValues();

    if (!$form_state->get('user_sort_num')) {
      $form_state->set('user_sort_num', count($userSortValues));
    }

    $form['user_sort_values'] = [
      '#type' => 'table',
      '#caption' => 'Add user-facing sorts',
      '#header' => ['Label', 'Search field key', 'Sort direction', 'Weight'],
    ];

    $sortSearchApiFields = array_merge($searchApiFields, ['search_api_relevance' => 'relevance']);
    for ($i = 0; $i < $form_state->get('user_sort_num'); $i++) {
      $form['user_sort_values'][$i]['label'] = [
        '#type' => 'textfield',
        '#title' => 'Label',
        '#default_value' => (!empty($userSortValues[$i]) && !empty($userSortValues[$i]['label'])) ? $userSortValues[$i]['label'] : '',
        '#required' => TRUE,
      ];

      $form['user_sort_values'][$i]['search_key'] = [
        '#type' => 'select',
        '#title' => 'Search field key',
        '#empty_option' => '- Select search field key -',
        '#options' => $sortSearchApiFields,
        '#default_value' => (!empty($userSortValues[$i]) && !empty($userSortValues[$i]['search_key'])) ? $userSortValues[$i]['search_key'] : '',
        '#required' => FALSE,
      ];
      $form['user_sort_values'][$i]['direction'] = [
        '#type' => 'select',
        '#title' => 'Sort direction',
        '#empty_option' => '- No direction specified -',
        '#options' => [
          'asc' => $this->t('Ascending'),
          'desc' => $this->t('Descending'),
        ],
        '#default_value' => (!empty($userSortValues[$i]) && !empty($userSortValues[$i]['direction'])) ? $userSortValues[$i]['direction'] : NULL,
        '#required' => FALSE,
      ];
      $form['user_sort_values'][$i]['weighting'] = [
        '#type' => 'select',
        '#title' => 'Weight',
        '#options' => $this->getWeightingOptions($form_state->get('user_sort_num')),
        '#default_value' => (!empty($userSortValues[$i]) && !empty($userSortValues[$i]['weighting'])) ? $userSortValues[$i]['weighting'] : 0,
        '#required' => TRUE,
      ];
    }

    // Button to add more rows.
    $form['add_user_sort'] = [
      '#type' => 'submit',
      '#attributes' => [
        'class' => [
          'button-action',
        ],
      ],
      '#value' => $this->t('Add user-facing sort'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $paragraphType = ParagraphsType::load($form_state->getValue('paragraph_type_id'));
    if (!$paragraphType) {
      $form_state->setErrorByName('paragraph_type_id', $this->t('The listings paragraph MUST have a valid paragraph type machine name specified.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    switch ($form_state->getValue('op')) {
      case 'Add prefilter value':
        // Add an additional prefilter value.
        $prefilter_num = $form_state->get('prefilter_num');
        $form_state->set('prefilter_num', ($prefilter_num + 1));

        // Rebuild the form.
        $form_state->setRebuild();
        break;

      case 'Add default sort':
        // Add an additional default sort value.
        $sort_num = $form_state->get('sort_num');
        $form_state->set('sort_num', ($sort_num + 1));

        // Rebuild the form.
        $form_state->setRebuild();
        break;

      case 'Add user-facing sort':
        // Add an additional default sort value.
        $sort_num = $form_state->get('user_sort_num');
        $form_state->set('user_sort_num', ($sort_num + 1));

        // Rebuild the form.
        $form_state->setRebuild();
        break;

      default:
        parent::submitForm($form, $form_state);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $listingsParagraph = $this->entity;

    $prefilterFields = [];
    if (!empty($form_state->getValue('prefilter_fields'))) {
      $prefilterFields = $this->convertPrefilterFieldArrayToConfigArray($form_state->getValue('prefilter_fields'));
    }
    $listingsParagraph->setPrefilterFields($prefilterFields);

    $prefilterValues = [];
    if (!empty($form_state->getValue('prefilter_values'))) {
      $prefilterValues = $this->convertPrefilterValueArrayToConfigArray($form_state->getValue('prefilter_values'));
    }
    $listingsParagraph->setPrefilterValues($prefilterValues);

    $sortValues = [];
    if (!empty($form_state->getValue('sort_values'))) {
      $sortValues = $form_state->getValue('sort_values');
      $sortValues = $this->prepareSortValuesForConfig($sortValues);
    }
    $listingsParagraph->setSortValues($sortValues);

    $userSortValues = [];
    if (!empty($form_state->getValue('user_sort_values'))) {
      $userSortValues = $form_state->getValue('user_sort_values');
      $userSortValues = $this->prepareSortValuesForConfig($userSortValues);
    }
    $listingsParagraph->setUserSortValues($userSortValues);

    if ($form_state->getValue('has_keyword')) {
      $listingsParagraph->setHasKeyword(TRUE);
    }
    else {
      $listingsParagraph->setHasKeyword(FALSE);
    }

    $status = $listingsParagraph->save();

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()->addMessage($this->t('Created the %label Listings paragraph.', [
          '%label' => $listingsParagraph->label(),
        ]));
        break;

      default:
        $this->messenger()->addMessage($this->t('Saved the %label Listings paragraph.', [
          '%label' => $listingsParagraph->label(),
        ]));
    }

    $form_state->setRedirectUrl($listingsParagraph->toUrl('collection'));
  }

  /**
   * Flatten the prefilter value array from a config array to form value array.
   */
  protected function flattenPrefilterValueArray(array $configArray) {
    $formValues = [];
    foreach ($configArray as $searchKey => $prefilterValue) {
      foreach ($prefilterValue as $prefilterValueItem) {
        $key = NULL;
        if (is_array($prefilterValueItem)) {
          $key = key($prefilterValueItem);
          $value = $prefilterValueItem[$key];
        }
        else {
          $value = $prefilterValueItem;
        }
        $formValues[] = [
          'search_key' => $searchKey,
          'key' => $key,
          'value' => $prefilterValueItem,
        ];
      }
    }
    return $formValues;
  }

  /**
   * Flatten the prefilter value array from a config array to form value array.
   *
   * This function removes indexes with empty key values (erroneous entries).
   */
  protected function convertPrefilterValueArrayToConfigArray(array $formValues) {
    $configArray = [];
    foreach ($formValues as $i => $prefilterValue) {
      // If no search key is set, do not add to array.
      if (empty($prefilterValue['search_key'])) {
        continue;
      }

      // If a key has been defined then create an array item using the
      // key and value.
      $value = $prefilterValue['value'];
      if (!empty($prefilterValue['key'])) {
        $value = [$prefilterValue['key'] => $prefilterValue['value']];
      }
      // Assign the value into a new array or append.
      if (!isset($prefilterValues[$prefilterValue['search_key']])) {
        $configArray[$prefilterValue['search_key']] = [];
      }
      $configArray[$prefilterValue['search_key']][] = $value;
    }
    return $configArray;
  }

  /**
   * Convert the prefilter field array from form value array to a config array.
   */
  protected function convertPrefilterFieldArrayToConfigArray(array $formValues) {
    $configArray = [];
    foreach ($formValues as $prefilterField) {
      if (!empty($prefilterField['search_key'])) {
        $configArray[$prefilterField['field_name']]['search_key'] = $prefilterField['search_key'];
        $configArray[$prefilterField['field_name']]['processor'] = $prefilterField['processor'];
      }
    }
    return $configArray;
  }

  /**
   * Set the entity field manager.
   */
  public function setEntityFieldManager(EntityFieldManagerInterface $entity_field_manager) {
    $this->entityFieldManager = $entity_field_manager;
    return $this;
  }

  /**
   * Set the listings field processor manager.
   */
  public function setListingsFieldProcessorManager(ListingsFieldProcessorManager $listings_field_processor_manager) {
    $this->listingsFieldProcessorManager = $listings_field_processor_manager;
    return $this;
  }

  /**
   * Generate weighting options from row count.
   *
   * @param int $rowCount
   *   Row count of current entity table to weight.
   *
   * @return array
   *   Array of weighting options.
   */
  protected function getWeightingOptions($rowCount) {
    $options = [];
    for ($i = 0; $i < $rowCount; $i++) {
      $options[$i] = $i;
    }
    return $options;
  }

  /**
   * Prepare sortValues array for save to config.
   *
   * Sort by weighting.
   * Remove entries with no search field selected.
   *
   * @param array $sortValues
   *   sortValues to be prepared.
   *
   * @return array
   *   Prepared sortValues.
   */
  protected function prepareSortValuesForConfig(array $sortValues) {
    foreach ($sortValues as $key => $value) {
      if (empty($value['search_key'])) {
        unset($sortValues[$key]);
      }
    }
    // Sort sort values by weighting.
    usort($sortValues, function ($a, $b) {
      return $a['weighting'] <=> $b['weighting'];
    });
    return $sortValues;
  }

}
