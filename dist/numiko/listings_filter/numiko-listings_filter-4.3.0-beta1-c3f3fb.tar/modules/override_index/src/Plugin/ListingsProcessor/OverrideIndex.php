<?php

namespace Drupal\listings_filter_override_index\Plugin\ListingsProcessor;

use Drupal\search_api\Entity\Index;
use Drupal\Core\Form\SubformStateInterface;
use Drupal\listings_filter\ListingsProcessorBase;
use Drupal\listings_filter\ListingsProcessorInterface;

/**
 * A processor for overriding the search index.
 *
 * @ListingsProcessor(
 *   id = "override_index",
 *   name = @Translation("Override Search Index"),
 *   description = @Translation("Allows a paragraph to override a search index"),
 *   stages = {
 *      "preprocess_listing_query_settings" = 0
 *   }
 * )
 */
class OverrideIndex extends ListingsProcessorBase implements ListingsProcessorInterface {

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $subform, SubformStateInterface $processorFormState): array {
    $processorSettings = $this->configuration;

    $form = [];

    $indexSelectOptions = array_map(function ($index) {
      return $index->label();
    }, Index::loadMultiple());

    $form['site_index'] = [
      '#type' => 'select',
      '#title' => 'Site index',
      '#description' => 'Use an alternative site index for this listing',
      '#default_value' => $processorSettings['site_index'] ?? NULL,
      '#required' => FALSE,
      '#empty_option' => 'Use default index',
      '#options' => $indexSelectOptions,
    ];
    return $form;
  }

  /**
   * Allow the search index to be overridden.
   */
  public function preprocessListingQuerySettings(array &$settings): void {
    if (isset($this->configuration['site_index'])) {
      $settings['site_index'];
    }
  }

}
