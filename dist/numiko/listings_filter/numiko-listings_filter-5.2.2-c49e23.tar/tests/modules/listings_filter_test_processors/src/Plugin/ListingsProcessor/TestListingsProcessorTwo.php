<?php

namespace Drupal\listings_filter_test_processors\Plugin\ListingsProcessor;

use Drupal\Core\Form\SubformStateInterface;
use Drupal\listings_filter\ListingsProcessorBase;
use Drupal\listings_filter_test_processors\TestPluginTrait;
use Drupal\search_api\Query\QueryInterface;
use Drupal\search_api\Query\ResultSetInterface;

/**
 * Provides a listings filter processor.
 *
 * @ListingsProcessor(
 *   id = "listings_filter_test_processor_two",
 *   label = @Translation("Test listings processor"),
 * )
 */
class TestListingsProcessorTwo extends ListingsProcessorBase {

  use TestPluginTrait;

  /**
   * {@inheritdoc}
   */
  public function supportsStage($stage_identifier): bool {
    return TRUE;
  }

  /**
   * {@inheritdoc}
   */
  public function alterQuery(QueryInterface &$query, array $settings = []): void {}

  /**
   * {@inheritdoc}
   */
  public function preprocessResults(ResultSetInterface &$results, array $settings = []): void {}

  /**
   * {@inheritdoc}
   */
  public function preprocessResponseData(array &$data, array $settings = [], ?ResultSetInterface $results = NULL): void {
    $this->logMethodCall(__FUNCTION__, func_get_args());
    $data['test_data']['listings_filter_test_processor_two'] = 'listings_filter_test_processor_two';
  }

  /**
   * {@inheritdoc}
   */
  public function preprocessListingQuerySettings(array &$settings): void {}

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $subform, SubformStateInterface $processorFormState): array {
    $this->logMethodCall(__FUNCTION__, func_get_args());
    return [];
  }

}
