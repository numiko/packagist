# Listings Filter

Map listing filter paragraphs to the drupalSettings.listing javascript object, ready to be accessed by a front-end approach.

## Installation

Install the module as usual `drush en listings_filter`

## Configuration

In order to setup a listing paragraph:

 1. Create a paragraph [/admin/structure/paragraphs_type/add]
 1. Add the following fields (each is optional and should work in any combination):
    * Facets field - entity reference field to select one or more facets to display (the ID here should be field_facets)
    * Pinned items field - entity reference field to select one or more nodes to display pinned
    * Items per page field - integer field if you would like the CMS editor to define how many items show per page
    * Result count field - integer field if you would like the CMS editor to define the maximum number of results
    * Any fields referencing taxonomy or nodes to allow the content to be pre-filtered by the CMS user
 1. Enable the paragraph as a listings filter paragraph type [/admin/structure/listings_paragraph/settings]
 1. Create a listings paragraph config entity [/admin/structure/listings_paragraph/add]
 1. After saving click 'Edit' to configure the fields (optional):
    * Facets field - select the facets entity reference field
    * Pinned items field - select the pinned items content entity reference field
    * Items per page field - select the integer field to store the number of items per page
    * Items per page value - enter the number of items to display per page if Items per page field is not set
    * Result count field - select the integer field to store the maximum number of results for this listing
    * Result count value - enter the maximum number of results if Result count field is not set
    * Check 'provide a keyword search' to enable a keyword search
    * Display mode - The display mode to render the entity.
    * Promoted display mode - If using promoted content set the display mode to render the entity.
    * Promoted content field - Set the field to search on when using promoted content. e.g uuid.
    * Prefilter fields - select any entity reference fields to be used to prefilter the search listing and identify the search field to be mapped to (see Processors below)
    * Prefilter values - enter any hardcoded values to be passed to the filter for this paragraph type (e.g. content_type), as well as the value add the prefilter key for the value array (e.g. target_id for a node reference field ['target_id' => 12] - where 12 is your node ID)
    * Default sorts - define one or more search fields to use to sort the listing results, alongside the sort direction
    * User sorts - define one or more search fields to be exposed to the user as interactable sorts, alongside the label

After carrying out the steps above your paragraph template will now have access to drupalSettings.listing which will be populated from a combination of the predefined values and values stored in the fields selected by the CMS editor.

## Facet field

This module has built in functionality to filter the facets available based on content type when the paragraph is being updated. This will natively work if you are using an options based field (select, checkboxes, etc). You can also enable this for autocomplete fields by using the *Listing filter: Facet selection* reference type when configuring the facets field.

## Prefilter Value Processors

Most of the prefilter fields are simply a case of passing the data from the field value array to the search field, this is certainly true of taxonomy fields for example, so for these we use the default **Get Value** processor.

However occassionally there is a requirement to cast a field of one format into another, so processors are available for these fields, you can add custom processors using the **@ListingsFieldProcessor** annotation, a couple of options are available for use or as examples, these can be found in the Plugin / ListingFieldProcessor folder.

### Annotation

Listing field processors (**@ListingsFieldProcessor**) should include an ID string, a label and a description.

```php
/**
 * Provides a direct field listing processor.
 *
 * @ListingsFieldProcessor(
 *   id = "get_value",
 *   name = @Translation("Get Value"),
 *   description = @Translation("Map the value of the field to search API")
 * )
 */
```

The class must implement the `processField(FieldItemList $field)` method, and return the field value in the format expected for the search field you are trying to map to, for example here is the get value processor processField method:

```php
/**
 * Pass the value of the field directly to search API.
 */
public function processField(FieldItemList $field) {
  return $field->getValue();
}
```

Another example of this is the string field processor, which simply extracts the string interpretation of the field value:

```php
/**
 * Pass the string interpretation of the field directly to search API.
 */
public function processField(FieldItemList $field) {
  return $field->getString();
}
```

## Listings processors

Listings processors allow modules to define plugins that provide bespoke behaviour for listings paragraphs.

As of writing, plugins can interact with listings paragraph data at the following stages: 'Alter query',
'Preprocess results', 'Preprocess response data', 'Preprocess listing query settings'.

See Drupal\listings_filter\ListingsProcessorBase for an example annotation.
ListingsProcessors should implement Drupal\listings_filter\ListingsProcessorInterface.
ListingsProcessor classes should be placed in src/Plugin/ListingsProcessor within a module in order to be discovered.

See Drupal\listings_filter_test_processors\Plugin\ListingsProcessor\TestListingsProcessor for an example of how
a ListingsProcessor class could make changes to data.

## Facets

Facets should use the Listing Filter Search API Facets {Index} source. The URL processor should be set to `Listing Filter Query string`.

When adding a facet use the `Listing Filter JSON` widget.

### Hierarchical support
Facets have a boolean to allow `use_hierarchy`, this must be enabled and then parent terms
within a facet can be selected, their children will be added to the data:

```json
"id": "filter_my_vocab",
"label": "My Vocabulary",
"path": "my_vocab",
"terms": [
    {
        "value": "12",
        "label": "Parent term label",
        "active": false,
        "children": [
            {
                "value": "14",
                "label": "Child term label",
                "active": true,
                
            }
        ]
    }
]
```
Also ensure that the `index hierarchy` processor is enabled in the search api with

`Hierarchy property to use` set as Taxonomy term » Term Parents for your hierarchical facet.

### Additional fields data

For entity reference fields you can select one or more fields to return within the facet result data.

This is currently only geared to work with fields storing text data, e.g. icons, description, etc.

For example: If a "facet description" (field_description) field was added to the taxonomy term, this could then be selected and it would return within the facet object.

```json
"id": "filter_my_vocab",
"label": "My Vocabulary",
"path": "my_vocab",
"terms": [
    {
        "value": "12",
        "label": "My Term Label",
        "active": false,
        "field_description": "Some info about my term label"
    }
]
```

## Theme'ing

There is a template suggestion added of `paragraph--listings-filter.html.twig` for each of the paragraph types selected above, as well as bundle (`paragraph--listings-filter--{bundle}.html.twig`) and view mode (`paragraph--listings-filter--{bundle}--{view-mode}.html.twig`) variants.

This will most likely be a barebones template, something akin to:

```
<div data-js-views-listing data-js-listing-type="{{ listing_type }}" data-js-listing-title="{{ title }}" data-js-listing-title-id="{{ title_id }}-title">
  <div class="container">
    <h2 {{ create_attribute({ 'class': title_classes }) }} id="{{ title_id }}-title">
      {{ title }}
    </h2>
  </div>
</div>
```

## Testing a listing filter

Testing a listing filter by using javascript to select facets and check calls come back correct is hard so the best way to test listing slices is by directly querying them with JSON:

First, use the `Drupal\Tests\listings_filter\Traits\ListingsFilterApiTrait` to import a function to make the request and some other functions to assert various properties of the request.

Then, create any nodes and taxonomies you will use to test with:

```php
$vocab_1 = Vocabulary::load('taxonomy_vocab_1');
$testFacetTerm1 = $this->createTerm($vocab_1);
$testFacetTerm2 = $this->createTerm($vocab_1);

$vocab_2 = Vocabulary::load('taxonomy_vocab_2');
$testPrefilterTerm1 = $this->createTerm($vocab_1);
$testPrefilterTerm2 = $this->createTerm($vocab_2);

$node = $this->createPublishedNode([
  'type' => 'article',
  'title' => 'Test page 1',
  'field_publish_date' => '2023-12-19',
  'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser.jpg')->id(),
  'field_teaser_summary' => 'Test teaser 1',
  'field_taxonomy_type_1' => $testFacetTerm1->id(),
  'field_taxonomy_type_2' => $testPrefilterTerm1->id(),
]);
```
Now remember to reset the solr index:

```php
// Index newly created nodes.
$this->clearCache();
$this->indexItemsInSearch();
```

Then, create your listing paragraph and a published node its attached to.

Note: If you have any prefilters pass them to the paragraph here too.

```php
$paragraph = $this->createParagraph('slice_listing_1', [
  'field_facet' => ['target_id' => 'facet_1'],
  'field_prefilter_taxonomy' => $testPrefilterTerm1->id(),
]);
$this->createPublishedNode([
  'type' => 'listing_page',
  'field_slices' => $paragraph,
]);
```

Now add the listing to a page with dev tools open and inspect the GET request. Convert URL query parameters to an array and pass `callListingFilterApi` the listing paragraph and the query parameters:

```php
$response = $this->callListingFilterApi($paragraph, [
  'filter' => [
    'facet_1' => [
      'path' => 'search_api_filter_1',
      'value' => [$testFacetTerm1->id()],
      ],
    ],
  ],
);
```

Use the functions in `ListingsFilterApiTrait`, passing the response from the calling function as the last argument:


```php
$this->assertResultsByUuid([$node->uuid()], $response);
```

