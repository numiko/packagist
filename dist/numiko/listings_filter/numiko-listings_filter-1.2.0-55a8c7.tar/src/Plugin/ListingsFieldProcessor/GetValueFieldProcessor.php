<?php

namespace Drupal\listings_filter\Plugin\ListingsFieldProcessor;

use Drupal\Core\Field\FieldItemList;
use Drupal\listings_filter\ListingsFieldProcessorBase;
use Drupal\listings_filter\Annotation\ListingsFieldProcessor;

/**
 * Provides a direct field listing processor.
 *
 * @ListingsFieldProcessor(
 *   id = "get_value",
 *   name = @Translation("Get Value"),
 *   description = @Translation("Map the value of the field to search API")
 * )
 */
class GetValueFieldProcessor extends ListingsFieldProcessorBase {

  /**
   * Pass the value of the field directly to search API.
   */
  public function processField(FieldItemList $field) {
    return $field->getValue();
  }

}
