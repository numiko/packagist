<?php

namespace Drupal\listings_filter\Form;

use Drupal\Component\Utility\Html;
use Drupal\Core\Entity\EntityDisplayRepositoryInterface;
use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Form\SubformState;
use Drupal\listings_filter\ListingsParagraphFacets;
use Drupal\listings_filter\ListingsProcessorManager;
use Drupal\Core\Form\FormStateInterface;
use Drupal\paragraphs\Entity\ParagraphsType;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\listings_filter\ListingsFieldProcessorManager;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class ListingsParagraphForm.
 */
class ListingsParagraphForm extends EntityForm {

  /**
   * The key for storing the value in the prefilter flattened array.
   *
   * This key is expected by the front-end application.
   */
  const PREFILTER_VALUE_KEY = 'value';

  /**
   * The key for storing the operator in the prefilter flattened array.
   */
  const PREFILTER_OP_KEY = 'op';

  /**
   * The default prefilter operator.
   */
  const PREFILTER_OP_DEFAULT = 'IN';

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected EntityFieldManagerInterface $entityFieldManager;

  /**
   * The listings field processor manager.
   *
   * @var \Drupal\listings_filter\ListingsFieldProcessorManager
   */
  protected ListingsFieldProcessorManager $listingsFieldProcessorManager;

  /**
   * The listings processor manager.
   *
   * @var \Drupal\listings_filter\ListingsProcessorManager
   */
  protected ListingsProcessorManager $listingsProcessorManager;

  /**
   * The entity display repository.
   *
   * @var \Drupal\Core\Entity\EntityDisplayRepositoryInterface
   */
  protected EntityDisplayRepositoryInterface $entityDisplayRepository;

  /**
   * The listings facet helper service.
   *
   * @var \Drupal\listings_filter\ListingsParagraphFacets
   */
  protected ListingsParagraphFacets $listingsParagraphFacets;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->setEntityFieldManager($container->get('entity_field.manager'));
    $instance->setListingsFieldProcessorManager($container->get('plugin.manager.listings_field_processor'));
    $instance->setListingsProcessorManager($container->get('plugin.manager.listings_processor'));
    $instance->setEntityDisplayRepository($container->get('entity_display.repository'));
    $instance->setListingsParagraphFacets($container->get('listings_filter.facets'));
    return $instance;
  }

  /**
   * Set the entity field manager.
   */
  public function setEntityFieldManager(EntityFieldManagerInterface $entity_field_manager) {
    $this->entityFieldManager = $entity_field_manager;
    return $this;
  }

  /**
   * Set the listings field processor manager.
   */
  public function setListingsFieldProcessorManager(ListingsFieldProcessorManager $listings_field_processor_manager) {
    $this->listingsFieldProcessorManager = $listings_field_processor_manager;
    return $this;
  }

  /**
   * Set the listings processor manager.
   */
  public function setListingsProcessorManager(ListingsProcessorManager $listings_processor_manager) {
    $this->listingsProcessorManager = $listings_processor_manager;
    return $this;
  }

  /**
   * Set the entity display repository.
   */
  public function setEntityDisplayRepository($entity_display_repository) {
    $this->entityDisplayRepository = $entity_display_repository;
    return $this;
  }

  /**
   * Set the listings facet helper service.
   */
  public function setListingsParagraphFacets(ListingsParagraphFacets $listings_paragraphs_facets) {
    $this->listingsParagraphFacets = $listings_paragraphs_facets;
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);

    /** @var \Drupal\listings_filter\Entity\ListingsParagraph */
    $listingsParagraph = $this->entity;
    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Label'),
      '#maxlength' => 255,
      '#default_value' => $listingsParagraph->label(),
      '#description' => $this->t("Label for the Listings paragraph."),
      '#required' => TRUE,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $listingsParagraph->id(),
      '#machine_name' => [
        'exists' => '\Drupal\listings_filter\Entity\ListingsParagraph::load',
      ],
      '#disabled' => !$listingsParagraph->isNew(),
    ];

    $listingParagraphTypes = ParagraphsType::loadMultiple(array_values(self::config('listings_filter.settings')
      ->get('paragraph_types')));
    $options = array_map(function($paragraph) {
      return $paragraph->label();
    }, $listingParagraphTypes);

    $form['paragraph_type_id'] = [
      '#type' => 'select',
      '#options' => $options,
      '#title' => $this->t('Paragraph type to map to'),
      '#description' => $this->t("If your paragraph type isn't showing then edit the listing paragraph settings."),
      '#default_value' => $listingsParagraph->getParagraphTypeId(),
      '#required' => TRUE,
      '#disabled' => ($listingsParagraph->getParagraphTypeId() && ParagraphsType::load($listingsParagraph->getParagraphTypeId())) ? TRUE : FALSE,
    ];

    // If the paragraph is new there is nothing more to do in the create stage.
    if ($listingsParagraph->isNew()) {
      return $form;
    }

    $fieldList = [];
    $bundleFields = $this->entityFieldManager->getFieldDefinitions('paragraph', $listingsParagraph->getParagraphTypeId());
    foreach ($bundleFields as $fieldName => $fieldDefinition) {
      if (!empty($fieldDefinition->getTargetBundle())) {
        $fieldList[$fieldName] = $fieldDefinition->getLabel();
      }
    }

    // Make field list available to plugins using form state.
    $form_state->set('field_list', $fieldList);

    $searchApiFields = $this->listingsParagraphFacets->getSearchApiFields();

    $fieldsInUse = [];

    $form['facets_field'] = [
      '#type' => 'select',
      '#title' => 'Facets field',
      '#description' => 'Select the field that will hold the selected facets',
      '#empty_option' => '- Select paragraph field -',
      '#options' => $fieldList,
      '#default_value' => $listingsParagraph->getFacetsField(),
      '#required' => FALSE,
    ];
    $fieldsInUse[] = $listingsParagraph->getFacetsField();

    $form['pinned_items_field'] = [
      '#type' => 'select',
      '#title' => 'Pinned items field',
      '#description' => 'Select the field that will hold the pinned items',
      '#empty_option' => '- Select paragraph field -',
      '#options' => $fieldList,
      '#default_value' => $listingsParagraph->getPinnedItemsField(),
      '#required' => FALSE,
    ];
    $fieldsInUse[] = $listingsParagraph->getPinnedItemsField();

    $form['items_per_page_field'] = [
      '#type' => 'select',
      '#title' => "Items per page field",
      '#description' => "Select the field that will hold the items per page value",
      '#empty_option' => '- Select paragraph field -',
      '#options' => $fieldList,
      '#default_value' => $listingsParagraph->getItemsPerPageField(),
      '#required' => FALSE,
    ];
    $fieldsInUse[] = $listingsParagraph->getItemsPerPageField();

    $form['items_per_page_value'] = [
      '#type' => 'number',
      '#title' => "Items per page value",
      '#description' => "Or define the number of items to show per page",
      '#default_value' => $listingsParagraph->getItemsPerPageValue(),
      '#required' => FALSE,
    ];

    $form['result_count_field'] = [
      '#type' => 'select',
      '#title' => "Result count field",
      '#description' => "Select the field that will hold the limit to the number of results",
      '#empty_option' => '- Select paragraph field -',
      '#options' => $fieldList,
      '#default_value' => $listingsParagraph->getResultCountField(),
      '#required' => FALSE,
    ];
    $fieldsInUse[] = $listingsParagraph->getResultCountField();

    $form['result_count_value'] = [
      '#type' => 'number',
      '#title' => "Result count value",
      '#description' => "Or define the maximum number of results",
      '#default_value' => $listingsParagraph->getResultCountValue(),
      '#required' => FALSE,
    ];

    $form['has_keyword'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Provide a keyword search'),
      '#default_value' => $listingsParagraph->getHasKeyword(),
    ];

    $form['display_mode'] = [
      '#type' => 'select',
      '#title' => $this->t('Display mode'),
      '#options' => $this->getDisplayModes(),
      '#description' => $this->t('The display mode to render'),
      '#default_value' => $listingsParagraph->getDisplayMode(),
    ];

    $form['promoted_display_mode'] = [
      '#type' => 'select',
      '#title' => $this->t('Promoted display mode'),
      '#options' => $this->getDisplayModes(),
      '#description' => $this->t('The display mode to render'),
      '#default_value' => $listingsParagraph->getPromotedDisplayMode(),
    ];

    $form['promoted_content_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Promoted content field'),
      '#empty_option' => '- Select search API field -',
      '#options' => $searchApiFields,
      '#default_value' => $listingsParagraph->getPromotedContentField(),
      '#required' => FALSE,
    ];

    /*
     * There are two methods of prefiltering:
     *
     * Using a defined prefilter field, which can then be selected by the CMS
     * user when setting up the paragraph on the content [prefilter_fields].
     *
     * Actually predefining the value on the listing paragraph configuration,
     * which CANNOT be altered by the CMS user (e.g. predefining content types
     * to return) [prefilter_values].
     */

    $processor_options = $this->listingsFieldProcessorManager->getProcessorOptions();

    $form['prefilter_fields'] = [
      '#type' => 'table',
      '#caption' => "Prefilter Fields",
      '#description' => "When using an IN or NOT IN operator you can comma separate the prefilter value",
      '#header' => [
        'Field label',
        'Field name',
        'Search Field',
        'Processor',
        '',
      ],
    ];

    $i = 0;
    foreach ($fieldList as $fieldName => $fieldLabel) {
      if (!in_array($fieldName, $fieldsInUse)) {
        $form['prefilter_fields'][$i]['label'] = [
          '#markup' => "<strong>{$fieldLabel}</strong>",
        ];
        $form['prefilter_fields'][$i]['name'] = [
          '#markup' => "{$fieldName}",
        ];
        $form['prefilter_fields'][$i]['search_key'] = [
          '#type' => 'select',
          '#empty_option' => '- Select search API field -',
          '#options' => $searchApiFields,
          '#default_value' => (isset($listingsParagraph->getPrefilterFields()[$fieldName]['search_key'])) ? $listingsParagraph->getPrefilterFields()[$fieldName]['search_key'] : NULL,
          '#required' => FALSE,
        ];
        $form['prefilter_fields'][$i]['processor'] = [
          '#type' => 'select',
          '#options' => $processor_options,
          '#default_value' => (isset($listingsParagraph->getPrefilterFields()[$fieldName]['processor'])) ? $listingsParagraph->getPrefilterFields()[$fieldName]['processor'] : NULL,
        ];
        $form['prefilter_fields'][$i]['field_name'] = [
          '#type' => 'hidden',
          '#default_value' => $fieldName,
        ];
        $i++;
      }
    }

    $prefilterValues = $this->flattenPrefilterValueArray($listingsParagraph->getPrefilterValues());

    if (!$form_state->get('prefilter_num')) {
      $form_state->set('prefilter_num', count($prefilterValues));
    }

    $form['prefilter_values'] = [
      '#type' => 'table',
      '#caption' => 'Add prefilter values',
      '#header' => [
        'Search field key',
        'Prefilter value',
        'Prefilter operator',
      ],
    ];

    for ($i = 0; $i < $form_state->get('prefilter_num'); $i++) {
      $form['prefilter_values'][$i]['search_key'] = [
        '#type' => 'select',
        '#title' => "Search field key",
        '#empty_option' => '- Select search field key -',
        '#options' => $searchApiFields,
        '#default_value' => (!empty($prefilterValues[$i]) && !empty($prefilterValues[$i]['search_key'])) ? $prefilterValues[$i]['search_key'] : '',
        '#required' => FALSE,
      ];
      $form['prefilter_values'][$i]['value'] = [
        '#type' => 'textfield',
        '#title' => "Value",
        '#default_value' => (!empty($prefilterValues[$i]) && !empty($prefilterValues[$i]['value'])) ? $prefilterValues[$i]['value'] : '',
        '#required' => FALSE,
      ];
      $default_op = !empty($prefilterValues[$i]) ? '' : self::PREFILTER_OP_DEFAULT;
      $form['prefilter_values'][$i][self::PREFILTER_OP_KEY] = [
        '#type' => 'textfield',
        '#title' => "Operator",
        '#default_value' => (!empty($prefilterValues[$i]) && !empty($prefilterValues[$i][self::PREFILTER_OP_KEY])) ? $prefilterValues[$i][self::PREFILTER_OP_KEY] : $default_op,
        '#required' => FALSE,
      ];
    }

    // Button to add more rows.
    $form['add_prefilter'] = [
      '#type' => 'submit',
      '#attributes' => [
        'class' => [
          'button-action',
        ],
      ],
      '#value' => $this->t('Add prefilter value'),
    ];

    $sortValues = $listingsParagraph->getSortValues();

    if (!$form_state->get('sort_num')) {
      $form_state->set('sort_num', count($sortValues));
    }

    $form['sort_values'] = [
      '#type' => 'table',
      '#caption' => 'Add default sorts',
      '#header' => ['Search field key', 'Sort direction', 'Weight'],
    ];

    $sortSearchApiFields = array_merge($searchApiFields, ['search_api_relevance' => 'relevance']);
    for ($i = 0; $i < $form_state->get('sort_num'); $i++) {
      $form['sort_values'][$i]['search_key'] = [
        '#type' => 'select',
        '#title' => 'Search field key',
        '#empty_option' => '- Select search field key -',
        '#options' => $sortSearchApiFields,
        '#default_value' => (!empty($sortValues[$i]) && !empty($sortValues[$i]['search_key'])) ? $sortValues[$i]['search_key'] : '',
        '#required' => FALSE,
      ];
      $form['sort_values'][$i]['direction'] = [
        '#type' => 'select',
        '#title' => 'Sort direction',
        '#options' => [
          'asc' => 'Ascending',
          'desc' => 'Descending',
        ],
        '#default_value' => (!empty($sortValues[$i]) && !empty($sortValues[$i]['direction'])) ? $sortValues[$i]['direction'] : 'asc',
        '#required' => TRUE,
      ];
      $form['sort_values'][$i]['weighting'] = [
        '#type' => 'select',
        '#title' => 'Weight',
        '#options' => $this->getWeightingOptions($form_state->get('sort_num')),
        '#default_value' => (!empty($sortValues[$i]) && !empty($sortValues[$i]['weighting'])) ? $sortValues[$i]['weighting'] : 0,
        '#required' => TRUE,
      ];
    }

    // Button to add more rows.
    $form['add_sort'] = [
      '#type' => 'submit',
      '#attributes' => [
        'class' => [
          'button-action',
        ],
      ],
      '#value' => $this->t('Add default sort'),
    ];

    $userSortValues = $listingsParagraph->getUserSortValues();

    if (!$form_state->get('user_sort_num')) {
      $form_state->set('user_sort_num', count($userSortValues));
    }

    $form['user_sort_values'] = [
      '#type' => 'table',
      '#caption' => 'Add user-facing sorts',
      '#header' => ['Label', 'Search field key', 'Sort direction', 'Weight'],
    ];

    for ($i = 0; $i < $form_state->get('user_sort_num'); $i++) {
      $form['user_sort_values'][$i]['label'] = [
        '#type' => 'textfield',
        '#title' => 'Label',
        '#default_value' => (!empty($userSortValues[$i]) && !empty($userSortValues[$i]['label'])) ? $userSortValues[$i]['label'] : '',
        '#required' => TRUE,
      ];

      $form['user_sort_values'][$i]['search_key'] = [
        '#type' => 'select',
        '#title' => 'Search field key',
        '#empty_option' => '- Select search field key -',
        '#options' => $sortSearchApiFields,
        '#default_value' => (!empty($userSortValues[$i]) && !empty($userSortValues[$i]['search_key'])) ? $userSortValues[$i]['search_key'] : '',
        '#required' => FALSE,
      ];
      $form['user_sort_values'][$i]['direction'] = [
        '#type' => 'select',
        '#title' => 'Sort direction',
        '#empty_option' => '- No direction specified -',
        '#options' => [
          'asc' => $this->t('Ascending'),
          'desc' => $this->t('Descending'),
        ],
        '#default_value' => (!empty($userSortValues[$i]) && !empty($userSortValues[$i]['direction'])) ? $userSortValues[$i]['direction'] : NULL,
        '#required' => FALSE,
      ];
      $form['user_sort_values'][$i]['weighting'] = [
        '#type' => 'select',
        '#title' => 'Weight',
        '#options' => $this->getWeightingOptions($form_state->get('user_sort_num')),
        '#default_value' => (!empty($userSortValues[$i]) && !empty($userSortValues[$i]['weighting'])) ? $userSortValues[$i]['weighting'] : 0,
        '#required' => TRUE,
      ];
    }

    // Button to add more rows.
    $form['add_user_sort'] = [
      '#type' => 'submit',
      '#attributes' => [
        'class' => [
          'button-action',
        ],
      ],
      '#value' => $this->t('Add user-facing sort'),
    ];

    $form['processors'] =
      $this->getProcessorsSubform($sortSearchApiFields,  $form_state);

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $paragraphType = ParagraphsType::load($form_state->getValue('paragraph_type_id'));
    if (!$paragraphType) {
      $form_state->setErrorByName('paragraph_type_id', $this->t('The listings paragraph MUST have a valid paragraph type machine name specified.'));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    switch ($form_state->getValue('op')) {
      case 'Add prefilter value':
        // Add an additional prefilter value.
        $prefilter_num = $form_state->get('prefilter_num');
        $form_state->set('prefilter_num', ($prefilter_num + 1));

        // Rebuild the form.
        $form_state->setRebuild();
        break;

      case 'Add default sort':
        // Add an additional default sort value.
        $sort_num = $form_state->get('sort_num');
        $form_state->set('sort_num', ($sort_num + 1));

        // Rebuild the form.
        $form_state->setRebuild();
        break;

      case 'Add user-facing sort':
        // Add an additional default sort value.
        $sort_num = $form_state->get('user_sort_num');
        $form_state->set('user_sort_num', ($sort_num + 1));

        // Rebuild the form.
        $form_state->setRebuild();
        break;

      default:
        parent::submitForm($form, $form_state);
    }
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $listingsParagraph = $this->entity;

    $prefilterFields = [];
    if (!empty($form_state->getValue('prefilter_fields'))) {
      $prefilterFields = $this->convertPrefilterFieldArrayToConfigArray($form_state->getValue('prefilter_fields'));
    }
    $listingsParagraph->setPrefilterFields($prefilterFields);

    $prefilterValues = [];
    if (!empty($form_state->getValue('prefilter_values'))) {
      $prefilterValues = $this->convertPrefilterValueArrayToConfigArray($form_state->getValue('prefilter_values'));
    }
    $listingsParagraph->setPrefilterValues($prefilterValues);

    $sortValues = [];
    if (!empty($form_state->getValue('sort_values'))) {
      $sortValues = $form_state->getValue('sort_values');
      $sortValues = $this->prepareSortValuesForConfig($sortValues);
    }
    $listingsParagraph->setSortValues($sortValues);

    $userSortValues = [];
    if (!empty($form_state->getValue('user_sort_values'))) {
      $userSortValues = $form_state->getValue('user_sort_values');
      $userSortValues = $this->prepareSortValuesForConfig($userSortValues);
    }
    $listingsParagraph->setUserSortValues($userSortValues);

    if ($form_state->getValue('has_keyword')) {
      $listingsParagraph->setHasKeyword(TRUE);
    }
    else {
      $listingsParagraph->setHasKeyword(FALSE);
    }

    $listingsParagraph->setDisplayMode($form_state->getValue('display_mode'));
    $listingsParagraph->setPromotedDisplayMode($form_state->getValue('promoted_display_mode'));
    $listingsParagraph->setPromotedContentField($form_state->getValue('promoted_content_field'));
    $listingsParagraph->setProcessors($form_state->getValue('processors'));

    $status = $listingsParagraph->save();

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()
          ->addMessage($this->t('Created the %label Listings paragraph.', [
            '%label' => $listingsParagraph->label(),
          ]));
        break;

      default:
        $this->messenger()
          ->addMessage($this->t('Saved the %label Listings paragraph.', [
            '%label' => $listingsParagraph->label(),
          ]));
    }

    $form_state->setRedirectUrl($listingsParagraph->toUrl('collection'));
  }

  /**
   * Flatten the prefilter value array from a config array to form value array.
   */
  protected function flattenPrefilterValueArray(array $configArray) {
    $formValues = [];
    foreach ($configArray as $searchKey => $prefilterValue) {
      if (is_array($prefilterValue) && empty($prefilterValue['search_key'])) {
        $value = $prefilterValue[self::PREFILTER_VALUE_KEY];
        // If we are using IN or NOT in the value needs to be an array.
        if (in_array($prefilterValue[self::PREFILTER_OP_KEY], [
          'IN',
          'NOT IN'
        ])) {
          $value = implode(',', $prefilterValue[self::PREFILTER_VALUE_KEY]);
        }
        $formValues[] = [
          'search_key' => $searchKey,
          'value' => $value,
          self::PREFILTER_OP_KEY => $prefilterValue[self::PREFILTER_OP_KEY],
        ];
      }
    }
    return $formValues;
  }

  /**
   * Flatten the prefilter value array from a config array to form value array.
   *
   * This function removes indexes with empty key values (erroneous entries).
   */
  protected function convertPrefilterValueArrayToConfigArray(array $formValues) {
    $configArray = [];
    foreach ($formValues as $i => $prefilterValue) {
      // If no search key is set, do not add to array.
      if (empty($prefilterValue['search_key'])) {
        continue;
      }

      // If a key has been defined then create an array item using the
      // key and value.
      $value = $prefilterValue['value'];
      // If we are using IN or NOT in the value needs to be an array.
      if (in_array($prefilterValue[self::PREFILTER_OP_KEY], ['IN', 'NOT IN'])) {
        $value = explode(',', $prefilterValue[self::PREFILTER_VALUE_KEY]);
      }
      if (!empty($prefilterValue['search_key'])) {
        $value = [
          self::PREFILTER_VALUE_KEY => $value,
          self::PREFILTER_OP_KEY => (!empty($prefilterValue[self::PREFILTER_OP_KEY])) ? $prefilterValue[self::PREFILTER_OP_KEY] : '',
        ];
      }
      // Assign the value into a new array or append.
      if (!isset($prefilterValues[$prefilterValue['search_key']])) {
        $configArray[$prefilterValue['search_key']] = [];
      }
      $configArray[$prefilterValue['search_key']] = $value;
    }
    return $configArray;
  }

  /**
   * Convert the prefilter field array from form value array to a config array.
   */
  protected function convertPrefilterFieldArrayToConfigArray(array $formValues) {
    $configArray = [];
    foreach ($formValues as $prefilterField) {
      if (!empty($prefilterField['search_key'])) {
        $configArray[$prefilterField['field_name']]['search_key'] = $prefilterField['search_key'];
        $configArray[$prefilterField['field_name']]['processor'] = $prefilterField['processor'];
      }
    }
    return $configArray;
  }

  /**
   * Generate weighting options from row count.
   *
   * @param int $rowCount
   *   Row count of current entity table to weight.
   *
   * @return array
   *   Array of weighting options.
   */
  protected function getWeightingOptions($rowCount) {
    $options = [];
    for ($i = 0; $i < $rowCount; $i++) {
      $options[$i] = $i;
    }
    return $options;
  }

  /**
   * Prepare sortValues array for save to config.
   *
   * Sort by weighting.
   * Remove entries with no search field selected.
   *
   * @param array $sortValues
   *   sortValues to be prepared.
   *
   * @return array
   *   Prepared sortValues.
   */
  protected function prepareSortValuesForConfig(array $sortValues) {
    foreach ($sortValues as $key => $value) {
      if (empty($value['search_key'])) {
        unset($sortValues[$key]);
      }
    }
    // Sort sort values by weighting.
    usort($sortValues, function($a, $b) {
      return $a['weighting'] <=> $b['weighting'];
    });
    return $sortValues;
  }

  /**
   * Gets the display mode options.
   *
   * @return array
   *   The display modes.
   */
  protected function getDisplayModes(): array {
    $options = [];
    $node_options = $this->entityDisplayRepository->getViewModeOptions('node');
    unset($node_options['default']);
    $options += $node_options;

    $media_options = $this->entityDisplayRepository->getViewModeOptions('media');
    unset($media_options['default']);
    $options += $media_options;

    return $options;
  }

  protected function getAllProcessors() {
    $processors = $this->entity->getProcessors();
    foreach ($this->listingsProcessorManager->getDefinitions() as $processorId => $processorDefinition) {
      if (class_exists($processorDefinition['class'])) {
        $settings = isset($processors[$processorId]) ? $processors[$processorId]['settings'] : [];
        $processors[$processorId] =
          $this->listingsProcessorManager->createInstance($processorId, $settings);
      }
      else {
        $this->logger('listing_paragraph')->warning(
          'Processor %id specifies a non-existing class %class.', [
            '%id' => $processorId,
            '%class' => $processorDefinition['class'],
          ]
        );
        unset($processors[$processorId]);
      }
    }

    return $processors;
  }

  protected function getProcessorsSubform(array $form, FormStateInterface &$form_state) {
    // Retrieve list of all processors.
    if (!$form_state->has('processors_plugins')) {
      $allProcessors = $this->getAllProcessors();
      $sortProcessors = function($a, $b) {
        return strnatcasecmp($a->getLabel(), $b->getLabel());
      };
      uasort($allProcessors, $sortProcessors);
      $form_state->set('processors_plugins', $allProcessors);
    }
    else {
      $allProcessors = $form_state->get('processors_plugins');
    }

    $stages = $this->listingsProcessorManager->getProcessingStages();
    /** @var \Drupal\listings_filter\ListingsProcessorInterface[][] $processorsByStage */
    $processorsByStage = [];
    foreach ($allProcessors as $processorId => $processor) {
      foreach ($stages as $stage => $definition) {
        if ($processor->supportsStage($stage)) {
          $processorsByStage[$stage][$processorId] = $processor;
        }
      }
    }

    $enabledProcessors = $this->entity->getProcessors();

    $form = [];
    $form['#tree'] = TRUE;
    $form['title']['#markup'] = $this->t('Manage processors for listing paragraph %label', ['%label' => $this->entity->label()]);
    // Prepare list of processor statuses.
    $form['status'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Enabled'),
      '#attributes' => [
        'class' => [
          'listings-processor-status-wrapper',
        ],
      ],
    ];

    // Populate processor statuses.
    foreach ($allProcessors as $processorId => $processor) {
      $cleanCssId = Html::cleanCssIdentifier($processorId);
      $isEnabled = !empty($enabledProcessors[$processorId]);
      $form['status'][$processorId] = [
        '#type' => 'checkbox',
        '#title' => $processor->getLabel(),
        '#default_value' => $isEnabled,
        '#description' => $processor->getDescription(),
        '#attributes' => [
          'class' => [
            'listings-processor-status-' . $cleanCssId,
          ],
        ],
        '#parents' => ['processors', $processorId, 'status'],
      ];
    }

    // Prepare processor weighting table.
    $form['weights'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Processor order'),
      '#id' => 'listings-processor-weights-table'
    ];

    // Order enabled processors per stage.
    foreach ($stages as $stage => $description) {
      $form['weights'][$stage] = [
        '#type' => 'fieldset',
        '#title' => $description['label'],
        '#attributes' => [
          'class' => [
            'listings-processor-stage-wrapper',
            'listings-processor-stage-wrapper-' . Html::cleanCssIdentifier($stage),
          ],
        ],
      ];
      $form['weights'][$stage]['order'] = [
        '#type' => 'table',
      ];
      $form['weights'][$stage]['order']['#tabledrag'][] = [
        'action' => 'order',
        'relationship' => 'sibling',
        'group' => 'listings-processor-weight-' . Html::cleanCssIdentifier($stage),
      ];
    }


    foreach ($processorsByStage as $stage => $processors) {
      // Sort processors by weight to populate weights table.
      $weightSortedProcessors = $processors;
      uasort($weightSortedProcessors, function($a, $b) use ($stage) {
        return (int) ($a->getWeight($stage) > $b->getWeight($stage));
      });
      // Populate processor weights table.
      foreach ($weightSortedProcessors as $processorId => $processor) {
        $form['weights'][$stage]['order'][$processorId]['#type'] = 'container';
        $form['weights'][$stage]['order'][$processorId]['#attributes']['class'][] = 'draggable';
        $form['weights'][$stage]['order'][$processorId]['#attributes']['class'][] = 'listings-processor-weight--' . Html::cleanCssIdentifier($processorId);
        $form['weights'][$stage]['order'][$processorId]['#weight'] = $processor->getWeight($stage);
        $form['weights'][$stage]['order'][$processorId]['label']['#plain_text'] = $processor->getLabel();
        $form['weights'][$stage]['order'][$processorId]['weight'] = [
          '#type' => 'weight',
          '#title' => $this->t('Weight for processor %title', ['%title' => $processor->getLabel()]),
          '#title_display' => 'invisible',
          '#delta' => 50,
          '#default_value' => $processor->getWeight($stage),
          '#parents' => ['processors', $processorId, 'settings', 'weight', $stage],
          '#attributes' => [
            'class' => [
              'listings-processor-weight-' . Html::cleanCssIdentifier($stage),
            ],
          ],
        ];
      }

      // Prepare processor settings.
      $form['processor_settings'] = [
        '#title' => $this->t('Processor settings'),
        '#type' => 'vertical_tabs',
      ];

      // Populate processor settings.
      foreach ($allProcessors as $processorId => $processor) {
        $form['settings'][$processorId] = [
          '#type' => 'details',
          '#title' => $processor->getLabel(),
          '#group' => 'processor_settings',
          '#parents' => ['processors', $processorId, 'settings'],
          '#attributes' => [
            'class' => [
              'listings-processor-settings-' . Html::cleanCssIdentifier($processorId),
            ],
          ],
        ];
        $processorFormState = SubformState::createForSubform($form['settings'][$processorId], $form, $form_state);
        $form['settings'][$processorId] += $processor->buildConfigurationForm($form['settings'][$processorId], $processorFormState);
      }
    }

    return $form;
  }

}
