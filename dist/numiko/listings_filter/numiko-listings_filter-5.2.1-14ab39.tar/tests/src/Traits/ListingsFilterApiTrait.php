<?php

namespace Drupal\Tests\listings_filter\Traits;

use Drupal\Component\Serialization\Json;
use Drupal\Component\Utility\UrlHelper;
use Drupal\Core\Cache\CacheableJsonResponse;
use Drupal\paragraphs\ParagraphInterface;
use Symfony\Component\HttpFoundation\Request;

/**
 * Contains functions useful for testing listing filters.
 */
trait ListingsFilterApiTrait {

  /**
   * Request a response from the listings filter.
   *
   * @param \Drupal\paragraphs\ParagraphInterface $listing
   *   The listing.
   * @param array $params
   *   Any URL paramaters (as an array).
   *
   * @return \Drupal\Core\Cache\CacheableJsonResponse
   *   The response which can then be passed to assert functions.
   */
  protected function callListingFilterApi(ParagraphInterface $listing, array $params = []): CacheableJsonResponse {
    $httpKernel = \Drupal::service('http_kernel');
    $request = Request::create('/api/listing/' . $listing->id() . '?' . UrlHelper::buildQuery($params));
    $request->headers->set('Accept', 'application/json');
    return $httpKernel->handle($request);
  }

  /**
   * Check the UUIDs in a response are exactly what we expect.
   *
   * @param array $uuids
   *   Ids to check.
   * @param \Drupal\Core\Cache\CacheableJsonResponse $responseDocument
   *   The response.
   */
  protected function assertResultsByUuid(array $uuids, CacheableJsonResponse $responseDocument): void {
    $data = Json::decode($responseDocument->getContent());
    $this->assertSame($uuids, array_map(fn (array $data) => $data['id'], $data['items']));
  }

  /**
   * Check a uuid exists in the json response.
   *
   * @param string $uuid
   *   UUID to check.
   * @param \Drupal\Core\Cache\CacheableJsonResponse $responseDocument
   *   The response.
   */
  protected function assertUuidExistsInResponse(string $uuid, CacheableJsonResponse $responseDocument): void {
    $data = Json::decode($responseDocument->getContent());
    $responseUuids = array_map(fn (array $data) => $data['id'], $data['items']);
    $this->assertContains($uuid, $responseUuids);
  }

  /**
   * Check a uuid does not exist in the json response.
   *
   * @param string $uuid
   *   UUID to check.
   * @param \Drupal\Core\Cache\CacheableJsonResponse $responseDocument
   *   Raw content response.
   */
  protected function assertUuidNotExistsInResponse(string $uuid, CacheableJsonResponse $responseDocument): void {
    $data = Json::decode($responseDocument->getContent());
    $responseUuids = array_map(fn (array $data) => $data['id'], $data['items']);
    $this->assertNotContains($uuid, $responseUuids);
  }

  /**
   * Any uuids from a list do not exist in the json response.
   *
   * @param list<string> $uuids
   *   List of UUIDs to check.
   * @param \Drupal\Core\Cache\CacheableJsonResponse $responseDocument
   *   Raw content response.
   */
  protected function assertUuidListNotExistsInResponse(array $uuids, CacheableJsonResponse $responseDocument): void {
    $data = Json::decode($responseDocument->getContent());
    $responseUuids = array_map(fn (array $data) => $data['id'], $data['items']);
    array_map(fn (string $uuid) => $this->assertNotContains($uuid, $responseUuids), $uuids);
  }

  /**
   * Check the response contains $count documents.
   *
   * @param int $count
   *   The count.
   * @param \Drupal\Core\Cache\CacheableJsonResponse $responseDocument
   *   Raw content response.
   */
  protected function assertResponseCountEquals(int $count, CacheableJsonResponse $responseDocument): void {
    $data = Json::decode($responseDocument->getContent());
    $this->assertCount($count, $data['items']);
  }

  /**
   * Check the response contains total $count documents.
   *
   * @param int $count
   *   The count.
   * @param \Drupal\Core\Cache\CacheableJsonResponse $responseDocument
   *   The response.
   */
  protected function assertResponseTotalEquals(int $count, CacheableJsonResponse $responseDocument): void {
    $data = Json::decode($responseDocument->getContent());
    $this->assertEquals($count, $data['meta']['count']);
  }

  /**
   * Check that a facet term is active.
   *
   * @param string $facetId
   *   The facet ids.
   * @param string|int $term
   *   The term to check.
   * @param \Drupal\Core\Cache\CacheableJsonResponse $responseDocument
   *   The response.
   */
  protected function assertFacetTermActive(string $facetId, string|int $term, CacheableJsonResponse $responseDocument): void {
    $data = Json::decode($responseDocument->getContent());
    foreach ($data['meta']['facets'] as $facet) {
      if ($facet['id'] == $facetId) {
        foreach ($facet['terms'] as $facetTerm) {
          if ($facetTerm['value'] == $term) {
            $this->assertTrue($facetTerm['active']);
          }
        }
      }
    }
  }

}
