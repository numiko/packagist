<?php

namespace Drupal\listings_filter_test_processors\Plugin\ListingsProcessor;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\SubformStateInterface;
use Drupal\listings_filter\ListingsProcessorBase;
use Drupal\listings_filter_test_processors\TestPluginTrait;
use Drupal\search_api\Query\QueryInterface;
use Drupal\search_api\Query\ResultSetInterface;

/**
 * Provides a listings filter processor with dependencies, for the
 * dependency removal tests.
 *
 * @ListingsProcessor(
 *   id = "listings_filter_test_processor",
 *   label = @Translation("Test listings processor"),
 * )
 */
class TestListingsProcessor extends ListingsProcessorBase {

  use TestPluginTrait;

  /**
   * Node UUID that appears in result set and can be used in tests.
   *
   * @var string
   */
  const TEST_NODE_UUID = 'e14d303f-6956-4b70-b99b-da27e6951aaf';

  /**
   * Node ID that appears in result set and can be used in tests.
   *
   * @var string
   */
  const TEST_NODE_ID = '5000';

  /**
   * {@inheritdoc}
   */
  public function supportsStage($stage_identifier): bool {
    return TRUE;
  }

  /**
   * {@inheritdoc}
   */
  public function alterQuery(QueryInterface &$query, array $settings = []): void {
    $this->logMethodCall(__FUNCTION__, func_get_args());
    $query->addCondition('uuid', [self::TEST_NODE_UUID], 'NOT IN');
  }

  /**
   * {@inheritdoc}
   */
  public function preprocessPromotedResults(ResultSetInterface &$promotedResults, array $settings = []): void {
    $this->logMethodCall(__FUNCTION__, func_get_args());
    $resultSet = $promotedResults->getResultItems();
    unset($resultSet['entity:node/5000:en']);
    $promotedResults->setResultItems($resultSet);
  }

  /**
   * {@inheritdoc}
   */
  public function preprocessResults(ResultSetInterface &$results, array $settings = []): void {
    $this->logMethodCall(__FUNCTION__, func_get_args());
    $resultSet = $results->getResultItems();
    unset($resultSet['entity:node/5000:en']);
    $results->setResultItems($resultSet);
  }

  /**
   * {@inheritdoc}
   */
  public function preprocessResponseData(array &$data, array $settings = []): void {
    $this->logMethodCall(__FUNCTION__, func_get_args());
    $data['test_data']['listings_filter_test_processor'] = 'listings_filter_test_processor';
    if (isset($settings['paragraph_id'])) {
      $data['test_settings'] = $settings['paragraph_id'];
    }
  }

  /**
   * {@inheritdoc}
   */
  public function preprocessListingQuerySettings(array &$settings): void {
    $this->logMethodCall(__FUNCTION__, func_get_args());
    $settings['test_setting'] = 'listings_filter_test_processor';
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $subform, SubformStateInterface $processorFormState): array {
    $this->logMethodCall(__FUNCTION__, func_get_args());
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function alterConfigurationForm(array &$form, FormStateInterface $form_state, $entity): void {
    $this->logMethodCall(__FUNCTION__, func_get_args());
    // Add a test field to verify form alteration works.
    $form['test_configuration_form_field'] = [
      '#type' => 'textfield',
      '#title' => 'Test Configuration Form Field',
      '#description' => 'This field was added by the test processor to verify STAGE_ALTER_CONFIGURATION_FORM works.',
      '#default_value' => 'test_value_from_processor',
    ];
  }

}
