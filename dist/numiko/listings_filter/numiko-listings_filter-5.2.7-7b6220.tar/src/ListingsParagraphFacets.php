<?php

namespace Drupal\listings_filter;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Link;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\Url;
use Drupal\listings_filter\Entity\ListingsParagraphInterface;

/**
 * Identify the facets available for a specific listing paragraph.
 *
 * @package Drupal\listings_filter
 */
class ListingsParagraphFacets {

  const DEFAULT_SEARCH_INDEX = 'site';
  const FACET_SOURCE_ID_WITHOUT_INDEX = 'listing_filter_search_api_facets:';

  /**
   * The Entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * The Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The listings_filter service.
   *
   * @var \Drupal\listings_filter\ContentListing
   */
  protected $contentListing;

  /**
   * The search_api index ID used by the JSON API facets.
   *
   * @var string
   */
  protected $searchApiIndexId;

  /**
   * The search_api index used by the JSON API facets.
   *
   * @var \Drupal\search_api\IndexInterface
   */
  protected $searchApiIndex;

  /**
   * Messenger service.
   *
   * Used to provide feedback to the user when the default/fallback search index is invalid.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface
   */
  protected $messenger;

  /**
   * ParagraphFormAmends constructor.
   *
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entity_field_manager
   *   The Entity field manager.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The Entity type manager.
   * @param \Drupal\listings_filter\ContentListing $content_listing
   *   The listings_filter service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory service.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger service.
   */
  public function __construct(EntityFieldManagerInterface $entity_field_manager,
                              EntityTypeManagerInterface $entity_type_manager,
                              ContentListing $content_listing,
                              ConfigFactoryInterface $config_factory,
                              MessengerInterface $messenger) {
    $this->entityFieldManager = $entity_field_manager;
    $this->entityTypeManager = $entity_type_manager;
    $this->contentListing = $content_listing;
    $this->messenger = $messenger;
    // Get search api index. Use fallback for backwards compatibility.
    $index = $config_factory->get('listings_filter.settings')->get('index');
    if ($index) {
      $this->searchApiIndexId = $index;
      $this->searchApiIndex = $entity_type_manager->getStorage('search_api_index')->load($index);
    }
    else {
      $this->searchApiIndexId = self::DEFAULT_SEARCH_INDEX;
      $this->searchApiIndex = $entity_type_manager->getStorage('search_api_index')->load(self::DEFAULT_SEARCH_INDEX);
    }
  }

  /**
   * Get facet options for the given listings paragraph.
   *
   * Returns options for the facets that could be used to filter
   * the content types that could appear in the results.
   * For example, the news content type, could not be filtered
   * by event type because it doesn't have the field defined.
   * Therefore the event type facet is removed as an option
   * from a news listing paragraph slice form.
   *
   * @param string $paragraphType
   *   The paragraph type to identify the available facets for.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function getFacetOptions(string $paragraphType): ?array {
    $listingParagraph = $this->contentListing->getListingParagraphFromSliceType($paragraphType);
    if (!isset($listingParagraph)) {
      return NULL;
    }

    // Check that listing paragraph can have facets added.
    $facetField = $listingParagraph->getFacetsField();
    if (!isset($facetField)) {
      return NULL;
    }

    // Get content types of any potential result.
    // Either any prefilter types, or any indexed types.
    $availableEntityTypes = $this->getResultsPotentialContentTypes($listingParagraph);

    // Build facet options.
    $availableFacets = ['_none' => '- None -'];
    foreach ($availableEntityTypes as $entityType) {
      $facetsAvailable = $this->getFacetsRelevantToContentType($entityType);
      if (isset($facetsAvailable)) {
        $availableFacets = array_merge($availableFacets, $facetsAvailable);
      }
    }

    return $availableFacets;
  }

  /**
   * Get results' potential content types.
   *
   * Calculate potential content types of
   * results. Taking into account content
   * type prefilters and search_api content
   * data source.
   *
   * @param \Drupal\listings_filter\Entity\ListingsParagraphInterface $listingParagraph
   *   Listing paragraph for which to calculate content types.
   *
   * @return array
   *   Array of possible result content types.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  protected function getResultsPotentialContentTypes(ListingsParagraphInterface $listingParagraph): array {
    $entityPrefilters = [];
    $excludedPrefilters = [];
    $prefilterValues = $listingParagraph->getPrefilterValues();
    // Gather all the prefilter inclusions and exclusions.
    foreach (['type', 'bundle'] as $filterKey) {
      $types = $this->contentListing->getListingParagraphPrefilters($filterKey, $listingParagraph);
      $operator = $prefilterValues[$filterKey]['op'] ?? 'IN';
      if (in_array($operator, ['NOT IN', '<>'], TRUE)) {
        $excludedPrefilters = array_merge($excludedPrefilters, $types);
      }
      else {
        $entityPrefilters = array_merge($entityPrefilters, $types);
      }
    }

    // If inclusive prefilters are set, return them, minus the exclusions.
    if (!empty($entityPrefilters)) {
      return array_values(array_diff($entityPrefilters, $excludedPrefilters));
    }

    // Otherwise load all indexed content types, minus the exclusions.
    $bundleSettings = [];
    foreach ($this->searchApiIndex->getDatasources() as $datasourceId => $datasource) {
      // Remove excluded types, and rebuild the array as a list.
      $bundleSettings[$datasourceId] = array_values(array_diff(array_keys($datasource->getBundles()), $excludedPrefilters));
    }

    return $bundleSettings;
  }

  /**
   * Get facets relevant to content type.
   *
   * @param array $contentType
   *   Content type.
   *
   * @return array
   *   Array of available facet options.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  protected function getFacetsRelevantToContentType($contentType): array {
    $facets = $this->entityTypeManager->getStorage('facets_facet')->loadByProperties(['facet_source_id' => self::FACET_SOURCE_ID_WITHOUT_INDEX . $this->searchApiIndexId]);
    $availableFacets = [];
    foreach ($facets as $facet) {
      $searchApiFieldIdentifier = $facet->toArray()['field_identifier'];
      $site = $this->searchApiIndex;
      $fieldsSettings = $site->get('field_settings')[$searchApiFieldIdentifier];
      $fieldName = $fieldsSettings['property_path'];
      // Get the entity type from the search api datasource.
      if (!isset($fieldsSettings['datasource_id'])) {
        continue;
      }
      $entity_type = explode(':', $fieldsSettings['datasource_id'])[1];
      $fieldDefinitions = [];
      if (is_array($contentType)) {
        foreach ($contentType as $type) {
          $fieldDefinitions += $this->entityFieldManager->getFieldDefinitions($entity_type, $type);
        }
      }
      else {
        $fieldDefinitions += $this->entityFieldManager->getFieldDefinitions($entity_type, $contentType);
      }
      if (isset($fieldDefinitions[$fieldName])) {
        $availableFacets[$facet->id()] = $facet->label();
      }
    }

    // Invoke an alter hook so other modules can alter the available facets.
    // This is useful in cases where a facet does not exist on a node such as
    // an aggregated field.
    \Drupal::moduleHandler()->alter('listings_filter_get_relevant_facets', $availableFacets, $contentType);
    return $availableFacets;
  }

  /**
   * Get search API fields available to the listings_filter index.
   *
   * @return array
   *   Array of available search API fields.
   */
  public function getSearchApiFields(): array {
    if (!$this->searchApiIndex) {
      // log an error if the index can't be found
      $link = Link::fromTextAndUrl(t('<em>listings_filter</em> settings'), Url::fromRoute('listings_filter.settings_form'))->toString();
      $this->messenger->addError(t('The search API default index %index could not be found. Please check your @link.', ['%index' => $this->searchApiIndexId, '@link' => $link]));
      // return empty array to avoid full crash
      return [];
    }
    return array_map(function($fieldDefinition) {
      return $fieldDefinition->getFieldIdentifier();
    }, $this->searchApiIndex->getFields());
  }

}
