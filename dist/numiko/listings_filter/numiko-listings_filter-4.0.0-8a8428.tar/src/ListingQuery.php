<?php

namespace Drupal\listings_filter;

use Drupal\search_api\IndexInterface;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Render\RendererInterface;
use Drupal\search_api\Item\ItemInterface;
use Drupal\search_api\Query\QueryInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\search_api\Query\ResultSetInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\facets\FacetManager\DefaultFacetManager;
use Drupal\Core\Entity\EntityDisplayRepositoryInterface;

/**
 * Listing query service for pulling together listing results.
 */
class ListingQuery {

  /**
   * The EntityTypeManagerInterface.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The Listings Configuration.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configuration;

  /**
   * The RendererInterface.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected $renderer;

  /**
   * The facet manager.
   *
   * @var \Drupal\facets\FacetManager\DefaultFacetManager
   */
  protected $facetManager;

  /**
   * The Search Index.
   *
   * @var \Drupal\search_api\IndexInterface|null
   */
  protected $searchIndex;

  /**
   * The Entity Display Repository.
   *
   * @var \Drupal\Core\Entity\EntityDisplayRepositoryInterface
   */
  protected $entityDisplayRepository;

  /**
   * The current request options.
   *
   * @var array
   */
  protected $requestOptions = [];

  /**
   * Active facets for the listing.
   *
   * @var array
   */
  protected $facets = [];

  /**
   * Constructs a new Api Controller.
   *
   * @param \Symfony\Component\HttpFoundation\RequestStack $requestStack
   *   The current request.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The renderer.
   * @param \Drupal\facets\FacetManager\DefaultFacetManager $facetManager
   *   The facet manager.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager, ConfigFactoryInterface $configFactory, RendererInterface $renderer, DefaultFacetManager $facetManager, EntityDisplayRepositoryInterface $entityDisplayRepository) {
    $this->entityTypeManager = $entityTypeManager;
    $this->configuration = $configFactory->get('listings_filter.settings');
    $this->renderer = $renderer;
    $this->facetManager = $facetManager;
    $this->entityDisplayRepository = $entityDisplayRepository;
    $this->searchIndex = $this->loadSearchIndex();
  }

  /**
   * Performs a Search API search and returns the resulting data.
   *
   * Results include the entities with their rendered markup,
   * the total count & the facets.
   *
   * Possible query parameters:
   *   page - used for pagination
   *   fulltext - used for fulltext keyword search
   *   language - used to add a language condition to the query
   *   filter-group - used to create filter groups
   *    `filter-group[rock-group][conjunction]=OR` accepts AND, OR conjunction.
   *   filter - used to create query conditions.
   *     `?filter[janis-filter][path]=field_first_name
   *       &filter[janis-filter][operator]=IN
   *       &filter[janis-filter][value]=Janis
   *   If using filter-group add a filter to the group with `memberOf`
   *       &filter[janis-filter][memberOf]=rock-group`
   *   count - to return only a count `count=1`
   *
   * @param array $settings
   *   The listing paragraph settings.
   * @param array|null $requestOptions
   *   The request options being passed to the get results method
   *   (commonly derived from the query parameters).
   *
   * @return array
   *   The results for the listing.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\search_api\SearchApiException|\Drupal\facets\Exception\InvalidProcessorException
   */
  public function getResults(array $settings, ?array $requestOptions = []) : array {
    $this->requestOptions = $requestOptions;

    $data = [
      'items' => [],
      'meta' => [
        'count' => 0,
        'facets' => [],
      ],
    ];

    $query = $this->getBaseQuery($settings);
    $query->addTag('listings_filter');

    // Get the promoted items.
    $promotedItems = [];
    $promotedResultsCount = 0;
    if ($settings['promoted']) {
      $promotedItemsQuery = clone $query;
      $promotedItemsQuery->addCondition($settings['promoted_content_field'], $settings['promoted'], 'IN');
      $promotedItemsQuery->addTag('listings_filter_promoted_items');
      $this->setPagination($promotedItemsQuery, $settings['items_per_page'], $settings['result_count'], 0);
      $promotedResults = $promotedItemsQuery->execute();

      // getResultCount() is giving the wrong result when using pagination.
      $promotedResultsCount = count($promotedItemsQuery->getResults()->getResultItems());
    }

    // Add search ID after promoted content query so that the facet conditions aren't applied.
    $query->setSearchId(strtr('listings_filter_facets:!index', ['!index' => $this->searchIndex->id()]));

    $facetQuery = clone $query;
    $facetQuery->addTag('listings_filter_facets');
    $facetQuery->execute();

    if (!$this->isCount()) {
      $data['meta']['facets'] = $this->getFacets();
    }

    // Exclude the promoted items from the standard results.
    if ($settings['promoted']) {
      $query->addCondition($settings['promoted_content_field'], $settings['promoted'], 'NOT IN');
    }

    $this->setPagination($query, $settings['items_per_page'], $settings['result_count'], $promotedResultsCount);

    $results = $query->execute();

    $this->runPreprocessResultsProcessors($results, $settings);

    // The total count should include the promoted items.
    $data['meta']['count'] = $this->getTotalCount($query, $promotedResultsCount);

    // Dont add the items and facets if we are requesting the count only.
    if (!$this->isCount()) {
      if (isset($promotedResults)) {
        $promotedItems = $this->processResults($promotedResults, $settings['promoted_display_mode']);
      }
      $items = $this->processResults($results, $settings['display_mode']);
      // Combine the promoted results and the rest of the results.
      $data['items'] = array_merge($promotedItems, $items);
    }

    $this->runPreprocessResponseDataProcessors($data, $settings);

    return $data;
  }

  /**
   * Get the cache metadata.
   *
   * Adds cache context for the search index.
   *
   * @return \Drupal\Core\Cache\CacheableMetadata
   *   The cache meta data.
   */
  public function getCacheDependencies(): CacheableMetadata {
    $metadata = new CacheableMetadata();
    // Ensure changes to the index invalidate cache.
    $metadata->addCacheableDependency($this->searchIndex);
    // Make sure the index list cache tag is present.
    $metadata->addCacheTags(['search_api_list:' . $this->searchIndex->id()]);
    return $metadata;
  }

  /**
   * Is the request only for the count.
   *
   * @return bool
   *   Whether the request contains a count param.
   */
  private function isCount(): bool {
    return (!empty($this->requestOptions['count']));
  }

  /**
   * The base query.
   *
   * @param array $settings
   *   The listing settings.
   *
   * @return \Drupal\search_api\Query\QueryInterface
   *   The search API query.
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  private function getBaseQuery(array $settings): QueryInterface {
    $query = $this->searchIndex->query();
    $this->runAlterQueryProcessors($query, $settings);
    $this->setFulltextFields($query);
    $this->setLanguage($query);
    $this->setPreFilters($query, $settings['filters']);
    $this->setFacets($query, $settings['facets']);
    $this->setSort($query, $settings['default_sorts']);

    return $query;
  }

  /**
   * Load the search index.
   *
   * @return \Drupal\search_api\IndexInterface|null
   *   The search index.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  private function loadSearchIndex(): ?IndexInterface {
    $index = $this->configuration->get('index');
    return $this->entityTypeManager->getStorage('search_api_index')->load($index);
  }

  /**
   * Set the full text search key.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   */
  private function setFulltextFields(QueryInterface &$query) {
    $fullText = (!empty($this->requestOptions['fulltext'])) ? $this->requestOptions['fulltext'] : NULL;
    if ($fullText) {
      $query->keys($fullText);
    }
  }

  /**
   * Add the prefilter conditions to the query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $conditions
   *   The conditions.
   */
  private function setPreFilters(QueryInterface &$query, array $conditions) {
    foreach ($conditions as $fieldName => $condition) {
      $query->addCondition($fieldName, $condition['value'], $condition['op']);
    }
  }

  /**
   * Add facets to the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $facets
   *   The facets to add.
   */
  private function setFacets(QueryInterface &$query, array $facets) {
    $facetsArray = [];

    foreach ($facets as $facetId => $facet) {
      $facetsArray[$facet['field']] = [
        'field' => $facet['field'],
        'limit' => $facet['limit'],
        'min_count' => $facet['min_count'],
        'operator' => $facet['operator'],
        'missing' => FALSE,
      ];

      $this->facets[$facetId] = $facetId;
    }

    $query->setOption('search_api_facets', $facetsArray);
  }

  /**
   * Set the range on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param int $itemsPerPage
   *   The number of items per page.
   * @param string|null $limitResultCount
   *   Hard limit on the number of results to return.
   * @param int $promotedItems
   *   The number of promoted items.
   */
  private function setPagination(QueryInterface &$query, int $itemsPerPage, ?string $limitResultCount, int $promotedItems, int $page = 0) {
    if (!empty($limitResultCount)) {
      $query->range(0, $limitResultCount - $promotedItems);
    }
    else {
      $page = (!empty($this->requestOptions['page'])) ? (int) $this->requestOptions['page'] : 0;
      $query->range($itemsPerPage * $page, $itemsPerPage - $promotedItems);
    }
  }

  /**
   * Set the language condition on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   */
  private function setLanguage(QueryInterface &$query) {
    $language = (!empty($this->requestOptions['language'])) ? $this->requestOptions['language'] : NULL;
    if ($language) {
      $query->setLanguages([$language]);
    }
  }

  /**
   * Set the sorts on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $defaultSorts
   *   The default sorts on the listing slice.
   */
  private function setSort(QueryInterface &$query, array $defaultSorts) {
    $sorts = (!empty($this->requestOptions['sort'])) ? $this->requestOptions['sort'] : NULL;
    if ($sorts) {
      foreach ($sorts as $sort) {
        $direction = isset($sort['direction']) ? $sort['direction'] : 'ASC';
        $query->sort($sort['path'], $direction);
      }
    }
    else {
      // Add default sorts.
      foreach ($defaultSorts as $sort) {
        $direction = isset($sort['direction']) ? $sort['direction'] : 'ASC';
        $query->sort($sort['search_key'], $direction);
      }
    }
  }

  /**
   * Processes the results.
   *
   * @param Drupal\search_api\Query\ResultSetInterface $results
   *   The results to process.
   * @param string|null $displayMode
   *   THe display mode to render.
   *
   * @return array
   *   Returns the markup for each entity.
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  private function processResults(ResultSetInterface $results, ?string $displayMode): array {
    $data = [];

    $displayMode = $this->getDisplayMode($displayMode);
    $results->preLoadResultItems();
    $result_entities = array_map(static function (ItemInterface $item) {
      return $item->getOriginalObject()->getValue();
    }, $results->getResultItems());

    foreach ($result_entities as $entity) {
      $entityType = $entity->getEntityTypeId();
      $renderArray = $this->entityTypeManager->getViewBuilder($entityType)->view($entity, $displayMode);
      $data[] = [
        'id' => $entity->uuid(),
        'bundle' => $entity->bundle(),
        'type' => $entityType,
        'markup' => $this->renderer->renderRoot($renderArray),
      ];
    }

    return $data;
  }

  /**
   * Get the total count.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param int $promotedResultsCount
   *   The promoted results count.
   *
   * @return int
   *   The count.
   */
  private function getTotalCount(QueryInterface $query, int $promotedResultsCount): int {
    return $query->getResults()->getResultCount() + $promotedResultsCount;
  }

  /**
   * Get the facets.
   *
   * @return array
   *   Returns an array of processed facets.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\facets\Exception\InvalidProcessorException
   */
  private function getFacets(): array {

    $responseFacets = [];
    $facetEntities = $this->entityTypeManager->getStorage('facets_facet')->loadMultiple($this->facets);

    foreach ($facetEntities as $facetEntity) {
      $facet_results = $this->facetManager->build($facetEntity);
      $facet_data = reset($facet_results);

      // If there are no results, the facet manager adds empty behavior render
      // array data. We need to strip that out.
      if (isset($facet_data['#type'])) {
        $facet_data = reset($facet_data);
      }

      if ($facet_data) {
        $responseFacets[] = $facet_data;
      }
    }

    return $responseFacets;
  }

  /**
   * Get the display mode.
   *
   * If a display_mode query parameter is set and the requested display mode
   * exists then this display mode is used. Otherwise fallback to the default
   * display mode set in the listings slice settings.
   *
   * @param string $displayMode
   *   The default display mode.
   *
   * @return string
   *   The display mode.
   */
  private function getDisplayMode(string $displayMode) {
    $displayModeOverride = (!empty($this->requestOptions['display_mode'])) ? $this->requestOptions['display_mode'] : NULL;
    if ($displayModeOverride) {
      $displayModes = $this->getDisplayModes();
      if (isset($displayModes[$displayModeOverride])) {
        $displayMode = $displayModeOverride;
      }
    }
    return $displayMode;
  }

  /**
   * Gets the display mode options.
   *
   * @return array
   *   The display modes.
   */
  private function getDisplayModes(): array {
    $options = [];
    $node_options = $this->entityDisplayRepository->getViewModeOptions('node');
    unset($node_options['default']);
    $options += $node_options;
    $media_options = $this->entityDisplayRepository->getViewModeOptions('media');
    unset($media_options['default']);
    $options += $media_options;
    return $options;
  }

  /**
   * Run alter_query processor stages against query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *    The query.
   * @param array $settings
   *    The listing paragraph settings.
   */
  protected function runAlterQueryProcessors(QueryInterface &$query, array $settings) {
    if (!isset($settings['processors'][ListingsProcessorInterface::STAGE_ALTER_QUERY])) {
      return;
    }
    $processors = $settings['processors'][ListingsProcessorInterface::STAGE_ALTER_QUERY];
    foreach ($processors as $processor) {
      $processor->alterQuery($query);
    }
  }

  /**
   * Run preprocess_results processor stage against results set.
   *
   * @param \Drupal\search_api\Query\ResultSetInterface $results
   *    The results.
   * @param array $settings
   *    The listing paragraph settings.
   */
  protected function runPreprocessResultsProcessors(ResultSetInterface &$results, array $settings) {
    if (!isset($settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_RESULTS])) {
      return;
    }
    $processors = $settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_RESULTS];
    foreach ($processors as $processor) {
      $processor->preprocessResults($results);
    }
  }

  /**
   * Run preprocess_response_data processor stage against response data.
   *
   * @param array $data
   *    The result data.
   * @param array $settings
   *    The listing paragraph settings.
   */
  protected function runPreprocessResponseDataProcessors(array &$data, array $settings) {
    if (!isset($settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_RESPONSE_DATA])) {
      return;
    }
    $processors = $settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_RESPONSE_DATA];
    foreach ($processors as $processor) {
      $processor->preprocessResponseData($data);
    }
  }

}
