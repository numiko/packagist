<?php

namespace Drupal\listings_filter\Controller;

use Drupal\paragraphs\Entity\Paragraph;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\listings_filter\ListingQuery;
use Drupal\search_api\SearchApiException;
use Drupal\Core\Controller\ControllerBase;
use Drupal\listings_filter\ContentListing;
use Drupal\Core\Cache\CacheableJsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Http\Exception\CacheableBadRequestHttpException;

/**
 * Class Api.
 *
 * Provides a JSON endpoint for Listing filters.
 *
 * @package Drupal\listings_filter\Controller
 */
class Api extends ControllerBase implements ContainerInjectionInterface {

  /**
   * The EntityTypeManagerInterface.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The Listing Filter Service.
   *
   * @var \Drupal\listings_filter\ContentListing
   */
  protected $listingFilter;

  /**
   * The Listings Configuration.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configuration;

  /**
   * The Listing Query Service.
   *
   * @var \Drupal\listings_filter\ListingQuery
   */
  protected $listingQuery;

  /**
   * The current request.
   *
   * @var \Symfony\Component\HttpFoundation\Request
   */
  protected $request;

  /**
   * Constructs a new Api Controller.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\listings_filter\ContentListing $listingFilter
   *   The listing filter service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   * @param \Drupal\listings_filter\ListingQuery $listingQuery
   *   The listing query service.
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The current request.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager, ContentListing $listingFilter, ConfigFactoryInterface $configFactory, ListingQuery $listingQuery, Request $request) {
    $this->entityTypeManager = $entityTypeManager;
    $this->listingFilter = $listingFilter;
    $this->configuration = $configFactory->get('listings_filter.settings');
    $this->listingQuery = $listingQuery;
    $this->request = $request;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager'),
      $container->get('listings_filter.settings'),
      $container->get('config.factory'),
      $container->get('listings_filter.query'),
      $container->get('request_stack')->getCurrentRequest(),
    );
  }

  /**
   * Performs a Search API search and returns a JSON response containing
   * entities with their rendered markup, the total count & the facets.
   *
   * Possible query parameters:
   *   page - used for pagination
   *   fulltext - used for fulltext keyword search
   *   language - used to add a language condition to the query
   *   filter-group - used to create filter groups
   *    `filter-group[rock-group][conjunction]=OR` accepts AND, OR conjunction.
   *   filter - used to create query conditions.
   *     `?filter[janis-filter][path]=field_first_name
   *       &filter[janis-filter][operator]=IN
   *       &filter[janis-filter][value]=Janis
   *   If using filter-group add a filter to the group with `memberOf`
   *       &filter[janis-filter][memberOf]=rock-group`
   *   count - to return only a count `count=1`
   *
   * @param \Drupal\paragraphs\Entity\Paragraph $paragraph
   *   The listing slice.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\search_api\SearchApiException|\Drupal\facets\Exception\InvalidProcessorException
   */
  public function get(Paragraph $paragraph) {
    $cacheability = $this->getCacheDependencies();

    // Load the settings for this listing slice.
    $settings = $this->loadListingSetting($paragraph);
    if (empty($settings)) {
      throw new CacheableBadRequestHttpException($cacheability, sprintf('The listing filter settings were not found.'));
    }

    $cacheability->merge($this->listingQuery->getCacheDependencies($settings));

    try {
      $data = $this->listingQuery->getResults($settings, $this->request->query->all());
    }
    catch (SearchApiException $exception) {
      throw new CacheableBadRequestHttpException($cacheability, $exception->getMessage());
    }

    $response = $this->createJsonResponse($data);
    $response->addCacheableDependency($cacheability);
    return $response;
  }

  /**
   * Get the cache metadata.
   *
   * Adds cache context for query parameters and the search index.
   *
   * @return \Drupal\Core\Cache\CacheableMetadata
   *   The cache meta data.
   */
  private function getCacheDependencies(): CacheableMetadata {
    $metadata = new CacheableMetadata();
    // Ensure that different pages will be cached separately.
    $metadata->addCacheContexts(['url.query_args:page']);
    $metadata->addCacheContexts(['url.query_args:filter']);
    $metadata->addCacheContexts(['url.query_args:filter-group']);
    $metadata->addCacheContexts(['url.query_args:sort']);
    return $metadata;
  }

  /**
   * Gets the listing filter settings for a paragraph.
   *
   * @param \Drupal\paragraphs\Entity\Paragraph $paragraph
   *   The paragraph entity.
   *
   * @return array
   *   The listing filter settings.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  private function loadListingSetting(Paragraph $paragraph): array {
    $listingsParagraphBundles = $this->configuration->get('paragraph_types');
    if (in_array($paragraph->bundle(), $listingsParagraphBundles)) {
      $listingsParagraphs = $this->entityTypeManager->getStorage('listings_paragraph')
        ->loadByProperties(['paragraph_type_id' => $paragraph->bundle()]);
      if (!empty($listingsParagraphs)) {
        /** @var \Drupal\listings_filter\Entity\ListingsParagraph $listingsParagraph */
        $listingsParagraph = reset($listingsParagraphs);
        return $this->listingFilter->buildListingQuerySettings($listingsParagraph, $paragraph);
      }
    }

    return [];
  }

  /**
   * Returns a CacheableJsonResponse.
   *
   * @param array $response
   *
   * @return \Drupal\Core\Cache\CacheableJsonResponse
   */
  private function createJsonResponse(array $response): CacheableJsonResponse {
    return new CacheableJsonResponse($response);
  }

}
