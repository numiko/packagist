<?php

namespace Drupal\listings_filter_test_processors;


/**
 * Provides common functionality for test plugins.
 */
trait TestPluginTrait {

  /**
   * This object's plugin type.
   *
   * @var string
   */
  protected string $pluginType;


  /**
   * Logs a method call to the site state.
   *
   * @param string $method
   *   The name of the called method.
   * @param array $args
   *   (optional) The method arguments.
   */
  protected function logMethodCall($method, array $args = []) {
    $type = $this->getPluginType();
    $state = \Drupal::state();

    // Log call.
    $key = "listings_filter_test_processors.$type.methods_called";
    $methods_called = $state->get($key, []);
    $methods_called[] = $method;
    $state->set($key, $methods_called);

    // Log arguments.
    $key = "listings_filter_test_processors.$type.method_arguments.$method";
    $state->set($key, $args);
  }

  /**
   * Retrieves the methods called on a given plugin.
   *
   * @param string $plugin_type
   *   The "short" plugin type.
   * @param bool $reset
   *   (optional) If TRUE, also clear the list of called methods for that type.
   *
   * @return string[]
   *   The methods called on the given plugin.
   */
  protected function getCalledMethods($plugin_type, $reset = TRUE) {
    $key = "listings_filter_test_processors.$plugin_type.methods_called";
    $methods = \Drupal::state()->get($key, []);
    if ($reset) {
      \Drupal::state()->delete($key);
    }
    return $methods;
  }

  /**
   * Retrieves the arguments of a certain method called on the given plugin.
   *
   * @param string $plugin_type
   *   The "short" plugin type.
   * @param string $method
   *   The method name.
   *
   * @return array
   *   The arguments of the last call to the method.
   */
  protected function getMethodArguments($plugin_type, $method) {
    $key = "listings_filter_test_processors.$plugin_type.method_arguments.$method";
    return \Drupal::state()->get($key);
  }

  /**
   * Returns the plugin type of this object.
   *
   * Equivalent to the last component of the namespace.
   *
   * @return string
   *   The "short" plugin type.
   */
  protected function getPluginType() {
    if (!isset($this->pluginType)) {
      $class = explode("\\", get_class($this));
      array_pop($class);
      $this->pluginType = array_pop($class);
    }

    return $this->pluginType;
  }

}
