<?php

namespace Drupal\listings_filter\Plugin\ListingQuery;

/**
 * Listing query DB service for pulling together listing results.
 *
 * @ListingQuery(
 *   id = "listings_filter_query_db",
 *   backend = "search_api_db",
 *   label = @Translation("DB support")
 * )
 */
class DbListingQuery extends SolrListingQuery {}
