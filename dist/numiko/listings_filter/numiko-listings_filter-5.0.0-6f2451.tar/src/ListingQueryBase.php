<?php

namespace Drupal\listings_filter;

use Drupal\search_api\IndexInterface;
use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Render\RendererInterface;
use Drupal\search_api\Item\ItemInterface;
use Drupal\search_api\Query\QueryInterface;
use Drupal\search_api\Query\ResultSetInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\facets\FacetManager\DefaultFacetManager;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Entity\EntityDisplayRepositoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Listing query service for pulling together listing results.
 */
abstract class ListingQueryBase extends PluginBase implements ListingQueryInterface, ContainerFactoryPluginInterface {

  /**
   * The Search Index.
   *
   * @var \Drupal\search_api\IndexInterface|null
   */
  protected $searchIndex;

  /**
   * The current request options.
   *
   * @var array
   */
  protected $requestOptions = [];

  /**
   * Constructs a new Api Controller.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The renderer.
   * @param \Drupal\facets\FacetManager\DefaultFacetManager $facetManager
   *   The facet manager.
   * @param \Drupal\Core\Entity\EntityDisplayRepositoryInterface $entityDisplayRepository
   *   The entity display repository.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function __construct(array $configuration,
                              $plugin_id,
                              $plugin_definition,
                              protected EntityTypeManagerInterface $entityTypeManager,
                              protected RendererInterface $renderer,
                              protected DefaultFacetManager $facetManager,
                              protected EntityDisplayRepositoryInterface $entityDisplayRepository) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('renderer'),
      $container->get('facets.manager'),
      $container->get('entity_display.repository')
    );
  }

  /**
   * Performs a Search API search and returns the resulting data.
   *
   * Results include the entities with their rendered markup,
   * the total count & the facets.
   *
   * Possible query parameters:
   *   page - used for pagination
   *   fulltext - used for fulltext keyword search
   *   language - used to add a language condition to the query
   *   filter-group - used to create filter groups
   *    `filter-group[rock-group][conjunction]=OR` accepts AND, OR conjunction.
   *   filter - used to create query conditions.
   *     `?filter[janis-filter][path]=field_first_name
   *       &filter[janis-filter][operator]=IN
   *       &filter[janis-filter][value]=Janis
   *   If using filter-group add a filter to the group with `memberOf`
   *       &filter[janis-filter][memberOf]=rock-group`
   *   count - to return only a count `count=1`
   *
   * @param array $settings
   *   The listing paragraph settings.
   * @param array|null $requestOptions
   *   The request options being passed to the get results method
   *   (commonly derived from the query parameters).
   *
   * @return array
   *   The results for the listing.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\search_api\SearchApiException|\Drupal\facets\Exception\InvalidProcessorException
   */
  abstract public function getResults(array $settings, ?array $requestOptions = []) : array;

  /**
   * Get the cache metadata.
   *
   * Adds cache context for the search index.
   *
   * @return \Drupal\Core\Cache\CacheableMetadata
   *   The cache meta data.
   */
  public function getCacheDependencies(array $settings): CacheableMetadata {
    $metadata = new CacheableMetadata();
    $this->searchIndex = $this->loadSearchIndex($settings['search_index']);
    // Ensure changes to the index invalidate cache.
    $metadata->addCacheableDependency($this->searchIndex);
    // Make sure the index list cache tag is present.
    $metadata->addCacheTags(['search_api_list:' . $this->searchIndex->id()]);
    return $metadata;
  }

  /**
   * Is the request only for the count.
   *
   * @return bool
   *   Whether the request contains a count param.
   */
  protected function isCount(): bool {
    return (!empty($this->requestOptions['count']));
  }

  /**
   * The base query.
   *
   * @param array $settings
   *   The listing settings.
   *
   * @return \Drupal\search_api\Query\QueryInterface
   *   The search API query.
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  protected function getBaseQuery(array $settings): QueryInterface {
    $query = $this->searchIndex->query();
    $this->setFulltextFields($query);
    $this->setLanguage($query);
    $this->setPreFilters($query, $settings['filters']);
    $this->runAlterQueryProcessors($query, $settings);

    return $query;
  }

  /**
   * Load the search index.
   *
   * @return \Drupal\search_api\IndexInterface|null
   *   The search index.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  protected function loadSearchIndex(string $index): ?IndexInterface {
    return $this->entityTypeManager->getStorage('search_api_index')->load($index);
  }

  /**
   * Set the full text search key.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   */
  protected function setFulltextFields(QueryInterface &$query) {
    $fullText = (!empty($this->requestOptions['fulltext'])) ? $this->requestOptions['fulltext'] : NULL;
    if ($fullText) {
      $query->keys($fullText);
    }
  }

  /**
   * Add the prefilter conditions to the query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $conditions
   *   The conditions.
   */
  protected function setPreFilters(QueryInterface &$query, array $conditions) {
    foreach ($conditions as $fieldName => $condition) {
      $query->addCondition($fieldName, $condition['value'], $condition['op']);
    }
  }

  /**
   * Set the language condition on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   */
  protected function setLanguage(QueryInterface &$query) {
    $language = (!empty($this->requestOptions['language'])) ? $this->requestOptions['language'] : NULL;
    if ($language) {
      $query->setLanguages([$language]);
    }
  }

  /**
   * Processes the results.
   *
   * @param Drupal\search_api\Query\ResultSetInterface $results
   *   The results to process.
   * @param string|null $displayMode
   *   THe display mode to render.
   *
   * @return array
   *   Returns the markup for each entity.
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  protected function processResults(ResultSetInterface $results, ?string $displayMode): array {
    $data = [];

    $displayMode = $this->getDisplayMode($displayMode);
    $results->preLoadResultItems();

    foreach ($results->getResultItems() as $item) {
      // If the item has no original object (if it has been removed from the db)
      // skip over this item.
      if (!$item->getOriginalObject(FALSE)) {
        continue;
      }
      $entity = $item->getOriginalObject()->getValue();
      $entityType = $entity->getEntityTypeId();
      $renderArray = $this->entityTypeManager->getViewBuilder($entityType)->view($entity, $displayMode);
      $data[] = [
        'id' => $entity->uuid(),
        'bundle' => $entity->bundle(),
        'type' => $entityType,
        'markup' => $this->renderer->renderRoot($renderArray),
      ];
    }

    return $data;
  }

  /**
   * Get the display mode.
   *
   * If a display_mode query parameter is set and the requested display mode
   * exists then this display mode is used. Otherwise fallback to the default
   * display mode set in the listings slice settings.
   *
   * @param string $displayMode
   *   The default display mode.
   *
   * @return string
   *   The display mode.
   */
  protected function getDisplayMode(string $displayMode) {
    $displayModeOverride = (!empty($this->requestOptions['display_mode'])) ? $this->requestOptions['display_mode'] : NULL;
    if ($displayModeOverride) {
      $displayModes = $this->getDisplayModes();
      if (isset($displayModes[$displayModeOverride])) {
        $displayMode = $displayModeOverride;
      }
    }
    return $displayMode;
  }

  /**
   * Gets the display mode options.
   *
   * @return array
   *   The display modes.
   */
  protected function getDisplayModes(): array {
    $options = [];
    $node_options = $this->entityDisplayRepository->getViewModeOptions('node');
    unset($node_options['default']);
    $options += $node_options;
    $media_options = $this->entityDisplayRepository->getViewModeOptions('media');
    unset($media_options['default']);
    $options += $media_options;
    return $options;
  }

  /**
   * Run alter_query processor stages against query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $settings
   *   The listing paragraph settings.
   */
  protected function runAlterQueryProcessors(QueryInterface &$query, array $settings) {
    if (!isset($settings['processors'][ListingsProcessorInterface::STAGE_ALTER_QUERY])) {
      return;
    }
    $processors = $settings['processors'][ListingsProcessorInterface::STAGE_ALTER_QUERY];
    foreach ($processors as $processor) {
      $processor->alterQuery($query, $settings);
    }
  }

  /**
   * Run preprocess_results processor stage against results set.
   *
   * @param \Drupal\search_api\Query\ResultSetInterface $results
   *   The results.
   * @param array $settings
   *   The listing paragraph settings.
   */
  protected function runPreprocessResultsProcessors(ResultSetInterface &$results, array $settings) {
    if (!isset($settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_RESULTS])) {
      return;
    }
    $processors = $settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_RESULTS];
    foreach ($processors as $processor) {
      $processor->preprocessResults($results, $settings);
    }
  }

  /**
   * Run preprocess_response_data processor stage against response data.
   *
   * @param array $data
   *   The result data.
   * @param array $settings
   *   The listing paragraph settings.
   */
  protected function runPreprocessResponseDataProcessors(array &$data, array $settings) {
    if (!isset($settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_RESPONSE_DATA])) {
      return;
    }
    $processors = $settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_RESPONSE_DATA];
    foreach ($processors as $processor) {
      $processor->preprocessResponseData($data, $settings);
    }
  }

}
