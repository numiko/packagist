# Override Search Index

This module adds a processor to allow specified listing paragraphs to use an
alternative search index to that specified in the listing paragraph settings.

When the processor is enabled in the listing paragraph settings and an
additional configuration can be specified to allow the non default index to be
used.

