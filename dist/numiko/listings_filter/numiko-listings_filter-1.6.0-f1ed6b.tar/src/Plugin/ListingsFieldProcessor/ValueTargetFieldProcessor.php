<?php

namespace Drupal\listings_filter\Plugin\ListingsFieldProcessor;

use Drupal\Core\Field\FieldItemList;
use Drupal\listings_filter\ListingsFieldProcessorBase;

/**
 * Provides a value field listing processor.
 *
 * @ListingsFieldProcessor(
 *   id = "value_target",
 *   name = @Translation("Value to Target"),
 *   description = @Translation("Map the value interpretation to a target ID and send to search API")
 * )
 */
class ValueTargetFieldProcessor extends ListingsFieldProcessorBase {

  /**
   * Pass value interpretation of field directly to search API as a target_id.
   */
  public function processField(FieldItemList $field) {
    $fieldValues = $field->getValue();
    array_walk($fieldValues, [$this, 'array_value_to_target_id']);
    return $fieldValues;
  }

  private function array_value_to_target_id(&$item) {
    $item = ['target_id' => $item['value']];
  }

}
