<?php

namespace Drupal\listings_filter\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Defines a data type of structured data.
 *
 * Plugin Namespace: Plugin\ListingsProcessor.
 *
 * @see \Drupal\listings_filter\ListingsProcessorManager
 * @see \Drupal\listings_filter\ListingsProcessorInterface
 * @see \Drupal\listings_filter\ListingsProcessorBase
 * @see listings_filter_processor_info_alter()
 * @see plugin_api
 *
 * @Annotation
 */
class ListingsProcessor extends Plugin {

  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

  /**
   * The label of the processor.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $label;

  /**
   * The description of the processor.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $description;

  /**
   * The stages this processor will run in, along with their default weights.
   *
   * This is represented as an associative array, mapping one or more of the
   * stage identifiers to the default weight for that stage.
   *
   * @var int[]
   */
  public $stages;

}
