<?php

namespace Drupal\listings_filter;

use Drupal\Component\Plugin\PluginInspectionInterface;

/**
 * The interface for a listings field processor.
 */
interface ListingQueryInterface extends PluginInspectionInterface {

  /**
   * Performs a Search API search and returns the resulting data.
   */
  public function getResults(array $settings, ?array $requestOptions = []) : array;

}
