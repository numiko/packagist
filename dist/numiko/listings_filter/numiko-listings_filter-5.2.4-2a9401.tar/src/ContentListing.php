<?php

namespace Drupal\listings_filter;

use Drupal\Core\Cache\Cache;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\listings_filter\Entity\ListingsParagraphInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\path_alias\AliasManagerInterface;
use Drupal\Core\Entity\TranslatableInterface;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\listings_filter\Entity\ListingsParagraph;

/**
 * Class ContentListing.
 *
 * @package Drupal\listings_filter
 */
class ContentListing {

  /**
   * The Listings Config Paragraph.
   *
   * @var \Drupal\listings_filter\Entity\ListingsParagraph
   */
  protected $listingsParagraph;

  /**
   * The Paragraph.
   *
   * @var \Drupal\paragraphs\Entity\Paragraph
   */
  protected $paragraph;

  /**
   * ContentListing constructor.
   *
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entityFieldManager
   *   The Entity field manager.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config
   *   The config factory.
   * @param \Drupal\Core\Path\CurrentPathStack $currentPath
   *   The current path.
   * @param \Drupal\path_alias\AliasManagerInterface $aliasManager
   *   The AliasManager.
   * @param \Drupal\Core\Language\LanguageManagerInterface $languageManager
   *   The language manager.
   * @param \Drupal\listings_filter\ListingsFieldProcessorManager $listingsFieldProcessorManager
   *   The listings field processor manager service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The Entity type manager.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache
   *   The listings_filter cache bin.
   * @param \Drupal\listings_filter\ListingsProcessorManager $listingsProcessorManager
   *   The listings processor manager.
   */
  public function __construct(protected EntityFieldManagerInterface $entityFieldManager,
                              protected ConfigFactoryInterface $config,
                              protected CurrentPathStack $currentPath,
                              protected AliasManagerInterface $aliasManager,
                              protected LanguageManagerInterface $languageManager,
                              protected ListingsFieldProcessorManager $listingsFieldProcessorManager,
                              protected EntityTypeManagerInterface $entityTypeManager,
                              protected CacheBackendInterface $cache,
                              protected ListingsProcessorManager $listingsProcessorManager) {
  }

  /**
   * Build the query settings object.
   *
   * @param \Drupal\listings_filter\Entity\ListingsParagraph $listings_paragraph
   *   The listings paragraph configuration.
   * @param \Drupal\paragraphs\Entity\Paragraph $paragraph
   *   The paragraph we are viewing.
   *
   * @return array
   *   The query settings object to be used to query the listing filters to
   *   return the appropriate listing results.
   *
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   */
  public function buildListingQuerySettings(ListingsParagraph $listings_paragraph, Paragraph $paragraph): array {
    $this->listingsParagraph = $listings_paragraph;
    $this->paragraph = $paragraph;
    $itemsPerPageFieldKey = $this->listingsParagraph->getItemsPerPageField();
    $resultCountFieldKey = $this->listingsParagraph->getResultCountField();
    $settings = [
      'reset_path' => $this->aliasManager->getAliasByPath($this->currentPath->getPath()),
      'items_per_page' => $this->paragraph->hasField($itemsPerPageFieldKey) ? (int) $this->paragraph->get($itemsPerPageFieldKey)->getString() : $this->listingsParagraph->getItemsPerPageValue(),
      'result_count' => $this->paragraph->hasField($resultCountFieldKey) ? $this->paragraph->get($resultCountFieldKey)->getString() : $this->listingsParagraph->getResultCountValue(),
      'default_sorts' => $this->listingsParagraph->getSortValues(),
      'user_sorts' => $this->listingsParagraph->getUserSortValues(),
      'facets' => $this->getFacets(),
      'filters' => array_merge($this->listingsParagraph->getPrefilterValues(), $this->getPreFilters()),
      'promoted' => $this->getPinnedItems(),
      'listing_id' => $paragraph->bundle(),
      'paragraph_id' => $paragraph->id(),
      'keyword' => (bool) $this->listingsParagraph->getHasKeyword(),
      'display_mode' => $this->listingsParagraph->getDisplayMode(),
      'promoted_display_mode' => $this->listingsParagraph->getPromotedDisplayMode(),
      'promoted_content_field' => $this->listingsParagraph->getPromotedContentField(),
      'processors' => $this->getProcessorInstances(),
      'search_index' => $this->config->get('listings_filter.settings')->get('index') ?? '',
    ];
    $this->runPreprocessListingQuerySettingsProcessors($settings);
    return $settings;
  }

  /**
   * Get the pre filters.
   *
   * @return array
   *   The pre filters.
   *
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   */
  private function getPreFilters(): array {
    $preFilters = [];
    foreach ($this->listingsParagraph->getPrefilterFields() as $fieldName => $definition) {
      if ($this->paragraph->hasField($fieldName) && !$this->paragraph->get($fieldName)->isEmpty()) {
        $instance = $this->listingsFieldProcessorManager->createInstance($definition['processor']);
        if ($instance) {
          $preFilters[$definition['search_key']] = $instance->processField($this->paragraph->get($fieldName));
        }
      }
    }
    return $preFilters;
  }

  /**
   * Get the facets.
   *
   * @return array
   *   The facets.
   */
  private function getFacets(): array {
    $activeFacets = [];
    $facetsFieldKey = $this->listingsParagraph->getFacetsField();
    if ($this->paragraph->hasField($facetsFieldKey)) {
      if (!$this->paragraph->get($facetsFieldKey)->isEmpty()) {
        foreach ($this->paragraph->get($facetsFieldKey)->referencedEntities() as $weight => $filter) {
          if ($filter instanceof TranslatableInterface && $filter->isTranslatable() && $filter->hasTranslation($this->languageManager->getCurrentLanguage()->getId())) {
            $filter = $filter->getTranslation($this->languageManager->getCurrentLanguage()->getId());
          }
          $activeFacets[$filter->id()] = [
            'weight' => $weight,
            'label' => $filter->label(),
            'show_only_one_result' => $filter->getShowOnlyOneResult() ? TRUE : FALSE,
            'field' => $filter->getFieldIdentifier(),
            'operator' => $filter->getQueryOperator(),
            'limit' => $filter->getHardLimit(),
            'min_count' => $filter->getMinCount(),
          ];
        }
      }
    }

    return $activeFacets;
  }

  /**
   * Get the fields on the paragraph.
   *
   * @return \Drupal\Core\Field\FieldDefinitionInterface[]
   *   Paragraph fields.
   */
  private function getFields() {
    $bundleFields = $this->entityFieldManager->getFieldDefinitions('paragraph', $this->paragraph->bundle());
    return array_filter($bundleFields, function ($field) {
      return !$field->getFieldStorageDefinition()->isBaseField();
    });
  }

  /**
   * Get the pinned content items and return the uuid.
   *
   * @return array
   *   The pinned content items.
   */
  private function getPinnedItems(): array {
    $values = [];
    $pinnedItemsFieldKey = $this->listingsParagraph->getPinnedItemsField();
    if ($this->paragraph->hasField($pinnedItemsFieldKey)) {
      foreach ($this->paragraph->get($pinnedItemsFieldKey)->referencedEntities() as $value) {
        $values[$value->uuid()] = $value->uuid();
      }
    }

    return $values;
  }

  /**
   * Get slice/paragraph types are are set as listing paragraphs.
   *
   * @return array
   *   Array of paragraph type IDs.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function getListingParagraphSliceTypes() {
    // Attempt to retrieve types from cache.
    $cachedData = $this->cache->get('listings_paragraph:paragraph_types');
    if ($cachedData) {
      $paragraphTypes = $cachedData->data;
    }
    else {
      $listingParagraphEntities =
        $this->entityTypeManager->getStorage('listings_paragraph')
          ->loadMultiple();
      $paragraphTypes = [];
      foreach ($listingParagraphEntities as $listingParagraphEntity) {
        $paragraphTypes[] = $listingParagraphEntity->get('paragraph_type_id');
      }
      // Store in cache.
      // Invalidate when a listing paragraph entity is saved.
      $this->cache->set(
        'listings_paragraph:paragraph_types',
        $paragraphTypes,
        Cache::PERMANENT,
        ['config:listings_paragraph_list']
      );
    }
    return $paragraphTypes;
  }

  /**
   * Get prefilters from listing paragraph.
   *
   * @param string $filter_key
   *   The filter key.
   * @param \Drupal\listings_filter\Entity\ListingsParagraphInterface $listingParagraph
   *   Listing paragraph.
   */
  public function getListingParagraphPrefilters(string $filter_key, ListingsParagraphInterface $listingParagraph) {
    $prefilters = $listingParagraph->getPrefilterValues();
    if (isset($prefilters[$filter_key])) {
      if (!is_array($prefilters[$filter_key]['value'])) {
        return explode(',', $prefilters[$filter_key]['value']);
      }

      return $prefilters[$filter_key]['value'];
    }
    return [];
  }

  /**
   * Get Listing paragraph entity from slice type.
   *
   * @param string $sliceType
   *   Slice type machine name.
   *
   * @return \Drupal\listings_filter\Entity\ListingsParagraphInterface|null
   *   Get the listing paragraph entity related to a slice type.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function getListingParagraphFromSliceType($sliceType) {
    /** @var \Drupal\listings_filter\Entity\ListingsParagraphInterface[] */
    $listingParagraphEntities =
      $this->entityTypeManager
        ->getStorage('listings_paragraph')
        ->loadMultiple();
    foreach ($listingParagraphEntities as $listingParagraphEntity) {
      if ($listingParagraphEntity->get('paragraph_type_id') == $sliceType) {
        return $listingParagraphEntity;
      }
    }
    return NULL;
  }

  /**
   * Get instantiated processors, in stages, sorted by weight.
   *
   * @return array
   *   Array of listing processor instances.
   */
  protected function getProcessorInstances() {
    $processors = $this->listingsParagraph->getProcessors();
    $processorInstances = [];
    foreach ($processors as $processorId => $processor) {
      $settings = $processor['settings'];
      // Some query processors need access to the fields on the slice.
      $settings['paragraph'] = $this->paragraph;
      $instance = $this->listingsProcessorManager->createInstance($processorId, $settings);
      foreach ($this->listingsProcessorManager->getProcessingStages() as $processingStageKey => $processingStageLabel) {
        if (!$instance->supportsStage($processingStageKey)) {
          continue;
        }
        $processorInstances[$processingStageKey][] = $instance;
      }
    }

    foreach ($processorInstances as $processingStageKey => &$stageProcessorInstances) {
      usort($stageProcessorInstances, function ($a, $b) use ($processingStageKey) {
        return (int) ($a->getWeight($processingStageKey) > $b->getWeight($processingStageKey));
      });
    }
    return $processorInstances;
  }

  /**
   * Run preprocess_listing_query_settings processor stage against settings.
   *
   * @param array $settings
   *   The listing paragraph settings.
   */
  protected function runPreprocessListingQuerySettingsProcessors(array &$settings) {
    if (!isset($settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_LISTING_QUERY_SETTINGS])) {
      return;
    }
    $processors = $settings['processors'][ListingsProcessorInterface::STAGE_PREPROCESS_LISTING_QUERY_SETTINGS];
    foreach ($processors as $processor) {
      $processor->preprocessListingQuerySettings($settings);
    }
  }

}
