<?php

namespace Drupal\listings_filter\Plugin\ListingQuery;

use Drupal\search_api\Query\QueryInterface;
use Drupal\listings_filter\ListingQueryBase;

/**
 * Listing query service for pulling together listing results.
 *
 * @ListingQuery(
 *   id = "listings_filter_query_solr",
 *   backend = "search_api_solr",
 *   label = @Translation("Solr support")
 * )
 */
class SolrListingQuery extends ListingQueryBase {

  /**
   * Active facets for the listing.
   *
   * @var array
   */
  protected $facets = [];

  /**
   * Performs a Search API search and returns the resulting data.
   *
   * Results include the entities with their rendered markup,
   * the total count & the facets.
   *
   * Possible query parameters:
   *   page - used for pagination
   *   fulltext - used for fulltext keyword search
   *   language - used to add a language condition to the query
   *   filter-group - used to create filter groups
   *    `filter-group[rock-group][conjunction]=OR` accepts AND, OR conjunction.
   *   filter - used to create query conditions.
   *     `?filter[janis-filter][path]=field_first_name
   *       &filter[janis-filter][operator]=IN
   *       &filter[janis-filter][value]=Janis
   *   If using filter-group add a filter to the group with `memberOf`
   *       &filter[janis-filter][memberOf]=rock-group`
   *   count - to return only a count `count=1`
   *
   * @param array $settings
   *   The listing paragraph settings.
   * @param array|null $requestOptions
   *   The request options being passed to the get results method
   *   (commonly derived from the query parameters).
   *
   * @return array
   *   The results for the listing.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\search_api\SearchApiException|\Drupal\facets\Exception\InvalidProcessorException
   */
  public function getResults(array $settings, ?array $requestOptions = []) : array {
    $this->requestOptions = $requestOptions;

    $data = [
      'items' => [],
      'meta' => [
        'count' => 0,
        'facets' => [],
      ],
    ];

    $this->searchIndex = $this->loadSearchIndex($settings['search_index']);

    $query = $this->getBaseQuery($settings);
    $query->addTag('listings_filter');

    // Get the promoted items.
    $promotedItems = [];
    $promotedResultsCount = 0;
    if ($settings['promoted']) {
      $promotedItemsQuery = clone $query;
      $promotedItemsQuery->addCondition($settings['promoted_content_field'], $settings['promoted'], 'IN');
      $promotedItemsQuery->addTag('listings_filter_promoted_items');
      $this->setPagination($promotedItemsQuery, $settings['items_per_page'], $settings['result_count'], 0);
      $promotedResults = $promotedItemsQuery->execute();

      $this->runPreprocessPromotedResultsProcessors($promotedResults, $settings);

      // getResultCount() is giving the wrong result when using pagination.
      $promotedResultsCount = count($promotedItemsQuery->getResults()->getResultItems());
    }

    // Add search ID after promoted content query so that the facet
    // conditions aren't applied.
    $query->setSearchId(strtr('listings_filter_facets:!index', ['!index' => $this->searchIndex->id()]));

    $facetQuery = clone $query;
    $facetQuery->addTag('listings_filter_facets');
    $facetQuery->execute();

    if (!$this->isCount()) {
      $data['meta']['facets'] = $this->getFacets();
    }

    // Exclude the promoted items from the standard results.
    if ($settings['promoted']) {
      $query->addCondition($settings['promoted_content_field'], $settings['promoted'], 'NOT IN');
    }

    $this->setPagination($query, $settings['items_per_page'], $settings['result_count'], $promotedResultsCount);

    $results = $query->execute();

    $this->runPreprocessResultsProcessors($results, $settings);

    // The total count should include the promoted items.
    $data['meta']['count'] = $this->getTotalCount($query, $promotedResultsCount);

    // Dont add the items and facets if we are requesting the count only.
    if (!$this->isCount()) {
      if (isset($promotedResults)) {
        $promotedItems = $this->processResults($promotedResults, $settings['promoted_display_mode']);
      }
      $items = $this->processResults($results, $settings['display_mode']);
      // Combine the promoted results and the rest of the results.
      $data['items'] = array_merge($promotedItems, $items);
    }

    $this->runPreprocessResponseDataProcessors($data, $settings, $results);

    return $data;
  }

  /**
   * The base query.
   *
   * @param array $settings
   *   The listing settings.
   *
   * @return \Drupal\search_api\Query\QueryInterface
   *   The search API query.
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  protected function getBaseQuery(array $settings): QueryInterface {
    $query = $this->searchIndex->query();
    $this->setFulltextFields($query);
    $this->setLanguage($query);
    $this->setPreFilters($query, $settings['filters']);
    $this->setFacets($query, $settings['facets']);
    $this->setSort($query, $settings['default_sorts']);
    $this->runAlterQueryProcessors($query, $settings);

    return $query;
  }

  /**
   * Add facets to the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $facets
   *   The facets to add.
   */
  protected function setFacets(QueryInterface &$query, array $facets) {
    $facetsArray = [];

    foreach ($facets as $facetId => $facet) {
      $facetsArray[$facet['field']] = [
        'field' => $facet['field'],
        'limit' => $facet['limit'],
        'min_count' => $facet['min_count'],
        'operator' => $facet['operator'],
        'missing' => FALSE,
      ];

      $this->facets[$facetId] = $facetId;
    }

    $query->setOption('search_api_facets', $facetsArray);
  }

  /**
   * Set the range on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param int $itemsPerPage
   *   The number of items per page.
   * @param string|null $limitResultCount
   *   Hard limit on the number of results to return.
   * @param int $promotedItems
   *   The number of promoted items.
   * @param int $page
   *   The page of items to display.
   */
  protected function setPagination(QueryInterface &$query, int $itemsPerPage, ?string $limitResultCount, int $promotedItems, int $page = 0) {
    if (!empty($limitResultCount)) {
      $query->range(0, $limitResultCount - $promotedItems);
    }
    else {
      $page = (!empty($this->requestOptions['page'])) ? (int) $this->requestOptions['page'] : 0;
      $query->range($itemsPerPage * $page, $itemsPerPage - $promotedItems);
    }
  }

  /**
   * Set the language condition on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   */
  protected function setLanguage(QueryInterface &$query) {
    $language = (!empty($this->requestOptions['language'])) ? $this->requestOptions['language'] : NULL;
    if ($language) {
      $query->setLanguages([$language]);
    }
  }

  /**
   * Set the sorts on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $defaultSorts
   *   The default sorts on the listing slice.
   */
  protected function setSort(QueryInterface &$query, array $defaultSorts) {
    $sorts = (!empty($this->requestOptions['sort'])) ? $this->requestOptions['sort'] : NULL;
    if ($sorts) {
      foreach ($sorts as $sort) {
        $direction = isset($sort['direction']) ? $sort['direction'] : 'ASC';
        $query->sort($sort['path'], $direction);
      }
    }
    else {
      // Add default sorts.
      foreach ($defaultSorts as $sort) {
        $direction = isset($sort['direction']) ? $sort['direction'] : 'ASC';
        $query->sort($sort['search_key'], $direction);
      }
    }
  }

  /**
   * Get the facets.
   *
   * @return array
   *   Returns an array of processed facets.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\facets\Exception\InvalidProcessorException
   */
  protected function getFacets(): array {

    $responseFacets = [];
    $facetEntities = $this->entityTypeManager->getStorage('facets_facet')->loadMultiple($this->facets);

    foreach ($facetEntities as $facetEntity) {
      $facet_results = $this->facetManager->build($facetEntity);
      $facet_data = reset($facet_results);

      // If there are no results, the facet manager adds empty behavior render
      // array data. We need to strip that out.
      if (isset($facet_data['#type'])) {
        $facet_data = reset($facet_data);
      }

      if ($facet_data) {
        $responseFacets[] = $facet_data;
      }
    }

    return $responseFacets;
  }

  /**
   * Get the total count.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param int $promotedResultsCount
   *   The promoted results count.
   *
   * @return int
   *   The count.
   */
  protected function getTotalCount(QueryInterface $query, int $promotedResultsCount): int {
    return $query->getResults()->getResultCount() + $promotedResultsCount;
  }

}
