<?php

namespace Drupal\listings_filter\Controller;

use Drupal\Core\Cache\CacheableJsonResponse;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Entity\EntityDisplayRepositoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Http\Exception\CacheableBadRequestHttpException;
use Drupal\Core\Render\RendererInterface;
use Drupal\facets\FacetManager\DefaultFacetManager;
use Drupal\listings_filter\ContentListing;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\search_api\IndexInterface;
use Drupal\search_api\Item\ItemInterface;
use Drupal\search_api\Query\QueryInterface;
use Drupal\search_api\SearchApiException;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;

/**
 * Class Api.
 *
 * Provides a JSON endpoint for Listing filters.
 *
 * @package Drupal\listings_filter\Controller
 */
class Api extends ControllerBase implements ContainerInjectionInterface {

  /**
   * The current request.
   *
   * @var \Symfony\Component\HttpFoundation\Request
   */
  protected $request;

  /**
   * The EntityTypeManagerInterface.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The Listing Filter Service.
   *
   * @var \Drupal\listings_filter\ContentListing
   */
  protected $listingFilter;

  /**
   * The Listings Configuration.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected $configuration;

  /**
   * The RendererInterface.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected $renderer;

  /**
   * The facet manager.
   *
   * @var \Drupal\facets\FacetManager\DefaultFacetManager
   */
  protected $facetManager;

  /**
   * The Search Index.
   *
   * @var \Drupal\search_api\IndexInterface|null
   */
  protected $searchIndex;

  /**
   * The Entity Display Repository.
   *
   * @var \Drupal\Core\Entity\EntityDisplayRepositoryInterface
   */
  protected $entityDisplayRepository;

  /**
   * Active facets for the listing.
   *
   * @var array
   */
  protected $facets = [];

  /**
   * Constructs a new Api Controller.
   *
   * @param \Symfony\Component\HttpFoundation\Request $request
   *   The current request.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\listings_filter\ContentListing $listingFilter
   *   The listing filter service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   * @param \Drupal\Core\Render\RendererInterface $renderer
   *   The renderer.
   * @param \Drupal\facets\FacetManager\DefaultFacetManager $facetManager
   *   The facet manager.
   * @param \Drupal\Core\Entity\EntityDisplayRepositoryInterface $entityDisplayRepository
   *   The entity display repository.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function __construct(Request $request, EntityTypeManagerInterface $entityTypeManager, ContentListing $listingFilter, ConfigFactoryInterface $configFactory, RendererInterface $renderer, DefaultFacetManager $facetManager, EntityDisplayRepositoryInterface $entityDisplayRepository) {
    $this->entityTypeManager = $entityTypeManager;
    $this->listingFilter = $listingFilter;
    $this->configuration = $configFactory->get('listings_filter.settings');
    $this->request = $request;
    $this->renderer = $renderer;
    $this->facetManager = $facetManager;
    $this->entityDisplayRepository = $entityDisplayRepository;
    $this->searchIndex = $this->loadSearchIndex();
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('request_stack')->getCurrentRequest(),
      $container->get('entity_type.manager'),
      $container->get('listings_filter.settings'),
      $container->get('config.factory'),
      $container->get('renderer'),
      $container->get('facets.manager'),
      $container->get('entity_display.repository')
    );
  }

  /**
   * Performs a Search API search and returns a JSON response containing
   * entities with their rendered markup, the total count & the facets.
   *
   * Possible query parameters:
   *   page - used for pagination
   *   fulltext - used for fulltext keyword search
   *   language - used to add a language condition to the query
   *   filter-group - used to create filter groups
   *    `filter-group[rock-group][conjunction]=OR` accepts AND, OR conjunction.
   *   filter - used to create query conditions.
   *     `?filter[janis-filter][path]=field_first_name
   *       &filter[janis-filter][operator]=IN
   *       &filter[janis-filter][value]=Janis
   *   If using filter-group add a filter to the group with `memberOf`
   *       &filter[janis-filter][memberOf]=rock-group`
   *   count - to return only a count `count=1`
   *
   * @param \Drupal\paragraphs\Entity\Paragraph $paragraph
   *   The listing slice.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\search_api\SearchApiException|\Drupal\facets\Exception\InvalidProcessorException
   */

  public function get(Paragraph $paragraph) {
    $cacheability = $this->getCacheDependencies();

    // Load the settings for this listing slice.
    $settings = $this->loadListingSetting($paragraph);
    if (empty($settings)) {
      throw new CacheableBadRequestHttpException($cacheability, sprintf('The listing filter settings were not found.'));
    }

    $response = [
      'items' => [],
      'meta' => [
        'count' => 0,
        'facets' => [],
      ],
    ];

    $query = $this->getBaseQuery($settings);
    $query->addTag('listings_filter');

    // Get the promoted items.
    $promotedItems = [];
    $promotedResultsCount = 0;
    if ($settings['promoted']) {
      $promotedItemsQuery = clone $query;
      $promotedItemsQuery->addCondition($settings['promoted_content_field'], $settings['promoted'], 'IN');
      $promotedItemsQuery->addTag('listings_filter_promoted_items');
      $this->setPagination($promotedItemsQuery, $settings['items_per_page'], $settings['result_count'], 0);
      try {
        $promotedResults = $promotedItemsQuery->execute();
      } catch (SearchApiException $exception) {
        throw new CacheableBadRequestHttpException($cacheability, $exception->getMessage());
      }

      // getResultCount() is giving the wrong result when using pagination.
      $promotedResultsCount = count($promotedItemsQuery->getResults()->getResultItems());
    }

    // The facet query needs to run without the promoted items. We are cloning
    // the query to run separately.
    $facetQuery = clone $query;
    $facetQuery->addTag('listings_filter_facets');
    $facetQuery->setSearchId(strtr('listings_filter_facets:!index', ['!index' => $this->searchIndex->id()]));
    try {
      $facetQuery->execute();
    } catch (SearchApiException $exception) {
      throw new CacheableBadRequestHttpException($cacheability, $exception->getMessage());
    }

    if (!$this->isCount()) {
      $response['meta']['facets'] = $this->getFacets();
    }

    // Exclude the promoted items from the standard results.
    if ($settings['promoted']) {
      $query->addCondition($settings['promoted_content_field'], $settings['promoted'], 'NOT IN');
    }

    $this->setPagination($query, $settings['items_per_page'], $settings['result_count'], $promotedResultsCount);

    try {
      $results = $query->execute();
    } catch (SearchApiException $exception) {
      throw new CacheableBadRequestHttpException($cacheability, $exception->getMessage());
    }

    // The total count should include the promoted items.
    $response['meta']['count'] = $this->getTotalCount($query, $promotedResultsCount);

    // Dont add the items and facets if we are requesting the count only.
    if (!$this->isCount()) {
      if (isset($promotedResults)) {
        $promotedItems = $this->processResults($promotedResults, $settings['promoted_display_mode']);
      }
      $items = $this->processResults($results, $settings['display_mode']);
      // Combine the promoted results and the rest of the results.
      $response['items'] = array_merge($promotedItems, $items);
    }

    $response = $this->createJsonResponse($response);
    $response->addCacheableDependency($cacheability);
    return $response;
  }
  /**
   * Get the cache metadata.
   *
   * Adds cache context for query parameters and the search index.
   *
   * @return \Drupal\Core\Cache\CacheableMetadata
   */
  private function getCacheDependencies(): CacheableMetadata {
    $metadata = new CacheableMetadata();
    // Ensure that different pages will be cached separately.
    $metadata->addCacheContexts(['url.query_args:page']);
    $metadata->addCacheContexts(['url.query_args:filter']);
    $metadata->addCacheContexts(['url.query_args:filter-group']);
    $metadata->addCacheContexts(['url.query_args:sort']);
    // Ensure changes to the index invalidate cache.
    $metadata->addCacheableDependency($this->searchIndex);
    // Make sure the index list cache tag is present.
    $metadata->addCacheTags(['search_api_list:' . $this->searchIndex->id()]);
    return $metadata;
  }

  /**
   * Gets the listing filter settings for a paragraph.
   *
   * @param \Drupal\paragraphs\Entity\Paragraph $paragraph
   *   The paragraph entity.
   *
   * @return array
   *   The listing filter settings.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  private function loadListingSetting(Paragraph $paragraph): array {
    $listingsParagraphBundles = $this->configuration->get('paragraph_types');
    if (in_array($paragraph->bundle(), $listingsParagraphBundles)) {
      $listingsParagraphs = $this->entityTypeManager->getStorage('listings_paragraph')
        ->loadByProperties(['paragraph_type_id' => $paragraph->bundle()]);
      if (!empty($listingsParagraphs)) {
        /** @var \Drupal\listings_filter\Entity\ListingsParagraph $listingsParagraph */
        $listingsParagraph = reset($listingsParagraphs);
        return $this->listingFilter->buildJs($listingsParagraph, $paragraph);
      }
    }

    return [];
  }

  /**
   * Is the request only for the count.
   *
   * @return boolean
   */
  private function isCount(): bool {
    return $this->request->query->get('count') ?: FALSE;
  }

  /**
   * The base query.
   *
   * @param $settings
   *   The listing settings.
   *
   * @return \Drupal\search_api\Query\QueryInterface
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  private function getBaseQuery($settings): QueryInterface {
    $query = $this->searchIndex->query();
    $this->setFulltextFields($query);
    $this->setConditions($query);
    $this->setLanguage($query);
    $this->setPreFilters($query, $settings['filters']);
    $this->setFacets($query, $settings['facets']);
    $this->setSort($query, $settings['default_sorts']);

    return $query;
  }

  /**
   * Load the search index.
   *
   * @return \Drupal\search_api\IndexInterface|null
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  private function loadSearchIndex(): ?IndexInterface {
    $index = $this->configuration->get('index');
    return $this->entityTypeManager->getStorage('search_api_index')->load($index);
  }

  /**
   * Set the full text search key.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   */
  private function setFulltextFields(QueryInterface &$query) {
    if ($fullText = $this->request->query->get('fulltext')) {
      $query->keys($fullText);
    }
  }

  /**
   * Set the conditions on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   */
  private function setConditions(QueryInterface &$query) {
    if ($conditions = $this->request->query->get('filter')) {

      // If there are any filter groups set, group these up.
      if ($groups = $this->request->query->get('filter-group')) {
        foreach ($conditions as $id => $condition) {
          if (isset($condition['memberOf'])) {
            $groups[$condition['memberOf']]['conditions'][] = $condition;
            unset($conditions[$id]);
          }
        }

        // Group queries.
        foreach ($groups as $group) {
          $condition_group = $query->createConditionGroup($group['conjunction'], []);
          foreach ($group['conditions'] as $condition) {
            $operator = isset($condition['operator']) ? $condition['operator'] : 'IN';
            $condition_group->addCondition($condition['path'], $condition['value'], $operator);
          }
          $query->addConditionGroup($condition_group);
        }
      }

      // Single query.
      foreach ($conditions as $facetId => $condition) {
        $operator = isset($condition['operator']) ? $condition['operator'] : 'IN';
        $query->addCondition($condition['path'], $condition['value'], $operator);
      }
    }
  }

  /**
   * Add the prefilter conditions to the query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $conditions
   *   The conditions.
   */
  private function setPreFilters(QueryInterface &$query, array $conditions) {
    foreach ($conditions as $fieldName => $condition) {
      $query->addCondition($fieldName, $condition['value'], $condition['op']);
    }
  }

  /**
   * Add facets to the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $facets
   *   The facets to add.
   */
  private function setFacets(QueryInterface &$query, array $facets) {
    $facetsArray = [];

    foreach ($facets as $facetId => $facet) {
      $facetsArray[$facet['field']] = [
        'field' => $facet['field'],
        'limit' => $facet['limit'],
        'min_count' => $facet['min_count'],
        'operator' => $facet['operator'],
        'missing' => FALSE,
      ];

      $this->facets[$facetId] = $facetId;
    }

    $query->setOption('search_api_facets', $facetsArray);
  }

  /**
   * Set the range on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param int $itemsPerPage
   *   The number of items per page.
   * @param string|null $limitResultCount
   *   Hard limit on the number of results to return.
   * @param int $promotedItems
   */
  private function setPagination(QueryInterface &$query, int $itemsPerPage, ?string $limitResultCount, int $promotedItems) {
    if (!empty($limitResultCount)) {
      $query->range(0, $limitResultCount - $promotedItems);
    }
    else {
      $page = $this->request->query->get('page') ?: 0;
      $query->range($itemsPerPage * $page, $itemsPerPage - $promotedItems);
    }
  }

  /**
   * Set the language condition on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   */
  private function setLanguage(QueryInterface &$query) {
    if ($language = $this->request->query->get('language')) {
      $query->setLanguages([$language]);
    }
  }

  /**
   * Set the sorts on the search query.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param array $defaultSorts
   *   The default sorts on the listing slice.
   */
  private function setSort(QueryInterface &$query, array $defaultSorts) {
    if ($sorts = $this->request->query->get('sort')) {
      foreach ($sorts as $sort) {
        $direction = isset($sort['direction']) ? $sort['direction'] : 'ASC';
        $query->sort($sort['path'], $direction);
      }
    }
    else {
      // Add default sorts.
      foreach ($defaultSorts as $sort) {
        $direction = isset($sort['direction']) ? $sort['direction'] : 'ASC';
        $query->sort($sort['search_key'], $direction);
      }
    }
  }

  /**
   * Processes the results.
   *
   * @param $results
   *   The results to process.
   * @param string|null $displayMode
   *   THe display mode to render.
   *
   * @return array
   *   Returns the markup for each entity.
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  private function processResults($results, ?string $displayMode): array {
    $data = [];

    $displayMode = $this->getDisplayMode($displayMode);
    $results->preLoadResultItems();
    $result_entities = array_map(static function (ItemInterface $item) {
      return $item->getOriginalObject()->getValue();
    }, $results->getResultItems());

    foreach ($result_entities as $entity) {
      $entityType = $entity->getEntityTypeId();
      $renderArray = $this->entityTypeManager->getViewBuilder($entityType)->view($entity, $displayMode);
      $data[] = [
        'id' => $entity->uuid(),
        'markup' => $this->renderer->renderRoot($renderArray),
      ];
    }

    return $data;
  }

  /**
   * Get the total count.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The query.
   * @param int $promotedResultsCount
   *   The promoted results count.
   *
   * @return int
   *   The count.
   */
  private function getTotalCount(QueryInterface $query, int $promotedResultsCount): int {
    return $query->getResults()->getResultCount() + $promotedResultsCount;
  }

  /**
   * Get the facets.
   *
   * @return array
   *  Returns an array of processed facets.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   * @throws \Drupal\facets\Exception\InvalidProcessorException
   */
  private function getFacets(): array {

    $responseFacets = [];
    $facetEntities = $this->entityTypeManager->getStorage('facets_facet')->loadMultiple($this->facets);

    foreach ($facetEntities as $facetEntity) {
      $facet_results = $this->facetManager->build($facetEntity);
      $facet_data = reset($facet_results);

      // If there are no results, the facet manager adds empty behavior render
      // array data. We need to strip that out.
      if (isset($facet_data['#type'])) {
        $facet_data = reset($facet_data);
      }

      if ($facet_data) {
        $responseFacets[] = $facet_data;
      }
    }

    return $responseFacets;
  }

  /**
   * Get the display mode.
   *
   * If a display_mode query parameter is set and the requested display mode
   * exists then this display mode is used. Otherwise fallback to the default
   * display mode set in the listings slice settings.
   *
   * @param string $displayMode
   *   The default display mode.
   *
   * @return string
   *   The display mode.
   */
  private function getDisplayMode(string $displayMode) {

    if ($displayModeOverride = $this->request->query->get('display_mode')) {
      $displayModes = $this->getDisplayModes();
      if (isset($displayModes[$displayModeOverride])) {
        $displayMode = $displayModeOverride;
      }
    }

    return $displayMode;
  }

  /**
   * Gets the display mode options.
   *
   * @return array
   *   The display modes.
   */
  private function getDisplayModes(): array {
    $options = [];
    $node_options = $this->entityDisplayRepository->getViewModeOptions('node');
    unset($node_options['default']);
    $options += $node_options;

    $media_options = $this->entityDisplayRepository->getViewModeOptions('media');
    unset($media_options['default']);
    $options += $media_options;

    return $options;
  }

  /**
   * Returns a CacheableJsonResponse.
   *
   * @param array $response
   *
   * @return \Drupal\Core\Cache\CacheableJsonResponse
   */
  private function createJsonResponse(array $response): CacheableJsonResponse {
    return new CacheableJsonResponse($response);
  }

}

