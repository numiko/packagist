<?php

namespace Drupal\Tests\listings_filter\Unit;

use Drupal\Core\Cache\DatabaseBackend;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\EntityReferenceFieldItemList;
use Drupal\Core\Field\FieldItemList;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\Field\Plugin\Field\FieldType\BooleanItem;
use Drupal\Core\Field\Plugin\Field\FieldType\IntegerItem;
use Drupal\Core\Language\LanguageInterface;
use Drupal\Core\Language\LanguageManager;
use Drupal\Core\Path\CurrentPathStack;
use Drupal\facets\Entity\Facet;
use Drupal\listings_filter\ContentListing;
use Drupal\listings_filter\Entity\ListingsParagraph;
use Drupal\listings_filter\ListingsFieldProcessorManager;
use Drupal\listings_filter\Plugin\ListingsFieldProcessor\GetValueFieldProcessor;
use Drupal\listings_filter\Plugin\ListingsFieldProcessor\StringFieldProcessor;
use Drupal\listings_filter\Plugin\ListingsFieldProcessor\ValueTargetFieldProcessor;
use Drupal\node\Entity\Node;
use Drupal\options\Plugin\Field\FieldType\ListStringItem;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\path_alias\AliasManagerInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\Tests\UnitTestCase;

/**
 * Class ContentListingTest.
 *
 * @group listings_filter
 * @coversDefaultClass \Drupal\listings_filter\ContentListing
 */
class ContentListingTest extends UnitTestCase {

  /**
   * Map types of field to field class.
   */
  const FIELD_TYPE_MAPPING = [
    'boolean' => BooleanItem::class,
    'entity_reference' => EntityReferenceFieldItemList::class,
    'integer' => IntegerItem::class,
    'list_string' => ListStringItem::class,
    'field_list' => FieldItemList::class,
  ];

  /**
   * The mocked entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $entityFieldManager;

  /**
   * The current path.
   *
   * @var \Drupal\Core\Path\CurrentPathStack|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $currentPath;

  /**
   * The alias manager that caches alias lookups based on the request.
   *
   * @var \Drupal\path_alias\AliasManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $aliasManager;

  /**
   * The language manager.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $languageManager;

  /**
   * The listings field processor manager service.
   *
   * @var \Drupal\listings_filter\ListingsFieldProcessorManager|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $listingsFieldProcessorManager;

  /**
   * The Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $entityTypeManager;

  /**
   * The listings_filter cache bin.
   *
   * @var \Drupal\Core\Cache\CacheBackendInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected $cache;

  /**
   * The content listing service.
   *
   * @var \Drupal\listings_filter\ContentListing
   */
  protected $contentListing;

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();
    $this->entityFieldManager = $this->getMockEntityFieldManager();
    $this->currentPath = $this->getMockCurrentPath();
    $this->aliasManager = $this->getMockAliasManager();
    $this->languageManager = $this->getMockLanguageManager();
    $this->listingsFieldProcessorManager = $this->getMockListingsFieldProcessorManager();
    $this->entityTypeManager = $this->getMockEntityTypeManager();
    $this->cache = $this->getMockCache();
    $this->contentListing = new ContentListing($this->entityFieldManager, $this->currentPath, $this->aliasManager, $this->languageManager, $this->listingsFieldProcessorManager, $this->entityTypeManager, $this->cache);
  }

  /**
   * @covers ::buildListingQuerySettings
   *
   * @dataProvider provideTestBuildJs
   */
  public function testBuildListingQuerySettings($expected, $fields) {
    $paragraphSlice = $this->getMockParagraphSlice('slice_search_listing', $fields['sliceFields']);
    $listingSlice = $this->getMockListingsParagraph($paragraphSlice, $fields['listingFields']);
    $js = $this->contentListing->buildListingQuerySettings($listingSlice, $paragraphSlice);
    $this->assertEquals($expected, $js);
  }

  /**
   * Get the mock EntityFieldManager.
   *
   * @return \Drupal\Core\Entity\EntityFieldManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   *   The EntityFieldManagerInterface.
   */
  private function getMockEntityFieldManager() {
    $entity_field_manager = $this->prophesize(EntityFieldManagerInterface::class);
    $entity_field_manager->getFieldDefinitions('paragraph', 'slice_publication_listing')->willReturn([]);
    return $entity_field_manager->reveal();
  }

  /**
   * Get mock currentPath.
   *
   * @return \Drupal\Core\Path\CurrentPathStack|\PHPUnit\Framework\MockObject\MockObject
   *   The mocked CurrentPathStack.
   */
  private function getMockCurrentPath() {
    $current_path = $this->prophesize(CurrentPathStack::class);
    $current_path->getPath()->willReturn('/node/1');
    return $current_path->reveal();
  }

  /**
   * Get mock aliasManager.
   *
   * @return \Drupal\path_alias\AliasManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   *   The mocked AliasManagerInterface.
   */
  private function getMockAliasManager() {
    $alias_manager = $this->prophesize(AliasManagerInterface::class);
    $alias_manager->getAliasByPath('/node/1')->willReturn('/search');
    return $alias_manager->reveal();
  }

  /**
   * Get mock LanguageManagerInterface.
   *
   * @return \Drupal\Core\Language\LanguageManagerInterface|\PHPUnit\Framework\MockObject\MockObject
   *   The mocked LanguageManagerInterface.
   */
  private function getMockLanguageManager() {
    $current_language = $this->prophesize(LanguageInterface::class);
    $current_language->getId()->willReturn('en');
    $language_manager = $this->prophesize(LanguageManager::class);
    $language_manager->getCurrentLanguage()->willReturn($current_language->reveal());
    return $language_manager->reveal();
  }

  private function getMockListingsFieldProcessorManager() {

    $listing_field_processor = $this->prophesize(ListingsFieldProcessorManager::class);

    $getValueProcessor = new GetValueFieldProcessor([], 'get_value', [
      'id' => "get_value",
    ]);
    $valueTargetProcessor = new ValueTargetFieldProcessor([], 'value_target', [
      'id' => "value_target",
    ]);
    $stringProcessor = new StringFieldProcessor([], 'string', [
      'id' => "string",
    ]);

    $listing_field_processor->createInstance('get_value')->willReturn($getValueProcessor);
    $listing_field_processor->createInstance('value_target')->willReturn($valueTargetProcessor);
    $listing_field_processor->createInstance('string')->willReturn($stringProcessor);
    return $listing_field_processor->reveal();
  }

  private function getMockEntityTypeManager() {
    $entity_type_manager = $this->prophesize(EntityTypeManagerInterface::class);
    return $entity_type_manager->reveal();
  }

  private function getMockCache() {
   $cache = $this->prophesize(DatabaseBackend::class);
   return $cache->reveal();
  }

  private function getMockParagraphSlice(string $bundle, array $fields) {
    $paragraph = $this->prophesize(Paragraph::class);
    $paragraph->bundle()->willReturn($bundle);
    $paragraph->id()->willReturn(1);
    foreach ($fields as $field_name => $settings) {
      $paragraph->hasField($field_name)->willReturn($settings['return']);
      $paragraph->get($field_name)->willReturn($this->getMockField($field_name, $settings['field_type'], $settings['value']));
    }

    return $paragraph->reveal();
  }

  private function getMockListingsParagraph(Paragraph $slice, $fields) {
    $listing = $this->prophesize(ListingsParagraph::class);
    $listing->getParagraphTypeId()->willReturn([]);
    $listing->getPrefilterFields()->willReturn($fields['prefilter_fields']);
    $listing->getFacetsField()->willReturn('field_facets');
    $listing->getPinnedItemsField()->willReturn('field_pinned');
    $listing->getItemsPerPageField()->willReturn('field_items_per_page');
    $listing->getItemsPerPageValue()->willReturn($fields['items_per_page']);
    $listing->getResultCountField()->willReturn('field_result_count');
    $listing->getResultCountValue()->willReturn('');
    $listing->getPrefilterValues()->willReturn($fields['prefilter_values']);
    $listing->getSortValues()->willReturn([]);
    $listing->getUserSortValues()->willReturn([]);
    $listing->getHasKeyword()->willReturn($fields['keyword']);
    $listing->getDisplayMode()->willReturn($fields['display_mode']);
    $listing->getPromotedDisplayMode()->willReturn($fields['promoted_display_mode']);
    $listing->getPromotedContentField()->willReturn($fields['promoted_content']);

    return $listing->reveal();
  }

  /**
   * Get a mock field.
   *
   * @param string $field_name
   *   The field name.
   * @param string $field_type
   *   The field type.
   * @param mixed $value
   *   The field value.
   * @param array $settings
   *   Additional field settings.
   *
   * @return object
   *   The field definition.
   */
  private function getMockField(string $field_name, string $field_type, $value, array $settings = []): object {
    $field_definition = $this->prophesize(self::FIELD_TYPE_MAPPING[$field_type]);
    $field_definition->willImplement('\Drupal\Core\Field\FieldDefinitionInterface');
    $field_definition->willImplement('\Drupal\Core\TypedData\TypedDataInterface');
    if ($field_type == 'entity_reference') {
      $field_definition->referencedEntities()->willReturn($value);
    }
    $field_definition->getValue()->willReturn($value);
    $field_definition->getString()->willReturn($value);
    $field_definition->isEmpty()->willReturn(empty($value));
    $field_definition->getFieldStorageDefinition()->willReturn($this->getMockFieldStorage($field_name, $field_type, $settings));
    return $field_definition->reveal();
  }

  /**
   * Get mock FieldStorage.
   *
   * @param string $field_name
   *   The field name.
   * @param string $field_type
   *   The field type.
   * @param array $settings
   *   Additional field settings.
   *
   * @return \Drupal\Core\Field\FieldStorageDefinitionInterface|\PHPUnit\Framework\MockObject\MockObject
   *   The FieldStorageDefinitionInterface.
   */
  private function getMockFieldStorage(string $field_name, string $field_type, array $settings) {
    $field_storage = $this->prophesize(FieldStorageDefinitionInterface::class);
    $field_storage->isBaseField()->willReturn(FALSE);
    $field_storage->getType()->willReturn($field_type);
    $field_storage->getName()->willReturn($field_name);
    foreach ($settings as $setting => $value) {
      $field_storage->getSetting($setting)->willReturn($value);
    }
    return $field_storage->reveal();
  }

  private function getMockNode($uuid) {
    $node = $this->prophesize(Node::class);
    $node->uuid()->willReturn($uuid);
    return $node->reveal();
  }

  private function mockTerm($id) {
    $term = $this->prophesize(Term::class);
    $term->id()->willReturn($id);
    return $term->reveal();
  }

  private function mockFacet($id, $label, $field) {
    $facet = $this->prophesize(Facet::class);
    $facet->id()->willReturn($id);
    $facet->label()->willReturn($label);
    $facet->getShowOnlyOneResult()->willReturn(FALSE);
    $facet->getFieldIdentifier()->willReturn($field);
    $facet->getQueryOperator()->willReturn('OR');
    $facet->getHardLimit()->willReturn('0');
    $facet->getMinCount()->willReturn('1');
    return $facet->reveal();
  }

  /**
   * Data provider for testBuildJs().
   */
  public function provideTestBuildJs() {
    return [
      [
        [
          'reset_path' => '/search',
          'items_per_page' => 24,
          'result_count' => NULL,
          'default_sorts' => [],
          'user_sorts' => [],
          'facets' => [],
          'filters' => [],
          'promoted' => [],
          'listing_id' => 'slice_search_listing',
          'paragraph_id' => 1,
          'keyword' => TRUE,
          'display_mode' => 'teaser',
          'promoted_display_mode' => 'teaser',
          'promoted_content_field' => 'uuid',
        ],
        [
          'sliceFields' => [
            'field_items_per_page' => [
              'return' => TRUE,
              'field_type' => 'integer',
              'value' => 24,
            ],
            'field_result_count' => [
              'return' => TRUE,
              'field_type' => 'integer',
              'value' => NULL,
            ],
            'field_facets' => [
              'return' => TRUE,
              'field_type' => 'entity_reference',
              'value' => [],
            ],
            'field_pinned' => [
              'return' => TRUE,
              'field_type' => 'entity_reference',
              'value' => [],
            ],
          ],
          'listingFields' => [
            'prefilter_fields' => [],
            'prefilter_values' => [],
            'keyword' => TRUE,
            'display_mode' => 'teaser',
            'promoted_display_mode' => 'teaser',
            'promoted_content' => 'uuid',
            'items_per_page' => '',
          ]
        ],
      ],
      [
        [
          'reset_path' => '/search',
          'items_per_page' => 0,
          'result_count' => 12,
          'default_sorts' => [],
          'user_sorts' => [],
          'facets' => [
            'tags' => [
              'weight' => 0,
              'label' => 'Tags',
              'show_only_one_result' => false,
              'field' => 'field_tags',
              'operator' => 'OR',
              'limit' => '0',
              'min_count' => '1',
            ],
            'type' => [
              'weight' => 1,
              'label' => 'Content type',
              'show_only_one_result' => false,
              'field' => 'type',
              'operator' => 'OR',
              'limit' => '0',
              'min_count' => '1',
            ],
          ],
          'filters' => [
            'field_tags' =>
              [
                'op' => 'IN',
                'value' =>
                  [
                    0 => 1,
                    1 => 2,
                  ],
              ],
          ],
          'promoted' => [
            'b64b70b-9a22-436b-8664-578af1e5dd97' => 'b64b70b-9a22-436b-8664-578af1e5dd97',
            '2b97c7c2-5959-4214-b07e-62b177709764' => '2b97c7c2-5959-4214-b07e-62b177709764',
          ],
          'listing_id' => 'slice_search_listing',
          'paragraph_id' => 1,
          'keyword' => TRUE,
          'display_mode' => 'teaser',
          'promoted_display_mode' => 'teaser',
          'promoted_content_field' => 'id',
        ],
        [
          'sliceFields' => [
            'field_facets' => [
              'return' => TRUE,
              'field_type' => 'entity_reference',
              'value' => [$this->mockFacet('tags', 'Tags', 'field_tags'), $this->mockFacet('type', 'Content type', 'type')],
            ],
            'field_pinned' => [
              'return' => TRUE,
              'field_type' => 'entity_reference',
              'value' => [$this->getMockNode('b64b70b-9a22-436b-8664-578af1e5dd97'), $this->getMockNode('2b97c7c2-5959-4214-b07e-62b177709764')],
            ],
            'field_items_per_page' => [
              'return' => TRUE,
              'field_type' => 'integer',
              'value' => NULL,
            ],
            'field_result_count' => [
              'return' => TRUE,
              'field_type' => 'integer',
              'value' => 12,
            ],
          ],
          'listingFields' => [
            'prefilter_fields' => [],
            'prefilter_values' => [
              'field_tags' => ['op' => 'IN', 'value' => [1,2]]
            ],
            'keyword' => TRUE,
            'display_mode' => 'teaser',
            'promoted_display_mode' => 'teaser',
            'promoted_content' => 'id',
            'items_per_page' => '',
          ]
        ],
      ],
      [
        [
          'reset_path' => '/search',
          'items_per_page' => 12,
          'result_count' => NULL,
          'default_sorts' => [],
          'user_sorts' => [],
          'facets' => [
            'tags' => [
              'weight' => 0,
              'label' => 'Tags',
              'show_only_one_result' => false,
              'field' => 'field_tags',
              'operator' => 'OR',
              'limit' => '0',
              'min_count' => '1',
            ],
          ],
          'filters' => [
            'field_tags' => [
              'op' => 'IN',
              'value' => [
                0 => 1,
                1 => 2,
              ],
            ],
            'field_status' => [
              'op' => 'IN',
              'value' => [
                0 => 1,
              ],
            ],
            'name' => [
              'op' => '=',
              'value' => 'test',
            ],
          ],
          'promoted' => [
            'f89c22e4-30b8-4602-bfc3-cccfc40befb9' => 'f89c22e4-30b8-4602-bfc3-cccfc40befb9',
            '2b97c7c2-5959-4214-b07e-62b177709764' => '2b97c7c2-5959-4214-b07e-62b177709764',
          ],
          'listing_id' => 'slice_search_listing',
          'paragraph_id' => 1,
          'keyword' => FALSE,
          'display_mode' => 'teaser',
          'promoted_display_mode' => 'promoted_teaser',
          'promoted_content_field' => 'uuid',
        ],
        [
          'sliceFields' => [
            'field_facets' => [
              'return' => TRUE,
              'field_type' => 'entity_reference',
              'value' => [$this->mockFacet('tags', 'Tags', 'field_tags')],
            ],
            'field_pinned' => [
              'return' => TRUE,
              'field_type' => 'entity_reference',
              'value' => [$this->getMockNode('f89c22e4-30b8-4602-bfc3-cccfc40befb9'), $this->getMockNode('2b97c7c2-5959-4214-b07e-62b177709764')],
            ],
            'field_items_per_page' => [
              'return' => TRUE,
              'field_type' => 'integer',
              'value' => 12,
            ],
            'field_result_count' => [
              'return' => TRUE,
              'field_type' => 'integer',
              'value' => NULL,
            ],
            'field_tags' => [
              'return' => TRUE,
              'field_type' => 'entity_reference',
              'value' => [['target_id' => 1], ['target_id' => 2]],
            ],
            'field_status' => [
              'return' => TRUE,
              'field_type' => 'field_list',
              'value' => [['value' => 1]],
            ],
            'name' => [
              'return' => TRUE,
              'field_type' => 'field_list',
              'value' => 'test',
            ]
          ],
          'listingFields' => [
            'prefilter_fields' => [
              'field_tags' => ['search_key' => 'field_tags', 'processor' => 'get_value'],
              'field_status' => ['search_key' => 'field_status', 'processor' => 'value_target'],
              'name' => ['search_key' => 'name', 'processor' => 'string'],
             ],
            'prefilter_values' => [],
            'keyword' => FALSE,
            'display_mode' => 'teaser',
            'promoted_display_mode' => 'promoted_teaser',
            'promoted_content' => 'uuid',
            'items_per_page' => '',
          ]
        ],
      ],
    ];
  }


}
