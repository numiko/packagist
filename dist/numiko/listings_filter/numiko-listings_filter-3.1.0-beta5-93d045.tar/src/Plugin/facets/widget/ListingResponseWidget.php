<?php

namespace Drupal\listings_filter\Plugin\facets\widget;

use Drupal\facets\FacetInterface;
use Drupal\facets\Result\ResultInterface;
use Drupal\facets\Widget\WidgetPluginBase;

/**
 * A simple widget class that returns for inclusion in Listing Filters.
 *
 * @FacetsWidget(
 *   id = "listings_filter",
 *   label = @Translation("Listing Filter JSON"),
 *   description = @Translation("A widget that builds an array with results. Used only for integrating into Listing Filters."),
 * )
 *
 */
class ListingResponseWidget extends WidgetPluginBase {

  /**
   * {@inheritdoc}
   */
  public function build(FacetInterface $facet) {
    $build = [
      'id' => $facet->id(),
      'label' => $facet->getName(),
      'path' => $facet->getUrlAlias(),
      'terms' => [],
    ];

    $configuration = $facet->getWidget();
    $this->showNumbers = empty($configuration['show_numbers']) ? FALSE : (bool) $configuration['show_numbers'];
    foreach ($facet->getResults() as $result) {
      $build['terms'][] = $this->generateValues($result);
    }
    return $build;
  }

  /**
   * Generates the value and the url.
   *
   * @param \Drupal\facets\Result\ResultInterface $result
   *   The result to extract the values.
   *
   * @return array
   *   The values.
   */
  protected function generateValues(ResultInterface $result) {
    $values = [
      'value' => $result->getRawValue(),
      'label' => $result->getDisplayValue(),
      'active' => $result->isActive(),
    ];

    if ($this->configuration['show_numbers']) {
      $values['count'] = (int) $result->getCount();
    }

    return $values;
  }

}
