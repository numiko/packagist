<?php

namespace Drupal\Tests\listings_filter\Kernel;

use Drupal\Core\Cache\CacheableJsonResponse;
use Drupal\Core\Datetime\Entity\DateFormat;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\KernelTests\KernelTestBase;
use Drupal\listings_filter\Entity\ListingsParagraph;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\search_api\Entity\Index;
use Drupal\search_api\Entity\Server;
use Drupal\search_api\Item\Field;
use Drupal\taxonomy\Entity\Term;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\Tests\paragraphs\FunctionalJavascript\ParagraphsTestBaseTrait;
use Drupal\user\Entity\User;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test the listings filter API.
 *
 * @group listings_filter
 */
class ListingsFilterApiTest extends KernelTestBase {

  use ParagraphsTestBaseTrait;

  /**
   * Modules to enable for this test.
   *
   * @var string[]
   */
  public static $modules = [
    'node',
    'user',
    'datetime',
    'system',
    'field',
    'entity_reference_revisions',
    'search_api',
    'search_api_db',
    'search_api_test',
    'facets',
    'paragraphs',
    'file',
    'path_alias',
    'listings_filter',
    'taxonomy',
    'filter',
    'text'
  ];

  /**
   * {@inheritdoc}
   */
  public function setUp() : void {
    parent::setUp();
    $this->installSchema('system', ['sequences']);
    $this->installSchema('node', ['node_access']);
    $this->installSchema('search_api', ['search_api_item']);

    $this->installEntitySchema('user');
    $this->installEntitySchema('node');
    $this->installEntitySchema('paragraph');
    $this->installEntitySchema('path_alias');
    $this->installEntitySchema('listings_paragraph');
    $this->installEntitySchema('facets_facet');
    $this->installEntitySchema('date_format');
    $this->installEntitySchema('taxonomy_term');
    $this->installEntitySchema('search_api_task');

    $this->installConfig(['filter', 'field', 'listings_filter', 'search_api']);

    User::create([
      'name' => '',
      'uid' => 0,
    ])->save();

    DateFormat::create([
      'id' => 'fallback',
      'label' => 'Fallback',
      'pattern' => 'Y-m-d',
    ])->save();

    Vocabulary::create([
      'name' => 'tags',
      'vid' => 'tags',
    ])->save();

    $node_type = NodeType::create(['type' => 'page', 'name' => 'page']);
    $node_type->save();
    // Add paragraphs field to node type.
    $this->addParagraphsField('page', 'field_paragraphs', 'node');
    // Create a new paragraph.
    $this->addParagraphsType('listing_slice');
    // Add the entity_reference field to node.
    $field_storage = FieldStorageConfig::create([
      'field_name' => 'field_tags',
      'entity_type' => 'node',
      'type' => 'entity_reference',
      'settings' => [
        'target_type' => 'taxonomy_term'
      ],
    ]);
    $field_storage->save();

    $field = FieldConfig::create([
      'field_storage' => $field_storage,
      'entity_type' => 'node',
      'bundle' => 'page',
      'settings' => [
        'handler' => 'default',
        'handler_settings' => [
          'target_bundles' => [
            'tags' => 'tags',
          ],
        ],
      ],
    ]);
    $field->save();

    $field_storage = FieldStorageConfig::create([
      'field_name' => 'field_tags',
      'entity_type' => 'paragraph',
      'type' => 'entity_reference',
      'settings' => [
        'target_type' => 'taxonomy_term'
      ],
    ]);
    $field_storage->save();

    $field = FieldConfig::create([
      'field_storage' => $field_storage,
      'entity_type' => 'paragraph',
      'bundle' => 'listing_slice',
      'settings' => [
        'handler' => 'default',
        'handler_settings' => [
          'target_bundles' => [
            'tags' => 'tags',
          ],
        ],
      ],
    ]);
    $field->save();

    $server = Server::create([
      'id' => 'server',
      'name' => 'Server',
      'status' => TRUE,
      'backend' => 'search_api_db',
      'backend_config' => [
        'database' => 'default:default',
      ],
    ]);
    $server->save();

    $index = Index::create([
      'id' => 'search_index',
      'name' => 'Index',
      'status' => TRUE,
      'datasource_settings' => [
        'entity:node' => [],
      ],
      'server' => 'server',
      'tracker_settings' => [
        'default' => [],
      ],
    ]);
    $index->setServer($server);
    $index->save();

    $field_tags = new Field($index, 'field_tags');
    $field_tags->setType('integer');
    $field_tags->setPropertyPath('field_tags');
    $field_tags->setDatasourceId('entity:node');
    $field_tags->setLabel('Tags');

    $field_created = new Field($index, 'created');
    $field_created->setType('date');
    $field_created->setPropertyPath('created');
    $field_created->setDatasourceId('entity:node');
    $field_created->setLabel('created');

    $index->addField($field_tags);
    $index->addField($field_created);
    $index->save();
  }

  function testListingsFilterApi() {
    $tag = Term::create(['name' => 'tag1', 'vid' => 'tags']);
    $tag->save();

    // Create a node with a paragraph.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $node = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $node->save();

    $node2 = Node::create([
      'type' => 'page',
      'title' => 'node1',
      'field_tags' => [$tag],
    ]);
    $node2->save();
    $node3 = Node::create(['type' => 'page', 'title' => 'node2']);
    $node3->save();
    $node4 = Node::create(['type' => 'page', 'title' => 'node3']);
    $node4->save();

    $this->indexItems('search_index');

    \Drupal::configFactory()
      ->getEditable('listings_filter.settings')
      ->set('paragraph_types', ['listing_slice'])
      ->set('index', 'search_index')
      ->save();

    $lisitingSlice = ListingsParagraph::create([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'prefilter_fields' => ['field_tags' => ['search_key' => 'field_tags', 'processor' => 'get_value']],
      'items_per_page_value' => 12,
      'result_count_value' => NULL,
      'display_mode' => 'teaser',
      'sort_values' => [['search_key' => 'created', 'direction' => 'asc', 'weighting' => 0]],
    ]);

    $lisitingSlice->save();

    $http_kernel = $this->container->get('http_kernel');

    $request = Request::create('/api/listing/' . $paragraph->id());
    $request->headers->set('Accept', 'application/json');
    $response = $http_kernel->handle($request);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    // Test the response. All created nodes should be in the response.
    $this->assertUuIdExistsInResponse([$node->uuid(), $node2->uuid(), $node3->uuid(), $node4->uuid()], $response);
    $this->assertResponseCountEquals(4, $response);

    // Add a prefilter to the slice.
    $paragraph->set('field_tags', [$tag])->save();

    $request = Request::create('/api/listing/' . $paragraph->id());
    $request->headers->set('Accept', 'application/json');
    $response = $http_kernel->handle($request);

    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);
    $this->assertUuIdExistsInResponse([$node2->uuid()], $response);
    $this->assertResponseCountEquals(1, $response);

    $node3->set('field_tags', [$tag])->save();

    $this->indexItems('search_index');

    $request = Request::create('/api/listing/' . $paragraph->id());
    $request->headers->set('Accept', 'application/json');
    $response = $http_kernel->handle($request);

    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);
    $this->assertUuIdExistsInResponse([$node2->uuid(), $node3->uuid()], $response);
    $this->assertResponseCountEquals(2, $response);
  }

  /**
   * Indexes all (unindexed) items on the specified index.
   *
   * @param string $index_id
   *   The ID of the index on which items should be indexed.
   *
   * @return int
   *   The number of successfully indexed items.
   */
  protected function indexItems($index_id) {
    /** @var \Drupal\search_api\IndexInterface $index */
    $index = Index::load($index_id);
    return $index->indexItems();
  }

  /**
   * Check a uuid exists in the json response.
   *
   * @param array $uuids
   *   Ids to check.
   * @param \Drupal\Core\Cache\CacheableJsonResponse $responseDocument
   */
  protected function assertUuIdExistsInResponse(array $uuids, CacheableJsonResponse $responseDocument) {
    $data = json_decode($responseDocument->getContent(), TRUE);
    $this->assertSame($uuids, array_map(static function (array $data) {
      return $data['id'];
    }, $data['items'] ));
  }

  /**
   * Check the response contains $count documents.
   *
   * @param int $count
   *   The count.
   * @param mixed $responseDocument
   *   The response.
   */
  public function assertResponseCountEquals(int $count, $responseDocument) {
    $data = json_decode($responseDocument->getContent(), TRUE);
    $this->assertCount($count, $data['items']);
  }

}
