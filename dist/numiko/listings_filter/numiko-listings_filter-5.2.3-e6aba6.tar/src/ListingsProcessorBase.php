<?php

namespace Drupal\listings_filter;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\DependencyInjection\DependencySerializationTrait;
use Drupal\Core\Form\FormStateInterface;
use Drupal\search_api\Query\QueryInterface;
use Drupal\search_api\Query\ResultSetInterface;

/**
 * The base class for the listing processor.
 *
 * Plugins extending this class need to define a plugin definition array through
 * annotation. These definition arrays may be altered through
 * hook_search_api_processor_info_alter(). The definition includes the following
 * keys:
 * - id: The unique, system-wide identifier of the processor.
 * - label: The human-readable name of the processor, translated.
 * - description: A human-readable description for the processor, translated.
 * - stages: The default weights for all stages for which the processor should
 *   run. Available stages are defined by the STAGE_* constants in
 *   ListingsProcessorInterface. This is, by default, used for supportsStage(),
 *   so if you don't provide a value here, your processor might not work as
 *   expected even though it implements the corresponding method.
 *
 * A complete plugin definition should be written as in this example:
 *
 * @code
 * @ListingsProcessor(
 *   id = "my_processor",
 *   label = @Translation("My Processor"),
 *   description = @Translation("Does … something."),
 *   stages = {
 *     "alter_configuration_form" = 0,
 *     "alter_query" = 0,
 *     "preprocess_promoted_results" = 0,
 *     "preprocess_results" = 0,
 *     "preprocess_response_data" = 0,
 *     "preprocess_listing_query_settings" = 0,
 *   }
 * )
 * @endcode
 */
abstract class ListingsProcessorBase extends PluginBase implements ListingsProcessorInterface {

  use DependencySerializationTrait;

  public function verifyPluginConfiguration() {
    return $this;
  }

  public function getId() {
    return $this->pluginDefinition['id'];
  }

  public function getLabel() {
    return $this->pluginDefinition['name'];
  }

  public function getDescription() {
    return $this->pluginDefinition['description'];
  }

  /**
   * {@inheritdoc}
   */
  public function getWeight($stage) {
    if (isset($this->configuration['weight'][$stage])) {
      return $this->configuration['weight'][$stage];
    }
    $plugin_definition = $this->getPluginDefinition();
    return (int) ($plugin_definition['stages'][$stage] ?? 0);
  }

  public function supportsStage($stage): bool {
    $plugin_definition = $this->getPluginDefinition();
    return isset($plugin_definition['stages'][$stage]);

  }
  /**
   * {@inheritdoc}
   */
  public function alterConfigurationForm(array &$form, FormStateInterface $form_state, $entity): void {}

  /**
   * {@inheritdoc}
   */
  public function alterQuery(QueryInterface &$query, array $settings = []): void {}

  /**
   * {@inheritdoc}
   */
  public function preprocessPromotedResults(ResultSetInterface &$promotedResults, array $settings = []): void {}

  /**
   * {@inheritdoc}
   */
  public function preprocessResults(ResultSetInterface &$results, array $settings = []): void {}

  /**
   * {@inheritdoc}
   */
  public function preprocessResponseData(array &$data, array $settings = [], ?ResultSetInterface $results = NULL): void {}

  /**
   * {@inheritdoc}
   */
  public function preprocessListingQuerySettings(array &$settings): void {}

}
