<?php

namespace Drupal\listings_filter;

use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\SubformStateInterface;
use Drupal\search_api\Query\QueryInterface;
use Drupal\search_api\Query\ResultSetInterface;

/**
 * The interface for a listings processor.
 *
 * Processors can act at many locations in the overall listings query process.
 * These locations are subsumed under the label "Stages" and defined by the
 * STAGE_* constants on this interface. A processor should take care to clearly
 * define for which stages it should run, in addition to implementing the
 * corresponding methods.
 */
interface ListingsProcessorInterface extends PluginInspectionInterface {

  /**
   * Processing stage: alter configuration form.
   */
  const STAGE_ALTER_CONFIGURATION_FORM = 'alter_configuration_form';

  /**
   * Processing stage: alter query.
   */
  const STAGE_ALTER_QUERY = 'alter_query';

  /**
   * Processing stage: preprocess promoted results.
   */
  const STAGE_PREPROCESS_PROMOTED_RESULTS = 'preprocess_promoted_results';

  /**
   * Processing stage: preprocess results.
   */
  const STAGE_PREPROCESS_RESULTS = 'preprocess_results';

  /**
   * Processing stage: preprocess response data.
   */
  const STAGE_PREPROCESS_RESPONSE_DATA = 'preprocess_response_data';

  /**
   * Processing stage: preprocess listing query settings.
   */
  const STAGE_PREPROCESS_LISTING_QUERY_SETTINGS
    = 'preprocess_listing_query_settings';

  /**
   * Return the configuration form for the listings processor.
   *
   * @param array $subform
   *   The form array to add the processor's configuration form to.
   * @param \Drupal\Core\Form\SubformStateInterface $processorFormState,
   *   The form state of the processor's subform.
   */
  public function buildConfigurationForm(
    array $subform,
    SubformStateInterface $processorFormState,
  ): array;

  /**
   * Alter the listings paragraph configuration form.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state object.
   * @param \Drupal\listings_filter\Entity\ListingsParagraphInterface $entity
   *   The listings paragraph entity being configured.
   */
  public function alterConfigurationForm(array &$form, FormStateInterface $form_state, $entity): void;

  /**
   * Alter a search query before execution.
   *
   * @param \Drupal\search_api\Query\QueryInterface $query
   *   The object representing the query to be executed.
   * @param array $settings
   *   The listing paragraph settings.
   */
  public function alterQuery(QueryInterface &$query, array $settings = []): void;

  /**
   * Preprocess promoted results before they are combined with standard results.
   *
   * @param \Drupal\search_api\Query\ResultSetInterface $promotedResults
   *   The promoted results.
   * @param array $settings
   *   The listing paragraph settings.
   */
  public function preprocessPromotedResults(ResultSetInterface &$promotedResults, array $settings = []): void;

  /**
   * Preprocess results before they are rendered.
   *
   * @param \Drupal\search_api\Query\ResultSetInterface $results
   *   The search results.
   * @param array $settings
   *   The listing paragraph settings.
   */
  public function preprocessResults(ResultSetInterface &$results, array $settings = []): void;

  /**
   * Preprocess response data.
   *
   * @param array $data
   *   The response data.
   * @param array $settings
   *   The listing paragraph settings.
   * @param ?Drupal\search_api\Query\ResultSetInterface $results
   *   The result set.
   */
  public function preprocessResponseData(array &$data, array $settings = [], ?ResultSetInterface $results = NULL): void;

  /**
   * Preprocess listing query settings.
   *
   * @param array $settings
   *   The settings.
   */
  public function preprocessListingQuerySettings(array &$settings): void;

  /**
   * Returns the weight for a specific processing stage.
   *
   * @param string $stage
   *   The stage whose weight should be returned.
   *
   * @return int
   *   The default weight for the given stage.
   */
  public function getWeight($stage);

  /**
   * Checks whether this processor implements a particular stage.
   *
   * @param string $stage
   *   The stage to check: one of the self::STAGE_* constants.
   *
   * @return bool
   *   TRUE if the processor runs on this particular stage; FALSE otherwise.
   */
  public function supportsStage(string $stage): bool;

}
