<?php

namespace Drupal\listings_filter;

use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Manager for ListingsProcessor.
 */
class ListingsProcessorManager extends DefaultPluginManager {

  use StringTranslationTrait;

  /**
   * Constructs an ListingsProcessor object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke the alter hook with.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct(
      'Plugin/ListingsProcessor',
      $namespaces,
      $module_handler,
      'Drupal\listings_filter\ListingsProcessorInterface',
      'Drupal\listings_filter\Annotation\ListingsProcessor'
    );
    $this->alterInfo('listings_filter_processor_info_alter');
    $this->setCacheBackend($cache_backend, 'listings_filter_processors_info_plugins');
  }

  /**
   * Get a list of processor options.
   */
  public function getProcessorOptions() {
    $processorOptions = [];
    $definitions = $this->getDefinitions();
    ksort($definitions);
    foreach ($definitions as $definition) {
      $processorOptions[$definition['id']] = $definition['name'];
    }
    return $processorOptions;
  }

  /**
   * {@inheritdoc}
   */
  public function getListingsProcessors() {
    $instances = $configuration = [];
    foreach ($this->getDefinitions() as $listingsProcessor) {
      $instance =
        $this
          ->createInstance($listingsProcessor['id'], $configuration)
          ->verifyPluginConfiguration();
      $instances[] = $instance;
    }
    return $instances;
  }

  /**
   * Retrieves information about the available processing stages.
   *
   * These are then used by processors in their "stages" definition to specify
   * in which stages they will run.
   *
   * @return array
   *   An associative array mapping stage identifiers to information about that
   *   stage. The information itself is an associative array with the following
   *   keys:
   *   - label: The translated label for this stage.
   */
  public function getProcessingStages() {
    return [
      ListingsProcessorInterface::STAGE_ALTER_CONFIGURATION_FORM => [
        'label' => $this->t('Alter configuration form'),
      ],
      ListingsProcessorInterface::STAGE_ALTER_QUERY => [
        'label' => $this->t('Alter query'),
      ],
      ListingsProcessorInterface::STAGE_PREPROCESS_PROMOTED_RESULTS => [
        'label' => $this->t('Preprocess promoted results'),
      ],
      ListingsProcessorInterface::STAGE_PREPROCESS_RESULTS => [
        'label' => $this->t('Preprocess results'),
      ],
      ListingsProcessorInterface::STAGE_PREPROCESS_RESPONSE_DATA => [
        'label' => $this->t('Preprocess response data'),
      ],
      ListingsProcessorInterface::STAGE_PREPROCESS_LISTING_QUERY_SETTINGS => [
        'label' => $this->t('Preprocess listing query settings'),
      ],
    ];
  }

}
