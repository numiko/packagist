<?php

namespace Drupal\Tests\listings_filter\Kernel;

use Drupal\Component\Serialization\Json;
use Drupal\Core\Datetime\DateFormatInterface;
use Drupal\Core\Datetime\Entity\DateFormat;
use Drupal\KernelTests\KernelTestBase;
use Drupal\Tests\listings_filter\Traits\ListingsFilterApiTrait;
use Drupal\Tests\paragraphs\FunctionalJavascript\ParagraphsTestBaseTrait;
use Drupal\facets\Entity\Facet;
use Drupal\facets\FacetInterface;
use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;
use Drupal\field\FieldConfigInterface;
use Drupal\listings_filter\Entity\ListingsParagraph;
use Drupal\listings_filter\Entity\ListingsParagraphInterface;
use Drupal\listings_filter_test_processors\Plugin\ListingsProcessor\TestListingsProcessor;
use Drupal\listings_filter_test_processors\TestPluginTrait;
use Drupal\node\Entity\Node;
use Drupal\node\Entity\NodeType;
use Drupal\node\NodeTypeInterface;
use Drupal\paragraphs\Entity\Paragraph;
use Drupal\search_api\Entity\Index;
use Drupal\search_api\Entity\Server;
use Drupal\search_api\IndexInterface;
use Drupal\search_api\Item\Field;
use Drupal\search_api\Item\FieldInterface;
use Drupal\taxonomy\Entity\Term;
use Drupal\taxonomy\Entity\Vocabulary;
use Drupal\taxonomy\VocabularyInterface;
use Drupal\user\Entity\User;
use Drupal\user\UserInterface;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test the listings filter API.
 *
 * @group listings_filter
 */
class ListingsFilterApiTest extends KernelTestBase {

  use ListingsFilterApiTrait, ParagraphsTestBaseTrait, TestPluginTrait;

  /**
   * Modules to enable for this test.
   *
   * @var string[]
   */
  protected static $modules = [
    'node',
    'user',
    'datetime',
    'system',
    'field',
    'entity_reference_revisions',
    'search_api',
    'search_api_db',
    'search_api_test',
    'facets',
    'paragraphs',
    'file',
    'path_alias',
    'listings_filter',
    'taxonomy',
    'filter',
    'text',
    'listings_filter_test_processors',
  ];

  /**
   * {@inheritdoc}
   */
  public function setUp(): void {
    parent::setUp();
    $this->installSchema('system', ['sequences']);
    $this->installSchema('node', ['node_access']);
    $this->installSchema('search_api', ['search_api_item']);

    $this->installEntitySchema('user');
    $this->installEntitySchema('node');
    $this->installEntitySchema('paragraph');
    $this->installEntitySchema('path_alias');
    $this->installEntitySchema('listings_paragraph');
    $this->installEntitySchema('facets_facet');
    $this->installEntitySchema('date_format');
    $this->installEntitySchema('taxonomy_term');
    $this->installEntitySchema('search_api_task');

    $this->installConfig([
      'filter',
      'field',
      'listings_filter',
      'search_api',
    ]);

    // Context error given if a user does not exist in the DB.
    $this->createAnonymousUser();
    // Error thrown when rendering teasers if no date format set.
    $this->createDateFormat();

    // Create tags vocab.
    $this->createVocabulary('tags');
    // Create a new content type.
    $this->createNodeType('page');
    // Add a tags field to node.
    $this->createEntityReferenceField('node', 'page', 'field_tags', 'taxonomy_term', ['tags' => 'tags']);
    // Add paragraphs field to node type.
    $this->addParagraphsField('page', 'field_paragraphs', 'node');

    // Create a new paragraph slice for the listing.
    $this->addParagraphsType('listing_slice');
    // Add tags field to listing slice.
    $this->createEntityReferenceField('paragraph', 'listing_slice', 'field_tags', 'taxonomy_term', ['tags' => 'tags']);
    // Add promoted field to listing slice.
    $this->createEntityReferenceField('paragraph', 'listing_slice', 'field_promoted', 'node', ['page' => 'page']);
    // Add facets field to listing slice.
    $this->createEntityReferenceField('paragraph', 'listing_slice', 'field_facets', 'facets_facet', []);

    // Create search server and index.
    $index = $this->createSearchIndex();
    // Add fields to the search index.
    $index->addField($this->createSearchIndexField($index, 'created', 'date'));
    $index->addField($this->createSearchIndexField($index, 'field_tags', 'integer'));
    $index->addField($this->createSearchIndexField($index, 'uuid', 'string'));
    $index->save();

    // Create facets.
    $this->createFacet('tags', 'field_tags');

    // Add the new slice as a slice in the listing settings and the new index.
    \Drupal::configFactory()
      ->getEditable('listings_filter.settings')
      ->set('paragraph_types', ['listing_slice'])
      ->set('index', 'search_index')
      ->save();
  }

  /**
   * Test the API responded with 200.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsApiResponse(): void {
    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ])->save();

    // Create the listing slice.
    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
    ]);

    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);
  }

  /**
   * Tests prefilters set in the listing settings.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsApiPrefilterValues(): void {
    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $node = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $node->save();

    $tag = Term::create([
      'name' => 'tag1',
      'vid' => 'tags',
    ]);
    $tag->save();

    $node2 = Node::create([
      'type' => 'page',
      'title' => 'node1',
      'field_tags' => [$tag],
    ]);
    $node2->save();

    $node3 = Node::create([
      'type' => 'page',
      'title' => 'node2',
    ]);
    $node3->save();

    $node4 = Node::create([
      'type' => 'page',
      'title' => 'node3',
    ]);
    $node4->save();

    $this->indexItems('search_index');

    // Create a listing slice.
    $listingSlice = $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
    ]);

    $response = $this->callListingFilterApi($paragraph);
    // Test the response. All created nodes should be in the response.
    $this->assertResultsByUuid([$node->uuid(), $node2->uuid(), $node3->uuid(), $node4->uuid()], $response);
    $this->assertResponseCountEquals(4, $response);

    // Add prefilter values to the listing settings.
    $listingSlice->set('prefilter_values',
      [
        'field_tags' => [
          'value' => [$tag->id()],
          'op' => 'IN',
        ],
      ],
    )->save();

    $response = $this->callListingFilterApi($paragraph);
    // Response will have the prefilter on tags.
    // Only node 2 should be in the response.
    $this->assertResultsByUuid([$node2->uuid()], $response);
    $this->assertResponseCountEquals(1, $response);

    $node3->set('field_tags', [$tag])->save();

    $this->indexItems('search_index');

    $response = $this->callListingFilterApi($paragraph);
    // Node 2 and 3 should both be in the response.
    $this->assertResultsByUuid([$node2->uuid(), $node3->uuid()], $response);
    $this->assertResponseCountEquals(2, $response);
  }

  /**
   * Tests prefilters set on the slice.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsApiPrefilterField(): void {
    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $node = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $node->save();

    $tag = Term::create([
      'name' => 'tag1',
      'vid' => 'tags',
    ]);
    $tag->save();

    $node2 = Node::create([
      'type' => 'page',
      'title' => 'node1',
      'field_tags' => [$tag],
    ]);
    $node2->save();

    $node3 = Node::create([
      'type' => 'page',
      'title' => 'node2',
    ]);
    $node3->save();

    $node4 = Node::create([
      'type' => 'page',
      'title' => 'node3',
    ]);
    $node4->save();

    $this->indexItems('search_index');

    // Create a listing slice with the prefilters set.
    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'prefilter_fields' => [
        'field_tags' => [
          'search_key' => 'field_tags',
          'processor' => 'get_value',
        ],
      ],
    ]);

    $response = $this->callListingFilterApi($paragraph);
    // Test the response. All created nodes should be in the response.
    $this->assertResultsByUuid([$node->uuid(), $node2->uuid(), $node3->uuid(), $node4->uuid()], $response);
    $this->assertResponseCountEquals(4, $response);

    // Add prefilter values to the slice.
    $paragraph->set('field_tags', [$tag])->save();

    $response = $this->callListingFilterApi($paragraph);
    // Response will have the prefilter on tags.
    // Only node 2 should be in the response.
    $this->assertResultsByUuid([$node2->uuid()], $response);
    $this->assertResponseCountEquals(1, $response);

    $node3->set('field_tags', [$tag])->save();

    $this->indexItems('search_index');

    $response = $this->callListingFilterApi($paragraph);
    // Node 2 and 3 should both be in the response.
    $this->assertResultsByUuid([$node2->uuid(), $node3->uuid()], $response);
    $this->assertResponseCountEquals(2, $response);
  }

  /**
   * Test the pagination.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsApiPagination(): void {

    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $node = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $node->save();

    $listingSlice = $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'sort_values' => [['search_key' => 'created', 'direction' => 'asc', 'weighting' => 0]],
    ]);

    $x = 1;
    while ($x <= 60) {
      Node::create([
        'type' => 'page',
        'title' => 'node' . $x,
      ])->save();
      $x++;
    }

    $this->indexItems('search_index');

    $response = $this->callListingFilterApi($paragraph);
    // Default set to 50.
    $this->assertResponseCountEquals(50, $response);
    $this->assertResponseTotalEquals(61, $response);

    // Set to 12 items per page.
    $listingSlice->set('items_per_page_value', 12)->save();

    $response = $this->callListingFilterApi($paragraph);
    $this->assertResponseCountEquals(12, $response);

    // 12 items per page, 61 nodes in the results the last past should only contain 1.
    $response = $this->callListingFilterApi($paragraph, ['page' => 0]);
    $this->assertResponseCountEquals(12, $response);
    $response = $this->callListingFilterApi($paragraph, ['page' => 2]);
    $this->assertResponseCountEquals(12, $response);
    $response = $this->callListingFilterApi($paragraph, ['page' => 5]);
    $this->assertResponseCountEquals(1, $response);

    $listingSlice->set('items_per_page_value', 24)->save();
    $response = $this->callListingFilterApi($paragraph);
    $this->assertResponseCountEquals(24, $response);
  }

  /**
   * Test the result count value.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsApiResultCount(): void {
    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $node = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $node->save();

    $listingSlice = $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
    ]);

    $x = 1;
    while ($x <= 10) {
      Node::create([
        'type' => 'page',
        'title' => 'node' . $x,
      ])->save();
      $x++;
    }

    $this->indexItems('search_index');

    $response = $this->callListingFilterApi($paragraph);
    // Should be returning everything.
    $this->assertResponseCountEquals(11, $response);

    $listingSlice->set('result_count_value', 5)->save();
    $response = $this->callListingFilterApi($paragraph);
    $this->assertResponseCountEquals(5, $response);

    $listingSlice->set('result_count_value', 1)->save();
    $response = $this->callListingFilterApi($paragraph);
    $this->assertResponseCountEquals(1, $response);
  }

  /**
   * Test the facets.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsApiFacets(): void {
    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $node = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $node->save();

    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'facets_field' => 'field_facets',
    ]);

    // Set the facet and check the response contains the facet.
    $paragraph->set('field_facets', [['target_id' => 'tags']])->save();

    $tag = Term::create([
      'name' => 'tag1',
      'vid' => 'tags',
    ]);
    $tag->save();

    $tag2 = Term::create([
      'name' => 'tag2',
      'vid' => 'tags',
    ]);
    $tag2->save();

    $tag3 = Term::create([
      'name' => 'tag3',
      'vid' => 'tags',
    ]);
    $tag3->save();

    $node2 = Node::create([
      'type' => 'page',
      'title' => 'node1',
      'field_tags' => [$tag],
    ]);
    $node2->save();

    $node3 = Node::create([
      'type' => 'page',
      'title' => 'node2',
      'field_tags' => [$tag, $tag2],
    ]);
    $node3->save();

    $node4 = Node::create([
      'type' => 'page',
      'title' => 'node3',
      'field_tags' => [$tag3],
    ]);
    $node4->save();

    $this->indexItems('search_index');

    $response = $this->callListingFilterApi($paragraph, [
      'filter' => [
        'tags' => [
          'path' => 'field_tags',
          'operator' => 'IN',
          'value' => [$tag->id()],
        ],
      ],
    ]);
    $this->assertResultsByUuid([$node2->uuid(), $node3->uuid()], $response);
    $this->assertUuidNotExistsInResponse($node4->uuid(), $response);
    $this->assertFacetTermActive('tags', $tag->id(), $response);
  }

  /**
   * Test the promoted items.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsApiPromotedItems(): void {
    $node2 = Node::create([
      'type' => 'page',
      'title' => 'node1',
    ]);
    $node2->save();

    $node3 = Node::create([
      'type' => 'page',
      'title' => 'node2',
    ]);
    $node3->save();

    $node4 = Node::create([
      'type' => 'page',
      'title' => 'node3',
    ]);
    $node4->save();

    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
      'field_promoted' => [$node4],
    ]);
    $paragraph->save();

    $node = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $node->save();

    $this->indexItems('search_index');

    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'pinned_items_field' => 'field_promoted',
      'promoted_display_mode' => 'teaser',
      'promoted_content_field' => 'uuid',
    ]);

    $response = $this->callListingFilterApi($paragraph);
    // Test the response. Node 4 should be first.
    $this->assertResultsByUuid([$node4->uuid(), $node2->uuid(), $node3->uuid(), $node->uuid()], $response);
    $this->assertResponseCountEquals(4, $response);
  }

  /**
   * Test that all stage methods are called in a fully implemented Processor.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsProcessorStagesExecuted(): void {
    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ])->save();

    // Create the listing slice.
    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'processors' => [
        'listings_filter_test_processor' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'alter_query' => 0,
              'preprocess_results' => 0,
              'preprocess_response_data' => 0,
              'preprocess_listing_query_settings' => 0,
            ],
          ],
        ],
      ],
    ]);

    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    // Get the method calls, logged to state in TestListingsProcessor.
    $processorMethodsCalled =
      \Drupal::state()->get('listings_filter_test_processors.ListingsProcessor.methods_called');
    $this->assertEquals(
      [
        'preprocessListingQuerySettings',
        'alterQuery',
        'preprocessResults',
        'preprocessResponseData',
      ],
      $processorMethodsCalled
    );
  }

  /**
   * Test that alter query method in a listings_filter processor alters query.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsProcessorAlterQueryAffectsResults(): void {
    $node1 = Node::create([
      'type' => 'page',
      'title' => 'node1',
    ]);
    $node1->save();

    $node2 = Node::create([
      'uuid' => TestListingsProcessor::TEST_NODE_UUID,
      'type' => 'page',
      'title' => 'node2',
    ]);
    $node2->save();

    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $listingNode = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $listingNode->save();

    $this->indexItems('search_index');

    // Create the listing slice.
    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'processors' => [
        'listings_filter_test_processor' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'alter_query' => 0,
              'preprocess_results' => 0,
              'preprocess_response_data' => 0,
              'preprocess_listing_query_settings' => 0,
            ],
          ],
        ],
      ],
    ]);

    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    // Test the response. Node 2 should be excluded as per the processor implementation.
    $this->assertResultsByUuid([$node1->uuid(), $listingNode->uuid()], $response);
    $this->assertUuidNotExistsInResponse($node2->uuid(), $response);
  }

  /**
   * Test that preprocess response data method in a listings_filter changes the response data.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsProcessorPreprocessResponseDataAffectsResults(): void {
    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $listingNode = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $listingNode->save();

    $this->indexItems('search_index');

    // Create the listing slice.
    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'processors' => [
        'listings_filter_test_processor' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'alter_query' => 0,
              'preprocess_results' => 0,
              'preprocess_response_data' => 0,
              'preprocess_listing_query_settings' => 0,
            ],
          ],
        ],
      ],
    ]);

    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    $responseData = json_decode($response->getContent(), TRUE);
    $this->assertEquals('listings_filter_test_processor', $responseData['test_data']['listings_filter_test_processor']);
    $this->assertEquals('test_flag_data', $responseData['test_flag']);
  }

  /**
   * Test that preprocess_results method in a listings_filter processes results.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsProcessorPreprocessResultsAffectsResults(): void {
    $node1 = Node::create([
      'type' => 'page',
      'title' => 'node1',
    ]);
    $node1->save();

    $node2 = Node::create([
      'nid' => TestListingsProcessor::TEST_NODE_ID,
      'type' => 'page',
      'title' => 'node2',
    ]);
    $node2->save();

    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $listingNode = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $listingNode->save();

    $this->indexItems('search_index');

    // Create the listing slice.
    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'processors' => [
        'listings_filter_test_processor' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'alter_query' => 0,
              'preprocess_results' => 0,
              'preprocess_response_data' => 0,
              'preprocess_listing_query_settings' => 0,
            ],
          ],
        ],
      ],
    ]);

    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    // Test the response. Node 2 should be excluded as per the processor implementation.
    $this->assertResultsByUuid([$node1->uuid(), $listingNode->uuid()], $response);
    $this->assertUuidNotExistsInResponse($node2->uuid(), $response);
  }

  /**
   * Test that preprocess_promoted_results method processes promoted results.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsProcessorPreprocessPromotedResultsAffectsResults(): void {
    $node1 = Node::create([
      'type' => 'page',
      'title' => 'node1',
    ]);
    $node1->save();

    $node2 = Node::create([
      'type' => 'page',
      'title' => 'node2',
    ]);
    $node2->save();

    $node3 = Node::create([
      'nid' => TestListingsProcessor::TEST_NODE_ID,
      'type' => 'page',
      'title' => 'node3',
    ]);
    $node3->save();

    $node4 = Node::create([
      'type' => 'page',
      'title' => 'node4',
    ]);
    $node4->save();

    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
      'field_promoted' => [$node3, $node4],
    ]);
    $paragraph->save();

    $listingNode = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $listingNode->save();

    $this->indexItems('search_index');

    // Create the listing slice.
    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'processors' => [
        'listings_filter_test_processor' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'alter_query' => 0,
              'preprocess_results' => 0,
              'preprocess_response_data' => 0,
              'preprocess_listing_query_settings' => 0,
            ],
          ],
        ],
      ],
    ]);

    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    // Test the response. Node 2 should be excluded as per the processor implementation.
    $this->assertResultsByUuid([$node1->uuid(), $node2->uuid(), $node4->uuid(), $listingNode->uuid()], $response);
    $this->assertUuidNotExistsInResponse($node3->uuid(), $response);
  }

  /**
   * Test that ListingProcessor stages are executed according to weight.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsProcessorStagesAreExecutedAccordingToWeight(): void {
    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();

    $listingNode = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $listingNode->save();

    $this->indexItems('search_index');

    // Create the listing slice.
    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'processors' => [
        'listings_filter_test_processor' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'alter_query' => 0,
              'preprocess_results' => 0,
              'preprocess_response_data' => 0,
              'preprocess_listing_query_settings' => 0,
            ],
          ],
        ],
        'listings_filter_test_processor_two' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'alter_query' => 0,
              'preprocess_results' => 0,
              'preprocess_response_data' => -1,
              'preprocess_listing_query_settings' => 0,
            ],
          ],
        ],
      ],
    ]);

    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    $responseData = Json::decode($response->getContent());
    // Assert that the listings_filter_test_processor_two test_data was added first.
    $this->assertEquals(
      [
        'listings_filter_test_processor_two' => 'listings_filter_test_processor_two',
        'listings_filter_test_processor' => 'listings_filter_test_processor',
      ], $responseData['test_data']);
  }

  /**
   * Test that ListingProcessor functions contain the settings.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsProcessorSettingsArrayIsPresent(): void {
    // Create the listing node.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
    ]);
    $paragraph->save();
    $paragraph_id = $paragraph->id();

    $listingNode = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $listingNode->save();

    $this->indexItems('search_index');

    // Create the listing slice.
    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'processors' => [
        'listings_filter_test_processor' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'alter_query' => 0,
              'preprocess_results' => 0,
              'preprocess_response_data' => 0,
              'preprocess_listing_query_settings' => 0,
            ],
          ],
        ],
      ],
    ]);
    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    $responseData = Json::decode($response->getContent());
    $this->assertEquals($paragraph_id, $responseData['test_settings']);
  }

  /**
   * Test that alterConfigurationForm stage is executed during form processing.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsProcessorAlterConfigurationFormStageExecuted(): void {
    // Create a listings paragraph entity with the test processor enabled.
    $listingsEntity = $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'processors' => [
        'listings_filter_test_processor' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'alter_configuration_form' => 0,
            ],
          ],
        ],
      ],
    ]);

    // Mock the form state.
    $form_state = $this->createMock(\Drupal\Core\Form\FormStateInterface::class);

    // Create a basic form array.
    $form = [
      'existing_field' => [
        '#type' => 'textfield',
        '#title' => 'Existing Field',
      ],
    ];

    // Create the form handler and call the processors alter method.
    $form_handler = \Drupal::entityTypeManager()
      ->getFormObject('listings_paragraph', 'edit')
      ->setEntity($listingsEntity);

    // Use reflection to call the protected method.
    $reflectionClass = new \ReflectionClass($form_handler);
    $method = $reflectionClass->getMethod('processorsAlterConfigurationForm');
    $method->setAccessible(TRUE);
    $method->invokeArgs($form_handler, [&$form, $form_state]);

    // Verify that the test processor added its field to the form.
    $this->assertArrayHasKey('test_configuration_form_field', $form);
    $this->assertEquals('textfield', $form['test_configuration_form_field']['#type']);
    $this->assertEquals('Test Configuration Form Field', $form['test_configuration_form_field']['#title']);
    $this->assertEquals('test_value_from_processor', $form['test_configuration_form_field']['#default_value']);

    // Verify that the method was called by checking the state.
    $processorMethodsCalled = \Drupal::state()->get('listings_filter_test_processors.ListingsProcessor.methods_called');
    $this->assertContains('alterConfigurationForm', $processorMethodsCalled);

    // Verify the arguments passed to the method.
    $methodArguments = \Drupal::state()->get('listings_filter_test_processors.ListingsProcessor.method_arguments.alterConfigurationForm');
    $this->assertIsArray($methodArguments);
    $this->assertCount(3, $methodArguments);
    $this->assertInstanceOf(\Drupal\Core\Form\FormStateInterface::class, $methodArguments[1]);
    $this->assertInstanceOf(\Drupal\listings_filter\Entity\ListingsParagraphInterface::class, $methodArguments[2]);
  }

  /**
   * Test that the promoted items are sorted by their order in 'field_promoted'.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function testListingsProcessorSortPinnedItemsByWeight(): void {
    // Create nodes to be used as promoted items.
    $node1 = Node::create([
      'type' => 'page',
      'title' => 'node1',
    ]);
    $node1->save();

    $node2 = Node::create([
      'type' => 'page',
      'title' => 'node2',
    ]);
    $node2->save();

    $node3 = Node::create([
      'type' => 'page',
      'title' => 'node3',
    ]);
    $node3->save();

    // Create a paragraph and assign promoted nodes in a specific order.
    $paragraph = Paragraph::create([
      'type' => 'listing_slice',
      'field_promoted' => [$node2, $node3, $node1],
    ]);
    $paragraph->save();

    $listingNode = Node::create([
      'title' => 'Listing',
      'type' => 'page',
      'field_paragraphs' => [
        $paragraph,
      ],
    ]);
    $listingNode->save();

    $this->indexItems('search_index');

    $this->createListingsParagraphEntity([
      'id' => 'listing_slice',
      'label' => 'Listing slice',
      'paragraph_type_id' => 'listing_slice',
      'pinned_items_field' => 'field_promoted',
      'promoted_display_mode' => 'teaser',
      'promoted_content_field' => 'uuid',
      'processors' => [
        'sort_pinned_items_by_weight' => [
          'status' => 1,
          'settings' => [
            'weight' => [
              'preprocess_promoted_results' => 0,
            ],
          ],
        ],
      ],
    ]);

    // Call the API and get the response.
    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    // Validate that the nodes are returned in the correct order.
    $this->assertResultsByUuid([
      $node2->uuid(),
      $node3->uuid(),
      $node1->uuid(),
      $listingNode->uuid(),
    ], $response);

    // Update the paragraph with a different order in 'field_promoted'.
    $paragraph->set('field_promoted', [$node1, $node3, $node2]);
    $paragraph->save();

    $response = $this->callListingFilterApi($paragraph);
    $this->assertEquals($response->getStatusCode(), Response::HTTP_OK);

    $this->assertResultsByUuid([
      $node1->uuid(),
      $node3->uuid(),
      $node2->uuid(),
      $listingNode->uuid(),
    ], $response);
  }

  /**
   * Creates an anonymous user.
   *
   * @return \Drupal\user\UserInterface
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function createAnonymousUser(): UserInterface {
    $user = User::create([
      'name' => 'anonymous',
      'uid' => 0,
    ]);
    $user->save();

    return $user;
  }

  /**
   * Creates a date format.
   *
   * @return \Drupal\Core\Datetime\DateFormatInterface
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function createDateFormat(): DateFormatInterface {
    $dateFormat = DateFormat::create([
      'id' => 'fallback',
      'label' => 'Fallback',
      'pattern' => 'Y-m-d',
    ]);
    $dateFormat->save();

    return $dateFormat;
  }

  /**
   * Creates a vocabulary.
   *
   * @param string $id
   *   The vid.
   *
   * @return \Drupal\taxonomy\VocabularyInterface
   *   The vocabulary.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function createVocabulary(string $id): VocabularyInterface {
    $vocabulary = Vocabulary::create([
      'name' => $id,
      'vid' => $id,
    ]);
    $vocabulary->save();

    return $vocabulary;
  }

  /**
   * Creates a node content type.
   *
   * @param string $id
   *   The id of the content type.
   *
   * @return \Drupal\node\NodeTypeInterface
   *   The created content type.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function createNodeType(string $id): NodeTypeInterface {
    $nodeType = NodeType::create([
      'type' => $id,
      'name' => $id,
    ]);
    $nodeType->save();

    return $nodeType;
  }

  /**
   * Creates an entity reference field.
   *
   * @param string $entityType
   *   The entity type.
   * @param string $bundle
   *   The bundle.
   * @param string $fieldName
   *   The field name.
   * @param string $targetType
   *   The target type.
   * @param array $targetBundles
   *   The target bundles.
   *
   * @return \Drupal\field\FieldConfigInterface
   *   The created field.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function createEntityReferenceField(string $entityType, string $bundle, string $fieldName, string $targetType, array $targetBundles): FieldConfigInterface {
    $fieldStorage = FieldStorageConfig::create([
      'field_name' => $fieldName,
      'entity_type' => $entityType,
      'type' => 'entity_reference',
      'cardinality' => '-1',
      'settings' => [
        'target_type' => $targetType,
      ],
    ]);
    $fieldStorage->save();

    $field = FieldConfig::create([
      'field_storage' => $fieldStorage,
      'entity_type' => $entityType,
      'bundle' => $bundle,
      'settings' => [
        'handler' => 'default',
        'handler_settings' => [
          'target_bundles' => $targetBundles,
        ],
      ],
    ]);
    $field->save();

    return $field;
  }

  /**
   * Creates a search server and index.
   *
   * @return \Drupal\search_api\IndexInterface
   *   The created index.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function createSearchIndex(): IndexInterface {
    $server = Server::create([
      'id' => 'server',
      'name' => 'Server',
      'status' => TRUE,
      'backend' => 'search_api_db',
      'backend_config' => [
        'database' => 'default:default',
      ],
    ]);
    $server->save();

    $index = Index::create([
      'id' => 'search_index',
      'name' => 'Index',
      'status' => TRUE,
      'datasource_settings' => [
        'entity:node' => [],
      ],
      'server' => 'server',
      'tracker_settings' => [
        'default' => [],
      ],
    ]);
    $index->setServer($server);
    $index->save();

    return $index;
  }

  /**
   * Creates a field on the search index.
   *
   * @param \Drupal\search_api\IndexInterface $index
   *   The search index.
   * @param string $fieldName
   *   The field name.
   * @param string $type
   *   The field type.
   *
   * @return \Drupal\search_api\Item\FieldInterface
   *   The new field.
   *
   * @throws \Drupal\search_api\SearchApiException
   */
  private function createSearchIndexField(IndexInterface $index, string $fieldName, string $type): FieldInterface {
    $field = new Field($index, $fieldName);
    $field->setType($type);
    $field->setPropertyPath($fieldName);
    $field->setDatasourceId('entity:node');
    $field->setLabel('Facet ' . $fieldName);
    return $field;
  }

  /**
   * Creates a facet.
   *
   * @param string $id
   *   The facet id.
   * @param string $field
   *   The field.
   *
   * @return \Drupal\facets\FacetInterface
   *   The created facet.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function createFacet(string $id, string $field): FacetInterface {
    $facet = Facet::create([
      'id' => $id,
      'name' => $id,
      'facet_source_id' => 'listing_filter_search_api_facets:search_index',
      'field_identifier' => $field,
      'url_alias' => $id,
      'empty_behavior' => ['behavior' => 'none'],
    ]);
    $facet->addProcessor([
      'processor_id' => 'url_processor_handler',
      'settings' => [],
      'weights' => ['pre_query' => -10, 'build' => -10],
    ]);
    $facet->setWidget('listings_filter');
    $facet->save();

    $source = $facet->getFacetSourceConfig();
    $source->setUrlProcessor('listings_filter');
    $source->save();

    return $facet;
  }

  /**
   * Creates a ListingsParagraph entity.
   *
   * @param array $values
   *   The values to add.
   *
   * @return \Drupal\listings_filter\Entity\ListingsParagraphInterface
   *   The created ListingsParagraph entity.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  private function createListingsParagraphEntity(array $values = []): ListingsParagraphInterface {
    $values += [
      'prefilter_fields' => [],
      'display_mode' => 'teaser',
    ];

    $listingSlice = ListingsParagraph::create($values);
    $listingSlice->save();

    return $listingSlice;
  }

  /**
   * Indexes all items on the specified index.
   *
   * @param string $index_id
   *   The ID of the index on which items should be indexed.
   *
   * @return int
   *   The number of successfully indexed items.
   */
  private function indexItems(string $index_id): int {
    /** @var \Drupal\search_api\IndexInterface $index */
    $index = Index::load($index_id);
    return $index->indexItems();
  }

}
