<?php

namespace Drupal\listings_filter\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Defines a listing query type.
 *
 * Plugin Namespace: Plugin\ListingQuery.
 *
 * @see \Drupal\listings_filter\ListingQueryManager
 * @see \Drupal\listings_filter\ListingQueryInterface
 * @see \Drupal\listings_filter\ListingQueryBase
 * @see listings_filter_processor_info_alter()
 * @see plugin_api
 *
 * @Annotation
 */
class ListingQuery extends Plugin {

  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

  /**
   * The label of the query type.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $label;

  /**
   * The backend this query will support.
   *
   * @var string
   */
  public $backend;

  /**
   * The features this query will support.
   *
   * @var string[]
   */
  public $features = [];

}
