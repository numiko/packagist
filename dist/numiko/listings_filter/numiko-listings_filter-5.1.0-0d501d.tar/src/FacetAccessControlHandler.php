<?php

namespace Drupal\listings_filter;

use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Access controller for the Facet entity.
 *
 * This access control handler overrides the standard entity access control
 * handler to allow us to add a 'view label' permission for facets.
 *
 * This permission will allow autocomplete fields to show the facet label to
 * users who cannot access facets (which is usually everyone).
 */
class FacetAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected $viewLabelOperation = TRUE;

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    if ($operation === 'view label') {
      return AccessResult::allowedIfHasPermission($account, 'view facet label');
    }
    return parent::checkAccess($entity, $operation, $account);
  }

}
