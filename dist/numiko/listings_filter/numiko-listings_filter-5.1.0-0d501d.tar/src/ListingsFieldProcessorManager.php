<?php

namespace Drupal\listings_filter;

use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;

/**
 * Manager for ListingsFieldProcessor.
 */
class ListingsFieldProcessorManager extends DefaultPluginManager {

  /**
   * Constructs an ListingsFieldProcessorManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke the alter hook with.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct('Plugin/ListingsFieldProcessor', $namespaces, $module_handler, 'Drupal\listings_filter\ListingsFieldProcessorInterface', 'Drupal\listings_filter\Annotation\ListingsFieldProcessor');
    $this->alterInfo('listings_field_processor_info');
    $this->setCacheBackend($cache_backend, 'listings_field_processors');
  }

  /**
   * Get a list of processor options.
   */
  public function getProcessorOptions() {
    $processorOptions = [];
    $definitions = $this->getDefinitions();
    ksort($definitions);
    foreach ($definitions as $definition) {
      $processorOptions[$definition['id']] = $definition['name'];
    }
    return $processorOptions;
  }

  /**
   * {@inheritdoc}
   */
  public function getListingsFieldProcessors() {
    $instances = $configuration = [];
    foreach ($this->getDefinitions() as $listingsFieldProcessor) {
      $instance = $this->createInstance($listingsFieldProcessor['id'], $configuration)->verifyPluginConfiguration();
      $instances[] = $instance;
    }
    return $instances;
  }

}
