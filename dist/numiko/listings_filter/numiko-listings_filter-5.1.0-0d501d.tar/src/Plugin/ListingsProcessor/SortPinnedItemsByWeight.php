<?php

namespace Drupal\listings_filter\Plugin\ListingsProcessor;

use Drupal\Core\Form\SubformStateInterface;
use Drupal\listings_filter\Annotation\ListingsProcessor;
use Drupal\listings_filter\ListingsProcessorBase;
use Drupal\search_api\Query\ResultSetInterface;
use Drupal\search_api\SearchApiException;

/**
 * @ListingsProcessor(
 *   id = "sort_pinned_items_by_weight",
 *   name = @Translation("Sort Pinned Items By Weight"),
 *   description = @Translation("Preprocess the promoted results to sort the pinned items in the 'Pinned items field' by weight."),
 *   stages = {
 *     "preprocess_promoted_results" = 0,
 *   }
 * )
 */
class SortPinnedItemsByWeight extends ListingsProcessorBase {

  /**
   * Reorders promoted search results based on their order in listing settings.
   *
   * @param ResultSetInterface $promotedResults
   *   The set of promoted results to be processed and reordered.
   * @param array $settings
   *   (optional) An associative array of settings, including the 'promoted'
   *   key that provides an ordered list of UUIDs for reordering the results.
   *
   * @return void
   *   This method directly modifies the passed $promotedResults by reference.
   */
  public function preprocessPromotedResults(ResultSetInterface &$promotedResults, array $settings = []): void {
    if (empty($settings['promoted']) || empty($promotedResults)) {
      return;
    }

    $orderedUuids = $settings['promoted'];
    $promotedResultItems = $promotedResults->getResultItems();

    // Get the result items' UUIDs and map them to their search_api IDs.
    $uuidsToSearchApiIds = [];
    foreach ($promotedResultItems as $searchApiId => $promotedResult) {
      try {
        $entityId = $promotedResult->getOriginalObject(load: TRUE)->getValue()->uuid();
      }
      // Error thrown if entity could not be loaded by ->getOriginalObject().
      catch (SearchApiException $e) {
        continue;
      }
      $uuidsToSearchApiIds[$entityId] = $searchApiId;
    }

    // Iterate through ordered UUIDs and add their results to the ordered
    // result array.
    $reorderedResultItems = [];
    foreach ($orderedUuids as $uuid) {
      if (!isset($uuidsToSearchApiIds[$uuid])) {
        continue;
      }
      $searchApiId = $uuidsToSearchApiIds[$uuid];
      if (!isset($promotedResultItems[$searchApiId])) {
        continue;
      }
      $reorderedResultItems[$searchApiId] = $promotedResultItems[$searchApiId];
    }

    $promotedResults->setResultItems($reorderedResultItems);

  }

  /**
   * {@inheritDoc}
   *
   * Nothing to configure.
   */
  public function buildConfigurationForm(array $subform, SubformStateInterface $processorFormState): array {
    return [];
  }

}
