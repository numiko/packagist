<?php

namespace Drupal\listings_filter\Plugin\EntityReferenceSelection;

use Drupal\Core\Entity\Plugin\EntityReferenceSelection\DefaultSelection;
use Drupal\Core\Form\FormStateInterface;
use Drupal\field_ui\Form\FieldConfigEditForm;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Entity reference selection plugin for listings filter facets.
 *
 * Selection plugin to filter the facets selection by only those facets
 * that are available for that listing based on the content type / pre-filter.
 *
 * @see ListingsParagraphFacets::getFacetOptions().
 *
 * @EntityReferenceSelection(
 *   id = "listings_filter_facet",
 *   label = @Translation("Listings filter: Facet selection"),
 *   group = "listings_filter_facet",
 *   weight = 0,
 *   entity_types = {"facets_facet"},
 * )
 */
class ListingsFacetsSelection extends DefaultSelection {

  /**
   * Handler for querying listings filter facets.
   *
   * @var \Drupal\listings_filter\ListingsParagraphFacets
   */
  protected $listingsParagraphFacets;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $static = parent::create($container, $configuration, $plugin_id, $plugin_definition);
    $static->listingsParagraphFacets = $container->get('listings_filter.facets');
    return $static;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'paragraph_type' => NULL,
    ] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   *
   * Store the paragraph_type that the field is being used upon, while this
   * unnecessary the matcher does not have a reference to the field
   * configuration so is unable to determine the paragraph type and therefore
   * the relevant facets.
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);

    $configuration = $this->getConfiguration();

    if (empty($configuration['paragraph_type'])) {
      $formObject = $form_state->getFormObject();
      if ($formObject instanceof FieldConfigEditForm) {
        /** @var Drupal\field\Entity\FieldConfig */
        $entity = $formObject->getEntity();
        $configuration['paragraph_type'] = $entity->getTargetBundle();
      }
    }

    $form['paragraph_type'] = [
      '#type' => 'hidden',
      '#value' => $configuration['paragraph_type'],
    ];

    return $form;
  }

  /**
   * Query the entities to identify relevant facets.
   *
   * Use the listings filters facet handler to filter the autocomplete entity
   * query to only show those facets that are relevant based upon content type.
   *
   * @param string|null $match
   *   (Optional) Text to match the label against. Defaults to NULL.
   * @param string $match_operator
   *   (Optional) The operation the matching should be done with. Defaults
   *   to "CONTAINS".
   *
   * @return \Drupal\Core\Entity\Query\QueryInterface
   *   The EntityQuery object with the conditions and sorting applied to
   *   it, alongside being filtered to only include relevant facet options.
   */
  protected function buildEntityQuery($match = NULL, $match_operator = 'CONTAINS') {
    $configuration = $this->getConfiguration();
    $target_type = $configuration['target_type'];
    $entity_type = $this->entityTypeManager->getDefinition($target_type);

    $query = $this->entityTypeManager->getStorage($target_type)->getQuery()->accessCheck(TRUE);

    if (!empty($configuration['paragraph_type'])) {
      $facets = $this->listingsParagraphFacets->getFacetOptions($configuration['paragraph_type']);
      if ($facets) {
        $query->condition($entity_type->getKey('id'), array_keys($facets), 'IN');
      }
    }

    if (isset($match) && $label_key = $entity_type->getKey('label')) {
      $query->condition($label_key, $match, $match_operator);
    }

    // Add entity-access tag.
    $query->addTag($target_type . '_access');

    // Add the Selection handler for system_query_entity_reference_alter().
    $query->addTag('entity_reference');
    $query->addMetaData('entity_reference_selection_handler', $this);

    // Add the sort option.
    if ($configuration['sort']['field'] !== '_none') {
      $query->sort($configuration['sort']['field'], $configuration['sort']['direction']);
    }

    return $query;
  }

}
