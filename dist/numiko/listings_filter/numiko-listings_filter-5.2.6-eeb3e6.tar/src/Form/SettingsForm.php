<?php

namespace Drupal\listings_filter\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\listings_filter\ListingsParagraphFacets;
use Drupal\paragraphs\Entity\ParagraphsType;
use Drupal\search_api\Entity\Index;

/**
 * Class ContentTypeForm.
 *
 * @package Drupal\section_node\Form
 */
class SettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'listings_filter.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'listings_filter_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('listings_filter.settings');

    $paragraphOptions = array_map(function ($paragraphType) {
      return $paragraphType->label();
    }, ParagraphsType::loadMultiple());

    $form['paragraph_types'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Select the paragraph types to use as listings'),
      '#options' => $paragraphOptions,
      '#default_value' => $config->get('paragraph_types'),
    ];

    $indexSelectOptions = array_map(function ($index) {
      return $index->label();
    }, Index::loadMultiple());

    $form['index'] = [
      '#type' => 'select',
      '#title' => $this->t('Select the search_api index to use for facets'),
      '#options' => $indexSelectOptions,
      '#default_value' => $config->get('index'),
      '#empty_option' => $this->t('- Select an index -'),
      '#empty_value' => '',
    ];

    // establish what index is being used: the saved index, or the fallback (ie "site")
    $effectiveIndex = $config->get('index') ?: ListingsParagraphFacets::DEFAULT_SEARCH_INDEX;

    if (!Index::load($effectiveIndex)) {
      // if the index being used cannot be loaded, show an error message to the user.
      $this->messenger()->addError($this->t('The search API index %index could not be found. Please select a valid index and save. You may also need to rebuild cache for this to take full effect.', ['%index' => $effectiveIndex]));

      // if the index being used cannot be loaded, also mark the form element as invalid with error attributes.
      $form['index']['#label_attributes']['class'][] = 'has-error';
      $form['index']['#attributes']['class'][] = 'error';
      $form['index']['#attributes']['aria-invalid'] = 'true';
    }

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $effectiveIndex = $form_state->getValue('index') ?: ListingsParagraphFacets::DEFAULT_SEARCH_INDEX;
    if (!Index::load($effectiveIndex)) {
      $form_state->setErrorByName('index', $this->t('<em>Could not save</em> - select a valid index and try again.', ['%index' => $effectiveIndex]));
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    parent::submitForm($form, $form_state);

    $config = $this->config('listings_filter.settings');

    $config->set('paragraph_types', array_filter($form_state->getValue('paragraph_types')));
    $config->set('index', $form_state->getValue('index'));

    $config->save();
  }
}
