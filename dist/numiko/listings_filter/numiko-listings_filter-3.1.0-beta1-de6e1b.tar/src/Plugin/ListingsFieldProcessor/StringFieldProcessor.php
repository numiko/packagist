<?php

namespace Drupal\listings_filter\Plugin\ListingsFieldProcessor;

use Drupal\Core\Field\FieldItemList;
use Drupal\listings_filter\ListingsFieldProcessorBase;

/**
 * Provides a string field listing processor.
 *
 * @ListingsFieldProcessor(
 *   id = "string",
 *   name = @Translation("String"),
 *   description = @Translation("Map the string interpretation of the field to search API")
 * )
 */
class StringFieldProcessor extends ListingsFieldProcessorBase {

  /**
   * Pass the string interpretation of the field directly to search API.
   */
  public function processField(FieldItemList $field) {
    return [
      'op' => '=',
      'value' => $field->getString(),
    ];
  }

}
