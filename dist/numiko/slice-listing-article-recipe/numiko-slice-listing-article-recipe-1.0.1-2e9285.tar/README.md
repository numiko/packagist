# Listing: Article Paragraph Type Recipe

This recipe installs the necessary configuration to add an Listing: Article Slice.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-listing-article-recipe`
