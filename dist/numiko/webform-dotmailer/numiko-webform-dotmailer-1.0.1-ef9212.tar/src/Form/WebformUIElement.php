<?php

namespace Drupal\webform_dotmailer\Form;

use Drupal\Core\Form\FormStateInterface;

class WebformUIElement {

  protected $dotmailerClient;

  public function __construct($dotmailerClient) {
    $this->dotmailerClient = $dotmailerClient;
  }

  public function elementFormAlter(array &$form, FormStateInterface $form_state) {
    if ($webform = $form_state->getBuildInfo()['callback_object']->getWebform()) {
      if ($webform->getHandlers()->has('dotmailer_post')) {
        $form['properties']['element']['dotmailer_key'] = [
          '#type' => 'select',
          '#title' => 'Select the dotmailer field',
          '#empty_option' => 'Not a dotmailer field',
          '#options' => $this->getDotmailerFieldOptions(),
          '#default_value' => ($form_state->get('element_properties') && isset($form_state->get('element_properties')['dotmailer_key'])) ? $form_state->get('element_properties')['dotmailer_key'] : '',
          '#parents' => ['properties', 'dotmailer_key'],
          '#weight' => -20,
        ];

        array_unshift($form['#validate'], 'webform_dotmailer_alter_form_key');
        array_push($form['#validate'], 'webform_dotmailer_alter_form_key_error');
      }
    }
  }

  /**
   * Get the fields from the Dotmailer Client (including the mandatory e-mail field).
   */
  protected function getDotmailerFieldOptions() {
    $dotmailerFields = [];
    foreach ($this->dotmailerClient->getDataFieldsArray() as $detail) {
      $dotmailerFields[strtolower($detail['name'])] = $detail['name'];
    }
    $dotmailerFields['email'] = 'EMAIL';
    asort($dotmailerFields);
    return $dotmailerFields;
  }

  public function alterFormKey(array $form, FormStateInterface $form_state) {
    $dotmailerKey = $this->getDotmailerKey($form_state);
    if ($dotmailerKey) {
      $form_state->setValue('key', $dotmailerKey);
    }
  }

  public function alterFormKeyError(array $form, FormStateInterface $form_state) {
    $dotmailerKey = $this->getDotmailerKey($form_state);
    if ($dotmailerKey) {
      $errors = $form_state->getErrors();
      if (isset($errors['key'])) {
        $form_state->setError($form['properties']['element']['dotmailer_key'], 'You are already using this dotmailer field on this form, please select an alternative');
      }
    }
  }

  /**
   * Get the dotmailer field key from the form values.
   */
  public function getDotmailerKey(FormStateInterface $form_state) {
    if (isset($form_state->getValue('properties')['dotmailer_key']) 
      && $form_state->getValue('properties')['dotmailer_key']) {
      return $form_state->getValue('properties')['dotmailer_key'];
    }
    return false;
  }

}