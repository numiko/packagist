<?php

namespace Drupal\webform_dotmailer\Client;

use DotMailer\Api\Container;
use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * @see https://github.com/romanpitak/dotMailer-API-v2-PHP-client/blob/master/src/Resources/Resources.php
 */

class DotmailerClient {

  protected $configFactory;

  protected $apiResources;

  public function __construct(ConfigFactoryInterface $config_factory) {
    $this->configFactory = $config_factory;
  }

  public function getBase64Creds() {
    return base64_encode($this->configFactory->get('dotmailer.auth')->get('user') . ':' . $this->configFactory->get('dotmailer.auth')->get('password'));
  }

  public function getDataFieldsArray() {
    $this->lazyLoadApiResources();
    return $this->apiResources->GetDataFields()->toArray();
  }

  public function getAddressBooksArray() {
    $this->lazyLoadApiResources();
    return $this->apiResources->GetAddressBooks()->toArray();
  }

  public function getAccountInfoArray() {
    $this->lazyLoadApiResources();
    return $this->apiResources->GetAccountInfo()->toArray();
  }

  public function lazyLoadApiResources() {
    if (!$this->apiResources) {
      $this->apiResources = Container::newResources([
        Container::USERNAME => $this->configFactory->get('dotmailer.auth')->get('user'),
        Container::PASSWORD => $this->configFactory->get('dotmailer.auth')->get('password')
      ]);
    }
  }

}