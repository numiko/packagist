# Content Bulk Update

Adds bulk actions for publishing latest revision and archiving with Drupal
core content moderation.