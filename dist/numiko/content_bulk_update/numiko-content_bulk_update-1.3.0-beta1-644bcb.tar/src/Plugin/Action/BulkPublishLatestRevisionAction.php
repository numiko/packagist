<?php

namespace Drupal\content_bulk_update\Plugin\Action;

use Drupal\Core\Action\ActionBase;
use Drupal\Core\Entity\RevisionableStorageInterface;
use Drupal\Core\Entity\RevisionLogInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Session\AccountInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * An action to publish the latest revision.
 *
 * @Action(
 *   id = "bulk_publish_latest_revision_action",
 *   label = @Translation("Publish Latest Revision"),
 *   type = "node",
 *   confirm = TRUE,
 * )
 */
class BulkPublishLatestRevisionAction extends ActionBase implements ContainerFactoryPluginInterface {

  /**
   * Node storage.
   *
   * @var \Drupal\Core\Entity\RevisionableStorageInterface
   */
  protected $entityTypeManager;

  /**
   * Constructs a BulkPublishLatestRevisionAction object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\RevisionableStorageInterface $entity_type_manager
   *   The node storage.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, RevisionableStorageInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager')->getStorage('node')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function execute($entity = NULL) {
    if (!$entity->isLatestRevision()) {
      $latest = $this->entityTypeManager
        ->getQuery()
        ->latestRevision()
        ->condition('nid', $entity->id())
        ->accessCheck(FALSE)
        ->execute();
      $revision = key($latest);
      $entity = $this->entityTypeManager->loadRevision($revision);
    }

    $entity->set('moderation_state', 'published');
    if ($entity instanceof RevisionLogInterface) {
      $entity->setRevisionCreationTime(\Drupal::time()->getRequestTime());
      $entity->setRevisionLogMessage('Bulk operation publish revision');
      $entity->setRevisionUserId(\Drupal::currentUser()->id());
    }
    $entity->save();
  }

  /**
   * {@inheritdoc}
   */
  public function access($object, AccountInterface $account = NULL, $return_as_object = FALSE) {
    if ($object->getEntityType() === 'node') {
      $access = $object->access('update', $account, TRUE)
        ->andIf($object->status->access('edit', $account, TRUE));
      return $return_as_object ? $access : $access->isAllowed();
    }

    return TRUE;
  }

}
