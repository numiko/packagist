<?php

namespace Drupal\migrate_group_ui\Controller;

use Drupal\Component\Utility\Html;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\migrate_plus\Plugin\MigrationConfigEntityPluginManager;

/**
 * Enables the running of a migration group.
 */
class MigrateController extends ControllerBase {

  public function execute($migration_group) {
    return $this->formBuilder()->getForm('\Drupal\migrate_group_ui\Form\ExecuteMigrateForm', $migration_group);
  }

}
