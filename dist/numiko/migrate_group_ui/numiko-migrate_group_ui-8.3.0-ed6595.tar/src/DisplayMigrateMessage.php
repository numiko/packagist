<?php

namespace Drupal\migrate_group_ui;

use Drupal\migrate\MigrateMessage as MigrateMessageBase;
use Drupal\Core\Logger\RfcLogLevel;

/**
 * Defines a migrate message class.
 */
class DisplayMigrateMessage extends MigrateMessageBase {

  const STATUS_STATUS = 'status';
  const STATUS_WARNING = 'warning';
  const STATUS_ERROR = 'error';

  /**
   * The map between migrate status and message type.
   *
   * @var array
   */
  protected $display_map = array(
    'status' => self::STATUS_STATUS,
    'error' => self::STATUS_ERROR,
  );

  /**
   * {@inheritdoc}
   */
  public function display($message, $type = 'status') {
    parent::display($message, $type);
    $type = isset($this->display_map[$type]) ? $this->display_map[$type] : self::STATUS_WARNING;
    drupal_set_message($message->render(), $type);
  }

}
