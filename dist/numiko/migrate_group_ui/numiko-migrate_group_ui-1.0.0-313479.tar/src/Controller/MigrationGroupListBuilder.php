<?php

namespace Drupal\migrate_group_ui\Controller;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Url;
use Drupal\migrate_tools\Controller\MigrationGroupListBuilder as ToolsMigrationGroupListBuilder;

/**
 * Provides a listing of migration group entities.
 *
 * @package Drupal\migrate_tools\Controller
 *
 * @ingroup migrate_tools
 */
class MigrationGroupListBuilder extends ToolsMigrationGroupListBuilder {

  /**
   * {@inheritdoc}
   */
  public function getDefaultOperations(EntityInterface $entity) {
    $operations = parent::getDefaultOperations($entity);
    $operations['run'] = [
      'title' => $this->t('Execute migrations'),
      'weight' => -10,
      'url' => Url::fromRoute('entity.migration_group.execute', ['migration_group' => $entity->id()]),
    ];

    return $operations;
  }

}
