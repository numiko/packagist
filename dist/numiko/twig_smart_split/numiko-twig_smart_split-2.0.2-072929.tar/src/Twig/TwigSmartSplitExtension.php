<?php

namespace Drupal\twig_smart_split\Twig;

use Drupal\Core\Render\Markup;
use Drupal\Core\Template\TwigExtension;

/**
 * Twig extension to allow smartly splitting a block of html.
 */
class TwigSmartSplitExtension extends TwigExtension {

  private $coreTwigExtension;

  public function __construct(TwigExtension $coreTwigExtension) {
    $this->coreTwigExtension = $coreTwigExtension;
  }

  public function getName() {
    return 'smart_split';
  }

  public function getFilters() {
    return [
      new TwigFilter('smart_split', [$this, 'smartSplitFilter']),
    ];
  }

  /**
   * Smartly split a rendered block of text.
   *
   * Smartly split a rendered block of text to create multiple roughly
   * equivalent or sensibly split blocks of text.
   *
   * Returns as Markup object to avoid double-escaping found when filters are
   * applied after render in template (like field_x|render|striptags|trim).
   *
   * @param string $field
   *   The field or text to be split.
   * @param int $split_into
   *   The number of "chunks" to split the content into.
   *
   * @return list
   *   A list of renderable
   *   (\Drupal\Component\Render\MarkupInterface|mixed|string) components.
   */
  public function smartSplitFilter($field, $splitInto = 2) {
    $fieldContent = $this->renderArrayToString($field);
    // First we try and split by paragraphs the obvious choice.
    // If it matches the number to split into, then use this.
    // If its more than that, then we should approximately divide it.
    $content = $this->chunkContentByDelimeter($fieldContent, "\<\/p\>", $splitInto);
    if ($content) {
      // Finally create a markup item for each of the strings so this can be
      // rendered in twig.
      array_walk($content, function (&$value) {
        $value = Markup::create((string) $value);
      });
      return $content;
    }
    // In the event that it is less than the number to split into, then
    // try to split by character length, and find a good breaking point
    // (such as nearest full-stop).
    $content = $this->chunkContentByDelimeter(rtrim(ltrim($fieldContent, "<p>"), "</p>"), '\.', $splitInto);
    if ($content) {
      // Finally create a markup item for each of the strings so this can be
      // rendered in twig.
      array_walk($content, function (&$value) {
        $value = Markup::create("<p>{$value}</p>");
      });
      return $content;
    }
    // In the event of being unable to split on either paragraphs or full-stops
    // assume that this is just one block of words and keep in one block.
    // Using markup create to make that one block renderable as the first item
    // in the expected array.
    return [Markup::create($fieldContent)];
  }

  /**
   * Take the provided content and break into the number of chunks defined.
   *
   * Using the provided delimeter split the content into parts based on the
   * requested number of chunks.
   */
  protected function chunkContentByDelimeter($content, $delimeter, $splitInto) {
    $fieldContentArray = array_filter(preg_split('[(?<=' . $delimeter . ')]', $content));
    if (count($fieldContentArray) >= $splitInto) {
      // If there are more items than required, then we use the array_chunk
      // function and combine using implode to create an array containing the
      // number of required items.
      if (count($fieldContentArray) > $splitInto) {
        $fieldContentArray = array_map('implode', array_chunk($fieldContentArray, ceil(count($fieldContentArray) / $splitInto)));
      }
      return $fieldContentArray;
    }
  }

  /**
   * Get the field contents as a string.
   */
  protected function renderArrayToString($field) {
    $rendered = $this->coreTwigExtension->renderVar($field);
    if ($rendered instanceof Markup) {
      $treatedMarkup = trim($this->stripHtmlComments((string) $rendered));
      return $treatedMarkup;
    }
    else {
      return $rendered;
    }
  }

  /**
   * Return the given string with html comments stripped out.
   *
   * @param $string
   * @return string
   */
  protected function stripHtmlComments($content) {
    return preg_replace('/<!--(.|\s)*?-->/', '', $content);
  }

}
