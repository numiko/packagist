# Twig Smart Split

This module adds a twig `smart_split` filter; this takes text and splits it into a defined number of chunks.

It will split based on paragraph tags (if they exist), or on full-stops if not, trying to get a balanced amount of content in each of the content chunks.

For example if the content has five paragraphs, and its being split in two (the default) then the first chunk would contain three paragraphs, and the second would contain the remaining two.

## Usage

```
{% set split_string = twig_string|smart_split %}
<div class="content-first-half">
  {{ split_string|first }}
</div>
<div class="content-second-half">
  {{ split_string|last }}
</div>
```