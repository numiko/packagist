<?php

namespace Drupal\autotagging;

use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use GuzzleHttp\ClientInterface;

/**
 * Makes LLM API calls.
 */
class LlmApiService {
  protected $httpClient;
  protected $configFactory;
  protected $entityTypeManager;

  public function __construct(ClientInterface $http_client, ConfigFactoryInterface $config_factory, EntityTypeManagerInterface $entity_type_manager) {
    $this->httpClient = $http_client;
    $this->configFactory = $config_factory;
    $this->entityTypeManager = $entity_type_manager;
  }

  public function categorise($nodeContent) {
    // Load category taxonomy terms.
    $categoryTerms = $this->entityTypeManager->getStorage('taxonomy_term')->loadByProperties(['vid' => 'category']);
    $categories = [];
    foreach ($categoryTerms as $category) {
      $categories[] = $category->getName();
    }

    $systemPrompt = 'ONLY from the following list of taxonomy terms, categorize the text entry.
      \n[' . implode(', ', $categories) . ']\n 
      Return a list of selected taxonomy terms from the list provided, each separated by a comma.
      For each selected taxonomy term, provide a relevance score between 0 and 100 inside brackets indicating how confident you are that the tag is relevant to the content.
      Make sure the relevance score is not a random rushed calculation - but one that is worked out.
      Example: taxonomy1 (85), taxonomy2 (40), taxonomy3 (90)';

    $message = new ChatInput([new ChatMessage('system', $systemPrompt), new ChatMessage('user', $nodeContent)]);

    $aiProvider = \Drupal::service('ai.provider');
    $defaultProvider = $aiProvider->getDefaultProviderForOperationType('chat');
    $provider = $aiProvider->createInstance($defaultProvider['provider_id']);

    /** @var \Drupal\ai\OperationType\Chat\ChatOutput $response */
    $response = $provider->chat($message, $defaultProvider['model_id']);
    /** @var \Drupal\ai\OperationType\Chat\ChatMessage $return_message */
    $return_message = $response->getNormalized()->getText();

    // Extract and parse the response.
    if ($return_message) {
      return $this->parseTagsWithConfidence($return_message);
    }
    return [];
  }

  private function parseTagsWithConfidence($response) {
    $confidenceThreshold = 70;
    $tagList = [];
    $tagListWithConfidenceScore = [];

    // Example: Response is a string "taxonomy1 (85), taxonomy2 (40), taxonomy3 (90)".
    preg_match_all('/([a-zA-Z0-9\s\-]+)\s*\((\d+)\)/', $response, $matches, PREG_SET_ORDER);

    foreach ($matches as $match) {
      $tag = trim($match[1]);  // Trim the tag name to remove any extra spaces.
      $confidenceScore = (int) $match[2];  // The confidence score.

      // Only add tags that meet the confidence threshold.
      if ($confidenceScore >= $confidenceThreshold) {
        $tagList[] = $tag;
        // For log purposes only.
        $tagListWithConfidenceScore[] = $tag . " (" . $confidenceScore . "% confident)";
      }
    }
    \Drupal::logger('autotagging')->debug("tag list: " . implode(', ', $tagListWithConfidenceScore));
    return $tagList;
  }

}
