Fork of the project field_lock_multi_values to offer permissions to reorder multi items fields in Drupal 8.

Dev state.

How to:

Enable it, set permissions to the Role that will be able to reorder.

Has no effect on Users without editing permissions