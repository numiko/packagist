
# Ai Metadata Module

The goal of this module it's to generate an AI metadata description to any chosen page.

## Requirements

- Drupal AI Core
- AI Core with OpenAI configured

## Set up

1. ``` composer require 'drupal/ai:^1.0@alpha' ```
2. Enable modules ` drush en drupal/ai`.
3. Enable 'key' and 'openAI provider' modules. Easier to enable on the UI.
4. Add openAI key to .env file ` OPEN_AI_KEY={API_KEY} `.
5. Rebuild the container ` docker compose build`, then `docker compose down` and ` docker compose up -d`
6. Add/Associate API key on ` /admin/config/system/keys `. On Provide Settings `Key Provide = Environment` and ` Environment variable = OPEN_AI_KEY`.
7. Add/Associate the key on OpenAI Authentication  at `/admin/config/ai/providers/openai`.
8. Enable module ` drush en ai_metadata `.

## Objectives Achieved

- The module is capable of generating an AI Metadata description with the information present in the body (introduction) of the content type.
- Currently working just for `Content Page` content type with `field_teaser_summary`.
- The description is getting generated when the page is saved.

## Future Objectives to Achieve

- If the description was already generated for that page, do not generate a new one.
- Create a button on the metadata form (side bar) for the user to be able to generate run the hook, and not when the page is being saved.