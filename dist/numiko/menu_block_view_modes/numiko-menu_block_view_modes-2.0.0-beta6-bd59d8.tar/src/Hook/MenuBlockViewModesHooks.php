<?php

namespace Drupal\menu_block_view_modes\Hook;

use Drupal\Core\Entity\EntityDisplayRepositoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\menu_block_view_modes\Menu\MenuBlockViewMode;

/**
 * Hook implementations for menu_block_view_modes.
 */
class MenuBlockViewModesHooks {

  use StringTranslationTrait;

  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
    protected EntityDisplayRepositoryInterface $entityDisplayRepository,
    TranslationInterface $string_translation,
  ) {
    $this->stringTranslation = $string_translation;
  }

  /**
   * Implements hook_form_alter().
   *
   * Add view_mode and render_level as third party settings to menu blocks.
   */
  #[Hook('form_alter')]
  public function formAlter(array &$form, FormStateInterface $form_state, string $form_id): void {
    if ($form_id !== 'block_form') {
      return;
    }

    $block = $form_state->getFormObject()->getEntity();

    if (!str_contains($block->getPluginId(), 'menu_block')) {
      return;
    }

    $menu_reference_entities = 'node';
    $view_mode_options = $this->entityDisplayRepository->getViewModeOptions($menu_reference_entities);

    $form['settings']['advanced']['menu_block_view_modes']['view_mode'] = [
      '#type' => 'select',
      '#options' => $view_mode_options,
      '#title' => $this->t('<strong>View mode to render</strong>'),
      '#default_value' => $block->getThirdPartySetting('menu_block_view_modes', 'view_mode'),
      '#empty_option' => '- Label only -',
      '#description' => $this->t('If specified menu links will display the linked entity in the specified view mode.'),
    ];

    $form['settings']['advanced']['menu_block_view_modes']['render_level'] = [
      '#type' => 'number',
      '#min' => 1,
      '#title' => '<strong>' . $this->t('Level to render') . '</strong>',
      '#description' => $this->t('Render this level, relative to the "Fixed parent item", as "View mode to render" if selected. ') .
        $this->t('e.g. 1 = children of the selected menu link (default), 2 = grandchildren, etc.'),
      '#default_value' => $block->getThirdPartySetting('menu_block_view_modes', 'render_level'),
    ];
  }

  /**
   * Implements hook_preprocess_block().
   *
   * Adds the rendered entity to the menu item.
   */
  #[Hook('preprocess_block')]
  public function preprocessBlock(array &$variables): void {
    if (!isset($variables['elements']['#id'])) {
      return;
    }
    $block = $this->entityTypeManager->getStorage('block')->load($variables['elements']['#id']);
    if ($block === NULL) {
      return;
    }
    $view_mode = $block->getThirdPartySetting('menu_block_view_modes', 'view_mode');
    if (!$view_mode) {
      return;
    }

    $render_level = $block->getThirdPartySetting('menu_block_view_modes', 'render_level') ?? 1;
    $menuBlockViewMode = new MenuBlockViewMode($render_level, $view_mode, $this->entityTypeManager, $this->entityDisplayRepository);
    $menuBlockViewMode->buildItems($variables['content']);
  }

}
