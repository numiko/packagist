<?php

namespace Drupal\menu_block_view_modes\Menu;

use Drupal\Core\Entity\EntityDisplayRepositoryInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * MenuBlockViewMode helper.
 */
class MenuBlockViewMode {

  const STARTING_LEVEL = 1;

  /**
   * MenuBlockViewMode constructor.
   *
   * @param int $renderLevel
   *   The initial render level.
   * @param string $viewMode
   *   The view mode to render.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityDisplayRepositoryInterface $entityDisplayRepository
   *   The entity display repository.
   */
  public function __construct(
    protected int $renderLevel,
    protected string $viewMode,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected EntityDisplayRepositoryInterface $entityDisplayRepository,
  ) {}

  /**
   * Build the items.
   *
   * @param array $build
   *   The menu build array.
   */
  public function buildItems(array &$build) {
    if (isset($build['#items'])) {
      $this->buildItemsAtLevel($build['#items'], self::STARTING_LEVEL);
    }
  }

  /**
   * Build the items for the current level.
   *
   * A recursive function to work through the menu items and either
   * continue the build or render, depending on the level.
   *
   * @param array $items
   *   The menu items.
   * @param int $currentLevel
   *   The current level.
   */
  protected function buildItemsAtLevel(array &$items, int $currentLevel) {
    if ($currentLevel == $this->renderLevel) {
      $this->renderItemsAtLevel($items);
    }
    else {
      foreach ($items as &$item) {
        $this->buildItemsAtLevel($item['below'], $currentLevel + 1);
      }
    }
  }

  /**
   * Render the menu items.
   *
   * @param array $items
   *   The items to render.
   */
  protected function renderItemsAtLevel(array &$items) {
    $ids = $this->getItemEntityIds($items);
    foreach ($ids as $entityType => $entityIds) {
      $entities[$entityType] = $this->loadMultipleEntities($entityType, $entityIds);
    }
    foreach ($items as &$item) {
      if (isset($item['entity_id']) && isset($entities[$item['entity_type']][$item['entity_id']])) {
        $entity = $entities[$item['entity_type']][$item['entity_id']];
        $item['bundle'] = $entity->bundle();
        $item['entity'] = $this->renderEntityToViewMode($item['entity_type'], $entity);
      }
    }
  }

  /**
   * Get the entity ids for the menu items.
   *
   * @param array $items
   *   The menu items.
   *
   * @return array
   *   The entity ids.
   */
  protected function getItemEntityIds(array &$items): array {
    $ids = [];
    foreach ($items as &$item) {
      if ($item['url']->isRouted()) {
        $params = $item['url']->getRouteParameters();
        if (isset($params)) {
          foreach ($params as $entity_type => $entity_id) {
            if ($entity_type !== 'node') {
              continue;
            }
            $item['entity_type'] = $entity_type;
            $ids[$entity_type][] = $item['entity_id'] = $entity_id;
          }
        }
      }
    }
    return $ids;
  }

  /**
   * Use the entity load multiple for the given entity type.
   *
   * @param string $entityType
   *   The type of entity to render.
   * @param array $entityIds
   *   The entity ids.
   *
   * @return mixed
   *   The rendered entities.
   */
  protected function loadMultipleEntities(string $entityType, array $entityIds) {
    return $this->entityTypeManager->getStorage($entityType)->loadMultiple($entityIds);
  }

  /**
   * Get the render array for a given entity to the view mode.
   *
   * @param string $entityType
   *   The type of entity to render.
   * @param mixed $entity
   *   The entity.
   *
   * @return array|false
   *   The rendered entity.
   */
  protected function renderEntityToViewMode(string $entityType, $entity) {
    $viewModeOptions = $this->entityDisplayRepository->getViewModeOptionsByBundle($entityType, $entity->bundle());
    if (array_key_exists($this->viewMode, $viewModeOptions)) {
      $viewBuilder = $this->entityTypeManager->getViewBuilder($entityType);
      return $viewBuilder->view($entity, $this->viewMode);
    }

    return FALSE;
  }

}
