# Facets Attachment #

By default each view requires a separate facet including views attached to other views. This module causes an attachment view to inherit selected facets from its attached view.