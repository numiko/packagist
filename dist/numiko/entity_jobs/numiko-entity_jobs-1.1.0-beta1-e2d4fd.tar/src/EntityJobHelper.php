<?php

namespace Drupal\entity_jobs;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\entity_jobs\Entity\EntityJob;

/**
 * Service helper to run actions and conditions for entity jobs.
 */
class EntityJobHelper {

  public function __construct(
    protected EntityTypeManagerInterface $entityTypeManager,
  ) {
  }

  /**
   * Run the actions for an entity job.
   *
   * @param \Drupal\entity_jobs\Entity\EntityJob $entityJob
   *   The entity job.
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity to run the actions on.
   */
  public function runActions(EntityJob $entityJob, EntityInterface $entity): void {
    $actionPlugins = $entityJob->getActionPluginInstancesWithOptions();
    foreach ($actionPlugins as $action) {
      if (isset($action['options'])) {
        $action['plugin']->process($entity, $action['options']);
        continue;
      }
      $action['plugin']->process($entity);
    }
  }

  /**
   * Run the conditions for an entity job.
   *
   * @param \Drupal\entity_jobs\Entity\EntityJob $entityJob
   *   The entity job.
   *
   * @return array|int
   */
  public function runConditions(EntityJob $entityJob) {
    $entityQuery = $this->entityTypeManager->getStorage($entityJob->getSubjectEntityTypeId())->getQuery();
    $conditionPlugins = $entityJob->getConditionPluginInstancesWithOptions();
    foreach ($conditionPlugins as $conditionPlugin) {
      $conditionPlugin['plugin']->process($entityQuery, $conditionPlugin['options']);
    }
    return $entityQuery->accessCheck(TRUE)->execute();
  }

}
