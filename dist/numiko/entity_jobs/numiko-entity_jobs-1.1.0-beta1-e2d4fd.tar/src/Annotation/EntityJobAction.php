<?php

namespace Drupal\entity_jobs\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Defines an entity_jobs Action annotation object.
 *
 * Plugin Namespace: Plugin\Action
 *
 * @see \Drupal\entity_jobs\ArchiverManager
 * @see \Drupal\entity_jobs\ArchiverInterface
 * @see plugin_api
 * @see hook_entity_jobs_action_info_alter()
 *
 * @Annotation
 */
class EntityJobAction extends Plugin {

  /**
   * The action plugin ID.
   *
   * @var string
   */
  public $id;

  /**
   * The human-readable name of the action plugin.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $title;

  /**
   * The description of the action plugin.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $description;
}
