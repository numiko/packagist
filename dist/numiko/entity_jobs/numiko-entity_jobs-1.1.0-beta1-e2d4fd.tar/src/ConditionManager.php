<?php

namespace Drupal\entity_jobs;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\entity_jobs\Attribute\EntityJobCondition;

/**
 * Provides an entity_jobs Condition plugin manager.
 *
 * @see \Drupal\entity_jobs\Attribute\EntityJobCondition
 * @see \Drupal\entity_jobs\Annotation\EntityJobCondition
 * @see \Drupal\entity_jobs\ConditionInterface
 * @see plugin_api
 */
class ConditionManager extends DefaultPluginManager {

  /**
   * Constructs a ConditionManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke the alter hook with.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct(
      'Plugin/Condition',
      $namespaces,
      $module_handler,
      ConditionInterface::class,
      EntityJobCondition::class,
      'Drupal\entity_jobs\Annotation\EntityJobCondition'
    );
    $this->alterInfo('entity_job_condition_info');
    $this->setCacheBackend($cache_backend, 'entity_job_condition_info_plugins');
  }

}
