<?php

namespace Drupal\entity_jobs;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\entity_jobs\Attribute\EntityJobAction;

/**
 * Provides an entity_jobs Action plugin manager.
 *
 * @see \Drupal\entity_jobs\Attribute\EntityJobAction
 * @see \Drupal\entity_jobs\Annotation\EntityJobAction
 * @see \Drupal\entity_jobs\ActionInterface
 * @see plugin_api
 */
class ActionManager extends DefaultPluginManager {

  /**
   * Constructs an ActionManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke the alter hook with.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct(
      'Plugin/Action',
      $namespaces,
      $module_handler,
      ActionInterface::class,
      EntityJobAction::class,
      'Drupal\entity_jobs\Annotation\EntityJobAction'
    );
    $this->alterInfo('entity_job_action_info');
    $this->setCacheBackend($cache_backend, 'entity_job_action_info_plugins');
  }

}
