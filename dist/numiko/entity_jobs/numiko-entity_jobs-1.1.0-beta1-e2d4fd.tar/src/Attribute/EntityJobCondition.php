<?php

namespace Drupal\entity_jobs\Attribute;

use Drupal\Component\Plugin\Attribute\Plugin;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines an EntityJobCondition attribute object.
 *
 * Plugin Namespace: Plugin\Condition
 *
 * @see \Drupal\entity_jobs\ConditionManager
 * @see \Drupal\entity_jobs\ConditionInterface
 * @see plugin_api
 */
#[\Attribute(\Attribute::TARGET_CLASS)]
class EntityJobCondition extends Plugin {

  /**
   * Constructs an EntityJobCondition attribute.
   *
   * @param string $id
   *   The plugin ID.
   * @param \Drupal\Core\StringTranslation\TranslatableMarkup|null $title
   *   The human-readable name of the condition plugin.
   * @param \Drupal\Core\StringTranslation\TranslatableMarkup|null $description
   *   The description of the condition plugin.
   */
  public function __construct(
    public readonly string $id,
    public readonly ?TranslatableMarkup $title = NULL,
    public readonly ?TranslatableMarkup $description = NULL,
  ) {}

}
