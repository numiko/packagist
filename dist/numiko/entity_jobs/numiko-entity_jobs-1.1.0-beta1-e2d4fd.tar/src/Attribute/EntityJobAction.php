<?php

namespace Drupal\entity_jobs\Attribute;

use Drupal\Component\Plugin\Attribute\Plugin;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines an EntityJobAction attribute object.
 *
 * Plugin Namespace: Plugin\Action
 *
 * @see \Drupal\entity_jobs\ActionManager
 * @see \Drupal\entity_jobs\ActionInterface
 * @see plugin_api
 */
#[\Attribute(\Attribute::TARGET_CLASS)]
class EntityJobAction extends Plugin {

  /**
   * Constructs an EntityJobAction attribute.
   *
   * @param string $id
   *   The plugin ID.
   * @param \Drupal\Core\StringTranslation\TranslatableMarkup|null $title
   *   The human-readable name of the action plugin.
   * @param \Drupal\Core\StringTranslation\TranslatableMarkup|null $description
   *   The description of the action plugin.
   */
  public function __construct(
    public readonly string $id,
    public readonly ?TranslatableMarkup $title = NULL,
    public readonly ?TranslatableMarkup $description = NULL,
  ) {}

}
