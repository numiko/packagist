<?php

namespace Drupal\entity_jobs\Plugin\Condition;

use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\entity_jobs\Attribute\EntityJobCondition;
use Drupal\entity_jobs\ConditionInterface;

#[EntityJobCondition(
  id: 'boolean_field_is_true',
  title: new TranslatableMarkup('Boolean field is true'),
  description: new TranslatableMarkup('Check if a boolean field on an entity is true.'),
)]
class BooleanFieldIsTrue extends PluginBase implements ConditionInterface {

  /**
   * @inheritDoc
   */
  public function process(QueryInterface &$entityQuery, ?array $options = NULL): void {
    $fieldName = $options['field_name'];
    $negate = isset($options['negate']) && $options['negate'] == TRUE;

    $orConditionGroup = $entityQuery->orConditionGroup();
    $orConditionGroup->condition($fieldName, !$negate);
    $orConditionGroup->notExists($fieldName);
    $entityQuery->condition($orConditionGroup);
  }
}
