<?php

namespace Drupal\entity_jobs\Plugin\Condition;

use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\entity_jobs\Attribute\EntityJobCondition;
use Drupal\entity_jobs\ConditionInterface;

#[EntityJobCondition(
  id: 'entity_is_published',
  title: new TranslatableMarkup('Entity is published'),
  description: new TranslatableMarkup('Check if an entity is published'),
)]
class EntityIsPublished extends PluginBase implements ConditionInterface {

  /**
   * @inheritDoc
   */
  public function process(QueryInterface &$entityQuery, ?array $options = NULL): void {
    $negate = isset($options['negate']) && $options['negate'] == TRUE;
    $entityQuery->condition('status', !$negate);
  }
}
