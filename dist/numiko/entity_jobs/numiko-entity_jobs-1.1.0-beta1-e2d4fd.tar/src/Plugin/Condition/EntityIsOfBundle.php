<?php

namespace Drupal\entity_jobs\Plugin\Condition;

use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\entity_jobs\Attribute\EntityJobCondition;
use Drupal\entity_jobs\ConditionInterface;

#[EntityJobCondition(
  id: 'entity_is_of_bundle',
  title: new TranslatableMarkup('Entity is of bundle'),
  description: new TranslatableMarkup('Check if an entity is of a given bundle'),
)]
class EntityIsOfBundle extends PluginBase implements ConditionInterface {

  /**
   * @inheritDoc
   */
  public function process(QueryInterface &$entityQuery, $options): void {
    $entityQuery->condition('type', $options['bundle']);
  }
}
