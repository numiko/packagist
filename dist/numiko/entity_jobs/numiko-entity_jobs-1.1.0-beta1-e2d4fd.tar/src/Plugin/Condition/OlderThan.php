<?php

namespace Drupal\entity_jobs\Plugin\Condition;

use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\datetime\Plugin\Field\FieldType\DateTimeItemInterface;
use Drupal\entity_jobs\Attribute\EntityJobCondition;
use Drupal\entity_jobs\ConditionInterface;

#[EntityJobCondition(
  id: 'older_than',
  title: new TranslatableMarkup('Published over a certain time ago'),
  description: new TranslatableMarkup('Check if content was published over a certain time ago'),
)]
class OlderThan extends PluginBase implements ConditionInterface {

  /**
   * @inheritDoc
   */
  public function process(QueryInterface &$entityQuery, $options): void {
    $timeAgo = $options['time_ago'];
    $field = $options['field'];
    $date = new DrupalDateTime();
    $date->setTimezone(new \DateTimezone(DateTimeItemInterface::STORAGE_TIMEZONE));
    $date->modify('-' . $timeAgo);
    $dbDateTime = $date->format(DateTimeItemInterface::DATETIME_STORAGE_FORMAT);
    $entityQuery->condition($field, $dbDateTime, '<');
  }
}
