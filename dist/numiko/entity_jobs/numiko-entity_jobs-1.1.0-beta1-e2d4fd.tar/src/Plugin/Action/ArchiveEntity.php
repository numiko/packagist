<?php

namespace Drupal\entity_jobs\Plugin\Action;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\RevisionLogInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\entity_jobs\ActionInterface;
use Drupal\entity_jobs\Attribute\EntityJobAction;
use Drupal\entity_jobs\Exception\ActionException;

#[EntityJobAction(
  id: 'archive_entity',
  title: new TranslatableMarkup('Archive Entity'),
  description: new TranslatableMarkup('Archives an entity'),
)]
class ArchiveEntity extends PluginBase implements ActionInterface {

  /**
   * The moderation state.
   */
  const ARCHIVED_MODERATION_STATE_ID = 'archived';

  /**
   * @inheritDoc
   */
  public function process(EntityInterface $entity, ?array $options = NULL): bool {
    try {
      $entity->set('moderation_state', self::ARCHIVED_MODERATION_STATE_ID);
      if ($entity instanceof RevisionLogInterface) {
        $entity->setRevisionLogMessage('Archived in an entity job.');
      }
      $entity->save();
    }
    catch (\Exception $e) {
      throw new ActionException($e->getMessage());
    }
    return TRUE;
  }
}
