<?php

namespace Drupal\entity_jobs\Hook;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Session\AccountInterface;

/**
 * Hook implementations for entity_jobs.
 */
class EntityJobsHooks {

  /**
   * Implements hook_entity_field_access().
   *
   * Disable access to field_exclude_from_entity_jobs for users without the
   * 'exclude nodes from entity jobs' permission.
   */
  #[Hook('entity_field_access')]
  public function entityFieldAccess(string $operation, FieldDefinitionInterface $field_definition, AccountInterface $account, ?FieldItemListInterface $items = NULL) {
    if ($field_definition->getName() === 'field_exclude_from_entity_jobs' && $operation === 'edit') {
      return AccessResult::forbiddenIf(!$account->hasPermission('exclude nodes from entity jobs'));
    }
    return AccessResult::neutral();
  }

}
