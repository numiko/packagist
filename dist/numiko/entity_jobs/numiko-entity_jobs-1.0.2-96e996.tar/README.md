## Entity Jobs

This module allows actions to be run on entities with optional conditions, grouped as a job.

Jobs are defined in config `entity_jobs.job.{job_id}`.

### Actions

The following actions plugins currently exist with this module.

1. ArchiveEntity - Sets a moderation state of archived on an entity.
2. RedirectEntity - Created a redirect for an entity to the defined destination.
3. ReplaceAlias - Replaces an entities url alias with the defined alias.

New action plugins can be added with the '@EntityJobAction' annotation by adding the plugin to `src/Plugins/Action`.

### Conditions

The following condition plugins currently exist with this module.

1. BooleanFieldIsTrue - Check if a boolean field on an entity is true.
2. EntityIsOfBundle - Check if an entity is of a given bundle.
3. EntityIsPublished - Check if an entity is published.
4. FieldReferencesId - Check if a field references an entity with a given ID.
5. OlderThan - Check if content was published over a certain time ago.

New condition plugins can be added with the '@EntityJobCondition' annotation by adding the plugin to `src/Plugins/Condition`.

Note: the annotation names were changed so as not to clash with core annotations.

An example of a job

`entity_jobs.job.article_archive.yml`

```
id: article_archive
label: 'Article archive'
subject_entity_type_id: node
actions:
  redirect_entity:
    action_id: redirect_entity
    action_options:
      destination_path:
        action_option_id: destination_path
        action_option_value: 'internal:/node/4'
  archive_entity:
    action_id: archive_entity
  replace_alias:
    action_id: replace_alias
    action_options:
      path:
        action_option_id: path
        action_option_value: '/archive/[node:title]'
conditions:
  entity_is_published:
    condition_id: entity_is_published
    condition_options:
      negate:
        condition_option_id: negate
        condition_option_value: 0
  entity_is_of_bundle:
    condition_id: entity_is_of_bundle
    condition_options:
      bundle:
        condition_option_id: bundle
        condition_option_value: article
  boolean_field_is_true_excluded:
    condition_id: boolean_field_is_true
    condition_options:
      negate:
        condition_option_id: negate
        condition_option_value: 1
      field_name:
        condition_option_id: field_name
        condition_option_value: field_exclude_from_archiving_job
  older_than:
    condition_id: older_than
    condition_options:
      time_ago:
        condition_option_id: time_ago
        condition_option_value: '5 years'
      field:
        condition_option_id: field
        condition_option_value: field_publish_date
  field_references_entity_with_id_book:
    condition_id: field_references_entity_with_id
    condition_options:
      negate:
        condition_option_id: negate
        condition_option_value: 1
      field_name:
        condition_option_id: field_name
        condition_option_value: field_taxonomy_ref
      referenced_entity_id:
        condition_option_id: referenced_entity_id
        condition_option_value: 81
```
