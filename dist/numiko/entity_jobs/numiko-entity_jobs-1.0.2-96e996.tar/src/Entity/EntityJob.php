<?php

namespace Drupal\entity_jobs\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBase;
use Drupal\Core\Entity\Annotation\ConfigEntityType;
use Drupal\entity_jobs\EntityJobInterface;

/**
 * Defines the EntityJob entity.
 *
 * @ConfigEntityType(
 *   id = "entity_job",
 *   label = @Translation("Entity Job"),
 *   handlers = {
 *     "list_builder" = "Drupal\entity_jobs\Controller\EntityJobListBuilder",
 *   },
 *   config_prefix = "job",
 *   admin_permission = "administer site configuration",
 *   entity_keys = {
 *     "id" = "id",
 *     "subject_entity_type_id" = "subject_entity_type_id",
 *     "label" = "label",
 *     "actions" = "actions",
 *     "conditions" = "conditions",
 *   },
 *   config_export = {
 *     "id",
 *     "subject_entity_type_id",
 *     "label",
 *     "actions",
 *     "conditions",
 *   },
 *   links = {
 *     "run" = "/admin/config/system/entity-jobs/run/{entity_job}",
 *   }
 * )
 */
class EntityJob extends ConfigEntityBase implements EntityJobInterface {

  /**
   * The EntityJob ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The EntityJob label.
   *
   * @var string
   */
  protected $label;

  /**
   * The EntityJob subject entity type ID.
   *
   * @var string
   */
  protected $subject_entity_type_id;

  /**
   * Array of action plugin implementations with options.
   *
   * @var array
   */
  protected $actions;

  /**
   * Array of condition plugin implementations with options.
   *
   * @var array
   */
  protected $conditions;

  /**
   * {@inheritDoc}
   */
  public function getId(): string {
    return $this->id;
  }

  /**
   * {@inheritDoc}
   */
  public function getLabel(): string {
    return $this->label;
  }

  /**
   * {@inheritDoc}
   */
  public function getSubjectEntityTypeId(): string {
    return $this->subject_entity_type_id;
  }

  /**
   * {@inheritDoc}
   */
  public function getActions(): array {
    return $this->actions;
  }

  /**
   * {@inheritDoc}
   */
  public function getConditions(): array {
    return $this->conditions;
  }

  /**
   * Get Entity Job conditions with options.
   */
  public function getConditionPluginInstancesWithOptions(): array {
    $conditions = $this->getConditions();
    $instantiatedConditions = [];
    foreach ($conditions as $conditionId => $condition) {
      $instantiatedConditions[$conditionId]['plugin'] = \Drupal::service('plugin.manager.entity_jobs.conditions')->createInstance($condition['condition_id']);
      if (!isset($condition['condition_options'])) {
        continue;
      }
      $rawConditionOptions = $condition['condition_options'];
      $conditionOptions = [];
      foreach ($rawConditionOptions as $option) {
        $conditionOptions[$option['condition_option_id']] = $option['condition_option_value'];
      }
      $instantiatedConditions[$conditionId]['options'] = $conditionOptions;
    }
    return $instantiatedConditions;
  }

  /**
   * Get Entity Job actions with options.
   */
  public function getActionPluginInstancesWithOptions(): array {
    $actions = $this->getActions();
    $instantiatedActions = [];
    foreach ($actions as $action) {
      $instantiatedActions[$action['action_id']]['plugin'] = \Drupal::service('plugin.manager.entity_jobs.actions')->createInstance($action['action_id']);
      if (!isset($action['action_options'])) {
        continue;
      }
      $rawActionOptions = $action['action_options'];
      $actionOptions = [];
      foreach ($rawActionOptions as $option) {
        $actionOptions[$option['action_option_id']] = $option['action_option_value'];
      }
      $instantiatedActions[$action['action_id']]['options'] = $actionOptions;
    }
    return $instantiatedActions;
  }

}

