<?php

namespace Drupal\entity_jobs\Plugin\Condition;

use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\entity_jobs\Annotation\EntityJobCondition;
use Drupal\entity_jobs\ConditionInterface;

/**
 * @EntityJobCondition(
 *   id = "entity_is_published",
 *   title = @Translation("Entity is published"),
 *   description = @Translation("Check if an entity is published")
 * )
 */
class EntityIsPublished extends PluginBase implements ConditionInterface {

  /**
   * @inheritDoc
   */
  public function process(QueryInterface &$entityQuery, ?array $options = NULL): void {
    $negate = isset($options['negate']) && $options['negate'] == TRUE;
    $entityQuery->condition('status', !$negate);
  }
}
