<?php

namespace Drupal\entity_jobs\Plugin\Condition;

use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\entity_jobs\Annotation\EntityJobCondition;
use Drupal\entity_jobs\ConditionInterface;

/**
 * @EntityJobCondition(
 *   id = "boolean_field_is_true",
 *   title = @Translation("Boolean field is true"),
 *   description = @Translation("Check if a boolean field on an entity is true.")
 * )
 */
class BooleanFieldIsTrue extends PluginBase implements ConditionInterface {

  /**
   * @inheritDoc
   */
  public function process(QueryInterface &$entityQuery, ?array $options = NULL): void {
    $fieldName = $options['field_name'];
    $negate = isset($options['negate']) && $options['negate'] == TRUE;

    $orConditionGroup = $entityQuery->orConditionGroup();
    $orConditionGroup->condition($fieldName, !$negate);
    $orConditionGroup->notExists($fieldName);
    $entityQuery->condition($orConditionGroup);
  }
}
