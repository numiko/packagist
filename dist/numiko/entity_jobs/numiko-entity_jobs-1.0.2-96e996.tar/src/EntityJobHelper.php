<?php

namespace Drupal\entity_jobs;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\entity_jobs\Entity\EntityJob;
use Drupal\node\Entity\Node;

class EntityJobHelper {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager) {
    $this->entityTypeManager = $entityTypeManager;
  }


  /**
   * Run the actions for an entity job.
   *
   * @param \Drupal\entity_jobs\Entity\EntityJob $entityJob
   *   The entity job.
   * @param \Drupal\node\Node $entity
   *   The entity to run the actions on.
   *
   * @return void
   */
  public function runActions(EntityJob $entityJob, Node $entity) {
    $actionPlugins = $entityJob->getActionPluginInstancesWithOptions();
    foreach ($actionPlugins as $action) {
      if (isset($action['options'])) {
        $action['plugin']->process($entity, $action['options']);
        continue;
      }
      $action['plugin']->process($entity);
    }
  }

  /**
   * Run the conditions for an entity job.
   *
   * @param \Drupal\entity_jobs\Entity\EntityJob $entityJob
   *   The entity job.
   *
   * @return array|int
   */
  public function runConditions(EntityJob $entityJob) {
    $entityQuery = $this->entityTypeManager->getStorage($entityJob->getSubjectEntityTypeId())->getQuery();
    $conditionPlugins = $entityJob->getConditionPluginInstancesWithOptions();
    foreach ($conditionPlugins as $conditionPlugin) {
      $conditionPlugin['plugin']->process($entityQuery, $conditionPlugin['options']);
    }
    return $entityQuery->accessCheck(TRUE)->execute();
  }

}
