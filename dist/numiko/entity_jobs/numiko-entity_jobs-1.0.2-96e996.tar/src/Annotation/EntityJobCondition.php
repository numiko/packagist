<?php

namespace Drupal\entity_jobs\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Defines an entity_jobs Condition annotation object.
 *
 * Plugin Namespace: Plugin\Condition
 *
 * @see \Drupal\entity_jobs\ArchiverManager
 * @see \Drupal\entity_jobs\ArchiverInterface
 * @see plugin_api
 * @see hook_entity_jobs_condition_info_alter()
 *
 * @Annotation
 */
class EntityJobCondition extends Plugin {

  /**
   * The condition plugin ID.
   *
   * @var string
   */
  public $id;

  /**
   * The human-readable name of the condition plugin.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $title;

  /**
   * The description of the condition plugin.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $description;
}
