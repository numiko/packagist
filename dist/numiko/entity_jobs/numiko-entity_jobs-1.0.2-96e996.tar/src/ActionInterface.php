<?php

namespace Drupal\entity_jobs;

use Drupal\Core\Entity\EntityInterface;

/**
 * Defines the common interface for all entity_job Action classes.
 *
 * @see \Drupal\entity_jobs\ActionManager
 * @see \Drupal\entity_jobs\Annotation\EntityJobAction
 * @see plugin_api
 */
interface ActionInterface {

  /**
   * Process the action on a given entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity upon which to process the action.
   * @param array|null $options
   *   Optional options to pass to the action.
   *
   * @return bool
   *   Whether or not the action completed successfully.
   */
  public function process(EntityInterface $entity, ?array $options): bool;

}
