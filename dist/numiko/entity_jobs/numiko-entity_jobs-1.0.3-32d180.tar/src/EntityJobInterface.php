<?php

namespace Drupal\entity_jobs;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface defining an entity_job entity.
 */
interface EntityJobInterface extends ConfigEntityInterface {

  /**
   * Get EntityJob ID.
   *
   * @return string
   *   EntityJob ID.
   */
  public function getId(): string;

  /**
   * Get EntityJob label.
   *
   * @return string
   *   EntityJob label.
   */
  public function getLabel(): string;

  /**
   * Get EntityJob subject entity type ID.
   *
   * @return string
   *   EntityJob subject entity type ID.
   */
  public function getSubjectEntityTypeId(): string;

  /**
   * Get EntityJob actions.
   *
   * @return array
   *   Entity job actions.
   */
  public function getActions(): array;

  /**
   * Get EntityJob actions.
   *
   * @return array
   *   EntityJob actions.
   */
  public function getConditions(): array;

}

