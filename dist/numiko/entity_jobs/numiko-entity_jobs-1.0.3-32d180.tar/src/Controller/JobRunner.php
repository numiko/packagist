<?php

namespace Drupal\entity_jobs\Controller;

use Drupal\Core\Batch\BatchBuilder;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\DependencyInjection\DependencySerializationTrait;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\Core\Url;
use Drupal\entity_jobs\Entity\EntityJob;
use Drupal\entity_jobs\EntityJobHelper;
use Psr\Log\LogLevel;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a controller to run entity jobs.
 */
class JobRunner extends ControllerBase implements ContainerInjectionInterface {

  use DependencySerializationTrait;

  /**
   * The batch size.
   */
  const BATCH_SIZE = 10;

  /**
   * The entity job helper.
   *
   * @var \Drupal\entity_jobs\EntityJobHelper
   */
  protected $entityJobHelper;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The logger factory.
   *
   * @var \Drupal\Core\Logger\LoggerChannelFactoryInterface
   */
  protected $loggerFactory;

  /**
   * The messenger.
   *
   * @var \Drupal\Core\Messenger\MessengerInterface
   */
  protected $messenger;

  /**
   * Constructor.
   *
   * @param \Drupal\entity_jobs\EntityJobHelper $entityJobHelper
   *   The entity job helper.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Logger\LoggerChannelFactoryInterface $loggerFactory
   *   The logger factory.
   * @param \Drupal\Core\Messenger\MessengerInterface $messenger
   *   The messenger.
   */
  public function __construct(EntityJobHelper $entityJobHelper, EntityTypeManagerInterface $entityTypeManager, LoggerChannelFactoryInterface $loggerFactory, MessengerInterface $messenger) {
    $this->entityJobHelper = $entityJobHelper;
    $this->entityTypeManager = $entityTypeManager;
    $this->loggerFactory = $loggerFactory;
    $this->messenger = $messenger;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_job.helper'),
      $container->get('entity_type.manager'),
      $container->get('logger.factory'),
      $container->get('messenger')
    );
  }

  /**
   * Runs the entity jobs actions as a batch condition.
   *
   * @param \Drupal\entity_jobs\Entity\EntityJob $entity_job
   *   The entity job.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   *   An array suitable for drupal_render().
   */
  public function runJob(EntityJob $entity_job) {
    $targetEntityIds = $this->entityJobHelper->runConditions($entity_job);
    $batch = (new BatchBuilder())
      ->setTitle($this->t('Processing entity job actions'))
      ->setFinishCallback([$this, 'finishActionBatch'])
      ->setProgressMessage($this->t('Processed @current out of @total entities'))
      ->setInitMessage($this->t('Job actions batch is starting.'))
      ->addOperation([$this, 'processActionBatch'], [$entity_job, $targetEntityIds]);

    // Schedule the batch.
    batch_set($batch->toArray());
    return batch_process(Url::fromRoute('entity.entity_job.collection'));
  }

  /**
   * Batch process which runs the action plugins for an entity job.
   *
   * @param \Drupal\entity_jobs\Entity\EntityJob $entityJob
   *   The entity job.
   * @param array $entityIds
   *   The entity ids to process.
   * @param \ArrayAccess|array $context
   *   The context of the current batch, as defined in the @return void
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function processActionBatch(EntityJob $entityJob, array $entityIds, \ArrayAccess|array &$context){
    if (!isset($context['sandbox']['progress'])) {
      $context['sandbox']['progress'] = 0;
      $context['sandbox']['current_entity'] = 0;
      $context['sandbox']['total'] = count($entityIds);
    }
    $context['message'] = 'Running entity job ' . $entityJob->getLabel() . ' actions...';

    $entityIdsForCurrentBatch = array_slice($entityIds, $context['sandbox']['progress'],self::BATCH_SIZE, TRUE);

    foreach ($entityIdsForCurrentBatch as $entityId) {
      $context['sandbox']['current_entity'] = $entityId;
      $entity = $this->entityTypeManager->getStorage($entityJob->getSubjectEntityTypeId())->load($entityId);
      $this->entityJobHelper->runActions($entityJob, $entity);
      $context['results'][] = $entityId;
      $context['sandbox']['progress']++;
    }

    if ($context['sandbox']['progress'] != $context['sandbox']['total']) {
      $context['finished'] = $context['sandbox']['progress'] / $context['sandbox']['total'];
    }
  }

  /**
   * Finishes an action batch.
   *
   * @param bool $success
   *   Indicates whether the batch process was successful.
   * @param array $results
   *   Results information passed from the processing callback.
   * @param array $operations
   *   If $success is FALSE, contains the operations that remained unprocessed.
   */
  public function finishActionBatch(bool $success, array $results, array $operations) {
    // Check if the batch job was successful.
    if ($success) {
      $message = $this->formatPlural(
        count($results),
        'Successfully actioned @count entity for entity job.',
        'Successfully actioned @count entities for entity job.'
      );
      $this->messenger->addMessage($message);
      $this->loggerFactory->get('entity_jobs')->log(LogLevel::INFO, $message);
    }
    else {
      // Notify the user about the batch job failure.
      $message = $this->t('An error occurred while trying to action an entity job. Check the logs for details.');
      $this->messenger->addError($message);
      $this->loggerFactory->get('entity_jobs')->error($message);
    }
  }

}
