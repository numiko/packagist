<?php

namespace Drupal\entity_jobs\Controller;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a listing of EntityJob.
 */
class EntityJobListBuilder extends ConfigEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['label'] = $this->t('Label');
    $header['id'] = $this->t('Machine name');
    $header['subject_entity_type'] = $this->t('Entity type');
    $header['conditions'] = $this->t('Conditions');
    $header['actions'] = $this->t('Actions');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    $row['label'] = $entity->label();
    $row['id'] = $entity->id();
    $row['subject_entity_type'] = $entity->getSubjectEntityTypeId();
    $row['conditions']['data'] = ['#markup' => $this->formatPlugins($entity->getConditions(), 'condition')];
    $row['actions']['data'] = ['#markup' => $this->formatPlugins($entity->getActions(), 'action')];

    return $row + parent::buildRow($entity);
  }

  /**
   * Format generic plugin structure for readable output.
   *
   * @param array $plugins
   *   Module entity_jobs plugins.
   */
  protected function formatPlugins(array $plugins, string $pluginType): string {
    if (!$plugins) {
      return '';
    }
    $formatted = '<ul>';
    foreach ($plugins as $plugin) {
      $formatted .= '<li>' . $plugin[$pluginType . '_id'];
      if (!isset($plugin[$pluginType . '_options'])) {
        $formatted .= '</li>';
        continue;
      }
      $formatted .= '<ul>';
      $pluginOptions = $plugin[$pluginType . '_options'];
      foreach ($pluginOptions as $option) {
        $formatted .= '<li>' . $option[$pluginType . '_option_id'] . ': ' . $option[$pluginType . '_option_value'] . '</li>';
      }
      $formatted .= '</ul>';
    }
    return $formatted . '</ul>';
  }

  /**
   * {@inheritdoc}
   */
  public function getDefaultOperations(EntityInterface $entity) {
    $run = [
      'title' => t('Run job'),
      'weight' => 200,
      'url' => $entity->toUrl('run'),
    ];

    $operations = parent::getDefaultOperations($entity) + [
      'run' => $run,
    ];

    return $operations;
  }

}
