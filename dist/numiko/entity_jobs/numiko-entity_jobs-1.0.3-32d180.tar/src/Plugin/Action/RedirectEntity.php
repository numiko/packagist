<?php

namespace Drupal\entity_jobs\Plugin\Action;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\entity_jobs\ActionInterface;
use Drupal\entity_jobs\Annotation\EntityJobAction;
use Drupal\entity_jobs\Exception\UnsupportedConditionException;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * @EntityJobAction(
 *   id = "redirect_entity",
 *   title = @Translation("Redirect entity to new path"),
 *   description = @Translation("Create a redirect from the "),
 * )
 */
class RedirectEntity extends PluginBase implements ActionInterface, ContainerFactoryPluginInterface {

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructs a UpdateAlias object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, EntityTypeManagerInterface $entityTypeManager) {
    $this->entityTypeManager = $entityTypeManager;
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager')
    );
  }

  /**
   * {@inheritdoc}
   *
   * @param array $options
   *   destination_path: The redirect destination path.
   */
  public function process(EntityInterface $entity, ?array $options): bool {
    if (!method_exists($entity, 'toUrl')) {
      throw new UnsupportedConditionException('Cannot create redirect from entity as entity cannot generate a URL.');
    }

    if (!$options['destination_path']) {
      throw new UnsupportedConditionException('Option destination_path is required.');
    }

    $this->entityTypeManager->getStorage('redirect')->create([
      'redirect_source' => ltrim($entity->toUrl()->toString(), '/'),
      'redirect_redirect' => $options['destination_path'],
      'status_code' => 301,
    ])->save();

    return TRUE;
  }
}
