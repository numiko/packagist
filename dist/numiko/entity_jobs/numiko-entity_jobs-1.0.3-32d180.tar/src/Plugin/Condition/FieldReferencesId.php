<?php

namespace Drupal\entity_jobs\Plugin\Condition;

use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\entity_jobs\Annotation\EntityJobCondition;
use Drupal\entity_jobs\ConditionInterface;

/**
 * @EntityJobCondition(
 *   id = "field_references_entity_with_id",
 *   title = @Translation("Field references entity with ID"),
 *   description = @Translation("Check if a field references an entity with a given ID")
 * )
 */
class FieldReferencesId extends PluginBase implements ConditionInterface {

  /**
   * @inheritDoc
   */
  public function process(QueryInterface &$entityQuery, $options): void {
    $negate = $options['negate'];
    $fieldName = $options['field_name'];
    $referencedEntityId = $options['referenced_entity_id'];

    // Logic accounts for single or multiple values.
    if ($negate) {
      $orConditionGroup = $entityQuery->orConditionGroup();
      $orConditionGroup->condition($fieldName, $referencedEntityId, 'NOT IN');
      $orConditionGroup->notExists($fieldName);
      $entityQuery->condition($orConditionGroup);
      return;
    }

    $orConditionGroup = $entityQuery->orConditionGroup();
    $orConditionGroup->condition($fieldName, $referencedEntityId, '=');
    $orConditionGroup->condition($fieldName, $referencedEntityId, 'IN');
    $entityQuery->condition($orConditionGroup);
  }
}
