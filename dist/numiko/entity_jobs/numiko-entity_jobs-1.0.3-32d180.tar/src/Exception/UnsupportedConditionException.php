<?php

namespace Drupal\entity_jobs\Exception;

class UnsupportedConditionException extends \Exception {

}
