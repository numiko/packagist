<?php

namespace Drupal\entity_jobs\Exception;

class ActionException extends \Exception {

}
