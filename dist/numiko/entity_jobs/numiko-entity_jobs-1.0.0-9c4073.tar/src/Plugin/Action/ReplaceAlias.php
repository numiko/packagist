<?php

namespace Drupal\entity_jobs\Plugin\Action;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\entity_jobs\ActionInterface;
use Drupal\entity_jobs\Annotation\Action;
use Drupal\entity_jobs\Exception\UnsupportedConditionException;
use Drupal\pathauto\AliasCleaner;
use Drupal\pathauto\PathautoState;
use Drupal\token\Token;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * @Action(
 *   id = "replace_alias",
 *   title = @Translation("Replace alias"),
 *   description = @Translation("Replaces an entity's url alias"),
 * )
 */
class ReplaceAlias extends PluginBase implements ActionInterface, ContainerFactoryPluginInterface {

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * @var \Drupal\pathauto\AliasCleaner
   */
  protected $aliasCleaner;

  /**
   * @var \Drupal\token\Token
   */
  protected $token;

  /**
   * Constructs a ReplaceAlias object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin ID for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\pathauto\AliasCleaner $aliasCleaner
   *   The path auto alias cleaner.
   * @param \Drupal\token\Token $token
   *   Token manager.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, EntityTypeManagerInterface $entityTypeManager, AliasCleaner $aliasCleaner, Token $token) {
    $this->entityTypeManager = $entityTypeManager;
    $this->aliasCleaner = $aliasCleaner;
    $this->token = $token;
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('pathauto.alias_cleaner'),
      $container->get('token')
    );
  }

  /**
   * {@inheritdoc}
   *
   * @param array $options
   *   path: The url path.
   */
  public function process(EntityInterface $entity, $options): bool {

    if (!$options['path']) {
      throw new UnsupportedConditionException('Option path is required.');
    }

    // Delete existing alias.
    $alias_objects = $this->entityTypeManager->getStorage('path_alias')->loadByProperties([
      'path' => '/node/' . $entity->id(),
    ]);

    foreach ($alias_objects as $alias_object) {
      $alias_object->delete();
    }

    $alias = $this->token->replace($options['path'], ['node' => $entity], [
      'clear' => TRUE,
      'callback' => [$this->aliasCleaner, 'cleanTokenValues'],
    ]);

    $entity->set('path', [
      'alias' =>  $this->aliasCleaner->cleanAlias($alias),
      'pathauto' => PathautoState::SKIP,
    ]);

    $entity->save();

    return TRUE;
  }

}
