<?php

namespace Drupal\entity_jobs\Plugin\Condition;

use Drupal\Core\Entity\Query\QueryInterface;
use Drupal\Core\Plugin\PluginBase;
use Drupal\entity_jobs\Annotation\Condition;
use Drupal\entity_jobs\ConditionInterface;

/**
 * @Condition(
 *   id = "entity_is_of_bundle",
 *   title = @Translation("Entity is of bundle"),
 *   description = @Translation("Check if an entity is of a given bundle")
 * )
 */
class EntityIsOfBundle extends PluginBase implements ConditionInterface {

  /**
   * @inheritDoc
   */
  public function process(QueryInterface &$entityQuery, $bundle): void {
    $entityQuery->condition('type', $bundle);
  }
}
