<?php

namespace Drupal\entity_jobs;

use Drupal\Core\Entity\Query\QueryInterface;

/**
 * Defines the common interface for all entity_job Condition classes.
 *
 * @see \Drupal\entity_jobs\ConditionManager
 * @see \Drupal\entity_jobs\Annotation\Condition
 * @see plugin_api
 */
interface ConditionInterface {

  /**
   * Process the condition on a given entity.
   *
   * @param \Drupal\Core\Entity\Query\QueryInterface $entityQuery
   *   The entity query to which this condition should be added.
   * @param array|null $options
   *   The comparison value for the condition.
   */
  public function process(QueryInterface &$entityQuery, ?array $options): void;

}
