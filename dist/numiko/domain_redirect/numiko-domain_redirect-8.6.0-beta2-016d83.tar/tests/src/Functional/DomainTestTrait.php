<?php

namespace Drupal\Tests\domain_redirect\Functional;

use Drupal\domain\DomainInterface;

trait DomainTestTrait {

  /**
   * Load a domain by the domain id.
   *
   * @param string $domainId
   *   The domain id.
   *
   * @return \Drupal\domain\DomainInterface|null
   */
  public function getDomain(string $domainId) {
    return \Drupal::service('entity_type.manager')
      ->getStorage('domain')
      ->load($domainId);
  }

  /**
   * Load all published domains.
   *
   * @return array
   */
  public function getDomains() {
    return \Drupal::service('entity_type.manager')->getStorage('domain')->loadByProperties(['status' => 1]);
  }

  /**
   * Sets the active domain.
   *
   * Setting it as default means that the tests load the domain when browsing.
   *
   * @param string $domain_id
   *   The domain id.
   */
  public function setActiveDomain(string $domain_id) {
    $domain = $this->getDomain($domain_id);
    $domain->saveDefault();
    \Drupal::service('domain.negotiator')->setActiveDomain($domain);
  }

  /**
   * Create a user and login.
   *
   * @param array $roles
   *   Roles to assign.
   * @param array $domains
   *   Domains to assign.
   *
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function createUserWithDomainsAndLogin(array $roles, array $domains) {
    $user = $this->createUser();
    foreach ($roles as $role) {
      $user->addRole($role);
    }
    $user->set(self::DOMAIN_ACCESS_FIELD, $domains);
    $user->save();
    // Login.
    $this->drupalGet('user/login');
    $this->submitForm([
      'name' => $user->getAccountName(),
      'pass' => $user->passRaw,
    ], t('Log in'));

    $this->setCurrentUser($user);
  }

  /**
   * Wraps $this->drupalGet() to make a request to a specific domain.
   *
   * @param \Drupal\domain\DomainInterface $domain
   *   The target domains for the request.
   * @param string|\Drupal\Core\Url $path
   *   Drupal path or URL to load into Mink controlled browser.
   * @param array $options
   *   (optional) Options to be forwarded to the url generator.
   * @param string[] $headers
   *   An array containing additional HTTP request headers, the array keys are
   *   the header names and the array values the header values. This is useful
   *   to set for example the "Accept-Language" header for requesting the page
   *   in a different language. Note that not all headers are supported, for
   *   example the "Accept" header is always overridden by the browser. For
   *   testing REST APIs it is recommended to obtain a separate HTTP client
   *   using getHttpClient() and performing requests that way.
   *
   * @return string
   *   The retrieved HTML string, also available as $this->getRawContent().
   */
  protected function domainGet(DomainInterface $domain, $path, $options = [], $headers = []) {
    $this->setActiveDomain($domain->id());
    $url = $domain->getPath() . $path;
    return $this->drupalGet($url, $options, $headers);
  }

}
