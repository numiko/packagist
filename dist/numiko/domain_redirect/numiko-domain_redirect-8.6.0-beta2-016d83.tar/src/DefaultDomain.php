<?php

namespace Drupal\domain_redirect;

/**
 * Add a default value to a redirect domain.
 */
class DefaultDomain {

  /**
   * The default value callback for the domain field on the redirect table.
   *
   * @return int
   *   The current domain.
   */
  public static function defaultValue(): int {
    $domainNegotiator = \Drupal::service('domain.negotiator');
    if ($domainNegotiator) {
      $domainId = $domainNegotiator->getActiveDomain()->getDomainId();
      return $domainId;
    }
  }

}
