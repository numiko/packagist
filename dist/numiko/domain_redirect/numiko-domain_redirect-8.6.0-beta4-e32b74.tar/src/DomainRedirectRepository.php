<?php

namespace Drupal\domain_redirect;

use Drupal\Component\Utility\Crypt;
use Drupal\Core\Cache\CacheableMetadata;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Language\Language;
use Drupal\redirect\Entity\Redirect;
use Drupal\redirect\Exception\RedirectLoopException;
use Drupal\redirect\RedirectRepository;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Overrides RedirectRepository so that we can make redirect domain-aware.
 */
class DomainRedirectRepository extends RedirectRepository {

  /**
   * @var \Drupal\domain\DomainNegotiatorInterface
   */
  private $domainNegotiator;

  public function __construct(EntityTypeManagerInterface $manager, Connection $connection, ConfigFactoryInterface $config_factory, ?RequestStack $request_stack) {
    parent::__construct($manager, $connection, $config_factory, $request_stack);
    $this->domainNegotiator = \Drupal::service('domain.negotiator');
  }

  /**
   * Generates a domain-aware hash for a Redirect entity.
   *
   * @param $source_path
   *   The source path of the redirect.
   * @param array $query
   *   The query params of the redirect path.
   * @param string $language
   *   The redirect language.
   * @param int|null $domainId
   *   The domain ID if not using the currently active domain.
   *
   * @return string
   *  Domain-aware redirect hash.
   */
  public function generateDomainAwareRedirectHash($source_path, array $query = [], $language = Language::LANGCODE_NOT_SPECIFIED, int $domainId = NULL): string {
    $hash['redirect_hash'] = Redirect::generateHash($source_path, $query, $language);
    if (isset($domainId) || $activeDomain = $this->domainNegotiator->getActiveDomain()) {
      $hash['domain_id'] = $domainId ?: $activeDomain->getDomainId();
    }
    redirect_sort_recursive($hash, 'ksort');
    return Crypt::hashBase64(serialize($hash));
  }

  /**
   * {inheritdoc}
   *
   * Had to duplicate an uncomfortable amount of code to add in domain-awareness
   * in this method.
   * @param string $source_path
   * @param array $query
   * @param string $language
   * @param CacheableMetadata|null $cacheable_metadata
   */
  public function findMatchingRedirect($source_path, array $query = [], $language = Language::LANGCODE_NOT_SPECIFIED, ?CacheableMetadata $cacheable_metadata = NULL) {
    $hashes = [$this->generateDomainAwareRedirectHash($source_path, $query, $language)];
    if ($language != Language::LANGCODE_NOT_SPECIFIED) {
      $hashes[] = $this->generateDomainAwareRedirectHash($source_path, $query);
    }

    // Add a hash without the query string if using passthrough querystrings.
    if (!empty($query) && $this->config->get('passthrough_querystring')) {
      $hashes[] = $this->generateDomainAwareRedirectHash($source_path, [], $language);
      if ($language != Language::LANGCODE_NOT_SPECIFIED) {
        $hashes[] = $this->generateDomainAwareRedirectHash($source_path, []);
      }
    }

    // Only find redirects on the current domain.
    if ($activeDomain = $this->domainNegotiator->getActiveDomain()) {
      $domainId = $activeDomain->getDomainId();
    }

    // Load redirects by hash. A direct query is used to improve performance.
    if (isset($domainId)) {
      $rid = $this->connection->query('SELECT rid FROM {redirect} WHERE hash IN (:hashes[])  AND domain = :domainId ORDER BY LENGTH(redirect_source__query) DESC', [':hashes[]' => $hashes, ':domainId' => $domainId])->fetchField();
    }
    else {
      $rid = $this->connection->query('SELECT rid FROM {redirect} WHERE hash IN (:hashes[])  ORDER BY LENGTH(redirect_source__query) DESC', [':hashes[]' => $hashes])->fetchField();
    }

    if (!empty($rid)) {
      // Check if this is a loop.
      if (in_array($rid, $this->foundRedirects)) {
        throw new RedirectLoopException('/' . $source_path, $rid);
      }
      $this->foundRedirects[] = $rid;

      $redirect = $this->load($rid);
      if ($cacheable_metadata) {
        $cacheable_metadata->addCacheableDependency($redirect);
      }

      // Find chained redirects.
      if ($recursive = $this->findByRedirect($redirect, $language, $cacheable_metadata)) {
        // Reset found redirects.
        $this->foundRedirects = [];
        return $recursive;
      }

      return $redirect;
    }

    return NULL;
  }

  /**
   * {inheritdoc}
   *
   * Add domain-awareness
   */
  public function findBySourcePath($source_path) {
    $domainId = $this->domainNegotiator->getActiveDomain()->getDomainId();
    $ids = $this->manager->getStorage('redirect')->getQuery()
      ->condition('redirect_source.path', $source_path, 'LIKE')
      ->condition('domain', $domainId)
      ->accessCheck(TRUE)
      ->execute();
    return $this->manager->getStorage('redirect')->loadMultiple($ids);
  }
}
