# Domain-Aware Redirects

This module is for sites that use the Domain module.

Once installed, every redirect will have an associated domain. If you add a redirect, the redirect will be associated with the current domain (the one you are logged into).

Add a 'domain' filter to the redirect module to auto-filter admin domain list to the current domain (see domain_redirect_views_pre_build()).

If you have existing redirects, you will need to populate the new `domain` field in the `redirect` table for those. 

## TODO

* Modify the redirect view during install.
