<?php

namespace Drupal\Tests\domain_redirect\Functional;

use Drupal\Core\Session\AnonymousUserSession;
use Drupal\domain\DomainInterface;
use Drupal\Tests\domain\Functional\DomainTestBase;
use Drupal\user\UserInterface;

/**
 * Test that redirects still function as normal (as domain_redirect messes with
 * a lot of what this module does) as well as testing what this module adds.
 *
 */
class DomainRedirectTest extends DomainTestBase {

  public static $modules = [
    'domain_access',
    'node',
    'redirect',
    'domain_redirect',
  ];

  private $testDomains = [];
  private $testDomainNodes = [];
  private $user;

  protected function setUp() {
    parent::setUp();
    $this->createDomains();
    $this->createNodes();
    $this->createUserForAllDomains();
  }

  private function createDomains() {
    $this->domainCreateTestDomains(4, getenv('SIMPLETEST_BASE_DOMAIN_SUFFIX'), [
      '', // always the "base" domain
      getenv('SIMPLETEST_BASE_MSI_URL_FRAG'),
      getenv('SIMPLETEST_BASE_SCI_URL_FRAG'),
      getenv('SIMPLETEST_BASE_MEDIA_URL_FRAG'),
    ]);
    $testDomains = \Drupal::service('domain.loader')->loadMultiple();
    // Store the Domains
    foreach ($testDomains as $domain) {
      if ($domain->getHostname() != getenv('SIMPLETEST_BASE_DOMAIN_SUFFIX')) {
        $this->testDomains[] = $domain;
      }
    }
  }

  /**
   * Create array of test nodes. One for each domain - e.g. array index 0 is the
   * node on domain 0 in $this->testDomains.
   *
   * Domains aren't labelled as that would tie them to a particular project.
   */
  private function createNodes() {
    $this->testDomainNodes[0] = $this->createNode([
      'type' => 'page',
      DOMAIN_ACCESS_FIELD => [
        'entity' => $this->testDomains[0]
      ]
    ]);
    $this->testDomainNodes[1] = $this->createNode([
      'type' => 'page',
      DOMAIN_ACCESS_FIELD => [
        'entity' => $this->testDomains[1]
      ]
    ]);
  }

  private function createUserForAllDomains() {
    $this->user = $this->drupalCreateUser([
      'administer redirects',
      'administer redirect settings',
      'view the administration theme',
      'access administration pages',
    ]);
    $this->addDomainsToEntity(
      'user',
      $this->user->id(),
      [
        $this->testDomains[0]->id(),
        $this->testDomains[1]->id(),
        $this->testDomains[2]->id(),
      ],
      DOMAIN_ACCESS_FIELD
    );
  }

  /**
   * Check that redirect only applies to one domain
   *
   * First check that adding a redirect on one domain works as it should.
   *
   * Then carry on to other domains. It would be nice to split this test up,
   * but there's no point repeating adding to the first domain, and it would
   * take a lot longer to run.
   */
  public function testAddRedirects() {
    $this->assertTrue(
      $this->domainLogin(
        $this->testDomains[0],
        $this->user
      )
    );
    // Create a redirect
    $this->addRedirectToDomain(0);

//    echo $this->getSession()->getPage()->getHtml();
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->responseContains('The redirect has been saved');
    // Check that it shows in the table
    $this->assertSession()->elementContains(
      'css',
      'td.views-field-redirect-source__path',
      '/redirect-source'
    );
    // Check that the redirect actually works
    $this->domainGet($this->testDomains[0], 'redirect-source');
    $this->assertSession()->addressEquals('node/' . $this->testDomainNodes[0]->id());

    // Check that the redirect doesn't work on the other domains
    $this->domainGet($this->testDomains[1], 'redirect-source');
    $this->assertSession()->statusCodeEquals(404);
    $this->domainGet($this->testDomains[2], 'redirect-source');
    $this->assertSession()->statusCodeEquals(404);

    // Add redirect to 2nd domain
    $this->assertTrue(
      $this->domainLogin(
        $this->testDomains[1],
        $this->user
      )
    );
    // @todo at this point, it has not logged into domain 1.
    $this->addRedirectToDomain(1);
    $this->assertSession()->statusCodeEquals(200);
    $this->assertSession()->responseContains('The redirect has been saved');
    $this->assertSession()->elementContains(
      'css',
      'td.views-field-redirect-source__path',
      '/redirect-source'
    );

//    echo '*** ' . $this->getSession()->getCurrentUrl() . "\n";

    // Check that no other redirects are showing for this domain as the list
    // should only show redirects on the domain we are currently logged into.
    $this->assertSession()->elementsCount(
      'css',
      'td.views-field-redirect-source__path',
      1
    );

    // Check that the redirect actually works
    $this->domainGet($this->testDomains[1], 'redirect-source');
    $this->assertSession()->addressEquals('node/' . $this->testDomainNodes[1]->id());

    // Check that the first redirect still works
    $this->domainGet($this->testDomains[0], 'redirect-source');
    $this->assertSession()->addressEquals('node/' . $this->testDomainNodes[0]->id());

  }

  /**
   * @todo Split the test into here...
   */
  private function _testAddOneRedirect() {

  }

  /**
   * @todo ... and here
   *
   * Test that there are no problems when the same source path is added to
   * multiple domains.
   */
  private function _testAddMoreRedirects() {

  }

  private function addRedirectToDomain($domainIndex) {
    // Create a redirect
    $this->domainGet($this->testDomains[$domainIndex], 'admin/config/search/redirect/add');
    $this->assertSession()->statusCodeEquals(200);
    // Note: without language features enabled, the
    $this->submitForm(
      [
        'redirect_source[0][path]' => 'redirect-source',
        'redirect_redirect[0][uri]' => '/node/' . $this->testDomainNodes[$domainIndex]->id(),
        'status_code' => '301',
      ],
      t('Save')
    );
  }


  /**
   * ---------------------------------------------------------------------------------
   * @todo
   *
   * Everything below here should be:
   *  1. moved to a base class for domain tests
   *  2. used with DomainAccessBlockingTest too
   *
   * And the domain module hack patches/domain-domain-login-test.patch can then be removed
   */


  protected $domainLoggedInUser;

  /**
   * Login a user on a specific domain.
   *
   * Based on Drupal\domain\Tests\DomainTestBase::domainLogin, but allows us to
   * use phpunit tests instead of having to go back to simpletest.
   *
   * @param \Drupal\domain\DomainInterface $domain
   *   The domain to log the user into.
   * @param \Drupal\user\UserInterface $account
   *   The user account to login.
   */
  public function domainLogin(DomainInterface $domain, UserInterface $account) {
    if (!empty($this->domainLoggedInUser[$domain->id()])) {
      $this->domainLogout($domain);
    }

    // For this to work, we must reset the password to a known value.
    $pass = 'thisissatestpassword';
    /** @var UserInterface $user */
    $user = \Drupal::entityTypeManager()->getStorage('user')->load($account->id());
    $user->setPassword($pass)->save();
    $url = $domain->getPath() . 'user/login';
    $edit = ['name' => $account->getAccountName(), 'pass' => $pass];
    $this->drupalPostForm($url, $edit, t('Log in'));

    $account->sessionId = $this->getSession()->getCookie($this->getSessionName());

    if ($this->drupalUserIsLoggedIn($account)) {
      $this->domainLoggedInUser[$domain->id()] = $account;
      $this->container->get('current_user')->setAccount($account);
      return TRUE;
    }
    return FALSE;
  }

  /**
   * Based on BrowserTestBase::drupalLogout()
   *
   * @param \Drupal\domain\DomainInterface $domain
   */
  protected function domainLogout(DomainInterface $domain) {
    // Make a request to the logout page, and redirect to the user page, the
    // idea being if you were properly logged out you should be seeing a login
    // screen.
    $assert_session = $this->assertSession();
    $this->domainGet($domain, 'user/logout', ['query' => ['destination' => 'user']]);
    $assert_session->statusCodeEquals(200);
    $assert_session->fieldExists('name');
    $assert_session->fieldExists('pass');

    // @see BrowserTestBase::drupalUserIsLoggedIn()
    unset($this->domainLoggedInUser[$domain->id()]->sessionId);
    $this->domainLoggedInUser[$domain->id()] = FALSE;
    $this->container->get('current_user')->setAccount(new AnonymousUserSession());
  }

  /**
   * Wraps $this->drupalGet() to browse to a specific domains.
   *
   * @todo this is copied from DomainAccessBlockingTest. We need a common testing
   * module with a parent class?
   *
   * @param \Drupal\domain\DomainInterface $domain
   * @param string $path
   *
   * @return string
   */
  protected function domainGet(DomainInterface $domain, $path, $options = [], $headers = []) {
    $url = $domain->getPath() . $path;
    return $this->drupalGet($url, $options, $headers);
  }

}
