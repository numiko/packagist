# Domain-Aware Redirects

This module is for sites that use the Domain module.

Once installed, every redirect will have an associated domain. If you add a redirect, the redirect will be associated with the current domain (the one you are logged into).

Add a 'domain' filter to the redirect module to auto-filter admin domain list to the current domain (see domain_redirect_views_pre_build()).

__Important:__ If you have existing redirects with no domain field i.e. you have just installed this module, these will become redirects for the default domain. This seems like a sensible default, but if your use-case is different, you will need to fork this module.

## Tests

In order to run these tests, some setup is required.

Three variables need to be added to phpunit.xml:
* 'SIMPLETEST_BASE_HOSTNAME'
* 'SIMPLETEST_TEST_SUBDOMAIN_ONE'
* 'SIMPLETEST_TEST_SUBDOMAIN_TWO'

For example:
```
<env name="SIMPLETEST_BASE_HOSTNAME" value="web"/>
<env name="SIMPLETEST_TEST_SUBDOMAIN_ONE" value="test1"/>
<env name="SIMPLETEST_TEST_SUBDOMAIN_TWO" value="test2"/>
```

These hosts need to be accessible on the test server.

Using the examples given above, these hosts would need to be accessible:
```
https://web
https://test1.web
https://test2.web
```

## TODO

* Modify the redirect view during install.
