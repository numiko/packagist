<?php

namespace Drupal\Tests\domain_redirect\Functional;

use Drupal\domain\DomainInterface;
use Drupal\node\NodeInterface;
use Drupal\Tests\domain\Functional\DomainTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test that redirects function correctly on single and across multiple domains.
 *
 * @group domain-redirect
 */
class DomainRedirectTest extends DomainTestBase {

  use DomainTestTrait;

  /**
   * @var string[]
   */
  public static $modules = [
    'domain_access',
    'node',
    'redirect',
    'domain_redirect',
  ];

  /**
   * The default domain access field.
   */
  const DOMAIN_ACCESS_FIELD = 'field_domain_access';

  /**
   * @var array
   */
  protected $testDomains = [];
  /**
   * @var array
   */
  protected $testDomainNodes = [];

  /**
   * @throws \Drupal\Core\Entity\EntityStorageException
   */
  public function setUp() : void {
    parent::setUp();
    $this->domainCreateTestDomains(3, getenv('SIMPLETEST_BASE_HOSTNAME'), [
      '', // Always the "base" domain.
      getenv('SIMPLETEST_TEST_SUBDOMAIN_ONE'),
      getenv('SIMPLETEST_TEST_SUBDOMAIN_TWO'),
    ]);
    $this->testDomains = array_values($this->getDomains());
    $this->createDomainNodes();
    $this->createUserWithDomainsAndLogin(
      [
        'administrator',
      ],
      [
        $this->testDomains[0]->id(),
        $this->testDomains[1]->id(),
        $this->testDomains[2]->id(),
      ],
    );
  }

  /**
   * Create array of test nodes. One for each domain - e.g. array index 0 is the
   * node on domain 0 in $this->testDomains.
   */
  private function createDomainNodes() {
    $this->testDomainNodes[0] = $this->createNode([
      'type' => 'page',
      self::DOMAIN_ACCESS_FIELD => [
        'entity' => $this->testDomains[0]
      ]
    ]);
    $this->testDomainNodes[1] = $this->createNode([
      'type' => 'page',
      self::DOMAIN_ACCESS_FIELD => [
        'entity' => $this->testDomains[1]
      ]
    ]);
  }

  /**
   * Test that a domain redirect only applies to one domain.
   */
  public function testAddOneRedirect() {
    // Create a redirect.
    $this->addRedirectToDomain($this->testDomains[0], $this->testDomainNodes[0]);

    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
    $this->assertSession()->responseContains('The redirect has been saved');
    // Test that it shows in the table.
    $this->assertSession()->elementContains(
      'css',
      'td.views-field-redirect-source__path',
      '/redirect-source'
    );
    // Test that the redirect actually works.
    $this->domainGet($this->testDomains[0], 'redirect-source');
    $this->assertSession()->addressEquals('node/' . $this->testDomainNodes[0]->id());

    // Test that the redirect doesn't work on the other domains.
    $this->domainGet($this->testDomains[1], 'redirect-source');
    $this->assertSession()->statusCodeEquals(Response::HTTP_NOT_FOUND);
    $this->domainGet($this->testDomains[2], 'redirect-source');
    $this->assertSession()->statusCodeEquals(Response::HTTP_NOT_FOUND);
  }

  /**
   * Test that a redirect can be added to multiple domains with the same source path.
   */
  public function testRedirectOnMultipleDomains() {
    // Create a redirect.
    $this->addRedirectToDomain($this->testDomains[0], $this->testDomainNodes[0]);

    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
    $this->assertSession()->responseContains('The redirect has been saved');
    // Test that it shows in the table.
    $this->assertSession()->elementContains(
      'css',
      'td.views-field-redirect-source__path',
      '/redirect-source'
    );
    // Test that the redirect actually works.
    $this->domainGet($this->testDomains[0], 'redirect-source');
    $this->assertSession()->addressEquals('node/' . $this->testDomainNodes[0]->id());

    // Test that the redirect doesn't work on the other domains.
    $this->domainGet($this->testDomains[1], 'redirect-source');
    $this->assertSession()->statusCodeEquals(Response::HTTP_NOT_FOUND);
    $this->domainGet($this->testDomains[2], 'redirect-source');
    $this->assertSession()->statusCodeEquals(Response::HTTP_NOT_FOUND);

    $this->addRedirectToDomain($this->testDomains[1], $this->testDomainNodes[1]);

    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
    $this->assertSession()->responseContains('The redirect has been saved');
    $this->assertSession()->elementContains(
      'css',
      'td.views-field-redirect-source__path',
      '/redirect-source'
    );

    // Test that the redirect actually works.
    $this->domainGet($this->testDomains[1], 'redirect-source');
    $this->assertSession()->addressEquals('node/' . $this->testDomainNodes[1]->id());

    // Test that the first redirect still works.
    $this->domainGet($this->testDomains[0], 'redirect-source');
    $this->assertSession()->addressEquals('node/' . $this->testDomainNodes[0]->id());
  }

  /**
   * Add a redirect from '/redirect-source' to a target node on a specific domain.
   *
   * @param \Drupal\domain\DomainInterface $domain
   *  The target domain to add the redirect to.
   * @param \Drupal\node\NodeInterface $nodeRedirect
   *  The target node to redirect to.
   *
   * @throws \Behat\Mink\Exception\ExpectationException
   */
  protected function addRedirectToDomain(DomainInterface $domain, NodeInterface $nodeRedirect) {
    // Create a redirect.
    $this->domainGet($domain, 'admin/config/search/redirect/add');
    $this->assertSession()->statusCodeEquals(Response::HTTP_OK);
    $this->submitForm(
      [
        'redirect_source[0][path]' => 'redirect-source',
        'redirect_redirect[0][uri]' => '/node/' . $nodeRedirect->id(),
        'status_code' => '301',
      ],
      t('Save')
    );
  }

}
