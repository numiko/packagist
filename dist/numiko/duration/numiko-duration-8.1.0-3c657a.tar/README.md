# Duration

Video duration field formatter

## Description

A custom _Duration_ widget and field formatter.

Video run time can be stored as seconds in an integer field.

The widget will display a _Minutes_ and _Seconds_ entry field.

e.g. Minutes:4 Seconds:27 is stored as 267 and displayed as 04:27
