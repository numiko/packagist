<?php

namespace Drupal\media_theme\Theme;

/**
 * Decorative elements for media.
 */
class MediaThemeHelper {

  /**
   * Get the verbose name for the file extension.
   *
   * Warning: This is not a security feature, and the extension should
   * not be relied upon to determine whether a file is harmful.
   */
  public function getVerboseFileExtension(string $extension) : string {
    switch ($extension) {
      case 'doc':
      case 'docx':
        return 'Word';

      case 'xls':
      case 'xlsx':
        return 'Excel';

      case 'ppt':
      case 'pptx':
        return 'Powerpoint';

      case 'pdf':
        return 'PDF';
    }
    return 'Document';
  }

  /**
   * Function to convert a file size in bytes to a more user-friendly format.
   *
   * @see http://jeffreysambells.com/2012/10/25/human-readable-filesize-php
   */
  public function getHumanReadableFilesize($bytes, $decimals = 2) : string {
    $size = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    $factor = floor((strlen($bytes) - 1) / 3);
    return sprintf("%.{$decimals}f", $bytes / pow(1024, $factor)) . @$size[$factor];
  }

}
