<?php

namespace Drupal\media_theme\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityFieldManager;
use Drupal\Core\Entity\EntityTypeBundleInfo;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Allows document-like media elements to be selected.
 */
class MediaThemeSettingsForm extends ConfigFormBase {

  /**
   * Entity bundle info.
   *
   * @var \Drupal\Core\Entity\EntityTypeBundleInfo
   */
  protected EntityTypeBundleInfo $bundleInfo;

  /**
   * Entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManager
   */
  protected EntityFieldManager $fieldManager;

  private const /*string*/ SETTINGS = 'media_theme.settings';

  /**
   * Form constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $cfi
   *   Usual form config.
   * @param \Drupal\Core\Entity\EntityTypeBundleInfo $bundleInfo
   *   Entity bundle info.
   * @param \Drupal\Core\Entity\EntityFieldManager $fieldManager
   *   Entity field manager.
   */
  public function __construct(ConfigFactoryInterface $cfi, EntityTypeBundleInfo $bundleInfo, EntityFieldManager $fieldManager) {
    parent::__construct($cfi);
    $this->bundleInfo = $bundleInfo;
    $this->fieldManager = $fieldManager;
  }

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.bundle.info'),
      $container->get('entity_field.manager')
    );
  }

  /**
   * {@inheritDoc}
   */
  public function getFormId(): string {
    return 'media_theme_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return [self::SETTINGS];
  }

  /**
   * {@inheritDoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config(self::SETTINGS);

    // Get a list of media types.
    $bundles = $this->bundleInfo->getBundleInfo('media');
    $bundleOptions = [];
    foreach ($bundles as $bundleId => $bundle) {
      $bundleOptions[$bundleId] = $bundle['label'];
    }
    $form['document_media_types'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Document media types'),
      '#description' => $this->t('Select all media that should be treated like a document by this module'),
      '#options' => $bundleOptions,
      '#default_value' => $config->get('document_media_types'),
    ];

    $mediaFieldBundleMap = [];
    foreach ($bundleOptions as $bundleId => $bundleName) {
      // For each media bundle, get each bundle's field definitions.
      $specificMediaFieldMap = $this->fieldManager->getFieldDefinitions('media', $bundleId);
      // We only care about field names so ignore everything else and filter out
      // those that don't begin with field_.
      $specificMediaFields = array_filter(
        array_keys($specificMediaFieldMap),
        fn($fieldName) => substr($fieldName, 0, 6) === 'field_'
      );

      foreach ($specificMediaFields as $field) {
        // For each field store a list of all the bundles it occurs in.
        if (array_key_exists($field, $mediaFieldBundleMap)) {
          $mediaFieldBundleMap[$field][] = $bundleName;
        }
        else {
          $mediaFieldBundleMap[$field] = [$bundleName];
        }
      }
    }

    // Finally convert the array into
    // `field_name => field_name (<strong>bundles</strong>)`.
    $textMap = [];
    foreach ($mediaFieldBundleMap as $field => $bundles) {
      $text = implode(', ', $bundles);
      $textMap[$field] = $field . ' (<strong>' . $text . '</strong>)';
    }

    $form['file_fields'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('The fields which contain files'),
      '#description' => $this->t('Select all fields which contain the actual file entities'),
      '#options' => $textMap,
      '#default_value' => $config->get('file_fields'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritDoc}
   */
  public function submitForm(array &$form, FormStateInterface $formState): void {
    // Process document_media_types.
    $bundleList = $formState->getValue('document_media_types');
    $bundleList = array_values(array_filter($bundleList));

    // Process file_fields.
    $fieldList = $formState->getValue('file_fields');
    $fieldList = array_values(array_filter($fieldList));

    $this->config(self::SETTINGS)
      ->set('document_media_types', $bundleList)
      ->set('file_fields', $fieldList)
      ->save();

    parent::submitForm($form, $formState);
  }

}
