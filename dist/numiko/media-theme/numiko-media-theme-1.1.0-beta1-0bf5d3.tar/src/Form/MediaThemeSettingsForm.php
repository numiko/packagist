<?php

namespace Drupal\media_theme\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeBundleInfo;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Allows document-like media elements to be selected.
 */
class MediaThemeSettingsForm extends ConfigFormBase {

  /**
   * Entity bundle info.
   *
   * @var \Drupal\Core\Entity\EntityTypeBundleInfo
   */
  protected EntityTypeBundleInfo $bundleInfo;

  private const /*string*/ SETTINGS = 'media_theme.settings';

  /**
   * Form constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $cfi
   *   Usual form config.
   * @param \Drupal\Core\Entity\EntityTypeBundleInfo $bundleInfo
   *   Entity bundle info.
   */
  public function __construct(ConfigFactoryInterface $cfi, EntityTypeBundleInfo $bundleInfo) {
    parent::__construct($cfi);
    $this->bundleInfo = $bundleInfo;
  }

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.bundle.info')
    );
  }

  /**
   * {@inheritDoc}
   */
  public function getFormId(): string {
    return 'media_theme_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return [self::SETTINGS];
  }

  /**
   * {@inheritDoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config(self::SETTINGS);

    // Get a list of media types.
    $bundles = $this->bundleInfo->getBundleInfo('media');
    $bundleOptions = [];
    foreach ($bundles as $bundleId => $bundle) {
      $bundleOptions[$bundleId] = $bundle['label'];
    }
    $form['document_media_types'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Document media types'),
      '#description' => $this->t('Select all media that should be treated like a document by this module'),
      '#options' => $bundleOptions,
      '#default_value' => $config->get('document_media_types'),
    ];

    $form['file_fields'] = [
      '#type' => 'textarea',
      '#title' => $this->t('The fields which contain files'),
      '#description' => $this->t('Newline seperated list of fields please'),
      '#default_value' => implode("\r\n", $config->get('file_fields')),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritDoc}
   */
  public function submitForm(array &$form, FormStateInterface $formState): void {
    // Process document_media_types.
    $bundleList = $formState->getValue('document_media_types');
    $bundleList = array_values(array_filter($bundleList));

    // Process file_fields.
    $fieldList = $formState->getValue('file_fields');
    $fieldList = $this->convertConfigStringsToArray($fieldList);

    $this->config(self::SETTINGS)
      ->set('document_media_types', $bundleList)
      ->set('file_fields', $fieldList)
      ->save();

    parent::submitForm($form, $formState);
  }

  /**
   * Split value from config's textarea to array.
   *
   * Each newline becomes a new array element.
   *
   * @param string $configuration
   *   The configuration textarea.
   *
   * @return array
   *   The config split up into an array
   */
  private function convertConfigStringsToArray(string $configuration): array {
    if ($configuration && !is_array($configuration)) {
      $configuration = preg_split('{\s*\r?\n\s*|,| }', $configuration, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
    }
    return $configuration;
  }

}
