# Media Themes

Adds extra theme elements that add extra document infomation to document templates

## Configuration

This module is set up for document media automatically but can extended to work for other media types.
