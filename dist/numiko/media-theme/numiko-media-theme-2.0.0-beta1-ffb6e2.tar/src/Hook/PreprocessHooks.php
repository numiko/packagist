<?php

namespace Drupal\media_theme\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\media_theme\MediaTheme;

/**
 * Hook add extension the media theme.
 */
final class PreprocessHooks {

  /**
   * Media Theme.
   *
   * @var \Drupal\media_theme\MediaTheme
   */
  protected MediaTheme $mediaTheme;

  public function __construct(protected MediaTheme $media_theme) {
    $this->mediaTheme = $media_theme;
  }

  /**
   * Implements hook_preprocess_media().
   *
   * Adds file extension, type and size for use in twig template.
   */
  #[Hook('preprocess_media')]
  function preprocessMedia(&$variables): void {
    if (!empty($variables['elements']['#media'])) {
      $documentLikeTypes = $this->mediaTheme->getDocumentLikeTypes();
      $media = $variables['elements']['#media'];

      if (in_array($media->bundle(), $documentLikeTypes, TRUE)) {
        // Iterate through the file fields until we find a valid file and
        // add parameters for file_extension, file_type_name & file_size.
        $this->mediaTheme->addFileVariables($variables, $media);
      }
    }
  }
}
