<?php

namespace Drupal\media_theme;

use Drupal\media_theme\Theme\MediaThemeHelper;
use Drupal\Core\Config\ConfigFactoryInterface;

class MediaTheme {

  /**
   * The media theme helper service.
   *
   * @var \Drupal\media_theme\Theme\MediaThemeHelper
   */
  protected MediaThemeHelper $mediaThemeHelper;

  /**
   * The media settings configuration.
   *
   * @var Drupal\Core\Config\ConfigFactoryInterface
   */
  protected ConfigFactoryInterface $configFactory;

  /**
   * Constructs a MediaTheme object.
   */
  public function __construct(MediaThemeHelper $media_theme_helper, ConfigFactoryInterface $config_factory) {
    $this->mediaThemeHelper = $media_theme_helper;
    $this->configFactory = $config_factory;
  }

  /**
   * Get the media settings configuration.
   */
  private function getMediaSettings(): object {
    return  $this->configFactory->get('media_theme.settings');
  }

  /**
   * Get the document-like media item types from
   * the media settings configuration.
   */
  public function getDocumentLikeTypes(): array {
    return $this->getMediaSettings()->get('document_media_types') ?? ['document'];
  }

  /**
   * Get the file fields configuration from media settings.
   */
  public function getFileFields(): array {
    return $this->getMediaSettings()->get('file_fields') ?? ['field_media_file'];
  }

  /**
   * Get the file entity attached to the media entity if available.
   */
  public function getFile(object $media): object | false {
    foreach ($this->getFileFields() as $fileField) {
      if ($media->hasField($fileField) && !$media->get($fileField)->isEmpty()) {
        return current($media->$fileField->referencedEntities());
      }
    }
    return false;
  }

  /**
   * Add extra file variables to allow the twig template display of file extension, type & size.
   */
  public function addFileVariables(&$variables, object $media): void {
    $file = $this->getFile($media);
    if ($file) {
      $variables['file_url'] = \Drupal::service('file_url_generator')->generateAbsoluteString($file->getFileUri());
      $path_parts = pathinfo($variables['file_url']);
      if (isset($path_parts['extension'])) {
        $extension = $path_parts['extension'];
        $variables['file_extension'] = $extension;
        $variables['file_type_name'] = $this->mediaThemeHelper->getVerboseFileExtension($path_parts['extension']);
        $variables['file_size'] = $this->mediaThemeHelper->getHumanReadableFilesize($file->getSize());
      }
    }
  }
}
