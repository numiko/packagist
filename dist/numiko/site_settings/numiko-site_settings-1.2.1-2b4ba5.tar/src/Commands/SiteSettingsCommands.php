<?php

namespace Drupal\site_settings\Commands;

use Drush\Commands\DrushCommands;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Defines Drush commands for the module.
 */
class SiteSettingsCommands extends DrushCommands {

  /**
   * The site settings storage.
   *
   * @var Drupal\site_settings\SiteSettingsStorageInterface
   */
  private $siteSettingsStorage;

  /**
   * SiteSettingsCommands object constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   */
  public function __construct(
    EntityTypeManagerInterface $entityTypeManager
  ) {
    $this->siteSettingsStorage = $entityTypeManager->getStorage('site_settings');
  }

  /**
   * Create a site settings object.
   *
   * @command site-settings:generate
   *
   * @param string $label
   *   The action to take. Possible actions are "create" (generate aliases for
   *   un-aliased paths only), "update" (update aliases for paths that have an
   *   existing alias) or "all" (generate aliases for all paths).
   *
   * @throws \Exception
   *
   * @usage drush site-settings:generate "Global"
   *   Generate a site settings object labelled "Global".
   */
  public function generateSiteSettings($label = NULL) {
    if (!$label) {
      return;
    }
    $siteSettings = $this->siteSettingsStorage->create([
      'label' => $label,
    ]);
    $siteSettings->save();
  }

}
