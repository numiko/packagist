<?php

declare(strict_types=1);

namespace Drupal\site_settings\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\site_settings\SiteSettingsInterface;

/**
 * Defines the site settings entity class.
 *
 * @ContentEntityType(
 *   id = "site_settings",
 *   label = @Translation("Site Settings"),
 *   label_collection = @Translation("Site Settingss"),
 *   label_singular = @Translation("site settings"),
 *   label_plural = @Translation("site settings"),
 *   label_count = @PluralTranslation(
 *     singular = "@count site settings",
 *     plural = "@count site settings",
 *   ),
 *   handlers = {
 *     "storage" = "Drupal\site_settings\SiteSettingsStorage",
 *     "list_builder" = "Drupal\site_settings\SiteSettingsListBuilder",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "access" = "Drupal\site_settings\SiteSettingsAccessControlHandler",
 *     "form" = {
 *       "add" = "Drupal\site_settings\Form\SiteSettingsForm",
 *       "edit" = "Drupal\site_settings\Form\SiteSettingsForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *       "delete-multiple-confirm" = "Drupal\Core\Entity\Form\DeleteMultipleForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\site_settings\Routing\SiteSettingsHtmlRouteProvider",
 *     },
 *   },
 *   base_table = "site_settings",
 *   data_table = "site_settings_field_data",
 *   translatable = TRUE,
 *   admin_permission = "administer site_settings",
 *   entity_keys = {
 *     "id" = "id",
 *     "langcode" = "langcode",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *   },
 *   links = {
 *     "collection" = "/admin/content/site-settings",
 *     "add-form" = "/site-settings/add",
 *     "canonical" = "/site-settings/{site_settings}",
 *     "edit-form" = "/site-settings/{site_settings}",
 *     "delete-form" = "/site-settings/{site_settings}/delete",
 *     "delete-multiple-form" = "/admin/content/site-settings/delete-multiple",
 *   },
 *   field_ui_base_route = "entity.site_settings.settings",
 * )
 */
final class SiteSettings extends ContentEntityBase implements SiteSettingsInterface {

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type): array {

    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['label'] = BaseFieldDefinition::create('string')
      ->setTranslatable(TRUE)
      ->setLabel(t('Label'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('view', TRUE);

    return $fields;
  }

}
