<?php

declare(strict_types=1);

namespace Drupal\site_settings\Entity;

use Drupal\Core\Condition\ConditionPluginCollection;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\site_settings\SiteSettingsInterface;

/**
 * Defines the site settings entity class.
 *
 * @ContentEntityType(
 *   id = "site_settings",
 *   label = @Translation("Site Settings"),
 *   label_collection = @Translation("Site Settings"),
 *   label_singular = @Translation("site settings"),
 *   label_plural = @Translation("site settings"),
 *   label_count = @PluralTranslation(
 *     singular = "@count site settings",
 *     plural = "@count site settings",
 *   ),
 *   bundle_label = @Translation("Site settings type"),
 *   handlers = {
 *     "storage" = "Drupal\site_settings\SiteSettingsStorage",
 *     "list_builder" = "Drupal\site_settings\SiteSettingsListBuilder",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "access" = "Drupal\site_settings\SiteSettingsAccessControlHandler",
 *     "form" = {
 *       "add" = "Drupal\site_settings\Form\SiteSettingsForm",
 *       "edit" = "Drupal\site_settings\Form\SiteSettingsForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *       "delete-multiple-confirm" = "Drupal\Core\Entity\Form\DeleteMultipleForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\site_settings\Routing\SiteSettingsHtmlRouteProvider",
 *     },
 *   },
 *   base_table = "site_settings",
 *   data_table = "site_settings_field_data",
 *   translatable = TRUE,
 *   admin_permission = "administer site_settings",
 *   entity_keys = {
 *     "id" = "id",
 *     "machine_name" = "machine_name",
 *     "bundle" = "bundle",
 *     "langcode" = "langcode",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *   },
 *   links = {
 *     "add-form" = "/admin/content/site-settings/add/{site_settings_type}",
 *     "add-page" = "/admin/content/site-settings/add",
 *     "edit-form" = "/admin/content/site-settings/{site_settings}/edit",
 *     "delete-form" = "/admin/content/site-settings/{site_settings}/delete",
 *     "collection" = "/admin/content/site-settings"
 *   },
 *   bundle_entity_type = "site_settings_type",
 *   field_ui_base_route = "entity.site_settings_type.edit_form"
 * )
 */
final class SiteSettings extends ContentEntityBase implements SiteSettingsInterface {

  /**
   * The visibility settings for this entity.
   *
   * @var array
   */
  protected $visibility = [];

  /**
   * The visibility collection.
   *
   * @var \Drupal\Core\Condition\ConditionPluginCollection
   */
  protected $visibilityCollection;

  /**
   * The condition plugin manager.
   *
   * @var \Drupal\Core\Executable\ExecutableManagerInterface
   */
  protected $conditionPluginManager;

  /**
   * Get the machine name.
   *
   * @return string|null
   */
  public function machineName() {
    return $this->get('machine_name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type): array {

    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['label'] = BaseFieldDefinition::create('string')
      ->setTranslatable(TRUE)
      ->setLabel(t('Label'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['machine_name'] = BaseFieldDefinition::create('string')
      ->setLabel('Machine name')
      ->setDescription('Machine name for internal use.')
      ->setRevisionable(FALSE);

    $fields['visibility'] = BaseFieldDefinition::create('map')
      ->setLabel(t('Visibility'))
      ->setDescription(t('Visibility of the site setting.'));

    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function getPluginCollections() {
    return [
      'visibility' => $this->getVisibilityConditions(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getVisibility() {
    return $this->getVisibilityConditions()->getConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function getVisibilityConditions() {
    if (!isset($this->visibilityCollection)) {
      $visibility = [];
      if (!$this->get('visibility')->isEmpty()) {
        $visibility = $this->get('visibility')->first()->getValue();
      }
      $this->visibilityCollection = new ConditionPluginCollection($this->conditionPluginManager(), $visibility);
    }
    return $this->visibilityCollection;
  }

  /**
   * Gets the condition plugin manager.
   *
   * @return \Drupal\Core\Executable\ExecutableManagerInterface
   *   The condition plugin manager.
   */
  protected function conditionPluginManager() {
    if (!isset($this->conditionPluginManager)) {
      $this->conditionPluginManager = \Drupal::service('plugin.manager.condition');
    }
    return $this->conditionPluginManager;
  }

  /**
   * {@inheritdoc}
   */
  public function preSave(EntityStorageInterface $storage) {
    parent::preSave($storage);

    if (!$this->isSyncing()) {
      foreach ($this->getPluginCollections() as $plugin_config_key => $plugin_collection) {
        $this->set($plugin_config_key, $plugin_collection->getConfiguration());
      }
    }
  }

}
