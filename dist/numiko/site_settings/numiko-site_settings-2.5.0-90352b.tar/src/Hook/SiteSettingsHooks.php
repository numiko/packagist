<?php

namespace Drupal\site_settings\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for site_settings.
 */
final class SiteSettingsHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'site_settings' => [
        'render element' => 'content',
      ],
    ];
  }

  /**
   * Implements hook_theme_suggestions_HOOK().
   */
  #[Hook('theme_suggestions_site_settings')]
  public function themeSuggestionsSiteSettings(array $variables): array {
    $suggestions = [];
    $site_settings = $variables['content']['#site_settings'];
    $sanitized_view_mode = strtr($variables['content']['#view_mode'], '.', '_');
    $suggestions[] = 'site_settings__' . $sanitized_view_mode;
    $suggestions[] = 'site_settings__' . $site_settings->bundle();
    $suggestions[] = 'site_settings__' . $site_settings->bundle() . '__' . $sanitized_view_mode;
    return $suggestions;
  }

}
