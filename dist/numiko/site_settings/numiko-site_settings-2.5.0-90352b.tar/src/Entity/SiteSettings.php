<?php

declare(strict_types=1);

namespace Drupal\site_settings\Entity;

use Drupal\Core\Condition\ConditionPluginCollection;
use Drupal\Core\Entity\Attribute\ContentEntityType;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\ContentEntityDeleteForm;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\Form\DeleteMultipleForm;
use Drupal\Core\Executable\ExecutableManagerInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\site_settings\Form\SiteSettingsForm;
use Drupal\site_settings\Routing\SiteSettingsHtmlRouteProvider;
use Drupal\site_settings\SiteSettingsAccessControlHandler;
use Drupal\site_settings\SiteSettingsInterface;
use Drupal\site_settings\SiteSettingsListBuilder;
use Drupal\site_settings\SiteSettingsStorage;
use Drupal\views\EntityViewsData;

/**
 * Defines the site settings entity class.
 */
#[ContentEntityType(
  id: 'site_settings',
  label: new TranslatableMarkup('Site Settings'),
  label_collection: new TranslatableMarkup('Site Settings'),
  label_singular: new TranslatableMarkup('site settings'),
  label_plural: new TranslatableMarkup('site settings'),
  label_count: [
    'singular' => '@count site settings',
    'plural' => '@count site settings',
  ],
  bundle_label: new TranslatableMarkup('Site settings type'),
  handlers: [
    'storage' => SiteSettingsStorage::class,
    'list_builder' => SiteSettingsListBuilder::class,
    'views_data' => EntityViewsData::class,
    'access' => SiteSettingsAccessControlHandler::class,
    'form' => [
      'add' => SiteSettingsForm::class,
      'edit' => SiteSettingsForm::class,
      'delete' => ContentEntityDeleteForm::class,
      'delete-multiple-confirm' => DeleteMultipleForm::class,
    ],
    'route_provider' => [
      'html' => SiteSettingsHtmlRouteProvider::class,
    ],
  ],
  base_table: 'site_settings',
  data_table: 'site_settings_field_data',
  translatable: TRUE,
  admin_permission: 'administer site_settings',
  entity_keys: [
    'id' => 'id',
    'machine_name' => 'machine_name',
    'bundle' => 'bundle',
    'langcode' => 'langcode',
    'label' => 'label',
    'uuid' => 'uuid',
  ],
  links: [
    'add-form' => '/admin/content/site-settings/add/{site_settings_type}',
    'add-page' => '/admin/content/site-settings/add',
    'edit-form' => '/admin/content/site-settings/{site_settings}/edit',
    'delete-form' => '/admin/content/site-settings/{site_settings}/delete',
    'collection' => '/admin/content/site-settings',
  ],
  bundle_entity_type: 'site_settings_type',
  field_ui_base_route: 'entity.site_settings_type.edit_form'
)]
final class SiteSettings extends ContentEntityBase implements SiteSettingsInterface {

  /**
   * The visibility settings for this entity.
   *
   * @var array
   */
  protected $visibility = [];

  /**
   * The visibility collection.
   *
   * @var \Drupal\Core\Condition\ConditionPluginCollection
   */
  protected $visibilityCollection;

  /**
   * The condition plugin manager.
   *
   * @var \Drupal\Core\Executable\ExecutableManagerInterface
   */
  protected $conditionPluginManager;

  /**
   * Get the machine name.
   *
   * @return string|null
   */
  public function machineName() {
    return $this->get('machine_name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type): array {

    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['label'] = BaseFieldDefinition::create('string')
      ->setTranslatable(TRUE)
      ->setLabel(t('Label'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('view', TRUE);

    $fields['machine_name'] = BaseFieldDefinition::create('string')
      ->setLabel('Machine name')
      ->setDescription('Machine name for internal use.')
      ->setRevisionable(FALSE);

    $fields['visibility'] = BaseFieldDefinition::create('map')
      ->setLabel(t('Visibility'))
      ->setDescription(t('Visibility of the site setting.'));

    return $fields;
  }

  /**
   * {@inheritdoc}
   */
  public function getPluginCollections(): array {
    return [
      'visibility' => $this->getVisibilityConditions(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getVisibility(): array {
    return $this->getVisibilityConditions()->getConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function getVisibilityConditions(): ConditionPluginCollection {
    if (!isset($this->visibilityCollection)) {
      $visibility = [];
      if (!$this->get('visibility')->isEmpty()) {
        $visibility = $this->get('visibility')->first()->getValue();
      }
      $this->visibilityCollection = new ConditionPluginCollection($this->conditionPluginManager(), $visibility);
    }
    return $this->visibilityCollection;
  }

  /**
   * Gets the condition plugin manager.
   *
   * @return \Drupal\Core\Executable\ExecutableManagerInterface
   *   The condition plugin manager.
   */
  protected function conditionPluginManager(): ExecutableManagerInterface {
    if (!isset($this->conditionPluginManager)) {
      $this->conditionPluginManager = \Drupal::service('plugin.manager.condition');
    }
    return $this->conditionPluginManager;
  }

  /**
   * {@inheritdoc}
   */
  public function preSave(EntityStorageInterface $storage): void {
    parent::preSave($storage);

    if (!$this->isSyncing()) {
      foreach ($this->getPluginCollections() as $plugin_config_key => $plugin_collection) {
        $this->set($plugin_config_key, $plugin_collection->getConfiguration());
      }
    }
  }

}
