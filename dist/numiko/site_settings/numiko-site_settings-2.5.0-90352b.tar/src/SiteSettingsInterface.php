<?php

declare(strict_types=1);

namespace Drupal\site_settings;

use Drupal\Core\Entity\ContentEntityInterface;

/**
 * Provides an interface defining a site settings entity type.
 */
interface SiteSettingsInterface extends ContentEntityInterface {}
