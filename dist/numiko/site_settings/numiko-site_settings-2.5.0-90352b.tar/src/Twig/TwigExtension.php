<?php

namespace Drupal\site_settings\Twig;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

/**
 * Twig extension for fetching site settings.
 */
class TwigExtension extends AbstractExtension {

  public function __construct(protected readonly EntityTypeManagerInterface $entityTypeManager) {}

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return [
      new TwigFunction('site_setting', $this->siteSetting(...)),
      new TwigFunction('instance_site_setting', $this->instanceSiteSetting(...)),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getName(): string {
    return 'site_settings';
  }

  /**
   * Returns a field value for a site setting for a given setting bundle.
   *
   * @param string $bundle
   *   The bundle of the site setting.
   * @param string $fieldName
   *   The setting field name to return.
   * @param string|null $defaultValue
   *   The default value to return.
   * @param string $viewMode
   *   The view mode to render.
   *
   * @return null|array
   *   A render array for the site setting field value.
   */
  public function siteSetting(string $bundle, string $fieldName, ?string $defaultValue = NULL, string $viewMode = 'default'): ?array {
    /** @var \Drupal\site_settings\SiteSettingsInterface[] $siteSettingEntities */
    $siteSettingEntities = $this->entityTypeManager->getStorage('site_settings')->loadByProperties(['bundle' => $bundle]);
    foreach ($siteSettingEntities as $siteSettings) {
      if (!$siteSettings->access('view', NULL, TRUE)->isAllowed()) {
        continue;
      }
      if (!$siteSettings->hasField($fieldName) || $siteSettings->get($fieldName)->isEmpty()) {
        return $defaultValue;
      }
      return $siteSettings->get($fieldName)->view($viewMode);
    }

    return $defaultValue;
  }

  /**
   * Returns a field value for a site setting for a given setting instance.
   *
   * The instance is referenced by assigning a machine name.
   *
   * @param string $instanceMachineName
   *   The machine name of the setting.
   * @param string $fieldName
   *   The setting field name to return.
   * @param string|null $defaultValue
   *   The default value to return.
   * @param string $viewMode
   *   The view mode to render.
   *
   * @return null|array
   *   A render array for the site setting field value for the given instance.
   */
  public function instanceSiteSetting(
    string $instanceMachineName,
    string $fieldName,
    ?string $defaultValue = NULL,
    string $viewMode = 'default',
  ): ?array {
    /** @var \Drupal\site_settings\SiteSettingsInterface[] $siteSettingEntities */
    $siteSettingEntities = $this->entityTypeManager->getStorage('site_settings')->loadByProperties(['machine_name' => $instanceMachineName]);
    $siteSettings = reset($siteSettingEntities);
    if (!$siteSettings || !$siteSettings->hasField($fieldName) || $siteSettings->get($fieldName)->isEmpty()) {
      return $defaultValue;
    }
    $access = $siteSettings->access('view', NULL, TRUE);
    if ($access->isAllowed()) {
      return $siteSettings->get($fieldName)->view($viewMode);
    }

    return $defaultValue;
  }

}
