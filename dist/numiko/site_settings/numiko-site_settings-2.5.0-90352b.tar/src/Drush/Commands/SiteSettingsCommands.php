<?php

namespace Drupal\site_settings\Drush\Commands;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drush\Attributes as CLI;
use Drush\Commands\AutowireTrait;
use Drush\Commands\DrushCommands;

/**
 * Defines Drush commands for the module.
 */
class SiteSettingsCommands extends DrushCommands {
  use AutowireTrait;

  /**
   * SiteSettingsCommands object constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   */
  public function __construct(protected readonly EntityTypeManagerInterface $entityTypeManager) {
    parent::__construct();
  }

  /**
   * Create a site settings object.
   *
   * @param string $bundle
   *   The site setting type bundle.
   * @param string $machineName
   *   The setting machine name.
   * @param string $label
   *   The setting label.
   *
   * @throws \Exception
   */
  #[CLI\Command(name: 'site-settings:generate')]
  #[CLI\Usage(name: 'drush site-settings:generate footer footer "Footer"', description: 'Generate a site settings object of bundle footer, with machine name footer labelled "Footer".')]
  public function generateSiteSettings(string $bundle, string $machineName, ?string $label = NULL): void {
    if (!$label) {
      return;
    }
    $siteSettings = $this->entityTypeManager->getStorage('site_settings')->create([
      'bundle' => $bundle,
      'machine_name' => $machineName,
      'label' => $label,
    ]);
    $siteSettings->save();
  }

}
