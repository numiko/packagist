<?php

declare(strict_types=1);

namespace Drupal\site_settings\Form;

use Drupal\Core\Condition\ConditionManager;
use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\SubformState;
use Drupal\Core\Language\LanguageManagerInterface;
use Drupal\Core\Plugin\Context\ContextRepositoryInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Form controller for the site settings entity edit forms.
 */
class SiteSettingsForm extends ContentEntityForm {

  /**
   * The context repository service.
   */
  protected ContextRepositoryInterface $contextRepository;

  /**
   * The condition plugin manager.
   */
  protected ConditionManager $manager;

  /**
   * The language manager service.
   */
  protected LanguageManagerInterface $language;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container): static {
    // Instantiates this form class.
    $instance = parent::create($container);
    $instance->contextRepository = $container->get('context.repository');
    $instance->manager = $container->get('plugin.manager.condition');
    $instance->language = $container->get('language_manager');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state): array {
    $form = parent::form($form, $form_state);
    $form['machine_name'] = [
      '#type' => 'machine_name',
      '#default_value' => $this->entity->machineName(),
      '#disabled' => !$this->entity->isNew(),
      '#maxlength' => EntityTypeInterface::BUNDLE_MAX_LENGTH,
      '#machine_name' => [
        'exists' => [$this, 'exists'],
        'source' => ['label', 'widget', 0, 'value'],
      ],
      '#description' => $this->t('A unique machine-readable name for this site settings. It must only contain lowercase letters, numbers, and underscores.'),
    ];
    $form_state->setTemporaryValue('gathered_contexts', $this->contextRepository->getAvailableContexts());
    $form['#tree'] = TRUE;
    $form['visibility'] = $this->buildVisibilityInterface([], $form_state);
    $form['visibility']['#weight'] = 100;
    return $form;
  }

  /**
   * Helper function for building the visibility UI form.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   *
   * @return array
   *   The form array with the visibility UI added in.
   */
  protected function buildVisibilityInterface(array $form, FormStateInterface $form_state) {
    $form['visibility_tabs'] = [
      '#type' => 'vertical_tabs',
      '#title' => $this->t('Visibility'),
      '#parents' => ['visibility_tabs'],
      '#attached' => [
        'library' => [
          'block/drupal.block',
        ],
      ],
    ];

    $visibility = $this->entity->getVisibility();
    $site_settings_type = $this->entityTypeManager->getStorage('site_settings_type')->load($this->entity->bundle());
    $enabled_plugins = $site_settings_type->get('conditions');
    foreach ($this->manager->getDefinitionsForContexts($form_state->getTemporaryValue('gathered_contexts')) as $condition_id => $definition) {
      if (!isset($enabled_plugins[$condition_id]) || $enabled_plugins[$condition_id] !== $condition_id || $enabled_plugins[$condition_id] === FALSE) {
        continue;
      }
      // Don't display the language condition until we have multiple languages.
      if ($condition_id == 'language' && !$this->language->isMultilingual()) {
        continue;
      }
      /** @var \Drupal\Core\Condition\ConditionInterface $condition */
      $condition = $this->manager->createInstance($condition_id, $visibility[$condition_id] ?? []);
      $form_state->set(['conditions', $condition_id], $condition);
      $condition_form = $condition->buildConfigurationForm([], $form_state);
      $condition_form['#type'] = 'details';
      $condition_form['#title'] = $condition->getPluginDefinition()['label'];
      $condition_form['#group'] = 'visibility_tabs';
      $form[$condition_id] = $condition_form;
    }

    if (isset($form['request_path'])) {
      $form['request_path']['#title'] = $this->t('Pages');
      $form['request_path']['negate']['#type'] = 'radios';
      $form['request_path']['negate']['#default_value'] = (int) $form['request_path']['negate']['#default_value'];
      $form['request_path']['negate']['#title_display'] = 'invisible';
      $form['request_path']['negate']['#options'] = [
        $this->t('Show for the listed pages'),
        $this->t('Hide for the listed pages'),
      ];
    }

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
    $this->validateVisibility($form, $form_state);
  }

  /**
   * Helper function to independently validate the visibility UI.
   *
   * @param array $form
   *   A nested array form elements comprising the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  protected function validateVisibility(array $form, FormStateInterface $form_state): void {
    // Validate visibility condition settings.
    $visibility = $form_state->getValue('visibility');
    if ($visibility) {
      foreach ($form_state->getValue('visibility') as $condition_id => $values) {
        // Allow the condition to validate the form.
        $condition = $form_state->get(['conditions', $condition_id]);
        $condition->validateConfigurationForm($form['visibility'][$condition_id], SubformState::createForSubform($form['visibility'][$condition_id], $form, $form_state));
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    parent::submitForm($form, $form_state);
    $visibility = $form_state->getValue('visibility');
    if ($visibility) {
      foreach ($form_state->getValue('visibility') as $condition_id => $values) {
        // Allow the condition to submit the form.
        $condition = $form_state->get(['conditions', $condition_id]);
        $condition->submitConfigurationForm($form['visibility'][$condition_id], SubformState::createForSubform($form['visibility'][$condition_id], $form, $form_state));

        $condition_configuration = $condition->getConfiguration();
        // Update the visibility conditions.
        $this->entity->getVisibilityConditions()->addInstanceId($condition_id, $condition_configuration);
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state): int {
    $result = parent::save($form, $form_state);

    $message_args = ['%label' => $this->entity->label()];
    $logger_args = [
      '%label' => $this->entity->label(),
    ];

    switch ($result) {
      case SAVED_NEW:
        $this->messenger()->addStatus($this->t('New site settings %label has been created.', $message_args));
        $this->logger('site_settings')->notice('New site settings %label has been created.', $logger_args);
        break;

      case SAVED_UPDATED:
        $this->messenger()->addStatus($this->t('The site settings %label has been updated.', $message_args));
        $this->logger('site_settings')->notice('The site settings %label has been updated.', $logger_args);
        break;

      default:
        throw new \LogicException('Could not save the entity.');
    }

    $form_state->setRedirectUrl($this->entity->toUrl('collection'));

    return $result;
  }

  /**
   * Determines if the site setting already exists.
   *
   * @param string $id
   *   The site setting ID.
   *
   * @return bool
   *   TRUE if the setting exists, FALSE otherwise.
   */
  public function exists($id) {
    $settings = $this->entityTypeManager->getStorage('site_settings')->loadByProperties(['machine_name' => $id]);
    return !empty($settings);
  }

}
