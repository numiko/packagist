<?php

namespace Drupal\site_settings\Twig;

use Twig\TwigFunction;
use Twig\Extension\AbstractExtension;

/**
 * Twig extension for handling media.
 *
 * Dependency injection is not used for performance reason.
 */
class TwigExtension extends AbstractExtension {

  /**
   * {@inheritdoc}
   */
  public function getFunctions() {
    return [
      new TwigFunction('site_setting', [$this, 'siteSetting']),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return 'site_settings';
  }

  /**
   * Returns the render array for an entity.
   *
   * @param string $machineName
   * *   The machine name of the setting.
   * @param string $fieldName
   *   The setting field name to return.
   * @param string|null $defaultValue
   *   The default value to return.
   * @param string $viewMode
   *   The view mode to render.
   *
   * @return null|array
   *   A render array for the site setting field value.
   */
  public function siteSetting(string $machineName, string $fieldName, ?string $defaultValue = NULL, string $viewMode = 'default') {
    /** @var Drupal\site_settings\SiteSettingsStorage */
    $storage = \Drupal::entityTypeManager()->getStorage('site_settings');
    $siteSettingEntities = $storage->loadByProperties(['machine_name' => $machineName]);
    $siteSettings = reset($siteSettingEntities);
    if (!$siteSettings || !$siteSettings->hasField($fieldName) || $siteSettings->get($fieldName)->isEmpty()) {
      return $defaultValue;
    }
    return $siteSettings->get($fieldName)->view($viewMode);
  }

}
