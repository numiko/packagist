<?php

namespace Drupal\site_settings;

use Drupal\Core\Entity\Sql\SqlContentEntityStorage;

/**
 * Defines the storage handler class for site settings.
 *
 * This extends the base storage class, adding required special handling for
 * site settings entities.
 */
class SiteSettingsStorage extends SqlContentEntityStorage {

  /**
   * Load the active site settings.
   *
   * We anticipate only ever having one site settings per language, therefore
   * we just return the first result.
   */
  public function loadActive() : ?SiteSettingsInterface {
    return current($this->loadMultiple());
  }

}
