# Site Settings

When setting up a new site the first thing to do is setup a site setting object, the complexity of this will be driven by the nature of the site, e.g. multilingual, domains, etc.

Currently the site settings has a bunch of pre-defined fields (telephone, email, copyright, etc) but you can add and remove fields as best suits the site.

## Usage

### By Bundle

In order to output an element from site settings in a template you can use the `site_setting` twig function using the bundle of the setting and the field name that you need to output.

For example with the telephone number:

```
{{ site_setting('footer', 'field_telephone') }}
```

Where `footer` is the bundle, if there are multiple instances of this bundle the visibility options will be used to determine which setting to output.

### By Specific Setting Instance

In order to output an element from a specific site settings in a template you can use the `instance_site_setting` twig function using the machine name of the specific setting instance and the field name that you need to output.

For example with the telephone number of a specific instance of the footer bundle called `my_site_footer`:

```
{{ instance_site_setting('my_site_footer', 'field_telephone') }}
```


## Extendability

In order to modify the site settings object returned you can alter the SiteSettings storage handler and change the loadActive method to suit your needs.
