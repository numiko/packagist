<?php

namespace Drupal\site_settings\Form;

use Drupal\Core\Entity\BundleEntityFormBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form handler for site setting type forms.
 */
class SiteSettingsTypeForm extends BundleEntityFormBase {

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state): array {
    $form = parent::form($form, $form_state);

    $entity_type = $this->entity;
    if ($this->operation == 'add') {
      $form['#title'] = $this->t('Add site settings type');
    }
    else {
      $form['#title'] = $this->t(
        'Edit %label site settings type',
        ['%label' => $entity_type->label()]
      );
    }

    $form['label'] = [
      '#title' => $this->t('Label'),
      '#type' => 'textfield',
      '#default_value' => $entity_type->label(),
      '#description' => $this->t('The human-readable name of this site settings type.'),
      '#required' => TRUE,
      '#size' => 30,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $entity_type->id(),
      '#maxlength' => EntityTypeInterface::BUNDLE_MAX_LENGTH,
      '#machine_name' => [
        'exists' => ['Drupal\site_settings\Entity\SiteSettingsType', 'load'],
        'source' => ['label'],
      ],
      '#description' => $this->t('A unique machine-readable name for this site settings type. It must only contain lowercase letters, numbers, and underscores.'),
    ];

    $options = $this->getConditionOptions();
    $form['conditions'] = [
      '#title' => $this->t('Conditions'),
      '#type' => 'checkboxes',
      '#options' => $options,
      '#default_value' => $entity_type->get('conditions') ? $entity_type->get('conditions') : [],
      '#description' => $this->t('Enabled condition plugins'),
    ];

    return $this->protectBundleIdElement($form);
  }

  /**
   * {@inheritdoc}
   */
  protected function actions(array $form, FormStateInterface $form_state) {
    $actions = parent::actions($form, $form_state);
    $actions['submit']['#value'] = $this->t('Save site settings type');
    $actions['delete']['#value'] = $this->t('Delete site settings type');
    return $actions;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $entity_type = $this->entity;

    $entity_type->set('id', trim($entity_type->id()));
    $entity_type->set('label', trim($entity_type->label()));

    $status = $entity_type->save();

    $t_args = ['%name' => $entity_type->label()];
    if ($status == SAVED_UPDATED) {
      $message = $this->t('The site settings type %name has been updated.', $t_args);
    }
    elseif ($status == SAVED_NEW) {
      $message = $this->t('The site settings type %name has been added.', $t_args);
    }
    $this->messenger()->addStatus($message);

    $form_state->setRedirectUrl($entity_type->toUrl('collection'));
  }

  /**
   * Retrieves the condition options.
   *
   * @return array
   *   An associative array of condition options.
   */
  private function getConditionOptions() {
    $options = [];
    $condition_manager = \Drupal::service('plugin.manager.condition');
    $definitions = $condition_manager->getDefinitions();
    foreach ($definitions as $id => $condition) {
      $options[$id] = $condition['label'];
    }
    return $options;
  }

}
