<?php

declare(strict_types=1);

namespace Drupal\site_settings_tokens\Hook;

use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Field\EntityReferenceFieldItemListInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;

/**
 * Token hook implementations for Site Settings.
 */
final class SiteSettingsTokensHooks {

  use StringTranslationTrait;

  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly EntityFieldManagerInterface $entityFieldManager,
    TranslationInterface $stringTranslation,
  ) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Implements hook_token_info().
   *
   * Registers [site-settings:BUNDLE:FIELD] tokens for every string field
   * on every Site Settings bundle.
   */
  #[Hook('token_info')]
  public function tokenInfo(): array {
    $info = [
      'types' => [
        'site-settings' => [
          'name' => $this->t('Site settings'),
          'description' => $this->t('Tokens for Site Settings field values.'),
        ],
      ],
      'tokens' => ['site-settings' => []],
    ];

    $bundles = $this->entityTypeManager
      ->getStorage('site_settings_type')
      ->loadMultiple();

    foreach ($bundles as $bundle_id => $bundle) {
      $fields = $this->entityFieldManager
        ->getFieldDefinitions('site_settings', $bundle_id);

      foreach ($fields as $field_name => $definition) {
        // Expose string fields and entity references; skip base fields and
        // unsupported types (e.g. boolean, integer).
        if ($definition instanceof BaseFieldDefinition) {
          continue;
        }
        $supported = ['string', 'string_long', 'text', 'text_long', 'entity_reference'];
        if (!in_array($definition->getType(), $supported, TRUE)) {
          continue;
        }

        $args = ['%bundle' => $bundle->label(), '%field' => $definition->getLabel()];
        if ($definition->getType() === 'entity_reference') {
          $description = $this->t('URL path of the entity referenced by the %field field on the %bundle site setting.', $args);
        }
        else {
          $description = $this->t('Value of the %field field on the %bundle site setting.', $args);
        }

        $info['tokens']['site-settings'][$bundle_id . ':' . $field_name] = [
          'name' => $this->t('@bundle: @field', [
            '@bundle' => $bundle->label(),
            '@field'  => $definition->getLabel(),
          ]),
          'description' => $description,
        ];
      }
    }

    return $info;
  }

  /**
   * Implements hook_tokens().
   *
   * Resolves [site-settings:BUNDLE:FIELD] tokens to their stored values.
   */
  #[Hook('tokens')]
  public function tokens(string $type, array $tokens, array $data, array $options, BubbleableMetadata $bubbleableMetadata): array {
    if ($type !== 'site-settings') {
      return [];
    }

    $replacements = [];

    foreach ($tokens as $name => $original) {
      // Token name is "bundle_id:field_name".
      $parts = explode(':', $name, 2);
      if (count($parts) !== 2) {
        continue;
      }
      [$bundle_id, $field_name] = $parts;

      /** @var array<\Drupal\site_settings\SiteSettingsInterface> $entities */
      $entities = $this->entityTypeManager
        ->getStorage('site_settings')
        ->loadByProperties(['bundle' => $bundle_id]);

      if (!$entities) {
        continue;
      }

      $entity = reset($entities);

      if (!$entity->hasField($field_name)) {
        continue;
      }

      $field_list = $entity->get($field_name);

      if ($field_list->isEmpty()) {
        continue;
      }

      $bubbleableMetadata->addCacheableDependency($entity);

      if ($field_list instanceof EntityReferenceFieldItemListInterface) {
        $referenced_entities = $field_list->referencedEntities();
        $referenced = reset($referenced_entities) ?: NULL;
        if (!$referenced || !$referenced->hasLinkTemplate('canonical')) {
          continue;
        }
        $bubbleableMetadata->addCacheableDependency($referenced);
        $url = $referenced->toUrl('canonical');
        $url->setAbsolute(FALSE);
        $replacements[$original] = ltrim($url->toString(), '/');
      }
      else {
        $replacements[$original] = $field_list->value;
      }
    }

    return $replacements;
  }

}
