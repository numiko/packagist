<?php

declare(strict_types=1);

namespace Drupal\Tests\site_settings_tokens\Unit;

use Drupal\Core\Config\Entity\ConfigEntityInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Field\EntityReferenceFieldItemListInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\Core\Url;
use Drupal\Tests\UnitTestCase;
use Drupal\site_settings_tokens\Hook\SiteSettingsTokensHooks;
use PHPUnit\Framework\Attributes\CoversClass;

/**
 * Unit tests for SiteSettingsTokensHooks.
 */
#[CoversClass(SiteSettingsTokensHooks::class)]
class SiteSettingsTokensHooksTest extends UnitTestCase {

  private EntityTypeManagerInterface $entityTypeManager;
  private EntityFieldManagerInterface $entityFieldManager;
  private SiteSettingsTokensHooks $hooks;

  protected function setUp(): void {
    parent::setUp();

    $this->entityTypeManager = $this->createMock(EntityTypeManagerInterface::class);
    $this->entityFieldManager = $this->createMock(EntityFieldManagerInterface::class);

    $this->hooks = new SiteSettingsTokensHooks(
      $this->entityTypeManager,
      $this->entityFieldManager,
      $this->getStringTranslationStub(),
    );
  }

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  /**
   * Builds a mock bundle (SiteSettingsType) config entity.
   */
  private function makeBundleMock(string $id, string $label): object {
    $bundle = $this->createMock(ConfigEntityInterface::class);
    $bundle->method('label')->willReturn($label);
    $bundle->method('id')->willReturn($id);
    return $bundle;
  }

  /**
   * Configures the entity type manager to return $bundles from the
   * site_settings_type storage.
   */
  private function setupTypesStorage(array $bundles): void {
    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('loadMultiple')->willReturn($bundles);

    $this->entityTypeManager
      ->method('getStorage')
      ->with('site_settings_type')
      ->willReturn($storage);
  }

  /**
   * Configures the entity type manager to return $entity from the
   * site_settings storage when queried for $bundle.
   */
  private function setupSettingsStorage(?object $entity, string $bundle): void {
    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->method('loadByProperties')
      ->with(['bundle' => $bundle])
      ->willReturn($entity ? [$entity] : []);

    $this->entityTypeManager
      ->method('getStorage')
      ->with('site_settings')
      ->willReturn($storage);
  }

  /**
   * Builds a configurable field definition mock of the given type.
   */
  private function makeFieldDefinition(string $type, string $label = 'A field'): FieldDefinitionInterface {
    $def = $this->createMock(FieldDefinitionInterface::class);
    $def->method('getType')->willReturn($type);
    $def->method('getLabel')->willReturn($label);
    return $def;
  }

  /**
   * Builds a plain-text field item list test double with the given value.
   *
   * Returns an anonymous class (not an EntityReferenceFieldItemListInterface)
   * so that the string-field code path in tokens() is exercised.
   */
  private function makeStringFieldList(string $value): object {
    return new class($value) {

      public function __construct(public readonly string $value) {}

      public function isEmpty(): bool {
        return $this->value === '';
      }

    };
  }

  /**
   * Builds a mock entity reference field item list pointing to $referenced.
   */
  private function makeEntityReferenceFieldList(EntityInterface $referenced): EntityReferenceFieldItemListInterface {
    $list = $this->createMock(EntityReferenceFieldItemListInterface::class);
    $list->method('isEmpty')->willReturn(FALSE);
    $list->method('referencedEntities')->willReturn([$referenced]);
    return $list;
  }

  /**
   * Builds a mock URL that returns $path from toString().
   *
   * setAbsolute() is chained so it returns the same mock.
   */
  private function makeUrlMock(string $path): Url {
    $url = $this->createMock(Url::class);
    $url->method('setAbsolute')->willReturn($url);
    $url->method('toString')->willReturn($path);
    return $url;
  }

  /**
   * Builds a mock entity that can produce a canonical URL.
   */
  private function makeReferencedEntity(string $urlPath): EntityInterface {
    $entity = $this->createMock(EntityInterface::class);
    $entity->method('hasLinkTemplate')->with('canonical')->willReturn(TRUE);
    $entity->method('toUrl')->with('canonical')->willReturn($this->makeUrlMock($urlPath));
    $entity->method('getCacheContexts')->willReturn([]);
    $entity->method('getCacheTags')->willReturn([]);
    $entity->method('getCacheMaxAge')->willReturn(-1);
    return $entity;
  }

  // ---------------------------------------------------------------------------
  // tokenInfo() — string fields
  // ---------------------------------------------------------------------------

  public function testTokenInfoReturnsSiteSettingsType(): void {
    $this->setupTypesStorage([]);

    $result = $this->hooks->tokenInfo();

    $this->assertArrayHasKey('site-settings', $result['types']);
  }

  public function testTokenInfoRegistersStringField(): void {
    $bundle = $this->makeBundleMock('mind_matters', 'Mind Matters');
    $this->setupTypesStorage(['mind_matters' => $bundle]);

    $this->entityFieldManager
      ->method('getFieldDefinitions')
      ->with('site_settings', 'mind_matters')
      ->willReturn([
        'field_resource_parent_path' => $this->makeFieldDefinition('string', 'Resource parent path'),
      ]);

    $result = $this->hooks->tokenInfo();

    $this->assertArrayHasKey('mind_matters:field_resource_parent_path', $result['tokens']['site-settings']);
  }

  public function testTokenInfoExcludesBaseFields(): void {
    $bundle = $this->makeBundleMock('mind_matters', 'Mind Matters');
    $this->setupTypesStorage(['mind_matters' => $bundle]);

    $this->entityFieldManager
      ->method('getFieldDefinitions')
      ->willReturn([
        'id'   => $this->createMock(BaseFieldDefinition::class),
        'type' => $this->createMock(BaseFieldDefinition::class),
      ]);

    $result = $this->hooks->tokenInfo();

    $this->assertEmpty($result['tokens']['site-settings']);
  }

  public function testTokenInfoRegistersAllSupportedStringTypes(): void {
    $bundle = $this->makeBundleMock('test', 'Test');
    $this->setupTypesStorage(['test' => $bundle]);

    $this->entityFieldManager
      ->method('getFieldDefinitions')
      ->willReturn([
        'field_a' => $this->makeFieldDefinition('string'),
        'field_b' => $this->makeFieldDefinition('string_long'),
        'field_c' => $this->makeFieldDefinition('text'),
        'field_d' => $this->makeFieldDefinition('text_long'),
        'field_e' => $this->makeFieldDefinition('boolean'),
      ]);

    $result = $this->hooks->tokenInfo();
    $tokens = $result['tokens']['site-settings'];

    $this->assertArrayHasKey('test:field_a', $tokens);
    $this->assertArrayHasKey('test:field_b', $tokens);
    $this->assertArrayHasKey('test:field_c', $tokens);
    $this->assertArrayHasKey('test:field_d', $tokens);
    $this->assertArrayNotHasKey('test:field_e', $tokens);
  }

  public function testTokenInfoTokenNameContainsBundleAndFieldLabel(): void {
    $bundle = $this->makeBundleMock('mind_matters', 'Mind Matters');
    $this->setupTypesStorage(['mind_matters' => $bundle]);

    $this->entityFieldManager
      ->method('getFieldDefinitions')
      ->willReturn([
        'field_resource_parent_path' => $this->makeFieldDefinition('string', 'Resource parent path'),
      ]);

    $result = $this->hooks->tokenInfo();
    $name = (string) $result['tokens']['site-settings']['mind_matters:field_resource_parent_path']['name'];

    $this->assertStringContainsString('Mind Matters', $name);
    $this->assertStringContainsString('Resource parent path', $name);
  }

  // ---------------------------------------------------------------------------
  // tokenInfo() — entity reference fields
  // ---------------------------------------------------------------------------

  public function testTokenInfoRegistersEntityReferenceField(): void {
    $bundle = $this->makeBundleMock('find_a_vet', 'Find a Vet');
    $this->setupTypesStorage(['find_a_vet' => $bundle]);

    $this->entityFieldManager
      ->method('getFieldDefinitions')
      ->willReturn([
        'field_vet_listing_page' => $this->makeFieldDefinition('entity_reference', 'Vet listing page'),
      ]);

    $result = $this->hooks->tokenInfo();

    $this->assertArrayHasKey('find_a_vet:field_vet_listing_page', $result['tokens']['site-settings']);
  }

  public function testTokenInfoEntityReferenceDescriptionMentionsUrlPath(): void {
    $bundle = $this->makeBundleMock('find_a_vet', 'Find a Vet');
    $this->setupTypesStorage(['find_a_vet' => $bundle]);

    $this->entityFieldManager
      ->method('getFieldDefinitions')
      ->willReturn([
        'field_vet_listing_page' => $this->makeFieldDefinition('entity_reference', 'Vet listing page'),
      ]);

    $result = $this->hooks->tokenInfo();
    $description = (string) $result['tokens']['site-settings']['find_a_vet:field_vet_listing_page']['description'];

    $this->assertStringContainsStringIgnoringCase('url', $description);
  }

  // ---------------------------------------------------------------------------
  // tokens() — wrong type / malformed input
  // ---------------------------------------------------------------------------

  public function testTokensReturnsEmptyArrayForNonSiteSettingsType(): void {
    $result = $this->hooks->tokens('node', ['title' => '[node:title]'], [], [], $this->createMock(BubbleableMetadata::class));

    $this->assertEmpty($result);
  }

  public function testTokensSkipsMalformedTokenName(): void {
    $storage = $this->createMock(EntityStorageInterface::class);
    $storage->expects($this->never())->method('loadByProperties');

    $this->entityTypeManager->method('getStorage')->willReturn($storage);

    $result = $this->hooks->tokens(
      'site-settings',
      ['no_colon_here' => '[site-settings:no_colon_here]'],
      [],
      [],
      $this->createMock(BubbleableMetadata::class),
    );

    $this->assertEmpty($result);
  }

  public function testTokensReturnsEmptyWhenBundleNotFound(): void {
    $this->setupSettingsStorage(NULL, 'unknown_bundle');

    $result = $this->hooks->tokens(
      'site-settings',
      ['unknown_bundle:field_name' => '[site-settings:unknown_bundle:field_name]'],
      [],
      [],
      $this->createMock(BubbleableMetadata::class),
    );

    $this->assertEmpty($result);
  }

  public function testTokensReturnsEmptyWhenFieldDoesNotExist(): void {
    $entity = $this->createMock(FieldableEntityInterface::class);
    $entity->method('hasField')->willReturn(FALSE);

    $this->setupSettingsStorage($entity, 'mind_matters');

    $result = $this->hooks->tokens(
      'site-settings',
      ['mind_matters:field_missing' => '[site-settings:mind_matters:field_missing]'],
      [],
      [],
      $this->createMock(BubbleableMetadata::class),
    );

    $this->assertEmpty($result);
  }

  // ---------------------------------------------------------------------------
  // tokens() — string field resolution
  // ---------------------------------------------------------------------------

  public function testTokensReturnsEmptyWhenStringFieldIsEmpty(): void {
    $entity = $this->createMock(FieldableEntityInterface::class);
    $entity->method('hasField')->willReturn(TRUE);
    $entity->method('get')->willReturn($this->makeStringFieldList(''));

    $this->setupSettingsStorage($entity, 'mind_matters');

    $result = $this->hooks->tokens(
      'site-settings',
      ['mind_matters:field_resource_parent_path' => '[site-settings:mind_matters:field_resource_parent_path]'],
      [],
      [],
      $this->createMock(BubbleableMetadata::class),
    );

    $this->assertEmpty($result);
  }

  public function testTokensResolvesStringFieldValue(): void {
    $entity = $this->createMock(FieldableEntityInterface::class);
    $entity->method('hasField')->willReturn(TRUE);
    $entity->method('get')
      ->with('field_resource_parent_path')
      ->willReturn($this->makeStringFieldList('veterinary-professionals/mind-matters/resources-and-cpd'));
    $entity->method('getCacheContexts')->willReturn([]);
    $entity->method('getCacheTags')->willReturn([]);
    $entity->method('getCacheMaxAge')->willReturn(-1);

    $this->setupSettingsStorage($entity, 'mind_matters');

    $result = $this->hooks->tokens(
      'site-settings',
      ['mind_matters:field_resource_parent_path' => '[site-settings:mind_matters:field_resource_parent_path]'],
      [],
      [],
      new BubbleableMetadata(),
    );

    $this->assertSame(
      'veterinary-professionals/mind-matters/resources-and-cpd',
      $result['[site-settings:mind_matters:field_resource_parent_path]'],
    );
  }

  public function testTokensAddsCacheDependencyOnEntity(): void {
    $entity = $this->createMock(FieldableEntityInterface::class);
    $entity->method('hasField')->willReturn(TRUE);
    $entity->method('get')->willReturn($this->makeStringFieldList('some-value'));
    $entity->method('getCacheContexts')->willReturn([]);
    $entity->method('getCacheTags')->willReturn(['site_settings:1']);
    $entity->method('getCacheMaxAge')->willReturn(-1);

    $this->setupSettingsStorage($entity, 'mind_matters');

    $meta = new BubbleableMetadata();
    $this->hooks->tokens(
      'site-settings',
      ['mind_matters:field_name' => '[site-settings:mind_matters:field_name]'],
      [],
      [],
      $meta,
    );

    $this->assertContains('site_settings:1', $meta->getCacheTags());
  }

  // ---------------------------------------------------------------------------
  // tokens() — entity reference field resolution
  // ---------------------------------------------------------------------------

  public function testTokensResolvesEntityReferenceToUrlPath(): void {
    $referenced = $this->makeReferencedEntity('/animal-owners/find-a-vet/people');

    $entity = $this->createMock(FieldableEntityInterface::class);
    $entity->method('hasField')->willReturn(TRUE);
    $entity->method('get')
      ->with('field_vet_listing_page')
      ->willReturn($this->makeEntityReferenceFieldList($referenced));
    $entity->method('getCacheContexts')->willReturn([]);
    $entity->method('getCacheTags')->willReturn([]);
    $entity->method('getCacheMaxAge')->willReturn(-1);

    $this->setupSettingsStorage($entity, 'find_a_vet');

    $result = $this->hooks->tokens(
      'site-settings',
      ['find_a_vet:field_vet_listing_page' => '[site-settings:find_a_vet:field_vet_listing_page]'],
      [],
      [],
      new BubbleableMetadata(),
    );

    // Leading slash stripped; token resolves to path without domain.
    $this->assertSame(
      'animal-owners/find-a-vet/people',
      $result['[site-settings:find_a_vet:field_vet_listing_page]'],
    );
  }

  public function testTokensAddsCacheDependencyOnReferencedEntity(): void {
    $referenced = $this->createMock(EntityInterface::class);
    $referenced->method('hasLinkTemplate')->with('canonical')->willReturn(TRUE);
    $referenced->method('toUrl')->with('canonical')->willReturn($this->makeUrlMock('/some/path'));
    $referenced->method('getCacheContexts')->willReturn([]);
    $referenced->method('getCacheTags')->willReturn(['node:42']);
    $referenced->method('getCacheMaxAge')->willReturn(-1);

    $entity = $this->createMock(FieldableEntityInterface::class);
    $entity->method('hasField')->willReturn(TRUE);
    $entity->method('get')->willReturn($this->makeEntityReferenceFieldList($referenced));
    $entity->method('getCacheContexts')->willReturn([]);
    $entity->method('getCacheTags')->willReturn(['site_settings:1']);
    $entity->method('getCacheMaxAge')->willReturn(-1);

    $this->setupSettingsStorage($entity, 'find_a_vet');

    $meta = new BubbleableMetadata();
    $this->hooks->tokens(
      'site-settings',
      ['find_a_vet:field_vet_listing_page' => '[site-settings:find_a_vet:field_vet_listing_page]'],
      [],
      [],
      $meta,
    );

    $this->assertContains('node:42', $meta->getCacheTags());
    $this->assertContains('site_settings:1', $meta->getCacheTags());
  }

  public function testTokensSkipsEntityReferenceWithNoCanonicalUrl(): void {
    $referenced = $this->createMock(EntityInterface::class);
    $referenced->method('hasLinkTemplate')->with('canonical')->willReturn(FALSE);

    $entity = $this->createMock(FieldableEntityInterface::class);
    $entity->method('hasField')->willReturn(TRUE);
    $entity->method('get')->willReturn($this->makeEntityReferenceFieldList($referenced));
    $entity->method('getCacheContexts')->willReturn([]);
    $entity->method('getCacheTags')->willReturn([]);
    $entity->method('getCacheMaxAge')->willReturn(-1);

    $this->setupSettingsStorage($entity, 'find_a_vet');

    $result = $this->hooks->tokens(
      'site-settings',
      ['find_a_vet:field_vet_listing_page' => '[site-settings:find_a_vet:field_vet_listing_page]'],
      [],
      [],
      new BubbleableMetadata(),
    );

    $this->assertEmpty($result);
  }

  public function testTokensStripsLeadingSlashFromEntityReferenceUrl(): void {
    // Drupal URL::toString() with setAbsolute(FALSE) returns a leading slash.
    $referenced = $this->makeReferencedEntity('/some/path');

    $entity = $this->createMock(FieldableEntityInterface::class);
    $entity->method('hasField')->willReturn(TRUE);
    $entity->method('get')->willReturn($this->makeEntityReferenceFieldList($referenced));
    $entity->method('getCacheContexts')->willReturn([]);
    $entity->method('getCacheTags')->willReturn([]);
    $entity->method('getCacheMaxAge')->willReturn(-1);

    $this->setupSettingsStorage($entity, 'find_a_vet');

    $result = $this->hooks->tokens(
      'site-settings',
      ['find_a_vet:field_listing' => '[site-settings:find_a_vet:field_listing]'],
      [],
      [],
      new BubbleableMetadata(),
    );

    $this->assertSame('some/path', $result['[site-settings:find_a_vet:field_listing]']);
  }

}
