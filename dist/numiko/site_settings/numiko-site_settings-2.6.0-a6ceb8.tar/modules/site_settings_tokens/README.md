# Site Settings Tokens

Exposes Site Settings field values as Drupal tokens, making them available anywhere tokens are supported (e.g. metatags, email templates, path aliases).

## Token format

```
[site-settings:BUNDLE:FIELD_NAME]
```

Where `BUNDLE` is the site settings bundle machine name and `FIELD_NAME` is the field machine name.

For example, to use the telephone number from the `footer` bundle:

```
[site-settings:footer:field_telephone]
```

## Supported field types

| Field type | Resolved value |
|---|---|
| `string`, `string_long` | Raw field value |
| `text`, `text_long` | Raw field value |
| `entity_reference` | Relative URL path of the referenced entity |

Base fields (e.g. `label`, `machine_name`) and unsupported field types (boolean, integer, etc.) are not currently exposed as tokens.

## Discovering available tokens

All available tokens are registered dynamically based on the bundles and fields configured on your site. Use the token browser (provided by the [Token](https://www.drupal.org/project/token) contrib module) or visit **Reports > Available tokens** to see the full list.
