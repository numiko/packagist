<?php

namespace Drupal\site_settings;

/**
 * Defines the storage handler class for site settings.
 *
 * This extends the base storage class, adding required special handling for
 * site settings entities.
 */
interface SiteSettingsStorageInterface {

  /**
   * {@inheritDoc}
   */
  public function loadActive() : ?SiteSettingsInterface;

}
