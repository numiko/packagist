<?php

declare(strict_types=1);

namespace Drupal\site_settings\Form;

use Drupal\Core\Entity\ContentEntityForm;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form controller for the site settings entity edit forms.
 */
class SiteSettingsForm extends ContentEntityForm {

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);
    $form['machine_name'] = [
      '#type' => 'machine_name',
      '#default_value' => $this->entity->machineName(),
      '#disabled' => !$this->entity->isNew(),
      '#maxlength' => EntityTypeInterface::BUNDLE_MAX_LENGTH,
      '#machine_name' => [
        'exists' => [$this, 'exists'],
        'source' => ['label', 'widget', 0, 'value'],
      ],
      '#description' => $this->t('A unique machine-readable name for this site settings. It must only contain lowercase letters, numbers, and underscores.'),
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state): int {
    $result = parent::save($form, $form_state);

    $message_args = ['%label' => $this->entity->label()];
    $logger_args = [
      '%label' => $this->entity->label(),
    ];

    switch ($result) {
      case SAVED_NEW:
        $this->messenger()->addStatus($this->t('New site settings %label has been created.', $message_args));
        $this->logger('site_settings')->notice('New site settings %label has been created.', $logger_args);
        break;

      case SAVED_UPDATED:
        $this->messenger()->addStatus($this->t('The site settings %label has been updated.', $message_args));
        $this->logger('site_settings')->notice('The site settings %label has been updated.', $logger_args);
        break;

      default:
        throw new \LogicException('Could not save the entity.');
    }

    $form_state->setRedirectUrl($this->entity->toUrl('collection'));

    return $result;
  }

  /**
   * Determines if the site setting already exists.
   *
   * @param string $id
   *   The site setting ID.
   *
   * @return bool
   *   TRUE if the setting exists, FALSE otherwise.
   */
  public function exists($id) {
    $settings = $this->entityTypeManager->getStorage('site_settings')->loadByProperties(['machine_name' => $id]);
    return !empty($settings);
  }

}
