<?php

namespace Drupal\site_settings\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBundleBase;
use Drupal\Core\Entity\Attribute\ConfigEntityType;
use Drupal\Core\Entity\EntityDeleteForm;
use Drupal\Core\Entity\Routing\AdminHtmlRouteProvider;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\site_settings\Form\SiteSettingsTypeForm;
use Drupal\site_settings\SiteSettingsTypeListBuilder;

/**
 * Defines the Site settings type configuration entity.
 */
#[ConfigEntityType(
  id: 'site_settings_type',
  label: new TranslatableMarkup('Site settings type'),
  handlers: [
    'form' => [
      'add' => SiteSettingsTypeForm::class,
      'edit' => SiteSettingsTypeForm::class,
      'delete' => EntityDeleteForm::class,
    ],
    'list_builder' => SiteSettingsTypeListBuilder::class,
    'route_provider' => [
      'html' => AdminHtmlRouteProvider::class,
    ],
  ],
    admin_permission: 'administer site_settings',
    bundle_of: 'site_settings',
    config_prefix: 'site_settings_type',
    entity_keys: [
      'id' => 'id',
      'label' => 'label',
      'uuid' => 'uuid',
      'conditions' => 'conditions',
    ],
    links: [
      'add-form' => '/admin/structure/site-settings-type/add',
      'edit-form' => '/admin/structure/site-settings-type/manage/{site_settings_type}',
      'delete-form' => '/admin/structure/site-settings-type/manage/{site_settings_type}/delete',
      'collection' => '/admin/structure/site-settings-type',
    ],
    config_export: [
      'id',
      'label',
      'uuid',
      'conditions' => 'conditions',
    ]
  )]
class SiteSettingsType extends ConfigEntityBundleBase {

  /**
   * The machine name of this site settings type.
   *
   * @var string
   */
  protected $id;

  /**
   * The human-readable name of the site settings type.
   *
   * @var string
   */
  protected $label;

  /**
   * The condition plugins enabled for this site settings type.
   *
   * @var array
   */
  protected $conditions;

}
