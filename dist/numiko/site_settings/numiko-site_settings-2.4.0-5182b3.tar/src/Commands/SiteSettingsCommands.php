<?php

namespace Drupal\site_settings\Commands;

use Drush\Commands\DrushCommands;
use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Defines Drush commands for the module.
 */
class SiteSettingsCommands extends DrushCommands {

  /**
   * The site settings storage.
   *
   * @var Drupal\site_settings\SiteSettingsStorageInterface
   */
  private $siteSettingsStorage;

  /**
   * SiteSettingsCommands object constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   */
  public function __construct(
    EntityTypeManagerInterface $entityTypeManager
  ) {
    $this->siteSettingsStorage = $entityTypeManager->getStorage('site_settings');
  }

  /**
   * Create a site settings object.
   *
   * @command site-settings:generate
   *
   * @param string $bundle
   *   The site setting type bundle.
   * @param string $machineName
   *   The setting machine name.
   * @param string $label
   *   The setting label.
   *
   * @throws \Exception
   *
   * @usage drush site-settings:generate footer footer "Footer"
   *   Generate a site settings object of bundle footer, with machine name footer
   *   labelled "Footer".
   */
  public function generateSiteSettings(string $bundle, string $machineName, ?string $label = NULL) {
    if (!$label) {
      return;
    }
    $siteSettings = $this->siteSettingsStorage->create([
      'bundle' => $bundle,
      'machine_name' => $machineName,
      'label' => $label,
    ]);
    $siteSettings->save();
  }

}
