<?php

namespace Drupal\site_settings\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBundleBase;

/**
 * Defines the Site settings type configuration entity.
 *
 * @ConfigEntityType(
 *   id = "site_settings_type",
 *   label = @Translation("Site settings type"),
 *   handlers = {
 *     "form" = {
 *       "add" = "Drupal\site_settings\Form\SiteSettingsTypeForm",
 *       "edit" = "Drupal\site_settings\Form\SiteSettingsTypeForm",
 *       "delete" = "Drupal\Core\Entity\EntityDeleteForm",
 *     },
 *     "list_builder" = "Drupal\site_settings\SiteSettingsTypeListBuilder",
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     }
 *   },
 *   admin_permission = "administer site_settings",
 *   bundle_of = "site_settings",
 *   config_prefix = "site_settings_type",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *     "conditions" = "conditions"
 *   },
 *   links = {
 *     "add-form" = "/admin/structure/site-settings-type/add",
 *     "edit-form" = "/admin/structure/site-settings-type/manage/{site_settings_type}",
 *     "delete-form" = "/admin/structure/site-settings-type/manage/{site_settings_type}/delete",
 *     "collection" = "/admin/structure/site-settings-type"
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "uuid",
 *     "conditions" = "conditions"
 *   }
 * )
 */
class SiteSettingsType extends ConfigEntityBundleBase {

  /**
   * The machine name of this site settings type.
   *
   * @var string
   */
  protected $id;

  /**
   * The human-readable name of the site settings type.
   *
   * @var string
   */
  protected $label;

  /**
   * The condition plugins enabled for this site settings type.
   *
   * @var array
   */
  protected $conditions;

}
