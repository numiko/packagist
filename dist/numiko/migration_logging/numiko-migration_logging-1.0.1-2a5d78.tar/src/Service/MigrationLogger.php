<?php

namespace Drupal\migration_logging\Service;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\migrate\Plugin\MigrateIdMapInterface;
use Drupal\migrate\Plugin\MigrationPluginManagerInterface;

/**
 * Service for logging migration operations.
 */
class MigrationLogger {

  /**
   * Status constant for deleted items.
   */
  const STATUS_DELETED = 'deleted';

  /**
   * Tracks migration progress by status.
   *
   * @var array
   */
  protected array $progressStatus = [];

  /**
   * Whether the destination item exists before saving.
   *
   * @var bool
   */
  protected bool $preExistingItem = FALSE;

  /**
   * Cache of migration destination entity types.
   *
   * @var array
   */
  protected array $migrationEntityTypes = [];

  /**
   * Constructs a MigrationLogger service.
   *
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Component\Datetime\TimeInterface $time
   *   The time service.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The config factory.
   * @param \Drupal\migrate\Plugin\MigrationPluginManagerInterface $migrationPluginManager
   *   The migration plugin manager.
   */
  public function __construct(
    protected Connection $database,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected TimeInterface $time,
    protected ConfigFactoryInterface $configFactory,
    protected MigrationPluginManagerInterface $migrationPluginManager
  ) {}

  /**
   * Check if a migration should be tracked.
   *
   * @param string $migrationId
   *   The migration ID.
   *
   * @return bool
   *   TRUE if the migration should be logged.
   */
  public function shouldTrackMigration(string $migrationId): bool {
    $config = $this->configFactory->get('migration_logging.settings');
    $tracked_migrations = $config->get('tracked_migrations') ?: [];
    return in_array($migrationId, $tracked_migrations);
  }

  /**
   * Get the destination entity type for a migration.
   *
   * @param string $migrationId
   *   The migration ID.
   *
   * @return string
   *   The entity type, or empty string if not determinable.
   */
  public function getMigrationEntityType(string $migrationId): string {
    if (isset($this->migrationEntityTypes[$migrationId])) {
      return $this->migrationEntityTypes[$migrationId];
    }

    try {
      $migration = $this->migrationPluginManager->createInstance($migrationId);
      $destination = $migration->getDestinationPlugin();
      
      // Extract entity type from destination plugin ID.
      $plugin_id = $destination->getPluginId();
      if (strpos($plugin_id, 'entity:') === 0) {
        $entity_type = substr($plugin_id, 7); // Remove 'entity:' prefix.
        $this->migrationEntityTypes[$migrationId] = $entity_type;
        return $entity_type;
      }
    } catch (\Exception $e) {
      // Log the error but don't fail the migration.
      \Drupal::logger('migration_logging')->warning('Could not determine entity type for migration @migration: @message', [
        '@migration' => $migrationId,
        '@message' => $e->getMessage(),
      ]);
    }

    $this->migrationEntityTypes[$migrationId] = '';
    return '';
  }

  /**
   * Initialize progress tracking for a migration.
   *
   * @param string $migrationId
   *   The migration ID.
   */
  public function initializeProgress(string $migrationId): void {
    $this->progressStatus[$migrationId] = [
      MigrateIdMapInterface::STATUS_IMPORTED => [],
      MigrateIdMapInterface::STATUS_NEEDS_UPDATE => [],
      MigrateIdMapInterface::STATUS_FAILED => [],
      self::STATUS_DELETED => [],
    ];
  }

  /**
   * Set pre-existing item status.
   *
   * @param bool $exists
   *   Whether the item exists.
   */
  public function setPreExistingItem(bool $exists): void {
    $this->preExistingItem = $exists;
  }

  /**
   * Track a migration map save event.
   *
   * @param string $migrationId
   *   The migration ID.
   * @param array $fields
   *   The map fields.
   * @param string $entityType
   *   The destination entity type.
   */
  public function trackMapSave(string $migrationId, array $fields, string $entityType = ''): void {
    if (!isset($this->progressStatus[$migrationId])) {
      $this->initializeProgress($migrationId);
    }

    $sourceStatus = $fields['source_row_status'] ?? MigrateIdMapInterface::STATUS_IMPORTED;
    $destId = $fields['destid1'] ?? NULL;
    $sourceId = $fields['sourceid1'] ?? NULL;

    if ($sourceStatus == MigrateIdMapInterface::STATUS_IMPORTED && $this->preExistingItem && $destId) {
      $entityKey = $entityType ? "{$entityType}:{$destId}" : $destId;
      $this->progressStatus[$migrationId][MigrateIdMapInterface::STATUS_NEEDS_UPDATE][$entityKey] = $destId;
      return;
    }

    if ($sourceStatus == MigrateIdMapInterface::STATUS_IMPORTED && $destId) {
      $entityKey = $entityType ? "{$entityType}:{$destId}" : $destId;
      $this->progressStatus[$migrationId][MigrateIdMapInterface::STATUS_IMPORTED][$entityKey] = $destId;
      return;
    }

    if ($sourceId) {
      $this->progressStatus[$migrationId][$sourceStatus][$sourceId] = $sourceId;
    }
  }

  /**
   * Track a deleted item.
   *
   * @param string $migrationId
   *   The migration ID.
   * @param mixed $entityId
   *   The entity ID.
   * @param string $entityType
   *   The entity type.
   */
  public function trackDeleted(string $migrationId, $entityId, string $entityType = ''): void {
    if (!isset($this->progressStatus[$migrationId])) {
      $this->initializeProgress($migrationId);
    }
    $entityKey = $entityType ? "{$entityType}:{$entityId}" : $entityId;
    $this->progressStatus[$migrationId][self::STATUS_DELETED][$entityKey] = $entityId;
  }

  /**
   * Write migration log to database.
   *
   * @param string $migrationId
   *   The migration ID.
   */
  public function writeLog(string $migrationId): void {
    if (!isset($this->progressStatus[$migrationId])) {
      return;
    }

    $progress = $this->progressStatus[$migrationId];
    $created = $progress[MigrateIdMapInterface::STATUS_IMPORTED] ?? [];
    $updated = $progress[MigrateIdMapInterface::STATUS_NEEDS_UPDATE] ?? [];
    $failed = $progress[MigrateIdMapInterface::STATUS_FAILED] ?? [];
    $deleted = $progress[self::STATUS_DELETED] ?? [];

    // Ensure updated doesn't contain any values from created.
    if (!empty($updated) && !empty($created)) {
      $updated = array_diff($updated, $created);
    }

    $data = [
      'migration_id' => $migrationId,
      'created' => count($created),
      'updated' => count($updated),
      'deleted' => count($deleted),
      'failed' => count($failed),
      'data' => serialize([
        'created' => $created,
        'updated' => $updated,
        'deleted' => $deleted,
        'failed' => $failed,
      ]),
      'timestamp' => $this->time->getCurrentTime(),
    ];

    $this->database->insert('migration_logs')
      ->fields($data)
      ->execute();

    // Clear progress for this migration.
    unset($this->progressStatus[$migrationId]);
  }

  /**
   * Get migration logs.
   *
   * @param int $limit
   *   Number of logs to fetch.
   * @param int $offset
   *   Offset for pagination.
   *
   * @return array
   *   Array of log entries.
   */
  public function getLogs(int $limit = 50, int $offset = 0): array {
    $query = $this->database->select('migration_logs', 'ml')
      ->fields('ml')
      ->orderBy('timestamp', 'DESC')
      ->orderBy('id', 'DESC')
      ->range($offset, $limit);

    return $query->execute()->fetchAll();
  }

  /**
   * Get a specific migration log.
   *
   * @param int $logId
   *   The log ID.
   *
   * @return object|false
   *   The log object or FALSE if not found.
   */
  public function getLog(int $logId): object|false {
    return $this->database->select('migration_logs', 'ml')
      ->fields('ml')
      ->condition('id', $logId)
      ->execute()
      ->fetch();
  }

  /**
   * Prune old migration logs based on configuration.
   *
   * @return int
   *   Number of logs deleted.
   */
  public function pruneLogs(): int {
    $config = $this->configFactory->get('migration_logging.settings');
    
    if (!$config->get('auto_prune')) {
      return 0;
    }

    $deleted = 0;
    $prune_age_days = $config->get('prune_age_days') ?: 90;
    $max_logs_per_migration = $config->get('max_logs_per_migration') ?: 50;
    
    // Delete logs older than specified days.
    if ($prune_age_days > 0) {
      $cutoff_time = $this->time->getCurrentTime() - ($prune_age_days * 86400);
      $deleted += $this->database->delete('migration_logs')
        ->condition('timestamp', $cutoff_time, '<')
        ->execute();
    }
    
    // Limit number of logs per migration.
    if ($max_logs_per_migration > 0) {
      $migrations = $this->database->select('migration_logs', 'ml')
        ->fields('ml', ['migration_id'])
        ->distinct()
        ->execute()
        ->fetchCol();
        
      foreach ($migrations as $migration_id) {
        $excess_logs = $this->database->select('migration_logs', 'ml')
          ->fields('ml', ['id'])
          ->condition('migration_id', $migration_id)
          ->orderBy('timestamp', 'DESC')
          ->orderBy('id', 'DESC')
          ->range($max_logs_per_migration, 9999)
          ->execute()
          ->fetchCol();
          
        if (!empty($excess_logs)) {
          $deleted += $this->database->delete('migration_logs')
            ->condition('id', $excess_logs, 'IN')
            ->execute();
        }
      }
    }
    
    return $deleted;
  }

  /**
   * Clear all logs or logs for a specific migration.
   *
   * @param string|null $migration_id
   *   The migration ID, or NULL to clear all logs.
   *
   * @return int
   *   Number of logs deleted.
   */
  public function clearLogs(?string $migration_id = NULL): int {
    $query = $this->database->delete('migration_logs');
    
    if ($migration_id !== NULL) {
      $query->condition('migration_id', $migration_id);
    }
    
    return $query->execute();
  }

}