<?php

namespace Drupal\migration_logging\Commands;

use Drupal\migration_logging\Service\MigrationLogger;
use Drush\Attributes as CLI;
use Drush\Commands\DrushCommands;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Drush commands for migration logging management.
 */
class MigrationLoggingCommands extends DrushCommands {

  /**
   * Constructs a MigrationLoggingCommands object.
   *
   * @param \Drupal\migration_logging\Service\MigrationLogger $migrationLogger
   *   The migration logger service.
   */
  public function __construct(protected MigrationLogger $migrationLogger) {
    parent::__construct();
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('migration_logging.logger')
    );
  }

  /**
   * Clear migration logs.
   *
   * @param array $options
   *   Command options.
   *
   * @return void
   *   No return value.
   *
   * @command migration-logging:clear
   * @aliases ml:clear
   * @option migration Clear logs for specific migration ID only.
   * @option all Clear all migration logs.
   * @usage migration-logging:clear --all
   *   Clear all migration logs.
   * @usage migration-logging:clear --migration=event_import
   *   Clear logs for specific migration.
   */
  #[CLI\Command(name: 'migration-logging:clear', aliases: ['ml:clear'])]
  #[CLI\Option(name: 'migration', description: 'Clear logs for specific migration ID only')]
  #[CLI\Option(name: 'all', description: 'Clear all migration logs')]
  public function clearLogs(array $options = ['migration' => NULL, 'all' => FALSE]): void {
    $migration_id = $options['migration'];
    $clear_all = $options['all'];

    if (!$migration_id && !$clear_all) {
      $this->output()->writeln('<error>You must specify either --migration=MIGRATION_ID or --all</error>');
      return;
    }

    if ($migration_id && $clear_all) {
      $this->output()->writeln('<error>Cannot use both --migration and --all options together</error>');
      return;
    }

    // Confirmation prompt.
    if ($clear_all) {
      $message = 'Are you sure you want to delete ALL migration logs? This cannot be undone.';
    } else {
      $message = "Are you sure you want to delete all logs for migration '{$migration_id}'? This cannot be undone.";
    }

    if (!$this->io()->confirm($message)) {
      $this->output()->writeln('<comment>Operation cancelled.</comment>');
      return;
    }

    $deleted = $this->migrationLogger->clearLogs($clear_all ? NULL : $migration_id);

    if ($deleted > 0) {
      if ($clear_all) {
        $this->output()->writeln("<info>Successfully deleted {$deleted} migration log entries.</info>");
        $this->logger()->info('All migration logs cleared via drush command. Deleted @count entries.', ['@count' => $deleted]);
      } else {
        $this->output()->writeln("<info>Successfully deleted {$deleted} log entries for migration '{$migration_id}'.</info>");
        $this->logger()->info('Migration logs cleared for @migration via drush command. Deleted @count entries.', [
          '@migration' => $migration_id,
          '@count' => $deleted,
        ]);
      }
    } else {
      $this->output()->writeln('<comment>No logs found to delete.</comment>');
    }
  }

  /**
   * Prune old migration logs based on configuration.
   *
   * @return void
   *   No return value.
   *
   * @command migration-logging:prune
   * @aliases ml:prune
   * @usage migration-logging:prune
   *   Prune old logs according to configuration settings.
   */
  #[CLI\Command(name: 'migration-logging:prune', aliases: ['ml:prune'])]
  public function pruneLogs(): void {
    $this->output()->writeln('Pruning old migration logs...');
    
    $deleted = $this->migrationLogger->pruneLogs();
    
    if ($deleted > 0) {
      $this->output()->writeln("<info>Successfully pruned {$deleted} old migration log entries.</info>");
      $this->logger()->info('Migration logs pruned via drush command. Deleted @count entries.', ['@count' => $deleted]);
    } else {
      $this->output()->writeln('<comment>No logs needed pruning or auto-pruning is disabled.</comment>');
    }
  }

  /**
   * Show migration logging statistics.
   *
   * @return void
   *   No return value.
   *
   * @command migration-logging:status
   * @aliases ml:status
   * @usage migration-logging:status
   *   Display migration logging statistics.
   */
  #[CLI\Command(name: 'migration-logging:status', aliases: ['ml:status'])]
  public function showStatus(): void {
    $config = \Drupal::config('migration_logging.settings');
    
    $this->output()->writeln('<info>Migration Logging Status:</info>');
    
    $tracked = $config->get('tracked_migrations') ?: [];
    $this->output()->writeln("  Tracked migrations: " . count($tracked));
    if (!empty($tracked)) {
      foreach ($tracked as $migration) {
        $this->output()->writeln("    - {$migration}");
      }
    }
    
    $this->output()->writeln("  Auto-pruning: " . ($config->get('auto_prune') ? '<info>Enabled</info>' : '<comment>Disabled</comment>'));
    
    if ($config->get('auto_prune')) {
      $this->output()->writeln("  Prune age: " . $config->get('prune_age_days') . " days");
      $this->output()->writeln("  Max logs per migration: " . $config->get('max_logs_per_migration'));
    }
    
    // Get total log count.
    $total_logs = \Drupal::database()->select('migration_logs', 'ml')
      ->countQuery()
      ->execute()
      ->fetchField();
    
    $this->output()->writeln("  Total stored logs: {$total_logs}");
    
    // Get logs by migration.
    $logs_by_migration = \Drupal::database()->select('migration_logs', 'ml')
      ->fields('ml', ['migration_id'])
      ->groupBy('migration_id')
      ->execute()
      ->fetchCol();
    
    if (!empty($logs_by_migration)) {
      $this->output()->writeln("  Logs by migration:");
      foreach ($logs_by_migration as $migration_id) {
        $count = \Drupal::database()->select('migration_logs', 'ml')
          ->condition('migration_id', $migration_id)
          ->countQuery()
          ->execute()
          ->fetchField();
        $this->output()->writeln("    - {$migration_id}: {$count} logs");
      }
    }
  }

}