<?php

namespace Drupal\migration_logging\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Connection;
use Drupal\Core\Datetime\DateFormatterInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Drupal\migration_logging\Service\MigrationLogger;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Controller for migration log pages.
 */
class MigrationLogController extends ControllerBase {

  /**
   * Constructs a MigrationLogController.
   *
   * @param \Drupal\migration_logging\Service\MigrationLogger $logger
   *   The migration logger service.
   * @param \Drupal\Core\Datetime\DateFormatterInterface $dateFormatter
   *   The date formatter service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Database\Connection $database
   *   The database connection.
   */
  public function __construct(
    protected MigrationLogger $logger,
    protected DateFormatterInterface $dateFormatter,
    EntityTypeManagerInterface $entityTypeManager,
    protected Connection $database
  ) {
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('migration_logging.logger'),
      $container->get('date.formatter'),
      $container->get('entity_type.manager'),
      $container->get('database')
    );
  }

  /**
   * Display list of migration logs.
   *
   * @return array
   *   A render array for the logs table.
   */
  public function list(): array {
    $logs = $this->logger->getLogs(50);

    $rows = [];
    foreach ($logs as $log) {
      $rows[] = [
        'date' => [
          'data' => [
            '#markup' => $this->dateFormatter->format($log->timestamp, 'short') . '<br><small>' . $this->dateFormatter->format($log->timestamp, 'custom', 'H:i:s') . '</small>',
          ],
        ],
        'migration' => $log->migration_id,
        'created' => $log->created,
        'updated' => $log->updated,
        'deleted' => $log->deleted,
        'failed' => $log->failed,
        'operations' => Link::createFromRoute(
          $this->t('View details'),
          'migration_logging.log_detail',
          [
            'migration' => $log->migration_id,
            'id' => $log->id,
          ]
        )->toString(),
      ];
    }

    // Add action buttons if user has permission.
    if ($this->currentUser()->hasPermission('administer migration logging')) {
      $build['actions'] = [
        '#type' => 'container',
        '#attributes' => ['class' => ['clearfix']],
        'clear_all' => [
          '#type' => 'link',
          '#title' => $this->t('Clear all logs'),
          '#url' => Url::fromRoute('migration_logging.clear_all_logs_confirm'),
          '#attributes' => [
            'class' => ['button', 'button--small', 'button--danger'],
          ],
        ],
      ];
    }

    $build['logs'] = [
      '#type' => 'table',
      '#header' => [
        $this->t('Date'),
        $this->t('Migration'),
        $this->t('Created'),
        $this->t('Updated'),
        $this->t('Deleted'),
        $this->t('Failed'),
        $this->t('Operations'),
      ],
      '#rows' => $rows,
      '#empty' => $this->t('No migration logs found.'),
    ];

    return $build;
  }

  /**
   * Display detailed view of a specific migration log.
   *
   * @param string $migration
   *   The migration ID.
   * @param int $id
   *   The log ID.
   *
   * @return array
   *   A render array for the log details.
   */
  public function view(string $migration, int $id): array {
    $log = $this->logger->getLog($id);

    if (!$log || $log->migration_id !== $migration) {
      throw new NotFoundHttpException();
    }

    $build = [];

    // Add action buttons if user has permission.
    if ($this->currentUser()->hasPermission('administer migration logging')) {
      $build['actions'] = [
        '#type' => 'container',
        '#attributes' => ['class' => ['clearfix']],
        '#weight' => -100,
        'clear_migration' => [
          '#type' => 'link',
          '#title' => $this->t('Delete this log entry'),
          '#url' => Url::fromRoute('migration_logging.clear_single_log_confirm', [
            'migration' => $log->migration_id,
            'id' => $log->id,
          ]),
          '#attributes' => [
            'class' => ['button', 'button--small', 'button--danger'],
          ],
        ],
      ];
    }

    $build['info'] = [
      '#type' => 'item',
      '#title' => $this->t('Migration Log: @migration', [
        '@migration' => $log->migration_id,
      ]),
      '#markup' => $this->t('<strong>Run date:</strong> @date at @time', [
        '@date' => $this->dateFormatter->format($log->timestamp, 'long'),
        '@time' => $this->dateFormatter->format($log->timestamp, 'custom', 'H:i:s'),
      ]),
    ];

    $build['summary'] = [
      '#type' => 'table',
      '#header' => [
        $this->t('Action'),
        $this->t('Count'),
      ],
      '#rows' => [
        [$this->t('Created'), $log->created],
        [$this->t('Updated'), $log->updated],
        [$this->t('Deleted'), $log->deleted],
        [$this->t('Failed'), $log->failed],
      ],
    ];

    if (!empty($log->data)) {
      $data = unserialize($log->data);
      if (is_array($data)) {
        foreach (['created', 'updated', 'deleted', 'failed'] as $type) {
          if (!empty($data[$type])) {
            $rows = $this->buildEntityTableRows($data[$type]);
            $build[$type] = [
              '#type' => 'details',
              '#title' => $this->t('@type entities (@count)', [
                '@type' => ucfirst($type),
                '@count' => count($data[$type]),
              ]),
              'table' => [
                '#type' => 'table',
                '#header' => [
                  $this->t('Entity Type'),
                  $this->t('ID'),
                  $this->t('Title'),
                ],
                '#rows' => $rows,
                '#empty' => $this->t('No @type entities.', ['@type' => $type]),
              ],
            ];
          }
        }
      }
    }

    return $build;
  }

  /**
   * Build table rows for entity data.
   *
   * @param array $entityData
   *   The entity data from the log.
   *
   * @return array
   *   Array of table rows.
   */
  protected function buildEntityTableRows(array $entityData): array {
    $rows = [];
    
    foreach ($entityData as $entityKey => $entityId) {
      // Check if the key contains entity type (format: "entity_type:id").
      if (str_contains($entityKey, ':')) {
        [$entityType, $id] = explode(':', $entityKey, 2);

        try {
          $entity = $this->entityTypeManager->getStorage($entityType)->load($id);
          if ($entity) {
            $title = $entity->label() ?: $this->t('(No title)');
            if ($entity->hasLinkTemplate('canonical')) {
              $title = $entity->toLink($title)->toString();
            }
            
            $rows[] = [
              'entity_type' => ucfirst($entityType),
              'id' => $id,
              'title' => $title,
            ];
          } else {
            $rows[] = [
              'entity_type' => ucfirst($entityType),
              'id' => $id,
              'title' => $this->t('(Entity deleted)'),
            ];
          }
        } catch (\Exception $e) {
          $rows[] = [
            'entity_type' => ucfirst($entityType),
            'id' => $id,
            'title' => $this->t('(Could not load)'),
          ];
        }
      } else {
        // Fallback for old logs without entity type.
        $rows[] = [
          'entity_type' => $this->t('Unknown'),
          'id' => $entityKey,
          'title' => $this->t('(Legacy log entry)'),
        ];
      }
    }
    
    return $rows;
  }

  /**
   * Confirmation page for clearing all logs.
   *
   * @return array
   *   A render array for the confirmation form.
   */
  public function clearAllLogsConfirm(): array {
    return $this->getConfirmForm(
      $this->t('Are you sure you want to clear ALL migration logs?'),
      $this->t('This action cannot be undone. All migration log data will be permanently deleted.'),
      'migration_logging.clear_all_logs_execute'
    );
  }

  /**
   * Confirmation page for clearing logs for a specific migration.
   *
   * @param string $migration
   *   The migration ID.
   *
   * @return array
   *   A render array for the confirmation form.
   */
  public function clearMigrationLogsConfirm(string $migration): array {
    return $this->getConfirmForm(
      $this->t('Are you sure you want to clear all logs for migration %migration?', ['%migration' => $migration]),
      $this->t('This action cannot be undone. All log data for this migration will be permanently deleted.'),
      'migration_logging.clear_migration_logs_execute',
      ['migration' => $migration]
    );
  }

  /**
   * Confirmation page for deleting a single log entry.
   *
   * @param string $migration
   *   The migration ID.
   * @param int $id
   *   The log ID.
   *
   * @return array
   *   A render array for the confirmation form.
   */
  public function clearSingleLogConfirm(string $migration, int $id): array {
    $log = $this->logger->getLog($id);
    if (!$log || $log->migration_id !== $migration) {
      throw new NotFoundHttpException();
    }
    
    return $this->getConfirmForm(
      $this->t('Are you sure you want to delete this log entry?'),
      $this->t('This action cannot be undone. This log entry for migration %migration (run on @date at @time) will be permanently deleted.', [
        '%migration' => $log->migration_id,
        '@date' => $this->dateFormatter->format($log->timestamp, 'short'),
        '@time' => $this->dateFormatter->format($log->timestamp, 'custom', 'H:i:s'),
      ]),
      'migration_logging.clear_single_log_execute',
      ['migration' => $migration, 'id' => $id]
    );
  }

  /**
   * Execute clearing all logs.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   *   A redirect response.
   */
  public function clearAllLogsExecute(): RedirectResponse {
    $deleted = $this->logger->clearLogs();
    
    if ($deleted > 0) {
      $this->messenger()->addStatus($this->t('Cleared @count migration log entries.', ['@count' => $deleted]));
      \Drupal::logger('migration_logging')->info('All migration logs cleared via admin UI. Deleted @count entries.', ['@count' => $deleted]);
    } else {
      $this->messenger()->addWarning($this->t('No logs found to clear.'));
    }
    
    return new RedirectResponse(Url::fromRoute('migration_logging.logs')->toString());
  }

  /**
   * Execute clearing logs for a specific migration.
   *
   * @param string $migration
   *   The migration ID.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   *   A redirect response.
   */
  public function clearMigrationLogsExecute(string $migration): RedirectResponse {
    $deleted = $this->logger->clearLogs($migration);
    
    if ($deleted > 0) {
      $this->messenger()->addStatus($this->t('Cleared @count log entries for migration %migration.', [
        '@count' => $deleted,
        '%migration' => $migration,
      ]));
      \Drupal::logger('migration_logging')->info('Migration logs cleared for @migration via admin UI. Deleted @count entries.', [
        '@migration' => $migration,
        '@count' => $deleted,
      ]);
    } else {
      $this->messenger()->addWarning($this->t('No logs found to clear for migration %migration.', ['%migration' => $migration]));
    }
    
    return new RedirectResponse(Url::fromRoute('migration_logging.logs')->toString());
  }

  /**
   * Execute deleting a single log entry.
   *
   * @param string $migration
   *   The migration ID.
   * @param int $id
   *   The log ID.
   *
   * @return \Symfony\Component\HttpFoundation\RedirectResponse
   *   A redirect response.
   */
  public function clearSingleLogExecute(string $migration, int $id): RedirectResponse {
    $log = $this->logger->getLog($id);
    if (!$log || $log->migration_id !== $migration) {
      throw new NotFoundHttpException();
    }
    
    $deleted = $this->database->delete('migration_logs')
      ->condition('id', $id)
      ->execute();
    
    if ($deleted > 0) {
      $this->messenger()->addStatus($this->t('Deleted log entry for migration %migration.', [
        '%migration' => $log->migration_id,
      ]));
      \Drupal::logger('migration_logging')->info('Single migration log entry deleted via admin UI. Migration: @migration, ID: @id', [
        '@migration' => $log->migration_id,
        '@id' => $id,
      ]);
    } else {
      $this->messenger()->addWarning($this->t('Log entry could not be deleted.'));
    }
    
    return new RedirectResponse(Url::fromRoute('migration_logging.logs')->toString());
  }

  /**
   * Build a confirmation form.
   *
   * @param string $question
   *   The confirmation question.
   * @param string $description
   *   The description text.
   * @param string $action_route
   *   The route for the action.
   * @param array $route_params
   *   The route parameters.
   *
   * @return array
   *   A render array for the confirmation form.
   */
  protected function getConfirmForm(string $question, string $description, string $action_route, array $route_params = []): array {
    $build = [
      'question' => [
        '#type' => 'item',
        '#markup' => '<h2>' . $question . '</h2>',
      ],
      'description' => [
        '#type' => 'item',
        '#markup' => '<p>' . $description . '</p>',
      ],
      'actions' => [
        '#type' => 'actions',
        'submit' => [
          '#type' => 'link',
          '#title' => $this->t('Clear logs'),
          '#url' => Url::fromRoute($action_route, $route_params),
          '#attributes' => [
            'class' => ['button', 'button--primary', 'button--danger'],
          ],
        ],
        'cancel' => [
          '#type' => 'link',
          '#title' => $this->t('Cancel'),
          '#url' => Url::fromRoute('migration_logging.logs'),
          '#attributes' => [
            'class' => ['button'],
          ],
        ],
      ],
    ];

    return $build;
  }

}