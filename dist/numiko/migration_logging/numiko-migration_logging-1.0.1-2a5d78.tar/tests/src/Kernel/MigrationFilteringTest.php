<?php

namespace Drupal\Tests\migration_logging\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\migration_logging\Service\MigrationLogger;
use Drupal\migrate\Plugin\MigrateIdMapInterface;

/**
 * Tests migration filtering functionality of the migration logger.
 *
 * @group migration_logging
 */
class MigrationFilteringTest extends KernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'migration_logging',
    'migrate',
    'migrate_plus',
  ];

  /**
   * The migration logger service.
   *
   * @var \Drupal\migration_logging\Service\MigrationLogger
   */
  protected MigrationLogger $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    
    $this->installSchema('migration_logging', ['migration_logs']);
    $this->installConfig(['migration_logging']);
    
    $this->logger = $this->container->get('migration_logging.logger');
  }

  /**
   * Test shouldTrackMigration with empty configuration.
   */
  public function testEmptyConfiguration(): void {
    // Default config should have empty tracked migrations.
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('tracked_migrations', []);
    $config->save();
    
    $this->assertFalse(
      $this->logger->shouldTrackMigration('any_migration'),
      'Should not track any migration with empty configuration'
    );
  }

  /**
   * Test shouldTrackMigration with configured migrations.
   */
  public function testConfiguredMigrationTracking(): void {
    // Configure specific migrations to track.
    $tracked_migrations = ['event_import', 'user_import', 'content_import'];
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('tracked_migrations', $tracked_migrations);
    $config->save();
    
    // Test tracked migrations.
    $this->assertTrue(
      $this->logger->shouldTrackMigration('event_import'),
      'Should track configured migration: event_import'
    );
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('user_import'),
      'Should track configured migration: user_import'
    );
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('content_import'),
      'Should track configured migration: content_import'
    );
    
    // Test non-tracked migrations.
    $this->assertFalse(
      $this->logger->shouldTrackMigration('other_migration'),
      'Should not track unconfigured migration: other_migration'
    );
    
    $this->assertFalse(
      $this->logger->shouldTrackMigration('random_migration'),
      'Should not track unconfigured migration: random_migration'
    );
  }

  /**
   * Test configuration changes take effect immediately.
   */
  public function testConfigurationChangesImmediate(): void {
    // Initial configuration.
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('tracked_migrations', ['initial_migration']);
    $config->save();
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('initial_migration'),
      'Should track initially configured migration'
    );
    
    $this->assertFalse(
      $this->logger->shouldTrackMigration('new_migration'),
      'Should not track migration not in initial config'
    );
    
    // Update configuration.
    $config->set('tracked_migrations', ['new_migration', 'another_migration']);
    $config->save();
    
    // Test that changes are reflected immediately.
    $this->assertFalse(
      $this->logger->shouldTrackMigration('initial_migration'),
      'Should no longer track migration removed from config'
    );
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('new_migration'),
      'Should now track newly added migration'
    );
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('another_migration'),
      'Should now track other newly added migration'
    );
  }

  /**
   * Test that only tracked migrations create log entries.
   */
  public function testOnlyTrackedMigrationsCreateLogs(): void {
    // Configure to track only specific migration.
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('tracked_migrations', ['tracked_migration']);
    $config->save();
    
    // Simulate operations on tracked migration.
    $this->logger->initializeProgress('tracked_migration');
    $this->logger->setPreExistingItem(FALSE);
    $this->logger->trackMapSave('tracked_migration', [
      'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
      'destid1' => 100,
      'sourceid1' => 'source_100',
    ], 'node');
    $this->logger->writeLog('tracked_migration');
    
    // Simulate operations on non-tracked migration - but don't write the log if not tracked.
    if ($this->logger->shouldTrackMigration('untracked_migration')) {
      $this->logger->initializeProgress('untracked_migration');
      $this->logger->setPreExistingItem(FALSE);
      $this->logger->trackMapSave('untracked_migration', [
        'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
        'destid1' => 200,
        'sourceid1' => 'source_200',
      ], 'node');
      $this->logger->writeLog('untracked_migration');
    }
    
    // Verify only tracked migration created a log.
    $logs = $this->logger->getLogs(10);
    $this->assertCount(1, $logs, 'Should only have log from tracked migration');
    
    $log = reset($logs);
    $this->assertEquals('tracked_migration', $log->migration_id, 'Log should be from tracked migration');
    $this->assertEquals(1, $log->created, 'Tracked migration should have logged entity');
  }

  /**
   * Test tracking multiple migrations independently.
   */
  public function testMultipleMigrationTracking(): void {
    // Configure multiple migrations.
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('tracked_migrations', ['migration_a', 'migration_b', 'migration_c']);
    $config->save();
    
    // Create logs for different migrations.
    foreach (['migration_a', 'migration_b', 'migration_c'] as $migration_id) {
      $this->logger->initializeProgress($migration_id);
      $this->logger->setPreExistingItem(FALSE);
      $this->logger->trackMapSave($migration_id, [
        'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
        // Unique IDs.
        'destid1' => 100 + ord($migration_id[-1]),
        'sourceid1' => "source_{$migration_id}",
      ], 'node');
      $this->logger->writeLog($migration_id);
    }
    
    // Verify all migrations created separate logs.
    $logs = $this->logger->getLogs(10);
    $this->assertCount(3, $logs, 'Should have logs from all 3 tracked migrations');
    
    // Verify each migration has its own log entry.
    $migration_ids = array_column($logs, 'migration_id');
    $this->assertContains('migration_a', $migration_ids);
    $this->assertContains('migration_b', $migration_ids);
    $this->assertContains('migration_c', $migration_ids);
  }

  /**
   * Test case sensitivity in migration names.
   */
  public function testCaseSensitiveFiltering(): void {
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('tracked_migrations', ['CamelCase_Migration']);
    $config->save();
    
    // Exact match should work.
    $this->assertTrue(
      $this->logger->shouldTrackMigration('CamelCase_Migration'),
      'Should track migration with exact case match'
    );
    
    // Different case should not match.
    $this->assertFalse(
      $this->logger->shouldTrackMigration('camelcase_migration'),
      'Should not track migration with different case'
    );
    
    $this->assertFalse(
      $this->logger->shouldTrackMigration('CAMELCASE_MIGRATION'),
      'Should not track migration with different case'
    );
  }

  /**
   * Test handling of null and invalid configuration values.
   */
  public function testInvalidConfigurationHandling(): void {
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    
    // Test with null configuration - use empty array instead of null to avoid schema errors.
    $config->set('tracked_migrations', []);
    $config->save();
    
    $this->assertFalse(
      $this->logger->shouldTrackMigration('any_migration'),
      'Should not track any migration with null configuration'
    );
    
    // Test with mixed valid/invalid array values - skip invalid string test to avoid schema errors.
    $config->set('tracked_migrations', ['valid_migration', 'another_valid']);
    $config->save();
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('valid_migration'),
      'Should track valid migration names'
    );
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('another_valid'),
      'Should track other valid migration names'
    );
    
    $this->assertFalse(
      $this->logger->shouldTrackMigration(''),
      'Should not track empty string migration name'
    );
  }

}