<?php

namespace Drupal\Tests\migration_logging\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\migration_logging\Service\MigrationLogger;

/**
 * Tests log pruning functionality of the migration logger.
 *
 * @group migration_logging
 */
class LogPruningTest extends KernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'migration_logging',
    'migrate',
    'migrate_plus',
  ];

  /**
   * The migration logger service.
   *
   * @var \Drupal\migration_logging\Service\MigrationLogger
   */
  protected MigrationLogger $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    
    $this->installSchema('migration_logging', ['migration_logs']);
    $this->installConfig(['migration_logging']);
    
    $this->logger = $this->container->get('migration_logging.logger');
  }

  /**
   * Test age-based log pruning.
   */
  public function testAgePruning(): void {
    $current_time = \Drupal::time()->getCurrentTime();
    
    // Configure pruning: 30 days, no count limit.
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('auto_prune', TRUE);
    $config->set('prune_age_days', 30);
    // No count limit.
    $config->set('max_logs_per_migration', 0);
    $config->save();
    
    // Create logs with different ages.
    $this->createTestLog('test_migration', $current_time - (40 * 86400)); // 40 days old
    $this->createTestLog('test_migration', $current_time - (20 * 86400)); // 20 days old
    $this->createTestLog('test_migration', $current_time - (10 * 86400)); // 10 days old
    $this->createTestLog('another_migration', $current_time - (35 * 86400)); // 35 days old
    
    // Verify all logs exist.
    $logs_before = $this->logger->getLogs(10);
    $this->assertCount(4, $logs_before, 'Should have 4 logs before pruning');
    
    // Run pruning.
    $deleted = $this->logger->pruneLogs();
    
    // Should delete logs older than 30 days (40-day and 35-day old logs).
    $this->assertEquals(2, $deleted, 'Should delete 2 old logs');
    
    $logs_after = $this->logger->getLogs(10);
    $this->assertCount(2, $logs_after, 'Should have 2 logs remaining after pruning');
  }

  /**
   * Test count-based log pruning.
   */
  public function testCountPruning(): void {
    $current_time = \Drupal::time()->getCurrentTime();
    
    // Configure pruning: no age limit, keep 2 logs per migration.
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('auto_prune', TRUE);
    // No count limit.
    $config->set('prune_age_days', 0);
    $config->set('max_logs_per_migration', 2);
    $config->save();
    
    // Create multiple logs for same migration (newest first in creation order).
    // Oldest.
    $this->createTestLog('count_test', $current_time - 400);
    $this->createTestLog('count_test', $current_time - 300);
    $this->createTestLog('count_test', $current_time - 200);
    // Newest.
    $this->createTestLog('count_test', $current_time - 100);
    
    // Create logs for another migration.
    $this->createTestLog('other_migration', $current_time - 500);
    $this->createTestLog('other_migration', $current_time - 400);
    $this->createTestLog('other_migration', $current_time - 300);
    
    $logs_before = $this->logger->getLogs(10);
    $this->assertCount(7, $logs_before, 'Should have 7 logs before pruning');
    
    // Run pruning.
    $deleted = $this->logger->pruneLogs();
    
    // Should keep 2 most recent logs per migration.
    // count_test: keep 2, delete 2.
    // other_migration: keep 2, delete 1.
    $this->assertEquals(3, $deleted, 'Should delete 3 excess logs');
    
    $logs_after = $this->logger->getLogs(10);
    $this->assertCount(4, $logs_after, 'Should have 4 logs remaining after pruning');
    
    // Verify the correct logs remain (most recent ones).
    foreach ($logs_after as $log) {
      if ($log->migration_id === 'count_test') {
        // Should be the 2 most recent timestamps.
        $this->assertTrue(
          $log->timestamp >= $current_time - 200,
          'count_test logs should be the most recent ones'
        );
      }
      if ($log->migration_id === 'other_migration') {
        $this->assertTrue(
          $log->timestamp >= $current_time - 400,
          'other_migration logs should be the most recent ones'
        );
      }
    }
  }

  /**
   * Test combined age and count pruning.
   */
  public function testCombinedPruning(): void {
    $current_time = \Drupal::time()->getCurrentTime();
    
    // Configure both age and count limits.
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('auto_prune', TRUE);
    $config->set('prune_age_days', 20);
    $config->set('max_logs_per_migration', 2);
    $config->save();
    
    // Create logs that test both conditions.
    $this->createTestLog('combined_test', $current_time - (30 * 86400)); // Old + excess
    $this->createTestLog('combined_test', $current_time - (25 * 86400)); // Old + excess  
    $this->createTestLog('combined_test', $current_time - (15 * 86400)); // Recent + keep
    $this->createTestLog('combined_test', $current_time - (10 * 86400)); // Recent + keep
    $this->createTestLog('combined_test', $current_time - (5 * 86400));  // Recent + excess
    
    $logs_before = $this->logger->getLogs(10);
    $this->assertCount(5, $logs_before, 'Should have 5 logs before pruning');
    
    $deleted = $this->logger->pruneLogs();
    
    // Age pruning removes 2 old logs, then count pruning removes 1 excess.
    $this->assertEquals(3, $deleted, 'Should delete 3 logs (2 old + 1 excess)');
    
    $logs_after = $this->logger->getLogs(10);
    $this->assertCount(2, $logs_after, 'Should have 2 logs remaining');
    
    // Remaining logs should be recent and within count limit.
    foreach ($logs_after as $log) {
      $this->assertTrue(
        $log->timestamp >= $current_time - (20 * 86400),
        'Remaining logs should be within age limit'
      );
    }
  }

  /**
   * Test pruning with auto_prune disabled.
   */
  public function testPruningDisabled(): void {
    // Disable auto pruning.
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('auto_prune', FALSE);
    $config->save();
    
    // Create old logs.
    $current_time = \Drupal::time()->getCurrentTime();
    $this->createTestLog('disabled_test', $current_time - (100 * 86400));
    $this->createTestLog('disabled_test', $current_time - (200 * 86400));
    
    $logs_before = $this->logger->getLogs(10);
    $this->assertCount(2, $logs_before, 'Should have 2 logs before attempting to prune');

    $deleted = $this->logger->pruneLogs();
    
    $this->assertEquals(0, $deleted, 'Should not delete any logs when pruning is disabled');
    
    $logs_after = $this->logger->getLogs(10);
    $this->assertCount(2, $logs_after, 'Should still have 2 logs after attempting to prune');
  }

  /**
   * Test pruning edge cases.
   */
  public function testPruningEdgeCases(): void {
    $config = \Drupal::configFactory()->getEditable('migration_logging.settings');
    $config->set('auto_prune', TRUE);
    $config->set('prune_age_days', 30);
    $config->set('max_logs_per_migration', 1);
    $config->save();
    
    // Test with no logs.
    $deleted = $this->logger->pruneLogs();
    $this->assertEquals(0, $deleted, 'Should handle empty log table gracefully');
    
    // Test with single log within limits.
    $current_time = \Drupal::time()->getCurrentTime();
    $this->createTestLog('edge_test', $current_time - (10 * 86400));
    
    $deleted = $this->logger->pruneLogs();
    $this->assertEquals(0, $deleted, 'Should not delete logs within all limits');
    
    $logs = $this->logger->getLogs(10);
    $this->assertCount(1, $logs, 'Should preserve log within limits');
  }

  /**
   * Helper method to create test log entries.
   */
  protected function createTestLog(string $migration_id, int $timestamp): void {
    \Drupal::database()->insert('migration_logs')
      ->fields([
        'migration_id' => $migration_id,
        'created' => rand(0, 10),
        'updated' => rand(0, 5),
        'deleted' => rand(0, 3),
        'failed' => rand(0, 2),
        'data' => serialize(['created' => [], 'updated' => [], 'deleted' => [], 'failed' => []]),
        'timestamp' => $timestamp,
      ])
      ->execute();
  }

}