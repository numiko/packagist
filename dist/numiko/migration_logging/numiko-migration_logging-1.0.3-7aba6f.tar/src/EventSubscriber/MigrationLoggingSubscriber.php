<?php

namespace Drupal\migration_logging\EventSubscriber;

use Drupal\migration_logging\Service\MigrationLogger;
use Drupal\migrate\Event\MigrateEvents;
use Drupal\migrate\Event\MigrateImportEvent;
use Drupal\migrate\Event\MigrateMapSaveEvent;
use Drupal\migrate\Event\MigratePreRowSaveEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Event subscriber for migration logging.
 */
class MigrationLoggingSubscriber implements EventSubscriberInterface {

  /**
   * Constructs a MigrationLoggingSubscriber.
   *
   * @param \Drupal\migration_logging\Service\MigrationLogger $logger
   *   The migration logger service.
   */
  public function __construct(
    protected MigrationLogger $logger
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return [
      MigrateEvents::PRE_IMPORT => 'onPreImport',
      MigrateEvents::PRE_ROW_SAVE => 'onPreRowSave',
      MigrateEvents::MAP_SAVE => 'onMapSave',
      MigrateEvents::POST_IMPORT => 'onPostImport',
    ];
  }

  /**
   * React to migration pre-import event.
   *
   * @param \Drupal\migrate\Event\MigrateImportEvent $event
   *   The migrate import event.
   */
  public function onPreImport(MigrateImportEvent $event): void {
    $migration = $event->getMigration();
    $migrationId = $migration->id();

    if ($this->logger->shouldTrackMigration($migrationId)) {
      $this->logger->initializeProgress($migrationId);
    }
  }

  /**
   * React to pre-row save event.
   *
   * Sets if the row being imported already exists in the destination.
   *
   * @param \Drupal\migrate\Event\MigratePreRowSaveEvent $event
   *   The pre-save event.
   */
  public function onPreRowSave(MigratePreRowSaveEvent $event): void {
    $migration = $event->getMigration();
    $migrationId = $migration->id();

    if ($this->logger->shouldTrackMigration($migrationId)) {
      $idMap = $event->getRow()->getIdMap();
      $preExistingItem = !empty($idMap['destid1']);
      $this->logger->setPreExistingItem($preExistingItem);
    }
  }

  /**
   * React to migration map save event.
   *
   * Tracks what happened to each item during migration.
   *
   * @param \Drupal\migrate\Event\MigrateMapSaveEvent $event
   *   The map save event.
   */
  public function onMapSave(MigrateMapSaveEvent $event): void {
    $table = explode('.', $event->getMap()->getQualifiedMapTableName());
    $migrationId = str_replace('migrate_map_', '', $table[1]);

    if ($this->logger->shouldTrackMigration($migrationId)) {
      $fields = $event->getFields();
      $entityType = $this->logger->getMigrationEntityType($migrationId);
      $this->logger->trackMapSave($migrationId, $fields, $entityType);
    }
  }

  /**
   * React to migration post-import event.
   *
   * Writes the final log to the database.
   *
   * @param \Drupal\migrate\Event\MigrateImportEvent $event
   *   The migrate import event.
   */
  public function onPostImport(MigrateImportEvent $event): void {
    $migration = $event->getMigration();
    $migrationId = $migration->id();

    if ($this->logger->shouldTrackMigration($migrationId)) {
      $this->logger->writeLog($migrationId);
    }
  }

}