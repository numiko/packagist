<?php

namespace Drupal\Tests\migration_logging\Unit;

use Drupal\Component\Datetime\TimeInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\Database\Connection;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\migration_logging\Service\MigrationLogger;
use Drupal\migrate\Plugin\MigrationPluginManagerInterface;
use Drupal\Tests\UnitTestCase;
use PHPUnit\Framework\MockObject\MockObject;

/**
 * Tests configuration logic of the migration logger service.
 *
 * @group migration_logging
 * @coversDefaultClass \Drupal\migration_logging\Service\MigrationLogger
 */
class ConfigurationLogicTest extends UnitTestCase {

  /**
   * The mocked configuration factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface|\PHPUnit\Framework\MockObject\MockObject
   */
  protected ConfigFactoryInterface|MockObject $configFactory;

  /**
   * The mocked configuration object.
   *
   * @var \Drupal\Core\Config\ImmutableConfig|\PHPUnit\Framework\MockObject\MockObject
   */
  protected ImmutableConfig|MockObject $config;

  /**
   * The migration logger service under test.
   *
   * @var \Drupal\migration_logging\Service\MigrationLogger
   */
  protected MigrationLogger $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    
    // Mock dependencies.
    $database = $this->createMock(Connection::class);
    $entity_manager = $this->createMock(EntityTypeManagerInterface::class);
    $time = $this->createMock(TimeInterface::class);
    $migration_manager = $this->createMock(MigrationPluginManagerInterface::class);
    
    // Mock configuration.
    $this->config = $this->createMock(ImmutableConfig::class);
    $this->configFactory = $this->createMock(ConfigFactoryInterface::class);
    $this->configFactory
      ->method('get')
      ->with('migration_logging.settings')
      ->willReturn($this->config);
    
    // Create service instance.
    $this->logger = new MigrationLogger(
      $database,
      $entity_manager,
      $time,
      $this->configFactory,
      $migration_manager
    );
  }

  /**
   * Test shouldTrackMigration with empty tracked migrations.
   *
   * @covers ::shouldTrackMigration
   */
  public function testShouldTrackMigrationEmpty(): void {
    $this->config
      ->method('get')
      ->with('tracked_migrations')
      ->willReturn([]);
    
    $result = $this->logger->shouldTrackMigration('any_migration');
    $this->assertFalse($result, 'Should not track migration when list is empty');
  }

  /**
   * Test shouldTrackMigration with null tracked migrations.
   *
   * @covers ::shouldTrackMigration
   */
  public function testShouldTrackMigrationNull(): void {
    $this->config
      ->method('get')
      ->with('tracked_migrations')
      ->willReturn(NULL);
    
    $result = $this->logger->shouldTrackMigration('any_migration');
    $this->assertFalse($result, 'Should not track migration when configuration is null');
  }

  /**
   * Test shouldTrackMigration with configured migrations.
   *
   * @covers ::shouldTrackMigration
   */
  public function testShouldTrackMigrationConfigured(): void {
    $tracked_migrations = ['event_import', 'user_import', 'content_import'];
    
    $this->config
      ->method('get')
      ->with('tracked_migrations')
      ->willReturn($tracked_migrations);
    
    // Test tracked migrations.
    $this->assertTrue(
      $this->logger->shouldTrackMigration('event_import'),
      'Should track configured migration: event_import'
    );
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('user_import'),
      'Should track configured migration: user_import'
    );
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('content_import'),
      'Should track configured migration: content_import'
    );
    
    // Test non-tracked migrations.
    $this->assertFalse(
      $this->logger->shouldTrackMigration('other_migration'),
      'Should not track unconfigured migration: other_migration'
    );
    
    $this->assertFalse(
      $this->logger->shouldTrackMigration(''),
      'Should not track empty migration name'
    );
  }

  /**
   * Test shouldTrackMigration with duplicate entries.
   *
   * @covers ::shouldTrackMigration
   */
  public function testShouldTrackMigrationDuplicates(): void {
    $tracked_migrations = [
      'duplicate_migration',
      'unique_migration',
      // Duplicate entry.
      'duplicate_migration',
      'another_migration',
    ];
    
    $this->config
      ->method('get')
      ->with('tracked_migrations')
      ->willReturn($tracked_migrations);
    
    // Should still work with duplicates in configuration.
    $this->assertTrue(
      $this->logger->shouldTrackMigration('duplicate_migration'),
      'Should track migration even with duplicate entries in config'
    );
    
    $this->assertTrue(
      $this->logger->shouldTrackMigration('unique_migration'),
      'Should track unique migration'
    );
  }

}