<?php

namespace Drupal\Tests\migration_logging\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\migration_logging\Service\MigrationLogger;
use Drupal\migrate\Plugin\MigrateIdMapInterface;

/**
 * Tests log data integrity and serialization of the migration logger.
 *
 * @group migration_logging
 */
class LogDataIntegrityTest extends KernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'migration_logging',
    'migrate',
    'migrate_plus',
  ];

  /**
   * The migration logger service.
   *
   * @var \Drupal\migration_logging\Service\MigrationLogger
   */
  protected MigrationLogger $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    
    $this->installSchema('migration_logging', ['migration_logs']);
    $this->installConfig(['migration_logging']);
    
    $this->logger = $this->container->get('migration_logging.logger');
  }

  /**
   * Test data serialization and deserialization integrity.
   */
  public function testDataSerializationIntegrity(): void {
    $migration_id = 'serialization_test';
    
    $this->logger->initializeProgress($migration_id);
    
    // Create complex data structure.
    $entity_data = [
      'created' => ['node:1', 'node:2', 'media:3'],
      'updated' => ['node:4', 'paragraph:5'],
      'deleted' => ['node:6', 'media:7', 'taxonomy_term:8'],
      'failed' => ['source_9', 'source_10'],
    ];
    
    // Track entities to create this data structure.
    foreach ($entity_data['created'] as $key) {
      [$entity_type, $id] = explode(':', $key);
      $this->logger->setPreExistingItem(FALSE);
      $this->logger->trackMapSave($migration_id, [
        'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
        'destid1' => $id,
        'sourceid1' => "source_{$id}",
      ], $entity_type);
    }
    
    foreach ($entity_data['updated'] as $key) {
      [$entity_type, $id] = explode(':', $key);
      $this->logger->setPreExistingItem(TRUE);
      $this->logger->trackMapSave($migration_id, [
        'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
        'destid1' => $id,
        'sourceid1' => "source_{$id}",
      ], $entity_type);
    }
    
    foreach ($entity_data['deleted'] as $key) {
      [$entity_type, $id] = explode(':', $key);
      $this->logger->trackDeleted($migration_id, $id, $entity_type);
    }
    
    foreach ($entity_data['failed'] as $source_id) {
      $this->logger->trackMapSave($migration_id, [
        'source_row_status' => MigrateIdMapInterface::STATUS_FAILED,
        'destid1' => NULL,
        'sourceid1' => $source_id,
      ], '');
    }
    
    // Write and retrieve log.
    $this->logger->writeLog($migration_id);
    
    $logs = $this->logger->getLogs(1);
    $this->assertCount(1, $logs, 'Should have one log entry');
    
    $log = reset($logs);
    $deserialized_data = unserialize($log->data);
    
    // Verify data structure integrity.
    $this->assertIsArray($deserialized_data, 'Deserialized data should be an array');
    $this->assertArrayHasKey('created', $deserialized_data);
    $this->assertArrayHasKey('updated', $deserialized_data);
    $this->assertArrayHasKey('deleted', $deserialized_data);
    $this->assertArrayHasKey('failed', $deserialized_data);
    
    // Verify entity keys are preserved correctly.
    foreach ($entity_data['created'] as $expected_key) {
      $this->assertArrayHasKey($expected_key, $deserialized_data['created'], 
        "Created data should contain key: {$expected_key}");
    }
    
    foreach ($entity_data['updated'] as $expected_key) {
      $this->assertArrayHasKey($expected_key, $deserialized_data['updated'],
        "Updated data should contain key: {$expected_key}");
    }
    
    foreach ($entity_data['deleted'] as $expected_key) {
      $this->assertArrayHasKey($expected_key, $deserialized_data['deleted'],
        "Deleted data should contain key: {$expected_key}");
    }
    
    foreach ($entity_data['failed'] as $expected_key) {
      $this->assertArrayHasKey($expected_key, $deserialized_data['failed'],
        "Failed data should contain key: {$expected_key}");
    }
  }

  /**
   * Test large data volume handling.
   */
  public function testLargeDataVolume(): void {
    $migration_id = 'large_volume_test';
    
    $this->logger->initializeProgress($migration_id);
    
    // Create a large number of entity tracking entries.
    $num_entities = 1000;
    for ($i = 1; $i <= $num_entities; $i++) {
      $entity_type = ($i % 2 === 0) ? 'node' : 'media';
      $this->logger->setPreExistingItem(FALSE);
      $this->logger->trackMapSave($migration_id, [
        'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
        'destid1' => $i,
        'sourceid1' => "source_{$i}",
      ], $entity_type);
    }
    
    $this->logger->writeLog($migration_id);
    
    $logs = $this->logger->getLogs(1);
    $this->assertCount(1, $logs, 'Should create one log for large volume');
    
    $log = reset($logs);
    $this->assertEquals($num_entities, $log->created, 'Should track all entities');
    
    $data = unserialize($log->data);
    $this->assertIsArray($data, 'Should deserialize large data volume');
    $this->assertCount($num_entities, $data['created'], 
      'Should preserve all entity keys in large volume');
    
    // Verify some random entries to ensure data integrity.
    $this->assertArrayHasKey('node:2', $data['created']);
    $this->assertArrayHasKey('media:1', $data['created']);
    $this->assertArrayHasKey('node:1000', $data['created']);
  }

  /**
   * Test empty data handling.
   */
  public function testEmptyDataHandling(): void {
    $migration_id = 'empty_data_test';
    
    // Write log with no tracked entities.
    $this->logger->initializeProgress($migration_id);
    $this->logger->writeLog($migration_id);
    
    $logs = $this->logger->getLogs(1);
    $this->assertCount(1, $logs, 'Should create log even with no entities');
    
    $log = reset($logs);
    $this->assertEquals(0, $log->created);
    $this->assertEquals(0, $log->updated);
    $this->assertEquals(0, $log->deleted);
    $this->assertEquals(0, $log->failed);
    
    $data = unserialize($log->data);
    $this->assertIsArray($data, 'Should deserialize empty data structure');
    $this->assertEmpty($data['created'], 'Created array should be empty');
    $this->assertEmpty($data['updated'], 'Updated array should be empty');
    $this->assertEmpty($data['deleted'], 'Deleted array should be empty');
    $this->assertEmpty($data['failed'], 'Failed array should be empty');
  }

  /**
   * Test data corruption detection.
   */
  public function testDataCorruptionDetection(): void {
    // Manually insert corrupted data.
    \Drupal::database()->insert('migration_logs')
      ->fields([
        'migration_id' => 'corruption_test',
        'created' => 1,
        'updated' => 0,
        'deleted' => 0,
        'failed' => 0,
        'data' => 'invalid_serialized_data',
        'timestamp' => \Drupal::time()->getCurrentTime(),
      ])
      ->execute();
    
    $log = $this->logger->getLog(\Drupal::database()->lastInsertId());
    
    // Attempt to unserialise corrupted data.
    $unserialized = @unserialize($log->data);
    $this->assertFalse($unserialized, 'Corrupted data should fail to unserialize');
    
    // Test that system handles corruption gracefully.
    $this->assertTrue(TRUE, 'System should handle corrupted data without fatal errors');
  }

}