<?php

namespace Drupal\Tests\migration_logging\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\migration_logging\Service\MigrationLogger;
use Drupal\migrate\Plugin\MigrateIdMapInterface;

/**
 * Tests progress tracking functionality of the migration logger.
 *
 * @group migration_logging
 */
class ProgressTrackingTest extends KernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  protected static $modules = [
    'migration_logging',
    'migrate',
    'migrate_plus',
  ];

  /**
   * The migration logger service.
   *
   * @var \Drupal\migration_logging\Service\MigrationLogger
   */
  protected MigrationLogger $logger;

  /**
   * {@inheritdoc}
   */
  protected function setUp(): void {
    parent::setUp();
    
    $this->installSchema('migration_logging', ['migration_logs']);
    $this->installConfig(['migration_logging']);
    
    $this->logger = $this->container->get('migration_logging.logger');
  }

  /**
   * Test basic progress tracking initialization.
   */
  public function testProgressInitialization(): void {
    $migration_id = 'test_migration';
    
    // Test initialization.
    $this->logger->initializeProgress($migration_id);
    
    // Verify no logs exist yet.
    $logs = $this->logger->getLogs();
    $this->assertEmpty($logs, 'No logs should exist before tracking events');
  }

  /**
   * Test tracking created entities.
   */
  public function testTrackingCreatedEntities(): void {
    $migration_id = 'test_migration';
    $entity_type = 'node';
    
    $this->logger->initializeProgress($migration_id);
    
    // Simulate creating entities.
    $this->logger->setPreExistingItem(FALSE);
    $this->logger->trackMapSave($migration_id, [
      'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
      'destid1' => 123,
      'sourceid1' => 'source_123',
    ], $entity_type);
    
    $this->logger->setPreExistingItem(FALSE);
    $this->logger->trackMapSave($migration_id, [
      'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
      'destid1' => 124,
      'sourceid1' => 'source_124',
    ], $entity_type);
    
    // Write log and verify.
    $this->logger->writeLog($migration_id);
    
    $logs = $this->logger->getLogs(1);
    $this->assertCount(1, $logs, 'Should have one log entry');
    
    $log = reset($logs);
    $this->assertEquals(2, $log->created, 'Should track 2 created entities');
    $this->assertEquals(0, $log->updated, 'Should have 0 updated entities');
    $this->assertEquals(0, $log->deleted, 'Should have 0 deleted entities');
    $this->assertEquals(0, $log->failed, 'Should have 0 failed entities');
    
    // Verify entity data contains proper keys.
    $data = unserialize($log->data);
    $this->assertArrayHasKey('created', $data);
    $this->assertArrayHasKey("$entity_type:123", $data['created']);
    $this->assertArrayHasKey("$entity_type:124", $data['created']);
  }

  /**
   * Test tracking updated entities.
   */
  public function testTrackingUpdatedEntities(): void {
    $migration_id = 'test_migration';
    $entity_type = 'node';
    
    $this->logger->initializeProgress($migration_id);
    
    // Simulate updating existing entities.
    $this->logger->setPreExistingItem(TRUE);
    $this->logger->trackMapSave($migration_id, [
      'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
      'destid1' => 456,
      'sourceid1' => 'source_456',
    ], $entity_type);
    
    $this->logger->writeLog($migration_id);
    
    $logs = $this->logger->getLogs(1);
    $log = reset($logs);
    
    $this->assertEquals(0, $log->created, 'Should have 0 created entities');
    $this->assertEquals(1, $log->updated, 'Should track 1 updated entity');
    
    $data = unserialize($log->data);
    $this->assertArrayHasKey("$entity_type:456", $data['updated']);
  }

  /**
   * Test tracking deleted entities.
   */
  public function testTrackingDeletedEntities(): void {
    $migration_id = 'test_migration';
    $entity_type = 'paragraph';
    
    $this->logger->initializeProgress($migration_id);

    // Simulate deleted entities.
    $this->logger->trackDeleted($migration_id, 789, $entity_type);
    $this->logger->trackDeleted($migration_id, 790, $entity_type);
    
    $this->logger->writeLog($migration_id);
    
    $logs = $this->logger->getLogs(1);
    $log = reset($logs);
    
    $this->assertEquals(0, $log->created, 'Should have 0 created entities');
    $this->assertEquals(0, $log->updated, 'Should have 0 updated entities');
    $this->assertEquals(2, $log->deleted, 'Should track 2 deleted entities');
    
    $data = unserialize($log->data);
    $this->assertArrayHasKey("$entity_type:789", $data['deleted']);
    $this->assertArrayHasKey("$entity_type:790", $data['deleted']);
  }

  /**
   * Test mixed entity operations in single migration run.
   */
  public function testMixedEntityOperations(): void {
    $migration_id = 'mixed_test';
    $entity_type = 'node';
    
    $this->logger->initializeProgress($migration_id);
    
    // Created entity.
    $this->logger->setPreExistingItem(FALSE);
    $this->logger->trackMapSave($migration_id, [
      'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
      'destid1' => 100,
      'sourceid1' => 'source_100',
    ], $entity_type);
    
    // Updated entity.
    $this->logger->setPreExistingItem(TRUE);
    $this->logger->trackMapSave($migration_id, [
      'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
      'destid1' => 200,
      'sourceid1' => 'source_200',
    ], $entity_type);
    
    // Failed entity.
    $this->logger->trackMapSave($migration_id, [
      'source_row_status' => MigrateIdMapInterface::STATUS_FAILED,
      'destid1' => NULL,
      'sourceid1' => 'source_300',
    ], $entity_type);
    
    // Deleted entity.
    $this->logger->trackDeleted($migration_id, 400, $entity_type);
    
    $this->logger->writeLog($migration_id);
    
    $logs = $this->logger->getLogs(1);
    $log = reset($logs);
    
    $this->assertEquals(1, $log->created, 'Should track 1 created entity');
    $this->assertEquals(1, $log->updated, 'Should track 1 updated entity');
    $this->assertEquals(1, $log->deleted, 'Should track 1 deleted entity');
    $this->assertEquals(1, $log->failed, 'Should track 1 failed entity');
    
    $data = unserialize($log->data);
    $this->assertArrayHasKey("$entity_type:100", $data['created']);
    $this->assertArrayHasKey("$entity_type:200", $data['updated']);
    $this->assertArrayHasKey("$entity_type:400", $data['deleted']);
    $this->assertArrayHasKey('source_300', $data['failed']);
  }

  /**
   * Test entity key format consistency.
   */
  public function testEntityKeyFormat(): void {
    $migration_id = 'key_test';
    
    $this->logger->initializeProgress($migration_id);
    
    // Test with entity type.
    $this->logger->setPreExistingItem(FALSE);
    $this->logger->trackMapSave($migration_id, [
      'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
      'destid1' => 999,
      'sourceid1' => 'source_999',
    ], 'media');
    
    // Test without entity type (fallback).
    $this->logger->setPreExistingItem(FALSE);
    $this->logger->trackMapSave($migration_id, [
      'source_row_status' => MigrateIdMapInterface::STATUS_IMPORTED,
      'destid1' => 888,
      'sourceid1' => 'source_888',
    ], '');
    
    $this->logger->writeLog($migration_id);
    
    $logs = $this->logger->getLogs(1);
    $log = reset($logs);
    $data = unserialize($log->data);
    
    // With entity type should use entity_type:id format.
    $this->assertArrayHasKey('media:999', $data['created']);
    
    // Without entity type should use just ID.
    $this->assertArrayHasKey('888', $data['created']);
  }

}