<?php

namespace Drupal\migration_logging\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\TypedConfigManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\migrate\Plugin\MigrationPluginManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Configure migration logging settings.
 */
class MigrationLoggingSettingsForm extends ConfigFormBase {

  /**
   * Configuration name.
   */
  const CONFIG_NAME = 'migration_logging.settings';

  /**
   * Constructs a MigrationLoggingSettingsForm object.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   The factory for configuration objects.
   * @param \Drupal\Core\Config\TypedConfigManagerInterface $typedConfigManager
   *   The typed config manager.
   * @param \Drupal\migrate\Plugin\MigrationPluginManagerInterface $migrationPluginManager
   *   The migration plugin manager.
   */
  public function __construct(ConfigFactoryInterface $configFactory, TypedConfigManagerInterface $typedConfigManager, protected MigrationPluginManagerInterface $migrationPluginManager) {
    parent::__construct($configFactory, $typedConfigManager);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('config.typed'),
      $container->get('plugin.manager.migration')
    );
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return [self::CONFIG_NAME];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId(): string {
    return 'migration_logging_settings';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config(self::CONFIG_NAME);
    $tracked_migrations = $config->get('tracked_migrations') ?: [];

    // Get all available migrations.
    $migration_options = [];
    $migrations = $this->migrationPluginManager->getDefinitions();
    foreach ($migrations as $migration_id => $migration) {
      $migration_options[$migration_id] = $migration['label'] ?? $migration_id;
    }

    // Sort by label for better UX.
    asort($migration_options);

    $form['tracked_migrations'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Tracked Migrations'),
      '#description' => $this->t('Select which migrations should be tracked for logging. When these migrations run, detailed logs will be created showing what entities were created, updated, deleted, or failed.'),
      '#options' => $migration_options,
      '#default_value' => array_combine($tracked_migrations, $tracked_migrations),
    ];

    if (empty($migration_options)) {
      $form['no_migrations'] = [
        '#type' => 'item',
        '#markup' => $this->t('No migrations are currently available. Migrations must be defined by other modules.'),
      ];
      $form['tracked_migrations']['#access'] = FALSE;
    }

    // Log pruning settings.
    $form['pruning'] = [
      '#type' => 'details',
      '#title' => $this->t('Automatic Log Pruning'),
      '#description' => $this->t('Configure automatic cleanup of old migration logs to prevent database growth.'),
      '#open' => FALSE,
    ];

    $form['pruning']['auto_prune'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable automatic log pruning'),
      '#description' => $this->t('Automatically delete old migration logs during cron runs.'),
      '#default_value' => $config->get('auto_prune') ?: FALSE,
    ];

    $form['pruning']['prune_age_days'] = [
      '#type' => 'number',
      '#title' => $this->t('Delete logs older than (days)'),
      '#description' => $this->t('Migration logs older than this many days will be automatically deleted.'),
      '#default_value' => $config->get('prune_age_days') ?: 90,
      '#min' => 1,
      '#max' => 3650,
      '#states' => [
        'visible' => [
          ':input[name="auto_prune"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['pruning']['max_logs_per_migration'] = [
      '#type' => 'number',
      '#title' => $this->t('Maximum logs to keep per migration'),
      '#description' => $this->t('Keep only the most recent N logs for each migration (0 = no limit).'),
      '#default_value' => $config->get('max_logs_per_migration') ?: 50,
      '#min' => 0,
      '#max' => 1000,
      '#states' => [
        'visible' => [
          ':input[name="auto_prune"]' => ['checked' => TRUE],
        ],
      ],
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $tracked_migrations = array_filter($form_state->getValue('tracked_migrations'));
    
    $config = $this->config(self::CONFIG_NAME);
    $config
      ->set('tracked_migrations', array_values($tracked_migrations))
      ->set('auto_prune', $form_state->getValue('auto_prune'))
      ->set('prune_age_days', $form_state->getValue('prune_age_days'))
      ->set('max_logs_per_migration', $form_state->getValue('max_logs_per_migration'))
      ->save();

    $count = count($tracked_migrations);
    if ($count > 0) {
      $this->messenger()->addStatus($this->t('Migration logging has been configured to track @count migration(s).', ['@count' => $count]));
    } else {
      $this->messenger()->addStatus($this->t('Migration logging has been disabled for all migrations.'));
    }

    if ($form_state->getValue('auto_prune')) {
      $this->messenger()->addStatus($this->t('Automatic log pruning is enabled. Logs older than @days days will be deleted during cron runs.', [
        '@days' => $form_state->getValue('prune_age_days'),
      ]));
    }

    parent::submitForm($form, $form_state);
  }

}