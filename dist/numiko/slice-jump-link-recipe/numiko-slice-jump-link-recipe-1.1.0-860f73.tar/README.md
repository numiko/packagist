# Jump Links Recipe
This recipe installs and configures jump link with basic fields.

## Installation
This recipe requires the use of extra-recipe-config-action module.
https://bitbucket.org/numiko/extra-recipe-config-action/src/main/

Apply the recipe from the docroot folder.

`php core/scripts/drupal recipe recipes/contrib/slice-jump-link-recipe`

## Test
Add checks for field_jump_link_label for each slice that is using jump links.

example:
```
'field_jump_link_label' => 'Jump link Label',
$assertSession->pageTextContains('Jump link Label');
```