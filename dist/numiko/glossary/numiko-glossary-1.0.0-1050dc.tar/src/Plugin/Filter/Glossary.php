<?php

namespace Drupal\glossary\Plugin\Filter;

use Drupal\Component\Utility\Html;
use Drupal\filter\FilterProcessResult;
use Drupal\filter\Plugin\FilterBase;
use Drupal\taxonomy\Entity\Term;

/**
 * @Filter(
 *   id = "filter_glossary",
 *   title = @Translation("Glossary Filter"),
 *   description = @Translation("Show tooltip from shortcode"),
 *   type = Drupal\filter\Plugin\FilterInterface::TYPE_MARKUP_LANGUAGE,
 * )
 */
class Glossary extends FilterBase {

  /**
   * This has mostly been taken from the D7 ofgem module.
   *
   * {@inheritdoc}
   */
  public function process($text, $langcode) {
    preg_match_all('/\[key-term:(\d+):(.*?)\]/', $text, $matches);
    foreach ($matches[1] as $k => $tid) {
      // Load the term and render as a data attribute.
      if ($term = Term::load($tid)) {
        $description = '';
        if (!($term->get('field_description')->isEmpty())) {
          $field = $term->field_description->view('teaser');
          $description = \Drupal::service('renderer')->render($field);
        }

        $text = str_replace(
          $matches[0][$k],
          '<button type="button" class="c-button c-button--text align-baseline p-0 underline underline-style-dotted underline-offset-small cursor-help [ hover:no-underline ]" data-toggle="tooltip" data-js-modal-trigger data-term-id="' . $tid . '" data-js-modal-markup="' . Html::escape($description) . '" title="' . $matches[2][$k] . '">' . $matches[2][$k] . '</button>',
          $text
        );
      }
    }
    return new FilterProcessResult($text);
  }

}
