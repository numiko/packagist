<?php

namespace Drupal\glossary\Plugin\CKEditorPlugin;

use Drupal\ckeditor\CKEditorPluginBase;
use Drupal\editor\Entity\Editor;

/**
 * Defines the glossary plugin.
 *
 * @CKEditorPlugin(
 *   id = "glossary",
 *   label = @Translation("Glossary"),
 * )
 */
class Glossary extends CKEditorPluginBase {

  /**
   * {@inheritdoc}
   */
  public function getFile() {
    return drupal_get_path('module', 'glossary') . '/js/plugins/glossary/plugin.js';
  }

  /**
   * {@inheritdoc}
   */
  public function getLibraries(Editor $editor) {
    return [
      'core/drupal.ajax',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getConfig(Editor $editor) {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function getButtons() {
    $path = drupal_get_path('module', 'glossary') . '/js/plugins/glossary';
    return [
      'glossary' => [
        'label' => $this->t('Glossary'),
        'image' => $path . '/glossary.png',
      ],
    ];
  }

}
