# Glossary

## Installation

This module will install a glossary taxonomy, slice and view, the only manual step is to populate the taxonomy and copy and update the paragraph template into the theme folder.

## Usage

In order to use this functionality:

* Add the glossary button to the text format settings
* Add the glossary filter to the text format settings
* Add an item to the "glossaries" taxonomy
