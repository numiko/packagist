/**
 * @file
 * CKEditor Glossary plugin.
 *
 * @ignore
 */

(function ($, Drupal, drupalSettings, CKEDITOR) {

  'use strict';

  CKEDITOR.plugins.add('glossary', {
    init: function (editor) {
      editor.addCommand('glossary', {
        modes: {wysiwyg: 1},
        canUndo: true,
        exec: function (editor) {
          // Prepare a save callback to be used upon saving the dialog.
          var saveCallback = function (returnValues) {
            editor.fire('saveSnapshot');
            // Create a key term element.
            if (returnValues.attributes.tid) {
              editor.insertText('[key-term:' + returnValues.attributes.tid + ':' + returnValues.attributes.name + ']');
            }
            // Save snapshot for undo support.
            editor.fire('saveSnapshot');
          };

          var dialogSettings = {
            title: 'Add glossary term',
            dialogClass: 'editor-glossary-dialog'
          };

          // Open the dialog for the edit form.
          Drupal.ckeditor.openDialog(editor, Drupal.url('ckeditor-glossary/dialog/' + editor.config.drupal.format), [], saveCallback, dialogSettings);
        }
      });

      // Add buttons for link and unlink.
      if (editor.ui.addButton) {
        editor.ui.addButton('glossary', {
          label: Drupal.t('Glossary'),
          command: 'glossary',
          icon: this.path + '/glossary.png'
        });
      }
    }
  });

})(jQuery, Drupal, drupalSettings, CKEDITOR);
