<?php

namespace Drupal\glossary\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Class DefaultController.
 */
class DefaultController extends ControllerBase {

  /**
   * Dummy route for the summary in views to work.
   *
   * @return array
   *   Return dummy string.
   */
  public function dummy($name) {
    return [
      '#theme' => 'glossary',
      '#letters' => 'A-B-C',
    ];
  }

}
