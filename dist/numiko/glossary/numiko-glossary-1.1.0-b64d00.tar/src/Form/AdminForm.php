<?php

namespace Drupal\glossary\Form;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Glossary administrative settings form.
 */
class AdminForm extends ConfigFormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'glossary_admin_form';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['glossary.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('glossary.settings');

    $form = [];
    $form['glossary']['classes'] = [
      '#type'          => 'textfield',
      '#title'         => $this->t('Glossary term HTML element classes'),
      '#default_value' => $config->get('classes') ? $config->get('classes') : '',
      '#size'          => 60,
      '#description'   => $this->t('Enter the class string be applied to the button element class attribute in the HTML generated for the glossary term.'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $config = $this->config('glossary.settings');
    $config->set('classes', $form_state->getValue('classes'));
    $config->save();
    parent::submitForm($form, $form_state);
  }

}
