<?php

namespace Drupal\glossary\Plugin\Filter;

use Drupal\Component\Utility\Html;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\filter\FilterProcessResult;
use Drupal\filter\Plugin\FilterBase;
use Drupal\taxonomy\TermStorageInterface;

/**
 * @Filter(
 *   id = "filter_glossary",
 *   title = @Translation("Glossary Filter"),
 *   description = @Translation("Show tooltip from shortcode"),
 *   type = Drupal\filter\Plugin\FilterInterface::TYPE_MARKUP_LANGUAGE,
 * )
 */
class Glossary extends FilterBase implements ContainerFactoryPluginInterface {

  /**
   * Renderer service.
   *
   * @var \Drupal\Core\Render\RendererInterface
   */
  protected RendererInterface $renderer;

  /**
   * Taxonomy term storage.
   *
   * @var \Drupal\taxonomy\TermStorageInterface
   */
  protected TermStorageInterface $termStorage;

  /**
   * Config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected ConfigFactoryInterface $configFactory;

  /**
   * {@inheritdoc}
   */
  public static function create($container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('renderer'),
      $container->get('entity_type.manager')->getStorage('taxonomy_term'),
      $container->get('config.factory')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function __construct
  (
    array $configuration,
    $plugin_id,
    $plugin_definition,
    RendererInterface $renderer,
    TermStorageInterface $term_storage,
    ConfigFactoryInterface $config_factory
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);

    $this->renderer = $renderer;
    $this->termStorage = $term_storage;
    $this->configFactory = $config_factory;
  }

  /**
   * This has mostly been taken from the D7 ofgem module.
   *
   * {@inheritdoc}
   *
   * @throws \Exception
   */
  public function process($text, $langcode) {
    preg_match_all('/\[key-term:(\d+):(.*?)\]/', $text, $matches);
    foreach ($matches[1] as $k => $tid) {
      // Load the term and render as a data attribute.
      if ($term = $this->termStorage->load($tid)) {
        $description = '';
        if (!($term->get('field_description')->isEmpty())) {
          $field = $term->field_description->view('teaser');
          $description = $this->renderer->render($field);
        }

        $config = $this->configFactory->get('glossary.settings');
        $elementClasses = $config->get('classes') ? $config->get('classes') : '';

        $text = str_replace(
          $matches[0][$k],
          '<button type="button" class="' . $elementClasses . '" data-toggle="tooltip" data-js-modal-trigger data-term-id="' . $tid . '" data-js-modal-markup="' . Html::escape($description) . '" data-js-term-title="' . $term->getName() . '" title="' . $matches[2][$k] . '">' . $matches[2][$k] . '</button>',
          $text
        );
      }
    }
    return new FilterProcessResult($text);
  }

}
