(function ($) {
  Drupal.behaviors.main = {
    attach: function(context, settings) {

      var $azLinks = $('[data-js-az-link]');
      var activeClass = 'border-color-theme';

      $azLinks.on("click",function(event) {
        event.preventDefault();
        if (!$(this).hasClass('disabled')) {
          // Read in user selection for A-Z letter.
          var userSelectionLetter = $(this).attr('data-js-az-letter');

          $azLinks.removeClass(activeClass);

          $('[data-js-az-letter=' + userSelectionLetter + ']').addClass(activeClass);

          // Populate the hidden exposed filter with the user selection.
          var exposedFilter = "#" + settings["exposed_filter"];
          $(exposedFilter).find("input[name=letter]").val(userSelectionLetter);
          // Reload the form.
          $(exposedFilter).find("[data-js-form-submit]").click();
        }
      });
    }
  }
})(jQuery);
