# Media Responsive Thumbnail File Formatter #

This module includes a field formatter for enabling responsive images for a media entity.

This module uses the thumbnail property of a media item and contains a factory for generating thumbnail elements including correct alt text for image media items.

The module requires the responsive image module to be enabled.
