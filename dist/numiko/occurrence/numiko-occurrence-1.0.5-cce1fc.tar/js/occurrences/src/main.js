import { createApp } from 'vue'
import App from './App.vue'

const appElements = document.querySelectorAll('[data-js-occurrences]');

appElements.forEach(appElement => {
  // Get the occurrence settings that are passed from drupal.
  // This will contain any exisiting occurrence entities. 
  // The required fields and the fields from the occurrence entity form.
  const occurrenceSettings = window.drupalSettings['occurrence'];
  if (occurrenceSettings) {
    const app = createApp(App, {occurrenceSettings});
    app.mount(appElement);
  }
});
