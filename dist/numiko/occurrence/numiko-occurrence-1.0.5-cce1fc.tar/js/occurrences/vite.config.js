import path from 'path';
import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import basicSsl from '@vitejs/plugin-basic-ssl';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    basicSsl(),
    vue(),
  ],
  define: {
    'process.env': {}
  },
  build: {
    manifest: true,
    rollupOptions: {
      input: {
        'main': path.resolve(__dirname, 'src/main.js'),
      },
      output: {
        entryFileNames: '[name]-[hash].js',
        chunkFileNames: '[name]-[hash].js',
      },
    },
  },
  server: {
    host: true,
    https: true,
    port: 5173,
    strictPort: true,
    hmr: {
      host: 'localhost',
    },
  },
})
