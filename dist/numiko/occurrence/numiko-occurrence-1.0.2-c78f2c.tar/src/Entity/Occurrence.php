<?php

namespace Drupal\occurrence\Entity;

use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\user\UserInterface;

/**
 * Defines the Occurrence entity.
 *
 * @ingroup occurrence
 *
 * @ContentEntityType(
 *   id = "occurrence",
 *   label = @Translation("Occurrence"),
 *   label_singular = @Translation("occurrence"),
 *   label_plural = @Translation("occurrences"),
 *   label_count = @PluralTranslation(
 *     singular = "@count occurrence",
 *     plural = "@count occurrences"
 *   ),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\occurrence\OccurrenceListBuilder",
 *     "form" = {
 *       "default" = "Drupal\occurrence\Form\OccurrenceForm",
 *       "add" = "Drupal\occurrence\Form\OccurrenceForm",
 *       "edit" = "Drupal\occurrence\Form\OccurrenceForm",
 *       "delete" = "Drupal\occurrence\Form\OccurrenceDeleteForm",
 *     },
 *     "access" = "Drupal\occurrence\OccurrenceAccessControlHandler",
 *     "route_provider" = {
 *       "html" = "Drupal\occurrence\OccurrenceHtmlRouteProvider",
 *     },
 *   },
 *   base_table = "occurrence",
 *   data_table = "occurrence_field_data",
 *   translatable = TRUE,
 *   admin_permission = "administer occurrence entities",
 *   entity_keys = {
 *     "id" = "id",
 *     "uuid" = "uuid",
 *     "uid" = "user_id",
 *     "langcode" = "langcode",
 *     "status" = "status",
 *   },
 *   links = {
 *     "add-form" = "/admin/structure/occurrence/add",
 *     "edit-form" = "/admin/structure/occurrence/{occurrence}/edit",
 *     "delete-form" = "/admin/structure/occurrence/{occurrence}/delete",
 *     "collection" = "/admin/structure/occurrence",
 *   },
 *   field_ui_base_route = "occurrence.settings"
 * )
 */
class Occurrence extends ContentEntityBase implements OccurrenceInterface {

  use EntityChangedTrait;

  /**
   * {@inheritdoc}
   */
  public static function preCreate(EntityStorageInterface $storage_controller, array &$values) {
    parent::preCreate($storage_controller, $values);
    $values += [
      'user_id' => \Drupal::currentUser()->id(),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function getCreatedTime() {
    return $this->get('created')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setCreatedTime($timestamp) {
    $this->set('created', $timestamp);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getOwner() {
    return $this->get('user_id')->entity;
  }

  /**
   * {@inheritdoc}
   */
  public function getOwnerId() {
    return $this->get('user_id')->target_id;
  }

  /**
   * {@inheritdoc}
   */
  public function setOwnerId($uid) {
    $this->set('user_id', $uid);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function setOwner(UserInterface $account) {
    $this->set('user_id', $account->id());
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function isPublished() {
    return (bool) $this->getEntityKey('status');
  }

  /**
   * {@inheritdoc}
   */
  public function setPublished($published) {
    $this->set('status', $published ? TRUE : FALSE);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getDate() {
    return $this->get('date')->date;
  }

  /**
   * {@inheritdoc}
   */
  public function getStartTime() {
    return $this->get('start_time')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function getEndTime() {
    return $this->get('end_time')->value;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['date'] = BaseFieldDefinition::create('datetime')
      ->setLabel(t('Date'))
      ->setDisplayConfigurable('view', TRUE)
      ->setSettings([
        'datetime_type' => 'date'
      ])
      ->setDisplayOptions('form', [
        'type' => 'datetime_default',
        'weight' => -5,
      ])
      ->setRequired(TRUE);

    $fields['start_time'] = BaseFieldDefinition::create('time')
      ->setLabel(t('Start time'))
      ->setDisplayConfigurable('view', TRUE)
      ->setSetting('unsigned', TRUE)
      ->setSetting('size', 'small')
      ->setDisplayOptions('form', [
        'type' => 'time_widget',
        'weight' => -4,
      ])
      ->setRequired(TRUE);

    $fields['end_time'] = BaseFieldDefinition::create('time')
      ->setLabel(t('End time'))
      ->setDisplayConfigurable('view', TRUE)
      ->setSetting('unsigned', TRUE)
      ->setSetting('size', 'small')
      ->setDisplayOptions('form', [
        'type' => 'time_widget',
        'weight' => -3,
      ])
      ->setRequired(TRUE);

    $fields['user_id'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Authored by'))
      ->setDescription(t('The user ID of author of the Occurrence entity.'))
      ->setRevisionable(TRUE)
      ->setSetting('target_type', 'user')
      ->setSetting('handler', 'default')
      ->setTranslatable(TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'author',
        'weight' => 0,
      ])
      ->setDisplayOptions('form', [
        'type' => 'entity_reference_autocomplete',
        'weight' => 5,
        'settings' => [
          'match_operator' => 'CONTAINS',
          'size' => '60',
          'autocomplete_type' => 'tags',
          'placeholder' => '',
        ],
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE);

    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Publishing status'))
      ->setDescription(t('A boolean indicating whether the Occurrence is published.'))
      ->setDefaultValue(TRUE);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'))
      ->setDescription(t('The time that the entity was created.'));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
      ->setDescription(t('The time that the entity was last edited.'));

    return $fields;
  }

}
