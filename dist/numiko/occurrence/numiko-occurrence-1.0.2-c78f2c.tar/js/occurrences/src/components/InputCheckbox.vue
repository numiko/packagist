<script setup>
import {computed} from 'vue';

const props = defineProps({
  id: {
    type: Number,
    required: true
  },
  label: {
    type: String,
    required: true
  },
  labelClass: {
    type: String,
    required: false
  },
  data: {
    type: [Object, Number],
    default: () => ({})
  },
  modelValue: Array
});

const emit = defineEmits(['update:modelValue'])
const model = computed({
  get: () => props.modelValue,
  set: items => emit('update:modelValue', items)
})
</script>

<template>
  <div class="form-item form-type--checkbox form-type--boolean">
    <input
      class="form-checkbox form-boolean form-boolean--type-checkbox"
      type="checkbox"
      :id="`checkbox-${id}`"
      :value="data"
      v-model="model"
    />
    <label class="form-item__label option" :class="labelClass" :for="`checkbox-${id}`">{{ label }}</label>
  </div>
</template>
