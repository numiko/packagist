<?php

namespace Drupal\occurrence\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Occurrence entities.
 *
 * @ingroup occurrence
 */
class OccurrenceDeleteForm extends ContentEntityDeleteForm {


}
