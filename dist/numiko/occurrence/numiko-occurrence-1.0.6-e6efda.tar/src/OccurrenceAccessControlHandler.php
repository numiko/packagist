<?php

namespace Drupal\occurrence;

use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

/**
 * Access controller for the Occurrence entity.
 *
 * @see \Drupal\occurrence\Entity\Occurrence.
 */
class OccurrenceAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\occurrence\Entity\OccurrenceInterface $entity */
    switch ($operation) {
      case 'view':
        if (!$entity->isPublished()) {
          return AccessResult::allowedIfHasPermission($account, 'view unpublished occurrence entities');
        }
        return AccessResult::allowedIfHasPermission($account, 'view published occurrence entities');

      case 'update':
        return AccessResult::allowedIfHasPermission($account, 'edit occurrence entities');

      case 'delete':
        return AccessResult::allowedIfHasPermission($account, 'delete occurrence entities');
    }

    // Unknown operation, no opinion.
    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'add occurrence entities');
  }

}
