import { useDateFormat } from '@vueuse/core'

/**
 * formatTime
 *
 * Formats a timestamp to time.
 */
export function formatTime(value) {
  // This is how the Drupal time field handles this.
  const time = new Date('2012-01-01 00:00:00');
  time.setTime(((time.getTime() / 1000) + value) * 1000);
  return useDateFormat(time, 'HH:mm').value;
}

/**
 * formatDate
 *
 * Formats a date.
 */
export function formatDate(value) {
  return useDateFormat(value, 'dddd D MMMM YYYY').value;
}

/**
 * formatShortDate
 *
 * Formats a date.
 */
export function formatShortDate(value) {
  return useDateFormat(value, 'YYYY-MM-DD').value;
}
