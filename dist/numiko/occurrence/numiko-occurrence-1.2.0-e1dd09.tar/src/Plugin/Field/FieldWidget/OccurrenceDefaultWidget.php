<?php

namespace Drupal\occurrence\Plugin\Field\FieldWidget;

use Drupal\Component\Utility\NestedArray;
use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\Entity\EntityFormDisplay;
use Drupal\Core\Entity\EntityTypeManager;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Field\WidgetBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\Serializer\Serializer;

/**
 * Class OccurrenceDefaultWidget.
 *
 * @FieldWidget(
 *   id = "occurrence_default",
 *   label = @Translation("Occurrence default"),
 *   field_types = {
 *     "entity_reference",
 *   },
 *   multiple_values = true
 * )
 */
class OccurrenceDefaultWidget extends WidgetBase implements ContainerFactoryPluginInterface {

  /**
   * @var \Drupal\Core\Entity\EntityTypeManager
   */
  protected $entityTypeManager;

  /**
   * @var \Symfony\Component\Serializer\Serializer
   */
  protected $serializer;

  /**
   * Constructs an OccurrenceDefaultWidget object.
   *
   * @param $plugin_id
   * @param $plugin_definition
   * @param \Drupal\Core\Field\FieldDefinitionInterface $field_definition
   * @param array $settings
   * @param array $third_party_settings
   * @param \Drupal\Core\Entity\EntityTypeManager $entityTypeManager
   * @param \Symfony\Component\Serializer\Serializer $serializer
   */
  public function __construct($plugin_id, $plugin_definition, FieldDefinitionInterface $field_definition, array $settings, array $third_party_settings, EntityTypeManager $entityTypeManager, Serializer $serializer) {
    parent::__construct($plugin_id, $plugin_definition, $field_definition, $settings, $third_party_settings);
    $this->entityTypeManager = $entityTypeManager;
    $this->serializer = $serializer;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $plugin_id,
      $plugin_definition,
      $configuration['field_definition'],
      $configuration['settings'],
      $configuration['third_party_settings'],
      $container->get('entity_type.manager'),
      $container->get('serializer')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    // Add the VueJS occurrence library.
    $element['#attached']['library'][] = 'occurrence/occurrence_app';
    $element['#attached']['drupalSettings']['occurrence'] = [
      'entities' => [],
      'requiredFields' => [],
      'fields' => [],
    ];

    $target_ids = [];
    $referenced_entities = $items->referencedEntities();
    foreach ($referenced_entities as $key => $entity) {
      $target_ids[] = [
        'target_id' => $entity->id(),
      ];
      // Add referenced occurrences to JS settings for vue to read.
      $element['#attached']['drupalSettings']['occurrence']['entities'][] = json_decode($this->serializer->serialize($entity, 'json'));
    }

    $field_name = $this->fieldDefinition->getName();
    $parents = $element['#field_parents'];

    $element_parents = $parents;
    $element_parents[] = $field_name;
    $element_parents[] = 'subform';

    $element += [
      '#type' => 'container',
      'subform' => [
        '#type' => 'fieldset',
        '#parents' => $element_parents,
        '#attributes' => ['data-js-drupal-form' => ''],
      ],
    ];

    // Create an empty occurrence entity to build the form.
    $entity = $this->entityTypeManager->getStorage('occurrence')->create([]);
    $form_display = $this->getFormDisplay($entity, 'default');
    $form_display->buildForm($entity, $element['subform'], $form_state);

    foreach ($form_display->getComponents() as $fieldName => $field) {
      $this->unsetRequiredFields($element, $fieldName);
      // Add to JS setting.
      $element['#attached']['drupalSettings']['occurrence']['fields'][] = $fieldName;
    }

    $element['target_ids'] = [
      '#title' => $this->t('Target IDs'),
      '#type' => 'value',
      '#value' => $target_ids,
    ];

    // Add a payload field which vue will populate. This data is then processed
    // with massageFormValues().
    $element['payload'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Payload'),
      '#prefix' => '<div class="hidden">',
      '#suffix' => '</div>'
    ];

    // Container for the vue app to be added to.
    $element['app'] = [
      '#type' => 'container',
      '#attributes' => ['data-js-occurrences' => ''],
      '#weight' => 50,
    ];

    // Set the widget state so it can be read in massageFormValues().
    $widget_state['occurrence']['display'] = $form_display;
    $widget_state['new_occurrences'] = [];

    static::setWidgetState($parents, $field_name, $form_state, $widget_state);

    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function massageFormValues(array $values, array $form, FormStateInterface $form_state) {
    $field_name = $this->fieldDefinition->getName();
    $widget_state = static::getWidgetState($form['#parents'], $field_name, $form_state);
    if (!empty($values['payload'])) {
      $payload = json_decode($values['payload']);
      $element = NestedArray::getValue($form_state->getCompleteForm(), $widget_state['array_parents']);
      $display = $widget_state['occurrence']['display'];
      // Adding occurrences.
      if ($payload->opcode == 'add' && empty($widget_state['new_occurrences'])) {
        foreach ($payload->occurrences as $occurrence) {
          $entity = $this->entityTypeManager->getStorage('occurrence')->create([]);
          $display->extractFormValues($entity, $element['subform'], $form_state);
          $entity->set('date', $occurrence);
          $entity->save();
          $widget_state['new_occurrences'][] = ['target_id' => $entity->id()];
        }
      }
      // Editing occurrences.
      if ($payload->opcode == 'edit') {
        $entities = $this->entityTypeManager->getStorage('occurrence')->loadMultiple($payload->occurrences);
        foreach ($entities as $entity) {
          $original = clone $entity;
          $display->extractFormValues($entity, $element['subform'], $form_state);
          // If editing multiple the date wont change. But the field will be empty,
          // this needs adding back.
          if (!$values['subform']['date'][0]['value']) {
            $entity->set('date', $original->get('date')->value);
          }
          $entity->save();
        }
      }
      // Deleting occurrences.
      if ($payload->opcode == 'delete') {
        $entities = $this->entityTypeManager->getStorage('occurrence')->loadMultiple($payload->occurrences);
        foreach ($entities as $entity) {
          $id = $entity->id();
          foreach ($values['target_ids'] as $key => $value) {
            if ($value['target_id'] == $id) {
              unset($values['target_ids'][$key]);
            }
          }
          $entity->delete();
        }
      }

      static::setWidgetState($form['#parents'], $field_name, $form_state, $widget_state);
    }

    return array_merge($values['target_ids'], $widget_state['new_occurrences']);
  }

  /**
   * Gets the form display for the given entity.
   *
   * @param \Drupal\Core\Entity\ContentEntityInterface $entity
   *   The entity.
   * @param string $form_mode
   *   The form mode.
   *
   * @return \Drupal\Core\Entity\Display\EntityFormDisplayInterface
   *   The form display.
   */
  private function getFormDisplay(ContentEntityInterface $entity, $form_mode) {
    return EntityFormDisplay::collectRenderDisplay($entity, $form_mode);
  }

  /**
   * Unset required fields.
   *
   * We only want to validate if we are adding or editing occurrences. Otherwise
   * when saving the node validation will fail on the required fields. This also
   * happens when deleting.
   *
   * Validation will be handled client side and in the widget.
   *
   * @todo - is there a better way to do this.
   *
   * @param array $element
   *   The field widget element.
   * @param string $fieldName
   *   The field name to process.
   */
  private function unsetRequiredFields(array &$element, string $fieldName) {
    if ($element['subform'][$fieldName]['widget']['#required']) {
      unset($element['subform'][$fieldName]['widget']['#required']);
      // Add to drupalSettings so vue app can validate.
      $element['#attached']['drupalSettings']['occurrence']['requiredFields'][] = $fieldName;
      // If its a multi value field we need to remove required from all deltas.
      if (isset($element['subform'][$fieldName]['widget']['#max_delta'])) {
        for ($x = 0; $x <= $element['subform'][$fieldName]['widget']['#max_delta']; $x++) {
          if (isset($element['subform'][$fieldName]['widget'][$x]['value'])) {
            unset($element['subform'][$fieldName]['widget'][$x]['value']['#required']);
            // Make it easier to target this field with Vue.
            $element['subform'][$fieldName]['widget'][$x]['value']['#attributes']['data-js-occurrence-field'] = $fieldName;
          }
          if (isset($element['subform'][$fieldName]['widget'][$x]['target_id'])) {
            unset($element['subform'][$fieldName]['widget'][$x]['target_id']['#required']);
            // Make it easier to target this field with Vue.
            $element['subform'][$fieldName]['widget'][$x]['target_id']['#attributes']['data-js-occurrence-field'] = $fieldName;
          }
        }
      }
      else {
        // Make it easier to target this field with Vue.
        $element['subform'][$fieldName]['widget']['#attributes']['data-js-occurrence-field'] = $fieldName;
      }
    }
  }
}
