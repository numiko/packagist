<?php

namespace Drupal\occurrence\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface for defining Occurrence entities.
 *
 * @ingroup occurrence
 */
interface OccurrenceInterface extends ContentEntityInterface, EntityChangedInterface, EntityOwnerInterface {

  /**
   * Gets the Occurrence creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Occurrence.
   */
  public function getCreatedTime();

  /**
   * Sets the Occurrence creation timestamp.
   *
   * @param int $timestamp
   *   The Occurrence creation timestamp.
   *
   * @return \Drupal\occurrence\Entity\OccurrenceInterface
   *   The called Occurrence entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Returns the Occurrence published status indicator.
   *
   * Unpublished Occurrence are only visible to restricted users.
   *
   * @return bool
   *   TRUE if the Occurrence is published.
   */
  public function isPublished();

  /**
   * Sets the published status of a Occurrence.
   *
   * @param bool $published
   *   TRUE to set this Occurrence to published, FALSE to set it to unpublished.
   *
   * @return \Drupal\occurrence\Entity\OccurrenceInterface
   *   The called Occurrence entity.
   */
  public function setPublished($published);

  /**
   * Get the date.
   *
   * @return \Drupal\Core\Datetime\DrupalDateTime
   *   The timestamp.
   */
  public function getDate();

  /**
   * Get the start time.
   *
   * @return string
   *   The timestamp.
   */
  public function getStartTime();

  /**
   * Get the end time.
   *
   * @return int
   *   The timestamp.
   */
  public function getEndTime();

}
