<template>
  <span class="c-occurrence__header">Changes confirmed</span>
  <span>Please note: these will not be saved until you save the event.</span>
</template>
