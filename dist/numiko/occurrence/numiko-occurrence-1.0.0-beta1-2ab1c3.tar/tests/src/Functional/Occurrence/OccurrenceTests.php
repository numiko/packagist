<?php

namespace Drupal\Tests\occurrence\Functional\Content;

use Drupal\integration_tests\IntegrationTestBase;
use Drupal\node\Entity\Node;
use Symfony\Component\HttpFoundation\Response;

/**
 * Tests for occurrences.
 *
 * @group occurrence_tests
 */
class OccurrenceTests extends IntegrationTestBase {

  /**
   * Test adding, editing and deleting occurrences though the payload field.
   */
  public function testOccurrencePayload() {

    $eventNode = $this->createNode(['type' => 'event']);

    $this->createUserWithPersonaAndLogin(['editor']);

    $this->visitCheckCode('/node/' . $eventNode->id() . '/edit', Response::HTTP_OK);

    $occurrence_payload = ['opcode' => 'add',
      'occurrences' => [
        '2023-01-01T00:00:00+00:00',
      ],
    ];

    $formValues = [
      'field_occurrences[subform][start_time][0][value]' => '10:00',
      'field_occurrences[subform][end_time][0][value]' => '14:00',
      'field_occurrences[payload]' => json_encode($occurrence_payload),
    ];

    $this->submitForm($formValues, t('Save'));

    // Need to reload the node.
    $eventNode = Node::load($eventNode->id());
    $occurrences = $eventNode->get('field_occurrences')->referencedEntities();
    $this->assertCount(1, $occurrences);
    foreach ($occurrences as $occurrence) {
      $this->assertEquals('2023-01-01', $occurrence->getDate()->format('Y-m-d'));
      $this->assertEquals('36000', $occurrence->getStartTime());
      $this->assertEquals('50400', $occurrence->getEndTime());
    }

    // Add more occurrences.
    $occurrence_payload = ['opcode' => 'add',
      'occurrences' => [
        '2023-01-02T00:00:00+00:00',
        '2023-01-03T00:00:00+00:00',
        '2023-01-04T00:00:00+00:00',
        '2023-01-05T00:00:00+00:00',
      ],
    ];

    $formValues = [
      'field_occurrences[subform][start_time][0][value]' => '10:00',
      'field_occurrences[subform][end_time][0][value]' => '14:00',
      'field_occurrences[payload]' => json_encode($occurrence_payload),
    ];

    $this->visitCheckCode('/node/' . $eventNode->id() . '/edit', Response::HTTP_OK);

    $this->submitForm($formValues, t('Save'));

    // Need a cache clear when reloading the node.
    $this->clearCache();
    $eventNode = Node::load($eventNode->id());
    $occurrences = $eventNode->get('field_occurrences')->referencedEntities();
    $this->assertCount(5, $occurrences);

    $occurrenceIds = [];
    foreach ($occurrences as $occurrence) {
      $occurrenceIds[] = $occurrence->id();
    }

    // Change the time on all occurrences.
    $occurrence_payload = ['opcode' => 'edit',
      'occurrences' => $occurrenceIds,
    ];

    $this->visitCheckCode('/node/' . $eventNode->id() . '/edit', Response::HTTP_OK);
    $formValues = [
      'field_occurrences[subform][start_time][0][value]' => '15:00',
      'field_occurrences[subform][end_time][0][value]' => '17:00',
      'field_occurrences[payload]' => json_encode($occurrence_payload),
    ];

    $this->submitForm($formValues, t('Save'));

    // Need a cache clear when reloading the node.
    $this->clearCache();
    $eventNode = Node::load($eventNode->id());
    $occurrences = $eventNode->get('field_occurrences')->referencedEntities();
    foreach ($occurrences as $occurrence) {
      $this->assertEquals('54000', $occurrence->getStartTime());
      $this->assertEquals('61200', $occurrence->getEndTime());
    }

    // Delete the occurrences
    $this->visitCheckCode('/node/' . $eventNode->id() . '/edit', Response::HTTP_OK);
    // Change the time on all occurrences.
    $occurrence_payload = ['opcode' => 'delete',
      'occurrences' => $occurrenceIds,
    ];
    $formValues = [
      'field_occurrences[payload]' => json_encode($occurrence_payload),
    ];
    $this->submitForm($formValues, t('Save'));

    // Need a cache clear when reloading the node.
    $this->clearCache();
    $eventNode = Node::load($eventNode->id());
    $occurrences = $eventNode->get('field_occurrences')->referencedEntities();
    // Should be 0 occurrences for this node.
    $this->assertCount(0, $occurrences);
  }

}
