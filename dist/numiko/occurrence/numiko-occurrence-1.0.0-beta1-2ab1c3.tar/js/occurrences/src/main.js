import { createApp } from 'vue'
import App from './App.vue'

const appElements = document.querySelectorAll('[data-js-occurrences]');

appElements.forEach(appElement => {
  const occurrenceSettings = window.drupalSettings['occurrence'];
  if (occurrenceSettings) {
    const app = createApp(App, {occurrenceSettings});
    app.mount(appElement);
  }
});
