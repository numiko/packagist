<script setup>
const props = defineProps({
  id: {
    type: String,
    required: true
  },
  label: {
    type: String,
    required: true
  },
  modelValue: String
});

defineEmits(['update:modelValue'])
</script>

<template>
  <div class="form-item form-datetime-wrapper">
    <h4 class="form-item__label">{{ label }}</h4>
    <label :for="id" class="visually-hidden">{{ label }}</label>
    <input
      class="form-date form-element form-element--type-date"
      type="date"
      :value="modelValue"
      @input="$emit('update:modelValue', $event.target.value)"
    />
  </div>
</template>
