<script setup>
import { provide } from 'vue';
import OccurrenceContainer from './components/OccurrenceContainer.vue'

const props = defineProps({
  occurrenceSettings: {
    type: Object,
    required: true
  }
});

provide('occurrenceSettings', props.occurrenceSettings);
</script>

<template>
  <OccurrenceContainer />
</template>
