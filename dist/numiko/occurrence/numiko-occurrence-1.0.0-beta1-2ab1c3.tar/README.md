Provides an occurrence entity to store occurrences of events, and an VueJS application to make editing complex
occurrences much easier.

## Setup

* Enable this module
* Add a field named `field_occurrences` to a content type, type entity reference, type to reference - occurrence.
* Set this field to display on the form using the "Occurrence default" widget

The Vue App adds json to a payload field which the `OccurrenceDefaultWidget` reads to
create, edit and delete occurrences.

The Vue app add shows/hides the Drupal occurrence entity form. As the form is open by default when creating/editing a node
this causes issues if fields are required when saving the node. Any required fields are therefore unset in the OccurenceDefaultWidget.
The required fields are instead added to `drupalSettings` which the VueApp will read and will set them as required when
the drupal form becomes visible.

When editing a single occurrence the drupal form needs to populate the fields with exisiting data for that occurrence. This has
only been tested with basic field types. Date, time, text, select lists.
