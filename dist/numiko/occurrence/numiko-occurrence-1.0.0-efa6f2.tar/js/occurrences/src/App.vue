<script setup>
import { provide } from 'vue';
import OccurrenceContainer from './components/OccurrenceContainer.vue'

const props = defineProps({
  /**
   * Array of existing occurrence entities.
   * @typedef {Array} entities
   * Array containing the id of the required fields from the drupal occurrence form. 
   * @typedef {Array} requiredFields
   * Array containing the id of fields from the drupal occurrence form. 
   * @typedef {Array} fields
   */
  occurrenceSettings: {
    type: Object,
    required: true
  }
});

provide('occurrenceSettings', props.occurrenceSettings);
</script>

<template>
  <OccurrenceContainer />
</template>
