<?php

namespace Drupal\occurrence;

use Closure;
use Drupal\occurrence\Entity\Occurrence;

/**
 * Class OccurrenceSorter.
 *
 * @package Drupal\occurrence
 */
class OccurrenceSorter {

  /**
   * Sort occurrences by date, earliest first
   *
   * @param array $occurrences
   *   Array of Occurrence objects
   *
   * @return array mixed
   *   The sorted occurrences.
   */
  public function sortByDate(array $occurrences) {
    usort($occurrences, Closure::fromCallable([$this, 'sortOccurrences']));
    return $occurrences;
  }

  /**
   * @param \Drupal\occurrence\Entity\Occurrence $a
   * @param \Drupal\occurrence\Entity\Occurrence $b
   *
   * @return int
   *   An integer less than, equal to, or greater than zero if the first argument is
   *   considered to be respectively less than, equal to, or greater than the second.
   */
  private function sortOccurrences(Occurrence $a, Occurrence $b) {
    if ($a->get('date')->value == $b->get('date')->value) {
      return 0;
    }
    else {
      return ($a->get('date')->value < $b->get('date')->date) ? -1 : 1;
    }
  }

}
