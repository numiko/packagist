<?php

namespace Drupal\occurrence\Plugin\Field\FieldFormatter;

use Drupal\Core\Datetime\DateFormatterInterface;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\Plugin\Field\FieldFormatter\EntityReferenceFormatterBase;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\occurrence\OccurrenceSorter;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Show first and last occurrences
 *
 * @FieldFormatter(
 *   id = "occurrence_min_max",
 *   label = @Translation("Occurrence first and last"),
 *   field_types = {
 *     "entity_reference",
 *     "occurrence_item"
 *   }
 * )
 */
class OccurrenceMinMaxFormatter extends EntityReferenceFormatterBase {

  /**
   * The date formatter service.
   *
   * @var \Drupal\Core\Datetime\DateFormatterInterface
   */
  protected $dateFormatter;

  /**
   * The date format entity storage.
   *
   * @var \Drupal\Core\Entity\EntityStorageInterface
   */
  protected $dateFormatStorage;

  /**
   * The occurrence sorter.
   *
   * @var \Drupal\occurrence\OccurrenceSorter
   */
  protected $occurrenceSorter;

  /**
   * Constructs an OccurrenceMinMaxFormatter object.
   *
   * {@inheritdoc}
   *
   * @param \Drupal\Core\Datetime\DateFormatterInterface $date_formatter
   *   The date formatter service.
   * @param \Drupal\Core\Entity\EntityStorageInterface $date_format_storage
   *   The date format entity storage.
   */
  public function __construct($plugin_id, $plugin_definition, FieldDefinitionInterface $field_definition, array $settings, $label, $view_mode, array $third_party_settings, DateFormatterInterface $date_formatter, EntityStorageInterface $date_format_storage, OccurrenceSorter $occurence_sorter) {
    parent::__construct($plugin_id, $plugin_definition, $field_definition, $settings, $label, $view_mode, $third_party_settings);

    $this->dateFormatter = $date_formatter;
    $this->dateFormatStorage = $date_format_storage;
    $this->occurrenceSorter = $occurence_sorter;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $plugin_id,
      $plugin_definition,
      $configuration['field_definition'],
      $configuration['settings'],
      $configuration['label'],
      $configuration['view_mode'],
      $configuration['third_party_settings'],
      $container->get('date.formatter'),
      $container->get('entity_type.manager')->getStorage('date_format'),
      $container->get('occurrence.sorter'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings(): array {
    $settings = parent::defaultSettings();
    $settings['separator'] = ' - ';
    $settings['format_type'] = 'medium';

    return $settings;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state): array {
    $element = parent::settingsForm($form, $form_state);
    $element['separator'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Separator'),
      '#description' => $this->t('Specify a separator which will be placed in between the dates.'),
      '#default_value' => $this->getSetting('separator'),
    ];

    $time = new DrupalDateTime();
    $format_types = $this->dateFormatStorage->loadMultiple();
    $options = [];
    foreach ($format_types as $type => $type_info) {
      $format = $this->dateFormatter->format($time->getTimestamp(), $type);
      $options[$type] = $type_info->label() . ' (' . $format . ')';
    }

    $element['format_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Date format'),
      '#description' => $this->t("Choose a format for displaying the date. Be sure to set a format appropriate for the field, i.e. omitting time for a field that only has a date."),
      '#options' => $options,
      '#default_value' => $this->getSetting('format_type'),
    ];

    return $element;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary(): array {
    $summary = parent::settingsSummary();
    $separator = $this->getSetting('separator');
    $date = new DrupalDateTime();

    $summary[] = $this->t('Separator: @separator', [
      '@separator' => empty($separator) ? $this->t('None') : $separator,
    ]);
    $summary[] = $this->t('Format: @display', ['@display' => $this->formatDate($date)]);

    return $summary;
  }

  /**
   * Show first and last occurrences
   *
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {

    $output = '';

    if ($items) {
      $occurrences = $this->getEntitiesToView($items, $langcode);
      if (!empty($occurrences)) {
        $occurrences = \Drupal::service('occurrence.sorter')->sortByDate($occurrences);

        $output =
          $this->formatDate(
            reset($occurrences)->get('date')->value
          )
          . ' - ' .
          $this->formatDate(
            end($occurrences)->get('date')->value
          );
      }
    }

    return [
      '#type' => 'markup',
      '#markup' => $output
    ];
  }

  /**
   * Format a date, taking account of timezones (stored as UTC).
   *
   * @param $dateTimeStr
   *
   * @return mixed
   */
  private function formatDate($dateTimeStr) {
    $format = $this->getSetting('format_type');
    $date = new DrupalDateTime(
      $dateTimeStr,
      'UTC'
    );
    return $this->dateFormatter->format(
      $date->format('U'),
      $format,
      '',
      date_default_timezone_get()
    );
  }

}
