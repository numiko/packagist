import { formatTime } from '../composables/useFormatDateTime.js';

/**
 * showDrupalForm
 *
 * Shows the drupal form.
 */
export function showDrupalForm(showDate) {
  document.querySelectorAll('[data-js-drupal-form]').forEach(function (element) {
    element.classList.remove('hidden');
  })

  const dateWrapper = document.getElementById('edit-field-occurrences-subform-date-wrapper');
  if (showDate) {
    dateWrapper.classList.remove('hidden');
  }
  else {
    dateWrapper.classList.add('hidden');
  }
}

/**
 * hideDrupalForm
 *
 * Hides the drupal form.
 */
export function hideDrupalForm() {
  document.querySelectorAll('[data-js-drupal-form]').forEach(function (element) {
    element.classList.add('hidden');
  });
}

/**
 * resetDrupalForm
 *
 * Clears the form values for the drupal form.
 */
export function resetDrupalForm() {
  document.querySelectorAll('[data-js-drupal-form]').forEach(function (element) {
    const inputs = document.getElementById(element.id).getElementsByTagName("input");
    const inputList = Array.prototype.slice.call(inputs);
    inputList.forEach(function (inputElement) {
      inputElement.value = '';
    });

    const selects = document.getElementById(element.id).getElementsByTagName("select");
    var selectList = Array.prototype.slice.call(selects);
    selectList.forEach(function (inputElement) {
      // Reset for selects.
      inputElement.selectedIndex = 0;
    })
  })
}

/**
 * setRequiredFields
 *
 * Adds a required attribute to input and class to the label to show asterix.
 */
export function setRequiredFields(requiredFields, skipDate) {
  requiredFields.forEach(function (input) {
    if (skipDate && input == 'date') {
      return;
    }
    const elements = document.querySelectorAll(`[data-js-occurrence-field="${input}"]`);
    elements.forEach(function (element) {
      if (element.id) {
        element.required = true;
        document.querySelector(`label[for='${element.id}']`).classList.add('form-required');
      }
    })
  })
}

/**
 * unsetRequiredFields
 *
 * Removes the required attribute from input and required class from the label.
 */
export function unsetRequiredFields(requiredFields) {
  requiredFields.forEach(function (input) {
    const elements = document.querySelectorAll(`[data-js-occurrence-field="${input}"]`);
    elements.forEach(function (element) {
      if (element.id) {
        element.required = false;
        document.querySelector(`label[for='${element.id}']`).classList.remove('form-required');
      }
    })
  })
}

/**
 * syncDrupalForm
 *
 * When editing a single occurrence prepopulate the drupal form values.
 *
 * @todo check different field types and multi selects.
 */
export function syncDrupalForm(selectedOccurrences, fields) {
  fields.forEach(function (field) {
    // Find the input.
    const inputs = document.querySelectorAll(`[data-js-occurrence-field="${field}"]`);
    inputs.forEach(function (input) {
      if (selectedOccurrences.value[0][field] && selectedOccurrences.value[0][field][0]) {
        if (selectedOccurrences.value[0][field][0]['value']) {
          input.value = selectedOccurrences.value[0][field][0]['value'];
          // Start and end time need to be formatted to hours:minutes from
          // a timestamp.
          if (field == 'start_time' || field == 'end_time') {
            input.value = formatTime(selectedOccurrences.value[0][field][0]['value']);
          }
        }
        else if (selectedOccurrences.value[0][field][0]['target_id']) {
          input.value = '"Entity (' + selectedOccurrences.value[0][field][0]['target_id'] + ')"';
        }
      }
    });
  });
}
