<script setup>
import {computed, ref} from 'vue'
import InputCheckbox from './InputCheckbox.vue';
import Pagination from './Pagination.vue';

import { formatTime, formatDate } from '../composables/useFormatDateTime.js';

const isSelectAll = ref(false);
const props = defineProps({
  occurrenceEntities: Array,
  selectedOccurrences: Array,
});

const emit = defineEmits(['setSelectedOccurrences', 'setStep'])

/**
 * Set items per page
 */
const itemsPerPage = 10;

/**
 * Set current page
 */
const currentPage = ref(1);

/**
 * Sort occurrences by date & time.
 */
const sortedOccurrences = computed({
  get() {
    const sortedOccurrences = props.occurrenceEntities;
    return sortedOccurrences.sort(function(a, b) {
      if (a.date[0].value === b.date[0].value) {
        return a.start_time[0].value - b.start_time[0].value
      }
      return new Date(a.date[0].value) - new Date(b.date[0].value)
    })
  },
});

/**
 * Paginated occurrences.
 */
const paginatedOccurrences = computed(() => paginate())

/**
 * paginate.
 *
 * Returns paginated list of occurrences.
 */
const paginate = () => {
  return sortedOccurrences.value.slice((currentPage.value - 1) * itemsPerPage, currentPage.value * itemsPerPage);
}

/**
 * The selected occurrences.
 */
 const selected = computed({
  get: () => props.selectedOccurrences,
  set: items => emit('setSelectedOccurrences', items)
})

/**
 * Set the selected occurrences.
 */
const setSelected = (occurence) => {
  selected.value = [occurence];
}

/**
 * Select all occurrences.
 */
const selectAll = () => {
  isSelectAll.value = !isSelectAll.value;
  selected.value = [];
  if(isSelectAll.value) {
    const selectedValues = [];
    paginatedOccurrences.value.forEach(function (occurrence) {
      selectedValues.push(occurrence);
    });

    selected.value = selectedValues;
  }
}

/**
 * Update select all checkbox when selected occurrences change.
 */
const updateSelectAll = () => {
  if(selected.value.length == paginatedOccurrences.value.length){
    isSelectAll.value = true;
  }
  else{
    isSelectAll.value = false;
  }
}

/**
 * setStep
 *
 * Pass the step back to the parent.
 */
const setStep = () => {
  emit('setStep', 'editSingle')
}

/**
 * changePage
 *
 * Changes the page when changed in pagination component.
 */
const changePage = (value) => {
  currentPage.value = value;
  isSelectAll.value = false
  selected.value = [];
}

</script>

<template>
  <table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tbody>
      <tr>
        <th scope="col">
          <input class="form-checkbox form-boolean form-boolean--type-checkbox" type="checkbox" @click='selectAll()' v-model="isSelectAll" />
        </th>
        <th scope="col">ID</th>
        <th scope="col">Date</th>
        <th scope="col">Start time</th>
        <th scope="col">End time</th>
        <th scope="col">Actions</th>
      </tr>
      <tr v-for="(occurrence, index) in paginatedOccurrences" :key="index">
        <td>
          <InputCheckbox
            :id="occurrence.id[0].value"
            :data="occurrence"
            :label="`Select ${occurrence.id[0].value}`"
            :label-class="'visually-hidden'"
            v-model="selected"
            @change='updateSelectAll()'
          />
        </td>
        <td>{{ occurrence.id[0].value }}</td>
        <td>{{ occurrence.date[0] ? formatDate(occurrence.date[0].value) : 'N/A' }}</td>
        <td>{{ occurrence.start_time[0] ? formatTime(occurrence.start_time[0].value) : 'N/A' }}</td>
        <td>{{ occurrence.end_time[0] ? formatTime(occurrence.end_time[0].value) : 'N/A' }}</td>
        <td><button :data="occurrence.id[0].value" class="button" type="button" @click="setSelected(occurrence), setStep()">Edit</button></td>
      </tr>
    </tbody>
  </table>
  <Pagination
      :results-count="occurrenceEntities.length"
      :current-page="currentPage"
      :pagination-size="Number(itemsPerPage)"
      @update-page="changePage"
    />
</template>
