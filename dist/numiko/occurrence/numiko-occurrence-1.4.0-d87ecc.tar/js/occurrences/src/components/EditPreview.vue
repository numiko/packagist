<script setup>
import { formatDate, formatTime } from '../composables/useFormatDateTime.js';

const props = defineProps({
  startTime: String,
  endTime: String,
  date: String,
  occurrences: Array,
})

</script>
<template>
  <span class="c-occurrence__header" v-text="`Update ${occurrences.length} occurrence(s).`" />
  <table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tbody>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Date</th>
        <th scope="col">Start time</th>
        <th scope="col">End time</th>
      </tr>
      <tr v-for="(occurrence, index) in occurrences" :key="index">
        <td>{{ occurrence.id[0].value }}</td>
        <td>{{ date ? formatDate(date) : formatDate(occurrence.date[0].value) }}</td>
        <td>{{ startTime ? startTime : formatTime(occurrence.start_time[0].value) }}</td>
        <td>{{ endTime ? endTime : formatTime(occurrence.end_time[0].value) }}</td>
      </tr>
    </tbody>
  </table>
</template>
