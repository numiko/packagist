<script setup>
import { ref, inject, watch } from 'vue';

import List from './List.vue';
import Calendar from './Calendar.vue';
import AddPreview from './AddPreview.vue';
import EditPreview from './EditPreview.vue';
import DeletePreview from './DeletePreview.vue';
import Complete from './Complete.vue';

import { eachDayOfInterval, getDay } from 'date-fns'

import {
  showDrupalForm,
  hideDrupalForm,
  resetDrupalForm,
  setRequiredFields,
  unsetRequiredFields,
  syncDrupalForm,
} from '../composables/useDrupalForm.js';

import {formatShortDate} from '../composables/useFormatDateTime.js';

const occurrenceSettings = inject('occurrenceSettings');

const step = ref('list');
const calendarDates = ref([]);
const startDate = ref();
const endDate = ref();
const weekDays = ref([]);
const date = ref();
const startTime = ref();
const endTime = ref();
const selectedOccurrences = ref([]);

/**
 * setDates
 *
 * @param {Array} dates
 *
 * Called when calendar dates are updated
 */
const setDates = (dates) => {
  calendarDates.value = dates
}

/**
 * setStartDate
 *
 * @param {String} date
 *
 * Called when start date is updated
 */
const setStartDate = (date) => {
  startDate.value = date
}

/**
 * setEndDate
 *
 * @param {String} date
 *
 * Called when end date is updated
 */
const setEndDate = (date) => {
  endDate.value = date
}

/**
 * setWeekDays
 *
 * @param {Array} value
 *
 * Called when weekdays is updated
 */
const setWeekDays = (days) => {
  weekDays.value = days
}

/**
 * setSelectedOccurrences
 *
 * @param {Array} occurrences
 *
 * Sets the selected occurrences when editing/deleting.
 */
const setSelectedOccurrences = (occurrences) => {
  selectedOccurrences.value = occurrences
}

/**
 * getSelectedOccurenceIds
 *
 * Returns an array of ids from the selected occurrences.
 */
const getSelectedOccurenceIds = () => {
  let ids = [];
  selectedOccurrences.value.forEach(function (occurence) {
    ids.push(occurence.id[0].value);
  });

  return ids;
}

/**
 * setAddPayload
 *
 * Sets the payload field value when adding.
 */
const setAddPayload = () => {
  const payload = {
    opcode: 'add',
    occurrences: [],
  };

  calendarDates.value.forEach(function (date) {
    payload.occurrences.push(formatShortDate(date));
  });

  document.querySelector('[name="field_occurrences[payload]"]').value = JSON.stringify(payload);
}

/**
 * setDeletePayload
 *
 * Sets the payload field value when deleting.
 */
const setDeletePayload = () => {
  const payload = {
    opcode: 'delete',
    occurrences: getSelectedOccurenceIds(),
  };
  document.querySelector('[name="field_occurrences[payload]"]').value = JSON.stringify(payload);
}

/**
 * setEditPayload
 *
 * Sets the payload field value when editing.
 */
const setEditPayload = () => {
  const payload = {
    opcode: 'edit',
    occurrences: getSelectedOccurenceIds(),
    fields: [],
  };
  document.querySelector('[name="field_occurrences[payload]"]').value = JSON.stringify(payload);
}

/**
 * resetPayload
 *
 * Resets the payload field.
 */
const resetPayload = () => {
  document.querySelector('[name="field_occurrences[payload]"]').value = '';
}

/**
 * setStep
 *
 * Sets the active step.
 */
const setStep = ((nextStep) => {
  step.value = nextStep;
})

/**
 * resetRefs
 *
 * Reset refs when changing steps.
 */
const resetRefs = () => {
  date.value = '';
  startTime.value = '';
  endTime.value = '';
}

/**
 * validateForm
 *
 * Validates the drupal form.
 */
const validateForm = (nextStep) => {
  const form = document.forms[0];
  if (form.checkValidity()) {
    setStep(nextStep)
  }
  else {
    form.reportValidity();
  }
}


/**
 * Sorts the dates when the calendarDates changes.
 */
watch(calendarDates, () => {
  calendarDates.value.sort(function(a,b){
    return new Date(a) - new Date(b)
  })
})

/**
 * When the step changes show/hide drupal form.
 *
 * Sets required/unrequired fields and syncs when
 * editing.
 */
watch(step, () => {
  if (step.value == 'calendar') {
    resetRefs();
    resetPayload();
    showDrupalForm();
    resetDrupalForm();
    setRequiredFields(occurrenceSettings.requiredFields, true);
  }
  else {
    hideDrupalForm();
    unsetRequiredFields(occurrenceSettings.requiredFields);
  }

  if (step.value == 'editMultiple') {
    resetRefs();
    resetPayload();
    resetDrupalForm();
    showDrupalForm();
    resetDrupalForm();
    setRequiredFields(occurrenceSettings.requiredFields);
  }

  if (step.value == 'editSingle') {
    resetRefs();
    resetPayload();
    showDrupalForm(true);
    resetDrupalForm();
    setRequiredFields(occurrenceSettings.requiredFields);
    syncDrupalForm(selectedOccurrences, occurrenceSettings.fields);
  }

  if (step.value == 'addPreview' || step.value == 'editPreviewSingle' || step.value == 'editPreviewMultiple') {
    // Set the start and end time.
    startTime.value = document.querySelector('[name="field_occurrences[subform][start_time][0][value]"]').value;
    endTime.value = document.querySelector('[name="field_occurrences[subform][end_time][0][value]"]').value;
    date.value = document.querySelector('[name="field_occurrences[subform][date][0][value][date]"]').value;
  }
}, { immediate: true });

/**
 * Sets the calendarDates between two dates.
 *
 * When selecting weekdays, if start date and end date is also set
 * we find all weekdays selected between those dates and push to
 * calendarDates.
 */
watch(weekDays, () => {
  if (startDate.value && endDate.value && weekDays.value.length) {
    // Reset the dates when selecting weekdays.
    calendarDates.value = [];
    const datesBetween = eachDayOfInterval({
      start: new Date(startDate.value),
      end: new Date(endDate.value)
    })

    weekDays.value.forEach(day => {
      datesBetween.forEach(date => {
        if (getDay(date) == day.id) {
          calendarDates.value.push(date)
        }
      })
    });
  }

  // Reset the dates if no week days are selected.
  if (!weekDays.value.length) {
    calendarDates.value = [];
  }
});

</script>

<template>
  <!-- Calendar step. -->
  <div v-if="step == 'calendar'">
    <Calendar
      :calendar-dates="calendarDates"
      @set-dates="setDates"
      :start-date="startDate"
      @set-start-date="setStartDate"
      :end-date="endDate"
      @set-end-date="setEndDate"
      :week-days="weekDays"
      @set-week-days="setWeekDays"
    />
    <p>Once you have set up the dates and times above, you must preview the individual occurrences by clicking the preview button below, and then click to confirm those occurrences. The occurrences will then be part of the edits you are making to this event page, and will be saved only when you save or publish this event.</p>
    <p>Past occurrences will be automatically deleted.</p>
    <button class="button" type="button" @click="setStep('list')">Back</button>
    <button
      class="button"
      :disabled="calendarDates.length < 1"
      type="button"
      @click="validateForm('addPreview')"
      v-text="`Preview ${calendarDates.length} occurrence(s)`"
    />
  </div>
  <!-- Add preview step. -->
  <div v-else-if="step == 'addPreview'">
    <AddPreview
      :start-time="startTime"
      :end-time="endTime"
      :calendar-dates="calendarDates"
    />
    <button class="button" type="button" @click="setStep('calendar')">Back</button>
    <button class="button" type="button" @click="setStep('complete'), setAddPayload()">Confirm</button>
  </div>
  <!-- Edit multiple step. -->
  <div v-else-if="step == 'editMultiple'">
    <button class="button" type="button" @click="setStep('list')">Back</button>
    <button class="button" type="button button--danger" @click="setStep('editPreviewMultiple')">Preview changes</button>
  </div>
  <!-- Edit single step. -->
  <div v-else-if="step == 'editSingle'">
    <button class="button" type="button" @click="setStep('list')">Back</button>
    <button class="button" type="button button--danger" @click="validateForm('editPreviewSingle')">Preview changes</button>
  </div>
  <!-- Edit preview multiple step. -->
  <div v-else-if="step == 'editPreviewMultiple'">
    <EditPreview
      :start-time="startTime"
      :end-time="endTime"
      :date="date"
      :occurrences="selectedOccurrences"
    />
    <button class="button" type="button" @click="setStep('editMultiple')">Back</button>
    <button class="button" type="button" @click="setStep('complete'), setEditPayload()">Confirm</button>
  </div>
  <!-- Edit preview single step. -->
  <div v-else-if="step == 'editPreviewSingle'">
    <EditPreview
      :start-time="startTime"
      :end-time="endTime"
      :date="date"
      :occurrences="selectedOccurrences"
    />
    <button class="button" type="button" @click="setStep('editSingle')">Back</button>
    <button class="button" type="button" @click="setStep('complete'), setEditPayload()">Confirm</button>
  </div>
  <!-- Delete preview step. -->
  <div v-else-if="step == 'deletePreview'">
    <DeletePreview :selected-occurrences="selectedOccurrences" />
    <button class="button" type="button" @click="setStep('list')">Back</button>
    <button class="button" type="button button--danger" @click="setStep('complete'), setDeletePayload()">Confirm and delete</button>
  </div>
  <!-- Complete step. -->
  <div v-else-if="step == 'complete'">
    <Complete />
  </div>
  <!-- List step. -->
  <div v-else>
    <button class="button" type="button" @click="setStep('calendar')">Add occurence(s)</button>
    <template v-if="occurrenceSettings.entities.length">
      <List
        :occurrence-entities="occurrenceSettings.entities"
        :selected-occurrences="selectedOccurrences"
        @set-selected-occurrences="setSelectedOccurrences"
        @set-step="setStep"
      />
      <button
        class="button"
        type="button"
        @click="setStep('editMultiple')"
        :disabled="selectedOccurrences.length < 1"
        v-text="`Edit ${selectedOccurrences.length} selected occurrence(s)`"
      />
      <button
        class="button button--danger"
        type="button"
        @click="setStep('deletePreview')"
        :disabled="selectedOccurrences.length < 1"
        v-text="`Delete ${selectedOccurrences.length} selected occurrence(s)`"
      />
    </template>
  </div>
</template>

<style>
.c-occurrence__header {
  display: block;
  font-size: 1rem;
  margin-bottom: 1rem;
}
</style>
