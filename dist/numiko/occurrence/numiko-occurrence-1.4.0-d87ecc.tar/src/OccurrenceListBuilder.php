<?php

namespace Drupal\occurrence;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityListBuilder;
use Drupal\Core\Link;
use Drupal\time_field\Time;

/**
 * Defines a class to build a listing of Occurrence entities.
 *
 * @ingroup occurrence
 */
class OccurrenceListBuilder extends EntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['id'] = $this->t('Occurrence ID');
    $header['date'] = $this->t('Date');
    $header['start_time'] = $this->t('Start time');
    $header['end_time'] = $this->t('End time');
    $header['updated'] = $this->t('Updated');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /* @var $entity \Drupal\occurrence\Entity\Occurrence */
    $row['id'] = $entity->id();
    $row['date'] = Link::createFromRoute(
      \Drupal::service('date.formatter')->format($entity->getDate()->getTimestamp(), 'long'),
      'entity.occurrence.edit_form',
      ['occurrence' => $entity->id()]
    );
    $row['start_time'] = Time::createFromTimestamp($entity->getStartTime())->format('H:i');
    $row['end_time'] = Time::createFromTimestamp($entity->getEndTime())->format('H:i');
    $row['updated'] = \Drupal::service('date.formatter')->format($entity->getChangedTime(), 'short');
    return $row + parent::buildRow($entity);
  }

}
