<script setup>
import { computed, ref } from 'vue';

const props = defineProps({
  resultsCount: {
    type: Number,
    default: () => 0
  },
  currentPage: {
    type: Number,
    required: true
  },
  paginationSize: {
    type: Number,
    required: true
  }
});

const emit = defineEmits(['update:pagination']);

const itemsPerPage = ref(props.paginationSize);
const offset = ref(10);
const firstPage = ref(1);
const showNextAndPrev = ref(true);

/**
 * maxPageIndex
 *
 * Used to calculate the number of pages based on number of results
 *
 * @returns {Number}
 */
const maxPageIndex = computed(() => Math.ceil(props.resultsCount / itemsPerPage.value));

/**
 * paginationItems
 *
 * Used to store range of pagination links based around currently selected page
 *
 * @returns {Array}
 */
const paginationItems = computed(() => {

  const pages = [];

  /**
   * from
   *
   * @type {number} to count the start from
   */
  let from = props.currentPage - Math.floor(offset.value / 2);

  if (from < 1) {
    from = firstPage.value;
  }

  /**
   * to
   *
   * @type {number} to count up to
   */
  let to = from + offset.value - 1;

  if (to > maxPageIndex.value) {
    to = maxPageIndex.value;
  }

  /**
   * overflow
   *
   * @type {number} number of items overflowing the last page
   */
  const overflow = (to - maxPageIndex.value);

  /**
   * Set from value lower in instances where the to value overflows the last page
   */
  if (overflow > 0) {
    from = props.currentPage - (Math.floor(offset.value / 2) + overflow);
  }

  /**
   * Build array of results. [ first, [...range], last ]
   */
  for (let index = 1; index <= maxPageIndex.value; index += 1) {
    const isInRange = index >= from && index <= to;
    const isFirst = index === 1;
    const isLast = index === maxPageIndex.value;

    // Ensure items that aren't in range are skipped
    if (isInRange || isFirst || isLast) {
      pages.push(index);
    }
  }

  return pages;
});


/**
 * rangeWithBreaks
 *
 * @returns {Array} of pagination items, with breaks at the start and end when required
 */
const rangeWithBreaks = computed(() => {
  const items = [];
  // Add breaks to sections where required
  paginationItems.value.forEach((item, index, inputArray) => {
    const prevValue = inputArray[index - 1];

    if (prevValue) {
      if (item - prevValue === 2) {
        items.push(prevValue + 1);
      } else if (item - prevValue !== 1) {
        items.push('BREAK');
      }
    }

    items.push(item);
  });

  return items;
});


/**
 * prevPage
 *
 * @returns {Number}
 */
const prevPage = computed(() => props.currentPage - 1);

/**
 * nextPage
 *
 * @returns {Number}
 */
const nextPage = computed(() => props.currentPage + 1);

/**
 * disablePrev
 *
 * Determines whether button should be disabled
 *
 * @returns {Boolean}
 */
const disablePrev = computed(() => props.currentPage <= firstPage.value);

/**
 * disableNext
 *
 * Determines whether button should be disabled
 *
 * @returns {Boolean}
 */
const disableNext = computed(() => props.currentPage >= maxPageIndex.value);

/**
 * changePage
 *
 * Inform parent of page change so state can be updated
 *
 * @param {Number} pageNumber - Page number to change to
 */
const changePage = (pageNumber) => {
  emit('update-page', pageNumber);
};

</script>

<template>
  <div class="pager" v-if="paginationItems.length > 1">
    <ul class="pager__items">
      <li class="pager__item pager__item--action pager__item--previous" v-if="showNextAndPrev">
        <button
          type="button"
          :disabled="disablePrev"
          :aria-disabled="disablePrev"
          @click="changePage(prevPage)"
        >
          <span class="pager__link pager__link--action-link">
            <span class="pager__item-title pager__item-title--backwards">Previous</span>
          </span>
        </button>
      </li>

      <li
        v-for="(page, index) in rangeWithBreaks"
        :key="index"
        :aria-current="page === currentPage ? 'page' : null"
        :class="page == 'BREAK' ? 'pager__item--ellipsis' : 'pager_item'"
      >
        <button
          v-if="page !== 'BREAK'"
          type="button"
          @click="changePage(page)"
        >
          <span class="visually-hidden">Page</span>
          <span class="pager__link" :class="page === currentPage ? 'is-active' : ''">
            {{ page }}
          </span>
        </button>
        <span v-else>
          &hellip;
        </span>
      </li>

      <li class="pager__item pager__item--action pager__item--next" v-if="showNextAndPrev">
        <button
          type="button"
          :disabled="disableNext"
          :aria-disabled="disableNext"
          @click="changePage(nextPage)"
        >
          <span class="pager__link pager__link--action-link">
            <span class="pager__item-title pager__item-title--forward">Next</span>
          </span>
        </button>
      </li>
    </ul>
  </div>
</template>

<style scoped>
button {
  border: none;
  background: none;
}
</style>
