<script setup>
import { formatDate } from '../composables/useFormatDateTime.js';

const props = defineProps({
  startTime: String,
  endTime: String,
  calendarDates: Array,
})

</script>
<template>
  <span class="c-occurrence__header" v-text="`Create ${calendarDates.length} new occurrence(s).`" />
  <table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tbody>
      <tr>
        <th scope="col">Date</th>
        <th scope="col">Start time</th>
        <th scope="col">End time</th>
      </tr>
      <tr v-for="(date, index) in calendarDates" :key="index">
        <td>{{ formatDate(date) }}</td>
        <td>{{ startTime }}</td>
        <td>{{ endTime }}</td>
      </tr>
    </tbody>
  </table>
</template>
