<script setup>
import { computed } from 'vue';

import InputDate from './InputDate.vue';
import InputCheckbox from './InputCheckbox.vue';
import Datepicker from '@vuepic/vue-datepicker';
import '@vuepic/vue-datepicker/dist/main.css'

const props = defineProps({
  calendarDates: Array,
  startDate: String,
  endDate: String,
  weekDays: Array,
})

const emit = defineEmits(['setDates', 'setStartDate', 'setEndDate', 'setWeekDays'])

const dates = computed({
  get: () => props.calendarDates,
  set: items => emit('setDates', items)
})

const start = computed({
  get: () => props.startDate,
  set: value => emit('setStartDate', value)
})

const end = computed({
  get: () => props.endDate,
  set: value => emit('setEndDate', value)
})

const selectedDays = computed({
  get: () => props.weekDays,
  set: value => emit('setWeekDays', value)
})

const daysOfWeek = [
  {
      id: 1,
      name: 'Monday'
  },
  {
      id: 2,
      name: 'Tuesday'
  },
  {
      id: 3,
      name: 'Wednesday'
  },
  {
      id: 4,
      name: 'Thursday'
  },
  {
      id: 5,
      name: 'Friday'
  },
  {
      id: 6,
      name: 'Saturday'
  },
  {
      id: 7,
      name: 'Sunday'
  },
];

</script>

<template>
  <fieldset class="fieldset">
    <div class="fieldset__wrapper">
      <span class="c-occurrence__header">Select the days on which your event repeats (optional).</span>
      <InputDate label="Start date" id="start-date" v-model="start"/>
      <InputDate label="End date" id="end-date" v-model="end" />
      <div class="form-item">
        <h4 class="form-item__label">Repeat on these days</h4>
        <div class="c-picker__days form-checkboxes">
          <InputCheckbox v-for="day in daysOfWeek" :id="day.id" :key="day.id" :label="day.name" :data="day" v-model="selectedDays" />
        </div>
      </div>
    </div>
  </fieldset>
  <fieldset class="fieldset">
    <div class="fieldset__wrapper">
      <span class="c-occurrence__header">Click on individual dates on the calendar to include or remove occurrences.</span>
      <Datepicker
        inline
        multi-dates
        auto-apply
        :enable-time-picker="false"
        v-model="dates"
      />
    </div>
  </fieldset>
</template>

<style>
.c-picker__days {
  display: flex;
  justify-content: space-between;
}
.dp__main {
  justify-content: center;
}
</style>
