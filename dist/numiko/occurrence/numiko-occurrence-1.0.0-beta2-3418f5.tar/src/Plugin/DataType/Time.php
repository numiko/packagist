<?php

namespace Drupal\occurrence\Plugin\DataType;

use Drupal\Core\TypedData\Plugin\DataType\IntegerData;

/**
 * The Time data type.
 *
 * Adds a data type for time fields so they can be used as entity fields.
 *
 * @DataType(
 *  id = "time",
 *  label = @Translation("Time")
 * )
 */
class Time extends IntegerData {

}
