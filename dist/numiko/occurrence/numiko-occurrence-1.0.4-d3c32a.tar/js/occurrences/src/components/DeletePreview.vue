<script setup>
import { formatTime, formatDate } from '../composables/useFormatDateTime.js';

const props = defineProps({
  selectedOccurrences: Array,
});

</script>
<template>
  <span class="c-occurrence__header" v-text="`Delete ${selectedOccurrences.length} occurrence(s).`" />
  <table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tbody>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Date</th>
        <th scope="col">Start time</th>
        <th scope="col">End time</th>
      </tr>
      <tr v-for="(occurrence, index) in selectedOccurrences" :key="index">
        <td>{{ occurrence.id[0].value }}</td>
        <td>{{ occurrence.date[0] ? formatDate(occurrence.date[0].value) : 'N/A' }}</td>
        <td>{{ occurrence.start_time[0] ? formatTime(occurrence.start_time[0].value) : 'N/A' }}</td>
        <td>{{ occurrence.end_time[0] ? formatTime(occurrence.end_time[0].value) : 'N/A' }}</td>
      </tr>
    </tbody>
  </table>
</template>
