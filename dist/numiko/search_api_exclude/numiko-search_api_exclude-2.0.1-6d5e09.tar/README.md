# Search API Exclude

This module comprises the result of a Drupal contributor's [patch](https://www.drupal.org/files/issues/search_api_exclude--drupal-8.patch) to [port](https://www.drupal.org/node/2869359) [`search_api_exclude`](https://www.drupal.org/project/search_api_exclude) to Drupal 8.

* Install the module
* Enable "Search API exclude" on each content type's edit form
* Enable the "Node exclude" processor on the search index
* Re-index