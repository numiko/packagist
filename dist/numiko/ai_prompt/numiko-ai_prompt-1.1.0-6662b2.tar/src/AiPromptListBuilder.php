<?php

declare(strict_types=1);

namespace Drupal\ai_prompt;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;

/**
 * Provides a listing of ai prompts.
 */
final class AiPromptListBuilder extends ConfigEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader(): array {
    $header['label'] = $this->t('Label');
    $header['id'] = $this->t('Machine name');
    $header['character_limit'] = $this->t('Character Limit');
    $header['status'] = $this->t('Status');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity): array {
    /** @var \Drupal\ai_prompt\AiPromptInterface $entity */
    $row['label'] = $entity->label();
    $row['id'] = $entity->id();
    $character_limit = $entity->get('character_limit');
    $row['character_limit'] = $character_limit ? $this->t('@limit characters', ['@limit' => $character_limit]) : $this->t('Unlimited');
    $row['status'] = $entity->status() ? $this->t('Enabled') : $this->t('Disabled');
    return $row + parent::buildRow($entity);
  }

}
