<?php

declare(strict_types=1);

namespace Drupal\ai_prompt\Entity;

use Drupal\ai_prompt\AiPromptInterface;
use Drupal\Core\Config\Entity\ConfigEntityBase;

/**
 * Defines the ai prompt entity type.
 *
 * @ConfigEntityType(
 *   id = "ai_prompt",
 *   label = @Translation("AI Prompt"),
 *   label_collection = @Translation("AI Prompts"),
 *   label_singular = @Translation("ai prompt"),
 *   label_plural = @Translation("ai prompts"),
 *   label_count = @PluralTranslation(
 *     singular = "@count ai prompt",
 *     plural = "@count ai prompts",
 *   ),
 *   handlers = {
 *     "list_builder" = "Drupal\ai_prompt\AiPromptListBuilder",
 *     "form" = {
 *       "add" = "Drupal\ai_prompt\Form\AiPromptForm",
 *       "edit" = "Drupal\ai_prompt\Form\AiPromptForm",
 *       "delete" = "Drupal\Core\Entity\EntityDeleteForm",
 *     },
 *   },
 *   config_prefix = "ai_prompt",
 *   admin_permission = "administer ai_prompt",
 *   links = {
 *     "collection" = "/admin/structure/ai-prompt",
 *     "add-form" = "/admin/structure/ai-prompt/add",
 *     "edit-form" = "/admin/structure/ai-prompt/{ai_prompt}",
 *     "delete-form" = "/admin/structure/ai-prompt/{ai_prompt}/delete",
 *   },
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "prompt",
 *     "model",
 *     "character_limit",
 *   },
 * )
 */
final class AiPrompt extends ConfigEntityBase implements AiPromptInterface {

  /**
   * The prompt ID.
   */
  protected string $id;

  /**
   * The prompt label.
   */
  protected string $label;

  /**
   * The actual prompt string to use.
   */
  public string $prompt;

  /**
   * The prompt model.
   */
  public string $model;
  
  /**
   * Character limit for the AI response.
   */
  public int $character_limit = 0;

}
