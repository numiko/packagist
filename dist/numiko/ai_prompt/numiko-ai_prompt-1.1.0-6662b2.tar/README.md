# AI Prompt

Add an entity to store AI prompts in config

## Usage

1. Setup an AI prompt (Structure >> AI Prompt).
