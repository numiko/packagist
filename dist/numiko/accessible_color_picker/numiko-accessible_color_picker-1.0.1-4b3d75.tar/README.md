### Accessible colour picker

This module is used to add a colour picker field which will check the accessibility rating against a background colour.

The background colour can be set per field.

To use Spectrum JS picker the library needs to be installed.

Spectrum JS widget was taken and modified from https://www.drupal.org/project/color_field