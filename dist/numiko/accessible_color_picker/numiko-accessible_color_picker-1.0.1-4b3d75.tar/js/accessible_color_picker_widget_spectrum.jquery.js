/**
 * @file
 * Javascript for Accessible Color Picker.
 */

(function ($, Drupal) {

    'use strict';

    /**
     * Enables spectrum on color elements.
     *
     * @type {Drupal~behavior}
     *
     * @prop {Drupal~behaviorAttach} attach
     *   Attaches a spectrum widget to a color input element.
     */
    Drupal.behaviors.accessible_color_picker_spectrum = {
        attach: function (context, settings) {
            var $context = $(context);

            $context.find('.js-accessible-color-picker-widget-spectrum__color').each(function (index, element) {
                var $element = $(element);
                var spectrum_settings = settings.accessible_color_picker.accessible_color_picker_widget_spectrum[$element.attr('data-uid')];

                $element.spectrum({
                    showInitial: true,
                    preferredFormat: "hex",
                    showInput: spectrum_settings.show_input,
                    showAlpha: spectrum_settings.show_alpha,
                    showPalette: spectrum_settings.show_palette,
                    showPaletteOnly: spectrum_settings.show_palette_only,
                    palette: JSON.parse('[' + spectrum_settings.palette + ']'),
                    showButtons: spectrum_settings.show_buttons,
                    allowEmpty: spectrum_settings.allow_empty,
                    change: function (tinycolor) {
                        var hexColor = '';

                        if (tinycolor) {
                            hexColor = tinycolor.toHexString();
                        }

                        $element.val(hexColor);
                    }
                });
            });
        }
    };

})(jQuery, Drupal);
