<?php

namespace Drupal\listing_template\Twig;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\listings_filter\ContentListing;
use Drupal\listings_filter\ListingQueryBase;
use Drupal\listings_filter\ListingQueryManager;
use Drupal\paragraphs\ParagraphInterface;
use Drupal\search_api_solr\SearchApiSolrException;
use Twig\Extension\AbstractExtension;
use Twig\TwigFunction;

/**
 * Listing Template Twig filters.
 */
class ListingTemplateTwigExtension extends AbstractExtension {

  /**
   * The Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The Listing Filter Service.
   *
   * @var \Drupal\listings_filter\ContentListing
   */
  protected $listingFilter;

  /**
   * The Listing Query Service.
   *
   * @var \Drupal\listings_filter\ListingQueryManager
   */
  protected $listingQueryManager;

  /**
   * {@inheritDoc}
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\listings_filter\ContentListing $listingFilter
   *   The listing filter service.
   * @param \Drupal\listings_filter\ListingQueryManager $listingQueryManager
   *   The listing query service.
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager, ContentListing $listingFilter, ListingQueryManager $listingQueryManager) {
    $this->entityTypeManager = $entityTypeManager;
    $this->listingFilter = $listingFilter;
    $this->listingQueryManager = $listingQueryManager;
  }

  /**
   * {@inheritDoc}
   */
  public function getName(): string {
    return 'listings_filter';
  }

  /**
   * Get a list of twig simple functions.
   *
   * @return \Twig\TwigFunction[]
   */
  public function getFunctions(): array {
    return [
      new TwigFunction('get_listing_results', [$this, 'getListingsResults']),
    ];
  }

  /**
   * Get the listing data for given listing ID.
   *
   * @param \Drupal\paragraphs\ParagraphInterface $paragraph
   *   The paragraph to show the listing for.
   * @param ?array $requestOptions
   *   The request options being passed in (e.g. display_mode / page / count).
   *
   * @return array
   *   Return the data array from the listing.
   */
  public function getListingsResults(ParagraphInterface $paragraph, ?array $requestOptions = NULL): array {
    /** @var \Drupal\listings_filter\Entity\ListingsParagraphInterface[] */
    $listingsParagraphs = $this->entityTypeManager->getStorage('listings_paragraph')->loadByProperties(['paragraph_type_id' => $paragraph->bundle()]);
    if (!empty($listingsParagraphs)) {
      $listingsParagraph = reset($listingsParagraphs);
      $settings = $this->listingFilter->buildListingQuerySettings($listingsParagraph, $paragraph);

      try {
        $index = $this->entityTypeManager->getStorage('search_api_index')->load($settings['search_index']);
        $listingQuery = $this->listingQueryManager->getListingQuery($index->getServerInstance()->getBackendId());
        $results = $listingQuery->getResults($settings, $requestOptions);
        return $this->convertResultsToRenderArray($results, $listingQuery, $settings);
      }
      catch (SearchApiSolrException $e) {
        return [];
      }
    }
    return [];
  }

  /**
   * Convert the results to a render array.
   *
   * Prefix the data keys with a # and add a #cache context to the result set.
   *
   * Currently there is no way for a twig extension to impact the cache, so
   * either the render array needs to be output.
   *  {{ results | without('items') }}
   * or simply render the cache key.
   *  {{ {'#cache': results['#cache']}|render }}
   * (See https://www.drupal.org/project/drupal/issues/2660002#comment-14580634)
   */
  private function convertResultsToRenderArray(array $results, ListingQueryBase $listingQuery, array $settings): array {
    $items = [];
    foreach ($results['items'] as $key => $item) {
      $items[$key] = [
        '#id' => $item['id'],
        '#markup' => $item['markup'],
      ];
    }
    $cacheDependencies = $listingQuery->getCacheDependencies($settings);
    return [
      'items' => $items,
      '#meta' => $results['meta'],
      '#cache' => [
        'tags' => $cacheDependencies->getCacheTags(),
        'contexts' => $cacheDependencies->getCacheContexts(),
        'max-age' => $cacheDependencies->getCacheMaxAge(),
      ],
    ];
  }

}
