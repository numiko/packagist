(function ($, Drupal, drupalSettings) {

    $('.views-col').click(function(e) {
      $checkbox = $(this).find('input');
      if (e.target.tagName != 'INPUT') {
        $checkbox.click();
      }
      if ($checkbox.is(':checked')) {
        $(this).addClass('selected');
      } else {
        $(this).removeClass('selected');
      }
    });

})(jQuery, Drupal, drupalSettings);