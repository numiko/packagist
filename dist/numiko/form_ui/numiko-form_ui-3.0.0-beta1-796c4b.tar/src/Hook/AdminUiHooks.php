<?php

namespace Drupal\form_ui\Hook;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Path\PathMatcherInterface;
use Drupal\Core\Routing\AdminContext;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Routing\RouteProviderInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\Core\Url;
use Drupal\user\UserInterface;
use Symfony\Component\HttpFoundation\RequestStack;

/**
 * Various changes to the admin UI.
 *
 * These are collected together as they use lots of router and path services.
 */
final class AdminUiHooks {
  use StringTranslationTrait;

  private const string MODULE_SETTINGS = 'form_ui.settings';

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
    private readonly AdminContext $adminContext,
    private readonly RouteProviderInterface $routeProvider,
    private readonly RouteMatchInterface $routeMatcher,
    private readonly PathMatcherInterface $pathMatcher,
    private readonly RequestStack $requestStack,
    TranslationInterface $stringTranslation,
  ) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Implements hook_toolbar_alter().
   */
  #[Hook('toolbar_alter')]
  public function toolbarAlter(array &$items): void {
    $config = $this->configFactory->get(self::MODULE_SETTINGS);
    if ($config->get('toolbar.home_button')) {
      if (!$this->adminContext->isAdminRoute() && !$this->pathMatcher->isFrontPage()) {
        $items['home']['tab']['#title'] = $this->t('Home');
        $items['home']['#wrapper_attributes']['class'] = array_diff($items['home']['#wrapper_attributes']['class'], [
          'hidden',
        ]);
      }
    }
    if ($config->get('toolbar.shortcuts_label')) {
      $items['shortcuts']['tab']['#title'] = $this->t($config->get('toolbar.shortcuts_label'));
      $items['shortcuts']['#weight'] = -18;
    }
  }

  /**
   * Implements hook_user_login().
   */
  #[Hook('user_login')]
  public function userLogin(UserInterface $account): void {
    // If user is in process of resetting password, do not redirect on login.
    $route_name = $this->routeMatcher->getRouteName();
    if ($route_name == 'user.reset.login' || $route_name == 'tfa.entry' && $this->requestStack->getCurrentRequest()?->query?->get('pass-reset-token')) {
      return;
    }

    $config = $this->configFactory->get(self::MODULE_SETTINGS);
    if ($config->get('redirects.editor_login') && $account->hasPermission('access content overview')) {
      $this->requestStack->getCurrentRequest()?->query?->set('destination', Url::fromRoute('system.admin_content')->toString());
    }
    elseif ($config->get('redirects.workbench_login') && $account->hasPermission('access workbench')) {
      $workbench_exists = count($this->routeProvider->getRoutesByNames(['workbench.content'])) === 1;
      if ($workbench_exists) {
        $this->requestStack->getCurrentRequest()?->query?->set('destination', Url::fromRoute('workbench.content')->toString());
      }
    }
  }

  /**
   * Implements hook_page_attachments().
   *
   * Attach the sticky secondary nav css.
   */
  #[Hook('page_attachments')]
  public function pageAttachments(array &$attachments): void {
    if ($this->adminContext->isAdminRoute()) {
      return;
    }
    $toolbar = $this->configFactory->get('gin.settings')->get('classic_toolbar');
    $config = $this->configFactory->get(self::MODULE_SETTINGS);
    // Attach the base library if the horizontal toolbar is set and
    // the config is set to use a sticky secondary nav.
    if ($config->get('toolbar.gin_secondary_nav_sticky') && $toolbar === 'horizontal') {
      // Attach your library.
      $attachments['#attached']['library'][] = 'form_ui/drupal.form_ui.sticky_secondary_nav';
    }
  }

}
