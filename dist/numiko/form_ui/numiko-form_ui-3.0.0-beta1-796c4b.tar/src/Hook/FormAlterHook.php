<?php

namespace Drupal\form_ui\Hook;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityFormInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\Core\Theme\ThemeManagerInterface;
use Symfony\Component\DependencyInjection\Attribute\AutowireServiceClosure;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Implements hook_form_alter().
 *
 * This hook does many different things at once so it has its own function.
 * This should be split up into multiple form alter hooks.
 */
#[Hook('form_alter')]
final class FormAlterHook {
  use StringTranslationTrait;

  private const string MODULE_SETTINGS = 'form_ui.settings';

  /**
   * The form alter hook constructor.
   *
   * Since this is run on every form be careful in what you instantiate.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   Config factory.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $moduleHandler
   *   Module handler to check installed modules.
   * @param \Symfony\Component\DependencyInjection\ContainerInterface $container
   *   The container.
   * @param \Drupal\Core\StringTranslation\TranslationInterface $stringTranslation
   *   Translation interface for the t function.
   * @param \Closure(): \Drupal\Core\Theme\ThemeManagerInterface $themeManagerClosure
   *   Theme manager.
   */
  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
    private readonly ModuleHandlerInterface $moduleHandler,
    private readonly ContainerInterface $container,
    TranslationInterface $stringTranslation,
    #[AutowireServiceClosure(ThemeManagerInterface::class)]
    private readonly \Closure $themeManagerClosure,
  ) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Hook entry point.
   */
  public function __invoke(array &$form, FormStateInterface $form_state, string $form_id): void {
    $entity_type = $this->getEntity($form_state)?->getEntityTypeId();
    if ($entity_type) {
      $this->entityFormAlters($form, $form_state, $entity_type);
    }
    if ($form_id === 'entity_view_display_edit_form') {
      $this->entityDisplayFormAlters($form);
    }
    if ($form_id === 'views_form_content_page_1') {
      $this->footerBulkActions($form);
    }
    if ($form_id === 'user_pass_reset') {
      $this->hideUsernameOtp($form);
    }
  }

  /**
   * Alterations for entity forms.
   */
  private function entityFormAlters(array &$form, FormStateInterface $form_state, string $entity_type): void {
    $config = $this->configFactory->get(self::MODULE_SETTINGS);
    if ($config->get('edit_form.styling') || $config->get('edit_form.hide_paragraph_drag_handles') || $config->get('edit_form.media_library')) {
      $this->attachStylingAlterations($form);
    }
    if ($config->get('edit_form.remove_moderation') && $this->moduleHandler->moduleExists('content_moderation')) {
      $this->hideModerationFields($form, $form_state);
    }
    if ($config->get('redirects.edit_form.' . $entity_type)) {
      $this->redirectBackToListing($form);
    }
    if ($config->get('edit_form.novalidate.' . $entity_type)) {
      $form['#attributes']['novalidate'] = 'novalidate';
    }
    if ($entity_type === 'node') {
      if ($config->get('edit_form.save_edit')) {
        $this->addSaveAndExit($form);
      }
    }
    if ($entity_type === 'comment') {
      $this->commentAlter($form);
    }
    if ($config->get('edit_form.hide_preview')) {
      unset($form['actions']['preview']);
    }
  }

  /**
   * Apply smaller screen styling alterations.
   */
  private function attachStylingAlterations(array &$form): void {
    $config = $this->configFactory->get(self::MODULE_SETTINGS);
    $admin_theme = $this->configFactory->get('system.theme')->get('admin');
    $current_theme = ($this->themeManagerClosure)()->getActiveTheme()->getName();
    if ($admin_theme === $current_theme) {
      if ($config->get('edit_form.styling')) {
        $form['#attached']['library'][] = 'form_ui/drupal.form_ui';
      }
      if ($config->get('edit_form.media_library')) {
        $form['#attached']['library'][] = 'form_ui/drupal.media_library';
      }
      if ($config->get('edit_form.hide_paragraph_drag_handles')) {
        $form['#attached']['library'][] = 'form_ui/drupal.form_ui.hide_paragraph_drag_handles';
      }
    }
  }

  /**
   * Hide moderation fields if an entity is not moderated.
   */
  private function hideModerationFields(array &$form, FormStateInterface $form_state): void {
    // We know this is a entity form so entity will never be null.
    /** @var \Drupal\Core\Entity\EntityInterface $entity */
    $entity = $this->getEntity($form_state);
    // This service exists because we checked the content moderation
    // module is installed.
    //
    // Do not use `ClassName::class` here as that would result in an invalid
    // import if content moderation is not installed.
    $moderationInfomation = $this->container->get('content_moderation.moderation_information');
    $isModeratable = $moderationInfomation->isModeratedEntity($entity);
    if (!$isModeratable) {
      $form['revision']['#access'] = FALSE;
      $form['revision_log_message']['#access'] = FALSE;
    }
  }

  /**
   * Redirect back to an entity collection after submitting an entity.
   */
  private function redirectBackToListing(array &$form): void {
    foreach (array_keys($form['actions']) as $action) {
      if ($action != 'preview' && isset($form['actions'][$action]['#type']) && $form['actions'][$action]['#type'] === 'submit') {
        $form['actions'][$action]['#submit'][] = [FormAlterHook::class, 'redirectSubmit'];
      }
    }
  }

  /**
   * Submit handler for redirecting back to an entity collection.
   */
  public static function redirectSubmit(array $form, FormStateInterface $form_state): void {
    $entity_type = self::getEntity($form_state)?->getEntityTypeId();
    if (!$entity_type) {
      return;
    }

    $collection_link = \Drupal::config(self::MODULE_SETTINGS)->get('redirects.edit_form.' . $entity_type);
    if ($redirect = \Drupal::pathValidator()->getUrlIfValid($collection_link)) {
      $form_state->setRedirectUrl($redirect);
    }
  }

  /**
   * Get the entity type of a form.
   */
  private static function getEntity(FormStateInterface $form_state): ?EntityInterface {
    if ($form_state->getFormObject() instanceof EntityFormInterface) {
      $entity = $form_state->getFormObject()->getEntity();
      return $entity;
    }
    return NULL;
  }

  /**
   * Add a save and exit button.
   */
  private function addSaveAndExit(array $form): void {
    $form['actions']['submitedit'] = [
      '#type' => 'submit',
      '#value' => $this->t("Save & Edit"),
      '#access' => TRUE,
      '#weight' => 10,
      '#submit' => [
        '::submitForm',
        '::save',
        [FormAlterHook::class, 'saveAndEditRedirect'],
      ],
    ];
  }

  /**
   * After clicking save & edit the user is redirected back to the form.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  public static function saveAndEditRedirect(array &$form, FormStateInterface $form_state): void {
    $entity = self::getEntity($form_state);
    if (!$entity) {
      return;
    }

    $entity_type_id = $entity->getEntityTypeId();
    $form_state->setRedirect("entity.$entity_type_id.edit_form", [$entity_type_id => $entity->id()]);
    // To ensure consistent behaviour we must drop the detination parameter
    // otherwise this will override our expected bahaviour.
    \Drupal::request()->query->remove('destination');
  }

  /**
   * Alterations to comments.
   */
  private function commentAlter(array &$form): void {
    $config = $this->configFactory->get(self::MODULE_SETTINGS);
    if ($author_mail_title = $config->get('comments.author_mail_title')) {
      $form['author']['mail']['#title'] = $this->t($author_mail_title);
    }
    if ($author_mail_description = $config->get('comments.author_mail_description')) {
      if ($author_mail_description == '<none>') {
        unset($form['author']['mail']['#description']);
      }
      else {
        $form['author']['mail']['#description'] = $this->t($author_mail_description);
      }
    }
    if ($save_label = $config->get('comments.save_label')) {
      $form['actions']['submit']['#value'] = $this->t($save_label);
    }
    if ($config->get('comments.hide_homepage_field')) {
      $form['author']['homepage']['#access'] = FALSE;
    }
  }

  /**
   * Alterations for entity display forms.
   */
  private function entityDisplayFormAlters(array &$form): void {
    // Show field ids on the display form.
    if ($this->configFactory->get(self::MODULE_SETTINGS)->get('manage_display.display_field_ids')) {
      foreach ($form['fields'] as $field_id => &$field) {
        if (substr($field_id, 0, 6) === 'field_') {
          $field['human_name']['#markup'] = $field['human_name']['#plain_text'] . ' <small>(' . $field_id . ')</small>';
          unset($field['human_name']['#plain_text']);
        }
      }
    }
  }

  /**
   * Move bulk actions to the footer.
   */
  private function footerBulkActions(array &$form): void {
    if ($this->configFactory->get(self::MODULE_SETTINGS)->get('content_view.move_bulk_actions')) {
      if (isset($form['header']) && isset($form['header']['node_bulk_form'])) {
        $form['actions']['action'] = $form['header']['node_bulk_form']['action'];
        $form['actions']['action']['#empty_option'] = '- Bulk action -';
        $form['actions']['action']['#title'] = $this->t('Bulk Actions');
        $form['actions']['action']['#required'] = TRUE;
        $form['actions']['action']['#weight'] = -10;
        unset($form['header']['node_bulk_form']);
        $form['actions']['submit']['#value'] = $this->t('Apply to selected');
      }
    }
  }

  /**
   * Remove username from one-time login page.
   */
  private function hideUsernameOtp(array &$form): void {
    if ($this->configFactory->get(self::MODULE_SETTINGS)->get('user.one_time_login_enum')) {
      $message = $form['message']['#markup']->getUntranslatedString();
      $arguments = $form['message']['#markup']->getArguments();
      $message = str_replace("for %user_name", "", $message);
      $form['message']['#markup'] = $this->t($message, $arguments);
    }
  }

}
