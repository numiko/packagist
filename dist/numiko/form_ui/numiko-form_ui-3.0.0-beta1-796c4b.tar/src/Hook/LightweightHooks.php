<?php

namespace Drupal\form_ui\Hook;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\form_ui\Factory\FieldElementRenderFactory;

/**
 * Various small hook implementations for form_ui.
 */
final class LightweightHooks {

  public function __construct(
    private readonly ConfigFactoryInterface $configFactory,
  ) {}

  /**
   * Implements hook_field_widget_single_element_form_alter().
   */
  #[Hook('field_widget_single_element_form_alter')]
  public function fieldWidgetSingleElementFormAlter(array &$element, FormStateInterface $form_state, array $context): void {
    $descriptionDisplay = $this->configFactory->get('form_ui.settings')->get('fields.description_display');
    if ($descriptionDisplay) {
      $field_elements = FieldElementRenderFactory::getElementRenderArrayKeys($context['widget'], $element);
      foreach ($field_elements as $field_element) {
        if ($field_element == 'root') {
          $element['#description_display'] = $descriptionDisplay;
        }
        else {
          $element[$field_element]['#description_display'] = $descriptionDisplay;
        }
      }
    }
  }

  /**
   * Implemets hook_preprocess_views_view().
   */
  #[Hook('preprocess_views_view')]
  public function preprocessViewsView(array &$variables): void {
    if ($variables['id'] === 'media_browser') {
      $variables['view']->element['#attached']['library'][] = 'form_ui/drupal.media_browser';
    }
  }

}
