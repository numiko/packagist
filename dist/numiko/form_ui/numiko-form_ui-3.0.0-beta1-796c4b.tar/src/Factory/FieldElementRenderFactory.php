<?php

namespace Drupal\form_ui\Factory;

use Drupal\Core\Field\Plugin\Field\FieldWidget\EntityReferenceAutocompleteTagsWidget;
use Drupal\Core\Field\Plugin\Field\FieldWidget\EntityReferenceAutocompleteWidget;
use Drupal\link\Plugin\Field\FieldWidget\LinkWidget;
use Drupal\text\Plugin\Field\FieldWidget\TextareaWithSummaryWidget;

class FieldElementRenderFactory {

  /**
   * Get an array of references to the form elements actual field render array.
   */
  public static function getElementRenderArrayKeys($widget, $render_element) {
    $field_elements = [];
    // Special case for fields with an additional summary field.
    if (isset($render_element['summary'])) {
      $field_elements[] = 'summary';
    }
    if ($widget instanceof EntityReferenceAutocompleteWidget) {
      $field_elements[] = 'target_id';
    }
    elseif ($widget instanceof TextareaWithSummaryWidget) {
      $field_elements[] = 'root';
    }
    elseif ($widget instanceof EntityReferenceAutocompleteTagsWidget) {
      $field_elements[] = 'target_id';
    }
    elseif ($widget instanceof LinkWidget) {
      $field_elements[] = 'uri';
    }
    elseif (isset($render_element['value'])) {
      $field_elements[] = 'value';
    }
    else {
      $field_elements[] = 'root';
    }
    return $field_elements;
  }

}
