<?php

namespace Drupal\form_ui\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Form\FormErrorHandler as FormErrorHandlerBase;
use Drupal\Core\Form\FormErrorHandlerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\form_ui\Element\ErrorFormat;

/**
 * Provides validation of form submissions.
 *
 * This decorates Drupal's FormErrorHandler but also extends it any method that
 * isn't overriden is called on the parent.
 */
class FormErrorHandler extends FormErrorHandlerBase {

  /**
   * Provides validation of form submissions.
   *
   * @param \Drupal\Core\Form\FormErrorHandler $inner
   *   Inner form element being decorated.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   Config service.
   */
  public function __construct(
    protected FormErrorHandlerInterface $inner,
    protected ConfigFactoryInterface $configFactory,
  ) {}

  /**
   * Loops through and displays all form errors.
   *
   * @param array $form
   *   An associative array containing the structure of the form.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The current state of the form.
   */
  #[\Override]
  protected function displayErrorMessages(array $form, FormStateInterface $form_state): void {
    if ($this->configFactory->get('form_ui.settings')->get('edit_form.form_error_handler')) {
      $this->displayDetailedErrorMessages($form, $form_state);
    }
    else {
      $this->inner->displayErrorMessages($form, $form_state);
    }
  }

  /**
   * Display the error message in the improved format.
   */
  protected function displayDetailedErrorMessages(array $form, FormStateInterface $form_state): void {
    $errors = $form_state->getErrors();
    $errorFormat = new ErrorFormat($form_state);

    // Loop through all form errors and set an error message.
    foreach ($errors as $key => $error) {
      if ($error instanceof TranslatableMarkup) {
        $error = $errorFormat->formatError($key, $error);
      }
      $this->messenger()->addMessage($error, 'error');
    }
  }

}
