<?php
/**
 * RestClientException.php
 *
 * @author Roman Piták <roman@pitak.net>
 * @package romanpitak/dotmailer-api-v2-client
 *
 */

namespace DotMailer\Api\Rest;

class RestClientException extends Exception
{

}
