# Link Class

Adds a new formatter for link field displays to allow additional classes to a link field in the display settings, e.g. c-button to display a link as a button.

Additionally allows svg code to be inserted inside the link wrapper.
