<?php

declare(strict_types=1);

namespace Drupal\ai_schema\Service;

use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\FieldItemListInterface;

class ContentTypeInspector {

  private const SKIP_FIELDS = [
    'nid', 'vid', 'langcode', 'type', 'revision_timestamp', 'revision_uid',
    'revision_log', 'status', 'uid', 'created', 'changed', 'promote', 'sticky',
    'default_langcode', 'revision_default', 'revision_translation_affected', 'path',
    'menu_link', 'content_translation_source', 'content_translation_outdated',
  ];

  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly EntityFieldManagerInterface $entityFieldManager,
    private readonly EntityTypeBundleInfoInterface $bundleInfo,
  ) {}

  /**
   * Returns all node bundle machine names keyed to their labels.
   *
   * @return array<string, string>
   */
  public function getAllNodeTypes(): array {
    $bundles = $this->bundleInfo->getBundleInfo('node');
    return array_map(fn($info) => (string) $info['label'], $bundles);
  }

  /**
   * Returns field and type metadata for a node bundle.
   *
   * @return array{bundle: string, label: string, description: string, fields: list<array>}
   *
   * @throws \InvalidArgumentException
   */
  public function inspectNodeType(string $bundle): array {
    $nodeType = $this->entityTypeManager->getStorage('node_type')->load($bundle);
    if (!$nodeType) {
      throw new \InvalidArgumentException("Content type '$bundle' does not exist.");
    }

    $fields = $this->entityFieldManager->getFieldDefinitions('node', $bundle);
    $fieldInfo = [];

    foreach ($fields as $fieldName => $definition) {
      if (in_array($fieldName, self::SKIP_FIELDS, TRUE)) {
        continue;
      }

      $storage = $definition->getFieldStorageDefinition();
      $fieldInfo[] = [
        'machine_name' => $fieldName,
        'label' => (string) $definition->getLabel(),
        'field_type' => $definition->getType(),
        'cardinality' => $storage->getCardinality(),
        'description' => (string) $definition->getDescription(),
        'required' => $definition->isRequired(),
      ];
    }

    return [
      'bundle' => $bundle,
      'label' => (string) $nodeType->label(),
      'description' => (string) $nodeType->getDescription(),
      'fields' => $fieldInfo,
    ];
  }

  /**
   * Returns representative field values sampled from published nodes.
   *
   * Loads up to $limit published nodes of the bundle and extracts one plain-text
   * preview per field. Complex field types (paragraphs, media, images) are skipped.
   * Entity-reference fields targeting taxonomy terms or users are resolved to their
   * labels so Claude sees meaningful text rather than numeric IDs.
   *
   * The results are shown to Claude alongside field definitions so it can
   * distinguish e.g. a short teaser text from a long body, or identify which
   * entity reference holds the author vs. a category. Pass an empty array to
   * the suggester to skip sampling (--exclude-samples flag).
   *
   * @return array<string, string>
   *   Field machine name → truncated plain-text sample value.
   */
  public function getSampleValues(string $bundle, int $limit = 2): array {
    $storage = $this->entityTypeManager->getStorage('node');
    $nids = $storage->getQuery()
      ->condition('type', $bundle)
      ->condition('status', 1)
      ->range(0, $limit)
      ->accessCheck(FALSE)
      ->execute();

    if (empty($nids)) {
      return [];
    }

    $samples = [];
    foreach ($storage->loadMultiple($nids) as $node) {
      foreach ($node->getFields() as $fieldName => $items) {
        if (isset($samples[$fieldName]) || in_array($fieldName, self::SKIP_FIELDS, TRUE)) {
          continue;
        }
        $value = $this->extractSampleValue($items);
        if ($value !== NULL && $value !== '') {
          $samples[$fieldName] = $value;
        }
      }
    }

    return $samples;
  }

  private function extractSampleValue(FieldItemListInterface $items): ?string {
    if ($items->isEmpty()) {
      return NULL;
    }

    $type = $items->getFieldDefinition()->getType();

    switch ($type) {
      case 'string':
      case 'string_long':
        return mb_substr((string) $items->first()->value, 0, 120) ?: NULL;

      case 'text':
      case 'text_long':
      case 'text_with_summary':
        $plain = trim(strip_tags((string) $items->first()->value));
        return $plain ? mb_substr($plain, 0, 120) : NULL;

      case 'datetime':
      case 'daterange':
        return (string) $items->first()->value ?: NULL;

      case 'boolean':
        return $items->first()->value ? 'true' : 'false';

      case 'link':
        return (string) $items->first()->uri ?: NULL;

      case 'entity_reference':
      case 'entity_reference_revisions': {
        $targetType = $items->getFieldDefinition()->getSetting('target_type');
        if (!in_array($targetType, ['taxonomy_term', 'user'], TRUE)) {
          return NULL;
        }
        $entity = $items->first()->entity;
        return $entity ? (string) $entity->label() : NULL;
      }

      default:
        return NULL;
    }
  }

}
