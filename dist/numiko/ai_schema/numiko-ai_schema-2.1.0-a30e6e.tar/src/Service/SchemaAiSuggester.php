<?php

declare(strict_types=1);

namespace Drupal\ai_schema\Service;

use Drupal\ai\AiProviderPluginManager;
use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;

class SchemaAiSuggester {

  private const MODEL = 'claude-sonnet-4-6';

  private const REQUIRED_KEYS = ['schema_type', 'group', 'confidence', 'rationale', 'type_tag', 'mappings'];

  public function __construct(
    private readonly AiProviderPluginManager $aiProviderManager,
  ) {}

  /**
   * Asks Claude to suggest Schema.org mappings for a content type.
   *
   * @param array $nodeTypeInfo
   *   From ContentTypeInspector::inspectNodeType().
   * @param array $availableTypes
   *   From SchemaMetatagRegistry::getAvailableTypes(). Installed types only —
   *   Claude uses their exact plugin IDs when generating mappings.
   * @param array $existingMetatags
   *   Non-schema metatag tags already configured for this bundle, from
   *   SchemaMetatagApplier::getExistingNonSchemaTags(). Used to match
   *   existing token conventions (image styles, description fields).
   * @param array $allKnownTypes
   *   From SchemaMetatagRegistry::getAllKnownSchemaTypes(). Full vocabulary
   *   including uninstalled types, so Claude can suggest the ideal type even
   *   when its sub-module is not yet present. When Claude selects an uninstalled
   *   type it returns empty mappings; the command layer installs the module and
   *   re-queries with the full plugin list.
   *
   * @return array{
   *   schema_type: string,
   *   group: string,
   *   confidence: string,
   *   rationale: string,
   *   type_tag: array{plugin_id: string, value: string},
   *   mappings: list<array>,
   *   skipped_properties: list<string>,
   *   unmapped_fields: list<string>
   * }
   *
   * @throws \RuntimeException
   */
  public function suggest(array $nodeTypeInfo, array $availableTypes, array $existingMetatags = [], array $allKnownTypes = [], array $sampleValues = []): array {
    [$system, $user] = $this->buildPrompts($nodeTypeInfo, $availableTypes, $existingMetatags, $allKnownTypes, $sampleValues);

    $provider = $this->aiProviderManager->createInstance('anthropic');
    $input = new ChatInput([new ChatMessage('user', $user)]);
    $input->setSystemPrompt($system);

    $output = $provider->chat($input, self::MODEL, ['ai_schema']);
    $text = $output->getNormalized()->getText();

    return $this->parseResponse($text);
  }

  private function buildPrompts(array $nodeTypeInfo, array $availableTypes, array $existingMetatags, array $allKnownTypes, array $sampleValues = []): array {
    $system = <<<'SYSTEM'
You are a Drupal Schema.org structured data expert. You analyse content type field definitions and suggest the best schema_metatag configuration for each content type.

Your response must be valid JSON and nothing else — no preamble, no explanation, no markdown fences.
SYSTEM;

    $fieldsJson = json_encode($nodeTypeInfo['fields'], JSON_PRETTY_PRINT);
    $installedBlock = $this->formatAvailableTypes($availableTypes, $allKnownTypes);
    $uninstalledBlock = $this->formatUninstalledTypes($allKnownTypes);
    $existingBlock = $this->formatExistingMetatags($existingMetatags);
    $samplesBlock = $this->formatSampleValues($sampleValues);

    $user = <<<EOT
Analyse this Drupal content type and return a JSON Schema.org mapping suggestion.

CONTENT TYPE:
  Machine name : {$nodeTypeInfo['bundle']}
  Label        : {$nodeTypeInfo['label']}
  Description  : {$nodeTypeInfo['description']}

FIELDS:
{$fieldsJson}

SAMPLE CONTENT (representative values from published nodes — use to disambiguate field purpose):
{$samplesBlock}

SCHEMA.ORG TYPES — INSTALLED (plugins available, use exact plugin IDs in mappings):
{$installedBlock}

SCHEMA.ORG TYPES — NOT YET INSTALLED (you may still choose these; the system will
install the required sub-module and re-query you for mappings afterwards):
{$uninstalledBlock}

EXISTING METATAG CONFIGURATION (tokens already in use for this content type):
{$existingBlock}
These reveal the project's token conventions. You MUST match them — particularly:
- Whichever field is used for "description" here is the correct field for Schema.org description properties.
- Whichever image token is used for "og_image" or "image_src" establishes the image style to use. Copy that token exactly for image_object properties — do not use a raw :url token if a styled token is already in use.

SITEKIT PROJECT CONVENTIONS:
- field_teaser_summary is the standard short summary field and is already used as the page meta description. Always prefer it over body for Schema.org description, abstract, and similar properties.
- field_image is the primary featured image. Image tokens must include an image style in the token path — never use [node:field_image:entity:url] alone. Follow the image style already established in the existing metatag config above.
- field_publish_date is the editorial publication date. Use it for datePublished in preference to the system created timestamp.
- field_author is the author entity reference. Use it for author properties.

DRUPAL TOKEN REFERENCE:
  title field                    → [node:title]
  text / string field            → [node:FIELD_NAME:value]
  date field                     → [node:FIELD_NAME:date:html_datetime]
  image with style (preferred)   → [node:FIELD_NAME:entity:FIELD_NAME:STYLE_NAME:url]
  image raw URL (fallback only)  → [node:FIELD_NAME:entity:url]
  entity ref (title)             → [node:FIELD_NAME:entity:title]
  entity ref (URL)               → [node:FIELD_NAME:entity:url]
  link URI                       → [node:FIELD_NAME:uri]
  body                           → [node:body:value]
  node URL                       → [node:url]
  site URL                       → [site:url]

RULES:
1. Always choose the best-fitting Schema.org type regardless of whether its sub-module is installed.
2. A group's plugin IDs work for every Schema.org type listed under that group. If you choose
   NewsArticle (group: schema_article), you MUST use schema_article_* plugin IDs in your mappings.
   The plugin IDs do not change based on which sub-type you pick within the group.
3. If the best type is installed: provide full mappings using the exact plugin IDs from that group.
4. If the best type is NOT yet installed: return schema_type, group, empty mappings [] — the system
   will install the module and call you again with the full plugin list.
5. The type_tag plugin_id follows the pattern "<group>_type" (e.g. "schema_article_type" for
   NewsArticle in group schema_article). The type_tag value is the specific Schema.org class name
   (e.g. "NewsArticle"), not a token and not the generic group name.
6. For simple property types, set token to a Drupal token string.
7. For complex property types (marked [complex]), set token to the most useful single token —
   for image_object use the styled image token; for place use a location name field.
8. Rate confidence: "high" (unambiguous match), "medium" (reasonable inference), "low" (uncertain).
9. Only map properties where there is a real field candidate. List unmatched properties in skipped_properties.
10. List fields with no useful mapping in unmapped_fields.
11. Do not invent plugin IDs — only use plugin_ids exactly as listed in the installed section above.

RETURN exactly this JSON shape (no other text):
{
  "schema_type": "Event",
  "group": "schema_event",
  "confidence": "high",
  "rationale": "One sentence explaining the type choice.",
  "type_tag": {
    "plugin_id": "schema_event_type",
    "value": "Event"
  },
  "mappings": [
    {
      "field_machine_name": "title",
      "plugin_id": "schema_event_name",
      "property_label": "name",
      "token": "[node:title]",
      "is_complex": false,
      "confidence": "high",
      "rationale": "Title is the event name."
    }
  ],
  "skipped_properties": ["performer"],
  "unmapped_fields": ["field_ticket_url"]
}
EOT;

    return [$system, $user];
  }

  /**
   * Formats the installed type list.
   *
   * Each group (e.g. schema_article) can cover several Schema.org class names
   * (Article, NewsArticle, BlogPosting, TechArticle). We show them all so
   * Claude knows any of those names is valid for that group's plugin IDs.
   */
  private function formatAvailableTypes(array $availableTypes, array $allKnownTypes = []): string {
    // Build reverse map: group → [schema types]
    $typesByGroup = [];
    foreach ($allKnownTypes as $schemaType => $info) {
      if ($info['enabled']) {
        $typesByGroup[$info['module']][] = $schemaType;
      }
    }

    $lines = [];
    foreach ($availableTypes as $group => $typeInfo) {
      $typeNames = $typesByGroup[$group] ?? [$typeInfo['schema_type']];
      $header = implode(' / ', $typeNames) . " (group: {$group})";
      $lines[] = "\n{$header}";
      foreach ($typeInfo['plugins'] as $pluginId => $plugin) {
        $complex = $plugin['is_complex'] ? " [complex:{$plugin['property_type']}]" : '';
        $lines[] = "  {$pluginId}: {$plugin['name']} — {$plugin['description']}{$complex}";
      }
    }
    return implode("\n", $lines);
  }

  private function formatUninstalledTypes(array $allKnownTypes): string {
    // Group uninstalled types by module so the list is compact.
    $byModule = [];
    foreach ($allKnownTypes as $schemaType => $info) {
      if (!$info['enabled']) {
        $byModule[$info['module']][] = $schemaType;
      }
    }

    if (empty($byModule)) {
      return '  (all known types are already installed)';
    }

    $lines = [];
    foreach ($byModule as $module => $types) {
      $lines[] = sprintf('  %-30s →  needs: %s', implode(', ', $types), $module);
    }
    return implode("\n", $lines);
  }

  private function formatSampleValues(array $samples): string {
    if (empty($samples)) {
      return '  (no published content available)';
    }
    $lines = [];
    foreach ($samples as $field => $value) {
      $lines[] = sprintf('  %-30s → "%s"', $field, $value);
    }
    return implode("\n", $lines);
  }

  private function formatExistingMetatags(array $tags): string {
    if (empty($tags)) {
      return '  (none configured)';
    }

    // Unserialise any PHP-serialised values so Claude sees the token inside them.
    $lines = [];
    foreach ($tags as $key => $value) {
      if (str_starts_with((string) $value, 'a:')) {
        $decoded = @unserialize($value);
        $value = is_array($decoded) ? json_encode($decoded) : $value;
      }
      $lines[] = sprintf('  %-30s → %s', $key, $value);
    }

    return implode("\n", $lines);
  }

  private function parseResponse(string $text): array {
    // Strip any accidental markdown fences.
    $text = (string) preg_replace('/^```(?:json)?\s*/m', '', $text);
    $text = (string) preg_replace('/\s*```$/m', '', $text);
    $text = trim($text);

    $data = json_decode($text, TRUE);
    if (json_last_error() !== JSON_ERROR_NONE) {
      throw new \RuntimeException(
        'Claude returned invalid JSON: ' . json_last_error_msg() . "\n\nRaw:\n" . $text
      );
    }

    foreach (self::REQUIRED_KEYS as $key) {
      if (!array_key_exists($key, $data)) {
        throw new \RuntimeException("Claude response missing required key: '{$key}'");
      }
    }

    $data['skipped_properties'] ??= [];
    $data['unmapped_fields'] ??= [];

    return $data;
  }

}
