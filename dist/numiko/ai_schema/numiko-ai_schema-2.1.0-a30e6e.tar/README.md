# AI Schema

A Drupal module that uses AI to suggest and apply Schema.org structured data mappings to content types, writing configuration for the [schema_metatag](https://www.drupal.org/project/schema_metatag) module via Drush.

Instead of manually working through the schema_metatag configuration UI for each content type, you run a single Drush command. Claude inspects your fields, suggests the correct Schema.org type and property mappings, presents them for review, and writes the resulting `metatag.metatag_defaults` config.

---

## Requirements

- Drupal 10 or 11
- [`drupal/metatag`](https://www.drupal.org/project/metatag)
- [`drupal/schema_metatag`](https://www.drupal.org/project/schema_metatag) (core module only; sub-modules are enabled on demand)
- [`drupal/ai`](https://www.drupal.org/project/ai) with the `drupal/ai_provider_anthropic` sub-module configured
- `ANTHROPIC_API_KEY` set in your environment
- Drush 12+

---

## Installation

Enable the module:

```bash
drush pm:install ai_schema
```

No configuration form is needed. The module reads your existing field definitions and available schema_metatag plugins at runtime.

---

## Commands

### `drush schema:status`

Shows all node content types with their mapping status, the Schema.org type applied, when it was last run, and how many properties were mapped.

```
 ------------------- ------------------- -------------- ------------- ------------ ------------ 
  Bundle              Label               Status         Schema Type   Applied      Properties  
 ------------------- ------------------- -------------- ------------- ------------ ------------ 
  article             News Article        Not mapped                                          
  event               Event               ✓ Mapped       Event         2026-06-09   9           
```

---

### `drush schema:suggest <bundle>`

Runs the AI analysis and displays the suggested mappings **without writing anything**. Use this to preview what would be applied or to understand how the module interprets a content type.

```bash
drush schema:suggest article
drush schema:suggest article --exclude-samples
```

Example output:

```
Analysing News Article (article): 18 fields
Querying Claude...

  Suggested type : schema.org/NewsArticle  →  schema_article
  Confidence     : high
  Rationale      : Content type has author, publish date, body, and image fields
                   consistent with a NewsArticle.

 -------------------- -------------- ----------------------------------------- ------- 
  Field                Property       Token                                     Score  
 -------------------- -------------- ----------------------------------------- ------- 
  title                name           [node:title]                              ●●●    
  field_author         author         [node:field_author:entity:title] [wrapped] ●●●   
  field_publish_date   datePublished  [node:field_publish_date:date:html_datetime] ●●● 
  body                 articleBody    [node:body:value]                         ●●●    
  field_image          image          [node:field_image:entity:url] [wrapped]   ●●○    
 -------------------- -------------- ----------------------------------------- ------- 

  Skipped (no field match): publisher, keywords
  Unmapped fields: field_category, field_slices, field_related_content

! [NOTE] Dry run. No changes made. Use drush schema:apply to apply.
```

---

### `drush schema:apply <bundle>`

The main command. Runs the AI analysis, presents mappings for review, and writes the accepted configuration.

```bash
drush schema:apply event
drush schema:apply article
```

**Interactive review modes.** When prompted, choose:

- **All:** accept every suggested mapping and write immediately
- **Review each:** step through every mapping and confirm or skip individually
- **Skip:** abort without writing anything

**Sub-module handling:** if the suggested Schema.org type requires a schema_metatag sub-module that is not yet enabled (e.g. `schema_article` for a blog content type), the module installs it automatically, then re-queries the AI with the now-complete plugin list before presenting mappings.

**Options:**

| Option | Description |
|---|---|
| `--all` | Process every content type that has no recorded state |
| `--auto-accept` | Skip all confirmation prompts and accept every mapping |
| `--exclude-samples` | Do not load or send field values from published content |

```bash
drush schema:apply --all                              # interactive, all unmapped types
drush schema:apply --all --auto-accept                # non-interactive, good for CI or initial setup
drush schema:apply event --exclude-samples            # map without sending content values to the API
```

After applying, **export config**:

```bash
drush cex
```

The written configuration lands in `metatag.metatag_defaults.node__<bundle>.yml` in your sync directory.

---

### `drush schema:show <bundle>`

Displays the recorded state for a content type: the Schema.org type chosen, confidence rating, Claude's rationale, and when it was last applied.

```bash
drush schema:show event
```

```
 ------------------- ------------------------------------------------------------------- 
  Bundle              event                                                              
  Schema type         schema.org/Event                                                  
  Group               schema_event                                                      
  Confidence          high                                                              
  Rationale           Explicit event page with start/end dates, booking link, performer 
  Properties mapped   9                                                                 
  Last applied        2026-06-09 16:19                                                  
```

---

### `drush schema:reset <bundle>`

Clears the recorded state entry for a content type, making it appear as "Not mapped" in `schema:status`. **Does not modify any metatag config.** It only resets the tracking record. Use this to re-run the AI mapping on a type that has already been processed.

```bash
drush schema:reset event
drush schema:apply event
```

---

## Token reference

When reviewing AI-suggested tokens or editing `metatag.metatag_defaults` config directly, the following patterns cover most mapping scenarios:

| Token | Description |
|---|---|
| `[node:title]` | Node title |
| `[node:url]` | Absolute URL of the node |
| `[node:body:value]` | Full body text (HTML) |
| `[node:body:summary]` | Body summary |
| `[node:created:html_datetime]` | Created date (ISO 8601) |
| `[node:changed:html_datetime]` | Last modified date (ISO 8601) |
| `[node:FIELD:value]` | Plain text or string field value |
| `[node:FIELD:date:html_datetime]` | Date field in ISO 8601 format |
| `[node:FIELD:entity:title]` | Label of a referenced entity (taxonomy term, user, etc.) |
| `[node:FIELD:entity:url]` | URL of a referenced entity |
| `[node:FIELD:uri]` | URI from a link field |
| `[node:FIELD:entity:IMAGEFIELD:STYLE:url]` | Image field with a named image style applied |
| `[site:name]` | Site name |
| `[site:url]` | Site base URL |

Image tokens should always include a named image style rather than a raw `:url`. The module passes your existing `og_image` token to Claude as context, so the correct style is picked up automatically on projects that already have metatag configured.

For multi-value fields, append the zero-based delta: `[node:field_tags:0:name]`, `[node:field_tags:1:name]`.

---

## How it works

### 1. Existing metatag context

Before querying Claude, the module loads the non-schema metatag tags already configured for the bundle, inheriting from global through node to bundle-specific defaults, and passes them to the prompt. This gives Claude two critical pieces of project-specific knowledge:

- **Which field is used for descriptions.** On sitekit projects, `field_teaser_summary` is the standard short summary field and is already wired as the page meta description. Without this context, Claude tends to map `body` (the full rich-text content) to Schema.org description properties.
- **Which image style is in use.** Schema.org image properties should reference a named image style, not a raw file URL. The existing `og_image` token (`[node:field_image:entity:field_image:uncropped_lg:url]`) shows Claude the correct pattern for this project.

PHP-serialised values in the existing config are decoded before being sent, so Claude reads them as JSON structures rather than serialised strings.

### 2. Content sampling

By default the module loads up to two published nodes of the bundle and extracts a short plain-text preview (≤ 120 characters) from each populated field. These samples are passed to Claude alongside the field definitions.

This helps resolve ambiguity that field names alone cannot: for example, two text fields both named `field_body_copy` and `field_teaser_summary` look similar in a schema definition but very different when you can see one contains a two-sentence teaser and the other a 2 000-word article. Claude uses this to choose the right token for description, abstract, and similar properties.

Field types that do not yield a useful plain-text sample (images, files, paragraphs, media entities) are silently skipped. Entity-reference fields targeting taxonomy terms or users are resolved to their labels before sending.

**Privacy note:** Sample values are drawn from your site's live database and sent to the Anthropic API as part of the prompt. For content types containing personally identifiable information, sensitive data, or content subject to confidentiality requirements, use `--exclude-samples` to disable this behaviour:

```bash
drush schema:apply patient_record --exclude-samples
drush schema:suggest medical_case --exclude-samples
```

### 3. Field introspection

`ContentTypeInspector` loads the bundle's field definitions via `EntityFieldManager`, returning machine name, human label, Drupal field type, cardinality, and description for every content field (system fields are excluded).

### 4. Plugin discovery

`SchemaMetatagRegistry` queries Drupal's `MetatagTagPluginManager` for all registered metatag tag plugins and filters for those in a `schema_*` group. This gives a live view of which Schema.org types and properties are available from currently enabled sub-modules, including their `property_type` annotation, which determines whether a value is stored as a plain token string or as a PHP-serialised object.

### 5. AI suggestion

`SchemaAiSuggester` sends a structured prompt to Claude (`claude-sonnet-4-6`) via the Drupal AI module's `AiProviderPluginManager`. The prompt includes the full field list, sample content values (unless excluded), the complete list of available plugin IDs and their descriptions, and a reference sheet of Drupal token patterns. Claude is instructed to return valid JSON only, with no surrounding text.

The response is validated for required keys before use. Any markdown code fences that might appear despite the instruction are stripped before parsing.

### 6. Complex type serialisation

schema_metatag stores simple values (name, date, URL, description) as plain token strings. Complex nested types (`image_object`, `place`, `person`, `organization`, `offer`) are stored as PHP-serialised arrays wrapping the token:

```php
// image_object
serialize(['@type' => 'ImageObject', 'url' => '[node:field_image:entity:url]'])
// → 'a:2:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:29:"[node:field_image:entity:url]";}'

// place
serialize(['@type' => 'Place', 'name' => '[node:field_location:value]'])
```

The `SchemaMetatagApplier` reads the plugin's `property_type` annotation to determine which wrapper to use. For property types not in the known wrapper map, it falls back to the plugin's `tree_parent` annotation.

### 7. Config write

The applier loads (or creates) the `metatag_defaults` config entity for `node__<bundle>` and **merges** the new tags into the existing `tags` array. Existing tags not in the AI suggestion (including any manually configured values) are preserved.

### 8. State tracking

Applied mappings are recorded in Drupal's State API (`ai_schema.bundle.<bundle>`), storing the timestamp, Schema.org type, confidence, and property count. This is what `schema:status` and `schema:show` read from.

---

## JSON-LD output

Once mappings are applied and config is exported, `schema_metatag` injects a `<script type="application/ld+json">` block into the `<head>` of every published node page of the configured bundle. Tokens are resolved against the entity at render time.

Example output for a `NewsArticle` mapping:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "NewsArticle",
  "headline": "Council announces new cycling infrastructure plan",
  "name": "Council announces new cycling infrastructure plan",
  "description": "The council today approved a £4m package of cycling improvements across the city centre.",
  "datePublished": "2026-06-09T09:00:00+00:00",
  "image": {
    "@type": "ImageObject",
    "url": "https://example.com/sites/default/files/styles/uncropped_lg/public/2026-06/cycling.jpg"
  },
  "author": {
    "@type": "Person",
    "name": "Sarah Jones"
  },
  "about": "Transport"
}
</script>
```

Complex types (`ImageObject`, `Person`, `Place`, etc.) are stored as PHP-serialised arrays in the metatag config and unwrapped by `schema_metatag` during rendering. The `@type` property always comes from the dedicated `schema_*_type` plugin rather than a token.

To verify output: view the source of a published node of the mapped type and search for `application/ld+json`. You can validate it with [Google's Rich Results Test](https://search.google.com/test/rich-results) or the [Schema.org validator](https://validator.schema.org/).

---

## Schema.org type → sub-module map

The registry maintains a static map of Schema.org class names to their schema_metatag sub-modules. The following types are supported:

| Schema.org type | Sub-module |
|---|---|
| Article, NewsArticle, BlogPosting, TechArticle | `schema_article` |
| Book | `schema_book` |
| Course | `schema_course` |
| Event | `schema_event` |
| HowTo | `schema_how_to` |
| ImageObject | `schema_image_object` |
| ItemList | `schema_item_list` |
| JobPosting | `schema_job_posting` |
| LocalBusiness, Organization | `schema_organization` |
| Movie | `schema_movie` |
| Person | `schema_person` |
| Place | `schema_place` |
| Product | `schema_product` |
| QAPage | `schema_qa_page` |
| Recipe | `schema_recipe` |
| Review | `schema_review` |
| Service | `schema_service` |
| SpecialAnnouncement | `schema_special_announcement` |
| WebPage | `schema_web_page` |
| WebSite | `schema_web_site` |

If Claude suggests a type whose sub-module isn't in this map, the module cannot auto-enable it but will still attempt to write mappings using whatever plugins are currently available.

---

## Notes and caveats

**Complex properties are minimal wrappers.** For `Place`, `Person`, `Organization`, and similar types, the module writes a two-key serialised object: `@type` + the single most-useful token. Full nested objects (e.g. a Place with a PostalAddress sub-object, or a Person with `sameAs` social links) require manual configuration in the metatag UI or direct YAML editing after the initial apply.

**The module only covers node content types.** Taxonomy terms, users, and media entities are not in scope for AI mapping, though metatag defaults for those can still be configured through the normal UI.

**Config export is manual.** After running `schema:apply`, run `drush cex` to write the changes to your config sync directory. The module writes to the active config store, not directly to YAML files.

**Re-applying overwrites previous AI mappings.** Running `schema:apply` on a type that was already mapped will overwrite any tags in the accepted suggestion, including ones previously written by this module. Manually configured tags on properties the AI does *not* suggest are preserved.

**The `schema:reset` command only clears state, not config.** After resetting, `schema:status` shows the type as unmapped, but the metatag config entity still contains the previous mappings. Running `schema:apply` again will overwrite them.

---

## Troubleshooting

**`Command "schema:apply" is not defined`**
Drush command registration requires a cache rebuild after the module is first installed:
```bash
drush cr
```
Confirm the module is enabled: `drush pm:list --filter=ai_schema`.

---

**AI query fails with "AI query failed"**
- Confirm `drupal/ai` and `drupal/ai_provider_anthropic` are installed and enabled
- Check that `ANTHROPIC_API_KEY` is set in the environment (`.env` or server config)
- Review Drupal logs at `/admin/reports/dblog` for the full error from the AI module
- Verify the API key has sufficient quota in the Anthropic console

---

**Empty mappings returned despite the sub-module being installed**
This indicates a stale plugin cache. Run a full cache rebuild:
```bash
drush cr
drush schema:apply <bundle>
```
The module calls `clearCachedDefinitions()` before each query, but a full rebuild is needed if the sub-module was installed outside this module's normal flow (e.g. via `drush pm:install` directly in a prior session).

---

**JSON-LD not appearing in the page source**
- Confirm `schema_metatag` (the core module, not just sub-modules) is enabled
- Clear caches after applying: `drush cr`
- Check that the node being viewed is of the configured bundle type and is published
- Verify the config was exported and imported: `drush cex` then `drush cim` (or check active config directly):
  ```bash
  drush config:get metatag.metatag_defaults.node__article
  ```

---

**Suggested type is wrong**
- Reset and re-run: `drush schema:reset <bundle> && drush schema:apply <bundle>`
- Add a description to the content type at `/admin/structure/types/manage/<bundle>`; Claude uses it as primary context for type selection
- If the type has no published nodes, use `--exclude-samples` to prevent Claude drawing incorrect inferences from an empty sample set

---

**Token values not resolving in the page output**
- Verify the field machine name is correct: token names match field machine names exactly
- For entity references, the referenced entity must be published and the field populated
- For image style tokens, confirm the style name exists at `/admin/config/media/image-styles`
- Check token syntax uses square brackets only: `[node:title]`, not `{node:title}` or `{{ node.title }}`

---

## Extending

To add new Schema.org type → sub-module mappings, edit the `TYPE_TO_MODULE` constant in `SchemaMetatagRegistry`. To add complex property wrappers for property types not yet handled, edit `COMPLEX_WRAPPERS` in both `SchemaMetatagRegistry` and `SchemaMetatagApplier`.

The `SchemaAiSuggester` prompt can be modified to change the AI's behaviour, for example to constrain which token patterns it may use or to give it additional context about your project's field naming conventions.

---

## API usage

The four services can be injected via the service container or retrieved with `\Drupal::service()` for custom integrations:

```php
// Inspect a content type's fields and load sample content values.
$inspector = \Drupal::service('ai_schema.content_type_inspector');
$info    = $inspector->inspectNodeType('article');   // fields, label, description
$samples = $inspector->getSampleValues('article');   // field_name → plain-text preview

// Query available Schema.org types from enabled sub-modules,
// and the full vocabulary including uninstalled types.
$registry      = \Drupal::service('ai_schema.metatag_registry');
$installed     = $registry->getAvailableTypes();         // installed only, with plugin IDs
$allKnown      = $registry->getAllKnownSchemaTypes();    // full map with enabled status
$isEnabled     = $registry->isSchemaTypeEnabled('NewsArticle');

// Run the AI suggestion.
$suggester  = \Drupal::service('ai_schema.suggester');
$suggestion = $suggester->suggest($info, $installed, [], $allKnown, $samples);

// Apply accepted mappings to metatag config.
$applier = \Drupal::service('ai_schema.applier');
$applier->apply('article', $suggestion, $suggestion['mappings']);

// Read back the recorded state.
$state = $applier->getMappingState('article');
// ['schema_type' => 'NewsArticle', 'confidence' => 'high', 'applied_count' => 9, ...]
```

The `suggest()` return value shape:

```php
[
  'schema_type'        => 'NewsArticle',
  'group'              => 'schema_article',
  'confidence'         => 'high',   // 'high' | 'medium' | 'low'
  'rationale'          => 'Explicit news content type with author and publish date fields.',
  'type_tag'           => ['plugin_id' => 'schema_article_type', 'value' => 'NewsArticle'],
  'mappings'           => [
    [
      'field_machine_name' => 'title',
      'plugin_id'          => 'schema_article_name',
      'property_label'     => 'name',
      'token'              => '[node:title]',
      'is_complex'         => false,
      'confidence'         => 'high',
      'rationale'          => 'Title is the article name.',
    ],
    // ...
  ],
  'skipped_properties' => ['publisher', 'speakable'],
  'unmapped_fields'    => ['field_slices', 'field_hero_media'],
]
```

Pass an empty array as `$sampleValues` to skip content sampling, equivalent to the `--exclude-samples` flag.
