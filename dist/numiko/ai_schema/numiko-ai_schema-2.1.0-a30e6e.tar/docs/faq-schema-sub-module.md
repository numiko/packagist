# Future feature: FAQPage schema sub-module (`ai_schema_faq`)

**Status:** Proposed  
**Schema.org type:** [FAQPage](https://schema.org/FAQPage)  
**Depends on:** `ai_schema`, `paragraphs`

---

## Problem

FAQPage JSON-LD requires a repeating list of `Question` / `Answer` pairs. The `schema_metatag` approach stores tag values as single-value tokens, so it cannot represent this structure. A dedicated sub-module is needed that bypasses metatag entirely, builds its own `<script type="application/ld+json">` block, and attaches it to the page.

---

## Output strategy

The FAQPage block is always an **additional** JSON-LD block. It never replaces the main schema type configured via `ai_schema`. A page with `Article` schema keeps that intact; the FAQ block appears as a second script tag. Google's structured data guidelines explicitly allow multiple JSON-LD blocks on a single page.

Example output:

```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What are your opening hours?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "We are open Tuesday to Sunday, 10am to 5pm."
      }
    }
  ]
}
```

---

## SiteKit accordion structure

The existing accordion paragraph structure in this project is:

```
node.field_slices  (entity_reference_revisions)
  └─ paragraph:slice_accordion
      ├─ field_title    (string)     accordion section heading
      ├─ field_summary  (text_long)  optional intro text
      └─ field_items    (entity_reference_revisions)
           └─ paragraph:accordion_item
               ├─ field_title    (string)    the question
               └─ field_content  (text_long) the answer
```

The `accordion_item` paragraph type is the atomic unit for FAQ data. The two field name conventions to keep in mind are:

- Question: `field_title`
- Answer: `field_content`

---

## Data source strategies

### Option A: Dedicated field (recommended for new setups)

`drush schema:faq:provision <bundle>` creates a `field_faq` field (entity_reference_revisions, target: `accordion_item`) directly on the content type. No slice wrapper is needed. Editorial intent is explicit because the FAQ content lives in its own field, separate from the slice builder.

```
node.field_faq  (entity_reference_revisions)
  └─ paragraph:accordion_item
      ├─ field_title    (question)
      └─ field_content  (answer)
```

**Trade-off:** editors use a second accordion-style field rather than the slice builder, which may feel inconsistent with how other structured content is managed.

### Option B: Mapped from existing `slice_accordion` slices

No new field is created. The renderer scans `field_slices` for `slice_accordion` paragraphs and collects all their `field_items`. Works immediately on content types that already have FAQ-style accordion slices built using the standard slice builder.

**Trade-off:** a page may contain multiple `slice_accordion` instances (for example "Technical specifications" and "Frequently asked questions"). Without a way to mark which slices are FAQ-relevant, the renderer must either use all of them (potentially wrong) or require a new boolean field such as `field_is_faq` on `slice_accordion` to flag editorial intent.

### Recommended approach

Ship Option A as the default for new setups. Support Option B for content types that already use accordion slices, but require one of the following:

- Accept that all `slice_accordion` paragraphs on the page contribute FAQ data (suitable only when a content type is exclusively used for FAQ pages), or
- Add a `field_is_faq` boolean to `slice_accordion` to allow editors to designate individual slices.

Both sources are configurable per bundle in the module settings.

---

## Module structure

```
ai_schema_faq/
├── ai_schema_faq.info.yml           # depends: ai_schema, paragraphs
├── ai_schema_faq.module              # hook_page_attachments
├── ai_schema_faq.services.yml
├── ai_schema_faq.routing.yml         # admin settings routes
├── drush.services.yml
├── config/
│   ├── install/
│   │   └── ai_schema_faq.settings.yml    # default: empty bundle map
│   └── schema/
│       └── ai_schema_faq.settings.yml    # config schema definition
└── src/
    ├── Commands/
    │   └── FaqSchemaCommands.php     # drush schema:faq:*
    ├── Form/
    │   └── FaqBundleSettingsForm.php
    └── Service/
        ├── FaqFieldProvisioner.php   # creates field_faq on a bundle
        └── FaqJsonLdBuilder.php      # builds the JSON-LD array from a node
```

---

## Configuration schema

Settings are stored as exportable config (not State), so they go into version control with `drush cex`.

```yaml
# ai_schema_faq.settings.yml

bundles:
  article:
    enabled: true
    source: direct              # direct | slice
    field: field_faq            # (source=direct) paragraphs field on the node
    question_field: field_title
    answer_field: field_content

  event:
    enabled: true
    source: slice               # use existing slice_accordion paragraphs
    slice_field: field_slices
    question_field: field_title
    answer_field: field_content
```

---

## Drush commands

| Command | What it does |
|---|---|
| `drush schema:faq:status` | Table showing each bundle: enabled, source, field, Q&A count from a sample node |
| `drush schema:faq:provision <bundle>` | Interactive wizard: detects existing accordion fields or creates `field_faq`, saves config |
| `drush schema:faq:enable <bundle> --field=<name>` | Non-interactive: enable FAQ schema for a bundle using a named field |
| `drush schema:faq:disable <bundle>` | Disables FAQ schema for a bundle without removing its config entry |

### `provision` wizard flow

1. Inspect the bundle for paragraphs fields that reference `accordion_item`. List them as candidates.
2. If candidates are found: offer to use one (Option B / slice), or create a dedicated `field_faq` (Option A).
3. If no candidates are found: create `field_faq` automatically. Confirm paragraph type (`accordion_item`) and the question / answer field mapping.
4. Write config. Remind the user to run `drush cex`.

---

## Service: `FaqJsonLdBuilder`

```php
public function build(NodeInterface $node, array $bundleConfig): ?array
```

Responsibilities:

- Resolves the correct strategy (`direct` vs `slice`) from the bundle config.
- Loads paragraph entities, strips HTML tags from answer text. Google's rich results validator rejects HTML in `acceptedAnswer.text`; stripping automatically is safer than relying on editorial discipline.
- Returns `null` if fewer than one Q&A pair is found, so no empty blocks are attached to the page.
- Does not output anything. The caller (`hook_page_attachments`) handles attaching the result.

---

## Rendering hook

`hook_page_attachments` only runs on `entity.node.canonical` routes. It:

1. Loads the current node.
2. Checks whether the bundle is enabled in config.
3. Calls `FaqJsonLdBuilder::build()`.
4. If a non-null result is returned, attaches it as a `<script type="application/ld+json">` tag.

There is no impact on pages where FAQ schema is not configured.

---

## Open decisions

These need to be resolved before implementation begins.

### 1. Option A only, or both A and B?

Option A (dedicated field) is simpler and unambiguous. Option B is useful for existing content but requires a policy decision about which accordion slices count as FAQ data. If the project only ever needs FAQ content on content types that are exclusively FAQ pages, Option B with "all accordion slices" is fine. Mixed-purpose content types need the `field_is_faq` flag approach.

### 2. Admin UI or Drush only?

A settings form at `/admin/config/search/schema-faq` makes the module manageable by site builders without CLI access. Drush-only is acceptable for a developer tool. An admin UI also allows non-technical editors to see which content types have FAQ schema active.

### 3. `schema:status` integration

Should the existing `drush schema:status` command include a FAQ column, or should FAQ status live exclusively in `drush schema:faq:status`? Integrating into `schema:status` gives a single overview; keeping it separate avoids changing the existing command's output contract.

### 4. `schema:suggest` integration

Could `schema:suggest` detect accordion-capable fields on a bundle and recommend enabling `ai_schema_faq`? This would make the AI suggestion workflow aware of the sub-module rather than requiring the developer to discover it separately.
