# AI-Powered Schema.org Mapping for Drupal: How We Built It and Why

Schema.org structured data is one of those things that every project should have and almost none do well. The vocabulary is vast, the Drupal module landscape is fragmented, and the gap between "technically possible" and "actually configured" is wide enough that most sites end up with generic Open Graph tags and nothing more. This article documents the thinking behind `ai_schema` — a Drupal module that uses Claude to close that gap automatically.

---

## The problem

Structured data matters. Google's documentation for rich results — event cards, recipe panels, job listings, article bylines — all depend on Schema.org JSON-LD in the page head. The vocabulary is well-maintained and deeply cross-referenced at [schema.org](https://schema.org/), covering thousands of types and properties. The tooling for Drupal, however, presents a recurring problem: there is a wide choice of approaches, none of which makes it easy to get from "here are our content types" to "here is working Schema.org JSON-LD in the head of every page" without significant manual work.

The specific challenge on every new project is this: content types exist with real fields, real labels, real data structures. Someone needs to translate those into Schema.org properties and then configure a module to emit them. That translation is almost always done by hand, it takes time, it requires knowledge of both the Schema.org vocabulary and the Drupal module internals, and it frequently gets deferred until it's too late to do it properly.

We wanted a solution that could bootstrap this work in minutes, grow incrementally as a project develops, and be repeatable across projects.

---

## Evaluating the module landscape

Before writing any code, we reviewed the available options.

### schema.org (D7 era — avoid)

The module at [drupal.org/project/schemaorg](https://www.drupal.org/project/schemaorg) predates Drupal 8. It outputs RDFa 1.0 microdata, maps Schema.org terms to content types via a configuration UI, and has not been maintained since 2015. It is not covered by Drupal's security advisory policy and has no Drupal 8/9/10 release. Nothing useful here.

### Schema.org Blueprints (schemadotorg)

The most ambitious option is [drupal.org/project/schemadotorg](https://www.drupal.org/project/schemadotorg), maintained by Jacob Rockowitz. His detailed configuration blog post at [jrockowitz.com/blog/schemadotorg-configuration](https://www.jrockowitz.com/blog/schemadotorg-configuration) is genuinely excellent — thorough, well-reasoned, with real examples. The module itself is a paradigm shift: rather than mapping existing Drupal content types to Schema.org, it generates content types, fields, and relationships *from* Schema.org definitions. The vocabulary drives the information architecture.

This approach has real merit for greenfield projects where you are designing content types from scratch and want them to be schema-aligned from the start. The 50+ sub-modules include industry starter kits, JSON:API integration, and support for Next.js front-ends.

The reasons we did not use it here:

1. **Alpha status.** At the time of writing, no stable release exists. The module is in active development, the API changes between releases, and adopting it as a starter-kit dependency would mean tracking a moving target.

2. **Structural commitment.** Blueprints wants to own your content model. On projects with existing content types — or on a starter kit where content types have already been designed by a team — this is a significant impediment. There is no smooth path from "we have an event content type" to Blueprints without either rebuilding the type from scratch or accepting a mismatch.

3. **Complexity floor.** The initial investment to learn and configure Blueprints is high. It rewards projects that fully commit to the Schema.org model. For a "deploy and grow" approach across many different project types, it adds too much friction.

Rockowitz's blog post is still worth reading. His analysis of the Schema.org property hierarchy and the reasoning behind the blueprint-first approach informed our understanding of the vocabulary structure even though we chose a different implementation path.

### Schema Metatag (schema_metatag)

[drupal.org/project/schema_metatag](https://www.drupal.org/project/schema_metatag) is the pragmatic choice. It extends the Metatag module with Schema.org-aware tag plugins, outputs JSON-LD in the `<head>`, and requires no changes to content type structure. Each Schema.org type is a separate sub-module (`schema_event`, `schema_article`, `schema_person`, etc.). Configuration is stored in `metatag.metatag_defaults` config entities, one per content type, and exports cleanly to YAML.

The module is stable, actively maintained, and widely deployed. The configuration UI works, but it has two friction points that matter at scale: you must work through each content type manually, and there is no discovery layer — you need to know which Schema.org type fits your content before you open the form.

**This is the module we built on.** The goal was to keep all of schema_metatag's strengths — stable, config-exportable, well-understood — while removing the manual work of deciding types and mapping fields.

---

## Why a custom Drush module rather than something else

Three other approaches were considered:

**Drush config commands.** You could write a Drush script that imports pre-authored metatag YAML. This is brittle — it requires the YAML to be correct for every project, and field names differ. It also doesn't give you the "tell me what to map" step.

**A Drupal configuration form.** A UI for selecting Schema.org types and mapping fields is possible, but it moves the problem back to the browser and adds complexity with no clear advantage over what schema_metatag's own UI already provides.

**schema_metatag's built-in configuration.** Perfectly functional, but requires someone who understands Schema.org to map each content type by hand. On a 10-type content model, that is a non-trivial amount of work, and the result sits in the UI rather than in code review.

A Drush command is the right answer because:
- It is repeatable and scriptable
- It works against the live content type and field definitions, so it is always accurate
- It can be run incrementally as new content types are added
- The output is standard config YAML that lands in source control
- It fits the existing developer workflow on this project

---

## What we learned by inspecting schema_metatag's internals

Before writing the AI prompt, we needed to understand how schema_metatag actually stores its configuration. This turned out to be more interesting than expected.

### Plugin structure

Every Schema.org property is a metatag tag plugin annotated with `@MetatagTag`. The annotations carry three fields that are critical for programmatic configuration:

**`group`** — all plugins for a given Schema.org type share the same group string (e.g. `schema_event`). This is how we discover which properties belong to which type.

**`property_type`** — declares how the value should be stored. Simple properties (`text`, `date`, `url`, `boolean`) store plain strings — a Drupal token like `[node:title]` or `[node:field_start_date:date:html_datetime]`. Complex properties (`image_object`, `place`, `person`, `organization`, `offer`) store PHP-serialised arrays.

**`tree_parent`** — for complex types, lists the Schema.org class or classes that the value should be an instance of (`Place`, `ImageObject`, `Person`).

### The serialisation format

Complex property values in schema_metatag are stored as PHP `serialize()` output containing an associative array. An image stored as an `ImageObject` looks like this in the config YAML:

```yaml
schema_event_image: 'a:2:{s:5:"@type";s:11:"ImageObject";s:3:"url";s:29:"[node:field_image:entity:url]";}'
```

This is standard PHP serialisation of `['@type' => 'ImageObject', 'url' => '[node:field_image:entity:url]']`. The token is embedded *inside* the serialised value and is replaced when Metatag renders the tag.

This format is not documented anywhere obvious, but it is consistent across all complex property types. Once you know to look for it, the pattern is clear: `@type` sets the Schema.org class, and one additional key holds the token for the most semantically relevant property of that class.

A fully nested object — for example, a `Place` with a `PostalAddress` containing street, city, postcode — would extend this structure:

```php
serialize([
  '@type' => 'Place',
  'name' => '[node:field_location:value]',
  'address' => serialize([
    '@type' => 'PostalAddress',
    'streetAddress' => '...',
    'addressLocality' => '...',
  ]),
])
```

For our purposes, we handle the minimal case: each complex type is wrapped with a two-key array containing `@type` and the single most useful token. Fully nested address structures or multiple performers with individual URLs require manual editing after the initial apply.

### Plugin discovery via MetatagTagPluginManager

Rather than hard-coding a list of property names, the module queries the live plugin manager:

```php
$definitions = $this->tagPluginManager->getDefinitions();
foreach ($definitions as $pluginId => $definition) {
    $group = $definition['group'];
    if (!str_starts_with($group, 'schema_')) continue;
    // $pluginId is the key used in the tags array: 'schema_event_name', etc.
    // $definition['property_type'] tells us how to store the value
}
```

This means the module always reflects what is actually installed. If a project enables `schema_recipe`, the recipe properties become available immediately. The module has no stale list to maintain.

---

## The AI field mapping problem

The hard part of Schema.org configuration is not knowing what `schema_event_start_date` is for — it's knowing that `field_event_start_date` (or `field_date_from`, or `field_commencement_date`) is the right field to map to it. This is a semantic matching problem: connect field machine names, labels, and types to Schema.org property identifiers.

An LLM is well-suited to this. It has broad knowledge of Schema.org, understands Drupal field naming conventions, can reason about `field_type` values (`datetime`, `image`, `entity_reference`), and can produce confidence ratings when the match is ambiguous.

### What we send to Claude

The prompt contains:
- The content type machine name, human label, and description
- Every content field with its machine name, label, Drupal field type, and cardinality
- The complete list of available plugin IDs and their descriptions, grouped by Schema.org type — exactly as discovered from the plugin manager
- The existing non-schema metatag configuration for the bundle (see below)
- Sitekit field conventions (see below)
- A reference sheet of Drupal token patterns for common field types

Sending the live plugin list is important. Claude knows what `schema.org/Event` is, but it does not know that the Drupal plugin for the `startDate` property has the ID `schema_event_start_date`. By passing the actual plugin IDs, we ensure that what Claude returns can be written directly to config without any additional translation step.

### Using existing metatag config as context

The first version of the module sent Claude nothing but the field list, available plugins, and a generic token reference. The suggestions it produced were structurally correct but had two recurring problems.

**Description fields.** Claude would map `body` to description properties. On sitekit projects, `body` is the full rich-text content of the page — rarely what you want as a Schema.org description. The correct field is `field_teaser_summary`, a short plain-text summary that is already used as the page's meta description. Claude had no way to know this from field names alone.

**Image tokens.** The generic token reference offered `[node:FIELD_NAME:entity:url]` for images. But schema_metatag expects an image URL token that includes a named image style — `[node:field_image:entity:field_image:uncropped_lg:url]` — to serve a web-optimised rather than a raw file URL. Claude would produce tokens that were technically valid but wrong for structured data.

Both problems have the same root cause: the project already has the right answers configured, in the Open Graph and standard metatag tags, and the AI simply wasn't being shown them.

The fix is to load the existing `metatag.metatag_defaults` configuration for the bundle — inheriting from `global` → `node` → bundle-specific — filter out any schema tags (those are what we're generating), and pass the remainder to the prompt:

```
EXISTING METATAG CONFIGURATION (tokens already in use for this content type):
  canonical_url                  → [node:url]
  description                    → [node:field_teaser_summary]
  og_description                 → [node:field_teaser_summary]
  og_image                       → [node:field_image:entity:field_image:uncropped_lg:url]
  image_src                      → [node:field_image:entity:field_image:uncropped_lg:url]
```

Claude now sees that `field_teaser_summary` is the description field for this project, and that `uncropped_lg` is the image style in use — and mirrors both in its Schema.org suggestions. PHP-serialised values in the existing config (e.g. complex Place or ImageObject wrappers from earlier schema_metatag configuration) are deserialised to JSON before being included, so Claude sees readable structure rather than serialised strings.

### Sitekit field conventions

Alongside the existing metatag context, the prompt includes a small set of explicit project conventions that are stable across all sitekit projects:

- `field_teaser_summary` is the standard short summary field — always prefer it over `body` for description-type properties
- Image tokens must include an image style — never suggest a raw `:url` token; match the style already used in `og_image`
- `field_publish_date` is the editorial publication date — use it for `datePublished` rather than the system `created` timestamp
- `field_author` is the author entity reference — use it for `author` properties

These are not things an LLM could reliably infer from field machine names alone. Making them explicit removes a category of wrong suggestions without narrowing Claude's latitude on anything genuinely ambiguous.

### What Claude returns

```json
{
  "schema_type": "Event",
  "group": "schema_event",
  "confidence": "high",
  "rationale": "Content type has date range, booking link, and performer fields consistent with an Event.",
  "type_tag": {
    "plugin_id": "schema_event_type",
    "value": "Event"
  },
  "mappings": [
    {
      "field_machine_name": "field_event_start_date",
      "plugin_id": "schema_event_start_date",
      "property_label": "startDate",
      "token": "[node:field_event_start_date:date:html_datetime]",
      "is_complex": false,
      "confidence": "high",
      "rationale": "Start date field maps directly to startDate."
    },
    {
      "field_machine_name": "field_image",
      "plugin_id": "schema_event_image",
      "property_label": "image",
      "token": "[node:field_image:entity:url]",
      "is_complex": true,
      "confidence": "high",
      "rationale": "Featured image maps to image property."
    }
  ],
  "skipped_properties": ["review", "aggregateRating"],
  "unmapped_fields": ["field_category", "field_slices"]
}
```

The `is_complex` flag tells the applier whether to wrap the token in a serialised object. The `skipped_properties` and `unmapped_fields` lists are surfaced to the developer as a record of what the automation did not cover.

### Prompt-based JSON rather than structured output

Anthropic's API supports strict JSON schemas via structured output. We initially explored this but found that prompting for raw JSON (with instructions to return nothing else) is more practical: the instruction `"Your response must be valid JSON and nothing else"` is consistently followed, and we strip any accidental markdown fences before parsing. This avoids having to maintain a full JSON Schema definition for the response shape alongside the code.

---

## The Drush workflow in practice

The interactive design reflects how this kind of configuration work actually happens on a project.

`schema:suggest` is a safe preview. Run it on a new content type to see what the AI proposes before committing to anything. It answers the question: "Does this make sense?" in under ten seconds.

`schema:apply` with the default interactive prompt gives the developer a checkpoint. The three-way choice — Accept All / Review Each / Skip — covers the common cases cleanly. For a content type whose fields are unambiguously mapped (an `event` with `field_start_date`, `field_end_date`, `field_image`, `field_booking_link`), accepting all is right. For a content type with more ambiguous fields, Review Each lets you skip anything that doesn't look right.

`--auto-accept` exists for CI pipelines and bulk initial setup, where the goal is to get baseline mappings in place quickly and refine them later.

The sub-module enablement step was a deliberate design choice. Rather than requiring the developer to know and pre-install all the schema_metatag sub-modules they might need, the module detects when one is missing and asks in the moment. Enabling it re-queries the AI so the final mapping uses the full property set, not a fallback list.

---

## What this gives us

Running `drush schema:apply --all --auto-accept` on a fresh project installation with 10 content types takes roughly two minutes and produces complete `metatag.metatag_defaults.node__*.yml` entries for every type. Each entry includes the correct `@type` declaration, date tokens in ISO 8601 format, image tokens wrapped as `ImageObject`, and property mappings at the appropriate confidence levels.

The result is not a finished Schema.org implementation — some properties genuinely need site-specific static values (a location address, an organisation name, an attendance mode), and complex nested structures require manual review. But the baseline is solid, it is in source control, and it is correct enough to pass Google's Rich Results Test for the properties it covers.

More importantly, the module grows with the project. When a new content type is added, `drush schema:apply <new-type>` handles it in the same way. When `schema:status` shows a type as unmapped, the path to mapping it is a single command.

---

## An architectural question: could this work without schema_metatag sub-modules at all?

Once the module was working, an obvious question surfaced: every Schema.org type still requires a schema_metatag sub-module and a set of PHP plugin classes. `schema_article` must be enabled for NewsArticle. `schema_person` must be enabled for Person. The sub-module enablement step in `schema:apply` handles this smoothly in practice, but it is a real coupling — a new Schema.org type on a future project means a sub-module must exist for it.

So we looked at whether the per-plugin-per-property architecture could be replaced with something dynamic: a single plugin for all Schema.org types.

### How schema_metatag actually renders JSON-LD

To evaluate this, we needed to understand the rendering pipeline. It works in two stages:

1. Each property plugin's `output()` method returns a `<meta>` render array, marked with a `schema_metatag: TRUE` attribute. This is not a real HTML attribute — it is a marker that survives the render pipeline.

2. `schema_metatag_page_attachments_alter()` scans all page head attachments for the marker, groups them by their `group` value (e.g. `schema_event`), extracts the name/content pairs into a nested array, removes the original meta tags, and re-renders the whole group as a single `<script type="application/ld+json">` block.

This is why each property needs its own plugin: the framework needs individual meta tag outputs so it can collect, group, and reorganise them into a JSON structure.

### What a single-plugin approach would look like

The alternative is to sidestep that pipeline entirely. A single `ai_schema_json_ld` metatag tag plugin would store the complete Schema.org object as a JSON string with Drupal tokens embedded as string values:

```json
{
  "@context": "https://schema.org",
  "@type": "Event",
  "name": "[node:title]",
  "startDate": "[node:field_start_date:date:html_datetime]",
  "image": {
    "@type": "ImageObject",
    "url": "[node:field_image:entity:url]"
  }
}
```

Rendering would move to a `hook_page_attachments_alter()` in `ai_schema.module`, which reads the stored template, processes tokens, and outputs the script tag directly — bypassing schema_metatag's collection pipeline entirely.

The critical detail is token escaping. You cannot do naive string replacement on a JSON template, because a token value containing `"` or `&` would produce invalid JSON. The safe approach is decode-first: parse the JSON template to a PHP array, call `token_replace()` on each string value (yielding raw PHP strings), then re-encode with `json_encode()`, which handles all escaping correctly. The raw string `The Beatles & Strings` becomes `"The Beatles & Strings"` in the output automatically.

This approach would also simplify the AI prompt considerably. Instead of generating an array of `{field, plugin_id, token}` mappings that the applier assembles into individual metatag tags, Claude would generate the complete JSON-LD object directly — which is a more natural thing for it to produce and easier to review.

The module's dependency on `schema_metatag` could be dropped entirely. Only the base `metatag` module would be needed.

### Why we did not implement it

The per-property plugin architecture has one genuine advantage: the metatag admin UI at `/admin/config/search/metatag` gives site builders a form with individual fields for each Schema.org property, with token autocomplete. With the single-plugin approach, that becomes a textarea containing a JSON blob. For projects where schema.org is configured entirely by developers via Drush and exported to config YAML, this is an acceptable — arguably preferable — trade-off. For projects where a site builder maintains these settings through the admin interface, it is a meaningful regression in usability.

Since the primary workflow for this module is Drush-driven and developer-owned, the single-plugin approach is the cleaner architecture. It is the direction the module should move if it outgrows its current scope. The implementation is well-understood; the decision not to make that change now is about keeping the scope bounded, not about any technical obstacle.

---

## What we would do differently / next steps

**Manual value prompts.** Some schema_metatag properties benefit from static values that the AI cannot know — `schema_event_organizer` (the site's own organisation), `schema_event_event_status`, postal addresses. The module currently skips these. A useful extension would be a second interactive pass that asks the developer to fill in the most important static values by hand.

**Taxonomy term and user mappings.** Schema.org matters beyond node content types. A `Person` taxonomy term that becomes a Schema.org `Person` with `sameAs` social links, or a Drupal user profile mapped to `schema.org/Person`, would follow exactly the same pattern. The field introspection and AI prompt are both already capable of this; only the `ContentTypeInspector` would need to be extended.

**Review and update flow.** Currently, re-running `schema:apply` on an already-mapped type overwrites the previous result. A smarter mode could compare the previous suggestion against the current one and surface only what changed — useful when a content type gains new fields.

**Token validation.** The AI constructs token strings based on a pattern reference, but it does not verify that the token resolves in the actual site. A post-apply validation step using the Token module's API to test each generated token would catch hallucinated token paths before they land in config.
