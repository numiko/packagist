<?php

declare(strict_types=1);

namespace Drupal\ai_schema\Commands;

use Drupal\ai_schema\Service\ContentTypeInspector;
use Drupal\ai_schema\Service\SchemaAiSuggester;
use Drupal\ai_schema\Service\SchemaMetatagApplier;
use Drupal\ai_schema\Service\SchemaMetatagRegistry;
use Drush\Attributes as CLI;
use Drush\Commands\DrushCommands;

final class SchemaAiCommands extends DrushCommands {

  public function __construct(
    private readonly ContentTypeInspector $inspector,
    private readonly SchemaMetatagRegistry $registry,
    private readonly SchemaAiSuggester $suggester,
    private readonly SchemaMetatagApplier $applier,
  ) {
    parent::__construct();
  }

  // ---------------------------------------------------------------------------
  // Commands
  // ---------------------------------------------------------------------------

  #[CLI\Command(name: 'schema:status')]
  #[CLI\Usage(name: 'drush schema:status', description: 'Show schema mapping status for all node content types')]
  public function status(): void {
    $nodeTypes = $this->inspector->getAllNodeTypes();
    $rows = [];

    foreach ($nodeTypes as $bundle => $label) {
      $state = $this->applier->getMappingState($bundle);
      $rows[] = [
        $bundle,
        $label,
        $state ? '✓ Mapped' : '— Not mapped',
        $state ? $state['schema_type'] : '',
        $state ? date('Y-m-d', $state['timestamp']) : '',
        $state ? (string) $state['applied_count'] : '',
      ];
    }

    $this->io()->table(['Bundle', 'Label', 'Status', 'Schema Type', 'Applied', 'Properties'], $rows);
  }

  #[CLI\Command(name: 'schema:suggest')]
  #[CLI\Argument(name: 'bundle', description: 'Node content type machine name')]
  #[CLI\Option(name: 'exclude-samples', description: 'Skip loading sample content values (use when content is sensitive)')]
  #[CLI\Usage(name: 'drush schema:suggest event', description: 'Show AI suggestions for a content type without applying')]
  #[CLI\Usage(name: 'drush schema:suggest event --exclude-samples', description: 'Show suggestions without sending content values to the AI')]
  public function suggest(string $bundle, array $options = ['exclude-samples' => FALSE]): void {
    $suggestion = $this->fetchSuggestion($bundle, (bool) $options['exclude-samples']);
    if (!$suggestion) {
      return;
    }

    $this->displaySuggestion($suggestion);

    if (isset($suggestion['_install_required'])) {
      $this->io()->warning(sprintf(
        '%s is not enabled. Run: drush schema:apply %s',
        $suggestion['_install_required'],
        $bundle,
      ));
    }
    else {
      $this->io()->note('Dry run — no changes made. Use drush schema:apply to apply.');
    }
  }

  #[CLI\Command(name: 'schema:apply')]
  #[CLI\Argument(name: 'bundle', description: 'Node content type machine name (omit with --all)')]
  #[CLI\Option(name: 'all', description: 'Process every unmapped content type')]
  #[CLI\Option(name: 'auto-accept', description: 'Accept all suggestions without interactive review')]
  #[CLI\Option(name: 'exclude-samples', description: 'Skip loading sample content values (use when content is sensitive)')]
  #[CLI\Usage(name: 'drush schema:apply event', description: 'AI-map and apply schema to the event content type')]
  #[CLI\Usage(name: 'drush schema:apply --all', description: 'Apply schema mappings to all unmapped types')]
  #[CLI\Usage(name: 'drush schema:apply --all --auto-accept', description: 'Apply all mappings non-interactively')]
  #[CLI\Usage(name: 'drush schema:apply event --exclude-samples', description: 'Apply without sending content values to the AI')]
  public function apply(string $bundle = '', array $options = ['all' => FALSE, 'auto-accept' => FALSE, 'exclude-samples' => FALSE]): void {
    if ($options['all']) {
      $nodeTypes = $this->inspector->getAllNodeTypes();
      foreach (array_keys($nodeTypes) as $b) {
        if (!$this->applier->getMappingState($b)) {
          $this->io()->section("Processing: $b");
          $this->runApply($b, (bool) $options['auto-accept'], (bool) $options['exclude-samples']);
        }
      }
      return;
    }

    if (!$bundle) {
      $this->io()->error('Provide a bundle name, or use --all.');
      return;
    }

    $this->runApply($bundle, (bool) $options['auto-accept'], (bool) $options['exclude-samples']);
  }

  #[CLI\Command(name: 'schema:show')]
  #[CLI\Argument(name: 'bundle', description: 'Node content type machine name')]
  #[CLI\Usage(name: 'drush schema:show event', description: 'Show the recorded schema mapping state for a content type')]
  public function show(string $bundle): void {
    $state = $this->applier->getMappingState($bundle);
    if (!$state) {
      $this->io()->warning("'$bundle' has no recorded schema mappings. Run: drush schema:apply $bundle");
      return;
    }

    $this->io()->definitionList(
      ['Bundle' => $bundle],
      ['Schema type' => 'schema.org/' . $state['schema_type']],
      ['Group' => $state['group']],
      ['Confidence' => $state['confidence']],
      ['Rationale' => $state['rationale']],
      ['Properties mapped' => (string) $state['applied_count']],
      ['Last applied' => date('Y-m-d H:i', $state['timestamp'])],
    );
  }

  #[CLI\Command(name: 'schema:reset')]
  #[CLI\Argument(name: 'bundle', description: 'Node content type machine name')]
  #[CLI\Usage(name: 'drush schema:reset event', description: 'Clear schema:status record for a type (metatag config unchanged)')]
  public function reset(string $bundle): void {
    $this->applier->resetState($bundle);
    $this->io()->success("State cleared for '$bundle'. Metatag config is unchanged. Re-run: drush schema:apply $bundle");
  }

  // ---------------------------------------------------------------------------
  // Internal helpers
  // ---------------------------------------------------------------------------

  private function fetchSuggestion(string $bundle, bool $excludeSamples = FALSE): ?array {
    try {
      $nodeTypeInfo = $this->inspector->inspectNodeType($bundle);
    }
    catch (\InvalidArgumentException $e) {
      $this->io()->error($e->getMessage());
      return NULL;
    }

    $sampleValues = $excludeSamples ? [] : $this->inspector->getSampleValues($bundle);
    $sampleNote = $excludeSamples ? ' <comment>(samples excluded)</comment>' : sprintf(' — <comment>%d field samples</comment>', count($sampleValues));

    $this->io()->text(sprintf(
      'Analysing <info>%s</info> (<comment>%s</comment>) — %d fields%s',
      $nodeTypeInfo['label'],
      $bundle,
      count($nodeTypeInfo['fields']),
      $sampleNote,
    ));
    $this->io()->text('Querying Claude...');

    $availableTypes = $this->registry->getAvailableTypes();
    $allKnownTypes = $this->registry->getAllKnownSchemaTypes();
    $existingMetatags = $this->applier->getExistingNonSchemaTags($bundle);

    try {
      $suggestion = $this->suggester->suggest($nodeTypeInfo, $availableTypes, $existingMetatags, $allKnownTypes, $sampleValues);
    }
    catch (\RuntimeException $e) {
      $this->io()->error('AI query failed: ' . $e->getMessage());
      return NULL;
    }

    // For the dry-run (suggest) command, warn if the ideal type needs installation.
    if (!$this->registry->isSchemaTypeEnabled($suggestion['schema_type'])) {
      $module = $this->registry->getModuleForSchemaType($suggestion['schema_type']);
      $suggestion['_install_required'] = $module;
    }

    return $suggestion;
  }

  private function runApply(string $bundle, bool $autoYes, bool $excludeSamples = FALSE): void {
    // Phase 1: get suggestion with currently enabled types.
    try {
      $nodeTypeInfo = $this->inspector->inspectNodeType($bundle);
    }
    catch (\InvalidArgumentException $e) {
      $this->io()->error($e->getMessage());
      return;
    }

    $sampleValues = $excludeSamples ? [] : $this->inspector->getSampleValues($bundle);
    $sampleNote = $excludeSamples ? ' <comment>(samples excluded)</comment>' : sprintf(' — <comment>%d field samples</comment>', count($sampleValues));

    $this->io()->text(sprintf(
      'Analysing <info>%s</info> (<comment>%s</comment>) — %d fields%s',
      $nodeTypeInfo['label'],
      $bundle,
      count($nodeTypeInfo['fields']),
      $sampleNote,
    ));
    $this->io()->text('Querying Claude...');

    $availableTypes = $this->registry->getAvailableTypes();
    $allKnownTypes = $this->registry->getAllKnownSchemaTypes();
    $existingMetatags = $this->applier->getExistingNonSchemaTags($bundle);

    try {
      $suggestion = $this->suggester->suggest($nodeTypeInfo, $availableTypes, $existingMetatags, $allKnownTypes, $sampleValues);
    }
    catch (\RuntimeException $e) {
      $this->io()->error('AI query failed: ' . $e->getMessage());
      return;
    }

    // Phase 2: ensure the required sub-module is enabled.
    if (!$this->registry->isSchemaTypeEnabled($suggestion['schema_type'])) {
      $module = $this->registry->getModuleForSchemaType($suggestion['schema_type']);

      if ($module) {
        $prompt = sprintf(
          "The <info>%s</info> sub-module must be enabled for schema.org/%s. Enable it now?",
          $module,
          $suggestion['schema_type'],
        );

        if ($autoYes || $this->io()->confirm($prompt)) {
          $this->io()->text("Enabling <info>$module</info>...");
          $this->applier->enableModule($module);

          // Re-query with updated available types so plugin IDs are validated.
          $availableTypes = $this->registry->getAvailableTypes();
          $allKnownTypes = $this->registry->getAllKnownSchemaTypes();
          try {
            $suggestion = $this->suggester->suggest($nodeTypeInfo, $availableTypes, $existingMetatags, $allKnownTypes, $sampleValues);
          }
          catch (\RuntimeException $e) {
            $this->io()->error('Second AI query failed: ' . $e->getMessage());
            return;
          }
        }
        else {
          $this->io()->warning("Skipped '$bundle' — required sub-module not enabled.");
          return;
        }
      }
    }

    // Phase 3: display and confirm.
    $this->displaySuggestion($suggestion);
    $acceptedMappings = $this->gatherAcceptedMappings($suggestion, $autoYes);

    if (empty($acceptedMappings)) {
      $this->io()->warning('No mappings accepted. Nothing saved.');
      return;
    }

    // Phase 4: write config.
    $this->applier->apply($bundle, $suggestion, $acceptedMappings);
    $this->io()->success(sprintf(
      "Applied %d mappings to '%s' (schema.org/%s). Export with: drush cex",
      count($acceptedMappings),
      $bundle,
      $suggestion['schema_type'],
    ));
  }

  private function displaySuggestion(array $suggestion): void {
    $this->io()->newLine();

    $confidenceTag = match ($suggestion['confidence']) {
      'high' => 'info',
      'medium' => 'comment',
      default => 'error',
    };

    $this->io()->text([
      "  Suggested type : <info>schema.org/{$suggestion['schema_type']}</info>  →  <comment>{$suggestion['group']}</comment>",
      "  Confidence     : <{$confidenceTag}>{$suggestion['confidence']}</{$confidenceTag}>",
      "  Rationale      : {$suggestion['rationale']}",
    ]);
    $this->io()->newLine();

    if (empty($suggestion['mappings'])) {
      $this->io()->text('  (No mappings yet — sub-module must be installed first)');
    }
    else {
      $rows = [];
      foreach ($suggestion['mappings'] as $mapping) {
        $dot = match ($mapping['confidence']) {
          'high' => '●●●',
          'medium' => '●●○',
          default => '●○○',
        };
        $note = $mapping['is_complex'] ? ' <comment>[wrapped]</comment>' : '';
        $rows[] = [
          $mapping['field_machine_name'],
          $mapping['property_label'],
          $mapping['token'] . $note,
          $dot,
        ];
      }
      $this->io()->table(['Field', 'Property', 'Token', 'Score'], $rows);
    }

    if (!empty($suggestion['skipped_properties'])) {
      $this->io()->text('  Skipped (no field match): ' . implode(', ', $suggestion['skipped_properties']));
    }
    if (!empty($suggestion['unmapped_fields'])) {
      $this->io()->text('  Unmapped fields: ' . implode(', ', $suggestion['unmapped_fields']));
    }
    $this->io()->newLine();
  }

  private function gatherAcceptedMappings(array $suggestion, bool $autoYes): array {
    if ($autoYes) {
      return $suggestion['mappings'];
    }

    $choice = $this->io()->choice(
      'Apply these mappings?',
      ['All', 'Review each', 'Skip'],
      'All',
    );

    if ($choice === 'Skip') {
      return [];
    }

    if ($choice === 'All') {
      return $suggestion['mappings'];
    }

    // Review mode: confirm each mapping individually.
    $accepted = [];
    foreach ($suggestion['mappings'] as $mapping) {
      $complexNote = $mapping['is_complex'] ? ' [complex → wrapped]' : '';
      $question = sprintf(
        '%s → %s: %s%s',
        $mapping['field_machine_name'],
        $mapping['property_label'],
        $mapping['token'],
        $complexNote,
      );

      if ($this->io()->confirm($question, TRUE)) {
        $accepted[] = $mapping;
      }
    }

    return $accepted;
  }

}
