<?php

declare(strict_types=1);

namespace Drupal\ai_schema\Service;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Extension\ModuleInstallerInterface;
use Drupal\Core\State\StateInterface;
use Drupal\metatag\MetatagTagPluginManager;

class SchemaMetatagApplier {

  private const SIMPLE_PROPERTY_TYPES = [
    'text', 'type', 'string', 'date', 'url', 'boolean', 'integer', 'number', 'duration',
  ];

  private const COMPLEX_WRAPPERS = [
    'image_object' => ['@type' => 'ImageObject', 'property' => 'url'],
    'place' => ['@type' => 'Place', 'property' => 'name'],
    'person' => ['@type' => 'Person', 'property' => 'name'],
    'organization' => ['@type' => 'Organization', 'property' => 'name'],
    'offer' => ['@type' => 'Offer', 'property' => 'url'],
    'rating' => ['@type' => 'AggregateRating', 'property' => 'ratingValue'],
  ];

  public function __construct(
    private readonly EntityTypeManagerInterface $entityTypeManager,
    private readonly StateInterface $state,
    private readonly ModuleInstallerInterface $moduleInstaller,
    private readonly MetatagTagPluginManager $tagPluginManager,
  ) {}

  /**
   * Writes accepted schema mappings into the metatag_defaults config entity.
   *
   * @param string $bundle
   *   Node bundle machine name (e.g. 'event').
   * @param array $suggestion
   *   Full suggestion from SchemaAiSuggester::suggest().
   * @param array $acceptedMappings
   *   The subset of $suggestion['mappings'] confirmed by the user.
   */
  public function apply(string $bundle, array $suggestion, array $acceptedMappings): void {
    $storage = $this->entityTypeManager->getStorage('metatag_defaults');
    $entity = $storage->load('node__' . $bundle);

    if (!$entity) {
      $entity = $storage->create([
        'id' => 'node__' . $bundle,
        'label' => ucfirst(str_replace('_', ' ', $bundle)),
      ]);
    }

    $tags = $entity->get('tags') ?? [];

    // Always write the @type tag.
    $tags[$suggestion['type_tag']['plugin_id']] = $suggestion['type_tag']['value'];

    foreach ($acceptedMappings as $mapping) {
      $pluginDef = $this->tagPluginManager->getDefinition($mapping['plugin_id'], FALSE);
      if (!$pluginDef) {
        continue;
      }

      $tags[$mapping['plugin_id']] = $this->buildValue(
        (string) ($pluginDef['property_type'] ?? 'text'),
        $mapping['token'],
        (array) ($pluginDef['tree_parent'] ?? []),
      );
    }

    $entity->set('tags', $tags);
    $entity->save();

    $this->state->set('ai_schema.bundle.' . $bundle, [
      'timestamp' => time(),
      'schema_type' => $suggestion['schema_type'],
      'group' => $suggestion['group'],
      'confidence' => $suggestion['confidence'],
      'rationale' => $suggestion['rationale'],
      'applied_count' => count($acceptedMappings),
    ]);
  }

  /**
   * Enables a schema_metatag sub-module and clears the tag plugin cache.
   */
  public function enableModule(string $moduleName): void {
    $this->moduleInstaller->install([$moduleName]);
    $this->tagPluginManager->clearCachedDefinitions();
  }

  /**
   * Returns non-schema metatag tags already configured for a bundle.
   *
   * Loads global → node → bundle-specific defaults in inheritance order,
   * merging them so bundle values win. Schema tags (prefixed schema_) are
   * excluded since those are what we are about to generate.
   *
   * The result is passed to the AI suggester so it can match existing token
   * conventions — particularly which image style is already in use and which
   * field is used for page descriptions.
   *
   * @return array<string, string>
   *   Metatag tag keys mapped to their raw token values.
   */
  public function getExistingNonSchemaTags(string $bundle): array {
    $storage = $this->entityTypeManager->getStorage('metatag_defaults');
    $merged = [];

    foreach (['global', 'node', 'node__' . $bundle] as $id) {
      $entity = $storage->load($id);
      if ($entity) {
        $merged = array_merge($merged, $entity->get('tags') ?? []);
      }
    }

    return array_filter(
      $merged,
      static fn(string $key) => !str_starts_with($key, 'schema_'),
      ARRAY_FILTER_USE_KEY,
    );
  }

  /**
   * Returns the persisted mapping state for a bundle, or NULL if not yet mapped.
   */
  public function getMappingState(string $bundle): ?array {
    return $this->state->get('ai_schema.bundle.' . $bundle);
  }

  /**
   * Clears the recorded state for a bundle. Does not modify metatag config.
   */
  public function resetState(string $bundle): void {
    $this->state->delete('ai_schema.bundle.' . $bundle);
  }

  private function buildValue(string $propertyType, string $token, array $treeParent): string {
    if (in_array($propertyType, self::SIMPLE_PROPERTY_TYPES, TRUE)) {
      return $token;
    }

    $wrapper = self::COMPLEX_WRAPPERS[$propertyType] ?? NULL;
    if ($wrapper) {
      return serialize(['@type' => $wrapper['@type'], $wrapper['property'] => $token]);
    }

    // Fallback: wrap with the first tree_parent class.
    if (!empty($treeParent)) {
      return serialize(['@type' => $treeParent[0], 'name' => $token]);
    }

    return $token;
  }

}
