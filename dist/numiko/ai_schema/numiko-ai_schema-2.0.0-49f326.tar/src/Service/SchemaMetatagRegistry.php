<?php

declare(strict_types=1);

namespace Drupal\ai_schema\Service;

use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\metatag\MetatagTagPluginManager;

class SchemaMetatagRegistry {

  /**
   * Maps Schema.org class names to their schema_metatag sub-module.
   * Covers all sub-modules shipped with schema_metatag 3.x.
   */
  private const TYPE_TO_MODULE = [
    'Article' => 'schema_article',
    'NewsArticle' => 'schema_article',
    'BlogPosting' => 'schema_article',
    'TechArticle' => 'schema_article',
    'Book' => 'schema_book',
    'Course' => 'schema_course',
    'Event' => 'schema_event',
    'HowTo' => 'schema_how_to',
    'ImageObject' => 'schema_image_object',
    'ItemList' => 'schema_item_list',
    'JobPosting' => 'schema_job_posting',
    'LocalBusiness' => 'schema_organization',
    'Movie' => 'schema_movie',
    'Organization' => 'schema_organization',
    'Person' => 'schema_person',
    'Place' => 'schema_place',
    'Product' => 'schema_product',
    'QAPage' => 'schema_qa_page',
    'Recipe' => 'schema_recipe',
    'Review' => 'schema_review',
    'Service' => 'schema_service',
    'SpecialAnnouncement' => 'schema_special_announcement',
    'WebPage' => 'schema_web_page',
    'WebSite' => 'schema_web_site',
  ];

  /**
   * Property types that serialise as a PHP array with a wrapping Schema.org class.
   * Key = property_type annotation value, value = [wrapper class, property name for token].
   */
  private const COMPLEX_WRAPPERS = [
    'image_object' => ['@type' => 'ImageObject', 'property' => 'url'],
    'place' => ['@type' => 'Place', 'property' => 'name'],
    'person' => ['@type' => 'Person', 'property' => 'name'],
    'organization' => ['@type' => 'Organization', 'property' => 'name'],
    'offer' => ['@type' => 'Offer', 'property' => 'url'],
    'rating' => ['@type' => 'AggregateRating', 'property' => 'ratingValue'],
  ];

  private const SIMPLE_PROPERTY_TYPES = [
    'text', 'type', 'string', 'date', 'url', 'boolean', 'integer', 'number', 'duration',
  ];

  public function __construct(
    private readonly MetatagTagPluginManager $tagPluginManager,
    private readonly ModuleHandlerInterface $moduleHandler,
  ) {}

  /**
   * Returns all Schema.org type groups discoverable from enabled metatag plugins.
   *
   * The plugin definition cache is cleared before querying so that modules
   * enabled earlier in the same drush run (or in a prior session that left the
   * cache in an intermediate state) do not produce stale results.
   *
   * @return array<string, array{schema_type: string, module: string, plugins: array}>
   *   Keyed by group ID (e.g. 'schema_event').
   */
  public function getAvailableTypes(): array {
    $this->tagPluginManager->clearCachedDefinitions();
    $definitions = $this->tagPluginManager->getDefinitions();
    $types = [];

    foreach ($definitions as $pluginId => $definition) {
      $group = (string) ($definition['group'] ?? '');
      if (!str_starts_with($group, 'schema_')) {
        continue;
      }

      if (!isset($types[$group])) {
        $types[$group] = [
          'schema_type' => $this->groupToSchemaType($group),
          'module' => $group,
          'plugins' => [],
        ];
      }

      $propertyType = (string) ($definition['property_type'] ?? 'text');
      $types[$group]['plugins'][$pluginId] = [
        'plugin_id' => $pluginId,
        'label' => (string) ($definition['label'] ?? $pluginId),
        'name' => (string) ($definition['name'] ?? ''),
        'property_type' => $propertyType,
        'is_complex' => !in_array($propertyType, self::SIMPLE_PROPERTY_TYPES, TRUE),
        'tree_parent' => (array) ($definition['tree_parent'] ?? []),
        'description' => (string) ($definition['description'] ?? ''),
      ];
    }

    return $types;
  }

  /**
   * Returns every known Schema.org type with its module and enabled status.
   *
   * Unlike getAvailableTypes(), this includes types whose sub-module is not
   * yet installed. Used to give the AI the full vocabulary so it can suggest
   * the ideal type regardless of what happens to be installed, allowing the
   * command layer to install the required module and re-query for mappings.
   *
   * @return array<string, array{module: string, enabled: bool}>
   *   Keyed by Schema.org class name (e.g. 'NewsArticle').
   */
  public function getAllKnownSchemaTypes(): array {
    $result = [];
    foreach (self::TYPE_TO_MODULE as $schemaType => $module) {
      $result[$schemaType] = [
        'module' => $module,
        'enabled' => $this->moduleHandler->moduleExists($module),
      ];
    }
    return $result;
  }

  /**
   * Returns TRUE if the schema_metatag sub-module for $schemaType is enabled.
   */
  public function isSchemaTypeEnabled(string $schemaType): bool {
    $module = self::TYPE_TO_MODULE[$schemaType] ?? NULL;
    return $module ? $this->moduleHandler->moduleExists($module) : FALSE;
  }

  /**
   * Returns the Drupal module name for a Schema.org type, or NULL if unknown.
   */
  public function getModuleForSchemaType(string $schemaType): ?string {
    return self::TYPE_TO_MODULE[$schemaType] ?? NULL;
  }

  /**
   * Builds the tag value for storage, serialising complex types as needed.
   */
  public function buildTagValue(array $pluginDefinition, string $token): string {
    $propertyType = (string) ($pluginDefinition['property_type'] ?? 'text');
    if (in_array($propertyType, self::SIMPLE_PROPERTY_TYPES, TRUE)) {
      return $token;
    }

    $wrapper = self::COMPLEX_WRAPPERS[$propertyType] ?? NULL;
    if ($wrapper) {
      return serialize(['@type' => $wrapper['@type'], $wrapper['property'] => $token]);
    }

    // Unknown complex type — try the first tree_parent class as wrapper.
    $treeParent = (array) ($pluginDefinition['tree_parent'] ?? []);
    if (!empty($treeParent)) {
      return serialize(['@type' => $treeParent[0], 'name' => $token]);
    }

    return $token;
  }

  private function groupToSchemaType(string $group): string {
    // schema_event -> Event, schema_web_page -> WebPage
    return str_replace('_', '', ucwords(substr($group, 7), '_'));
  }

}
