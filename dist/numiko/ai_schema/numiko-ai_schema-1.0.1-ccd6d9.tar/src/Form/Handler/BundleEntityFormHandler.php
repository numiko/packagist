<?php

namespace Drupal\ai_schema\Form\Handler;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\DependencyInjection\DependencySerializationTrait;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\ai_schema\Service\AiSchemaAnalyzer;
use Drupal\ai_schema\Service\SchemaOrgFetcher;
use Drupal\ai_schema\Service\YamlProcessor;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Handles AI Schema form elements on bundle entity forms.
 */
class BundleEntityFormHandler implements ContainerInjectionInterface {

  use DependencySerializationTrait;
  use StringTranslationTrait;

  /**
   * The bundle entity.
   *
   * @var \Drupal\Core\Entity\EntityInterface
   */
  protected EntityInterface $entity;

  /**
   * The content entity type ID.
   *
   * @var string
   */
  protected string $contentEntityType;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected ConfigFactoryInterface $configFactory;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected EntityFieldManagerInterface $entityFieldManager;

  /**
   * The YAML processor.
   *
   * @var \Drupal\ai_schema\Service\YamlProcessor
   */
  protected YamlProcessor $yamlProcessor;

  /**
   * The schema.org fetcher.
   *
   * @var \Drupal\ai_schema\Service\SchemaOrgFetcher
   */
  protected SchemaOrgFetcher $schemaOrgFetcher;

  /**
   * The AI schema analyzer.
   *
   * @var \Drupal\ai_schema\Service\AiSchemaAnalyzer
   */
  protected AiSchemaAnalyzer $aiAnalyzer;

  /**
   * Constructs a BundleEntityFormHandler.
   */
  public function __construct(
    ConfigFactoryInterface $config_factory,
    EntityTypeManagerInterface $entity_type_manager,
    EntityFieldManagerInterface $entity_field_manager,
    YamlProcessor $yaml_processor,
    SchemaOrgFetcher $schema_org_fetcher,
    AiSchemaAnalyzer $ai_analyzer,
  ) {
    $this->configFactory = $config_factory;
    $this->entityTypeManager = $entity_type_manager;
    $this->entityFieldManager = $entity_field_manager;
    $this->yamlProcessor = $yaml_processor;
    $this->schemaOrgFetcher = $schema_org_fetcher;
    $this->aiAnalyzer = $ai_analyzer;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.manager'),
      $container->get('entity_field.manager'),
      $container->get('ai_schema.yaml_processor'),
      $container->get('ai_schema.schema_org_fetcher'),
      $container->get('ai_schema.ai_analyzer'),
    );
  }

  /**
   * Sets the bundle entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The bundle entity.
   *
   * @return $this
   */
  public function setEntity(EntityInterface $entity): self {
    $this->entity = $entity;
    return $this;
  }

  /**
   * Sets the content entity type.
   *
   * @param string $entity_type
   *   The content entity type ID.
   *
   * @return $this
   */
  public function setContentEntityType(string $entity_type): self {
    $this->contentEntityType = $entity_type;
    return $this;
  }

  /**
   * Gets the bundle name.
   *
   * @return string
   *   The bundle name.
   */
  protected function getBundleName(): string {
    return $this->entity->id() ?? '';
  }

  /**
   * Gets the configuration name for this bundle.
   *
   * @return string
   *   The config name.
   */
  protected function getConfigName(): string {
    return 'ai_schema.bundle_settings.' . $this->contentEntityType . '.' . $this->getBundleName();
  }

  /**
   * Gets the current configuration for this bundle.
   *
   * @return array
   *   The configuration array.
   */
  protected function getConfig(): array {
    $config = $this->configFactory->get($this->getConfigName());
    return [
      'enabled' => $config->get('enabled') ?? FALSE,
      'schema_type' => $config->get('schema_type') ?? '',
      'mappings' => $config->get('mappings') ?? '',
    ];
  }

  /**
   * Alters the bundle entity form.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function formAlter(array &$form, FormStateInterface $form_state): void {
    $config = $this->getConfig();
    $schema_types = $this->schemaOrgFetcher->getAvailableTypes();

    $form['ai_schema'] = [
      '#type' => 'details',
      '#title' => $this->t('AI Schema (Schema.org)'),
      '#group' => 'additional_settings',
      '#tree' => TRUE,
      '#weight' => 50,
    ];

    $form['ai_schema']['enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enable schema.org output'),
      '#description' => $this->t('When enabled, JSON-LD structured data will be added to pages of this content type.'),
      '#default_value' => $config['enabled'],
    ];

    $form['ai_schema']['schema_type'] = [
      '#type' => 'select',
      '#title' => $this->t('Schema.org Type'),
      '#description' => $this->t('Select the primary schema.org type for this content type.'),
      '#options' => ['' => $this->t('- Select -')] + $schema_types,
      '#default_value' => $config['schema_type'],
      '#states' => [
        'visible' => [
          ':input[name="ai_schema[enabled]"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['ai_schema']['ai_analysis'] = [
      '#type' => 'details',
      '#title' => $this->t('AI Analysis'),
      '#description' => $this->t('Use AI to analyze sample content and suggest field mappings.'),
      '#open' => FALSE,
      '#states' => [
        'visible' => [
          ':input[name="ai_schema[enabled]"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['ai_schema']['ai_analysis']['sample_content'] = [
      '#type' => 'entity_autocomplete',
      '#title' => $this->t('Sample Content'),
      '#description' => $this->t('Select 1-5 content items to analyze. The AI will use these to suggest appropriate field mappings.'),
      '#target_type' => $this->contentEntityType,
      '#selection_settings' => [
        'target_bundles' => [$this->getBundleName()],
      ],
      '#tags' => TRUE,
      '#maxlength' => 1024,
    ];

    $form['ai_schema']['ai_analysis']['analyze_button'] = [
      '#type' => 'button',
      '#value' => $this->t('Analyze with AI'),
      '#ajax' => [
        'callback' => [$this, 'analyzeWithAi'],
        'wrapper' => 'ai-schema-mappings-wrapper',
        'progress' => [
          'type' => 'throbber',
          'message' => $this->t('Analyzing content...'),
        ],
      ],
      '#limit_validation_errors' => [
        ['ai_schema', 'sample_content'],
        ['ai_schema', 'schema_type'],
      ],
    ];

    $form['ai_schema']['mappings_wrapper'] = [
      '#type' => 'container',
      '#attributes' => ['id' => 'ai-schema-mappings-wrapper'],
      '#states' => [
        'visible' => [
          ':input[name="ai_schema[enabled]"]' => ['checked' => TRUE],
        ],
      ],
    ];

    $form['ai_schema']['mappings_wrapper']['mappings'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Field Mappings (YAML)'),
      '#description' => $this->t('Define the schema.org property mappings using YAML format. Use Drupal tokens for dynamic values.'),
      '#default_value' => $config['mappings'],
      '#rows' => 15,
      '#attributes' => [
        'class' => ['ai-schema-yaml-editor'],
        'spellcheck' => 'false',
      ],
    ];

    $form['ai_schema']['mappings_wrapper']['tokens'] = [
      '#type' => 'details',
      '#title' => $this->t('Available Tokens'),
      '#open' => FALSE,
    ];

    $form['ai_schema']['mappings_wrapper']['tokens']['info'] = [
      '#type' => 'markup',
      '#markup' => $this->getTokenHelp(),
    ];

    // Add submit handler.
    $form['actions']['submit']['#submit'][] = [$this, 'submitForm'];
  }

  /**
   * AJAX callback for AI analysis.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   *
   * @return array
   *   The form element to return.
   */
  public function analyzeWithAi(array &$form, FormStateInterface $form_state): array {
    $sample_content = $form_state->getValue(['ai_schema', 'ai_analysis', 'sample_content']);
    $schema_type = $form_state->getValue(['ai_schema', 'schema_type']);

    $wrapper = $form['ai_schema']['mappings_wrapper'];

    if (empty($sample_content)) {
      $wrapper['mappings']['#prefix'] = '<div class="messages messages--warning">' .
        $this->t('Please select at least one content item to analyze.') . '</div>';
      return $wrapper;
    }

    // Extract entity IDs from the autocomplete value.
    $entity_ids = $this->extractEntityIds($sample_content);
    if (empty($entity_ids)) {
      $wrapper['mappings']['#prefix'] = '<div class="messages messages--warning">' .
        $this->t('Please select at least one content item to analyze.') . '</div>';
      return $wrapper;
    }

    try {
      $entities = $this->entityTypeManager
        ->getStorage($this->contentEntityType)
        ->loadMultiple($entity_ids);

      if (empty($entities)) {
        $wrapper['mappings']['#prefix'] = '<div class="messages messages--warning">' .
          $this->t('Could not load the selected content items.') . '</div>';
        return $wrapper;
      }

      // If no schema type selected, identify it first.
      if (empty($schema_type)) {
        $schema_type = $this->aiAnalyzer->identifySchemaType($entities);
        $form['ai_schema']['schema_type']['#value'] = $schema_type;
      }

      // Get field mappings suggestion.
      $fields = $this->entityFieldManager->getFieldDefinitions($this->contentEntityType, $this->getBundleName());
      $suggested_yaml = $this->aiAnalyzer->suggestFieldMappings($schema_type, $fields, $entities);

      $wrapper['mappings']['#value'] = $suggested_yaml;
      $wrapper['mappings']['#prefix'] = '<div class="messages messages--status">' .
        $this->t('AI analysis complete. Review and adjust the suggested mappings below.') . '</div>';
    }
    catch (\Exception $e) {
      $wrapper['mappings']['#prefix'] = '<div class="messages messages--error">' .
        $this->t('AI analysis failed: @message', ['@message' => $e->getMessage()]) . '</div>';
    }

    return $wrapper;
  }

  /**
   * Form submission handler.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $values = $form_state->getValue('ai_schema');

    if ($values === NULL) {
      return;
    }

    // Validate YAML before saving.
    $mappings = $values['mappings_wrapper']['mappings'] ?? '';
    if (!empty($mappings)) {
      $error = $this->yamlProcessor->validate($mappings);
      if ($error) {
        \Drupal::messenger()->addError($this->t('Schema mappings contain invalid YAML: @error', ['@error' => $error]));
        return;
      }
    }

    $this->configFactory->getEditable($this->getConfigName())
      ->set('enabled', (bool) $values['enabled'])
      ->set('schema_type', $values['schema_type'] ?? '')
      ->set('mappings', $mappings)
      ->save();

    \Drupal::messenger()->addStatus($this->t('AI Schema settings have been saved.'));
  }

  /**
   * Extracts entity IDs from autocomplete value.
   *
   * Handles both array format (processed) and string format (raw input).
   *
   * @param mixed $value
   *   The autocomplete value.
   *
   * @return array
   *   Array of entity IDs.
   */
  protected function extractEntityIds($value): array {
    if (empty($value)) {
      return [];
    }

    // If already an array of target_id arrays.
    if (is_array($value)) {
      $ids = [];
      foreach ($value as $item) {
        if (is_array($item) && isset($item['target_id'])) {
          $ids[] = $item['target_id'];
        }
        elseif (is_numeric($item)) {
          $ids[] = $item;
        }
      }
      return $ids;
    }

    // If a string, parse entity IDs from format "Title (123), Another (456)".
    if (is_string($value)) {
      $ids = [];
      // Match patterns like (123) at the end of each entity reference.
      if (preg_match_all('/\((\d+)\)/', $value, $matches)) {
        $ids = array_map('intval', $matches[1]);
      }
      return $ids;
    }

    return [];
  }

  /**
   * Returns token help markup.
   *
   * @return string
   *   The help markup.
   */
  protected function getTokenHelp(): string {
    $tokens = [
      '[node:title]' => $this->t('Content title'),
      '[node:body]' => $this->t('Body field value'),
      '[node:body:summary]' => $this->t('Body summary'),
      '[node:created:html_datetime]' => $this->t('Created date (ISO 8601)'),
      '[node:changed:html_datetime]' => $this->t('Updated date (ISO 8601)'),
      '[node:author:display-name]' => $this->t('Author display name'),
      '[node:author:url]' => $this->t('Author profile URL'),
      '[node:url:absolute]' => $this->t('Absolute URL to content'),
      '[node:field_NAME]' => $this->t('Custom field value'),
      '[node:field_NAME:entity:url]' => $this->t('Referenced entity URL'),
      '[node:field_NAME:entity:field_image:uncropped_lg:url]' => $this->t('Media image URL with image style'),
      '[site:name]' => $this->t('Site name'),
      '[site:url]' => $this->t('Site URL'),
    ];

    $output = '<p>' . $this->t('Use Drupal tokens to map dynamic content values to schema.org properties:') . '</p>';
    $output .= '<dl>';
    foreach ($tokens as $token => $description) {
      $output .= '<dt><code>' . $token . '</code></dt>';
      $output .= '<dd>' . $description . '</dd>';
    }
    $output .= '</dl>';
    $output .= '<p>' . $this->t('For multi-value fields, use delta: <code>[node:field_tags:0:name]</code>, <code>[node:field_tags:1:name]</code>') . '</p>';
    $output .= '<p>' . $this->t('<strong>Note:</strong> For media fields, use the full path with image style: <code>[node:field_image:entity:field_image:uncropped_lg:url]</code>') . '</p>';

    return $output;
  }

}
