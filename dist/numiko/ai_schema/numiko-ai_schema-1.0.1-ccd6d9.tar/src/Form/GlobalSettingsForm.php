<?php

namespace Drupal\ai_schema\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\ai_schema\Service\YamlProcessor;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Global settings form for AI Schema module.
 */
class GlobalSettingsForm extends ConfigFormBase {

  /**
   * The YAML processor service.
   *
   * @var \Drupal\ai_schema\Service\YamlProcessor
   */
  protected YamlProcessor $yamlProcessor;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    $instance = parent::create($container);
    $instance->yamlProcessor = $container->get('ai_schema.yaml_processor');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'ai_schema_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['ai_schema.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('ai_schema.settings');

    $form['info'] = [
      '#type' => 'markup',
      '#markup' => '<p>' . $this->t('Configure global schema.org settings that will be merged with content-type specific settings. Use Drupal tokens for dynamic values.') . '</p>',
    ];

    $form['global_schema'] = [
      '#type' => 'textarea',
      '#title' => $this->t('Global Schema.org YAML'),
      '#description' => $this->t('Enter schema.org mappings in YAML format. These settings will be merged with content-type specific mappings (content-type settings take precedence). Use Drupal tokens like [site:name], [site:url], etc.'),
      '#default_value' => $config->get('global_schema') ?? '',
      '#rows' => 20,
      '#attributes' => [
        'class' => ['ai-schema-yaml-editor'],
        'spellcheck' => 'false',
      ],
    ];

    $form['tokens'] = [
      '#type' => 'details',
      '#title' => $this->t('Available Tokens'),
      '#open' => FALSE,
    ];

    $form['tokens']['info'] = [
      '#type' => 'markup',
      '#markup' => $this->getTokenHelp(),
    ];

    $form['advanced'] = [
      '#type' => 'details',
      '#title' => $this->t('Advanced Settings'),
      '#open' => FALSE,
    ];

    $form['advanced']['schema_org_cache_ttl'] = [
      '#type' => 'number',
      '#title' => $this->t('Schema.org Vocabulary Cache TTL'),
      '#description' => $this->t('Time in seconds to cache the schema.org vocabulary. Set to 0 to disable caching.'),
      '#default_value' => $config->get('schema_org_cache_ttl') ?? 86400,
      '#min' => 0,
      '#max' => 604800,
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

    $yaml = $form_state->getValue('global_schema');
    if (!empty($yaml)) {
      $error = $this->yamlProcessor->validate($yaml);
      if ($error) {
        $form_state->setErrorByName('global_schema', $error);
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('ai_schema.settings')
      ->set('global_schema', $form_state->getValue('global_schema'))
      ->set('schema_org_cache_ttl', $form_state->getValue('schema_org_cache_ttl'))
      ->save();

    parent::submitForm($form, $form_state);
  }

  /**
   * Returns token help markup.
   *
   * @return string
   *   The help markup.
   */
  protected function getTokenHelp(): string {
    $tokens = [
      '[site:name]' => $this->t('Site name'),
      '[site:url]' => $this->t('Site URL'),
      '[site:slogan]' => $this->t('Site slogan'),
      '[site:mail]' => $this->t('Site email'),
      '[current-date:html_datetime]' => $this->t('Current date in ISO 8601 format'),
    ];

    $output = '<p>' . $this->t('The following tokens are available for global schema settings:') . '</p>';
    $output .= '<dl>';
    foreach ($tokens as $token => $description) {
      $output .= '<dt><code>' . $token . '</code></dt>';
      $output .= '<dd>' . $description . '</dd>';
    }
    $output .= '</dl>';
    $output .= '<p>' . $this->t('For content-type specific mappings, additional tokens like [node:title], [node:author:display-name], etc. are available.') . '</p>';

    return $output;
  }

}
