<?php

namespace Drupal\ai_schema\Form;

use Drupal\Core\DependencyInjection\ClassResolverInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\Core\Config\ConfigFactoryInterface;

/**
 * Helper service for attaching AI Schema form elements to bundle forms.
 */
class FormHelper {

  /**
   * The bundle entity form handler class.
   */
  protected const BUNDLE_ENTITY_FORM_HANDLER = 'Drupal\ai_schema\Form\Handler\BundleEntityFormHandler';

  /**
   * Entity types that support AI Schema.
   */
  protected const SUPPORTED_ENTITY_TYPES = ['node'];

  /**
   * The current user.
   *
   * @var \Drupal\Core\Session\AccountProxyInterface
   */
  protected AccountProxyInterface $currentUser;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected ConfigFactoryInterface $configFactory;

  /**
   * The class resolver.
   *
   * @var \Drupal\Core\DependencyInjection\ClassResolverInterface
   */
  protected ClassResolverInterface $classResolver;

  /**
   * Constructs a FormHelper object.
   *
   * @param \Drupal\Core\Session\AccountProxyInterface $current_user
   *   The current user.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\DependencyInjection\ClassResolverInterface $class_resolver
   *   The class resolver.
   */
  public function __construct(
    AccountProxyInterface $current_user,
    EntityTypeManagerInterface $entity_type_manager,
    ConfigFactoryInterface $config_factory,
    ClassResolverInterface $class_resolver,
  ) {
    $this->currentUser = $current_user;
    $this->entityTypeManager = $entity_type_manager;
    $this->configFactory = $config_factory;
    $this->classResolver = $class_resolver;
  }

  /**
   * Alters forms to add AI Schema settings.
   *
   * @param array $form
   *   The form array.
   * @param \Drupal\Core\Form\FormStateInterface $form_state
   *   The form state.
   * @param string $form_id
   *   The form ID.
   */
  public function formAlter(array &$form, FormStateInterface $form_state, string $form_id): void {
    // Check access.
    if (!$this->formAlterAccess()) {
      return;
    }

    // Check if this is a bundle entity form.
    $form_object = $form_state->getFormObject();
    if (!method_exists($form_object, 'getEntity')) {
      return;
    }

    $entity = $form_object->getEntity();
    if (!$entity) {
      return;
    }

    // Resolve the form handler.
    $handler = $this->resolveFormHandler($entity);
    if (!$handler) {
      return;
    }

    // Apply form alterations.
    $handler->formAlter($form, $form_state);
  }

  /**
   * Checks if the current user has access to alter forms.
   *
   * @return bool
   *   TRUE if access is granted.
   */
  protected function formAlterAccess(): bool {
    return $this->currentUser->hasPermission('administer ai_schema');
  }

  /**
   * Resolves the appropriate form handler for an entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity.
   *
   * @return \Drupal\ai_schema\Form\Handler\BundleEntityFormHandler|null
   *   The form handler, or NULL if not applicable.
   */
  protected function resolveFormHandler($entity) {
    $entity_type_id = $entity->getEntityTypeId();

    // Check if this is a bundle entity for a supported content entity type.
    foreach (self::SUPPORTED_ENTITY_TYPES as $content_entity_type) {
      $content_entity_definition = $this->entityTypeManager->getDefinition($content_entity_type, FALSE);
      if ($content_entity_definition && $content_entity_definition->getBundleEntityType() === $entity_type_id) {
        /** @var \Drupal\ai_schema\Form\Handler\BundleEntityFormHandler $handler */
        $handler = $this->classResolver->getInstanceFromDefinition(self::BUNDLE_ENTITY_FORM_HANDLER);
        $handler->setEntity($entity);
        $handler->setContentEntityType($content_entity_type);
        return $handler;
      }
    }

    return NULL;
  }

  /**
   * Gets the supported entity types.
   *
   * @return array
   *   Array of supported entity type IDs.
   */
  public function getSupportedEntityTypes(): array {
    return self::SUPPORTED_ENTITY_TYPES;
  }

}
