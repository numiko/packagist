<?php

namespace Drupal\ai_schema\Service;

use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Extension\ModuleExtensionList;
use GuzzleHttp\ClientInterface;

/**
 * Service for fetching and caching schema.org type definitions.
 */
class SchemaOrgFetcher {

  /**
   * Cache ID for schema.org types.
   */
  protected const CACHE_ID = 'ai_schema.schema_org_types';

  /**
   * The cache backend.
   *
   * @var \Drupal\Core\Cache\CacheBackendInterface
   */
  protected CacheBackendInterface $cache;

  /**
   * The HTTP client.
   *
   * @var \GuzzleHttp\ClientInterface
   */
  protected ClientInterface $httpClient;

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected ConfigFactoryInterface $configFactory;

  /**
   * The module extension list.
   *
   * @var \Drupal\Core\Extension\ModuleExtensionList
   */
  protected ModuleExtensionList $moduleExtensionList;

  /**
   * Constructs a SchemaOrgFetcher.
   *
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache
   *   The cache backend.
   * @param \GuzzleHttp\ClientInterface $http_client
   *   The HTTP client.
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\Core\Extension\ModuleExtensionList $module_extension_list
   *   The module extension list.
   */
  public function __construct(
    CacheBackendInterface $cache,
    ClientInterface $http_client,
    ConfigFactoryInterface $config_factory,
    ModuleExtensionList $module_extension_list,
  ) {
    $this->cache = $cache;
    $this->httpClient = $http_client;
    $this->configFactory = $config_factory;
    $this->moduleExtensionList = $module_extension_list;
  }

  /**
   * Gets available schema.org types for selection.
   *
   * @return array
   *   Array of type ID => label pairs.
   */
  public function getAvailableTypes(): array {
    $data = $this->getTypesData();
    $options = [];

    foreach ($data['types'] as $type_id => $type_info) {
      $options[$type_id] = $type_info['label'] ?? $type_id;
    }

    asort($options);
    return $options;
  }

  /**
   * Gets the full data for a specific schema.org type.
   *
   * @param string $type
   *   The schema.org type ID.
   *
   * @return array|null
   *   The type data, or NULL if not found.
   */
  public function getTypeData(string $type): ?array {
    $data = $this->getTypesData();
    return $data['types'][$type] ?? NULL;
  }

  /**
   * Gets properties for a specific schema.org type.
   *
   * @param string $type
   *   The schema.org type ID.
   *
   * @return array
   *   Array of property names.
   */
  public function getTypeProperties(string $type): array {
    $type_data = $this->getTypeData($type);
    if (!$type_data) {
      return [];
    }

    $properties = $type_data['properties'] ?? [];

    // Include parent properties if extends is defined.
    if (!empty($type_data['extends'])) {
      $parent_properties = $this->getTypeProperties($type_data['extends']);
      $properties = array_merge($parent_properties, $properties);
    }

    return array_unique($properties);
  }

  /**
   * Validates if a property is valid for a schema.org type.
   *
   * @param string $type
   *   The schema.org type ID.
   * @param string $property
   *   The property name.
   *
   * @return bool
   *   TRUE if valid, FALSE otherwise.
   */
  public function isValidProperty(string $type, string $property): bool {
    // Common properties are valid for all types.
    $data = $this->getTypesData();
    if (isset($data['common_properties'][$property])) {
      return TRUE;
    }

    $properties = $this->getTypeProperties($type);
    return in_array($property, $properties, TRUE);
  }

  /**
   * Validates a schema.org mapping and returns warnings.
   *
   * @param string $type
   *   The schema.org type ID.
   * @param array $mapping
   *   The mapping array.
   *
   * @return array
   *   Array of warning messages.
   */
  public function validateMapping(string $type, array $mapping): array {
    $warnings = [];
    $valid_properties = $this->getTypeProperties($type);
    $data = $this->getTypesData();
    $common_properties = array_keys($data['common_properties'] ?? []);

    foreach ($mapping as $property => $value) {
      // Skip @type and @context.
      if (str_starts_with($property, '@')) {
        continue;
      }

      if (!in_array($property, $valid_properties, TRUE) &&
          !in_array($property, $common_properties, TRUE)) {
        $warnings[] = t('Unknown property "@property" for type "@type".', [
          '@property' => $property,
          '@type' => $type,
        ]);
      }
    }

    return $warnings;
  }

  /**
   * Gets the full types data.
   *
   * @return array
   *   The types data array.
   */
  protected function getTypesData(): array {
    // Check cache first.
    $cached = $this->cache->get(self::CACHE_ID);
    if ($cached) {
      return $cached->data;
    }

    // Load from bundled file.
    $data = $this->loadBundledTypes();

    // Cache the data.
    $ttl = $this->configFactory->get('ai_schema.settings')->get('schema_org_cache_ttl') ?? 86400;
    if ($ttl > 0) {
      $this->cache->set(self::CACHE_ID, $data, time() + $ttl);
    }

    return $data;
  }

  /**
   * Loads bundled schema.org types from the module's data file.
   *
   * @return array
   *   The types data array.
   */
  protected function loadBundledTypes(): array {
    $module_path = $this->moduleExtensionList->getPath('ai_schema');
    $file_path = $module_path . '/data/schema_org_types.json';

    if (!file_exists($file_path)) {
      return ['types' => [], 'common_properties' => []];
    }

    $content = file_get_contents($file_path);
    $data = json_decode($content, TRUE);

    if (!is_array($data)) {
      return ['types' => [], 'common_properties' => []];
    }

    return $data;
  }

  /**
   * Clears the schema.org types cache.
   */
  public function clearCache(): void {
    $this->cache->delete(self::CACHE_ID);
  }

  /**
   * Gets a description for a schema.org type.
   *
   * @param string $type
   *   The schema.org type ID.
   *
   * @return string
   *   The type description.
   */
  public function getTypeDescription(string $type): string {
    $type_data = $this->getTypeData($type);
    return $type_data['description'] ?? '';
  }

}
