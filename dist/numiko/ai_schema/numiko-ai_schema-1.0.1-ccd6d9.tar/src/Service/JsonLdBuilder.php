<?php

namespace Drupal\ai_schema\Service;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Render\BubbleableMetadata;
use Drupal\Core\Utility\Token;

/**
 * Service for building JSON-LD structured data from schema.org mappings.
 */
class JsonLdBuilder {

  /**
   * The config factory.
   *
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  protected ConfigFactoryInterface $configFactory;

  /**
   * The YAML processor.
   *
   * @var \Drupal\ai_schema\Service\YamlProcessor
   */
  protected YamlProcessor $yamlProcessor;

  /**
   * The token service.
   *
   * @var \Drupal\Core\Utility\Token
   */
  protected Token $token;

  /**
   * Constructs a JsonLdBuilder.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config_factory
   *   The config factory.
   * @param \Drupal\ai_schema\Service\YamlProcessor $yaml_processor
   *   The YAML processor.
   * @param \Drupal\Core\Utility\Token $token
   *   The token service.
   */
  public function __construct(
    ConfigFactoryInterface $config_factory,
    YamlProcessor $yaml_processor,
    Token $token,
  ) {
    $this->configFactory = $config_factory;
    $this->yamlProcessor = $yaml_processor;
    $this->token = $token;
  }

  /**
   * Builds JSON-LD structured data for an entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity.
   *
   * @return array|null
   *   The JSON-LD array, or NULL if not configured.
   */
  public function buildJsonLd(EntityInterface $entity): ?array {
    $bundle_config = $this->getBundleConfig($entity);

    // Check if enabled.
    if (empty($bundle_config) || empty($bundle_config['enabled'])) {
      return NULL;
    }

    // Get schema type.
    $schema_type = $bundle_config['schema_type'] ?? '';
    if (empty($schema_type)) {
      return NULL;
    }

    // Get global config.
    $global_config = $this->getGlobalConfig();

    // Decode YAML configurations.
    $bundle_mappings = $this->yamlProcessor->decode($bundle_config['mappings'] ?? '');
    $global_mappings = $this->yamlProcessor->decode($global_config['global_schema'] ?? '');

    // Merge configurations (bundle overrides global).
    $merged = array_replace_recursive($global_mappings, $bundle_mappings);

    if (empty($merged)) {
      return NULL;
    }

    // Build token data.
    $token_data = $this->buildTokenData($entity);

    // Process tokens recursively.
    $json_ld = $this->processTokensRecursive($merged, $token_data);

    // Remove empty values.
    $json_ld = $this->removeEmptyValues($json_ld);

    if (empty($json_ld)) {
      return NULL;
    }

    // Add @context and @type.
    $result = [
      '@context' => 'https://schema.org',
      '@type' => $schema_type,
    ];

    // Merge the processed mappings.
    $result = array_merge($result, $json_ld);

    return $result;
  }

  /**
   * Gets the bundle configuration for an entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity.
   *
   * @return array
   *   The configuration array.
   */
  protected function getBundleConfig(EntityInterface $entity): array {
    $entity_type = $entity->getEntityTypeId();
    $bundle = $entity->bundle();

    $config = $this->configFactory->get("ai_schema.bundle_settings.{$entity_type}.{$bundle}");

    return [
      'enabled' => $config->get('enabled') ?? FALSE,
      'schema_type' => $config->get('schema_type') ?? '',
      'mappings' => $config->get('mappings') ?? '',
    ];
  }

  /**
   * Gets the global configuration.
   *
   * @return array
   *   The global configuration array.
   */
  protected function getGlobalConfig(): array {
    $config = $this->configFactory->get('ai_schema.settings');

    return [
      'global_schema' => $config->get('global_schema') ?? '',
    ];
  }

  /**
   * Builds token data for an entity.
   *
   * @param \Drupal\Core\Entity\EntityInterface $entity
   *   The entity.
   *
   * @return array
   *   The token data array.
   */
  protected function buildTokenData(EntityInterface $entity): array {
    $data = [];

    // Add entity-specific token data.
    $entity_type = $entity->getEntityTypeId();
    $data[$entity_type] = $entity;

    // Add author/owner if available.
    if ($entity instanceof FieldableEntityInterface && $entity->hasField('uid')) {
      $owner_field = $entity->get('uid');
      if (!$owner_field->isEmpty() && $owner_field->entity) {
        $data['user'] = $owner_field->entity;
      }
    }
    elseif (method_exists($entity, 'getOwner')) {
      $owner = $entity->getOwner();
      if ($owner) {
        $data['user'] = $owner;
      }
    }

    return $data;
  }

  /**
   * Processes tokens recursively in the data structure.
   *
   * @param array $data
   *   The data array.
   * @param array $token_data
   *   The token data for replacement.
   *
   * @return array
   *   The processed data array.
   */
  protected function processTokensRecursive(array $data, array $token_data): array {
    $bubbleable_metadata = new BubbleableMetadata();
    $result = [];

    foreach ($data as $key => $value) {
      if (is_array($value)) {
        // Recursively process nested arrays.
        $result[$key] = $this->processTokensRecursive($value, $token_data);
      }
      elseif (is_string($value)) {
        // Check if the value contains tokens.
        if (strpos($value, '[') !== FALSE && strpos($value, ']') !== FALSE) {
          $replaced = $this->token->replace($value, $token_data, ['clear' => TRUE], $bubbleable_metadata);

          // Handle cases where token replacement returns non-string (e.g., entity objects).
          if (is_object($replaced)) {
            // Try to get a string representation.
            if (method_exists($replaced, 'label')) {
              $replaced = $replaced->label();
            }
            elseif (method_exists($replaced, '__toString')) {
              $replaced = (string) $replaced;
            }
            else {
              // Skip objects that can't be converted to string.
              continue;
            }
          }

          // Only include if the token was replaced with something meaningful.
          if (is_string($replaced) && ($replaced !== $value || strpos($replaced, '[') === FALSE)) {
            $result[$key] = $replaced;
          }
        }
        else {
          // Non-token string, keep as-is.
          $result[$key] = $value;
        }
      }
      else {
        // Other types (int, bool, etc.), keep as-is.
        $result[$key] = $value;
      }
    }

    return $result;
  }

  /**
   * Removes empty values from the data structure recursively.
   *
   * @param array $data
   *   The data array.
   *
   * @return array
   *   The cleaned data array.
   */
  protected function removeEmptyValues(array $data): array {
    $result = [];

    foreach ($data as $key => $value) {
      if (is_array($value)) {
        $cleaned = $this->removeEmptyValues($value);
        if (!empty($cleaned)) {
          $result[$key] = $cleaned;
        }
      }
      elseif ($value !== '' && $value !== NULL) {
        $result[$key] = $value;
      }
    }

    return $result;
  }

  /**
   * Builds JSON-LD for a preview (without full token replacement).
   *
   * @param string $schema_type
   *   The schema.org type.
   * @param string $mappings_yaml
   *   The YAML mappings.
   * @param \Drupal\Core\Entity\EntityInterface|null $entity
   *   Optional entity for token replacement.
   *
   * @return array
   *   The JSON-LD array.
   */
  public function buildPreview(string $schema_type, string $mappings_yaml, ?EntityInterface $entity = NULL): array {
    $mappings = $this->yamlProcessor->decode($mappings_yaml);

    if (empty($mappings)) {
      return [];
    }

    $result = [
      '@context' => 'https://schema.org',
      '@type' => $schema_type,
    ];

    if ($entity) {
      $token_data = $this->buildTokenData($entity);
      $mappings = $this->processTokensRecursive($mappings, $token_data);
      $mappings = $this->removeEmptyValues($mappings);
    }

    return array_merge($result, $mappings);
  }

}
