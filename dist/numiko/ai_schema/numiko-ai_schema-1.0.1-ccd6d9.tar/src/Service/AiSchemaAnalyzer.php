<?php

namespace Drupal\ai_schema\Service;

use Drupal\ai\AiProviderPluginManager;
use Drupal\ai\OperationType\Chat\ChatInput;
use Drupal\ai\OperationType\Chat\ChatMessage;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\FieldableEntityInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;

/**
 * Service for AI-powered schema.org analysis.
 */
class AiSchemaAnalyzer {

  use StringTranslationTrait;

  /**
   * The AI provider plugin manager.
   *
   * @var \Drupal\ai\AiProviderPluginManager
   */
  protected AiProviderPluginManager $aiProviderManager;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected EntityFieldManagerInterface $entityFieldManager;

  /**
   * The schema.org fetcher.
   *
   * @var \Drupal\ai_schema\Service\SchemaOrgFetcher
   */
  protected SchemaOrgFetcher $schemaOrgFetcher;

  /**
   * Constructs an AiSchemaAnalyzer.
   *
   * @param \Drupal\ai\AiProviderPluginManager $ai_provider_manager
   *   The AI provider plugin manager.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entity_field_manager
   *   The entity field manager.
   * @param \Drupal\ai_schema\Service\SchemaOrgFetcher $schema_org_fetcher
   *   The schema.org fetcher.
   */
  public function __construct(
    AiProviderPluginManager $ai_provider_manager,
    EntityTypeManagerInterface $entity_type_manager,
    EntityFieldManagerInterface $entity_field_manager,
    SchemaOrgFetcher $schema_org_fetcher,
  ) {
    $this->aiProviderManager = $ai_provider_manager;
    $this->entityTypeManager = $entity_type_manager;
    $this->entityFieldManager = $entity_field_manager;
    $this->schemaOrgFetcher = $schema_org_fetcher;
  }

  /**
   * Identifies the most appropriate schema.org type for content samples.
   *
   * @param array $entities
   *   Array of entity objects to analyze.
   *
   * @return string
   *   The recommended schema.org type ID.
   *
   * @throws \Exception
   *   If AI analysis fails.
   */
  public function identifySchemaType(array $entities): string {
    if (empty($entities)) {
      throw new \InvalidArgumentException('At least one entity is required for analysis.');
    }

    // Build content summary from samples.
    $content_summary = $this->buildContentSummary($entities);

    // Get available types.
    $available_types = $this->schemaOrgFetcher->getAvailableTypes();
    $types_list = implode(', ', array_keys($available_types));

    $prompt = $this->buildSchemaTypePrompt($content_summary, $types_list);

    $response = $this->executeAiRequest($prompt, $this->getSchemaTypeSystemPrompt());

    return $this->parseSchemaTypeResponse($response, array_keys($available_types));
  }

  /**
   * Suggests field mappings for a schema.org type based on content samples.
   *
   * @param string $schema_type
   *   The schema.org type ID.
   * @param array $fields
   *   Array of field definitions.
   * @param array $entities
   *   Array of entity objects for context.
   *
   * @return string
   *   YAML string with suggested mappings.
   *
   * @throws \Exception
   *   If AI analysis fails.
   */
  public function suggestFieldMappings(string $schema_type, array $fields, array $entities): string {
    // Get schema.org properties for this type.
    $properties = $this->schemaOrgFetcher->getTypeProperties($schema_type);

    // Build field information.
    $field_info = $this->buildFieldInfo($fields);

    // Build content samples.
    $content_samples = $this->buildContentSamples($entities, $fields);

    $prompt = $this->buildMappingPrompt($schema_type, $properties, $field_info, $content_samples);

    $response = $this->executeAiRequest($prompt, $this->getMappingSystemPrompt());

    return $this->parseMappingResponse($response);
  }

  /**
   * Executes an AI request.
   *
   * @param string $prompt
   *   The user prompt.
   * @param string $system_prompt
   *   The system prompt.
   *
   * @return string
   *   The AI response text.
   *
   * @throws \Exception
   *   If the AI request fails.
   */
  protected function executeAiRequest(string $prompt, string $system_prompt): string {
    // Get the default provider for chat operations.
    $default = $this->aiProviderManager->getDefaultProviderForOperationType('chat');

    if (empty($default)) {
      throw new \Exception('No AI provider configured for chat operations. Please configure an AI provider in the AI module settings.');
    }

    /** @var \Drupal\ai\AiProviderInterface $provider */
    $provider = $this->aiProviderManager->createInstance($default['provider_id']);

    $input = new ChatInput([
      new ChatMessage('system', $system_prompt),
      new ChatMessage('user', $prompt),
    ]);

    try {
      $response = $provider->chat($input, $default['model_id'], ['ai_schema']);
      return $response->getNormalized()->getText();
    }
    catch (\Exception $e) {
      throw new \Exception('AI request failed: ' . $e->getMessage());
    }
  }

  /**
   * Builds a content summary from entity samples.
   *
   * @param array $entities
   *   Array of entities.
   *
   * @return string
   *   The content summary.
   */
  protected function buildContentSummary(array $entities): string {
    $summaries = [];

    foreach ($entities as $entity) {
      if (!$entity instanceof FieldableEntityInterface) {
        continue;
      }

      $summary = [];

      // Get title/label.
      $summary['title'] = $entity->label();

      // Get common fields.
      if ($entity->hasField('body') && !$entity->get('body')->isEmpty()) {
        $body = $entity->get('body')->first();
        $summary['body'] = mb_substr(strip_tags($body->value ?? ''), 0, 500);
      }

      // Get created date if available.
      if (method_exists($entity, 'getCreatedTime')) {
        $summary['created'] = date('Y-m-d', $entity->getCreatedTime());
      }

      $summaries[] = $summary;
    }

    $output = "Content samples:\n\n";
    foreach ($summaries as $i => $summary) {
      $output .= "Sample " . ($i + 1) . ":\n";
      foreach ($summary as $key => $value) {
        $output .= "  {$key}: {$value}\n";
      }
      $output .= "\n";
    }

    return $output;
  }

  /**
   * Builds field information for the AI prompt.
   *
   * @param array $fields
   *   Array of field definitions.
   *
   * @return string
   *   Field information string.
   */
  protected function buildFieldInfo(array $fields): string {
    $info = "Available Drupal fields:\n\n";

    foreach ($fields as $field_name => $field) {
      if (!$field instanceof FieldDefinitionInterface) {
        continue;
      }

      // Skip internal fields.
      if (str_starts_with($field_name, 'revision_') ||
          in_array($field_name, ['uuid', 'vid', 'langcode', 'default_langcode', 'revision_default', 'revision_translation_affected'])) {
        continue;
      }

      $type = $field->getType();
      $label = $field->getLabel();

      // Map to token format.
      $token = $this->fieldToToken($field_name, $field);

      $info .= "- {$field_name} ({$label})\n";
      $info .= "  Type: {$type}\n";
      $info .= "  Token: {$token}\n\n";
    }

    return $info;
  }

  /**
   * Builds content samples with field values.
   *
   * @param array $entities
   *   Array of entities.
   * @param array $fields
   *   Array of field definitions.
   *
   * @return string
   *   Content samples string.
   */
  protected function buildContentSamples(array $entities, array $fields): string {
    $samples = "Sample content values:\n\n";

    $count = 0;
    foreach ($entities as $entity) {
      if (!$entity instanceof FieldableEntityInterface || $count >= 3) {
        continue;
      }

      $samples .= "Sample " . ($count + 1) . ":\n";

      foreach ($fields as $field_name => $field) {
        if (!$field instanceof FieldDefinitionInterface) {
          continue;
        }

        // Skip internal/revision fields.
        if (str_starts_with($field_name, 'revision_') ||
            in_array($field_name, ['uuid', 'vid', 'langcode', 'default_langcode'])) {
          continue;
        }

        if ($entity->hasField($field_name) && !$entity->get($field_name)->isEmpty()) {
          $value = $this->getFieldDisplayValue($entity, $field_name);
          if ($value) {
            $samples .= "  {$field_name}: {$value}\n";
          }
        }
      }

      $samples .= "\n";
      $count++;
    }

    return $samples;
  }

  /**
   * Gets a display value for a field.
   *
   * @param \Drupal\Core\Entity\FieldableEntityInterface $entity
   *   The entity.
   * @param string $field_name
   *   The field name.
   *
   * @return string|null
   *   The display value, or NULL.
   */
  protected function getFieldDisplayValue(FieldableEntityInterface $entity, string $field_name): ?string {
    $field = $entity->get($field_name);
    $first = $field->first();

    if (!$first) {
      return NULL;
    }

    // Handle different field types.
    $type = $field->getFieldDefinition()->getType();

    switch ($type) {
      case 'string':
      case 'string_long':
      case 'email':
      case 'telephone':
        return mb_substr((string) ($first->value ?? ''), 0, 200);

      case 'text':
      case 'text_long':
      case 'text_with_summary':
        return mb_substr(strip_tags($first->value ?? ''), 0, 200);

      case 'datetime':
      case 'daterange':
      case 'timestamp':
        return $first->value ?? NULL;

      case 'entity_reference':
        $referenced = $first->entity;
        return $referenced ? $referenced->label() : NULL;

      case 'image':
      case 'file':
        return '[file]';

      case 'link':
        return $first->uri ?? NULL;

      case 'boolean':
        return $first->value ? 'true' : 'false';

      case 'integer':
      case 'decimal':
      case 'float':
        return (string) $first->value;

      default:
        return mb_substr((string) ($first->value ?? ''), 0, 100);
    }
  }

  /**
   * Converts a field name and definition to a token.
   *
   * @param string $field_name
   *   The field name.
   * @param \Drupal\Core\Field\FieldDefinitionInterface $field
   *   The field definition.
   *
   * @return string
   *   The token string.
   */
  protected function fieldToToken(string $field_name, FieldDefinitionInterface $field): string {
    // Map common base fields.
    $base_field_tokens = [
      'title' => '[node:title]',
      'body' => '[node:body]',
      'created' => '[node:created:html_datetime]',
      'changed' => '[node:changed:html_datetime]',
      'uid' => '[node:author:display-name]',
      'status' => '[node:status]',
      'nid' => '[node:nid]',
    ];

    if (isset($base_field_tokens[$field_name])) {
      return $base_field_tokens[$field_name];
    }

    $field_type = $field->getType();

    // Generate token based on field type.
    $base = "[node:{$field_name}]";

    switch ($field_type) {
      case 'text_with_summary':
        return "[node:{$field_name}:summary] or [node:{$field_name}:value]";

      case 'entity_reference':
        // Check if this references media entities.
        $settings = $field->getSettings();
        $target_type = $settings['target_type'] ?? '';
        if ($target_type === 'media') {
          // For media, traverse to the source field and use image style.
          return "[node:{$field_name}:entity:field_image:uncropped_lg:url]";
        }
        return "[node:{$field_name}:entity:label]";

      case 'image':
        return "[node:{$field_name}:entity:url]";

      case 'datetime':
      case 'daterange':
        return "[node:{$field_name}:value]";

      case 'link':
        return "[node:{$field_name}:uri]";

      default:
        return $base;
    }
  }

  /**
   * Builds the prompt for schema type identification.
   *
   * @param string $content_summary
   *   The content summary.
   * @param string $types_list
   *   Available types list.
   *
   * @return string
   *   The prompt.
   */
  protected function buildSchemaTypePrompt(string $content_summary, string $types_list): string {
    return <<<PROMPT
Analyze the following content samples and identify the most appropriate schema.org type.

{$content_summary}

Available schema.org types: {$types_list}

Based on the content, which single schema.org type is most appropriate?
Reply with ONLY the type name (e.g., "Article" or "Event"), nothing else.
PROMPT;
  }

  /**
   * Builds the prompt for field mapping suggestions.
   *
   * @param string $schema_type
   *   The schema.org type.
   * @param array $properties
   *   Schema.org properties.
   * @param string $field_info
   *   Field information.
   * @param string $content_samples
   *   Content samples.
   *
   * @return string
   *   The prompt.
   */
  protected function buildMappingPrompt(string $schema_type, array $properties, string $field_info, string $content_samples): string {
    $properties_list = implode(', ', $properties);

    return <<<PROMPT
Create a YAML mapping from Drupal fields to schema.org properties for type "{$schema_type}".

{$field_info}

{$content_samples}

Schema.org properties for {$schema_type}: {$properties_list}

Create a YAML mapping using Drupal token syntax. Example format:

headline: '[node:title]'
description: '[node:body:summary]'
datePublished: '[node:created:html_datetime]'
author:
  '@type': Person
  name: '[node:author:display-name]'

Rules:
1. Use Drupal token syntax: [node:field_name] for custom fields, [node:title] for title, etc.
2. Only map fields that have appropriate schema.org properties
3. Use nested objects for complex properties (author, location, etc.)
4. Include @type for nested objects
5. Use appropriate date format tokens like :html_datetime for dates

Reply with ONLY the YAML mapping, no explanation or markdown code blocks.
PROMPT;
  }

  /**
   * Gets the system prompt for schema type identification.
   *
   * @return string
   *   The system prompt.
   */
  protected function getSchemaTypeSystemPrompt(): string {
    return <<<PROMPT
You are a schema.org expert. Your task is to analyze content and identify the most appropriate schema.org type.
Be concise and reply with only the type name.
Consider the content's purpose, structure, and typical use case when selecting a type.
PROMPT;
  }

  /**
   * Gets the system prompt for field mapping.
   *
   * @return string
   *   The system prompt.
   */
  protected function getMappingSystemPrompt(): string {
    return <<<PROMPT
You are a schema.org and Drupal expert. Your task is to create YAML mappings from Drupal fields to schema.org properties.

Key rules:
1. Use Drupal token syntax: [node:title], [node:body:summary], [node:field_name], [node:created:html_datetime]
2. For entity reference fields, use: [node:field_name:entity:label] or [node:field_name:entity:url]
3. IMPORTANT - For media/image reference fields, use the full path with image style: [node:field_name:entity:field_image:uncropped_lg:url]
4. For direct image fields (not media), use: [node:field_name:entity:url]
5. For author/user references, use: [node:author:display-name], [node:author:url:absolute]
6. For dates, prefer ISO 8601 format with :html_datetime suffix
7. Create nested structures for complex properties like author, location, publisher
8. Always include @type for nested objects

Use the exact token format provided in the field information. Output clean, valid YAML only. No markdown formatting, no explanations.
PROMPT;
  }

  /**
   * Parses the schema type response.
   *
   * @param string $response
   *   The AI response.
   * @param array $valid_types
   *   Valid type IDs.
   *
   * @return string
   *   The parsed type ID.
   */
  protected function parseSchemaTypeResponse(string $response, array $valid_types): string {
    $response = trim($response);

    // Try to find a valid type in the response.
    foreach ($valid_types as $type) {
      if (stripos($response, $type) !== FALSE) {
        return $type;
      }
    }

    // Default to Article if no match found.
    return 'Article';
  }

  /**
   * Parses the mapping response.
   *
   * @param string $response
   *   The AI response.
   *
   * @return string
   *   The cleaned YAML string.
   */
  protected function parseMappingResponse(string $response): string {
    $response = trim($response);

    // Remove markdown code blocks if present.
    $response = preg_replace('/^```ya?ml?\s*/i', '', $response);
    $response = preg_replace('/\s*```\s*$/', '', $response);

    // Remove any leading/trailing whitespace.
    $response = trim($response);

    return $response;
  }

}
