<?php

namespace Drupal\ai_schema\Service;

use Drupal\Component\Serialization\Yaml;
use Drupal\Component\Serialization\Exception\InvalidDataTypeException;

/**
 * Service for processing YAML configuration for schema.org mappings.
 */
class YamlProcessor {

  /**
   * Encodes data to YAML string.
   *
   * @param array $data
   *   The data to encode.
   *
   * @return string
   *   The YAML string.
   */
  public function encode(array $data): string {
    if (empty($data)) {
      return '';
    }

    try {
      $yaml = Yaml::encode($data);
      // Clean up the output for readability.
      $yaml = $this->tidy($yaml);
      return $yaml;
    }
    catch (\Exception $e) {
      return '';
    }
  }

  /**
   * Decodes a YAML string to an array.
   *
   * @param string $yaml
   *   The YAML string to decode.
   *
   * @return array
   *   The decoded array, or empty array on failure.
   */
  public function decode(string $yaml): array {
    if (empty(trim($yaml))) {
      return [];
    }

    try {
      $data = Yaml::decode($yaml);
      return is_array($data) ? $data : [];
    }
    catch (InvalidDataTypeException $e) {
      return [];
    }
    catch (\Exception $e) {
      return [];
    }
  }

  /**
   * Validates a YAML string.
   *
   * @param string $yaml
   *   The YAML string to validate.
   *
   * @return string|null
   *   Error message if invalid, NULL if valid.
   */
  public function validate(string $yaml): ?string {
    if (empty(trim($yaml))) {
      return NULL;
    }

    try {
      $data = Yaml::decode($yaml);
      if (!is_array($data)) {
        return t('YAML must decode to an array or object.');
      }
      return NULL;
    }
    catch (InvalidDataTypeException $e) {
      return t('Invalid YAML: @message', ['@message' => $e->getMessage()]);
    }
    catch (\Exception $e) {
      return t('YAML parsing error: @message', ['@message' => $e->getMessage()]);
    }
  }

  /**
   * Checks if a YAML string is valid.
   *
   * @param string $yaml
   *   The YAML string to check.
   *
   * @return bool
   *   TRUE if valid, FALSE otherwise.
   */
  public function isValid(string $yaml): bool {
    return $this->validate($yaml) === NULL;
  }

  /**
   * Tidies YAML output for better readability.
   *
   * @param string $yaml
   *   The YAML string to tidy.
   *
   * @return string
   *   The tidied YAML string.
   */
  public function tidy(string $yaml): string {
    // Normalize line endings.
    $yaml = str_replace("\r\n", "\n", $yaml);
    $yaml = str_replace("\r", "\n", $yaml);

    // Remove trailing whitespace from lines.
    $yaml = preg_replace('/[ \t]+$/m', '', $yaml);

    // Ensure single trailing newline.
    $yaml = rtrim($yaml) . "\n";

    return $yaml;
  }

  /**
   * Merges two YAML configurations.
   *
   * Bundle configuration overrides global configuration.
   *
   * @param string $global_yaml
   *   The global YAML configuration.
   * @param string $bundle_yaml
   *   The bundle-specific YAML configuration.
   *
   * @return array
   *   The merged configuration array.
   */
  public function merge(string $global_yaml, string $bundle_yaml): array {
    $global = $this->decode($global_yaml);
    $bundle = $this->decode($bundle_yaml);

    return array_replace_recursive($global, $bundle);
  }

}
