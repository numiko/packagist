# AI Schema Module - Implementation Specification

## Executive Summary

The `ai_schema` module provides AI-assisted schema.org structured data markup for Drupal content types. It analyzes content examples using AI to suggest appropriate schema.org entity types and field mappings, stores these as YAML configuration per content type, and outputs JSON-LD structured data on pages.

---

## 1. Module Architecture

```
ai_schema/
├── ai_schema.info.yml
├── ai_schema.module
├── ai_schema.services.yml
├── ai_schema.permissions.yml
├── ai_schema.routing.yml
├── ai_schema.links.menu.yml
├── config/
│   ├── install/
│   │   ├── ai_schema.settings.yml
│   │   └── ai_schema.bundle_settings.node.article.yml   # Default preset
│   │   └── ai_schema.bundle_settings.node.event.yml     # Default preset
│   └── schema/
│       ├── ai_schema.schema.yml
│       └── ai_schema.bundle_settings.schema.yml
├── data/
│   └── schema_org_types.json           # Bundled common schema.org types
└── src/
    ├── AiSchemaManager.php             # Core schema management service
    ├── Form/
    │   ├── GlobalSettingsForm.php      # Global schema.org settings
    │   └── FormHelper.php              # Form attachment service
    ├── Service/
    │   ├── SchemaOrgFetcher.php        # Fetches/caches schema.org definitions
    │   ├── AiSchemaAnalyzer.php        # AI analysis service
    │   ├── YamlProcessor.php           # YAML parsing/validation
    │   └── JsonLdBuilder.php           # Builds JSON-LD output
    ├── Form/Handler/
    │   └── BundleEntityFormHandler.php # Handles bundle form integration
    └── EventSubscriber/
        └── PageAttachmentSubscriber.php # Attaches JSON-LD to pages
```

---

## 2. Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Schema.org vocabulary | Hybrid: bundle common types, lazy-load others | Balance between performance and completeness |
| AI provider config | Use site-wide default from AI module | Simplicity; AI module is a dependency |
| Content sampling | 3-5 samples, manual selection via autocomplete | Balance between AI accuracy and token cost |
| Nested schema depth | 3 levels initially | Covers most use cases; document limitation |
| Multi-type support | Single type per bundle (MVP) | Simplicity for initial release |
| Validation | Warn on unknown properties, allow anyway | Flexibility with guidance |
| Form UX | Full YAML editor (MVP) | Power users; simpler to implement |
| Permissions | Single `administer ai_schema` permission | Simplicity |
| MVP schema types | Person, Organization, Article, Event | Most common use cases |
| Default presets | Ship with Article, Event, Organization | Quick start for users |

---

## 3. Core Components

### 3.1 Bundle Form Integration

Following the `simple_sitemap` pattern, attach schema configuration to bundle entity forms:

```php
// ai_schema.module
function ai_schema_form_alter(&$form, FormStateInterface $form_state, $form_id) {
  /** @var \Drupal\ai_schema\Form\FormHelper $form_helper */
  $form_helper = \Drupal::service('ai_schema.form_helper');
  $form_helper->formAlter($form, $form_state);
}
```

**Form Elements (MVP):**
1. **Enabled** - Checkbox to enable/disable schema output for this bundle
2. **Schema Type** - Dropdown of schema.org types (Article, Person, Organization, Event)
3. **Content Sampler** - Entity autocomplete to select 3-5 example content items
4. **AI Analysis Button** - Triggers AI to suggest field mappings
5. **YAML Editor** - Textarea for field mappings (no fancy editor for MVP)
6. **Preview** - Shows resulting JSON-LD preview for a selected entity

### 3.2 YAML Configuration Format

Schema mappings stored as YAML in Drupal config:

```yaml
# Example: ai_schema.bundle_settings.node.article.yml
enabled: true
schema_type: Article
mappings: |
  headline: '[node:title]'
  description: '[node:body:summary]'
  datePublished: '[node:created:html_datetime]'
  dateModified: '[node:changed:html_datetime]'
  author:
    '@type': Person
    name: '[node:author:display-name]'
    url: '[node:author:url:absolute]'
  image: '[node:field_image:url]'
  publisher:
    '@type': Organization
    name: '[site:name]'
```

### 3.3 Global Settings

Site-wide schema.org defaults (merged with bundle-specific):

```yaml
# ai_schema.settings.yml
global_schema: |
  publisher:
    '@type': Organization
    name: '[site:name]'
    url: '[site:url]'
    logo:
      '@type': ImageObject
      url: '[site:logo:url]'
schema_org_cache_ttl: 86400
```

### 3.4 AI Analysis Workflow

**Two-stage process:**

```
Stage 1: Schema Type Identification
├── Input: Sample content (title, body, field values)
├── AI Prompt: Identify most appropriate schema.org type from [Article, Person, Organization, Event]
└── Output: Recommended schema.org type

Stage 2: Field Mapping Suggestion
├── Input: Schema type + Available Drupal fields + Sample field values
├── AI Prompt: Map Drupal fields to schema.org properties using token syntax
└── Output: YAML mapping configuration
```

Uses site-wide default AI provider configured in AI module.

---

## 4. Technical Specifications

### 4.1 Configuration Schema

```yaml
# config/schema/ai_schema.schema.yml
ai_schema.settings:
  type: config_object
  label: 'AI Schema settings'
  mapping:
    global_schema:
      type: text
      label: 'Global schema.org YAML'
    schema_org_cache_ttl:
      type: integer
      label: 'Schema.org vocabulary cache TTL (seconds)'

ai_schema.bundle_settings.*.*:
  type: config_object
  label: 'Bundle schema settings'
  mapping:
    enabled:
      type: boolean
      label: 'Enabled'
    schema_type:
      type: string
      label: 'Primary schema.org type'
    mappings:
      type: text
      label: 'Field mappings YAML'
```

### 4.2 Services

```yaml
# ai_schema.services.yml
services:
  ai_schema.form_helper:
    class: Drupal\ai_schema\Form\FormHelper
    arguments:
      - '@current_user'
      - '@entity_type.manager'
      - '@config.factory'
      - '@class_resolver'

  ai_schema.yaml_processor:
    class: Drupal\ai_schema\Service\YamlProcessor

  ai_schema.schema_org_fetcher:
    class: Drupal\ai_schema\Service\SchemaOrgFetcher
    arguments:
      - '@cache.default'
      - '@http_client'
      - '@config.factory'

  ai_schema.ai_analyzer:
    class: Drupal\ai_schema\Service\AiSchemaAnalyzer
    arguments:
      - '@ai.provider'
      - '@entity_type.manager'
      - '@entity_field.manager'

  ai_schema.json_ld_builder:
    class: Drupal\ai_schema\Service\JsonLdBuilder
    arguments:
      - '@config.factory'
      - '@ai_schema.yaml_processor'
      - '@token'

  ai_schema.page_subscriber:
    class: Drupal\ai_schema\EventSubscriber\PageAttachmentSubscriber
    arguments:
      - '@current_route_match'
      - '@ai_schema.json_ld_builder'
    tags:
      - { name: event_subscriber }
```

### 4.3 AI Service Integration

```php
// src/Service/AiSchemaAnalyzer.php
class AiSchemaAnalyzer {

  public function identifySchemaType(array $content_samples): string {
    $provider_config = $this->providerManager->getDefaultProviderForOperationType('chat');

    $prompt = $this->buildSchemaTypePrompt($content_samples);

    $input = new ChatInput([
      new ChatMessage('user', $prompt),
    ]);
    $input->setSystemPrompt($this->getSystemPrompt());

    $response = $provider_config['provider']
      ->chat($input, $provider_config['model_id'], ['ai_schema'])
      ->getNormalized();

    return $this->parseSchemaTypeResponse($response->getText());
  }

  public function suggestFieldMappings(
    string $schema_type,
    array $fields,
    array $content_samples
  ): string {
    // Similar pattern, returns YAML string
  }

  protected function getSystemPrompt(): string {
    return <<<PROMPT
You are a schema.org expert. Your task is to analyze Drupal content and suggest
appropriate schema.org structured data mappings.

When suggesting field mappings, use Drupal token syntax:
- [node:title] for node title
- [node:body:summary] for body summary
- [node:field_name] for custom fields
- [node:author:display-name] for author name
- [site:name] for site name

Return YAML format for mappings.
PROMPT;
  }
}
```

### 4.4 Token Integration

```php
// src/Service/JsonLdBuilder.php
class JsonLdBuilder {

  public function buildJsonLd(EntityInterface $entity): ?array {
    $bundle_config = $this->getBundleConfig($entity);

    if (empty($bundle_config) || !$bundle_config['enabled']) {
      return NULL;
    }

    $global_config = $this->getGlobalConfig();

    // Decode YAML configurations
    $bundle_schema = $this->yamlProcessor->decode($bundle_config['mappings'] ?? '');
    $global_schema = $this->yamlProcessor->decode($global_config['global_schema'] ?? '');

    // Merge configurations (bundle overrides global)
    $merged = array_replace_recursive($global_schema, $bundle_schema);

    if (empty($merged)) {
      return NULL;
    }

    // Add @type from config
    $merged['@type'] = $bundle_config['schema_type'];

    // Process tokens
    $token_data = $this->buildTokenData($entity);
    $json_ld = $this->processTokensRecursive($merged, $token_data);

    // Add context
    $json_ld['@context'] = 'https://schema.org';

    return $json_ld;
  }

  protected function buildTokenData(EntityInterface $entity): array {
    $data = [];

    // Add entity-specific token data
    $entity_type = $entity->getEntityTypeId();
    $data[$entity_type] = $entity;

    // Add author/owner if available
    if (method_exists($entity, 'getOwner')) {
      $data['user'] = $entity->getOwner();
    }

    return $data;
  }

  protected function processTokensRecursive(array $data, array $token_data): array {
    $bubbleable_metadata = new BubbleableMetadata();

    array_walk_recursive($data, function (&$value) use ($token_data, $bubbleable_metadata) {
      if (is_string($value) && strpos($value, '[') !== FALSE) {
        $value = $this->token->replace($value, $token_data, [], $bubbleable_metadata);
        // Remove empty token replacements
        if (empty($value) || $value === $value) {
          $value = NULL;
        }
      }
    });

    // Remove null values recursively
    return $this->removeNullValues($data);
  }
}
```

### 4.5 Page Attachment

```php
// src/EventSubscriber/PageAttachmentSubscriber.php
class PageAttachmentSubscriber implements EventSubscriberInterface {

  public static function getSubscribedEvents() {
    return [
      KernelEvents::RESPONSE => ['onResponse', -100],
    ];
  }

  // Alternative: use hook_page_attachments() in .module file
}

// ai_schema.module
function ai_schema_page_attachments(array &$attachments) {
  $route_match = \Drupal::routeMatch();
  $json_ld_builder = \Drupal::service('ai_schema.json_ld_builder');

  // Check supported entity types
  foreach (['node'] as $entity_type) {
    if ($entity = $route_match->getParameter($entity_type)) {
      $json_ld = $json_ld_builder->buildJsonLd($entity);

      if (!empty($json_ld)) {
        $attachments['#attached']['html_head'][] = [
          [
            '#type' => 'html_tag',
            '#tag' => 'script',
            '#attributes' => ['type' => 'application/ld+json'],
            '#value' => json_encode($json_ld, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT),
          ],
          'ai_schema_jsonld',
        ];
      }
      break;
    }
  }
}
```

---

## 5. Default Presets

Ship with these default configurations:

### Article Preset
```yaml
# config/install/ai_schema.bundle_settings.node.article.yml
enabled: false
schema_type: Article
mappings: |
  headline: '[node:title]'
  description: '[node:body:summary]'
  datePublished: '[node:created:html_datetime]'
  dateModified: '[node:changed:html_datetime]'
  author:
    '@type': Person
    name: '[node:author:display-name]'
```

### Event Preset
```yaml
# config/install/ai_schema.bundle_settings.node.event.yml
enabled: false
schema_type: Event
mappings: |
  name: '[node:title]'
  description: '[node:body:summary]'
  startDate: '[node:field_event_date:value]'
  endDate: '[node:field_event_date:end_value]'
  location:
    '@type': Place
    name: '[node:field_location]'
```

### Organization Preset (Global)
```yaml
# config/install/ai_schema.settings.yml
global_schema: |
  publisher:
    '@type': Organization
    name: '[site:name]'
    url: '[site:url]'
schema_org_cache_ttl: 86400
```

---

## 6. Implementation Phases

### Phase 1: Module Scaffold
- Create module info, services, permissions files
- Implement `YamlProcessor` service
- Create configuration schema
- Set up basic routing for global settings form

### Phase 2: Bundle Form Integration
- Implement `FormHelper` service (following simple_sitemap pattern)
- Create `BundleEntityFormHandler`
- Add schema type selector and YAML textarea to bundle forms
- Implement config save/load

### Phase 3: Schema.org Vocabulary
- Bundle common types (Article, Person, Organization, Event) as JSON
- Implement `SchemaOrgFetcher` with caching
- Add validation warnings for unknown properties

### Phase 4: AI Analysis
- Implement `AiSchemaAnalyzer` service
- Create prompts for type identification and field mapping
- Add AJAX handler for AI analysis button
- Parse AI responses into YAML

### Phase 5: JSON-LD Output
- Implement `JsonLdBuilder` service
- Add `hook_page_attachments()` for JSON-LD injection
- Process tokens recursively
- Merge global + bundle configurations

### Phase 6: Polish
- Add JSON-LD preview in bundle form
- Add default presets
- Basic validation and error handling
- Documentation

---

## 7. Complexity Notes

### High Complexity
1. **AI Response Parsing** - AI responses may vary; need robust parsing with fallbacks
2. **Token Processing in Nested Structures** - Recursive replacement with proper cache metadata

### Medium Complexity
1. **Cache Invalidation** - Invalidate JSON-LD when content or config changes
2. **Error Handling** - Graceful degradation when AI unavailable or tokens fail

### Handled by Dependencies
- **Multi-value Fields** - Token module handles field delta syntax `[node:field:0:value]`
- **AI Provider Selection** - AI module handles provider configuration

---

## 8. Permissions

```yaml
# ai_schema.permissions.yml
administer ai_schema:
  title: 'Administer AI Schema'
  description: 'Configure schema.org mappings for content types and global settings.'
  restrict access: true
```

---

## 9. Dependencies

```yaml
# ai_schema.info.yml
name: 'AI Schema'
type: module
description: 'AI-assisted schema.org structured data for content types.'
package: 'AI'
core_version_requirement: ^10 || ^11
dependencies:
  - ai:ai
  - token:token
```

---

## 10. Available Token Types

Document for users which tokens are available:

| Token Type | Example | Description |
|------------|---------|-------------|
| `[node:*]` | `[node:title]` | Node properties and fields |
| `[node:author:*]` | `[node:author:display-name]` | Node author (user) properties |
| `[node:field_name]` | `[node:field_image:url]` | Custom field values |
| `[site:*]` | `[site:name]` | Site-wide properties |
| `[current-date:*]` | `[current-date:html_datetime]` | Current date/time |

For multi-value fields, use delta: `[node:field_tags:0:name]`, `[node:field_tags:1:name]`

---

## 11. File Checklist

| File | Purpose | Phase |
|------|---------|-------|
| `ai_schema.info.yml` | Module definition | 1 |
| `ai_schema.module` | Hooks (form_alter, page_attachments) | 1-2 |
| `ai_schema.services.yml` | Service definitions | 1 |
| `ai_schema.permissions.yml` | Permission definition | 1 |
| `ai_schema.routing.yml` | Admin routes | 1 |
| `ai_schema.links.menu.yml` | Admin menu links | 1 |
| `config/schema/ai_schema.schema.yml` | Config schema | 1 |
| `config/install/ai_schema.settings.yml` | Default global config | 1 |
| `src/Service/YamlProcessor.php` | YAML encode/decode/validate | 1 |
| `src/Form/GlobalSettingsForm.php` | Global settings form | 1 |
| `src/Form/FormHelper.php` | Form attachment router | 2 |
| `src/Form/Handler/BundleEntityFormHandler.php` | Bundle form handler | 2 |
| `data/schema_org_types.json` | Bundled schema.org types | 3 |
| `src/Service/SchemaOrgFetcher.php` | Schema.org vocabulary | 3 |
| `src/Service/AiSchemaAnalyzer.php` | AI analysis service | 4 |
| `src/Service/JsonLdBuilder.php` | JSON-LD output builder | 5 |
| `config/install/ai_schema.bundle_settings.*.yml` | Default presets | 6 |
