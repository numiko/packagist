# AI Schema

AI-assisted schema.org structured data for Drupal content types.

## Overview

The AI Schema module provides an intelligent way to add schema.org structured data (JSON-LD) to your Drupal content. It uses AI to analyze your content and suggest appropriate schema.org type mappings, then outputs properly formatted JSON-LD in the page head for search engine optimization.

## Features

- **AI-Powered Analysis**: Automatically identify the best schema.org type for your content and suggest field mappings
- **Per-Content-Type Configuration**: Configure schema.org mappings for each content type independently
- **Global Settings**: Define site-wide schema.org defaults that apply to all content
- **YAML-Based Configuration**: Flexible YAML format for defining field-to-property mappings
- **Token Integration**: Use Drupal tokens for dynamic value replacement
- **JSON-LD Output**: Automatically injects structured data into page head on entity pages

## Requirements

- Drupal 10.x or 11.x
- [AI Module](https://www.drupal.org/project/ai) - with a configured AI provider (OpenAI, Anthropic, etc.)
- [Token Module](https://www.drupal.org/project/token)

## Installation

1. Install the module and its dependencies:
   ```bash
   composer require drupal/ai drupal/token
   drush en ai_schema -y
   drush cr
   ```

2. Ensure you have an AI provider configured in the AI module settings at `/admin/config/ai/settings`

## Configuration

### Global Settings

Visit `/admin/config/search/ai-schema` to configure global schema.org settings that apply to all content types.

Example global configuration:
```yaml
publisher:
  '@type': Organization
  name: '[site:name]'
  url: '[site:url]'
```

### Per-Content-Type Settings

1. Navigate to the content type edit form (e.g., `/admin/structure/types/manage/article`)
2. Find the "AI Schema (Schema.org)" section in the vertical tabs
3. Enable schema.org output
4. Select the appropriate schema.org type
5. Use AI analysis or manually configure field mappings

## Using AI Analysis

1. On the content type edit form, open the "AI Schema" section
2. In the "AI Analysis" section, use the autocomplete to select 1-5 sample content items
3. Click "Analyze with AI"
4. The AI will:
   - Identify the most appropriate schema.org type (if not already selected)
   - Suggest field mappings based on your content structure
5. Review and adjust the suggested YAML mappings as needed
6. Save the content type

## YAML Mapping Format

Mappings use YAML format with Drupal token syntax:

```yaml
headline: '[node:title]'
description: '[node:body:summary]'
datePublished: '[node:created:html_datetime]'
dateModified: '[node:changed:html_datetime]'
author:
  '@type': Person
  name: '[node:author:display-name]'
  url: '[node:author:url:absolute]'
image: '[node:field_image:entity:url]'
```

## Available Tokens

| Token | Description |
|-------|-------------|
| `[node:title]` | Content title |
| `[node:body]` | Body field value |
| `[node:body:summary]` | Body summary |
| `[node:created:html_datetime]` | Created date (ISO 8601) |
| `[node:changed:html_datetime]` | Updated date (ISO 8601) |
| `[node:author:display-name]` | Author display name |
| `[node:author:url:absolute]` | Author profile URL |
| `[node:url:absolute]` | Absolute URL to content |
| `[node:field_NAME]` | Custom field value |
| `[node:field_NAME:entity:url]` | Referenced entity URL |
| `[node:field_NAME:entity:label]` | Referenced entity label |
| `[site:name]` | Site name |
| `[site:url]` | Site URL |

For multi-value fields, use delta: `[node:field_tags:0:name]`, `[node:field_tags:1:name]`

## Supported Schema.org Types

The module includes built-in support for common schema.org types:

- **Content**: Article, NewsArticle, BlogPosting, WebPage, FAQPage
- **Events**: Event
- **Organizations**: Organization, LocalBusiness
- **People**: Person
- **Products**: Product
- **Creative Works**: CreativeWork, Book, Movie, Recipe, HowTo
- **Media**: VideoObject, ImageObject
- **Other**: Course, JobPosting, Review, SoftwareApplication

## JSON-LD Output

When configured, the module outputs JSON-LD in the page head:

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "My Article Title",
  "description": "Article summary...",
  "datePublished": "2024-01-15T10:30:00+00:00",
  "author": {
    "@type": "Person",
    "name": "John Doe"
  }
}
</script>
```

## Permissions

| Permission | Description |
|------------|-------------|
| `administer ai_schema` | Configure schema.org mappings for content types and global settings |

## Troubleshooting

### AI Analysis Not Working

- Ensure an AI provider is configured in the AI module settings
- Check that the AI provider has sufficient credits/quota
- Review Drupal logs for error messages

### JSON-LD Not Appearing

- Verify schema.org output is enabled for the content type
- Check that the content type has a schema type selected
- Ensure field mappings are configured
- Clear Drupal caches after configuration changes

### Token Replacement Issues

- Verify the token syntax is correct (e.g., `[node:title]` not `{node:title}`)
- Check that referenced fields exist on the content type
- For entity references, use `:entity:url` or `:entity:label` suffixes

## API Usage

### Building JSON-LD Programmatically

```php
/** @var \Drupal\ai_schema\Service\JsonLdBuilder $builder */
$builder = \Drupal::service('ai_schema.json_ld_builder');
$json_ld = $builder->buildJsonLd($node);
```

### Validating YAML Configuration

```php
/** @var \Drupal\ai_schema\Service\YamlProcessor $processor */
$processor = \Drupal::service('ai_schema.yaml_processor');
$error = $processor->validate($yaml_string);
if ($error) {
  // Handle validation error
}
```

### Getting Schema.org Type Properties

```php
/** @var \Drupal\ai_schema\Service\SchemaOrgFetcher $fetcher */
$fetcher = \Drupal::service('ai_schema.schema_org_fetcher');
$properties = $fetcher->getTypeProperties('Article');
```

## Contributing

Issues and feature requests can be submitted to the project issue queue.

## License

This module is licensed under the GPL-2.0-or-later license.
