<?php

namespace Drupal\scheduled_site_alerts\Hook;

use Drupal\Core\Hook\Attribute\Hook;

/**
 * Hook implementations for scheduled_site_alerts.
 */
class ScheduledSiteAlertsHooks {

  /**
   * Implements hook_gin_content_form_routes().
   *
   * Adds the gin sidebar to the alert form so that the scheduled content fields
   * appear in the sidebar.
   */
  #[Hook('gin_content_form_routes')]
  public function ginContentFormRoutes(): array {
    return [
      'entity.alert.add_form',
      'entity.alert.edit_form',
    ];
  }

}
