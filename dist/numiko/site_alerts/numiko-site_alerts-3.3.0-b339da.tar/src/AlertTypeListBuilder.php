<?php

namespace Drupal\site_alerts;

use Drupal\Core\Config\Entity\ConfigEntityListBuilder;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Link;

/**
 * Defines a class to build a listing of Alert entities.
 *
 * @ingroup site_alerts
 */
class AlertTypeListBuilder extends ConfigEntityListBuilder {

  /**
   * {@inheritdoc}
   */
  public function buildHeader() {
    $header['name'] = $this->t('Name');
    return $header + parent::buildHeader();
  }

  /**
   * {@inheritdoc}
   */
  public function buildRow(EntityInterface $entity) {
    /** @var \Drupal\site_alerts\Entity\Alert $entity */
    $row['name'] = Link::createFromRoute(
      $entity->label(),
      'entity.alert_type.edit_form',
      ['alert_type' => $entity->id()]
    );

    return $row + parent::buildRow($entity);
  }

}
