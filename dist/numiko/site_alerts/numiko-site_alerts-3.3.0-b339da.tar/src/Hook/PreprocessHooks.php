<?php

namespace Drupal\site_alerts\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Render\Element;

/**
 * Preprocess hook implementations for site_alerts.
 */
final class PreprocessHooks {

  /**
   * Implements hook_theme().
   */
  #[Hook('theme')]
  public function theme(): array {
    return [
      'alert' => [
        'render element' => 'elements',
        'initial preprocess' => static::class . ':preprocessAlert',
      ],
    ];
  }

  /**
   * Implements hook_theme_suggestions_alert().
   */
  #[Hook('theme_suggestions_alert')]
  public function themeSuggestionsAlert(array $variables): array {
    $suggestions = [];
    $entity = $variables['elements']['#alert'];
    $sanitized_view_mode = strtr($variables['elements']['#view_mode'], '.', '_');
    $suggestions[] = 'alert__' . $sanitized_view_mode;
    $suggestions[] = 'alert__' . $entity->bundle();
    $suggestions[] = 'alert__' . $entity->bundle() . '__' . $sanitized_view_mode;
    $suggestions[] = 'alert__' . $entity->id();
    $suggestions[] = 'alert__' . $entity->id() . '__' . $sanitized_view_mode;
    return $suggestions;
  }

  /**
   * Prepares variables for alert templates.
   *
   * Default template: alert.html.twig.
   *
   * Most themes use their own copy of alert.html.twig. The default is located
   * inside "templates/alert.html.twig". Look in there for the
   * full list of variables.
   *
   * @param array $variables
   *   An associative array containing:
   *   - elements: An array of elements to display in view mode.
   *   - alert: The alert object.
   *   - view_mode: View mode; e.g., 'full', 'teaser'...
   */
  public function preprocessAlert(array &$variables): void {
    $alert = $variables['elements']['#alert'];

    $variables['view_mode'] = $variables['elements']['#view_mode'];
    $variables['alert'] = $alert;
    $variables['warning_level'] = $alert->getWarningLevel();

    // Helpful $content variable for templates.
    $variables += ['content' => []];
    foreach (Element::children($variables['elements']) as $key) {
      $variables['content'][$key] = $variables['elements'][$key];
    }
  }

}
