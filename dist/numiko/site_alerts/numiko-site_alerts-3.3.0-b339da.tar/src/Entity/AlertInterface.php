<?php

namespace Drupal\site_alerts\Entity;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;

/**
 * Provides an interface for defining Alert entities.
 *
 * @ingroup site_alerts
 */
interface AlertInterface extends ContentEntityInterface, EntityChangedInterface {

  /**
   * Gets the Alert name.
   *
   * @return string
   *   Name of the Alert.
   */
  public function getName();

  /**
   * Sets the Alert name.
   *
   * @param string $name
   *   The Alert name.
   *
   * @return \Drupal\site_alerts\Entity\AlertInterface
   *   The called Alert entity.
   */
  public function setName($name);

  /**
   * Gets the Alert creation timestamp.
   *
   * @return int
   *   Creation timestamp of the Alert.
   */
  public function getCreatedTime();

  /**
   * Sets the Alert creation timestamp.
   *
   * @param int $timestamp
   *   The Alert creation timestamp.
   *
   * @return \Drupal\site_alerts\Entity\AlertInterface
   *   The called Alert entity.
   */
  public function setCreatedTime($timestamp);

  /**
   * Returns the Alert published status indicator.
   *
   * Unpublished Alert are only visible to restricted users.
   *
   * @return bool
   *   TRUE if the Alert is published.
   */
  public function isPublished();

  /**
   * Sets the published status of an Alert.
   *
   * @return \Drupal\site_alerts\Entity\AlertInterface
   *   The called Alert entity.
   */
  public function setPublished();

  /**
   * Sets the Alert as unpublished.
   *
   * @return $this
   */
  public function setUnpublished();

  /**
   * Get the alert warning level.
   *
   * @return string
   *   Returns the warning level.
   */
  public function getWarningLevel();

}
