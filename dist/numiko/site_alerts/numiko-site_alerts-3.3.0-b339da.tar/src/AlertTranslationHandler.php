<?php

namespace Drupal\site_alerts;

use Drupal\Core\Entity\EntityInterface;
use Drupal\content_translation\ContentTranslationHandler;
use Drupal\site_alerts\Entity\AlertType;

/**
 * Defines the translation handler for alerts.
 */
class AlertTranslationHandler extends ContentTranslationHandler {

  /**
   * {@inheritdoc}
   */
  protected function entityFormTitle(EntityInterface $entity) {
    $alert_type = AlertType::load($entity->bundle());
    return t('<em>Edit @type</em> @title', ['@type' => $alert_type->label(), '@title' => $entity->label()]);
  }

}
