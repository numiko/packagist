<?php

namespace Drupal\site_alerts\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Configure settings for site alerts module.
 */
class SiteAlertsSettingsForm extends ConfigFormBase {

  /**
   * Config settings.
   *
   * @var string
   */
  const SETTINGS = 'site_alerts.settings';

  /**
   * The ID of the Alert object field_section field.
   *
   * @var string
   */
  const FIELD_SECTION_ID = 'alert.section_alert.field_section';

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'site_alert_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      static::SETTINGS,
    ];
  }

  /**
   * Class constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   Config factory service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   Entity type manager service.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entityFieldManager
   *   Entity field manager service.
   */
  public function __construct(
    ConfigFactoryInterface $configFactory,
    protected EntityTypeManagerInterface $entityTypeManager,
    protected EntityFieldManagerInterface $entityFieldManager,
  ) {
    $this->entityTypeManager = $entityTypeManager;
    $this->entityFieldManager = $entityFieldManager;
    parent::__construct($configFactory);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.manager'),
      $container->get('entity_field.manager')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config(static::SETTINGS);

    // Get the field map.
    $fieldMap = $this->entityFieldManager->getFieldMap();

    // Get all node entity_reference fields.
    $nodeFieldMap = $fieldMap['node'];
    $nodeFieldOptions = [];
    foreach ($nodeFieldMap as $fieldName => $nodeField) {
      if ($nodeField['type'] == 'entity_reference') {
        $nodeFieldOptions[$fieldName] = $fieldName;
      }
    }

    $form['site_alert_section_node_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Section node field'),
      '#description' => $this->t('Select a node field to replace the default field. This must be a taxonomy term reference. A cache clear may be required for this to take affect.'),
      '#options' => $nodeFieldOptions,
      '#default_value' => $config->get('site_alert_section_node_field'),
    ];

    // Get all taxonomy vocabularies.
    $vocabs = $this->entityTypeManager->getStorage('taxonomy_vocabulary')->loadMultiple();
    $vocabOptions = [];
    foreach ($vocabs as $vocabId => $vocab) {
      $vocabOptions[$vocabId] = $vocab->label();
    }

    $form['site_alert_section_taxonomy'] = [
      '#type' => 'select',
      '#title' => $this->t('Section taxonomy vocabulary'),
      '#description' => $this->t('Select a taxonomy vocabulary to replace the default taxonomy. A cache clear may be required for this to take affect. Changing this setting will amend a field definition, please ensure the configuration changes are exported and saved.'),
      '#options' => $vocabOptions,
      '#default_value' => $config->get('site_alert_section_taxonomy'),
    ];

    // Get all alert entity_reference fields.
    $alertFieldMap = $fieldMap['alert'];
    $alertFieldOptions = [];
    foreach ($alertFieldMap as $fieldName => $alertField) {
      if ($alertField['type'] == 'entity_reference') {
        $alertFieldOptions[$fieldName] = $fieldName;
      }
    }

    $form['site_alert_section_taxonomy_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Alert section taxonomy field'),
      '#description' => $this->t('Select a taxonomy field to replace the default field. This must be a taxonomy term reference. A cache clear may be required for this to take affect.'),
      '#options' => $alertFieldOptions,
      '#default_value' => $config->get('site_alert_section_taxonomy_field'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $previousTaxonomy = $this->config(static::SETTINGS)->get('site_alert_section_taxonomy');
    $newTaxonomy = $form_state->getValue('site_alert_section_taxonomy');

    $this->configFactory->getEditable(static::SETTINGS)
      // Set the submitted configuration setting.
      ->set('site_alert_section_node_field', $form_state->getValue('site_alert_section_node_field'))
      ->set('site_alert_section_taxonomy', $form_state->getValue('site_alert_section_taxonomy'))
      ->set('site_alert_section_taxonomy_field', $form_state->getValue('site_alert_section_taxonomy_field'))
      ->save();

    // If section taxonomy has changed update field definition target bundle.
    if ($newTaxonomy != $previousTaxonomy) {
      $fields = $this->entityTypeManager->getStorage('field_config')->loadByProperties(['id' => self::FIELD_SECTION_ID]);
      $field = reset($fields);
      $handlerSettings = $field->getSetting('handler_settings');
      $handlerSettings['target_bundles'] = [$newTaxonomy => $newTaxonomy];
      $field->setSetting('handler_settings', $handlerSettings);
      $field->save();
    }

    parent::submitForm($form, $form_state);
  }

}
