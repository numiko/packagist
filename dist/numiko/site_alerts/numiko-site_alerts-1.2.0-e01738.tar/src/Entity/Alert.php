<?php

namespace Drupal\site_alerts\Entity;

use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;

/**
 * Defines the Alert entity.
 *
 * @ingroup site_alerts
 *
 * @ContentEntityType(
 *   id = "alert",
 *   label = @Translation("Alert"),
 *   label_collection = @Translation("Alerts"),
 *   bundle_label = @Translation("Alert type"),
 *   handlers = {
 *     "view_builder" = "Drupal\Core\Entity\EntityViewBuilder",
 *     "list_builder" = "Drupal\site_alerts\AlertListBuilder",
 *     "views_data" = "Drupal\EntityViewsData",
 *
 *     "form" = {
 *       "default" = "Drupal\site_alerts\Form\AlertForm",
 *       "add" = "Drupal\site_alerts\Form\AlertForm",
 *       "edit" = "Drupal\site_alerts\Form\AlertForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm"
 *     },
 *     "translation" = "Drupal\content_translation\ContentTranslationHandler",
 *     "access" = "Drupal\site_alerts\AlertAccessControlHandler",
 *     "route_provider" = {
 *       "html" = "\Drupal\site_alerts\AlertEntityHtmlRouteProvider",
 *     },
 *   },
 *   base_table = "alert",
 *   data_table = "alert_field_data",
 *   translatable = TRUE,
 *   admin_permission = "administer alert entities",
 *   entity_keys = {
 *     "id" = "id",
 *     "bundle" = "type",
 *     "label" = "name",
 *     "uuid" = "uuid",
 *     "langcode" = "langcode",
 *     "status" = "status",
 *   },
 *   links = {
 *     "canonical" = "/admin/structure/alerts/{alert}",
 *     "add-page" = "/admin/structure/alerts/add",
 *     "add-form" = "/admin/structure/alerts/add/{alert_type}",
 *     "edit-form" = "/admin/structure/alerts/{alert}/edit",
 *     "delete-form" = "/admin/structure/alerts/{alert}/delete",
 *     "collection" = "/admin/structure/alerts",
 *   },
 *   bundle_entity_type = "alert_type",
 *   field_ui_base_route = "entity.alert_type.edit_form"
 * )
 */
class Alert extends ContentEntityBase implements AlertInterface {

  use EntityChangedTrait;

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->get('name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setName($name) {
    $this->set('name', $name);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getCreatedTime() {
    return $this->get('created')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setCreatedTime($timestamp) {
    $this->set('created', $timestamp);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function isPublished() {
    return (bool) $this->getEntityKey('status');
  }

  /**
   * {@inheritdoc}
   */
  public function setPublished($published) {
    $this->set('status', $published ? TRUE : FALSE);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getWarningLevel() {
    return $this->get('warning_level')->value;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setDescription(t('The name of the Alert.'))
      ->setSettings([
        'max_length' => 50,
        'text_processing' => 0,
      ])
      ->setDefaultValue('')
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'string',
        'weight' => -4,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -4,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRequired(TRUE);

    $fields['warning_level'] = BaseFieldDefinition::create("list_string")
      ->setSettings([
        'allowed_values' => [
          'critical' => 'Critical',
          'warning' => 'Warning',
          'polite' => 'Polite',
        ],
      ])
      ->setLabel('Warning level')
      ->setDescription('Set the warning level colour.')
      ->setRequired(TRUE)
      ->setDisplayOptions('form', [
        'type' => 'options_select',
        'weight' => 2,
      ])
      ->setDisplayConfigurable('form', TRUE);

    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Active'))
      ->setDefaultValue(TRUE)
      ->setDisplayOptions('form', [
        'type' => 'boolean_checkbox',
        'weight' => 50,
      ])
      ->setDisplayConfigurable('form', TRUE);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'))
      ->setDescription(t('The time that the entity was created.'));

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
      ->setDescription(t('The time that the entity was last edited.'));

    return $fields;
  }

}
