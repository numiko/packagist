<?php

namespace Drupal\site_alerts;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

abstract class AlertTypeBase extends PluginBase implements AlertTypeInterface, ContainerFactoryPluginInterface {

  /**
   * Entity type manager.
   *
   * @var Drupal\Core\Entity\EntityTypeManager
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
    );
    $instance->entityTypeManager = $container->get('entity_type.manager');
    return $instance;
  }

  /**
   * Verify the plugin configuration.
   */
  public function verifyPluginConfiguration() {
    return $this;
  }

  /**
   * Get the alert ID.
   */
  public function getId() {
    return $this->pluginDefinition['id'];
  }

  /**
   * Get the alert Name.
   */
  public function getName() {
    return $this->pluginDefinition['name'];
  }

  /**
   * Get alerts of the type that belong to the given plugin.
   *
   * For example if the plugin is "content_alert" then find all
   * alert types that are set to use the "content_alert" plugin and return
   * all alert entities matching those types.
   *
   * @param string $pluginId
   *   The ID of the alert type plugin to get alerts for.
   *
   * @return array
   *   Get an array of alert entities that belong to alert types
   *   of the current plugin.
   */
  protected function getAllAlertsAssignedToPlugin(string $pluginId) {
    $alertTypeStorage = $this->entityTypeManager->getStorage('alert_type');
    $alertStorage = $this->entityTypeManager->getStorage('alert');

    $alertTypes = $alertTypeStorage->loadByProperties([
      'status' => 1,
      'plugin' => $pluginId,
    ]);

    $alerts = [];
    foreach ($alertTypes as $alertType) {
      $alerts = array_merge($alertStorage->loadByProperties([
        'status' => 1,
        'type' => $alertType->id(),
      ]), $alerts);
    }
    return $alerts;
  }

}
