<?php

namespace Drupal\site_alerts\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBundleBase;

/**
 * Defines the Alert type entity.
 *
 * @ConfigEntityType(
 *   id = "alert_type",
 *   label = @Translation("Alert type"),
 *   label_collection = @Translation("Alert type"),
 *   handlers = {
 *     "list_builder" = "Drupal\site_alerts\AlertTypeListBuilder",
 *     "form" = {
 *       "add" = "Drupal\site_alerts\Form\AlertTypeForm",
 *       "edit" = "Drupal\site_alerts\Form\AlertTypeForm",
 *       "delete" = "Drupal\Core\Entity\EntityDeleteForm"
 *     },
 *     "route_provider" = {
 *       "default" = "\Drupal\Core\Entity\Routing\DefaultHtmlRouteProvider",
 *     },
 *   },
 *   config_prefix = "alert_type",
 *   admin_permission = "administer site configuration",
 *   bundle_of = "alert",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "plugin" = "plugin"
 *   },
 *   config_export = {
 *     "id",
 *     "label",
 *     "plugin"
 *   },
 *   links = {
 *     "add-form" = "/admin/structure/alert_type/add",
 *     "edit-form" = "/admin/structure/alert_type/{alert_type}/edit",
 *     "delete-form" = "/admin/structure/alert_type/{alert_type}/delete",
 *     "collection" = "/admin/structure/alert_type"
 *   }
 * )
 */
class AlertType extends ConfigEntityBundleBase {

  /**
   * The Alert type ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The Alert type label.
   *
   * @var string
   */
  protected $label;

  /**
   * The Alert type plugin.
   *
   * @var string
   */
  protected $plugin;

}
