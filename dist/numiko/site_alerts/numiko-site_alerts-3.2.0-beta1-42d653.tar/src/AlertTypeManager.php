<?php

namespace Drupal\site_alerts;

use Drupal\Core\Plugin\DefaultPluginManager;
use Drupal\Core\Cache\CacheBackendInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\site_alerts\Attribute\AlertType;

class AlertTypeManager extends DefaultPluginManager {

  /**
   * Constructs an StructuredDataManager object.
   *
   * @param \Traversable $namespaces
   *   An object that implements \Traversable which contains the root paths
   *   keyed by the corresponding namespace to look for plugin implementations.
   * @param \Drupal\Core\Cache\CacheBackendInterface $cache_backend
   *   Cache backend instance to use.
   * @param \Drupal\Core\Extension\ModuleHandlerInterface $module_handler
   *   The module handler to invoke the alter hook with.
   */
  public function __construct(\Traversable $namespaces, CacheBackendInterface $cache_backend, ModuleHandlerInterface $module_handler) {
    parent::__construct('Plugin/AlertType', $namespaces, $module_handler, 'Drupal\site_alerts\AlertTypeInterface', AlertType::class, 'Drupal\site_alerts\Annotation\AlertType');
    $this->alterInfo('alert_type_info');
    $this->setCacheBackend($cache_backend, 'alert_types');
  }

  /**
   * Gets a list of alerts
   *
   * @return list<mixed>
   */
  public function getAlertTypes(): array {
    $instances = $configuration = [];
    foreach ($this->getDefinitions() as $alertType) {
      $instances[] = $this->createInstance($alertType['id'], $configuration)->verifyPluginConfiguration();
    }
    return $instances;
  }

}
