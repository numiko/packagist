<?php

namespace Drupal\site_alerts;

use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\node\NodeInterface;

/**
 * The interface for an alert type plugin.
 */
interface AlertTypeInterface extends PluginInspectionInterface {

  /**
   * Get all alerts.
   *
   * @param Drupal\node\NodeInterface|null $node
   *   Optionally provide a node to query from.
   *
   * @return array
   *   Return an array of Drupal\site_alerts\Entity\Alert entities.
   */
  public function getAllAlerts(?NodeInterface $node): array;

}
