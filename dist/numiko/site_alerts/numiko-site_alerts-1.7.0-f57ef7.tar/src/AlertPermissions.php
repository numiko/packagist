<?php

namespace Drupal\site_alerts;

use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Class AlertPermissions.
 *
 * @package Drupal\site_alerts
 */
class AlertPermissions implements ContainerInjectionInterface {

  use StringTranslationTrait;

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructor for AlertPermissions.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   The entity type manager.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static($container->get('entity_type.manager'));
  }

  /**
   * Get permissions for Alerts.
   *
   * @return array
   *   Permissions array.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function permissions() {
    $permissions = [];

    foreach ($this->entityTypeManager->getStorage('alert_type')
               ->loadMultiple() as $type) {
      $permissions += [
        'create ' . $type->id() => [
          'title' => $this->t('Allow creation of %type', ['%type' => $type->label()]),
        ],
      ];

      $permissions += [
        'update ' . $type->id() => [
          'title' => $this->t('Allow update of %type', ['%type' => $type->label()]),
        ],
      ];

      $permissions += [
        'delete ' . $type->id() => [
          'title' => $this->t('Allow deletion of %type', ['%type' => $type->label()]),
        ],
      ];
    }

    return $permissions;
  }

}
