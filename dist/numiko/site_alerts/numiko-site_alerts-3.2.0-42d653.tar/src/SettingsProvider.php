<?php


namespace Drupal\site_alerts;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\ImmutableConfig;

/**
 * Class SettingsProvider.
 *
 * Provides site alert settings.
 *
 * @package Drupal\site_alerts
 */
class SettingsProvider {

  /**
   * Config settings.
   *
   * @var string
   */
  const SETTINGS = 'site_alerts.settings';

  /**
   * The default node field.
   *
   * @var string
   */
  const DEFAULT_NODE_SECTION_FIELD = 'site_alerts_section';

  /**
   * The currently set node section field.
   */
  protected string $nodeSectionField = self::DEFAULT_NODE_SECTION_FIELD;

  /**
   * The currently set section taxonomy.
   */
  protected string $sectionTaxonomy = 'site_section';

  /**
   * Stores whether a custom node section field has been set.
   */
  protected bool $hasCustomNodeSectionField = FALSE;

  /**
   * SettingsProvider constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactoryService
   *   Config factory service.
   */
  public function __construct(ConfigFactoryInterface $configFactoryService) {
    $config = $configFactoryService->get(self::SETTINGS);
    $this->applyConfigSettings($config);
  }

  /**
   * Populates member variables with current settings.
   *
   * @param \Drupal\Core\Config\ImmutableConfig $config
   *   Current config for this module.
   */
  private function applyConfigSettings(ImmutableConfig $config) {
    $sectionField = $config->get('site_alert_section_node_field');
    if (isset($sectionField)) {
      $this->nodeSectionField = $sectionField;
    }
    $taxonomy = $config->get('site_alert_section_taxonomy');
    if (isset($taxonomy)) {
      $this->sectionTaxonomy = $taxonomy;
    }
  }

  /**
   * Returns the section taxonomy set currently.
   *
   * @return string
   *   Machine name of the set section taxonomy.
   */
  public function getSectionTaxonomy() {
    return $this->sectionTaxonomy;
  }

  /**
   * Returns the node section field set currently.
   *
   * @return string
   *   Machine name of set node section field
   */
  public function getSectionNodeField() {
    return $this->nodeSectionField;
  }

  /**
   * Returns TRUE if a non-default section node field has been set.
   *
   * @return bool
   *   TRUE is non-default section node field is set.
   */
  public function hasCustomNodeField() {
    return $this->nodeSectionField != self::DEFAULT_NODE_SECTION_FIELD;
  }

}
