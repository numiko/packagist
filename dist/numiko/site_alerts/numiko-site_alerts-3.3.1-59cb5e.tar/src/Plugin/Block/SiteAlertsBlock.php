<?php

namespace Drupal\site_alerts\Plugin\Block;

use Drupal\Core\Entity\EntityViewBuilderInterface;
use Drupal\Core\Block\Attribute\Block;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Cache\Cache;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\node\NodeInterface;
use Drupal\site_alerts\Alerts;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Alerts Block.
 */
#[Block(
  id: 'site_alerts',
  admin_label: new TranslatableMarkup('Alerts'),
  category: new TranslatableMarkup('Alerts')
)]
class SiteAlertsBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * A node.
   */
  protected ?NodeInterface $node;

  /**
   * The route match.
   */
  protected RouteMatchInterface $routeMatch;

  /**
   * The alert view builder.
   */
  protected EntityViewBuilderInterface $viewBuilder;

  /**
   * The alerts service.
   */
  protected Alerts $alerts;

  /**
   * Create a Alert block instance.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Routing\RouteMatchInterface $route_match
   *   The current route match.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   EntityTypeManager.
   * @param \Drupal\site_alerts\Alerts $alerts
   *   Alerts.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, RouteMatchInterface $route_match, EntityTypeManagerInterface $entity_type_manager, Alerts $alerts) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->routeMatch = $route_match;
    $this->node = $this->getNode();
    $this->viewBuilder = $entity_type_manager->getViewBuilder('alert');
    $this->alerts = $alerts;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('current_route_match'),
      $container->get('entity_type.manager'),
      $container->get('site_alerts.alerts')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function build(): array {
    if ($this->node) {
      $allAlerts = $this->alerts->getAllAlerts($this->node);
    }
    else {
      $allAlerts = $this->alerts->getAllAlerts();
    }
    if (empty($allAlerts)) {
      return [];
    }
    return $this->viewBuilder->viewMultiple($allAlerts);
  }

  /**
   * Get the current node.
   */
  protected function getNode(): ?NodeInterface {
    $obj = $this->routeMatch->getParameter('node');
    if ($obj instanceof NodeInterface) {
      return $obj;
    }

    return NULL;
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheTags(): array {
    return Cache::mergeTags(
      parent::getCacheTags(),
      ['block:site_alerts'],
      $this->node ? $this->node->getCacheTags() : []
    );
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts(): array {
    return Cache::mergeContexts(parent::getCacheContexts(), ['url']);
  }

}
