<?php

namespace Drupal\site_alerts\Plugin\AlertType;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\node\NodeInterface;
use Drupal\site_alerts\AlertTypeBase;
use Drupal\site_alerts\Attribute\AlertType;

/**
 * Provides a 'section alert' alert type.
 */
#[AlertType(
  id: 'section_alert',
  name: new TranslatableMarkup('Section Alert')
)]
class SectionAlertType extends AlertTypeBase {

  /**
   * {@inheritDoc}
   */
  public function getAllAlerts(?NodeInterface $node): array {
    $section_alerts = [];
    // Section alerts only apply to content.
    if (!$node) {
      return $section_alerts;
    }

    $nodeSectionField = $this->settings->get('site_alert_section_node_field');
    $alertSectionField = $this->settings->get('site_alert_section_taxonomy_field');
    if ($node->hasField($nodeSectionField) && !$node->get($nodeSectionField)->isEmpty()) {
      $section = $node->get($nodeSectionField)->first()->getValue();
      $alerts = $this->getAllAlertsAssignedToPlugin($this->getId());
      foreach ($alerts as $alert) {
        /** @var \Drupal\site_alerts\Entity\alert $alert */
        if ($alert->hasField($alertSectionField) && !$alert->get($alertSectionField)->isEmpty()) {
          /*
           * Filter matching sections
           * The alert section field may be a multi-select field.
           * Use the filter() method to return any items matching the
           * current node's section setting. If the filtered fieldlist
           * is not empty, add the alert to the section_alerts array.
           */
          $section_target_id = $section['target_id'];
          $alert->get($alertSectionField)->filter(fn ($item) => $item->target_id == $section_target_id);
          if (!$alert->get($alertSectionField)->isEmpty()) {
            $section_alerts[] = $alert;
          }
        }
      }
    }
    return $section_alerts;
  }

}
