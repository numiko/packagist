<?php

namespace Drupal\site_alerts\Entity;

use Drupal\Core\Entity\Attribute\ContentEntityType;
use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\ContentEntityDeleteForm;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\EntityViewBuilder;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\EntityViewsData;
use Drupal\site_alerts\AlertAccessControlHandler;
use Drupal\site_alerts\AlertEntityHtmlRouteProvider;
use Drupal\site_alerts\AlertListBuilder;
use Drupal\site_alerts\AlertTranslationHandler;
use Drupal\site_alerts\Form\AlertForm;

/**
 * Defines the Alert entity.
 *
 * @ingroup site_alerts
 */
#[ContentEntityType(
  id: 'alert',
  label: new TranslatableMarkup('Alerts'),
  label_collection: new TranslatableMarkup('Alerts'),
  bundle_label: new TranslatableMarkup('Alert type'),
  handlers: [
    'view_builder' => EntityViewBuilder::class,
    'list_builder' => AlertListBuilder::class,
    'views_data' => EntityViewsData::class,
    'form' => [
      'default' => AlertForm::class,
      'add' => AlertForm::class,
      'edit' => AlertForm::class,
      'delete' => ContentEntityDeleteForm::class,
    ],
    'translation' => AlertTranslationHandler::class,
    'access' => AlertAccessControlHandler::class,
    'route_provider' => [
      'html' => AlertEntityHtmlRouteProvider::class,
    ],
  ],
  base_table: 'alert',
  data_table: 'alert_field_data',
  translatable: TRUE,
  admin_permission: 'administer alert entities',
  entity_keys: [
    'id' => 'id',
    'bundle' => 'type',
    'label' => 'name',
    'uuid' => 'uuid',
    'langcode' => 'langcode',
    'status' => 'status',
  ],
  links: [
    'canonical' => '/admin/structure/alerts/{alert}',
    'add-page' => '/admin/structure/alerts/add',
    'add-form' => '/admin/structure/alerts/add/{alert_type}',
    'edit-form' => '/admin/structure/alerts/{alert}/edit',
    'delete-form' => '/admin/structure/alerts/{alert}/delete',
    'collection' => '/admin/structure/alerts',
  ],
  bundle_entity_type: 'alert_type',
  field_ui_base_route: 'entity.alert_type.edit_form'
)]
class Alert extends ContentEntityBase implements AlertInterface {
  use EntityChangedTrait;

  /**
   * {@inheritdoc}
   */
  public function getName() {
    return $this->get('name')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setName($name) {
    $this->set('name', $name);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getCreatedTime() {
    return $this->get('created')->value;
  }

  /**
   * {@inheritdoc}
   */
  public function setCreatedTime($timestamp) {
    $this->set('created', $timestamp);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function isPublished() {
    return (bool) $this->getEntityKey('status');
  }

  /**
   * {@inheritdoc}
   */
  public function setPublished() {
    $this->set('status', TRUE);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function setUnpublished() {
    $this->set('status', FALSE);
    return $this;
  }

  /**
   * {@inheritdoc}
   */
  public function getWarningLevel() {
    return $this->get('warning_level')->value;
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setDescription(t('The name of the Alert.'))
      ->setSettings([
        'max_length' => 50,
        'text_processing' => 0,
      ])
      ->setDefaultValue('')
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'string',
        'weight' => -4,
      ])
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -4,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayConfigurable('view', TRUE)
      ->setRequired(TRUE)
      ->setTranslatable(TRUE);

    $fields['warning_level'] = BaseFieldDefinition::create('list_string')
      ->setSettings([
        'allowed_values' => [
          'critical' => 'Critical',
          'warning' => 'Warning',
          'polite' => 'Polite',
        ],
      ])
      ->setLabel('Warning level')
      ->setDescription('Set the warning level colour.')
      ->setRequired(TRUE)
      ->setDisplayOptions('form', [
        'type' => 'options_select',
        'weight' => 2,
      ])
      ->setDisplayConfigurable('form', TRUE);

    $fields['status'] = BaseFieldDefinition::create('boolean')
      ->setLabel(t('Active'))
      ->setDefaultValue(TRUE)
      ->setDisplayOptions('form', [
        'type' => 'boolean_checkbox',
        'weight' => 50,
      ])
      ->setDisplayConfigurable('form', TRUE);

    $fields['created'] = BaseFieldDefinition::create('created')
      ->setLabel(t('Created'))
      ->setDescription(t('The time that the entity was created.'))
      ->setTranslatable(TRUE);

    $fields['changed'] = BaseFieldDefinition::create('changed')
      ->setLabel(t('Changed'))
      ->setDescription(t('The time that the entity was last edited.'))
      ->setTranslatable(TRUE);

    $fields['langcode'] = BaseFieldDefinition::create('language')
      ->setName('langcode')
      ->setDefaultValue('en')
      ->setStorageRequired(TRUE)
      ->setLabel(t('Language code'))
      ->setDescription(t('The language code.'))
      ->setTranslatable(TRUE);

    $fields['default_langcode'] = BaseFieldDefinition::create('boolean')
      ->setName('default_langcode')
      ->setLabel(t('Default Language code'))
      ->setDescription(t('Indicates if this is the default language.'))
      ->setDefaultValue(1)
      ->setTargetEntityTypeId('alert')
      ->setTargetBundle(NULL)
      ->setStorageRequired(TRUE)
      ->setRevisionable(TRUE)
      ->setTranslatable(TRUE);

    return $fields;
  }

}
