<?php

namespace Drupal\site_alerts;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Entity\EntityAccessControlHandler;
use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Access controller for the Alert entity.
 *
 * @see \Drupal\site_alerts\Entity\Alert.
 */
class AlertAccessControlHandler extends EntityAccessControlHandler {

  /**
   * {@inheritdoc}
   */
  protected function checkAccess(EntityInterface $entity, $operation, AccountInterface $account) {
    /** @var \Drupal\site_alerts\Entity\AlertInterface $entity */
    switch ($operation) {
      case 'view':
        if ($entity->isPublished()) {
          return AccessResult::allowed();
        }
        break;

      case 'update':
        return AccessResult::allowedIfHasPermission($account, 'update ' . $entity->bundle());

      case 'delete':
        return AccessResult::allowedIfHasPermission($account, 'delete ' . $entity->bundle());
    }

    // Unknown operation, no opinion.
    return AccessResult::neutral();
  }

  /**
   * {@inheritdoc}
   */
  protected function checkCreateAccess(AccountInterface $account, array $context, $entity_bundle = NULL) {
    return AccessResult::allowedIfHasPermission($account, 'create ' . $entity_bundle);
  }

}
