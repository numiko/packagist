<?php

namespace Drupal\site_alerts\Attribute;

use Drupal\Component\Plugin\Attribute\Plugin;
use Drupal\Core\StringTranslation\TranslatableMarkup;

/**
 * Defines an alert type (attribute style).
 */
#[\Attribute(\Attribute::TARGET_CLASS)]
class AlertType extends Plugin {

  /**
   * Constructs a Alert Type plugin.
   *
   * @param string $id
   *   The plugin ID.
   * @param \Drupal\Core\StringTranslation\TranslatableMarkup $name
   *   The name of the alert type.
   */
  public function __construct(
    public readonly string $id,
    public readonly TranslatableMarkup $name,
  ) {
  }

}
