<?php

namespace Drupal\site_alerts\Hook;

use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Hook\Attribute\Hook;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\StringTranslation\StringTranslationTrait;
use Drupal\Core\StringTranslation\TranslationInterface;
use Drupal\node\NodeInterface;
use Drupal\node\NodeTypeInterface;
use Drupal\site_alerts\SettingsProvider;

/**
 * Form hook implementations for site_alerts.
 */
final class FormHooks {
  use StringTranslationTrait;

  public function __construct(
    private AccountInterface $currentUser,
    private SettingsProvider $settingsProvider,
    private EntityTypeManagerInterface $typeManager,
    TranslationInterface $stringTranslation,
  ) {
    $this->stringTranslation = $stringTranslation;
  }

  /**
   * Implements hook_form_alter().
   *
   * Check user access and restrict access to free text message field. Instead
   * show a predefined taxonomy list to choose from.
   */
  #[Hook('form_alter')]
  public function formAlter(array &$form, FormStateInterface $form_state, mixed $form_id): void {
    if (isset($form["#entity_type"]) && $form["#entity_type"] == 'alert') {
      $form['field_message']['#access'] = FALSE;
      if ($this->currentUser->hasPermission('add free text alert')) {
        $form['field_message']['#access'] = TRUE;
      }
    }
  }

  /**
   * Implements hook_form_node_form_alter().
   *
   * Adds the new site_alerts_section node field to the node form.
   */
  #[Hook('form_node_form_alter')]
  public function formNodeFormAlter(array &$form, FormStateInterface $form_state, mixed $form_id): void {
    if ($this->settingsProvider->hasCustomNodeField()) {
      return;
    }
    if (!$this->currentUser->hasPermission('assign site alert section')) {
      return;
    }

    /** @var \Drupal\node\NodeInterface $node */
    $node = $form_state->getFormObject()->getEntity();
    $type = $this->typeManager->getStorage('node_type')->load($node->bundle());

    if (!$type) {
      return;
    }
    if (!$type->getThirdPartySetting('site_alerts', 'enabled', FALSE)) {
      return;
    }

    $isSectionSet = !empty($node->get('site_alerts_section')->getString()) && $node->get('site_alerts_section')->getString() != '_none';
    $form['site_alerts_section'] = [
      '#type' => 'details',
      '#title' => $this->t('Site section'),
      '#group' => 'advanced',
      '#tree' => TRUE,
      '#open' => $isSectionSet,
    ];
    $form['site_alerts_section']['section'] = [
      '#type' => 'select',
      '#title' => $this->t('Select site section'),
      '#description' => $this->t('Select a section of the site in which this content resides. This is used to categorise content.'),
      '#default_value' => $isSectionSet ? $node->get('site_alerts_section')->getString() : '_none',
      '#options' => $this->getSettingsOptions(),
    ];
    $form['#entity_builders'][] = [FormHooks::class, 'nodeFormBuilder'];
  }

  /**
   * Entity builder for the node form with site_alerts_section options.
   *
   * @see site_alerts_form_node_form_alter()
   */
  public static function nodeFormBuilder(mixed $entity_type, NodeInterface $entity, array $form, FormStateInterface $form_state): void {
    if ($form_state->getValue(['site_alerts_section', 'section']) == '_none') {
      return;
    }
    $entity->set('site_alerts_section', ['target_id' => $form_state->getValue(['site_alerts_section', 'section'])]);
  }

  /**
   * Returns site section taxonomy terms formatted as select options.
   *
   * @return string[]
   *   Site section vocabulary formatted as select options.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  private function getSettingsOptions(): array {
    $terms = $this->typeManager->getStorage('taxonomy_term')->loadTree($this->settingsProvider->getSectionTaxonomy());
    $termOptions = ['_none' => '- None -'];
    foreach ($terms as $term) {
      $termOptions[$term->tid] = $term->name;
    }
    return $termOptions;
  }

  /**
   * Implements hook_form_node_type_form_alter().
   *
   * Adds option to enable site section options on content/node types.
   */
  #[Hook('form_node_type_form_alter')]
  public function formNodeTypeFormAlter(array &$form, FormStateInterface $form_state): void {
    if ($this->settingsProvider->hasCustomNodeField()) {
      return;
    }
    if (!$this->currentUser->hasPermission('administer site alert sections')) {
      return;
    }

    /** @var \Drupal\node\NodeTypeInterface $type */
    $type = $form_state->getFormObject()->getEntity();
    $form['site_alerts_section'] = [
      '#type' => 'details',
      '#title' => $this->t('Site section'),
      '#group' => 'additional_settings',
    ];
    $form['site_alerts_section']['site_alerts_section_enabled'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Enabled'),
      '#default_value' => $type->getThirdPartySetting('site_alerts', 'enabled', FALSE),
      '#description' => $this->t('Allow setting the section of a node'),
    ];
    $form['#entity_builders'][] = static fn ($entity_type, NodeTypeInterface $type, &$form, FormStateInterface $form_state) => $type->setThirdPartySetting(
      'site_alerts',
      'enabled',
      $form_state->getValue('site_alerts_section_enabled')
    );
  }

  /**
   * Implements hook_entity_base_field_info().
   *
   * Adds new site_alerts_section field to nodes.
   */
  #[Hook('entity_base_field_info')]
  public function entityBaseFieldInfo(EntityTypeInterface $entity_type): array {
    if ($this->settingsProvider->hasCustomNodeField()) {
      return [];
    }
    $fields = [];
    if ($entity_type->id() === 'node') {
      $siteSectionTaxonomy = $this->settingsProvider->getSectionTaxonomy();

      $fields['site_alerts_section'] = BaseFieldDefinition::create('entity_reference')
        ->setLabel($this->t('Site section'))
        ->setDescription($this->t('Select a section of the site in which this content resides. This is used to categorise content.'))
        ->setSetting('target_type', 'taxonomy_term')
        ->setSetting('handler', 'default:taxonomy_term')
        ->setSetting('handler_settings', ['target_bundles' => [$siteSectionTaxonomy => $siteSectionTaxonomy]])
        ->setDisplayConfigurable('form', FALSE)
        ->setDisplayConfigurable('view', FALSE);
    }
    return $fields;
  }

}
