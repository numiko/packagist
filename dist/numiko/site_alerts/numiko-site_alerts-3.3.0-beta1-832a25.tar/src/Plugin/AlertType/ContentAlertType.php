<?php

namespace Drupal\site_alerts\Plugin\AlertType;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\node\NodeInterface;
use Drupal\site_alerts\AlertTypeBase;
use Drupal\site_alerts\Attribute\AlertType;

/**
 * Provides a 'content alert' alert type.
 */
#[AlertType(
  id: 'content_alert',
  name: new TranslatableMarkup('Content Alert')
)]
class ContentAlertType extends AlertTypeBase {

  protected const string CONTENT_FIELD = 'field_content';

  /**
   * {@inheritDoc}
   */
  public function getAllAlerts(?NodeInterface $node): array {
    $content_alerts = [];
    // Content alerts only apply to content.
    if (!$node) {
      return $content_alerts;
    }

    $alerts = $this->getAllAlertsAssignedToPlugin($this->getId());
    foreach ($alerts as $alert) {
      if ($alert->hasField(self::CONTENT_FIELD) && !$alert->get(self::CONTENT_FIELD)->isEmpty()) {
        foreach ($alert->get(self::CONTENT_FIELD)->getValue() as $content) {
          if ($content['target_id'] == $node->id()) {
            $content_alerts[] = $alert;
          }
        }
      }
    }

    return $content_alerts;
  }

}
