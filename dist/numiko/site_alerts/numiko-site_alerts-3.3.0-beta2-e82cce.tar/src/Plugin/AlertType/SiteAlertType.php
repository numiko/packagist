<?php

namespace Drupal\site_alerts\Plugin\AlertType;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\node\NodeInterface;
use Drupal\site_alerts\AlertTypeBase;
use Drupal\site_alerts\Attribute\AlertType;

/**
 * Provides a 'site alert' alert type.
 */
#[AlertType(
  id: 'site_alert',
  name: new TranslatableMarkup('Site Alert')
)]
class SiteAlertType extends AlertTypeBase {

  /**
   * {@inheritDoc}
   */
  public function getAllAlerts(?NodeInterface $node): array {
    return $this->getAllAlertsAssignedToPlugin($this->getId());
  }

}
