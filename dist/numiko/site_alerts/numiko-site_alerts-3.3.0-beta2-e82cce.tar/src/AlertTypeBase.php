<?php

namespace Drupal\site_alerts;

use Drupal\Component\Plugin\PluginBase;
use Drupal\Core\Config\ImmutableConfig;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Base alert types for plugins to extend.
 */
abstract class AlertTypeBase extends PluginBase implements AlertTypeInterface, ContainerFactoryPluginInterface {

  /**
   * Entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected EntityTypeManagerInterface $entityTypeManager;

  /**
   * The site alert settings object.
   *
   * @var \Drupal\Core\Config\ImmutableConfig
   */
  protected ImmutableConfig $settings;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
    );
    $instance->entityTypeManager = $container->get('entity_type.manager');
    $instance->settings = $container->get('config.factory')->get('site_alerts.settings');
    return $instance;
  }

  /**
   * Verify the plugin configuration.
   */
  public function verifyPluginConfiguration() {
    return $this;
  }

  /**
   * Get the alert ID.
   */
  public function getId() {
    return $this->pluginDefinition['id'];
  }

  /**
   * Get the alert Name.
   */
  public function getName() {
    return $this->pluginDefinition['name'];
  }

  /**
   * Get alerts of the type that belong to the given plugin.
   *
   * For example if the plugin is "content_alert" then find all
   * alert types that are set to use the "content_alert" plugin and return
   * all alert entities matching those types.
   *
   * @param string $pluginId
   *   The ID of the alert type plugin to get alerts for.
   *
   * @return list<\Drupal\Core\Entity\EntityInterface>
   *   Get an array of alert entities that belong to alert types
   *   of the current plugin.
   */
  protected function getAllAlertsAssignedToPlugin(string $pluginId): array {
    $alertTypeStorage = $this->entityTypeManager->getStorage('alert_type');
    $alertStorage = $this->entityTypeManager->getStorage('alert');

    $alertTypes = $alertTypeStorage->loadByProperties([
      'status' => 1,
      'plugin' => $pluginId,
    ]);

    $alerts = [];
    foreach ($alertTypes as $alertType) {
      $alertEntities = $alertStorage->loadByProperties(['status' => 1, 'type' => $alertType->id()]);
      foreach ($alertEntities as $alertEntity) {
        if ($alertEntity->access('view')) {
          $alerts[] = $alertEntity;
        }
      }
    }
    return $alerts;
  }

}
