<?php

namespace Drupal\site_alerts;

use Drupal\node\NodeInterface;

/**
 * The Alerts service.
 */
class Alerts {

  /**
   * Create an instance of the Alerts manager.
   *
   * @param \Drupal\site_alerts\AlertTypeManager $alertTypePluginManager
   *   The alerts type plugin manager.
   */
  public function __construct(protected readonly AlertTypeManager $alertTypePluginManager) {
  }

  /**
   * Get all alerts.
   *
   * @param ?\Drupal\node\NodeInterface $node
   *   The node for which to get alerts if applicable.
   *
   * @return array
   *   Returns all alerts to display.
   *
   * @throws \Drupal\Core\TypedData\Exception\MissingDataException
   */
  public function getAllAlerts(?NodeInterface $node = NULL): array {
    $allAlerts = [];

    $alertTypes = $this->alertTypePluginManager->getAlertTypes();

    foreach ($alertTypes as $alertType) {
      $allAlerts = array_merge($allAlerts, $alertType->getAllAlerts($node));
    }

    return $allAlerts;
  }

}
