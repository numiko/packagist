<?php

namespace Drupal\site_alerts\Entity;

use Drupal\Core\Config\Entity\ConfigEntityBundleBase;
use Drupal\Core\Entity\Attribute\ConfigEntityType;
use Drupal\Core\Entity\EntityDeleteForm;
use Drupal\Core\Entity\Routing\DefaultHtmlRouteProvider;
use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\site_alerts\AlertTypeListBuilder;
use Drupal\site_alerts\Form\AlertTypeForm;

/**
 * Defines the Alert type entity.
 */
#[ConfigEntityType(
  id: 'alert_type',
  label: new TranslatableMarkup('Alert type'),
  label_collection: new TranslatableMarkup('Alert type'),
  handlers: [
    'list_builder' => AlertTypeListBuilder::class,
    'form' => [
      'add' => AlertTypeForm::class,
      'edit' => AlertTypeForm::class,
      'delete' => EntityDeleteForm::class,
    ],
    'route_provider' => [
      'default' => DefaultHtmlRouteProvider::class,
    ],
  ],
  config_prefix: 'alert_type',
  admin_permission: 'administer site configuration',
  bundle_of: 'alert',
  entity_keys: [
    'id' => 'id',
    'label' => 'label',
    'plugin' => 'plugin',
  ],
  config_export: [
    'id',
    'label',
    'plugin',
  ],
  links: [
    'add-form' => '/admin/structure/alert_type/add',
    'edit-form' => '/admin/structure/alert_type/{alert_type}/edit',
    'delete-form' => '/admin/structure/alert_type/{alert_type}/delete',
    'collection' => '/admin/structure/alert_type',
  ],
)]
class AlertType extends ConfigEntityBundleBase {

  /**
   * The Alert type ID.
   *
   * @var string
   */
  protected $id;

  /**
   * The Alert type label.
   *
   * @var string
   */
  protected $label;

  /**
   * The Alert type plugin.
   *
   * @var string
   */
  protected $plugin;

}
