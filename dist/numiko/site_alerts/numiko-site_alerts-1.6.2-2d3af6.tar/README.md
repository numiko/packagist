# Site Alerts

Originally developed by Luke Stirk.

## Overview

The site alerts module provides dismissible site alert messages to be shown across the site,
a site section or an individual node.

This module provides a default template but is not standalone and requires theme development.
The alert block requires both theming and JS functionality.

## Setup

Install the module.
* This creates two taxonomies: site_section and alerts.
* This creates two new configurable entities: alert and alert type.
* This defines new permissions.
* This adds the site_alerts_section field to nodes.

Configure module permissions.

Enable the site alert section ("setting the section of a node") on desired content types from their edit page.
Eg: /admin/structure/types/manage/{content_type}

Add Alerts block to desired region in block layout.

### Advanced setup and configuration

Some sites may want to use an existing field or taxonomy to define sections on content.

To make these changes navigate to /admin/config/site_alerts/settings.

There are two fields:
* Section node field. This lets the user select any entity_reference field installed on nodes as the field to check to
determine a node's section. This should be a taxonomy reference. The default is site_alerts_section.
* Section taxonomy. This lets the user select which taxonomy will be used to represent sections.
The default is site_section.

Both of these changes can be made independently of each other. For a standard configuration, leave them unchanged.

Changes to these may require a cache clear to take affect.

Changes to the section taxonomy will results in a field definition update. This configuration should be exported and
saved to the code base.

## Usage

### Creating alerts

Create site alerts at /admin/structure/alerts.

Select an alert type.
Please see the relevant section below for more information.

Alerts, as a standard, have a warning level, two message inputs, a link and an 'Active' checkbox.

The warning level is used to theme the alerts differently and has three levels: 'Critical', 'Warning' and 'Polite'.

The first message input allows the user to select from a set of predefined messages to display on the alert.
Please see the relevant section below for more information.

The second message input allows the user to add a freetext message to display on the alert.

The link input allows the user to add a link to display on the alert.

The active checkbox allows the user to toggle the display of alerts.

### Alert types

The module comes with three built-in types. They are described below.

Further alert types can be added via the UI, however, adding custom functionality to these
is not yet provided as an overridable service.

The default alert types:

#### Site alert

Site alerts display across the entire site.

#### Section alert

Section alerts allow the user to select a site section on which this alert should display.

Site sections must be correctly configured:
* Site sections must be enabled on the desired content types. See setup.
* Section taxonomy terms must be added to the site_section taxonomy.
* Nodes must be assigned sections via their edit form.

#### Content alert

Content alerts allow the user to select a specific node on which this alert should display.

### Predefined messages

Predefined messages, which are used to create reusable messages, can be created by adding terms
to the 'alerts' taxonomy. These terms are then listed as predefined messages.

## Extending the module

If more specific logic is needed to determine whether an alert type should display, this module's functionality
can be extended.

Create a new alert type via the admin UI, add and configure necessary fields.

Extend \Drupal\site_alerts\Alerts and override getAllAlerts() function with logic that includes the new alert type.

Override the site_alerts.alerts service definition to point at the new class.

If the new alert type is something that would be re-usable across multiple sites, consider adding
it to this module's repository.
