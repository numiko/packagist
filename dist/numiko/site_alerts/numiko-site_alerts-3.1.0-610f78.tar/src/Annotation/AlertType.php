<?php

namespace Drupal\site_alerts\Annotation;

use Drupal\Component\Annotation\Plugin;

/**
 * Defines an alert type.
 *
 * Plugin Namespace: Plugin\site_alerts\AlertType
 *
 * @see \Drupal\site_alerts\AlertTypeManager
 * @see plugin_api
 *
 * @Annotation
 */
class AlertType extends Plugin {

  /**
   * The plugin ID.
   *
   * @var string
   */
  public $id;

  /**
   * The name of the alert type.
   *
   * @var \Drupal\Core\Annotation\Translation
   *
   * @ingroup plugin_translatable
   */
  public $name;

}
