<?php

namespace Drupal\site_alerts\Form;

use Drupal\Core\Entity\EntityForm;
use Drupal\Core\Form\FormStateInterface;

/**
 * Class AlertTypeForm.
 */
class AlertTypeForm extends EntityForm {

  /**
   * {@inheritdoc}
   */
  public function form(array $form, FormStateInterface $form_state) {
    $form = parent::form($form, $form_state);

    $alertType = $this->entity;
    $form['label'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Label'),
      '#maxlength' => 255,
      '#default_value' => $alertType->label(),
      '#description' => $this->t("Label for the Alert type."),
      '#required' => TRUE,
    ];

    $options = [];
    foreach (\Drupal::Service('plugin.manager.site_alerts.types')->getAlertTypes() as $alertPlugin) {
      $options[$alertPlugin->getId()] = $alertPlugin->getName();
    }

    $form['plugin'] = [
      '#type' => 'select',
      '#empty_option' => '- None -',
      '#empty_value' => NULL,
      '#title' => $this->t('Alert plugin'),
      '#options' => $options,
      '#default_value' => (isset($options[$alertType->get('plugin')])) ? $alertType->get('plugin') : NULL,
      '#description' => $this->t("Select the plugin type to use for this alert type."),
      '#required' => FALSE,
    ];

    $form['id'] = [
      '#type' => 'machine_name',
      '#default_value' => $alertType->id(),
      '#machine_name' => [
        'exists' => '\Drupal\site_alerts\Entity\AlertType::load',
      ],
      '#disabled' => !$alertType->isNew(),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function save(array $form, FormStateInterface $form_state) {
    $alertType = $this->entity;
    $status = $alertType->save();

    switch ($status) {
      case SAVED_NEW:
        $this->messenger()
          ->addMessage($this->t('Created the %label Alert type.', [
            '%label' => $alertType->label(),
          ]));
        break;

      default:
        $this->messenger()
          ->addMessage($this->t('Saved the %label Alert type.', [
            '%label' => $alertType->label(),
          ]));
    }
    $form_state->setRedirectUrl($alertType->toUrl('collection'));
  }

}
