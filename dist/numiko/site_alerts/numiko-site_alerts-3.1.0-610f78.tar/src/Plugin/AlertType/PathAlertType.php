<?php

namespace Drupal\site_alerts\Plugin\AlertType;

use Drupal\node\NodeInterface;
use Drupal\site_alerts\AlertTypeBase;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'path alert' alert type.
 *
 * @AlertType(
 *   id = "path_alert",
 *   name = @Translation("Path Alert")
 * )
 */
class PathAlertType extends AlertTypeBase {

  const PATHS_FIELD = 'field_paths';

  /**
   * An alias manager to find the alias for the current system path.
   *
   * @var \Drupal\pathAlias\AliasManagerInterface
   */
  protected $aliasManager;

  /**
   * The path matcher.
   *
   * @var \Drupal\Core\Path\PathMatcherInterface
   */
  protected $pathMatcher;

  /**
   * The request stack.
   *
   * @var \Symfony\Component\HttpFoundation\RequestStack
   */
  protected $requestStack;

  /**
   * The current path.
   *
   * @var \Drupal\Core\Path\CurrentPathStack
   */
  protected $currentPath;

  /**
   * The language manager.
   *
   * @var \Drupal\Core\Language\LanguageManagerInterface
   */
  protected $languageManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = parent::create(
      $container,
      $configuration,
      $plugin_id,
      $plugin_definition,
    );
    $instance->aliasManager = $container->get('path_alias.manager');
    $instance->pathMatcher = $container->get('path.matcher');
    $instance->requestStack = $container->get('request_stack');
    $instance->currentPath = $container->get('path.current');
    $instance->languageManager = $container->get('language_manager');
    return $instance;
  }

  /**
   * {@inheritDoc}
   */
  public function getAllAlerts(?NodeInterface $node): array {
    $path_alerts = [];
    $alerts = $this->getAllAlertsAssignedToPlugin($this->getId());
    foreach ($alerts as $alert) {
      $paths = $alert->get(self::PATHS_FIELD)->value;
      if ($paths && $this->evaluate($paths)) {
        $path_alerts[] = $alert;
      }
    }
    return $path_alerts;
  }

  /**
   * Evaluate the alert to check if the alert is valid for the current path.
   */
  protected function evaluate($pages) {
    if (!$pages) {
      return FALSE;
    }
    // Convert path to lowercase. This allows comparison of the same path
    // with different case. Ex: /Page, /page, /PAGE.
    $pages = mb_strtolower($pages);

    $request = $this->requestStack->getCurrentRequest();
    // Compare the lowercase path alias (if any) and internal path.
    $path = $this->currentPath->getPath($request);
    // Do not trim a trailing slash if that is the complete path.
    $path = ($path === '/') ? $path : rtrim($path, '/');
    $pathAlias = $this->aliasManager->getAliasByPath($path);
    if (!$pathAlias) {
      return FALSE;
    }
    $pathAlias = mb_strtolower($pathAlias);

    // Add langcode to string if not default language.
    if ($this->languageManager->getCurrentLanguage()->getId() != $this->languageManager->getDefaultLanguage()->getId()) {
      $pathAlias = '/' . $this->languageManager->getCurrentLanguage()->getId() . $pathAlias;
    }
    return $this->pathMatcher->matchPath($pathAlias, $pages) || (($path != $pathAlias) && $this->pathMatcher->matchPath($path, $pages));
  }

}
