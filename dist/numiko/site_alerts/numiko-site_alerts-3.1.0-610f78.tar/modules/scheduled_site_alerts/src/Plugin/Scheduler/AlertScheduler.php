<?php

namespace Drupal\scheduled_site_alerts\Plugin\Scheduler;

use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\scheduler\SchedulerPluginBase;

/**
 * Plugin for Alert entity type.
 *
 * @package Drupal\Scheduler\Plugin\Scheduler
 *
 * @SchedulerPlugin(
 *  id = "alert_scheduler",
 *  label = @Translation("Alert Scheduler Plugin"),
 *  description = @Translation("Provides support for scheduling alert entities"),
 *  entityType = "alert",
 *  dependency = "site_alerts",
 *  collectionRoute = "entity.alert.collection",
 *  schedulerEventClass = "\Drupal\scheduled_site_alerts\Event\SchedulerAlertEvents",
 * )
 */
class AlertScheduler extends SchedulerPluginBase implements ContainerFactoryPluginInterface {}
