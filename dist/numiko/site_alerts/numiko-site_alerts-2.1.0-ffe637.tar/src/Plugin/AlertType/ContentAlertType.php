<?php

namespace Drupal\site_alerts\Plugin\AlertType;

use Drupal\node\NodeInterface;
use Drupal\site_alerts\AlertTypeBase;

/**
 * Provides a 'content alert' alert type.
 *
 * @AlertType(
 *   id = "content_alert",
 *   name = @Translation("Content Alert")
 * )
 */
class ContentAlertType extends AlertTypeBase {

  const CONTENT_FIELD = 'field_content';

  /**
   * {@inheritDoc}
   */
  public function getAllAlerts(?NodeInterface $node): array {
    $content_alerts = [];
    // Content alerts only apply to content.
    if (!$node) {
      return $content_alerts;
    }

    $alerts = $this->getAllAlertsAssignedToPlugin($this->getId());
    foreach ($alerts as $alert) {
      if ($alert->hasField(self::CONTENT_FIELD) && !$alert->get(self::CONTENT_FIELD)->isEmpty()) {
        foreach ($alert->get(self::CONTENT_FIELD)->getValue() as $content) {
          if ($content['target_id'] == $node->id()) {
            $content_alerts[] = $alert;
          }
        }
      }
    }

    return $content_alerts;
  }

}
