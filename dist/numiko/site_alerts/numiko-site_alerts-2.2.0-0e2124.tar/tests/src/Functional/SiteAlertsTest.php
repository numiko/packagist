<?php

namespace Drupal\Tests\site_alerts\Functional;

use Drupal\node\Entity\NodeType;
use Drupal\pathauto\PathautoState;
use Drupal\site_alerts\Entity\Alert;
use Drupal\taxonomy\Entity\Vocabulary;
use weitzman\DrupalTestTraits\ExistingSiteBase;

class SiteAlertsTest extends ExistingSiteBase {

  /**
   * The state of the section functionality.
   *
   * @var bool
   */
  protected $pageSectionState;

  /**
   * For the purpose of this test we want to switch on section functionality.
   */
  public function setUp() : void {
    parent::setUp();

    $type = NodeType::load('page');
    $this->pageSectionState = $type->getThirdPartySetting('site_alerts', 'enabled', FALSE);
    if (!$this->pageSectionState) {
      $type->setThirdPartySetting('site_alerts', 'enabled', TRUE);
      $type->save();
    }
  }

  /**
   * For the purpose of this test we want to revert section functionality.
   *
   * The revert only happens if we actually enabled it for the purpose of the
   * test, if it was already enabled do nothing.
   */
  public function tearDown() : void {
    if (!$this->pageSectionState) {
      $type = NodeType::load('page');
      $type->setThirdPartySetting('site_alerts', 'enabled', FALSE);
      $type->save();
    }

    parent::tearDown();
  }

  public function testSiteWideAlerts() {
    $node = $this->createNode(
      [
        'type' => 'page',
        'title' => 'Testing page page',
        'status' => 1,
        'moderation_state' => 'published',
      ]
    );

    $siteAlert = Alert::create(
      [
        'type' => 'site_alert',
        'name' => 'test site wide alert',
        'warning_level' => 'critical',
        'field_message' => 'test site wide alert message',
        'status' => 1,
      ]
    );
    $siteAlert->save();
    $this->markEntityForCleanup($siteAlert);

    $this->drupalGet('node/' . $node->id());

    $this->assertSession()->responseContains("test site wide alert message");

    $user = $this->createUser([], 'alert test user');
    $this->drupalLogin($user);

    $this->drupalGet('user/' . $user->id());

    $this->assertSession()->responseContains("test site wide alert message");
  }

  public function testContentAlerts() {
    $nodeWithAlert = $this->createNode(
      [
        'type' => 'page',
        'title' => 'test page with alert',
        'path' => [
          'alias' => '/test_page_with_alert',
          'pathauto' => PathautoState::SKIP,
        ],
        'status' => 1,
        'moderation_state' => 'published',
      ]
    );

    $nodeWithoutAlert = $this->createNode(
      [
        'type' => 'page',
        'title' => 'Testing page without alert',
        'path' => [
          'alias' => '/test_page_without_alert',
          'pathauto' => PathautoState::SKIP,
        ],
        'status' => 1,
        'moderation_state' => 'published',
      ]
    );

    $contentAlert = Alert::create(
      [
        'type' => 'content_alert',
        'name' => 'test content alert',
        'warning_level' => 'critical',
        'status' => 1,
        'field_message' => 'test content alert message',
        'field_content' => [
          0 => [
            'target_id' => $nodeWithAlert->id(),
          ],
        ],
      ]
    );
    $contentAlert->save();
    $this->markEntityForCleanup($contentAlert);

    $this->drupalGet('node/' . $nodeWithAlert->id());

    $this->assertSession()->responseContains("test content alert message");

    $this->drupalGet('node/' . $nodeWithoutAlert->id());

    $this->assertSession()->responseNotContains("test content alert message");

    $user = $this->createUser([], 'content alert test user');

    $this->drupalLogin($user);

    $this->drupalGet('user/' . $user->id());

    $this->assertSession()->responseNotContains("test content alert message");
  }

  public function testPathAlerts() {
    $nodeWithAlert = $this->createNode(
      [
        'type' => 'page',
        'title' => 'test page with alert',
        'path' => [
          'alias' => '/test_path/test_page_with_alert',
          'pathauto' => PathautoState::SKIP,
        ],
        'status' => 1,
        'moderation_state' => 'published',
      ]
    );

    $nodeWithoutAlert = $this->createNode(
      [
        'type' => 'page',
        'title' => 'Testing page without alert',
        'path' => [
          'alias' => '/test_path/test_page_without_alert',
          'pathauto' => PathautoState::SKIP,
        ],
        'status' => 1,
        'moderation_state' => 'published',
      ]
    );

    $pathAlert = Alert::create(
      [
        'type' => 'path_alert',
        'name' => 'test path alert',
        'warning_level' => 'critical',
        'status' => 1,
        'field_message' => 'test path alert message',
        'field_paths' => '/test_path/test_page_with_alert',
      ]
    );
    $pathAlert->save();
    $this->markEntityForCleanup($pathAlert);

    $pathAlert = Alert::create(
      [
        'type' => 'path_alert',
        'name' => 'test sub-path alert',
        'warning_level' => 'critical',
        'status' => 1,
        'field_message' => 'test sub-path alert message',
        'field_paths' => '/test_path',
      ]
    );
    $pathAlert->save();
    $this->markEntityForCleanup($pathAlert);

    $pathAlert = Alert::create(
      [
        'type' => 'path_alert',
        'name' => 'test wildcard sub-path alert',
        'warning_level' => 'critical',
        'status' => 1,
        'field_message' => 'test wildcard sub-path alert message',
        'field_paths' => '/test_path/*',
      ]
    );
    $pathAlert->save();
    $this->markEntityForCleanup($pathAlert);

    $this->drupalGet('node/' . $nodeWithAlert->id());

    $this->assertSession()->responseContains("test path alert message");

    $this->assertSession()->responseNotContains("test sub-path alert message");

    $this->assertSession()->responseContains("test wildcard sub-path alert message");

    $this->drupalGet('node/' . $nodeWithoutAlert->id());

    $this->assertSession()->responseNotContains("test path alert message");

    $this->assertSession()->responseNotContains("test sub-path alert message");

    $this->assertSession()->responseContains("test wildcard sub-path alert message");

    $user = $this->createUser([], 'path alert test user');

    $this->drupalLogin($user);

    $this->drupalGet('user/' . $user->id());

    $this->assertSession()->responseNotContains("test path alert message");
  }

  /**
   * Test the section alert message appears on content in the section.
   */
  public function testSectionAlert() {
    $section = $this->createTerm(Vocabulary::load('site_section'), [
      'name' => 'My section',
    ]);

    $nodeInSection = $this->createNode(
      [
        'type' => 'page',
        'title' => 'test page in section',
        'site_alerts_section' => ['target_id' => $section->id()],
        'path' => [
          'alias' => '/matching_path/test_node',
          'pathauto' => PathautoState::SKIP,
        ],
        'status' => 1,
        'moderation_state' => 'published',
      ]
    );

    $nodeNotInSection = $this->createNode(
      [
        'type' => 'page',
        'title' => 'Testing page not in section',
        'path' => [
          'alias' => '/test_node',
          'pathauto' => PathautoState::SKIP,
        ],
        'status' => 1,
        'moderation_state' => 'published',
      ]
    );

    $sectionAlert = Alert::create(
      [
        'type' => 'section_alert',
        'name' => 'test section alert',
        'warning_level' => 'critical',
        'status' => 1,
        'field_message' => 'test section alert message',
        'field_section' => $section->id(),
      ]
    );
    $sectionAlert->save();
    $this->markEntityForCleanup($sectionAlert);

    $this->drupalGet('node/' . $nodeInSection->id());

    $this->assertSession()->responseContains("test section alert message");

    $this->drupalGet('node/' . $nodeNotInSection->id());

    $this->assertSession()->responseNotContains("test section alert message");

    $user = $this->createUser([], 'section alert test user');
    $this->drupalLogin($user);

    $this->drupalGet('user/' . $user->id());

    $this->assertSession()->responseNotContains("test section alert message");
  }

}
