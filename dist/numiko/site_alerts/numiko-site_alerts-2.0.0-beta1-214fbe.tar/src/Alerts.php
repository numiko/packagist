<?php

namespace Drupal\site_alerts;

use Drupal\node\NodeInterface;

/**
 * Alerts Service.
 */
class Alerts {

  /**
   * The alert type plugin manager.
   *
   * @var Drupal\site_alerts\AlertTypeManager
   */
  protected $alertTypePluginManager;

  /**
   * Create an instance of the Alerts manager.
   *
   * @param Drupal\site_alerts\AlertTypeManager $alertTypePluginManager
   *   The alerts type plugin manager.
   */
  public function __construct(AlertTypeManager $alertTypePluginManager) {
    $this->alertTypePluginManager = $alertTypePluginManager;
  }

  /**
   * Get all alerts.
   *
   * @param \Drupal\node\NodeInterface|null $node
   *   The node for which to get alerts if applicable.
   *
   * @return array
   *   Returns all alerts to display.
   *
   * @throws \Drupal\Core\TypedData\Exception\MissingDataException
   */
  public function getAllAlerts(?NodeInterface $node = NULL) {
    $allAlerts = [];

    $alertTypes = $this->alertTypePluginManager->getAlertTypes();

    foreach ($alertTypes as $alertType) {
      $allAlerts = array_merge($allAlerts, $alertType->getAllAlerts($node));
    }

    return $allAlerts;
  }

}
