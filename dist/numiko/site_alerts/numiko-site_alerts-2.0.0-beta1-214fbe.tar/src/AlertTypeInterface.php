<?php

namespace Drupal\site_alerts;

use Drupal\Component\Plugin\PluginInspectionInterface;
use Drupal\node\NodeInterface;

interface AlertTypeInterface extends PluginInspectionInterface {

  /**
   * Get all alerts.
   *
   * @param NodeInterface|null $node
   *   Optionally provide a node to query from.
   */
  public function getAllAlerts(?NodeInterface $node);

}
