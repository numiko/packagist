<?php

namespace Drupal\site_alerts\Plugin\AlertType;

use Drupal\node\NodeInterface;
use Drupal\site_alerts\AlertTypeBase;

/**
 * Provides a 'site alert' alert type.
 *
 * @AlertType(
 *   id = "site_alert",
 *   name = @Translation("Site Alert")
 * )
 */
class SiteAlertType extends AlertTypeBase {

  /**
   * {@inheritDoc}
   */
  public function getAllAlerts(?NodeInterface $node) {
    return $this->getAllAlertsAssignedToPlugin($this->getId());
  }

}
