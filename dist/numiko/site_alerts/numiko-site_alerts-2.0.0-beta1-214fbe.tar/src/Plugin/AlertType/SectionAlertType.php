<?php

namespace Drupal\site_alerts\Plugin\AlertType;

use Drupal\node\NodeInterface;
use Drupal\site_alerts\AlertTypeBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Provides a 'section alert' alert type.
 *
 * @AlertType(
 *   id = "section_alert",
 *   name = @Translation("Section Alert")
 * )
 */
class SectionAlertType extends AlertTypeBase implements ContainerFactoryPluginInterface {

  /**
   * The node section field.
   *
   * @var string
   */
  protected $nodeSectionField;

  /**
   * The alert section field.
   *
   * @var string
   */
  protected $alertSectionField;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
    );
    $instance->nodeSectionField = $container->get('config.factory')->get('site_alerts.settings')->get('site_alert_section_node_field');
    $instance->alertSectionField = $container->get('config.factory')->get('site_alerts.settings')->get('site_alert_section_taxonomy_field');
    return $instance;
  }

  /**
   * {@inheritDoc}
   */
  public function getAllAlerts(?NodeInterface $node) {
    $section_alerts = [];
    if ($node->hasField($this->nodeSectionField) && !$node->get($this->nodeSectionField)->isEmpty()) {
      $section = $node->get($this->nodeSectionField)->first()->getValue();
      $alerts = $this->getAllAlertsAssignedToPlugin($this->getId());
      foreach ($alerts as $alert) {
        /** @var \Drupal\site_alerts\Entity\alert $alert */
        if ($alert->hasField($this->alertSectionField) && !$alert->get($this->alertSectionField)->isEmpty()) {
          /*
           * Filter matching sections
           * The alert section field may be a multi-select field.
           * Use the filter() method to return any items matching the
           * current node's section setting. If the filtered fieldlist
           * is not empty, add the alert to the section_alerts array.
           */
          $section_target_id = $section['target_id'];
          $alert->get($this->alertSectionField)->filter(
            function ($item) use ($section_target_id) {
               return $item->target_id == $section_target_id;
            });
          if (!$alert->get($this->alertSectionField)->isEmpty()) {
            $section_alerts[] = $alert;
          }
        }
      }
    }
    return $section_alerts;
  }

}
