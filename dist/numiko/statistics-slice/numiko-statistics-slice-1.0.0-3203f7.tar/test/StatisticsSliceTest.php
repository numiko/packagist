<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the statistics slice displays on a page.
 *
 * @group slices
 */
class StatisticSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a statistics slice to a node.
   */
  public function testStatisticsSliceDisplay() {

    $items[] = $this->createParagraph('statistic_item', [
      'field_value' => 'Stat content 100%',
      'field_summary' => 'Statistic item summary 1',
      'field_link' => [
        'uri' => 'https://www.github.com',
        'title' => 'Stat1 button text',
      ],
    ]);
    $items[] = $this->createParagraph('statistic_item', [
      'field_value' => 'Stat content $200m',
      'field_summary' => 'Statistic item summary 2',
      'field_link' => [
        'uri' => 'https://www.bing.com',
        'title' => 'Stat2 text link',
      ],
    ]);

    $paragraphs[] = $this->createParagraph('slice_statistics', [
      'field_title' => 'Statistics Slice',
      'field_items' => $items,
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $assertSession->pageTextContains('Statistics Slice');

    $assertSession->pageTextContains('Stat content 100%');
    $assertSession->pageTextContains('Statistic item summary 1');
    $assertSession->responseContains('https://www.github.com');
    $assertSession->pageTextContains('Stat1 button text');

    $assertSession->pageTextContains('Stat content $200m');
    $assertSession->pageTextContains('Statistic item summary 2');
    $assertSession->responseContains('https://www.bing.com');
    $assertSession->pageTextContains('Stat2 text link');
  }
}
