# README #

This module provides a new Query/Re-ranking Plugin for the Search API Solr Dense Vector Field module.
https://www.drupal.org/project/search_api_solr_dense_vector

The Plugin facilitates Hybrid search (Keyword + Vector).
For more information, read the following doc: https://numiko.atlassian.net/wiki/spaces/BACKEND/pages/1649377868/Solr+Dense+Vector+Search+In+progress