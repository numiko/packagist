<?php

declare(strict_types=1);

namespace Drupal\hybrid_vector_query_re_ranking_plugin\Plugin\search_api_solr_dense_vector\query_ranker;

use Drupal\Core\StringTranslation\TranslatableMarkup;
use Drupal\Core\Form\FormStateInterface;
use Drupal\search_api_solr_dense_vector\Attribute\DenseVectorRanker;
use Drupal\search_api_solr_dense_vector\DenseVectorRankerPluginBase;
use Solarium\QueryType\Select\Query\Query as SolariumQueryInterface;

/**
 * Hybrid keyword + vector search ranker.
 *
 * Combines traditional keyword search with vector similarity by:
 * 1. Creating a combined query of both keyword AND vector search
 * 2. Re-ranking the top candidates using vector similarity
 * 3. Blending scores for optimal relevance.
 */
#[DenseVectorRanker(
  id: 'hybrid_vector',
  label: new TranslatableMarkup('Hybrid Vector (Keyword + Rerank)'),
)]
class HybridVector extends DenseVectorRankerPluginBase {

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration(): array {
    return [
      'rerank_docs' => '100',
      'rerank_weight' => '0.7',
      'top_k' => '20',
      'minimum_return' => '0.3',
      'minimum_traverse' => '0',
    ] + parent::defaultConfiguration();
  }

  /**
   * {@inheritdoc}
   */
  public function apply(SolariumQueryInterface $query, string $solr_field, array $vectors): SolariumQueryInterface {
    $configuration = $this->getConfiguration();

    if (empty($vectors) || !is_array($vectors[0])) {
      return $query;
    }

    $rerank_docs = max(1, (int) $configuration['rerank_docs']);
    $rerank_weight = max(0.0, min(1.0, (float) $configuration['rerank_weight']));
    $top_k = (int) $configuration['top_k'];
    $min_return = (float) $configuration['minimum_return'];
    $min_traverse = ((int) $configuration['minimum_traverse'] > 0) ? $configuration['minimum_traverse'] : '-Infinity';

    // Vector subquery (isolated for safe parsing).
    $vector_subquery = '{!knn f=' . $solr_field . ' topK=' . $top_k . ' minReturn=' . $min_return . ' minTraverse=' . $min_traverse . '}[' . implode(', ', $vectors[0]) . ']';

    $keyword_query = $query->getQuery();

    if (!empty($keyword_query) && $keyword_query !== '*:*') {
      // Use bool parser with refs for (keyword OR vector matches.
      $query->setQuery('{!bool should=$lq should=$vq}');
      $query->addParam('lq', $keyword_query);
      $query->addParam('vq', $vector_subquery);

      // Then apply vector re-ranking to the combined set.
      $query->addParam('rq', '{!rerank reRankQuery=' . urlencode($vector_subquery) . ' reRankDocs=' . $rerank_docs . ' reRankWeight=' . $rerank_weight . '}');
    }
    else {
      // No keyword: Pure vector (set as main q).
      $query->setQuery($vector_subquery);
    }

    return $query;
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state): array {
    $form = parent::buildConfigurationForm($form, $form_state);

    $form['rerank_docs'] = [
      '#type' => 'number',
      '#title' => $this->t('Documents to rerank'),
      '#description' => $this->t('Number of top documents from the combined keyword+vector search to rerank with vector similarity. Higher values provide better recall but slower performance.'),
      '#default_value' => $this->configuration['rerank_docs'],
      '#min' => 1,
      '#max' => 1000,
      '#required' => TRUE,
    ];

    $form['rerank_weight'] = [
      '#type' => 'number',
      '#title' => $this->t('Rerank weight'),
      '#description' => $this->t('Weight of vector similarity vs original combined score. 0.0 = pure keyword, 1.0 = pure vector, 0.7 = 70% vector + 30% keyword.'),
      '#default_value' => $this->configuration['rerank_weight'],
      '#min' => 0.0,
      '#max' => 1.0,
      '#step' => 0.1,
      '#required' => TRUE,
    ];

    $form['top_k'] = [
      '#type' => 'number',
      '#title' => $this->t('Vector similarity top K'),
      '#description' => $this->t('Number of most similar vectors to consider in the combined search. Keep this moderate (e.g., 20-50) for balanced recall with keywords.'),
      '#default_value' => $this->configuration['top_k'],
      '#min' => 1,
      '#max' => 100,
      '#required' => TRUE,
    ];

    $form['minimum_return'] = [
      '#type' => 'number',
      '#title' => $this->t('Minimum similarity score'),
      '#description' => $this->t('Minimum vector similarity score to include in results. Lower values (e.g., 0.1-0.3) boost recall for vague queries.'),
      '#default_value' => $this->configuration['minimum_return'],
      '#min' => 0.0,
      '#max' => 1.0,
      '#step' => 0.1,
      '#required' => TRUE,
    ];

    return $form;
  }

}