# TFA Recipe

This recipe installs the necessary modules for adding TFA functionality to a site.

## Installation

An ENV variable needs to be setup containing the encryption key with the name `TFA_KEY`.
The key needs to be generated using `dd if=/dev/urandom bs=32 count=1 | base64` see https://git.drupalcode.org/project/tfa/-/blob/8.x-1.x/README.md

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/tfa-recipe`
