# TFA Recipe

This recipe installs the necessary modules for adding TFA functionality to a site.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/tfa-recipe`

## CSP

If using `csp_per_page` the `strict_policy_img` will need updating to allow `data:` this allows the QR code to show on the
user page.
