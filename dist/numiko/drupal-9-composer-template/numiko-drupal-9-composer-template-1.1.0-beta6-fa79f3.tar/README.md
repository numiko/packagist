# Numiko Composer template for Drupal Project

## Quickstart

```
composer create-project numiko/drupal-9-composer-template:1.* PROJECT_NAME --stability dev --no-interaction --repository-url=https://numiko.github.io/packagist --ignore-platform-reqs  
cd <project directory>
cp ~/.ssh/key_for_bitbucket_repos docker/web/.env.key  
./scripts/dev/install-first-time  
```

You will now have a site running at [https://localhost:8081/](https://localhost:8081/).

## Background

This template is a fork of [Composer template for Drupal Projects](https://github.com/drupal-composer/drupal-project) with additional functionality specific to Numiko.

## Detailed usage

### Create the project

Create the project with Composer. Brings in the Docker files, Drupal and the install profile.

Replace PROJECT_NAME with the directory name where you want the project.

* `composer create-project numiko/drupal-9-composer-template:1.* PROJECT_NAME --stability dev --no-interaction --repository-url=https://numiko.github.io/packagist --ignore-platform-reqs
`

### Docker setup and Drupal install 

Copy your key into the container context so that it can be accessed during the build, then run the setup script:

* `cp ~/.ssh/my_selected_key docker/web/.env.key`
  
Build and bring up the Docker containers, install Drupal using Drush (will ask a series of questions about the site), and then set correct permissions:

* `./scripts/dev/install-first-time`
