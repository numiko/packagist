<?php

declare(strict_types=1);

namespace Drupal\reference_views_filter\Hook;

use Drupal\Core\Hook\Attribute\Hook;
use Drupal\field\FieldStorageConfigInterface;

/**
 * Hook implementations for reference_views_filter.
 */
class ReferenceViewsFilterHooks {

  /**
   * Implements hook_field_views_data_alter().
   *
   * Views integration for entity reference fields which reference taxonomy
   * terms. Adds a term relationship to the default field data.
   *
   * @see views_field_default_views_data()
   */
  #[Hook('field_views_data_alter')]
  public function fieldViewsDataAlter(array &$data, FieldStorageConfigInterface $field_storage): void {
    if ($field_storage->getType() === 'entity_reference' && $field_storage->getSetting('target_type') === 'node') {
      foreach ($data as $table_name => $table_data) {
        foreach ($table_data as $field_name => $field_data) {
          if (isset($field_data['filter']) && $field_name !== 'delta') {
            $data[$table_name][$field_name]['filter']['id'] = 'reference_select_id';
          }
        }
      }
    }
  }

}
