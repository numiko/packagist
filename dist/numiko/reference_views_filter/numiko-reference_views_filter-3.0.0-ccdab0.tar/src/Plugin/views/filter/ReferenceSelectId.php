<?php

declare(strict_types=1);

namespace Drupal\reference_views_filter\Plugin\views\filter;

use Drupal\Core\Entity\EntityRepositoryInterface;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\views\Attribute\ViewsFilter;
use Drupal\views\ViewExecutable;
use Drupal\views\Plugin\views\display\DisplayPluginBase;
use Drupal\views\Plugin\views\filter\ManyToOne;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Filter by entity id.
 *
 * @ingroup views_filter_handlers
 */
#[ViewsFilter("reference_select_id")]
class ReferenceSelectId extends ManyToOne {

  /**
   * Stores the exposed input for this filter.
   *
   * @var array
   */
  public $validatedExposedInput = [];

  const VIEW_DISPLAY_SEPERATOR = ':';

  /**
   * The view storage.
   */
  protected EntityStorageInterface $viewStorage;

  /**
   * The node storage.
   */
  protected EntityStorageInterface $nodeStorage;

  /**
   * Constructs a ReferenceSelectId object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   The entity type manager.
   * @param \Drupal\Core\Entity\EntityRepositoryInterface $entityRepository
   *   The entity repository.
   */
  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    EntityTypeManagerInterface $entityTypeManager,
    protected readonly EntityRepositoryInterface $entityRepository,
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->viewStorage = $entityTypeManager->getStorage('view');
    $this->nodeStorage = $entityTypeManager->getStorage('node');
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition): static {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('entity_type.manager'),
      $container->get('entity.repository'),
    );
  }

  /**
   * {@inheritdoc}
   */
  public function init(ViewExecutable $view, DisplayPluginBase $display, ?array &$options = NULL) {
    parent::init($view, $display, $options);

    if (!empty($this->definition['view'])) {
      $this->options['view'] = $this->definition['view'];
    }
  }

  /**
   * {@inheritdoc}
   */
  public function hasExtraOptions(): bool {
    return TRUE;
  }

  /**
   * {@inheritdoc}
   */
  public function getValueOptions(): array {
    return $this->valueOptions;
  }

  /**
   * {@inheritdoc}
   */
  protected function defineOptions(): array {
    $options = parent::defineOptions();

    $options['type'] = ['default' => 'select'];
    $options['limit'] = ['default' => TRUE];
    $options['view'] = ['default' => ''];
    $options['error_message'] = ['default' => TRUE];

    return $options;
  }

  /**
   * {@inheritdoc}
   */
  public function buildExtraOptionsForm(&$form, FormStateInterface $form_state) {
    $views = $this->viewStorage->loadMultiple();
    $options = [];
    foreach ($views as $view) {
      $all_displays = $view->get('display');
      $reference_displays = array_filter($all_displays, [$this, 'isDisplayEntityReference']);
      foreach ($reference_displays as $display) {
        $options[$view->id() . self::VIEW_DISPLAY_SEPERATOR . $display['id']] = $view->label() . ': ' . $display['display_title'];
      }
    }

    if ($this->options['limit']) {
      // We only do this when the form is displayed.
      if (empty($this->definition['view'])) {
        $form['view'] = [
          '#type' => 'radios',
          '#title' => $this->t('View'),
          '#options' => $options,
          '#description' => $this->t('Select which view to use to display items.'),
          '#default_value' => $this->options['view'],
        ];
      }
    }
  }

  /**
   * Function for array_filter to remove non-block view displays.
   *
   * @see getViewDisplays
   */
  protected function isDisplayEntityReference(array $view_display): bool {
    return $view_display['display_plugin'] === 'entity_reference';
  }

  /**
   * {@inheritdoc}
   */
  protected function valueForm(&$form, FormStateInterface $form_state) {
    if (empty($this->options['view']) && $this->options['limit']) {
      $form['markup'] = [
        '#markup' => '<div class="js-form-item form-item">' . $this->t('An invalid view is selected. Please change it in the options.') . '</div>',
      ];
      return;
    }

    $options = [];
    $viewRender = $this->getViewDisplay($this->options['view'])->render();
    if (is_array($viewRender)) {
      $ids = array_keys($viewRender);
      if ($ids) {
        $entities = $this->nodeStorage->loadMultiple($ids);
        foreach ($entities as $entity) {
          $options[$entity->id()] = $this->entityRepository
            ->getTranslationFromContext($entity)
            ->label();
        }
      }
    }

    $default_value = (array) $this->value;

    if ($exposed = $form_state->get('exposed')) {
      $identifier = $this->options['expose']['identifier'];

      if (!empty($this->options['expose']['reduce'])) {
        $options = $this->reduceValueOptions($options);

        if (!empty($this->options['expose']['multiple']) && empty($this->options['expose']['required'])) {
          $default_value = [];
        }
      }

      if (empty($this->options['expose']['multiple'])) {
        if (empty($this->options['expose']['required']) && (empty($default_value) || !empty($this->options['expose']['reduce']))) {
          $default_value = 'All';
        }
        elseif (empty($default_value)) {
          $keys = array_keys($options);
          $default_value = array_shift($keys);
        }
        // Due to #1464174 there is a chance that array('') was saved in the admin ui.
        // Let's choose a safe default value.
        elseif ($default_value === ['']) {
          $default_value = 'All';
        }
        else {
          $copy = $default_value;
          $default_value = array_shift($copy);
        }
      }
    }
    $form['value'] = [
      '#type' => 'select',
      '#title' => $this->t('Select content'),
      '#multiple' => TRUE,
      '#options' => $options,
      '#size' => min(9, count($options)),
      '#default_value' => $default_value,
    ];

    $user_input = $form_state->getUserInput();
    if ($exposed && isset($identifier) && !isset($user_input[$identifier])) {
      $user_input[$identifier] = $default_value;
      $form_state->setUserInput($user_input);
    }

    if (!$form_state->get('exposed')) {
      // Retain the helper option.
      $this->helper->buildOptionsForm($form, $form_state);

      // Show help text if not exposed to end users.
      $form['value']['#description'] = $this->t('Leave blank for all. Otherwise, the first selected term will be the default instead of "Any".');
    }
  }

  /**
   * Get an executable view from a view display id.
   *
   * @param string $view_display_id
   *   View and Display ID seperated using VIEW_DISPLAY_SEPERATOR.
   *
   * @return Drupal\views\ViewExecutable
   *   The executable view from the given id.
   */
  protected function getViewDisplay(string $view_display_id): ViewExecutable {
    $target = explode(self::VIEW_DISPLAY_SEPERATOR, $view_display_id);
    $view = $this->viewStorage->load($target[0]);
    $executable = $view->getExecutable();
    $executable->setDisplay($target[1]);
    $executable->setArguments($this->view->args);
    return $executable;
  }

  /**
   * {@inheritdoc}
   */
  protected function valueValidate($form, FormStateInterface $form_state): void {
    // We only validate if they've chosen the text field style.
    if ($this->options['type'] !== 'textfield') {
      return;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function acceptExposedInput($input): bool {
    if (empty($this->options['exposed'])) {
      return TRUE;
    }
    // We need to know the operator, which is normally set in
    // \Drupal\views\Plugin\views\filter\FilterPluginBase::acceptExposedInput(),
    // before we actually call the parent version of ourselves.
    if (!empty($this->options['expose']['use_operator']) && !empty($this->options['expose']['operator_id']) && isset($input[$this->options['expose']['operator_id']])) {
      $this->operator = $input[$this->options['expose']['operator_id']];
    }

    // If view is an attachment and is inheriting exposed filters, then assume
    // exposed input has already been validated.
    if (!empty($this->view->is_attachment) && $this->view->display_handler->usesExposed()) {
      $this->validatedExposedInput = (array) $this->view->exposed_raw_input[$this->options['expose']['identifier']];
    }

    // If we're checking for EMPTY or NOT, we don't need any input, and we can
    // say that our input conditions are met by just having the right operator.
    if ($this->operator === 'empty' || $this->operator === 'not empty') {
      return TRUE;
    }

    // If it's non-required and there's no value don't bother filtering.
    if (!$this->options['expose']['required'] && empty($this->validatedExposedInput)) {
      return FALSE;
    }

    $rc = parent::acceptExposedInput($input);
    if ($rc) {
      // If we have previously validated input, override.
      if (isset($this->validatedExposedInput)) {
        $this->value = $this->validatedExposedInput;
      }
    }

    return $rc;
  }

  /**
   * {@inheritdoc}
   */
  public function validateExposed(&$form, FormStateInterface $form_state): void {
    if (empty($this->options['exposed'])) {
      return;
    }

    $identifier = $this->options['expose']['identifier'];

    // We only validate if they've chosen the text field style.
    if ($this->options['type'] !== 'textfield') {
      if ($form_state->getValue($identifier) !== 'All') {
        $this->validatedExposedInput = (array) $form_state->getValue($identifier);
      }
      return;
    }

    if (empty($this->options['expose']['identifier'])) {
      return;
    }

    if ($values = $form_state->getValue($identifier)) {
      foreach ($values as $value) {
        $this->validatedExposedInput[] = $value['target_id'];
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  protected function valueSubmit($form, FormStateInterface $form_state): void {
    // Prevent array_filter from messing up our arrays in parent submit.
  }

  /**
   * {@inheritdoc}
   */
  public function buildExposeForm(&$form, FormStateInterface $form_state): void {
    parent::buildExposeForm($form, $form_state);
    if ($this->options['type'] !== 'select') {
      unset($form['expose']['reduce']);
    }
    $form['error_message'] = [
      '#type' => 'checkbox',
      '#title' => $this->t('Display error message'),
      '#default_value' => !empty($this->options['error_message']),
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function adminSummary() {
    // Set up $this->valueOptions for the parent summary.
    $this->valueOptions = [];

    if ($this->value) {
      $this->value = array_filter($this->value);
      $nodes = $this->nodeStorage->loadMultiple($this->value);
      foreach ($nodes as $node) {
        $this->valueOptions[$node->id()] = $this->entityRepository->getTranslationFromContext($node)->label();
      }
    }
    return parent::adminSummary();
  }

  /**
   * {@inheritdoc}
   */
  public function getCacheContexts() {
    $contexts = parent::getCacheContexts();
    // The result potentially depends on term access and so is just cacheable
    // per user.
    // @todo See https://www.drupal.org/node/2352175.
    $contexts[] = 'user';

    return $contexts;
  }

  /**
   * {@inheritdoc}
   */
  public function calculateDependencies() {
    $dependencies = parent::calculateDependencies();

    foreach ($this->nodeStorage->loadMultiple($this->options['value']) as $node) {
      $dependencies[$node->getConfigDependencyKey()][] = $node->getConfigDependencyName();
    }

    return $dependencies;
  }

}
