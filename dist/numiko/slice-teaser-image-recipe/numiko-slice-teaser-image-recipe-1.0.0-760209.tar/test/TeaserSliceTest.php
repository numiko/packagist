<?php

namespace Drupal\Tests\site_tests\Functional\Slices;

use Symfony\Component\HttpFoundation\Response;

/**
 * Check that the teaser slice displays on a page.
 *
 * @group slices
 */
class TeaserSliceTest extends AbstractSliceTestCase {

  /**
   * Test adding a teaser slice to a node.
   */
  public function testTeaserSliceDisplay(): void {
    $items = [
      [
        'target_id' => $this->createPublishedNode([
          'title' => 'Test page one',
          'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser_1.jpg')->id(),
        ])->id(),
      ],
      [
        'target_id' => $this->createPublishedNode([
          'title' => 'Test page two',
          'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser_2.jpg')->id(),
        ])->id(),
      ],
      [
        'target_id' => $this->createPublishedNode([
          'title' => 'Test page three',
          'field_image' => $this->getSampleImageMedia([], 'sample_image_teaser_3.jpg')->id(),
        ])->id(),
      ],
    ];

    $paragraphs[] = $this->createParagraph('slice_teaser', [
      'field_title' => 'Teaser slice title',
      'field_content_items' => $items,
    ]);

    $node = $this->createPublishedNode(['field_slices' => $paragraphs]);
    $assertSession = $this->assertSession();

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);

    $assertSession->pageTextContains('Teaser slice title');
    $assertSession->pageTextContains('Test page one');
    $assertSession->pageTextContains('Test page two');
    $assertSession->pageTextContains('Test page three');
    $assertSession->responseContains('sample_image_teaser_1.jpg');
    $assertSession->responseContains('sample_image_teaser_2.jpg');
    $assertSession->responseContains('sample_image_teaser_3.jpg');
  }

}
