# Teaser Image Slice Recipe

This recipe installs teaser image slice config.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/slice-teaser-list-slice
