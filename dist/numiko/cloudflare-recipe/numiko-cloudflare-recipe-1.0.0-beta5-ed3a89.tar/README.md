# Cloudflare Recipe

This recipe installs the necessary modules for Cloudflare.

## Installation

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/cloudflare`
