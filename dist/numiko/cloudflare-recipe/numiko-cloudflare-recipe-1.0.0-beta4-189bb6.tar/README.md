# Cloudflare Recipe

This recipe installs the necessary modules for Cloudflare.

## Installation

`composer require oomphinc/composer-installers-extender:2.0.1`

Update `composer.json` to add the `drupal-recipe` installer path.

```
"installer-types": ["drupal-recipe"],
"installer-paths": {
 "docroot/recipes/contrib/{$name}": ["type:drupal-recipe"]
}
```

Install this recipe with `composer require numiko/cloudflare-recipe`

Apply the recipe from the `docroot` folder.

`php core/scripts/drupal recipe recipes/contrib/cloudflare`
