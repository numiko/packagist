This is the [drupal.org Persona module](https://www.drupal.org/project/personas) with Drupal 9 compatibility added.

There is no D9 version on drupal.org, and [the issue fork for this work](https://git.drupalcode.org/issue/personas-3141390) cannot be checked out without a key and so is unsuitable for adding to the install profile.

So we have to take the code ourselves unfortunately.

Features/Improvements we have added:
* Granular permissions for Persona assignment
  * This creates permissions for the assignment of each persona, and not just for all
  * See GranularPersonaPermissionGenerator class

