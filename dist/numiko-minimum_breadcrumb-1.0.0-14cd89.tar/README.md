# Minimum Breadcrumb

Allows the defining of a global minimum to be met before outputting the breadcrumbs.

## Usage

After installing this module a global minimum of 2 items will be required before a breadcrumb is displayed, this number can currently be altered in your settings file.

```
$config['minimum_breadcrumb.settings']['minimum'] = 3;
```

## How this works

This works on a breadcrumb preprocessor checking if the minimum is met and if not then unsetting the breadcrumb.
