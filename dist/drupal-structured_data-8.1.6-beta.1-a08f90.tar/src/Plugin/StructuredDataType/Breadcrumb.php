<?php

namespace Drupal\structured_data\Plugin\StructuredDataType;

use Drupal\Core\Link;
use Drupal\structured_data\StructuredDataTypeBase;
use Drupal\structured_data\Exception\StructuredDataException;
use Drupal\Core\Form\FormStateInterface;

/**
 * Provides a 'breadcrumb' structured data type.
 *
 * @StructuredDataType(
 *   id = "breadcrumb",
 *   name = @Translation("Breadcrumb"),
 *   type = "BreadcrumbList"
 * )
 */
class Breadcrumb extends StructuredDataTypeBase {

  protected $baseUrl = '';

  public function getData() {
    $config = \Drupal::config('structured_data.settings');
    $this->baseUrl = ($config->get('breadcrumb.base')) ? $this->tokenizeString($config->get('breadcrumb.base')) : \Drupal::request()->getSchemeAndHttpHost();
    $breadcrumbData = $this->getBreadcrumbData();
    if ($breadcrumbData) {
      return parent::getData() + $breadcrumbData;
    }
    return [];
  }

  protected function getBreadcrumbData() {
    $breadcrumbData = \Drupal::Service('breadcrumb')->build(\Drupal::routeMatch());
    if (!$breadcrumbData->getLinks()) {
      throw new StructuredDataException('Content item does not have a breadcrumb');
    }
    $data = $this->getBreadcrumbBaseArray();
    $position = 1;
    foreach ($breadcrumbData->getLinks() as $breadcrumbItem) {
      $data['itemListElement'][] = $this->getBreadcrumbItem($breadcrumbItem, $position);
      $position++;
    }
    return $data;
  }

  protected function getBreadcrumbBaseArray() {
    return [
      "itemListElement" => [],
    ];
  }

  protected function getBreadcrumbItem(Link $breadcrumbLink, $position) {
    return [
      "@type" => "ListItem",
      "position" => $position,
      "item" => [
        "@id" => ($breadcrumbLink->getUrl()->toString()) ? $this->baseUrl . $breadcrumbLink->getUrl()->toString() : "",
        "name" => $breadcrumbLink->getText(),
      ]
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state, $config) {
    $build['breadcrumb__base'] = [
      '#title' => t('Breadcrumb base url'),
      '#type' => 'textfield',
      '#default_value' => !is_null($config->get('breadcrumb.base')) ? $config->get('breadcrumb.base') : $this->defaultConfiguration()['base'],
      '#description' => t("The string to be used for the breadcrumb base url (this can include tokens)"),
      '#element_validate' => array('token_element_validate'),
      '#after_build' => array('token_element_validate'),
    ];

    $build['breadcrumb__token_help'] = array(
      '#theme' => 'token_tree_link',
    );

    return $build;
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    return [
      'base' => '[site:url]',
    ];
  }

}
