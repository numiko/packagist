<?php

namespace Drupal\numiko_security_review\Checks;

use Drupal\security_review\Check;
use Drupal\security_review\CheckResult;
use Drupal\user\Entity\User;

/**
 * Checks whether untrusted roles have restricted permissions.
 */
class PasswordPolicy extends Check {

  const RECOMMENDED_MIN_PASSWORD_LENGTH = 10;

  /**
   * {@inheritdoc}
   */
  public function getNamespace() {
    return 'Security Review';
  }

  /**
   * {@inheritdoc}
   */
  public function getTitle() {
    return 'Password policy';
  }

  /**
   * {@inheritdoc}
   */
  public function run() {
    // Check that the module is enabled.
    if (!$this->moduleHandler()->moduleExists('password_policy')) {
      return $this->createResult(CheckResult::FAIL, ['Module not enabled']);
    }

    // Check that at least one policy exists.
    // Password validation will pass if no policy exists.
    $policies = $this->container->get('entity_type.manager')
      ->getStorage('password_policy')
      ->loadMultiple();
    if (!$policies) {
      return $this->createResult(CheckResult::FAIL, ['No policy']);
    }

    // Check password policy for each role.
    $allRoles = user_roles(TRUE);
    $findings = [];

    foreach ($allRoles as $role) {
      $user = new User([], 'user');

      // Validate passwords from recommended length minus one down to length of
      // one in order to find any policies that allow less than the minimum.
      for ($passwordLength=(self::RECOMMENDED_MIN_PASSWORD_LENGTH-1);
           $passwordLength>=1;
           $passwordLength--) {

        $valid = \Drupal::service('password_policy.validator')
          ->validatePassword(
            $this->getRandomPassword($passwordLength),
            $user,
            [$role->id()]
          );
        if ($valid) {
          $findings[] = 'Password length of '
            . $passwordLength . ' allowed for '
            . $role->label();
          break;
        }
      }
    }

    if ($findings) {
      return $this->createResult(CheckResult::FAIL, $findings);
    }
    else {
      return $this->createResult(CheckResult::SUCCESS);
    }
  }

  /**
   * Generate a random password.
   *
   * Checks for Drupal 9 password_generator service or uses deprecated
   * user_password().
   *
   * @param int $length
   *
   * @return string
   */
  protected function getRandomPassword(int $length): string {
    if ($this->container->has('password_generator')) {
      $passwordGenerator = $this->container->get('password_generator');
      return $passwordGenerator->generate($length);
    }
    else if (function_exists('user_password')){
      return user_password($length);
    }
    else {
      throw new \Exception('Cannot find password generation function');
    }
  }

  /**
   * {@inheritdoc}
   */
  public function help() {
    return [];
  }

  /**
   * {@inheritdoc}
   */
  public function evaluate(CheckResult $result) {
    if ($result->result() == CheckResult::SUCCESS) {
      return [];
    }

    return [
      '#theme' => 'check_evaluation',
      '#paragraphs' => $result->findings(),
      '#items' => [],
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function evaluatePlain(CheckResult $result) {
    $output = '';

    foreach ($result->findings() as $message) {
      $output .= $message . "\n";
    }

    return $output;
  }

  /**
   * {@inheritdoc}
   */
  public function getMessage($result_const) {
    switch ($result_const) {
      case CheckResult::SUCCESS:
        return $this->t('Password policy configured correctly for all roles.');

      case CheckResult::FAIL:
        return $this->t('Password policy not configured correctly.');

      default:
        return $this->t("Unexpected result.");
    }
  }

}
