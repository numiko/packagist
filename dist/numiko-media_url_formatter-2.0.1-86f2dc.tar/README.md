# Media URL Formatter #

This URL formatter works with both image & media fields (two separate field formatter).

## But is it just a URL formatter? ##

Alas no, this url formatter outputs the actual image URL in the given image style (where selected) but also adds the alt text as an additional property.

For example, on an image field called `field_image` you can access this in the twig template using `content.field_image.alt` while `content.field_image` will give you the image url.