<?php

namespace Drupal\devel_matrix\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Entity\EntityTypeBundleInfo;
use Drupal\Core\Entity\EntityFieldManager;
use Drupal\field\Entity\FieldConfig;
use Drupal\Core\Url;
use \Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Provides route responses for field matrix.
 */
class FieldMatrixController extends ControllerBase implements ContainerInjectionInterface {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeBundleInfo
   */
  protected $entityTypeBundleInfo;

  /**
   * The entity field manager.
   *
   * @var \Drupal\Core\Entity\EntityFieldManager
   */
  protected $entityFieldManager;

  /**
   * Constructs a FieldMatrixController object.
   */
  public function __construct(EntityTypeBundleInfo $entity_type_bundle_info, EntityFieldManager $entity_field_manager) {
    $this->entityTypeBundleInfo = $entity_type_bundle_info;
    $this->entityFieldManager = $entity_field_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.bundle.info'),
      $container->get('entity_field.manager')
    );
  }

  /**
   * List available entity types and provide link.
   */
  public function reportMenu() {
    $fields = $this->entityFieldManager->getFieldMap();
    $entityTypes = \Drupal::entityTypeManager()->getDefinitions();

    foreach ($fields as $entityType => $fields) {
      $items[] = [
        'title' => $entityTypes[$entityType]->getLabel(),
        'url' => Url::fromRoute('devel_matrix.report', ['entity_type' => $entityType]),
        'description' => $entityType,
      ];
    }

    return [
      '#theme' => 'admin_block_content',
      '#content' => $items,
    ];
  }

  /**
   * Get a supporter details.
   */
  public function report($entity_type) {
    $entityType = $entity_type;

    $header = ['Field name'];
    $rows = [];

    $fields = $this->entityFieldManager->getFieldMap();

    if (!isset($fields[$entityType])) {
      throw new NotFoundHttpException();
    }

    $bundles = $this->entityTypeBundleInfo->getBundleInfo($entityType);

    foreach ($bundles as $bundleId => $bundle) {
      $header[] = $bundle['label'];
      $bundleFields[$bundleId] = $this->entityFieldManager->getFieldDefinitions($entityType, $bundleId);
    }

    foreach ($fields[$entityType] as $fieldName => $field) {
      $row = [$fieldName . ' (' . $field['type'] . ')'];
      foreach ($bundles as $bundleId => $bundle) {
        if (isset($bundleFields[$bundleId][$fieldName])) {
          $row[] = [
            'data' => '✔',
            'title' => ($bundleFields[$bundleId][$fieldName] instanceof FieldConfig) ? $bundleFields[$bundleId][$fieldName]->label() : "",
          ];
        }
        else {
          $row[] = [
            'data' => '☐',
          ];
        }
      }
      $rows[] = $row;
    }

    return [
      '#theme' => 'table',
      '#header' => $header,
      '#rows' => $rows,
      '#sticky' => TRUE,
    ];
  }

}
