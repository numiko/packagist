# Facets Attachment #

By default each view requires a separate facet including views attached to other views. This module causes an attachment view to inherit selected facets from its attached view.

## Installation ##

In order to use this module just install according to normal Drupal module installation instructions and it will operate on all attachment views with facets associated.