<?php

namespace Drupal\slice;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Slice type entities.
 */
interface SliceTypeInterface extends ConfigEntityInterface {
  // Add get/set methods for your configuration properties here.
}
