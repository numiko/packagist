<?php
namespace Drupal\migrate_group_ui\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\migrate_tools\MigrateExecutable;
use Drupal\migrate_group_ui\DisplayMigrateMessage;
use Drupal\file\Entity\File;
use Drupal\Core\Url;
use Drupal\migrate_group_ui\Plugin\migrate_plus\data_parser\ReplaceableUrlDataParser;

class ExecuteMigrateForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'migrate_execute_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $args = func_get_args();
    $migration_group = $args[2];

    $config = $this->config('migrate_group_ui.settings');
    $upload_location = $config->get('file_scheme') . '://' . $config->get('upload_directory') . '/';

    foreach ($this->getGroupMigrations($migration_group) as $migration) {
      $data_parser = $migration->getSourcePlugin()->getDataParserPlugin();
      $mid = $migration->id();
      if ($data_parser instanceof ReplaceableUrlDataParser) {
        $form[$mid] = array(
          '#title' => ucfirst($mid),
          '#description' => $migration->label(),
          '#type' => 'fieldset',
        );
        $form[$mid][$mid . '_uploaded_file'] = array(
          '#type' => 'managed_file',
          '#title' => $this->t('Override ') . $mid . t(' source file'),
          '#required' => true,
          '#upload_location' => $upload_location,
          '#upload_validators' => [
            'file_validate_extensions' => [$data_parser->getValidExtensions()],
          ],
        );
      }
    }

    $form['migration_group'] = array(
      '#type' => 'hidden',
      '#value' => $migration_group,
    );

    $form['confirm']['#markup'] = "<b>" . $this->t("Clicking 'Migrate' will start the migration") . "</b>";

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Migrate'),
      '#button_type' => 'primary',
    );
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getvalues();
    $migration_group = $values['migration_group'];
    $log = new DisplayMigrateMessage();
    foreach ($this->getGroupMigrations($migration_group) as $migration) {
      $mid = $migration->id();
      if (isset($values[$mid . '_uploaded_file'])) {
        $this->replaceSourceFileForMigration($migration, $values[$mid . '_uploaded_file'][0]);
      }
      $executable = new MigrateExecutable($migration, $log);
      $executable->import();
    }
    $this->setUserRedirect($form_state, $migration_group);
  }

  /**
   * Set the redirection on completion based on access level.
   */
  protected function setUserRedirect(FormStateInterface $form_state, $migration_group) {
    if ($this->userHasAdministratorAccess()) {
      $form_state->setRedirect('entity.migration_group.list');
    } else {
      $form_state->setRedirect('entity.migration_group.execute', array('migration_group' => $migration_group));
    }
  }

  /**
   * Check if the user can administer migrations.
   */
  protected function userHasAdministratorAccess() {
    $user = \Drupal::currentUser();
    return $user->hasPermission('administer migrations');
  }

  /**
   * Get the migration groups.
   */
  protected function getGroupMigrations($group_id) {
    $manager = \Drupal::service('plugin.manager.config_entity_migration');
    $plugins = $manager->createInstances([]);
    $migrations = [];
    foreach ($plugins as $id => $migration) {
      $configured_group_id = ($migration->get('migration_group')) ?: 'default';
      if ($group_id == $configured_group_id) {
        $migrations[$id] = $migration;
      }
    }
    return $migrations;
  }

  /**
   * Get the value from the form where necessary and convert to file path.
   */
  protected function replaceSourceFileForMigration($migration, $file_id) {
    if ($file_id) {
      $data_parser = $migration->getSourcePlugin()->getDataParserPlugin();
      if ($data_parser instanceof ReplaceableUrlDataParser) {
        $this->replaceSourceUrl($data_parser, $this->getFilePathFromId($file_id));
      }
    }
  }

  /**
   * Replace the source url of the data parser.
   */
  protected function replaceSourceUrl(ReplaceableUrlDataParser $data_parser, $file_path) {
    $file_paths = array($file_path);
    $data_parser->replaceUrls($file_paths);
  }

  /**
   * Get the file path from the managed file ID.
   */
  protected function getFilePathFromId($uploaded_file_id) {
    $file = File::load($uploaded_file_id);
    return \Drupal::service('file_system')->realpath($file->getFileUri());
  }

}