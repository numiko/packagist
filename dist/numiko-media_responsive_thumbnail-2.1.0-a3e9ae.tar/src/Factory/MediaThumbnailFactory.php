<?php

namespace Drupal\media_responsive_thumbnail\Factory;

use Drupal\media\MediaInterface;

class MediaThumbnailFactory {
  
  public static function getWithAltText(MediaInterface $mediaItem) {
    $mediaType = $mediaItem->getSource();
    $thumbnail = $mediaItem->get('thumbnail');
    switch ($mediaType->getPluginId()) {
      case 'image':
        if ($thumbnailEntity = $thumbnail->getEntity()) {
          $thumbnailSourceField = $mediaType->getConfiguration()['source_field'];
          if (!$thumbnailEntity->get($thumbnailSourceField)->isEmpty()) {
            if ($thumbnailEntityValue = $thumbnailEntity->get($thumbnailSourceField)->first()->getValue()) {
              $thumbnail->alt = $thumbnailEntityValue['alt'];
            }
          }
        }
	break;
      default:
        $thumbnail->alt = $thumbnail->title;
	break;
    }
    return $thumbnail;
  }

}
