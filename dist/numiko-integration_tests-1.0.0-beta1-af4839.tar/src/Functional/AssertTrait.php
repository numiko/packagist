<?php

namespace Drupal\integration_tests\Functional;

use weitzman\DrupalTestTraits\GoutteTrait;

/**
 * Provide useful assertions not available in phpunit.
 *
 * @package Drupal\integration_tests\Functional
 */
trait AssertTrait {

  use GoutteTrait;

  abstract public static function assertNotFalse($condition, $message = '');

  abstract protected function assertEqual($actual, $expected, $message = '');

  abstract public static function fail($message = '');

  /**
   * Asserts that one string appears before another in a container string.
   *
   * @param string $first
   *   The string that should appear first.
   * @param string $second
   *   The string that should appear second.
   * @param string $haystack
   *   The containing string.
   */
  public function assertAppearsBefore($first, $second, $haystack) {
    $whereFirst = strpos($haystack, $first);
    static::assertNotFalse($whereFirst, 'First string is missing');
    $whereSecond = strpos($haystack, $second);
    static::assertNotFalse($whereSecond, 'Second string is missing');
    static::assertLessThan($whereSecond, $whereFirst, 'First string is after second');
  }


  /**
   * Assert the value of querystring at the current URL.
   *
   * Mink's addressEquals() strips the querystring so we need this instead.
   *
   * @param $expected
   * @param $url
   */
  protected function assertQuerystring($expected) {
    $url = parse_url($this->getSession()->getCurrentUrl());
    if (empty($url['query']) && $expected) {
      $this->fail('Wrong query string');
    }
    return isset($url['query']) && $this->assertEqual($expected, $url['query']);
  }

  /**
   * Convenience function to visit URL and assert status code in one.
   *
   * @param $url
   * @param $expectedStatusCode
   */
  protected function visitCheckCode($url, $expectedStatusCode) {
    $this->drupalGet($url);
    $this->assertSession()->statusCodeEquals($expectedStatusCode);
  }

}
