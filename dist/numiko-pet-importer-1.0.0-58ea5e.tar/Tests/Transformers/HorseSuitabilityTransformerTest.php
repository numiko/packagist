<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests\Transformers;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\Transformers\HorseSuitabilityTransformer;

class HorseSuitabilityTransformerTest extends TestCase
{
    public function setUp(): void
    {
        $this->transformer = new HorseSuitabilityTransformer();
    }


    /**
     *
     * @testWith [["Ridden"], "ridden"]
     *           [["Ridden"], "Ridden"]
     *           [["Companion"], "Companion"]
     *           [["Companion"], "companion"]
     *           [["Ridden", "Companion"], "both"]
     *           [["Ridden", "Companion"], "Both"]
     *           [[], "Invalid answer"]
     *           [[], ""]
     *           [[], null]
     */
    public function testExpected($expected, $answer)
    {
        $this->assertEquals($expected, $this->transformer->transform($answer));
    }
}
