<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests\Transformers;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\Transformers\AgeBracketTransformer;

class AgeBracketTransformerTest extends TestCase
{
    public function setUp(): void
    {
        $this->transformer = new AgeBracketTransformer();
    }


    /**
     *
     * @testWith ["0 - 2", 0, 0]
     *           ["0 - 2", 0, 12]
     *           ["0 - 2", 1, 7]
     *           ["2 - 4", 2, 0]
     *           ["4 - 6", 3, 12]
     *           ["6 - 8", 7, 11]
     *           ["8 - 10", 8, 0]
     *           ["10+", 10, 0]
     *           ["10+", 11, 11]
     *           ["", 1, null]
     *           ["", null, null]
     *           ["", null, 1]
     */
    public function testExpected($expected, $ageYears, $ageMonths)
    {
        $this->assertEquals($expected, $this->transformer->transform($ageYears, $ageMonths));
    }
}
