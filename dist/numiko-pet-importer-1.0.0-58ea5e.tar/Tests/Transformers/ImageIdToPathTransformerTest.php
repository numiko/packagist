<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests\Transformers;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\Transformers\ImageIdToPathTransformer;

class ImageIdToPathTransformerTest extends TestCase
{
    public function setUp(): void
    {
        $this->transformer = new ImageIdToPathTransformer('/path/to/images/');
    }


    /**
     *
     * @testWith ["/path/to/images/123456.jpg", 123456]
     */
    public function test($expected, $imageId)
    {
        $this->assertEquals($expected, $this->transformer->transform($imageId));
    }
}
