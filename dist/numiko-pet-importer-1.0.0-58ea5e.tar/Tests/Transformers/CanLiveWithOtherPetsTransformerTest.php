<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Tests\Transformers;

use PHPUnit\Framework\TestCase;
use Numiko\PetImporter\Transformers\CanLiveWithOtherPetsTransformer;

class CanLiveWithOtherPetsTransformerTest extends TestCase
{
    public function setUp(): void
    {
        $this->transformer = new CanLiveWithOtherPetsTransformer();
    }


    /**
     *
     * @testWith [["Cats"], "cats"]
     *           [["Cats"], "Cats"]
     *           [["Cats", "Dogs"], "Cats and Dogs"]
     *           [["Dogs"], "Dogs"]
     *           [["Dogs"], "dogs"]
     *           [[], "Invalid answer"]
     *           [[], ""]
     *           [[], null]
     */
    public function testExpected($expected, $answer)
    {
        $this->assertEquals($expected, $this->transformer->transform($answer));
    }
}
