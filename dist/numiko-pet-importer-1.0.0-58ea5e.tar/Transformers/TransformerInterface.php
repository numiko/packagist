<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Transformers;

interface TransformerInterface
{
    public function transform();
}
