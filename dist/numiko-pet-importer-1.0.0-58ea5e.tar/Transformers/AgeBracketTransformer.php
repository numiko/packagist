<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Transformers;

/**
 * Class: AgeBracketTransformer
 *
 * Transforms a numeric data to a value in a list of ranges.
 *
 * @author Dan Bentley
 */
class AgeBracketTransformer implements TransformerInterface
{
    public const VALUES = [
        0 => '0 - 2',
        2 => '2 - 4',
        4 => '4 - 6',
        6 => '6 - 8',
        8 => '8 - 10',
        10 => '10+',
    ];

    /**
     * transform
     *
     * Transformas an age into a relevent age bracket entry
     *
     * @param ?int $ageYears
     * @param ?int $ageMonths
     * @return string age bracket
     */
    public function transform(?int $ageYears=null, ?int $ageMonths=null): string
    {
        if ($ageYears === null || $ageMonths === null) {
            return '';
        }

        $decimalAge = $ageYears + ($ageMonths / 12);

        $ages = array_keys(self::VALUES);
        $initial = current($ages);

        $key = array_reduce($ages, function ($previousAge, $age) use ($decimalAge) {
            return ($decimalAge >= $age) ? $age : $previousAge;
        }, $initial);

        return self::VALUES[$key];
    }
}
