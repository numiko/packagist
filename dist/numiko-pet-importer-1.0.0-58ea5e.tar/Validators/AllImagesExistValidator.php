<?php

declare(strict_types=1);

namespace Numiko\PetImporter\Validators;

/**
 * Class: AllImagesExistValidator
 *
 * This class ensures that all referenced images exist on disk before adding to
 * pets array.
 *
 * @author Dan Bentley
 */
class AllImagesExistValidator
{

    /**
     * validate
     *
     * Checks pet data to ensure that all refrenced images are present on disk
     *
     * @param mixed $petData
     * @return bool
     */
    public function validate($petData): bool
    {
        if (!array_key_exists('images', $petData)) {
            return false;
        }

        $petImages = $petData['images'];
        if (!array_key_exists('gallery_urls', $petImages) || !array_key_exists('featured_image_url', $petImages)) {
            return false;
        }

        $images = $petImages['gallery_urls'];
        $images[] = $petImages['featured_image_url'];

        $imagesOnDisk = array_filter($images, function ($imagePath) {
            return file_exists($imagePath);
        });

        return count($imagesOnDisk) === count($images);
    }
}
