<?php

namespace Drupal\adestra\Client;

use \PhpXmlRpc\Client;
use \PhpXmlRpc\Value;
use \PhpXmlRpc\Request;
use Drupal\adestra\Map\XmlRpcValueMap;
use Drupal\Core\Config\ConfigFactory;

/**
 * Handle remote calls to the messagefocus API.
 */
class AdestraClient {

  protected $xmlRpcValueMap;
  protected $account = NULL;
  protected $username = NULL;
  protected $password = NULL;
  protected $tableId = NULL;
  protected $xmlrpc = NULL;

  /**
   * Create an instance of an AdestraClient.
   */
  public function __construct(XmlRpcValueMap $xml_rpc_value_map, ConfigFactory $config_factory) {
    $this->xmlRpcValueMap = $xml_rpc_value_map;
    $config = $config_factory->get('adestra.settings');
    $this->account = ($config->get('account')) ?: "";
    $this->username = ($config->get('username')) ?: "";
    $this->password = ($config->get('password')) ?: "";
    $this->tableId = ($config->get('table_id')) ?: "";
    $this->debug = ($config->get('debug')) ?: FALSE;
  }

  /**
   * Get the core table id.
   */
  public function getTableId() {
    return $this->tableId;
  }

  /**
   * Send an XmlRpc request.
   */
  public function request($endpoint, $params = []) {
    $options = $this->arrayToValues($params);
    $msg = new Request($endpoint, $options);
    if (!$this->xmlrpc) {
      $this->initClient();
    }
    return $this->xmlrpc->send($msg);
  }

  /**
   * Convert the XmlRpcValue to a data array.
   */
  public function xmlRpcValueToArray(Value $value) {
    return $this->xmlRpcValueMap->valueToArray($value);
  }

  /**
   * Initialise the XmlRpc client.
   */
  protected function initClient() {
    $xmlrpc = new Client("http://{$this->account}.{$this->username}:{$this->password}@app.adestra.com/api/xmlrpc");
    $xmlrpc->setDebug($this->debug);
    $this->xmlrpc = $xmlrpc;
  }

  /**
   * Convert the params to values ready to send.
   */
  protected function arrayToValues($array = []) {
    $values = [];
    foreach ($array as $key => $value) {
      if (is_array($value)) {
        $value = $this->arrayToValues($value);
        $values[$key] = new Value($value, $this->isAssociative($value) ? 'struct' : 'array');
      }
      if (is_numeric($value)) {
        $values[$key] = new Value($value, 'int');
      }
      if (is_string($value)) {
        $values[$key] = new Value($value, 'string');
      }
      if (is_bool($value)) {
        $values[$key] = new Value($value, 'boolean');
      }
    }
    return $values;
  }

  /**
   * Is the parameter an associative array.
   */
  protected function isAssociative($arr) {
    if (!is_array($arr)) {
      return FALSE;
    }
    return !isset($arr[0]);
  }

}
