<?php

namespace Drupal\styleguide_media_modal\MediaModal;

use Drupal\Core\Entity\EntityInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\styleguide_media_modal\MediaModal\MediaModalInterface;

/**
 * Implementation of media modal for image media.
 */
class VideoMediaModal implements MediaModalInterface {

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Video media modal constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager) {
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * {@inheritdoc}
   */
  public function buildModalData(EntityInterface $entity) {
    $modalData = [
      "type" => $entity->bundle(),
      "id" => $entity->id(),
    ];

    $builder = $this->entityTypeManager->getViewBuilder('media');

    if ($entity->hasField('name')) {
      $modalData['title'] = $builder->viewField($entity->get('name'));
    }

    if ($entity->hasField('field_media_oembed_video') &&
      !$entity->get('field_media_oembed_video')->isEmpty()) {
      $modalData['video_file'] = $builder->viewField(
        $entity->get('field_media_oembed_video')
      );
    }

    return $modalData;
  }

}
