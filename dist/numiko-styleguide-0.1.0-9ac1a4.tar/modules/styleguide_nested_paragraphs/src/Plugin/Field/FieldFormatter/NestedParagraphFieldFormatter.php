<?php

namespace Drupal\styleguide_nested_paragraphs\Plugin\Field\FieldFormatter;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Entity\Entity\EntityViewDisplay;
use Drupal\entity_reference_revisions\Plugin\Field\FieldFormatter\EntityReferenceRevisionsEntityFormatter;

/**
 * Plugin implementation of the 'Webform rendered entity' formatter.
 *
 * @FieldFormatter(
 *   id = "styleguide_nested_paragraph_view",
 *   label = @Translation("Styleguide Nested Paragraph View"),
 *   description = @Translation("Display a nested paragraph."),
 *   field_types = {
 *     "entity_reference_revisions"
 *   }
 * )
 */
class NestedParagraphFieldFormatter extends EntityReferenceRevisionsEntityFormatter {

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    // The view mode configured in 'Manage display'.
    $viewMode = $this->getSetting('view_mode');
    $elements = array();

    foreach ($this->getEntitiesToView($items, $langcode) as $delta => $entity) {
      // Protect ourselves from recursive rendering.
      static $depth = 0;
      $depth++;
      if ($depth > 20) {
        $this->loggerFactory->get('entity')->error('Recursive rendering detected when rendering entity @entity_type @entity_id. Aborting rendering.', array('@entity_type' => $entity->getEntityTypeId(), '@entity_id' => $entity->id()));
        return $elements;
      }
      $viewBuilder = \Drupal::entityTypeManager()->getViewBuilder($entity->getEntityTypeId());
      $display = EntityViewDisplay::load($entity->getEntityTypeId() . '.' . $entity->bundle() . '.' . $viewMode);

      $item = [];
      // Make the entity ID available.
      $item['id'] = $entity->id();
      // Get all fields set to be displayed for the selected view mode.
      $entityDisplayFieldNames = array_keys($display->getComponents());
      foreach ($entityDisplayFieldNames as $fieldName) {
        // We use field names with the 'field_' prefix removed for use in
        // the style guide.
        $shortFieldName = str_replace("field_", "", $fieldName);
        // Get the render array for the field.
        $item[$shortFieldName] = $viewBuilder->viewField($entity->get($fieldName), $viewMode);
      }
      $elements[$delta] = $item;
      $depth = 0;
    }

    return $elements;
  }

}
