# Reference Views Filter #

## What is this module for? ##

* Replace a plain text node reference look-up with a select list from an entity reference view.

## Required Improvements ##

* Add an option to filter by bundle rather than having to attach a view
* Modify to work with all entity types not just nodes