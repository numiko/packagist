<?php


namespace Drupal\sensible_email_validation;

use Egulias\EmailValidator\EmailLexer;
use Egulias\EmailValidator\EmailParser;
use Egulias\EmailValidator\Result\InvalidEmail;
use Egulias\EmailValidator\Validation\EmailValidation;

class TLDValidation implements EmailValidation {

  /**
   * @var EmailParser|null
   */
  private $parser;

  /**
   * @var array
   */
  private $warnings = [];

  /**
   * @var ?InvalidEmail
   */
  private $error;

  /**
   * {@inheritdoc}
   */
  public function isValid(string $email, EmailLexer $emailLexer): bool {
    $this->parser = new EmailParser($emailLexer);
    try {
      $parts = $this->parser->parse($email);
      if (isset($parts['domain'])) {
        if (strpos($parts['domain'], '.') !== FALSE) {
          $this->warnings = $this->parser->getWarnings();
          return TRUE;
        }
      }
    }
    catch (\Exception $invalid) {
      $this->error = new InvalidEmail(new NoTLD(), '');
    }
    return FALSE;
  }

  /**
   * {@inheritdoc}
   */
  public function getError(): ?InvalidEmail {
    return $this->error;
  }

  /**
   * {@inheritdoc}
   */
  public function getWarnings(): array {
    return $this->warnings;
  }

}
