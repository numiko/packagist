# README #

Module that provides a field formatter for file types. Displays filename and file size.

### Theming ###

Copy templates/file-size-display-formatter.html.twig to your theme directory.