<?php

namespace Drupal\minimal_date_fields\Plugin\Field\FieldWidget;

use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\datetime\Plugin\Field\FieldWidget\DateTimeDatelistWidget;

/**
 * Plugin implementation of the 'datetime_minimaldatelist' widget.
 *
 * @FieldWidget(
 *   id = "datetime_minimaldatelist",
 *   label = @Translation("Minimal Select list"),
 *   field_types = {
 *     "datetime"
 *   }
 * )
 */
class YearMonthYearWidget extends DateTimeDatelistWidget {
  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return [
      'date_order' => 'MY',
    ] + parent::defaultSettings();
  }
  /**
   * {@inheritdoc}
   */
  public function formElement(FieldItemListInterface $items, $delta, array $element, array &$form, FormStateInterface $form_state) {
    $element = parent::formElement($items, $delta, $element, $form, $form_state);
   
    $date_order = $this->getSetting('date_order');
    
    // Set up the date part order array.
    switch ($date_order) {
      case 'MY':
        $date_part_order = ['month', 'year'];
        break;
        
      case 'Y':
        $date_part_order = ['year'];
        break;
    }
 
    $element['value']['#date_part_order'] = $date_part_order;
    
    return $element;
  }
  
  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $element = parent::settingsForm($form, $form_state);
    
    $element['date_order'] = [
      '#type' => 'select',
      '#title' => t('Date part order'),
      '#default_value' => $this->getSetting('date_order'),
      '#options' => ['MY' => t('Month/Year'), 'Y' => t('Year')],
    ];
    
      $element['time_type'] = [
        '#type' => 'hidden',
        '#value' => 'none',
      ];
      
      $element['increment'] = [
        '#type' => 'hidden',
        '#value' => $this->getSetting('increment'),
      ];
    
    return $element;
  }
}
