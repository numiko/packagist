# Webform Ajax #

This module enables Ajax functionality on 'inline' webforms.

## Further Requirements ##

* Need to test this with different elements
* Need to write automated tests