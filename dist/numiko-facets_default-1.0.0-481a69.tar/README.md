# Facets Default #

A facet processor to set an active facet by default. This can be either specified as a value or token.

NB Noticed when used with Drupal Core 8.9 - the Facets module does not have an option to Hide Default Option for Dropdown Widget,
without this, the Facets Default module will not work as expected, as the default facet value configured will conflict with the 
out of the box drupal Facet default -all- value.

patch to apply: https://www.drupal.org/project/facets/issues/3014027


