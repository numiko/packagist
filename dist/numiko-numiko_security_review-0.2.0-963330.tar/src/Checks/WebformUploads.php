<?php

namespace Drupal\numiko_security_review\Checks;

use Drupal\security_review\Check;
use Drupal\security_review\CheckResult;

/**
 * Check dangerous webform settings.
 */
class WebformUploads extends Check {

  /**
   * @inheritDoc
   */
  public function getNamespace() {
    return 'Security Review';
  }

  /**
   * @inheritDoc
   */
  public function getTitle() {
    return 'Webform uploads';
  }

  /**
   * @inheritDoc
   */
  public function run() {
    $webformSettings = \Drupal::config('webform.settings');
    $findings = [];

    // Uploads to the public file area should be disallowed, regardless
    // of whether any upload elements are allowed.
    if ($webformSettings->get('file.file_public')) {
      $findings[] = 'Public webform uploads are allowed';
    }

    // All of these dangerous elements should be in the "excluded element"
    // config. If not, it allows webforms to be used for unintended purposes.
    $dangerousElements = [
      'managed_file',
      'password',
      'password_confirm',
      'webform_audio_file',
      'webform_document_file',
      'webform_image_file',
      'webform_signature',
      'webform_video_file',
    ];
    $excludedElements = $webformSettings->get('element.excluded_elements');
    foreach ($dangerousElements as $dangerousElement) {
      if (!in_array($dangerousElement, $excludedElements)) {
        $findings[] = 'Dangerous element ' . $dangerousElement . ' is available';
      }
    }

    if ($findings) {
      return $this->createResult(CheckResult::FAIL, $findings);
    }

    return $this->createResult(CheckResult::SUCCESS);
  }

  /**
   * {@inheritdoc}
   */
  public function evaluatePlain(CheckResult $result) {
    $output = '';

    foreach ($result->findings() as $message) {
      $output .= $message . "\n";
    }

    return $output;
  }

  /**
   * @inheritDoc
   */
  public function help() {
    // TODO: Implement help() method.
  }

  /**
   * @inheritDoc
   */
  public function getMessage($result_const) {
    switch ($result_const) {
      case CheckResult::SUCCESS:
        return $this->t('No unsafe webform settings.');

      case CheckResult::FAIL:
        return $this->t('Unsafe webform settings.');

      default:
        return $this->t("Unexpected result.");
    }
  }

}
