<?php

namespace Drupal\numiko_security_review\tests\Kernel;

use Drupal\KernelTests\KernelTestBase;
use Drupal\numiko_security_review\Checks\RoutesAccess;
use Drupal\security_review\CheckResult;

class RoutesAccessTest extends KernelTestBase {

  /**
   * Modules to enable.
   *
   * @var array
   */
  public static $modules = [
    'routes_access_test',
    'security_review',
    'numiko_security_review',
  ];

  /**
   * Tests routes in routes_access_test module.
   *
   * This will not work when this module is installed in modules/contrib as
   * it only checks modules in modules/custom.
   */
  function testRoutes() {
    $accessCheck = new RoutesAccess();
    $result = $accessCheck->run();
    $this->assertEquals(
      CheckResult::INFO,
      $result->result()
    );
    $findings = $result->findings();
    $this->assertFalse(isset($findings['routes_access_test.protected']));

    $this->assertTrue(isset($findings['routes_access_test.basic_permission']));
    $this->assertStringContainsString(
      'Route _permission is open',
      $findings['routes_access_test.basic_permission']
    );

    $this->assertTrue(isset($findings['routes_access_test.open']));
    $this->assertStringContainsString(
      'Route _access is TRUE',
      $findings['routes_access_test.open']
    );

    $this->assertTrue(isset($findings['routes_access_test.anon_role']));
    $this->assertStringContainsString(
      'Route _role is "anonymous"',
      $findings['routes_access_test.anon_role']
    );

    $this->assertTrue(isset($findings['routes_access_test.multiple_roles']));
    $this->assertStringContainsString(
      'Route _role is "anonymous"',
      $findings['routes_access_test.multiple_roles'],
    );

    $this->assertTrue(isset($findings['routes_access_test.isuserloggedin']));
    $this->assertStringContainsString(
      'Route uses isuserloggedin = false',
      $findings['routes_access_test.isuserloggedin'],
    );

    $this->assertTrue(isset($findings['routes_access_test.obscure1']));
    $this->assertStringContainsString(
      'Route uses _entity_access',
      $findings['routes_access_test.obscure1'],
    );

    $this->assertTrue(isset($findings['routes_access_test.obscure2']));
    $this->assertStringContainsString(
      'Route uses _custom_access',
      $findings['routes_access_test.obscure2'],
    );

  }

}
