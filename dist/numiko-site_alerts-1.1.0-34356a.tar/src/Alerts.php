<?php

namespace Drupal\site_alerts;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\NodeInterface;

/**
 * Alerts Service.
 */
class Alerts {

  const CONTENT_FIELD = 'field_content';

  const TERM_SECTION_FIELD = 'field_section';

  protected $alertStorage;

  protected $alertSettingsProvider;

  /**
   * Alerts constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entity_type_manager
   *   EntityTypeManagerInterface.
   *
   * @throws \Drupal\Component\Plugin\Exception\InvalidPluginDefinitionException
   * @throws \Drupal\Component\Plugin\Exception\PluginNotFoundException
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager, SettingsProvider $alertSettingsProvider) {
    $this->alertStorage = $entity_type_manager->getStorage('alert');
    $this->alertSettingsProvider = $alertSettingsProvider;
  }

  /**
   * Get site alerts.
   */
  public function getSiteAlerts() {
    return $this->alertStorage->loadByProperties([
      'status' => 1,
      'type' => 'site_alert',
    ]);
  }

  /**
   * Get section alerts.
   *
   * @param \Drupal\node\NodeInterface $node
   *   A node.
   *
   * @return array
   *   The alerts.
   *
   * @throws \Drupal\Core\TypedData\Exception\MissingDataException
   */
  public function getSectionAlerts(NodeInterface $node) {
    $section_alerts = [];
    if (
      $node->hasField($this->alertSettingsProvider->getSectionNodeField()) &&
      !$node->get($this->alertSettingsProvider->getSectionNodeField())->isEmpty()
    ) {
      $section = $node->get($this->alertSettingsProvider->getSectionNodeField())->first()->getValue();
      $alerts = $this->alertStorage->loadByProperties([
        'status' => 1,
        'type' => 'section_alert',
      ]);
      foreach ($alerts as $alert) {
        /** @var \Drupal\site_alerts\Entity\alert $alert */
        if (
          $alert->hasField(self::TERM_SECTION_FIELD) &&
          !$alert->get(self::TERM_SECTION_FIELD)->isEmpty()
        ) {
          $alert_section = $alert->get(self::TERM_SECTION_FIELD)->first()->getValue();
          if ($alert_section['target_id'] == $section['target_id']) {
            $section_alerts[] = $alert;
          }
        }
      }
    }
    return $section_alerts;
  }

  /**
   * Get content alerts.
   *
   * @param \Drupal\node\NodeInterface $node
   *   A node.
   *
   * @return array
   *   The alerts.
   */
  public function getContentAlerts(NodeInterface $node) {
    $content_alerts = [];
    $alerts = $this->alertStorage->loadByProperties([
      'status' => 1,
      'type' => 'content_alert',
    ]);
    foreach ($alerts as $alert) {
      if ($alert->hasField(self::CONTENT_FIELD) && !$alert->get(self::CONTENT_FIELD)
          ->isEmpty()) {
        foreach ($alert->get(self::CONTENT_FIELD)->getValue() as $content) {
          if ($content['target_id'] == $node->id()) {
            $content_alerts[] = $alert;
          }
        }
      }
    }

    return $content_alerts;
  }

  /**
   * Get all alerts.
   *
   * @param \Drupal\node\NodeInterface|null $node
   *   The node for which to get alerts if applicable.
   *
   * @return array
   *   Returns all alerts to display.
   *
   * @throws \Drupal\Core\TypedData\Exception\MissingDataException
   */
  public function getAllAlerts($node = NULL) {
    $allAlerts = [];
    $siteAlerts = $this->getSiteAlerts();
    if (!empty($siteAlerts)) {
      $allAlerts = array_merge($allAlerts, $siteAlerts);
    }

    if ($node) {
      $sectionAlerts = $this->getSectionAlerts($node);
      $contentAlerts = $this->getContentAlerts($node);
      if (!empty($sectionAlerts)) {
        $allAlerts = array_merge($allAlerts, $sectionAlerts);
      }
      if (!empty($contentAlerts)) {
        $allAlerts = array_merge($allAlerts, $contentAlerts);
      }
    }
    return $allAlerts;
  }

}
