<?php

namespace Drupal\sensible_email_validation;

use Drupal\Component\Utility\EmailValidatorInterface;
use Egulias\EmailValidator\EmailValidator;
use Egulias\EmailValidator\Validation\DNSCheckValidation;
use Egulias\EmailValidator\Validation\MultipleValidationWithAnd;
use Egulias\EmailValidator\Validation\RFCValidation;

class SensibleEmailValidator implements EmailValidatorInterface {

  /**
   * Use Drupal's default email validator, but add extra check for TLD.
   *
   * {@inheritdoc}
   */
  public function isValid($email, $checkDNS = FALSE, $strict = FALSE) {
    $validator = new EmailValidator();

    if (!$checkDNS) {
      $multipleValidations = new MultipleValidationWithAnd([
        new RFCValidation(),
        new TLDValidation(),
      ]);
      $validationResult = $validator->isValid($email, $multipleValidations);
    }
    else {
      $multipleValidations = new MultipleValidationWithAnd([
        new RFCValidation(),
        new TLDValidation(),
        new DNSCheckValidation(),
      ]);
      $validationResult = $validator->isValid($email, $multipleValidations);
    }

    if ($strict && $validator->hasWarnings()) {
      $validationResult = FALSE;
    }

    return $validationResult;

  }

}
