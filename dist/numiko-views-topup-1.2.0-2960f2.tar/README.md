# Views Top-up #

Add a Top-up display block to views - allowing you to top-up one view block from another.

## Why is this useful? ##

This would be useful in circumstances such as related content, where you want an editorial view block to be topped-up with results from a taxonomy view block.
