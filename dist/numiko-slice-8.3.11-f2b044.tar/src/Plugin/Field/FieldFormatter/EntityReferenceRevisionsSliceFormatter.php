<?php

namespace Drupal\slice\Plugin\Field\FieldFormatter;

use Drupal\Core\Entity\EntityDisplayRepositoryInterface;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\Core\Field\FieldItemListInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\entity_reference_revisions\Plugin\Field\FieldFormatter\EntityReferenceRevisionsEntityFormatter;

/**
 * Plugin implementation of the 'entity reference rendered slice' formatter.
 *
 * @FieldFormatter(
 *   id = "entity_reference_revisions_slice_view",
 *   label = @Translation("Rendered slice"),
 *   description = @Translation("Display the referenced slices rendered by entity_view()."),
 *   field_types = {
 *     "entity_reference_revisions"
 *   }
 * )
 */
class EntityReferenceRevisionsSliceFormatter extends EntityReferenceRevisionsEntityFormatter implements ContainerFactoryPluginInterface {

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $elements = parent::viewElements($items, $langcode);

    foreach ($elements as $delta => $element) {
      $this->addPreviousElementContext($elements, $delta);
      $this->addNextElementContext($elements, $delta);
      $this->addPositionContext($elements, $delta);
    }

    return $elements;
  }

  protected function addPreviousElementContext(&$elements, $delta) {
    if ($slice_bundle = $this->findElementBundle($elements, $delta - 1)) {
      $elements[$delta]['#attributes']['data-slice-context-prev'] = $slice_bundle;
      $this->addGroupElementContext($elements, $delta, $slice_bundle);
    } else {
      $elements[$delta]['#attributes']['data-slice-context-first'] = true;
      $this->addGroupElementContext($elements, $delta);
    }
  }

  protected function addGroupElementContext(&$elements, $delta, $previous_bundle='') {
    static $slice_group = 0;
    $current_bundle = $this->findElementBundle($elements, $delta);
    if ($previous_bundle != $current_bundle) {
      $slice_group ++;
    }
    $elements[$delta]['#attributes']['data-slice-context-group'] = $slice_group;
  }

  protected function addNextElementContext(&$elements, $delta) {
    if ($slice_bundle = $this->findElementBundle($elements, $delta + 1)) {
      $elements[$delta]['#attributes']['data-slice-context-next'] = $slice_bundle;
    } else {
      $elements[$delta]['#attributes']['data-slice-context-last'] = true;
    }
  }

  protected function findElementBundle($elements, $delta) {
    if (isset($elements[$delta])) {
      return $elements[$delta]['#slice']->bundle();
    }
    return false;
  }

  protected function addPositionContext(&$elements, $delta) {
    $elements[$delta]['#attributes']['data-slice-context-position'] = $delta + 1;
    if (($delta + 1) % 2 == 1) {
      $elements[$delta]['#attributes']['data-slice-context-odd'] = true;
    } else {
      $elements[$delta]['#attributes']['data-slice-context-even'] = true;
    }
  }

}