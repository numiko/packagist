<?php

namespace Drupal\slice_jump_links\Entity;

/**
 * @file
 * Contains a jump link entity.
 */

class JumpLink {

  protected $label;
  protected $anchor;

  public function setLabel($label) {
    $this->label = $label;
    return $this;
  }

  public function getLabel() {
    return $this->label;
  }

  public function setAnchor($anchor) {
    $this->anchor = $anchor;
    return $this;
  }

  public function getAnchor() {
    if (!$this->anchor) {
      return $this->getAnchorFromLabel();
    }
    return $this->anchor;
  }

  /**
   * Create a fallback anchor if one isn't specified.
   *
   * Using regex we will create a default anchor, replacing any amount
   * of spaces with a single hyphen and removing any non-alpha numeric
   * characters (except hyphens).
   *
   * @return string
   *   A fallback anchor created from the label.
   */
  protected function getAnchorFromLabel() {
    $label = $this->getLabel();
    return preg_replace('/[^\da-z\-]/i', '', preg_replace('#[ -]+#', '-', trim(strtolower($label))));
  }

  public function justAnchor() {
    if (!$this->label) {
      return TRUE;
    }
    return FALSE;
  }

  public function isEmpty() {
    if ($this->label || $this->anchor) {
      return FALSE;
    }
    return TRUE;
  }

}
