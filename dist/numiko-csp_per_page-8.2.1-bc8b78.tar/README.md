# CSP Per Page

Sets a strict Content Security Policy on certain pages. This allows tracking and other services on most pages on a site, but a strict CSP on pages such as login and payment pages.

Use the config to set paths and content types that need the strict policy (no interface for this yet).

## Config file syntax

```
strict_paths: "/user/*\n/payment\n/payment/3d*\n/payment/dd*\n"
```

Use the default strict CSP on these pages. The default CSP is the one defined in this file in the `strict_policy_*` directives. Set to `null` if none required.

```
strict_types: event,article
```

Use the default strict CSP on these node types. Set to `null` if none required.

```
strict_policy_default: '''none'''
strict_policy_script: '''self'''
strict_policy_img: '''self'''
strict_policy_style: '''self'''
strict_policy_font: '''self'''
```

These are the parts of the default strict CSP. Anything outwith these directives goes in:

```
strict_policy_additional: 'frame-src ''self'' *.sagepay.com'
```

Any additional parts to the CSP.

```
custom_paths: "/about-us"
```

Paths that use a custom CSP. The CSP for /about-us would be specified in a separate config file named `csp_per_page.custom.about_us.yml` (`[^a-z0-9_]` replaced by underscores in the path, first slash removed).

## Nonces

Use the NonceManager to generate nonces. During preprocessing, for example, use NonceManager::generateNonce() to obtain to nonce and insert it into your theme. It will then be output as part of the CSP.

## Tests

There are currently no unit tests. Highly recommend integration tests for individual sites that test the effect this module is having together with other modules.
