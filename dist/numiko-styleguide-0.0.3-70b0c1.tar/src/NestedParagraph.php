<?php

namespace Drupal\styleguide;

use Drupal\Core\Entity\EntityTypeManagerInterface;

/**
 * Allow the theme layer to access the content of paragraphs nested inside
 * other paragraphs.
 */
class NestedParagraph {

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * NestedParagraph constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager) {
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * Return render arrays for the given fields in a paragraph's sub items.
   *
   * Slices like accordions and carousels have "sub items" - paragraphs that
   * are nested in the main paragraph.
   *
   * This method can be used by a paragraph's preprocessor to cleanly get
   * render arrays for those fields, that are then passed to the Storybook
   * template via the theme template, allowing the Storybook component template
   * to be shared between Drupal and Storybook.
   *
   * @param array $fields
   *   The machine names of the fields to get.
   * @param array $items
   *   Array of sub items from the parent's content array e.g.
   *   $variables['content']['field_items'].
   *
   * @return array
   */
  function buildRenderArraysForNestedParagraphs(
    array $fields,
    array $items): array {
    $itemsForOutput = [];
    $builder = $this->entityTypeManager->getViewBuilder('paragraph');
    foreach ($items as $key => $subItem) {
      if (!is_numeric($key)) {
        continue;
      }
      $item = new \stdClass();
      foreach ($fields as $fieldName) {
        $shortFieldName = str_replace('field_', '', $fieldName);
        $item->$shortFieldName = $builder->viewField(
          $subItem['#paragraph']->get($fieldName),
          $subItem['#view_mode']
        );
      }
      $item->id = $subItem['#paragraph']->id();
      $itemsForOutput[] = $item;
    }
    return $itemsForOutput;
  }

}
