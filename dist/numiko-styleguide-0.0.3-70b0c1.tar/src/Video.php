<?php

namespace Drupal\styleguide;

use Drupal\media\Entity\Media;

/**
 * Provide video data to the theme layer.
 *
 * @todo this is just a tidying of the code that was previously in numiko.theme.
 * Will complete once full requirements are discussed with FE.
 */
class Video {

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Video constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   */
  public function __construct(\Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager) {
    $this->entityTypeManager = $entityTypeManager;
  }

  /**
   * Build data needed for gallery.
   *
   * @param \Drupal\media\Entity\Media $video
   *
   * @return array
   */
  public function buildGalleryItemData(Media $video) {
    return $this->getDataForGalleryModals($video);
  }

  /**
   * Get data that is used for gallery modals.
   *
   * @param \Drupal\media\Entity\Media $media
   *   The individual media video entity to get data for.
   *
   * @return array
   */
  protected function getDataForGalleryModals(Media $video) {
    $videoData = [
      "type" => $video->bundle(),
      "id" => $video->id(),
    ];

    $builder = $this->entityTypeManager->getViewBuilder('media');

    if ($video->hasField('name')) {
      $videoData['title'] = $builder->viewField($video->get('name'));
    }

    if ($video->hasField('field_media_oembed_video') &&
      !$video->get('field_media_oembed_video')->isEmpty()) {
      $videoData['video_file'] = $builder->viewField(
        $video->get('field_media_oembed_video')
      );
    }

    return $videoData;
  }

}
