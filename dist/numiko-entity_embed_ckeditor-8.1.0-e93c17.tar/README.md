# Entity Embed CKeditor #

This module allows an overriding view mode to be used when embedding entities within ckeditor.