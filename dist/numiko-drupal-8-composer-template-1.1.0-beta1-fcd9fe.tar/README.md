# Numiko Composer template for Drupal Project

This template is a fork of [Composer template for Drupal Projects](https://github.com/drupal-composer/drupal-project) with additional functionality specific to Numiko.

## Usage

### Create the project

```
composer create-project numiko/drupal-8-composer-template:8.x PROJECT_NAME --stability dev --no-interaction --repository-url=https://numiko.github.io/packagist
```

Where PROJECT_NAME is the folder to create the project in.

Our internal repository is at packages.numiko.local, but requires --no-secure-http to access.

### Point the domain

* Choose a domain (currently a \*.sites.numiko.local one), based on Numiko internal domain guidelines
* Setup the virtual host in Apache to accept the domain

### Install the site

* Go to the sites domain in browser and follow the steps to install
* Generating a secure password and adding the site name

## What does this template do

This template will:

* Drupal will be installed in the `web`-directory.
* Autoloader is implemented to use the generated composer autoloader in `vendor/autoload.php`,
  instead of the one provided by Drupal (`web/vendor/autoload.php`).
* Modules (packages of type `drupal-module`) will be placed in `web/modules/contrib/`
* Theme (packages of type `drupal-theme`) will be placed in `web/themes/contrib/`
* Profiles (packages of type `drupal-profile`) will be placed in `web/profiles/contrib/`
* Creates default writable versions of `settings.php` and `services.yml`.
* Creates `sites/default/files`-directory.
* Latest version of drush is installed locally for use at `vendor/bin/drush`.
* Latest version of DrupalConsole is installed locally for use at `vendor/bin/drupal`.
* Numiko install profiles added:
	* [Numiko Media](https://bitbucket.org/numiko/numiko-media-profile)
* All dependencies of install profiles placed in appropriate directories

These files will then be ready for you to point the web server at and run the install process (selecting the profile best suited to the projects requirements).

For more information see [the original docs](https://github.com/drupal-composer/drupal-project).

## Installing new modules

Once the site has been installed, adding new modules must be done with composer. From the root of the site (as the modules are being added to the main composer.json):

```
composer require drupal/modulename
```

See https://packagist.drupal-composer.org for modules.

## Known Issues

* Currently pathauto causes an error on the status page, there are a number of ways around this issue ([all of them ugly one-off hacks](https://www.drupal.org/node/2601762#comment-10835098)), hopefully this will be resolved soon.