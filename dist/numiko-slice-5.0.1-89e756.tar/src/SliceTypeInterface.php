<?php

namespace Drupal\slice;

use Drupal\paragraphs\ParagraphsTypeInterface;

/**
 * Provides an interface for defining Slice type entities.
 */
interface SliceTypeInterface extends ParagraphsTypeInterface {
  
}
