<?php

namespace Drupal\link_class\Plugin\Field\FieldFormatter;

use Drupal\link\Plugin\Field\FieldFormatter\LinkFormatter;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\link\LinkItemInterface;

/**
 * Plugin implementation of the 'link' formatter.
 *
 * @FieldFormatter(
 *   id = "link_class",
 *   label = @Translation("Link Class"),
 *   field_types = {
 *     "link"
 *   }
 * )
 */
class LinkClassFormatter extends LinkFormatter {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return [
      'link_classes' => "",
      'svg' => "",
    ] + parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function settingsForm(array $form, FormStateInterface $form_state) {
    $elements = parent::settingsForm($form, $form_state);

    $elements['link_classes'] = [
      '#type' => 'textfield',
      '#title' => t('Link class(es)'),
      '#default_value' => $this->getSetting('link_classes'),
      '#description' => t('Space seperated classes list.'),
    ];

    $elements['svg'] = [
      '#type' => 'textarea',
      '#title' => t('Icon'),
      '#default_value' => $this->getSetting('svg'),
      '#description' => t('Icon to insert into link.'),
    ];

    return $elements;
  }

  /**
   * {@inheritdoc}
   */
  public function settingsSummary() {
    $summary = parent::settingsSummary();

    $settings = $this->getSettings();

    if (!empty($settings['link_classes'])) {
      $summary[] = t('Link text with: @classes classes', ['@classes' => $settings['link_classes']]);
      $summary[] = t('SVG used: @svg', ['@svg' => $settings['svg']]);
    }

    return $summary;
  }

  /**
   * Builds the \Drupal\Core\Url object for a link field item.
   *
   * @param \Drupal\link\LinkItemInterface $item
   *   The link field item being rendered.
   *
   * @return \Drupal\Core\Url
   *   A Url object.
   */
  protected function buildUrl(LinkItemInterface $item) {

    $url = $item->getUrl() ?: Url::fromRoute('<none>');

    $settings = $this->getSettings();
    $options = $item->options;
    $options += $url->getOptions();

    // Add optional 'rel' attribute to link options.
    if (!empty($settings['rel'])) {
      $options['attributes']['rel'] = $settings['rel'];
    }
    // Add optional 'target' attribute to link options.
    if (!empty($settings['target'])) {
      $options['attributes']['target'] = $settings['target'];
    }
    // Add optional 'classes' attribute to link options.
    if (!empty($settings['link_classes'])) {
      $options['attributes']['class'] = $settings['link_classes'];
    }

    // Add optional 'svg' attribute to link options.
    if (!empty($settings['svg'])) {
      $options['svg'] = $settings['svg'];
    }

    $url->setOptions($options);

    return $url;
  }

}
