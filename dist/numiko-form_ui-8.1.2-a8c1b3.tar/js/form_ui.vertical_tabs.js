(function ($, Drupal, drupalSettings) {

    drupalSettings.widthBreakpoint = 1150;

})(jQuery, Drupal, drupalSettings);