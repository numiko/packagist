<?php

namespace Drupal\integration_tests;

/**
 * Provide useful assertions not available in phpunit.
 *
 * @package Drupal\integration_tests
 */
trait AssertTrait {

  /**
   * Asserts that one string appears before another in a container string.
   *
   * @param string $first
   *   The string that should appear first.
   * @param string $second
   *   The string that should appear second.
   * @param string $haystack
   *   The containing string.
   */
  public function assertAppearsBefore($first, $second, $haystack) {
    $whereFirst = strpos($haystack, $first);
    static::assertNotFalse($whereFirst, 'First string is missing');
    $whereSecond = strpos($haystack, $second);
    static::assertNotFalse($whereSecond, 'Second string is missing');
    static::assertLessThan($whereSecond, $whereFirst, 'First string is after second');
  }

  /**
   * Assert the value of querystring at the current URL.
   *
   * Mink's addressEquals() strips the querystring so we need this instead.
   *
   * @param $expected
   */
  protected function assertQuerystring($expected) {
    $url = parse_url($this->getSession()->getCurrentUrl());
    if (empty($url['query']) && $expected) {
      $this->fail('Wrong query string');
    }
    return isset($url['query']) && $this->assertEquals($expected, $url['query']);
  }

  /**
   * Test the given user can edit content.
   *
   * @param $content_type
   *   The content type.
   * @param $status_code
   *   The status code to check.
   */
  protected function assertViewUnpublishedContentTypeReturnsStatusCode(string $content_type, int $status_code) {
    $node = $this->createNode(['type' => $content_type]);
    $this->visitCheckCode('node/' . $node->id(), $status_code);
  }

  /**
   * Test the given user can add content.
   *
   * @param $content_type
   *   The content type.
   * @param $status_code
   *   The status code to check.
   */
  protected function assertAddContentTypeReturnsStatusCode(string $content_type, int $status_code) {
    $this->visitCheckCode('node/add/' . $content_type, $status_code);
  }

  /**
   * Test the given user can edit content.
   *
   * @param $content_type
   *   The content type.
   * @param $status_code
   *   The status code to check.
   */
  protected function assertEditContentTypeReturnsStatusCode(string $content_type, int $status_code) {
    $node = $this->createPublishedNode(['type' => $content_type]);
    $this->visitCheckCode('node/' . $node->id() . '/edit', $status_code);
  }

  /**
   * Test the given user can delete content.
   *
   * @param $content_type
   *   The content type.
   * @param $status_code
   *   The status code to check.
   */
  protected function assertDeleteContentTypeReturnsStatusCode(string $content_type, int $status_code) {
    $node = $this->createPublishedNode(['type' => $content_type]);
    $this->visitCheckCode('node/' . $node->id() . '/delete', $status_code);
  }

  /**
   * Test the given user can add media.
   *
   * @param $media_type
   *   The media type.
   * @param $status_code
   *   The status code to check.
   */
  protected function assertAddMediaTypeReturnsStatusCode(string $media_type, int $status_code) {
    $this->visitCheckCode('media/add/' . $media_type, $status_code);
  }

  /**
   * Test the given user can edit media.
   *
   * @param $media_type
   *   The media type.
   * @param $status_code
   *   The status code to check.
   */
  protected function assertEditMediaTypeReturnsStatusCode(string $media_type, int $status_code) {
    $media = $this->createMedia(['bundle' => $media_type]);
    $this->visitCheckCode('media/' . $media->id() . '/edit', $status_code);
  }

  /**
   * Test the given user can delete media.
   *
   * @param $media_type
   *   The media type.
   * @param $status_code
   *   The status code to check.
   */
  protected function assertDeleteMediaTypeReturnsStatusCode(string $media_type, int $status_code) {
    $media = $this->createMedia(['bundle' => $media_type]);
    $this->visitCheckCode('media/' . $media->id() . '/delete', $status_code);
  }

  /**
   * Test the given user can delete media.
   *
   * @param $state
   *   The state to check.
   * @param $settings
   *   The node settings.
   */
  protected function assertCanUseTransition(string $state, array $settings = []) {
    $node = $this->createNode($settings);
    $this->drupalGet('node/' . $node->id() . '/edit');
    $this->assertStateShowingInModerationDropdown($state);
  }

  /**
   * Check that certain moderation state is showing in the moderation dropdown.
   *
   * @param string $state
   *   The state machine name.
   */
  protected function assertStateShowingInModerationDropdown(string $state) {
    $moderationStateDropdown = $this->getCurrentPage()->find('css', '#edit-moderation-state-0-state');
    $this->assertNotNull(
      $moderationStateDropdown,
      'Missing moderation state dropdown'
    );
    $this->assertNotNull(
      $moderationStateDropdown->find('named', ['option', $state]),
      $state . ' option not found'
    );
  }

  /**
   * Check that certain moderation state is showing in the moderation dropdown.
   *
   * @param string $state
   *   The state machine name.
   */
  protected function assertStateNotShowingInModerationDropdown(string $state) {
    $moderationStateDropdown = $this->getCurrentPage()->find('css', '#edit-moderation-state-0-state');
    $this->assertNotNull(
      $moderationStateDropdown,
      'Missing moderation state dropdown'
    );
    $this->assertNull(
      $moderationStateDropdown->find('named', ['option', $state]),
      $state . ' option not found'
    );
  }

  /**
   * Convenience function to visit URL and assert status code in one.
   *
   * @param $url
   * @param $expected_status_code
   */
  protected function visitCheckCode($url, $expected_status_code) {
    $this->drupalGet($url);
    $this->assertSession()->statusCodeEquals($expected_status_code);
  }

}
