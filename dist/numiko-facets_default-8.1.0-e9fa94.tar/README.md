# Facets Default #

A facet processor to set an active facet by default. This can be either specified as a value or token.