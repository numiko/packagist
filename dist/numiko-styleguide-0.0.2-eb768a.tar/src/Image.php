<?php

namespace Drupal\styleguide;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Image\ImageFactory;
use Drupal\media\Entity\Media;

/**
 * Provide image data to theme layer.
 */
class Image {

  /**
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * @var \Drupal\Core\Image\ImageFactory
   */
  protected $imageFactory;

  /**
   * @var string
   */
  protected $galleryImageStyle;

  /**
   * Image constructor.
   *
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   * @param \Drupal\Core\Image\ImageFactory $imageFactory
   */
  public function __construct(EntityTypeManagerInterface $entityTypeManager, ImageFactory $imageFactory) {
    $this->entityTypeManager = $entityTypeManager;
    $this->imageFactory = $imageFactory;
  }

  /**
   * @return string
   */
  public function getGalleryImageStyle(): ?string {
    return $this->galleryImageStyle;
  }

  /**
   * @param string $galleryImageStyle
   */
  public function setGalleryImageStyle(string $galleryImageStyle): void {
    $this->galleryImageStyle = $galleryImageStyle;
  }

  /**
   * Build data needed for gallery.
   *
   * @param \Drupal\media\Entity\Media $media
   *
   * @return array
   */
  public function buildGalleryItemData(Media $media): array {
    return $this->getDataForGalleryModals(
      $media, $this->galleryImageStyle
    );
  }

  /**
   * Get data that is used for gallery modals.
   *
   * @param \Drupal\media\Entity\Media $media
   *   The individual media image to get data for.
   * @param string $imageStyle
   *   The name of the image style this image is being displayed as.
   *
   * @return array
   */
  protected function getDataForGalleryModals(Media $media, string $imageStyle) {
    $imageData = [
      "type" => $media->bundle(),
      "id" => $media->id(),
    ];

    $builder = $this->entityTypeManager->getViewBuilder('media');

    if ($media->hasField('name')) {
      $imageData['title'] = $builder->viewField($media->get('name'));
    }

    if ($media->hasField('field_image') && !$media->get('field_image')->isEmpty()) {
      $fileUri = $media->get('field_image')->first()->entity->getFileUri();
      if ($fileUri) {
        $imageData['image_src'] = $this->entityTypeManager
          ->getStorage('image_style')
          ->load($imageStyle)
          ->buildUrl($fileUri);
        $imageData['image_alt'] = $media->get('field_image')
          ->first()
          ->getValue()['alt'];
        $dimensions = $this->getMediaDimensions($fileUri, $imageStyle);
        $imageData['image_width'] = $dimensions['width'];
        $imageData['image_height'] =  $dimensions['height'];
        $imageData['image_aspect_ratio'] =  $dimensions['aspect_ratio'];
      }
    }

    if ($media->hasField('field_caption')) {
      $imageData['caption'] = $builder->viewField($media->get('field_caption'));
    }

    return $imageData;
  }

  /**
   * Get dimensions of image once processed by image style.
   *
   * @param string $fileUri
   *   URI of file to get dimensions of.
   * @param string $imageStyle
   *   Name of the image style.
   * @return array
   */
  protected function getMediaDimensions(string $fileUri, string $imageStyle) {
    $imageStyle = $this->entityTypeManager
      ->getStorage('image_style')
      ->load($imageStyle);

    $buildUri = $imageStyle->buildUri($fileUri);
    // Preload image style for display in the modal.
    //
    // The data we need won't be available if the derivative image hasn't been
    // generated yet. See this commit and accompanying ticket:
    // https://bitbucket.org/numiko/ravensbourne-university/commits/e4b67be1ead6c90e1cd5a15be9e89828167d9ab5
    if (!file_exists($buildUri)) {
      $imageStyle->createDerivative($fileUri, $buildUri);
    }

    $imageFactory = $this->imageFactory->get($buildUri);
    $imageHeight = $imageFactory->getToolkit()->getHeight();
    $imageWidth = $imageFactory->getToolkit()->getWidth();

    return [
      "height" => $imageHeight,
      "width" => $imageWidth,
      "aspect_ratio" => $imageHeight / $imageWidth * 100 . "%",
    ];
  }

}
