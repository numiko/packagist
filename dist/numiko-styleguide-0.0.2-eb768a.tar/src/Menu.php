<?php

namespace Drupal\styleguide;

/**
 * Allow theme layer to access menu easily.
 */
class Menu {

  /**
   * Build an array of menu data from preprocessor data.
   *
   * We already have the data we want in the preprocessor variables
   * array. This just extracts it so it's usable by the templates.
   *
   * @param array $variables
   *
   * @return array
   */
  public function generateDataFromMenuBlock(array $variables) {
    $menuStructure = $variables['content']['#items'];
    return $this->buildMenu($menuStructure);
  }

  /**
   * Recursively extract minimal data needed for menu structure.
   *
   * @param array $menuStructure
   *  Menu array from a content array.
   *
   * @return array
   */
  public function buildMenu(array $menuStructure) {
    $menuForOutput = [];
    foreach ($menuStructure as $menuItem) {
      $menuItemForOutput = [
        'title' => $menuItem['title'],
        // The #cache data for the menu isn't stored in the link,
        // so this is acceptable.
        'url' => $menuItem['url']->toString(),
        'below' => $this->buildMenu($menuItem['below']),
      ];
      $menuForOutput[] = $menuItemForOutput;
    }
    return $menuForOutput;
  }
}
