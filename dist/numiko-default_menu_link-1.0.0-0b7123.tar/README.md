# Default Menu Link

Add the ability to tick "Provide a menu link" by default on a content type by content type basis.

## Usage

On a content type go to 'Edit' and to the 'Default Menu Settings' vertical tab, then select the 'Pre-select...' radio button.