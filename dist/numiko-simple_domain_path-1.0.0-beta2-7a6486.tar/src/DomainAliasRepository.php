<?php

namespace Drupal\simple_domain_path;

use Drupal\domain\DomainNegotiatorInterface;
use Drupal\path_alias\AliasRepository as AliasRepositoryAlias;

/**
 * Provides Domain-aware path alias lookup operations.
 */
class DomainAliasRepository extends AliasRepositoryAlias {

  /**
   * @var DomainNegotiatorInterface
   */
  protected $domainNegotiator;

  /**
   * @return \Drupal\domain\DomainNegotiatorInterface
   */
  public function getDomainNegotiator() {
    return $this->domainNegotiator;
  }

  /**
   * @param \Drupal\domain\DomainNegotiatorInterface $domainNegotiator
   */
  public function setDomainNegotiator($domainNegotiator) {
    $this->domainNegotiator = $domainNegotiator;
  }

  /**
   * Returns a SELECT query for the path_alias base table.
   *
   * @return \Drupal\Core\Database\Query\SelectInterface
   *   A Select query object.
   */
  protected function getBaseQuery() {
    $query = $this->connection->select('path_alias', 'base_table');

    $activeDomain = $this->domainNegotiator->getActiveDomain();
    if ($activeDomain) {
      $query->condition('base_table.domain', $activeDomain->id());
    }

    return $query;
  }

}
