<?php

namespace Drupal\integration_tests\Functional;

/**
 * A test that can be used to diagnose problems with the integration tests.
 *
 * This method of testing has been brittle and there is a lot that can go wrong.
 * Running this test may help to diagnose precisely what is wrong in a way that
 * normal tests won't show clearly.
 *
 * It may be useful to run this before trying to add new tests.
 *
 * @group diagnose
 */
class TestDiagnosisTest extends IntegrationTestBase {

  protected $testUser;

  function setUp(): void {
    parent::setUp();
    $this->createTestData();
  }

  protected function createTestData() {
    $this->testUser = $this->createUserWithPersonas([
      'editor',
      'publisher',
    ]);
  }

  public function testAdminLogin() {
    $this->attemptDrupalLogin($this->testUser);
    $this->drupalGet('admin/content');
    $this->assertSession()->statusCodeEquals(200);
  }

}
