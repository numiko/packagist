This module allows the same path to be used across different domains when the domain module is in use.

See discussion at https://www.drupal.org/node/2821633

Module created with patch from Drupal 7 dev version with patch from here: https://www.drupal.org/files/issues/domain_path_d8_2821633_1.patch.

Then patch ./unsigned_domain_id_field.patch applied.