<?php

namespace Drupal\slice\Factory;

use Drupal\slice\Entity\Slice;
use Drupal\slice\Entity\SliceType;

class SliceAdminLabelFactory {

  const ADMIN_LABEL_VIEW_MODE = 'admin_label';

  public static function generate(Slice $slice) {
    $sliceType = SliceType::load($slice->bundle());
    $adminLabelField = ($sliceType->adminlabelfield()) ?: SliceType::DEFAULT_ADMIN_LABEL_FIELD;

    switch ($adminLabelField) {
      case 'name':
        return $slice->getName();
        break;
      case 'id':
        return $slice->id();
        break;
      default:
        $fieldView = $slice->{$adminLabelField}->view(self::ADMIN_LABEL_VIEW_MODE);
        return drupal_render($fieldView);
        break;
    }
  }

}
