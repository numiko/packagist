<?php

namespace Drupal\Tests\domain_access_blocking\Functional;

use Drupal\Core\Url;
use Drupal\Tests\domain\Functional\DomainTestBase;

/**
 * Test ability of users to log in to only domain they are assigned to.
 *
 * In order to log in using built-in Domain module code ($this->domainLogin()),
 * this class needs to inherit from the Simpletest version of DomainTestsBase.
 *
 * @group DomainAccessBlocking
 */
class DomainAccessBlockingTest extends DomainTestBase {

  public static $modules = array('domain_access', 'node', 'domain_access_blocking');

  private $testDomains = [];

  protected function setUp() {
    parent::setUp();
    $this->domainCreateTestDomains(3, 'smg.local', [
      '', // always the "base" domain
      '4.msi',
      '4.sci'
    ]);
    $testDomains = \Drupal::service('domain.loader')->loadMultiple();
    // Store the 2 Domains
    foreach ($testDomains as $domain) {
      if ($domain->getHostname() != 'smg.local') {
        $this->testDomains[] = $domain;
      }
    }
  }

  public function testCorrectDomainUser() {
    $domain_user1 = $this->drupalCreateUser([
      // only so that we can test browsing to somewhere useful once logged in
      'access content overview'
    ]);
    $this->addDomainsToEntity(
      'user',
      $domain_user1->id(),
      [$this->testDomains[0]->id()],
      DOMAIN_ACCESS_FIELD
    );
    $this->assertTrue($this->domainLogin($this->testDomains[0], $domain_user1));
    $this->assertSession()->statusCodeEquals(200);
    $this->drupalGet('admin/content');
    $this->assertSession()->statusCodeEquals(200);
  }

  public function testUserWithNoDomain() {
    // Test that user is blocked from domains they are not assigned to
    $no_domain_user = $this->drupalCreateUser([
      'access content overview'
    ]);
    $this->assertTrue($this->domainLogin($this->testDomains[0], $no_domain_user));
    $this->assertSession()->statusCodeEquals(403);
    $this->drupalGet('admin/content');
    $this->assertSession()->statusCodeEquals(403);
    $this->assertTrue($this->domainLogin($this->testDomains[1], $no_domain_user));
    $this->assertSession()->statusCodeEquals(403);
    $this->drupalGet('admin/content');
    $this->assertSession()->statusCodeEquals(403);
  }

  public function testUserWithWrongDomain() {
    $other_domain_user = $this->drupalCreateUser([
      'access content overview'
    ]);
    $this->addDomainsToEntity(
      'user',
      $other_domain_user->id(),
      [$this->testDomains[0]->id()],
      DOMAIN_ACCESS_FIELD
    );
    $this->assertTrue($this->domainLogin($this->testDomains[1], $other_domain_user));
    $this->assertSession()->statusCodeEquals(403);
    $this->drupalGet('/admin/content');
    $this->assertSession()->statusCodeEquals(403);
  }

}