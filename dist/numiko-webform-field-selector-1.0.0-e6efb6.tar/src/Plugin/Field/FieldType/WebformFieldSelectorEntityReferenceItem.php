<?php

namespace Drupal\webform_field_selector\Plugin\Field\FieldType;

use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\FieldStorageDefinitionInterface;
use Drupal\Core\TypedData\DataDefinition;
use Drupal\webform\Plugin\Field\FieldType\WebformEntityReferenceItem;
use Drupal\Core\TypedData\MapDataDefinition;


/**
 * Defines the 'webform_entity_reference' entity field type.
 *
 * Extends EntityReferenceItem and only support targeting webform entities.
 *
 * @FieldType(
 *   id = "webform_optional_fields",
 *   label = @Translation("Webform with optional fields"),
 *   description = @Translation("A webform containing default submission values."),
 *   category = @Translation("Reference"),
 *   default_widget = "webform_entity_reference_select",
 *   default_formatter = "webform_entity_reference_entity_view",
 *   list_class = "\Drupal\webform\Plugin\Field\FieldType\WebformEntityReferenceFieldItemList",
 * )
 */
class WebFormFieldSelectorEntityReferenceItem extends WebformEntityReferenceItem {
  
  /**
   * {@inheritdoc}
   */
  public static function schema(FieldStorageDefinitionInterface $field_definition) {
    $schema = parent::schema($field_definition);
    
    $schema['columns']['optional_field_switch'] = [
      'description' => 'Switches optional field on and off',
      'type' => 'blob',
      'size' => 'big',
      'serialize' => TRUE,
    ];

    return $schema;
  }

  /**
   * {@inheritdoc}
   */
  public static function propertyDefinitions(FieldStorageDefinitionInterface $field_definition) {
    $properties = parent::propertyDefinitions($field_definition);

    $properties['optional_field_switch'] = MapDataDefinition::create()
      ->setLabel(t('Default optional field data'));

    return $properties;
  }
 
}
