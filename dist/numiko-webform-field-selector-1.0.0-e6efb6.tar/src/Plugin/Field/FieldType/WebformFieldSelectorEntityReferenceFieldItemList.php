<?php

namespace Drupal\webform_field_selector\Plugin\Field\FieldType;

use Drupal\webform\Plugin\Field\FieldType\WebformEntityReferenceFieldItemList;


/**
 * Defines a item list class for webform entity reference fields.
 */
class WebformFieldSelectorEntityReferenceFieldItemList extends WebformEntityReferenceFieldItemList {

}
