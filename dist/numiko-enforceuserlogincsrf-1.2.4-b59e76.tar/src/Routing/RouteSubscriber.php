<?php

namespace Drupal\enforceuserlogincsrf\Routing;

use Drupal\Core\Routing\RouteSubscriberBase;
use Symfony\Component\Routing\RouteCollection;

/**
 * Listens to the dynamic route events.
 */
class RouteSubscriber extends RouteSubscriberBase {

  /**
   * {@inheritdoc}
   */
  protected function alterRoutes(RouteCollection $collection) {
    if ($route = $collection->get('user.login')) {
      $defaults = $route->getDefaults();
      $defaults['_form'] = '\Drupal\enforceuserlogincsrf\Form\UserLoginForm';
      $route->setDefaults($defaults);
      $options = $route->getOptions();
      $options['no_cache'] = 'TRUE';
      $route->setOptions($options);
    }
    if ($route = $collection->get('user.password')) {
      $defaults = $route->getDefaults();
      $defaults['_form'] = '\Drupal\enforceuserlogincsrf\Form\UserPasswordForm';
      $route->setDefaults($defaults);
      $options = $route->getOptions();
      $options['no_cache'] = 'TRUE';
      $route->setOptions($options);
    }
  }

}
