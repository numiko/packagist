<?php

namespace Drupal\taxonomy_slice\Slice;

use Drupal\Core\Entity\EntityFieldManager;
use Drupal\Core\Extension\ModuleHandler;
use Drupal\Core\Field\FieldDefinitionInterface;
use Drupal\paragraphs\ParagraphInterface;

/**
 * Handle a taxonomy slice.
 */
class TaxonomySlice {

  /**
   * The entity field manager.
   *
   * @var Drupal\Core\Entity\EntityFieldManager
   */
  protected $entityFieldManager;

  /**
   * The module handler extension.
   *
   * @var Drupal\Core\Extension\ModuleHandler
   */
  protected $moduleHandler;

  /**
   * Construct a Taxonomy Slice Object.
   *
   * @param Drupal\Core\Entity\EntityFieldManager $entityFieldManager
   *   The entity field manager.
   */
  public function __construct(EntityFieldManager $entityFieldManager, ModuleHandler $moduleHandler) {
    $this->entityFieldManager = $entityFieldManager;
    $this->moduleHandler = $moduleHandler;
  }

  /**
   * Map the arguments from the slice to the view contained within.
   *
   * @param Drupal\paragraphs\ParagraphInterface $slice
   *   The slice containing the view.
   */
  public function mapArgumentsToView(ParagraphInterface $slice) {
    $isTaxonomySlice = FALSE;
    $bundleFields = $this->getBundleFields($slice->bundle());
    $view = $this->getView($slice, $bundleFields);
    if ($view) {
      $arguments = $this->getTaxonomyArguments($slice, $bundleFields);
      if ($arguments) {
        $view->getExecutable()->setArguments($arguments);
        $isTaxonomySlice = TRUE;
      }
      $numberOfItems = $this->getNumberOfItems($slice, $bundleFields);
      if ($numberOfItems) {
        $styleSettings = $view->getExecutable()->getDisplay()->getOption('style');
        $styleSettings['options']['columns'] = $numberOfItems;
        $view->getExecutable()->getDisplay()->overrideOption('style', $styleSettings);
        $view->getExecutable()->setItemsPerPage($numberOfItems);
        $isTaxonomySlice = TRUE;
      }
      if ($isTaxonomySlice) {
        $context = [
          'paragraph' => $slice,
          'arguments' => $arguments,
          'number_of_items' => $numberOfItems,
          'fields' => $bundleFields,
        ];
        $this->moduleHandler->alter('taxonomy_slice', $view, $context);
      }
    }
  }

  /**
   * Get all field definitions for a given bundle.
   *
   * Get all field definitions excluding base field definitions.
   *
   * @param string $bundle
   *   The bundle to lookup field definitions for.
   *
   * @return array
   *   Field definitions excluding base field definitions indexed by type.
   */
  protected function getBundleFields(string $bundle) {
    $allBundleFields = $this->entityFieldManager->getFieldDefinitions('paragraph', $bundle);
    foreach (array_filter($allBundleFields, [$this, 'isNotBaseField']) as $field) {
      $fieldStorage = $field->getFieldStorageDefinition();
      $bundleFields[$fieldStorage->getType()][$fieldStorage->getName()] = $fieldStorage;
    }
    return $bundleFields;
  }

  /**
   * Is the field not a base field.
   *
   * @param Drupal\Core\Field\FieldDefinitionInterface $field
   *   The field definition to query.
   *
   * @return bool
   *   Is the field a base field.
   */
  protected function isNotBaseField(FieldDefinitionInterface $field) {
    return !$field->getFieldStorageDefinition()->isBaseField();
  }

  /**
   * Get the view being used in this taxonomy slice.
   *
   * @param Drupal\paragraphs\ParagraphInterface $slice
   *   The taxonomy slice.
   * @param array $bundleFields
   *   The list of fields from the bundle.
   *
   * @return Drupal\views\Entity\View
   *   The view being used in this taxonomy slice.
   */
  protected function getView(ParagraphInterface $slice, array $bundleFields) {
    if (!isset($bundleFields['view_display_reference_item'])) {
      return NULL;
    }
    foreach ($bundleFields['view_display_reference_item'] as $fieldName => $fieldStorage) {
      if (!$slice->get($fieldName)->isEmpty()) {
        return $slice->get($fieldName)->first()->getValue()['entity'];
      }
    }
  }

  /**
   * Get the taxonomy values from all fields on the slice.
   *
   * @param Drupal\paragraphs\ParagraphInterface $slice
   *   The slice to etract the taxonomy from.
   * @param array $bundleFields
   *   The list of fields from the bundle.
   *
   * @return array
   *   An array of taxonomy arguments.
   */
  protected function getTaxonomyArguments(ParagraphInterface $slice, array $bundleFields) {
    $args = [];
    if (!isset($bundleFields['entity_reference'])) {
      return [];
    }
    foreach ($bundleFields['entity_reference'] as $fieldName => $fieldStorage) {
      if ($fieldStorage->getSetting('target_type') === 'taxonomy_term') {
        if (!$slice->get($fieldName)->isEmpty()) {
          $terms = [];
          foreach ($slice->get($fieldName) as $field) {
            $terms[] = $field->getString();
          }
          $args[] = implode('+', $terms);
        }
      }
    }
    return $args;
  }

  /**
   * Get the number of items from a list integer field.
   *
   * @param Drupal\paragraphs\ParagraphInterface $slice
   *   The slice containing the integer field with the number of items selected.
   * @param array $bundleFields
   *   The list of fields from the bundle.
   *
   * @return int
   *   The number of items to display.
   */
  protected function getNumberOfItems(ParagraphInterface $slice, array $bundleFields) {
    if (!isset($bundleFields['list_integer'])) {
      return NULL;
    }
    foreach ($bundleFields['list_integer'] as $fieldName => $fieldStorage) {
      if (!$slice->get($fieldName)->isEmpty()) {
        return $slice->get($fieldName)->first()->getString();
      }
    }
  }

}
