<?php

namespace Drupal\link_template_formatter\Plugin\Field\FieldFormatter;

use Drupal\link\Plugin\Field\FieldFormatter\LinkSeparateFormatter;
use Drupal\Component\Utility\Unicode;
use Drupal\Core\Field\FieldItemListInterface;

/**
 * Plugin implementation of the 'link_template' formatter.
 *
 * @FieldFormatter(
 *   id = "link_template",
 *   label = @Translation("Link Template"),
 *   field_types = {
 *     "link"
 *   }
 * )
 */
class LinkTemplateFormatter extends LinkSeparateFormatter {

  /**
   * {@inheritdoc}
   */
  public static function defaultSettings() {
    return parent::defaultSettings();
  }

  /**
   * {@inheritdoc}
   */
  public function viewElements(FieldItemListInterface $items, $langcode) {
    $elements = parent::viewElements($items, $langcode);
    foreach ($elements as &$element) {
      $element['#theme'] = 'link_link';
    }
    return $elements;
  }

}
