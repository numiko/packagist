## Background: 

A Drupal 8 version of the `domain_path` module that was created from a patch submitted on drupal.org, with some additions by Numiko, has been in use on SMG. With Drupal 8.8 changing aliases to be entities, this module no longer works. We've tried the latest version of `domain_path` (which differs significantly from the old patch), but have had various problems e.g.

[Fundamental problem with module overcome by enabled domain_config](https://www.drupal.org/project/domain_path/issues/3048553)

[My report of a bug traced back to parts of Drupal core not accessing domain aliases but instead using core ones](https://www.drupal.org/project/domain_path/issues/3166033). I've tried but I don't see how this can be fixed with Drupal core as it is.

This module is a version of `domain_path` that does only what we need. It does not allow nodes to exist on more than one domain, significantly reducing the complexity required.

This modules allows an path alias entity to apply to one specific domain if the alias is for a node entitiy. Path alias entities apply globally (across all domains) for all other entity types.

## Installation:

This module can be enabled in an environment both with domain_path enabled and without domain_path enabled.

Enable this module. domain_path should not be disabled until the migration step is complete.

Follow the next two steps below.

### 1. Migrating Aliases

This will:
* Port domain_path entities to path alias entities
* Port existing path alias entities to the new schema

The migration works from a state both with or without domain_path having been installed previously.

**Always back up the database before running this migration and test on a non-production environment first.**

Run the migration by using the command:

`drush add-domain-to-aliases`

or  

`drush ad2a`

Once this is complete, you should uninstall domain_path if currently enabled.

Continue onto the next step to test and validate all aliases are still functional.

### 2. Testing / Validation Process 

This validation process will attempt to request each alias from the domain set in the migration process.

The responses' status codes or exceptions are recorded and printed in a validation summary for each table validated.

From the summary, conclusions must be made as to whether the aliases that recorded non-200 status codes should be
be considered erroneous through manual testing, taking into account both the published state of that alias' node,
authentication required to view that alias' node and its Rabbit Hole settings (if the rabbit hole module is enabled).

Run the validation process by using the command:

`drush validate-path-aliases`

or  

`drush vpa`