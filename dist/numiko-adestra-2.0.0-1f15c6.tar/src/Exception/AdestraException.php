<?php

namespace Drupal\adestra\Exception;

use \Exception;

/**
 * A base exception thrown in any adestra exception.
 */
class AdestraException extends Exception {

}
