<?php

namespace Drupal\adestra\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\DependencyInjection\ContainerInjectionInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\adestra\Client\AdestraList;

/**
 * Provides route responses for webform.
 */
class AdestraListController extends ControllerBase implements ContainerInjectionInterface {

  /**
   * The adestra list.
   *
   * @var \Drupal\adestra\Client\AdestraList
   */
  protected $adestraList;

  /**
   * Constructs a AdestraListController object.
   */
  public function __construct(AdestraList $adestra_list) {
    $this->adestraList = $adestra_list;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('adestra.list')
    );
  }

  /**
   * Get a list of lists.
   */
  public function all() {
    return [
      '#theme' => 'item_list',
      '#items' => $this->getListOptions(),
    ];
  }

  /**
   * Get the list options.
   */
  private function getListOptions() {
    $options = [];
    $i = 1;
    $maxNumberOfResultsPages = 6;
    do {
      $resultsFound = FALSE;
      $listData = $this->adestraList->all(['page' => $i]);
      if (!empty($listData)) {
        $resultsFound = TRUE;
        foreach ($listData as $list) {
          $options[$list['id']] = "{$list['name']} ({$list['id']})";
        }
      }
      if ($i > $maxNumberOfResultsPages) {
        break;
      }
      $i++;
    } while ($resultsFound);

    natcasesort($options);

    return $options;
  }

}
