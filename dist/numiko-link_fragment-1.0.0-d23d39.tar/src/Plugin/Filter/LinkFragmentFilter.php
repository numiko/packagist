<?php

namespace Drupal\link_fragment\Plugin\Filter;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Component\Utility\Html;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Drupal\filter\FilterProcessResult;
use Drupal\filter\Plugin\FilterBase;

/**
 * Provides a Link Fragment filter.
 *
 * Note this must run before any Xss::filter() calls, because that strips
 * disallowed protocols. That effectively means this must run before the
 * \Drupal\filter\Plugin\Filter\FilterHtml filter. Hence the very low weight.
 *
 * @Filter(
 *   id = "link_fragment",
 *   title = @Translation("Link fragment filter"),
 *   description = @Translation("Append the url fragment to a link."),
 *   type = Drupal\filter\Plugin\FilterInterface::TYPE_TRANSFORM_REVERSIBLE,
 *   weight = -10,
 * )
 */
class LinkFragmentFilter extends FilterBase implements ContainerFactoryPluginInterface {


  /**
   * Constructs a LinkFragmentFilter object.
   *
   * @param array $configuration
   *   A configuration array containing information about the plugin instance.
   * @param string $plugin_id
   *   The plugin_id for the plugin instance.
   * @param mixed $plugin_definition
   *   The plugin implementation definition.
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition
    );
  }

  /**
   * {@inheritdoc}
   */
  public function process($text, $langcode) {
    $result = new FilterProcessResult($text);

    if (strpos($text, 'href') !== FALSE) {
      $dom = Html::load($text);
      $xpath = new \DOMXPath($dom);

      foreach ($xpath->query('//a[@data-fragment]') as $element) {
        /** @var \DOMElement $element */
        try {

          // Load the fragment.
          $fragment = $element->getAttribute('data-fragment');
          $href = $element->getAttribute('href');
          $element->setAttribute('href', $href . '#' . $fragment);
        }
        catch (\Exception $e) {
          watchdog_exception('linkfragment_filter', $e);
        }
      }

      $result->setProcessedText(Html::serialize($dom));
    }

    return $result;
  }

}
