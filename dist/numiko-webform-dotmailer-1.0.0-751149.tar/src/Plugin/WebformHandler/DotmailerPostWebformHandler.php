<?php

namespace Drupal\webform_dotmailer\Plugin\WebformHandler;

use Drupal\webform\Plugin\WebformHandler\RemotePostWebformHandler;
use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Logger\LoggerChannelFactoryInterface;
use Drupal\Core\Extension\ModuleHandlerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\FormStateInterface;
use Drupal\webform\WebformSubmissionConditionsValidatorInterface;
use Drupal\webform\WebformSubmissionInterface;
use Drupal\webform\WebformTokenManagerInterface;
use GuzzleHttp\ClientInterface;
use Drupal\Core\Serialization\Yaml;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\webform_dotmailer\Client\DotmailerClient;

/**
 * Webform submission remote post handler to Dotmailer.
 *
 * @WebformHandler(
 *   id = "dotmailer_post",
 *   label = @Translation("Dotmailer post"),
 *   category = @Translation("External"),
 *   description = @Translation("Posts webform submissions to a Dotmailer URL."),
 *   cardinality = \Drupal\webform\Plugin\WebformHandlerInterface::CARDINALITY_UNLIMITED,
 *   results = \Drupal\webform\Plugin\WebformHandlerInterface::RESULTS_PROCESSED,
 *   submission = \Drupal\webform\Plugin\WebformHandlerInterface::SUBMISSION_OPTIONAL,
 * )
 */
class DotmailerPostWebformHandler extends RemotePostWebformHandler {

  const DEFAULT_COMPLETED_URL = 'https://r1-api.dotmailer.com/v2/address-books/[ID]/contacts';

  /**
   * The Dotmailer Client wrapper.
   *
   * @var \Drupal\webform_dotmailer\Client\DotmailerClient
   */
  protected $dotmailerClient;

  /**
   * {@inheritdoc}
   */
  public function __construct(array $configuration, $plugin_id, $plugin_definition, LoggerChannelFactoryInterface $logger_factory, ConfigFactoryInterface $config_factory, EntityTypeManagerInterface $entity_type_manager, WebformSubmissionConditionsValidatorInterface $conditions_validator, ModuleHandlerInterface $module_handler, ClientInterface $http_client, WebformTokenManagerInterface $token_manager, DotmailerClient $dotmailer_client) {
    parent::__construct($configuration, $plugin_id, $plugin_definition, $logger_factory, $config_factory, $entity_type_manager, $conditions_validator, $module_handler, $http_client, $token_manager);
    $this->dotmailerClient = $dotmailer_client;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('logger.factory'),
      $container->get('config.factory'),
      $container->get('entity_type.manager'),
      $container->get('webform_submission.conditions_validator'),
      $container->get('module_handler'),
      $container->get('http_client'),
      $container->get('webform.token_manager'),
      $container->get('webform_dotmailer.client')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function defaultConfiguration() {
    $config = parent::defaultConfiguration() + [
      'addressbookid' => '',
      'userid' => '',
    ];
    $config['completed_url'] = self::DEFAULT_COMPLETED_URL;
    $config['type'] = 'json';
    return $config;
  }

  /**
   * {@inheritdoc}
   */
  public function getSummary() {
    $summary = parent::getSummary();
    $configuration = $this->getConfiguration();
    $summary['#settings']['addressbookid'] = $configuration['settings']['addressbookid'];
    return $summary;
  }

  /**
   * {@inheritdoc}
   */
  public function buildConfigurationForm(array $form, FormStateInterface $form_state) {
    $form = parent::buildConfigurationForm($form, $form_state);
  
    $form['completed']['userid'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Enter the user id to post the data to'),
      '#description' => $this->t('This should be prepopulated for you, so only override if you know what you\'re doing'),
      '#required' => TRUE,
      '#parents' => ['settings', 'userid'],
      '#default_value' => $this->getUserId(),
    ];

    $form['completed']['addressbookid'] = [
      '#type' => 'select',
      '#title' => $this->t('Select the address book'),
      '#description' => $this->t('Optionally you can leave this blank and add the address book to the form using checkboxes.'),
      '#options' => $this->getAvailableAddressBooks(),
      '#empty_option' => 'Not applicable',
      '#required' => TRUE,
      '#parents' => ['settings', 'addressbookid'],
      '#default_value' => $this->configuration['addressbookid'],
    ];

    return $form;
  }

  /**
   * Get the available address books from the Dotmailer API.
   */
  protected function getAvailableAddressBooks() {
    $addressBooks = [];
    foreach ($this->dotmailerClient->getAddressBooksArray() as $addressBook) {
      $addressBooks[$addressBook['id']] = $addressBook['name'];
    }
    return $addressBooks;
  }

  /**
   * If not specified get the id from the account info.
   */
  protected function getUserId() {
    if ($this->configuration['userid']) {
      return $this->configuration['userid'];
    }
    $accountInfo = $this->dotmailerClient->getAccountInfoArray();
    return $accountInfo['id'];
  }

  protected function remotePost($state, WebformSubmissionInterface $webform_submission) {
    $this->configuration['completed_url'] = str_replace('[ID]', $this->configuration['addressbookid'], $this->configuration['completed_url']);
    $request_options = (!empty($this->configuration['custom_options'])) ? Yaml::decode($this->configuration['custom_options']) : [];
    $request_options['headers']['Authorization'] = 'Basic ' . $this->dotmailerClient->getBase64Creds();
    $this->configuration['custom_options'] = Yaml::encode($request_options);

    parent::remotePost($state, $webform_submission);
  }

  /**
   * {@inheritdoc}
   */
  protected function getRequestData($state, WebformSubmissionInterface $webform_submission) {
    $dataFields = parent::getRequestData($state, $webform_submission);

    if (empty($dataFields['email'])) {
      return;
    }

    $data = [
      'email' => $dataFields['email'],
      'optInType' => 'Single',
      'status' => 'Subscribed',
    ];
    unset($dataFields['email']);

    foreach ($dataFields as $key => $value) {
      $data['dataFields'][] = [
        'key' => $key,
        'value' => $value,
      ];
    }

    return $data;
  }

}