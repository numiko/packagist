<?php

namespace Drupal\site_alerts\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\site_alerts\SettingsProvider;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Configure settings for site alerts module.
 */
class SiteAlertsSettingsForm extends ConfigFormBase {

  /**
   * Config settings.
   *
   * @var string
   */
  const SETTINGS = 'site_alerts.settings';

  /**
   * The ID of the Alert object field_section field.
   *
   * @var string
   */
  const FIELD_SECTION_ID = 'alert.section_alert.field_section';

  const DEFAULT_NODE_SECTION_FIELD = 'site_alerts_section';

  const DEFAULT_SECTION_TAXONOMY = 'site_section';

  /**
   * The entity type manager service.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * The entity field manager service.
   *
   * @var \Drupal\Core\Entity\EntityFieldManagerInterface
   */
  protected $entityFieldManager;

  /**
   * The site_alerts settings provider service.
   *
   * @var \Drupal\site_alerts\SettingsProvider
   */
  protected $settingsProvider;

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'site_alert_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      static::SETTINGS,
    ];
  }

  /**
   * Class constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $configFactory
   *   Config factory service.
   * @param \Drupal\Core\Entity\EntityTypeManagerInterface $entityTypeManager
   *   Entity type manager service.
   * @param \Drupal\Core\Entity\EntityFieldManagerInterface $entityFieldManager
   *   Entity field manager service.
   * @param \Drupal\site_alerts\SettingsProvider $settingsProvider
   *   The site_alerts settings provider service.
   */
  public function __construct(ConfigFactoryInterface $configFactory, EntityTypeManagerInterface $entityTypeManager, EntityFieldManagerInterface $entityFieldManager, SettingsProvider $settingsProvider) {
    $this->entityTypeManager = $entityTypeManager;
    $this->entityFieldManager = $entityFieldManager;
    $this->settingsProvider = $settingsProvider;
    parent::__construct($configFactory);
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.manager'),
      $container->get('entity_field.manager'),
      $container->get('site_alerts.settings_provider')
    );
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config(static::SETTINGS);

    // Get all node entity_reference fields.
    $fieldMap = $this->entityFieldManager->getFieldMap();
    $nodeFieldMap = $fieldMap['node'];
    $nodeFieldOptions = [];
    foreach ($nodeFieldMap as $fieldName => $nodeField) {
      if ($nodeField['type'] == 'entity_reference') {
        $nodeFieldOptions[$fieldName] = $fieldName;
      }
    }

    $form['site_alert_section_node_field'] = [
      '#type' => 'select',
      '#title' => $this->t('Section node field'),
      '#description' => $this->t('Select a node field to replace the default field. This must be a taxonomy term reference. A cache clear may be required for this to take affect. The default value of this field is @default.', ['@default' => self::DEFAULT_NODE_SECTION_FIELD]),
      '#options' => $nodeFieldOptions,
      '#default_value' => $config->get('site_alert_section_node_field') ? $config->get('site_alert_section_node_field') : self::DEFAULT_NODE_SECTION_FIELD,
    ];

    // Get all taxonomy vocabularies.
    $vocabs = $this->entityTypeManager->getStorage('taxonomy_vocabulary')->loadMultiple();
    $vocabOptions = [];
    foreach ($vocabs as $vocabId => $vocab) {
      $vocabOptions[$vocabId] = $vocab->label();
    }

    $form['site_alert_section_taxonomy'] = [
      '#type' => 'select',
      '#title' => $this->t('Section taxonomy vocabulary'),
      '#description' => $this->t('Select a taxonomy vocabulary to replace the default taxonomy. A cache clear may be required for this to take affect. Changing this setting will amend a field definition, please ensure the configuration changes are exported and saved. The default value of this field is @default.', ['@default' => self::DEFAULT_SECTION_TAXONOMY]),
      '#options' => $vocabOptions,
      '#default_value' => $config->get('site_alert_section_taxonomy') ? $config->get('site_alert_section_taxonomy') : self::DEFAULT_SECTION_TAXONOMY,
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $previousTaxonomy = $this->settingsProvider->getSectionTaxonomy();
    $newTaxonomy = $form_state->getValue('site_alert_section_taxonomy');

    $this->configFactory->getEditable(static::SETTINGS)
      // Set the submitted configuration setting.
      ->set('site_alert_section_node_field', $form_state->getValue('site_alert_section_node_field'))
      ->set('site_alert_section_taxonomy', $form_state->getValue('site_alert_section_taxonomy'))
      ->save();

    // If section taxonomy has changed update field definition target bundle.
    if ($newTaxonomy != $previousTaxonomy) {
      $fields = $this->entityTypeManager->getStorage('field_config')->loadByProperties(['id' => self::FIELD_SECTION_ID]);
      $field = reset($fields);
      $handlerSettings = $field->getSetting('handler_settings');
      $handlerSettings['target_bundles'] = [$newTaxonomy => $newTaxonomy];
      $field->setSetting('handler_settings', $handlerSettings);
      $field->save();
    }

    parent::submitForm($form, $form_state);
  }

}
