<?php

namespace Drupal\Tests\integration_tests\ExistingSite\Personas;

use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;
use weitzman\DrupalTestTraits\Entity\MediaCreationTrait;

/**
 * Test the site permissions.
 *
 * General site permissions tests, checks for adding / editing permissions
 * as well as access to site administration sections, such as but not exclusive
 * to:
 *   - Taxonomy.
 *   - Menus.
 *   - Webforms.
 *   - People.
 *
 * @group personas
 */
class SiteAdminTest extends IntegrationTestBase {

  function setUp(): void {
    parent::setUp();
    $this->createUserWithPersonaAndLogin(['site_admin']);
  }

  /**
   * Test admin pages.
   *
   * Test the personas access to administration functionality.
   */
  public function testAdminFunctions() {

    // Check they can view the content list.
    $this->visitCheckCode('admin/content', Response::HTTP_OK);

    // Check they can create a page.
    $this->visitCheckCode('node/add/page', Response::HTTP_OK);

    // Check Taxonomy access.
    $this->visitCheckCode('admin/structure/taxonomy', Response::HTTP_OK);

    // Check Menu access.
    $this->visitCheckCode('admin/structure/menu', Response::HTTP_OK);

    // Check Webform access.
    $this->visitCheckCode('admin/structure/webform', Response::HTTP_OK);

    // Check Webform adding.
    $this->visitCheckCode('admin/structure/webform/add', Response::HTTP_OK);

    // Check the people list access.
    $this->visitCheckCode('admin/people', Response::HTTP_OK);

    // Check they can can add people.
    $this->visitCheckCode('admin/people/create', Response::HTTP_OK);
  }

  /**
   * Test unpublished content view access.
   */
  public function testContentViewUnpublished() {
    $this->assertViewUnpublishedContentTypeReturnsStatusCode('page', Response::HTTP_OK);
  }

  /**
   * Test content add access.
   */
  public function testContentAdd() {
    $this->assertAddContentTypeReturnsStatusCode('page', Response::HTTP_OK);
  }

  /**
   * Test content edit access.
   */
  public function testContentEdit() {
    $this->assertEditContentTypeReturnsStatusCode('page', Response::HTTP_OK);
  }

  /**
   * Test content edit access.
   */
  public function testContentDelete() {
    $this->assertDeleteContentTypeReturnsStatusCode('page', Response::HTTP_OK);
  }

  /**
   * Test the media add access.
   */
  public function testAddMediaAccess() {
    $this->assertAddMediaTypeReturnsStatusCode('image', Response::HTTP_OK);
    $this->assertAddMediaTypeReturnsStatusCode('core_video', Response::HTTP_OK);
    $this->assertAddMediaTypeReturnsStatusCode('document', Response::HTTP_OK);
  }

  /**
   * Test the media edit access.
   */
  public function testEditMediaAccess() {
    $this->assertEditMediaTypeReturnsStatusCode('image', Response::HTTP_OK);
    $this->assertEditMediaTypeReturnsStatusCode('core_video', Response::HTTP_OK);
    $this->assertEditMediaTypeReturnsStatusCode('document', Response::HTTP_OK);
  }

  /**
   * Test the media edit access.
   */
  public function testDeleteMediaAccess() {
    $this->assertDeleteMediaTypeReturnsStatusCode('image', Response::HTTP_OK);
    $this->assertDeleteMediaTypeReturnsStatusCode('core_video', Response::HTTP_OK);
    $this->assertDeleteMediaTypeReturnsStatusCode('document', Response::HTTP_OK);
  }

  /**
   * Test can create a draft.
   */
  public function testCanCreateDraft() {
    $this->assertCanUseTransition('draft');
  }

  /**
   * Test can publish.
   */
  public function testCanPublish() {
    $this->assertCanUseTransition('published');
  }

  /**
   * Test can archive.
   */
  public function testCanArchive() {
    $this->assertCanUseTransition('archived');
  }

}
