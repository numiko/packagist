<?php

namespace Drupal\Tests\integration_tests\ExistingSite\Slices;

use Drupal\integration_tests\IntegrationTestBase;
use Symfony\Component\HttpFoundation\Response;

/**
 * Test that a content can be created/edited.
 *
 * @group slices
 */
class ContentSliceTest extends IntegrationTestBase {

  /**
   * Test adding a content slice to a node.
   */
  public function testCreateContentSlice() {
    $this->createUserWithPersonaAndLogin(['editor']);
    $paragraphs[] = $this->createParagraph('slice_content', [
      'field_title' => 'Content Slice Title',
      'field_content' => 'Content Slice Content',
    ]);

    $node = $this->createNode(['field_slices' => $paragraphs]);

    $this->visitCheckCode('node/' . $node->id(), Response::HTTP_OK);
    $this->assertSession()->pageTextContains('Content Slice Title');
    $this->assertSession()->pageTextContains('Content Slice Content');
  }

}
