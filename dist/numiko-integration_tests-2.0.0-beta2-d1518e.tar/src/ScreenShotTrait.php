<?php

namespace Drupal\integration_tests;

use Drupal\Component\Utility\Html;

/**
 * Adds methods to capture screenshots on failures.
 */
trait ScreenShotTrait
{

  private function sizes() {
    return [
      'desktop' => [
        'width' => 1440,
        'height' => 900,
      ],
      'tablet' => [
        'width' => 375,
        'height' => 812,
      ],
      'mobile' => [
        'width' => 768,
        'height' => 1024,
      ],
    ];
  }

  /**
   * Captures and saves a screenshot.
   *
   * The filename generated screenshot will contain a unique ID, the URL where
   * the screenshot was taken and the given base filename.
   */
  protected function captureScreenshot()
  {
    foreach ($this->sizes() as $name => $size) {
      $base_filename = Html::cleanCssIdentifier($name);
      $filename = $this->getOutputFileName(getenv('DTT_SCREENSHOT_REPORT_DIRECTORY')) . '_' . $base_filename . '.png';
      $this->getSession()->resizeWindow($size['width'], $size['height']);
      $screenshot = $this->getDriverInstance()->getScreenshot();
      file_put_contents($filename, $screenshot);
    }
  }
}
