<?php

namespace Drupal\instance_migrate\Plugin\migrate\process;

use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\Plugin\migrate\process\Migration;
use Drupal\migrate\Plugin\migrate\process\MigrationLookup;
use Drupal\migrate\Row;

/**
 * If the destination ID doesn't match any source IDs, assume that we're looking
 * for existing content i.e. content that exists on the source and destination
 * sites already (the destination ID will be the source ID).
 *
 * @MigrateProcessPlugin(
 *   id = "migration_with_existing_fallback"
 * )
 */

class MigrationWithExistingFallback extends MigrationLookup
{

  /**
   * {@inheritdoc}
   */
  public function transform($value, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {

    $destinationIds = parent::transform($value, $migrate_executable, $row, $destination_property);
    if (!$destinationIds) {
      return $value;
    }

    return $destinationIds;

  }

}
