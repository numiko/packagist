<?php

namespace Drupal\instance_migrate\Plugin\migrate\process;

use Drupal\Component\Utility\NestedArray;
use Drupal\migrate\Plugin\migrate\process\MigrationLookup;
use Drupal\migrate\ProcessPluginBase;
use Drupal\migrate\MigrateException;
use Drupal\migrate\MigrateExecutableInterface;
use Drupal\migrate\Row;

/**
 * A processor that will look up IDs mapping from the node IDs referenced
 * in a menu link.
 *
 * @todo this and LinkField should have a common base
 *
 * @MigrateProcessPlugin(
 *   id = "menu_link_link",
 *   handle_multiples = FALSE
 * )
 */
class MenuLinkLink extends LinkField {

  /**
   * {@inheritdoc}
   */
  public function transform($value, MigrateExecutableInterface $migrate_executable, Row $row, $destination_property) {

    $returnValue = $sourceUrl = $value;

    // @todo
    if (strpos($sourceUrl, self::LINK_ENTITY_REF_PREFIX) === 0) {
      $nid = $this->findReferencedEntity($sourceUrl);
      if ($nid) {
        $returnValue = self::LINK_ENTITY_REF_PREFIX . '/' . $nid;
      } else {
        throw new MigrateException("Can't find node for menu link " . $sourceUrl);
      }
    }

    return $returnValue;
  }

}
