<?php

namespace Drupal\Tests\site_tests\Functional\Content;

use Drupal\site_tests\DomainTestTrait;
use Drupal\site_tests\ContentTestTrait;
use Drupal\integration_tests\IntegrationTestBase;

/**
 * Test that the redirect page access module is correctly redirecting.
 *
 * @group redirect-page-access
 */
class PageAccessRedirectSubscriberTest extends IntegrationTestBase {

  use ContentTestTrait, DomainTestTrait;

  /**
   * Test person page with public access does NOT redirect.
   */
  public function testPersonPageDoesNotRedirect() {
    $nodeAlias = '/person-page';
    $node = $this->createPublishedNode([
      'type' => 'person',
      'title' => 'Mr John Smith',
      'field_public_access' => TRUE,
    ], $nodeAlias);

    // Assert page remains on the node page.
    $this->visit($nodeAlias);
    $this->assertSession()->addressEquals($nodeAlias);
  }

  /**
   * Test person page with public access does NOT redirect.
   */
  public function testPersonPageDoesRedirect() {
    $nodeAlias = '/person-page-private';
    $node = $this->createPublishedNode([
      'type' => 'person',
      'title' => 'Mr Paul Smith',
      'field_public_access' => FALSE,
    ], $nodeAlias);

    // Assert page has redirected to the front page.
    $this->visit($nodeAlias);
    $this->assertSession()->addressEquals('/');
  }

}
