<?php

namespace Drupal\redirect_page_access\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Entity\EntityTypeBundleInfo;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Config form for this module.
 */
class RedirectPageAccessForm extends ConfigFormBase {

  private const SETTINGS = 'redirect_page_access.settings';

  /**
   * Form constructor.
   *
   * @param \Drupal\Core\Config\ConfigFactoryInterface $cfi
   *   Usual form config.
   * @param \Drupal\Core\Entity\EntityTypeBundleInfo $bundleInfo
   *   Entity bundle info the populates the list of content types.
   */
  public function __construct(ConfigFactoryInterface $cfi, private EntityTypeBundleInfo $bundleInfo) {
    parent::__construct($cfi);
  }

  /**
   * {@inheritDoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('config.factory'),
      $container->get('entity_type.bundle.info')
    );
  }

  /**
   * {@inheritDoc}
   */
  public function getFormId(): string {
    return 'redirect_page_access_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return [self::SETTINGS];
  }

  /**
   * {@inheritDoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config(self::SETTINGS);
    $form['deny_access_field'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Redirect field'),
      '#description' => $this->t('Machine name of the field, if this field on some content is on then the content will be redirected from'),
      '#default_value' => $config->get('deny_access_field'),
    ];

    $bundles = $this->bundleInfo->getBundleInfo('node');
    $bundleOptions = [];
    foreach ($bundles as $bundleId => $bundle) {
      $bundleOptions[$bundleId] = $bundle['label'];
    }
    $form['deny_access_bundle'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Redirect content type'),
      '#description' => $this->t('Which content types to redirect'),
      '#options' => $bundleOptions,
      '#default_value' => $config->get('deny_access_bundle'),
    ];

    $form['deny_access_redirect_uri'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Redirect URI'),
      '#description' => $this->t('Where to redirect the user to'),
      '#default_value' => $config->get('deny_access_redirect_uri'),
    ];
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritDoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    $bundles = $form_state->getValue('deny_access_bundle');
    $bundles = array_values(array_filter($bundles));

    $this->config(self::SETTINGS)
      ->set('deny_access_field', $form_state->getValue('deny_access_field'))
      ->set('deny_access_bundle', $bundles)
      ->set('deny_access_redirect_uri', $form_state->getValue('deny_access_redirect_uri'))
      ->save();
    parent::submitForm($form, $form_state);
  }

}
