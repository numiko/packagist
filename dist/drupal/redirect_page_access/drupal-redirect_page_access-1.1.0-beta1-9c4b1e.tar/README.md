# Redirect Page Access
A module to restrict pages from being viewed by a user without premission. Instead of a 404, this module will redirect them instead.

There are two ways to make a redirect:
- Add a boolean field (by default named `field_public_access` but that can be changed). If a page has this field set to on it will redirect.
- Specify a content type. Any page of that content type will redirect when it is visited.

By default this module will redirect to the homepage, but that can be changed.
