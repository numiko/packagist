<?php

namespace Drupal\redirect_page_access\EventSubscriber;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Symfony\Component\HttpKernel\KernelEvents;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Redirect non-public access pages.
 */
class PageAccessRedirectSubscriber implements EventSubscriberInterface {

  public function __construct(private AccountProxyInterface $currentUser, private ConfigFactoryInterface $config) {
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents() {
    return ([
      KernelEvents::REQUEST => [
        ['redirectNonPublicAccessPages'],
      ],
    ]);
  }

  /**
   * Redirect page requests for pages not marked for public access.
   */
  public function redirectNonPublicAccessPages(RequestEvent $event) {
    // If the user has the 'bypass redirect page access' don't redirect
    if ($this->currentUser->hasPermission('bypass redirect page access')) {
      return;
    }

    $request = $event->getRequest();

    $settings = $this->config->get('redirect_page_access.settings');

    // This is necessary because this also gets called on
    // node sub-tabs such as "edit", "revisions", etc.  This
    // prevents those pages from redirected.
    if ($request->attributes->get('_route') !== 'entity.node.canonical') {
      return;
    }

    // Redirect response.
    $response = new RedirectResponse($settings->get('deny_access_redirect_uri'), 301);

    // Redirect content with the public access field.
    if ($settings->get('deny_access_field') && $request->attributes->get('node')->hasField($settings->get('deny_access_field'))) {
      // Only redirect content with the public access field not ticked.
      if (!$request->attributes->get('node')->get($settings->get('deny_access_field'))->getString()) {
        $event->setResponse($response);
      }
    }

    // Redirect content of a given bundle.
    $bundles = $settings->get('deny_access_bundle');
    if ($bundles && in_array($request->attributes->get('node')->bundle(), $bundles)) {
      $event->setResponse($response);
    }
  }

}
