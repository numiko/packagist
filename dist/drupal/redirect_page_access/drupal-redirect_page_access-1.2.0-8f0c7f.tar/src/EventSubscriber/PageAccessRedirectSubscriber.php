<?php

declare(strict_types=1);

namespace Drupal\redirect_page_access\EventSubscriber;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Session\AccountProxyInterface;
use Drupal\node\NodeInterface;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpKernel\Event\RequestEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Redirect non-public access pages.
 */
class PageAccessRedirectSubscriber implements EventSubscriberInterface {

  public function __construct(
    protected AccountProxyInterface $currentUser,
    protected ConfigFactoryInterface $config,
  ) {}

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents(): array {
    return ([
      KernelEvents::REQUEST => [
        ['redirectNonPublicAccessPages'],
      ],
    ]);
  }

  /**
   * Redirect page requests for pages not marked for public access.
   */
  public function redirectNonPublicAccessPages(RequestEvent $event): void {
    // If the user has the 'bypass redirect page access' don't redirect.
    if ($this->currentUser->hasPermission('bypass redirect page access')) {
      return;
    }

    $request = $event->getRequest();

    $settings = $this->config->get('redirect_page_access.settings');

    // This is necessary because this also gets called on
    // node sub-tabs such as "edit", "revisions", etc.  This
    // prevents those pages from redirected.
    if ($request->attributes->get('_route') !== 'entity.node.canonical') {
      return;
    }

    // Redirect response.
    $response = new RedirectResponse($settings->get('deny_access_redirect_uri'), 301);

    $node = $request->attributes->get('node');
    if (!($node instanceof NodeInterface)) {
      return;
    }

    // Redirect content with the public access field.
    if ($settings->get('deny_access_field') && $node->hasField($settings->get('deny_access_field'))) {
      // Only redirect content with the public access field not ticked.
      if (!$node->get($settings->get('deny_access_field'))->getString()) {
        $event->setResponse($response);
      }
    }

    // Redirect content of a given bundle.
    $bundles = $settings->get('deny_access_bundle');
    if (!empty($bundles) && in_array($node->bundle(), $bundles)) {
      $event->setResponse($response);
    }
  }

}
