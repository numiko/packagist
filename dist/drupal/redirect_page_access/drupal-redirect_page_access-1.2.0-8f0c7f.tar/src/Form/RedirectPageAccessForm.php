<?php

declare(strict_types=1);

namespace Drupal\redirect_page_access\Form;

use Drupal\Core\Config\ConfigFactoryInterface;
use Drupal\Core\Config\TypedConfigManagerInterface;
use Drupal\Core\DependencyInjection\AutowireTrait;
use Drupal\Core\Entity\EntityFieldManagerInterface;
use Drupal\Core\Entity\EntityTypeBundleInfoInterface;
use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Config form for this module.
 */
class RedirectPageAccessForm extends ConfigFormBase {
  use AutowireTrait;

  /**
   * The name of this module's config.
   */
  public const SETTINGS = 'redirect_page_access.settings';

  public function __construct(
    ConfigFactoryInterface $cfi,
    TypedConfigManagerInterface $typedConfigManager,
    protected EntityTypeBundleInfoInterface $bundleInfo,
    protected EntityFieldManagerInterface $entityFieldManager,
  ) {
    parent::__construct($cfi, $typedConfigManager);
  }

  /**
   * {@inheritDoc}
   */
  public function getFormId(): string {
    return 'redirect_page_access_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames(): array {
    return [self::SETTINGS];
  }

  /**
   * {@inheritDoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state): array {
    $config = $this->config(self::SETTINGS);
    $form['deny_access_field'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Redirect field'),
      '#description' => $this->t('Machine name of the field, if this field on some content is on then the content will be redirected from'),
      '#default_value' => $config->get('deny_access_field'),
    ];

    $allBundles = $this->bundleInfo->getBundleInfo('node');
    $bundleOptions = [];
    foreach ($allBundles as $bundleId => $bundle) {
      $bundleOptions[$bundleId] = $bundle['label'];
    }
    $form['deny_access_bundle'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Redirect content type'),
      '#description' => $this->t('Which content types to redirect'),
      '#options' => $bundleOptions,
      '#default_value' => $config->get('deny_access_bundle'),
    ];

    $form['deny_access_redirect_uri'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Redirect URI'),
      '#description' => $this->t('Where to redirect the user to'),
      '#default_value' => $config->get('deny_access_redirect_uri'),
    ];
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritDoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state): void {
    if ($form_state->getValue('deny_access_redirect_uri') == '') {
      $form_state->setErrorByName('deny_access_redirect_uri', $this->t('A URL to redirect to must be provided.'));
    }

    /** @var array<string, string|int> $bundles */
    $bundles = $form_state->getValue('deny_access_bundle');
    $bundles = array_values(array_filter($bundles));

    /** @var string $denyAccessField */
    $denyAccessField = $form_state->getValue('deny_access_field');
    if (empty($bundles) && ($denyAccessField == '')) {
      $form_state->setErrorByName('deny_access_field', $this->t('At least either a content type or...'));
      $form_state->setErrorByName('deny_access_bundle', $this->t('...a field must be provided.'));
    }

    if (($denyAccessField != '') && ($denyAccessField != 'field_public_access') && !$this->doesFieldExist($denyAccessField)) {
      $form_state->setErrorByName('deny_access_field', $this->t('Field @field does not match any fields defined on nodes.', ['@field' => $denyAccessField]));
    }
  }

  /**
   * Is the deny access field an actual field?
   */
  protected function doesFieldExist(string $fieldName): bool {
    $allBundles = $this->bundleInfo->getBundleInfo('node');
    foreach ($allBundles as $bundleId => $_) {
      $fieldsForBundle = $this->entityFieldManager->getFieldDefinitions('node', $bundleId);
      // @todo array_any in PHP 8.4.
      if (array_key_exists($fieldName, $fieldsForBundle)) {
        return TRUE;
      }
    }

    return FALSE;
  }

  /**
   * {@inheritDoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state): void {
    /** @var array<string, string|int> $bundles */
    $bundles = $form_state->getValue('deny_access_bundle');
    $bundles = array_values(array_filter($bundles));

    $this->config(self::SETTINGS)
      ->set('deny_access_field', $form_state->getValue('deny_access_field'))
      ->set('deny_access_bundle', $bundles)
      ->set('deny_access_redirect_uri', $form_state->getValue('deny_access_redirect_uri'))
      ->save();
    parent::submitForm($form, $form_state);
  }

}
