<?php

namespace Drupal\Tests\site_tests\Functional\Content;

use Drupal\integration_tests\IntegrationTestBase;

/**
 * Test that the redirect page access module is correctly redirecting.
 *
 * @group redirect-page-access
 */
class PageAccessRedirectSubscriberTest extends IntegrationTestBase {
  private $prev_config;

  public function setUp(): void {
    parent::setUp();

    $siteConfig = \Drupal::configFactory()->getEditable('redirect_page_access.settings');
    $this->prev_config = $siteConfig->get('deny_access_bundle');
    $siteConfig->set('deny_access_bundle', ['article']);
    $siteConfig->save();

  }

  public function tearDown(): void {
    // Return the settings to how they were
    $siteConfig = \Drupal::configFactory()->getEditable('redirect_page_access.settings');
    $siteConfig->set('deny_access_bundle', $this->prev_config);
    $siteConfig->save();
    parent::tearDown();
  }

  /**
   * Test person page with public access does NOT redirect.
   */
  public function testPersonPageDoesNotRedirect() {
    $nodeAlias = '/person-page';
    $node = $this->createPublishedNode([
      'type' => 'person',
      'title' => 'Mr John Smith',
      'field_public_access' => TRUE,
    ], $nodeAlias);

    // Assert page remains on the node page.
    $this->visit($nodeAlias);
    $this->assertSession()->addressEquals($nodeAlias);
  }

  /**
   * Test person page with private access does redirect.
   */
  public function testPersonPageDoesRedirect() {
    $nodeAlias = '/person-page-private';
    $node = $this->createPublishedNode([
      'type' => 'person',
      'title' => 'Mr Paul Smith',
      'field_public_access' => FALSE,
    ], $nodeAlias);

    // Assert page has redirected to the front page.
    $this->visit($nodeAlias);
    $this->assertSession()->addressEquals('/');
  }

  /**
   * Test person page with public access does redirect.
   */
  public function testPersonPageEditDoesNotRedirect() {
    $nodeAlias = '/person-page-private';
    $node = $this->createPublishedNode([
      'type' => 'person',
      'title' => 'Mr Paul Smith',
      'field_public_access' => FALSE,
    ], $nodeAlias);

    // We need to be an editor to access this page
    $this->createUserWithPersonaAndLogin(['editor']);
    $nodeAlias = '/node/' . $node->id() .'/edit';

    // Assert page remains on the node edit page
    $this->visit($nodeAlias);
    $this->assertSession()->addressEquals($nodeAlias);
  }

  /**
   * Test that the administrator (who always has permission 'bypass redirect page access') is not
   * effected by the redirect
   */
  public function testPersonPageDoesNotRedirectWithPermission() {
    $nodeAlias = '/person-page';
    $node = $this->createPublishedNode([
      'type' => 'person',
      'title' => 'Mr John Smith',
      'field_public_access' => FALSE,
    ], $nodeAlias);

    $this->createUserWithPersonaAndLogin(['administrator']);

    // Assert page remains on the node page.
    $this->visit($nodeAlias);
    $this->assertSession()->addressEquals($nodeAlias);
  }

  public function testPersonBundleDoesRedirect() {
    $nodeAlias = '/article-page-private';
    $node = $this->createPublishedNode([
      'type' => 'article',
      'title' => 'Mr Paul Smith\'s article',
    ], $nodeAlias);

    // Assert page has redirected to the front page.
    $this->visit($nodeAlias);
    $this->assertSession()->addressEquals('/');
  }
}
