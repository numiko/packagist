<?php

namespace Drupal\yamlform2text\Mapper;

use Drupal\yamlform\YamlFormSubmissionInterface;

class Form2TextMapper {

  protected $data = array();

  /**
   * Convert POST data to Form2Text's expected format
   */
  public function map(array $postData, YamlFormSubmissionInterface $yamlform_submission) {
    foreach ($postData['data'] as $field => $value) {
      if (is_array($value)) {
        $this->mapArrayValues($field, $value);
      } else {
        $this->mapFieldValue($field, $value);
      }
    }

    $this->data['delimfields'] = implode(',', array_keys($this->data));
    $this->data['mandfields'] = implode(',', $this->getRequiredFields($yamlform_submission));

    return $this->data;
  }

  /**
   * Handle fields with array values (e.g. multiple choice)
   */
  protected function mapArrayValues($field, $value) {
    if (count($value) > 1) {
      foreach ($value as $optionNumber => $optionValue) {
        $fieldOption = $field . '[' . $optionNumber . ']';
        $this->mapFieldValue($fieldOption, $value);
      }
    } else {
      $this->mapFieldValue($field, $value);
    }
  }

  /**
   * Add the field into the mapped data array.
   */
  protected function mapFieldValue($field, $value) {
    $this->data[$field] = $this->prepareLineBreaks($value);
  }

  /**
   * Prepare line breaks in the required Form2Text format.
   */
  protected function prepareLineBreaks($value) {
    return preg_replace(array("/\r\n/", "/\r/","/\n/"), "[break]", $value);
  }

  /**
   * Get the required fields.
   */
  protected function getRequiredFields(YamlFormSubmissionInterface $yamlform_submission) {
    $requiredFields = array();
    foreach ($yamlform_submission->getYamlForm()->getElementsDecoded() as $elementId => $element) {
      if (isset($element['#required']) && $element['#required']) {
        $requiredFields[] = $elementId;
      }
    }
    return $requiredFields;
  }

}