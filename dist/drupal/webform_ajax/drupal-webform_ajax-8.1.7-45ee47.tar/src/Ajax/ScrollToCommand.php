<?php

namespace Drupal\webform_ajax\Ajax;

use Drupal\Core\Ajax\CommandInterface;

/**
 * Provides an AJAX command for scrolling to an element.
 *
 * This command is implemented in Drupal.AjaxCommands.prototype.viewsScrollTop.
 */
class ScrollToCommand implements CommandInterface {

  /**
   * A CSS selector string.
   *
   * @var string
   */
  protected $selector;

  /**
   * Constructs a \Drupal\webform_ajax\Ajax\ScrollToCommand object.
   *
   * @param string $selector
   *   A CSS selector.
   */
  public function __construct($selector) {
    $this->selector = $selector;
  }

  /**
   * {@inheritdoc}
   */
  public function render() {
    return array(
      'command' => 'webformScrollTo',
      'selector' => $this->selector,
    );
  }

}
