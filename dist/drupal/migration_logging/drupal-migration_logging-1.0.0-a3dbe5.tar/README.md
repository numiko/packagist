# Migration Logging

Generic Drupal migration tracking with detailed reporting, automatic cleanup, and management tools.

## Features

- **Migration entity tracking**: Logs created/updated/deleted/failed entities with links
- **Automatic pruning**: Configurable cleanup by age/count via cron
- **Admin actions**: Clear logs directly from UI
- **Drush commands**: Full CLI management (`ml:clear`, `ml:prune`, `ml:status`)
- **Performance optimized**: Direct database writes, won't slow migrations

## Management

### Admin UI
- **Configure tracking**: Configuration → Development → Migration Logging  
- **View logs**: Reports → Migration Logs
- **Clear logs**: Action buttons with confirmation prompts
- **Auto-prune settings**: Configure age/count limits for automatic cleanup

### Drush Commands
```bash
# Status and cleanup
drush ml:status                    # Show tracking status & log counts
drush ml:prune                     # Manually prune old logs
drush ml:clear --all               # Clear all logs (with confirmation)
drush ml:clear --migration=foo     # Clear specific migration logs
```

### URLs
- Logs: `/admin/reports/migration-logs`
- Detail: `/admin/reports/migration-logs/{migration_id}/{log_id}`
- Config: `/admin/config/development/migration-logging`

## Attribution

Inspired by **Luke Stirk**'s original logging patterns, genericised for reusable migration tracking.