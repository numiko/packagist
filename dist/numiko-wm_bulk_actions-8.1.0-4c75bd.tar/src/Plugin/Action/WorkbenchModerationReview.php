<?php

namespace Drupal\wm_bulk_actions\Plugin\Action;


/**
 * Move a node to Needs Review.
 *
 * @Action(
 *   id = "workbench_moderation_node_review_action",
 *   label = @Translation("Workbench Moderation Needs Review"),
 *   type = "node"
 * )
 */
class WorkbenchModerationReview extends AbstractWorkbenchModerationAction
{
  const STATE_TARGET = 'needs_review';
}
