<?php

namespace Drupal\wm_bulk_actions\Plugin\Action;

use Drupal\Core\Action\ActionBase;
use Drupal\Core\Session\AccountInterface;
use Drupal\Core\Access\AccessResult;

abstract class AbstractWorkbenchModerationAction extends ActionBase
{
  const STATE_DRAFT = 'draft';
  const STATE_PUBLISHED = 'published';

  function __construct() {
    if (!defined('static::STATE_TARGET')) {
        throw new \RuntimeException('Class constant STATE_TARGET must be defined.');
    }
  }

  /**
   * Checks object access.
   *
   * @param mixed $object
   *   The object to execute the action on.
   * @param \Drupal\Core\Session\AccountInterface $account
   *   (optional) The user for which to check access, or NULL to check access
   *   for the current user. Defaults to NULL.
   * @param bool $return_as_object
   *   (optional) Defaults to FALSE.
   *
   * @return bool|\Drupal\Core\Access\AccessResultInterface
   *   The access result. Returns a boolean if $return_as_object is FALSE (this
   *   is the default) and otherwise an AccessResultInterface object.
   *   When a boolean is returned, the result of AccessInterface::isAllowed() is
   *   returned, i.e. TRUE means access is explicitly allowed, FALSE means
   *   access is either explicitly forbidden or "no opinion".
   */
  public function access($object, AccountInterface $account = NULL, $return_as_object = FALSE)
  {
    if (!$account) {
      $account = \Drupal::currentUser()->getAccount();
    }

    $current_state = \Drupal::service('workbench_moderation.moderation_information')->isModeratableEntity($object)
      ? $object->moderation_state->target_id
      : $object->status->value ? self::STATE_PUBLISHED : self::STATE_DRAFT;

    $access = \Drupal::service('workbench_moderation.state_transition_validation')->userMayTransition($current_state, static::STATE_TARGET, $account)
      ? AccessResult::allowed()
      : AccessResult::forbidden();

    return $return_as_object ? $access : $access->isAllowed();
  }

  /**
   * Executes the plugin.
   */
  public function execute($entity = NULL)
  {
    $isModeratable = \Drupal::service('workbench_moderation.moderation_information')->isModeratableEntity($entity);

    if ($isModeratable) {
      $entity->moderation_state->target_id = static::STATE_TARGET;
    } else {
      $entity->status = static::STATE_TARGET == self::STATE_PUBLISHED ? NODE_PUBLISHED : NODE_NOT_PUBLISHED;
    }
    $entity->save();
  }
}
