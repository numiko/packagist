<?php

namespace Drupal\wm_bulk_actions\Plugin\Action;

/**
 * Publishes a node.
 *
 * @Action(
 *   id = "workbench_moderation_node_publish_action",
 *   label = @Translation("Workbench Moderation Publish"),
 *   type = "node"
 * )
 */
class WorkbenchModerationPublish extends AbstractWorkbenchModerationAction
{
	const STATE_TARGET = 'published';
}
