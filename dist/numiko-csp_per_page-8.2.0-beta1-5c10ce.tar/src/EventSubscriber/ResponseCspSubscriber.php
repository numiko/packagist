<?php

namespace Drupal\csp_per_page\EventSubscriber;

use Drupal\csp_per_page\NonceManager;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

/**
 * Intercept response to modify Content Security Policy header.
 */
class ResponseCspSubscriber implements EventSubscriberInterface {

  /**
   * @var \Drupal\Core\Routing\RouteMatchInterface
   */
  private $routeMatch;

  /**
   * @var \Drupal\Core\Config\ConfigFactoryInterface
   */
  private $config;

  /**
   * @var \Drupal\Core\Path\PathMatcherInterface
   */
  private $pathMatcher;

  /**
   * @var \Drupal\Core\Path\CurrentPathStack
   */
  private $currentPath;

  /**
   * @var \Drupal\Core\Path\AliasManagerInterface
   */
  private $aliasManager;

  /**
   * @var \Drupal\csp_per_page\NonceManager
   */
  private $nonceManager;

  /**
   * ResponseCspSubscriber constructor.
   *
   * @param \Drupal\Core\Routing\RouteMatchInterface $routeMatch
   * @param \Drupal\Core\Config\ConfigFactoryInterface $config
   * @param \Drupal\Core\Path\PathMatcherInterface $pathMatcher
   * @param \Drupal\Core\Path\CurrentPathStack $currentPath
   * @param \Drupal\Core\Path\AliasManagerInterface $aliasManager
   */
  public function __construct(\Drupal\Core\Routing\RouteMatchInterface $routeMatch, \Drupal\Core\Config\ConfigFactoryInterface $config, \Drupal\Core\Path\PathMatcherInterface $pathMatcher, \Drupal\Core\Path\CurrentPathStack $currentPath, \Drupal\Core\Path\AliasManagerInterface $aliasManager, NonceManager $nonceManager) {
    $this->routeMatch = $routeMatch;
    $this->config = $config;
    $this->pathMatcher = $pathMatcher;
    $this->currentPath = $currentPath;
    $this->aliasManager = $aliasManager;
    $this->nonceManager = $nonceManager;
  }

  /**
   * {@inheritdoc}
   */
  public static function getSubscribedEvents() {
    $events[KernelEvents::RESPONSE] = ['onKernelResponse', -100];
    return $events;
  }

  /**
   * Use strict CSP on chosen pages.
   *
   * @param \Symfony\Component\HttpKernel\Event\FilterResponseEvent $event
   *   The Response event.
   */
  public function onKernelResponse(FilterResponseEvent $event) {
    if (!$event->isMasterRequest()) {
      return;
    }

    $moduleConfig = $this->config->get('csp_per_page.settings');

    $node = $this->routeMatch->getParameter('node');
    $onStrictNode = $node && in_array($node->getType(), $moduleConfig->get('strict_types'));

    if (!$onStrictNode) {
      $currentPath = $this->currentPath->getPath();
      $currentAlias = $this->aliasManager->getAliasByPath($currentPath);
      $onStrictPage = $this->pathMatcher->matchPath(
        $currentAlias,
        $moduleConfig->get('strict_paths')
      );
    }

    if ($onStrictNode || $onStrictPage) {
      $response = $event->getResponse();
      $response->headers->set(
        'Content-Security-Policy',
        $this->buildPolicyString()
      );
      // Prevent leakage of any reported data.
      $response->headers->remove('Content-Security-Policy-Report-Only');
    }

  }

  /**
   * Build the CSP policy from the individual parts.
   *
   * @return string
   */
  protected function buildPolicyString() {
    $config = $this->config->get('csp_per_page.settings');
    $policy = [];
    $parts = [
      'default-src' => 'strict_policy_default',
      'script-src' => 'strict_policy_script',
      'img-src' => 'strict_policy_img',
      'style-src' => 'strict_policy_style',
      'font-src' => 'strict_policy_font',
    ];
    foreach ($parts as $directive => $configForDirective) {
      $policyPart = $config->get($configForDirective);

      if ($directive == 'script-src') {
        foreach ($this->nonceManager->getGeneratedNonces() as $label => $nonceValue) {
          $policyPart .= " 'nonce-$nonceValue'";
        }
      }
      $policy[] = $directive . ' ' . $policyPart;
    }

    $policy[] = $config->get('strict_policy_additional');

    return implode('; ', $policy);
  }

}
