<?php

namespace Drupal\migrate_group_ui\Plugin\migrate\source;

use Drupal\migrate_source_csv\Plugin\migrate\source\CSV;
use Drupal\migrate_group_ui\Plugin\migrate_plus\data_parser\ReplaceableUrlDataParser;

/**
 * Obtain CSV data for migration.
 *
 * @MigrateSource(
 *   id = "ui_csv"
 * )
 */
class UICsv extends CSV implements ReplaceableUrlSource {

    protected $extensions = array(
        'csv',
      );

    /**
     * Override the source Url with the given url.
     */
    public function replaceUrl($url) {
      $this->configuration['path'] = $url;
    }

    /**
     * Space seperated list of valid extensions for the uploadable file types.
     */
    public function getValidExtensions() {
      return implode(' ', $this->extensions);
    }

}